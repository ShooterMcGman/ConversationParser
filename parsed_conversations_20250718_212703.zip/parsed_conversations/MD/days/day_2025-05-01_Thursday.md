# Daily Conversation: 2025-05-01 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-01 |
| **Day** | Thursday |
| **Week** | 3 |
| **Messages** | 288 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-01T00:03 - 2025-05-01T22:21 |

## 📝 Daily Summary

This day contains **288 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:03` **Meredith Lamb (+14169386001)**

🤯


**002.** `00:08` **You**

You still
Going?


**003.** `00:14` **You**

In bed will try to stay awake for a bit to see how you ended up if you end up texting back


**004.** `00:20` **You**

Uggh will see
You tomorrow\.\.
Nite ❤️ xo hope you are ok\.


**005.** `00:53` **Meredith Lamb (+14169386001)**

Nite xoxo omg still going\. He made me cry 😢


**006.** `01:37` **Meredith Lamb (+14169386001)**

Gah\. Going to bed\. Xoxo lovely evening 🫤


**007.** `01:38` **Meredith Lamb (+14169386001)**

On the bright side, we have both agreed not to talk about this shit again\. No point\. So there is that\. 🤕


**008.** `02:35` **You**

Omg mer I am so sorry fuck what can I do to make you feel better\.\. I love you so much I would do anything\. I tried to stay up but passed out\.  😢 I am sooo sorry you are dealing with that in your own\.


**009.** `02:39` **You**

If you don’t want to come in tomorrow would completely understand\.


**010.** `02:40` **You**

😢 ❤️❤️❤️❤️🏡🏡🏡🏡


**011.** `06:57` **Meredith Lamb (+14169386001)**

We are just not going to talk about past shit anymore\. We aren’t even sure how we got on the conversation honestly\. We were trying to discuss financials etc but it went off track completely\.


**012.** `06:57` **You**

Happened to j and I as well


**013.** `06:58` **Meredith Lamb (+14169386001)**

It comes back to me being to blame for basically everything always\. Lol that’s always the short story 🙄


**014.** `06:59` **You**

That’s awful although Jaimie would say same thing\.\. she always says I blame her for everything and I would say likewise


**015.** `06:59` **You**

20 years there is a lot of shit


**016.** `06:59` **Meredith Lamb (+14169386001)**

We just need to get this over with and live apart\. Very soon\.


**017.** `06:59` **You**

Same


**018.** `06:59` **Meredith Lamb (+14169386001)**

Yeah…


**019.** `07:00` **You**

Anyways i love you very much mer\.\. that’s the truth maybe think about that might make you feel just a bit better\.


**020.** `07:50` **Meredith Lamb (+14169386001)**

I love you too


**021.** `08:00` **You**

I got stuck at home you will beat me in


**022.** `08:01` **Meredith Lamb (+14169386001)**

Omg I got approached this morning so literally ran away


**023.** `08:04` **You**

J and I talked for about an hour or more


**024.** `08:05` **You**

Wasn’t bad


**025.** `08:16` **Meredith Lamb (+14169386001)**

That’s good\. Andrew is just treating me like an idiot constantly  and I’m done with it\. Had to tell him to stop this morning\.


**026.** `08:23` **You**

🙁 u aren’t you are amazing what you do is insane to balance and support everyone including him


**027.** `09:12` **Meredith Lamb (+14169386001)**

So I left something on your desk\. Turn it over\. I didn’t want to write you a note bc felt risky but growing up, our driveway was all those rocks and I used to love walking on them in my bare feet\. Wanted to give you something that reminded me of home\. Xoxoxo


**028.** `09:23` **You**

That was more than a little thing\.\. you are breaking down my work resolve\.\. gawd\. I cannot keep loving you more but I do\.\. thank you so much this means\.\. everything especially now… ❤️❤️❤️❤️ you are my home\.


**029.** `09:26` **You**

Reaction: ❤️ from Meredith Lamb
I wish I could keep it out but I put it in with the cork and the cards\.\. I will always hold on to that\.


**030.** `15:52` **You**

I am likely going to leave soon\.  But you made my day today\.\. just wanted you to know that\.  I love you and if I could show you right now I would\.  I will check on to see if you can chat later not to see if you are ok\.\. I know you don’t want me to do that lol\.


**031.** `16:20` **Meredith Lamb (+14169386001)**

Good job getting out of here\. Lol ❤️


**032.** `16:21` **You**

Errrrrrrrrrrrrrrrrr yeah that was a fail but I am leaving now\.


**033.** `17:08` **You**

So didn’t leave I suck


**034.** `17:08` **You**

Can you send me the contact info for your therapist if you are comfortable with that meant to follow up


**035.** `17:10` **Meredith Lamb (+14169386001)**

Wouldn’t that be weird?


**036.** `17:10` **Meredith Lamb (+14169386001)**

lol


**037.** `17:11` **Meredith Lamb (+14169386001)**

Like she would be getting the same story from both sides??


**038.** `17:14` **You**

Oh well then don’t for sure\.\. I had mentioned it previously you seemed open it’s ok


**039.** `17:15` **Meredith Lamb (+14169386001)**

I mean if she is fine with it I’m fine with it


**040.** `17:18` **You**

I am good either way you just said she was good


**041.** `17:18` **You**

Whatever you are comfortable with


**042.** `17:18` **You**

More whiplash at home


**043.** `17:18` **You**

Going to be a fun night


**044.** `17:19` **Meredith Lamb (+14169386001)**

https://midtowntorontocounselling\.com/


**045.** `17:20` **Meredith Lamb (+14169386001)**

I see Allison


**046.** `17:20` **Meredith Lamb (+14169386001)**

>
What now

*💬 Reply*

**047.** `17:32` **You**

No one will go back now


**048.** `17:32` **You**

And why don’t you ask Allison firsthand


**049.** `17:32` **You**

First


**050.** `17:33` **You**

Don’t want this to be weird


**051.** `17:35` **Meredith Lamb (+14169386001)**

lol I don’t talk to her again until tues


**052.** `17:35` **You**

I can wait


**053.** `17:35` **You**

It’s fine


**054.** `17:36` **Meredith Lamb (+14169386001)**

Okay


**055.** `17:37` **Meredith Lamb (+14169386001)**

I think there will be a lot more flip flopping with your family\. It isn’t a minor change…\. So will take some time


**056.** `17:37` **You**

We will see I don’t know


**057.** `17:37` **You**

I am very frustrated


**058.** `17:37` **You**

But I have to chill


**059.** `17:38` **Meredith Lamb (+14169386001)**

Yes, time is the only solution unfortunately here\.


**060.** `17:38` **Meredith Lamb (+14169386001)**

Things settle with time and the dust needs to settle a bit still


**061.** `17:39` **You**

This seems so logical to me


**062.** `17:39` **You**

But yeah Gracie is hardly that


**063.** `17:41` **Meredith Lamb (+14169386001)**

She just wants her parents to stay together


**064.** `17:41` **Meredith Lamb (+14169386001)**

At any cost


**065.** `17:41` **Meredith Lamb (+14169386001)**

That will be hard to get over


**066.** `17:43` **You**

Yep but if we had t had to deal with so much over past 5 years I would have more empathy\.


**067.** `17:45` **Meredith Lamb (+14169386001)**

Yeah it has to be draining


**068.** `17:45` **Meredith Lamb (+14169386001)**

K I’m driving home now\!


**069.** `17:46` **You**

It took everything and more ok leave ❤️


**070.** `17:46` **You**

Reaction: ❤️ from Meredith Lamb
Talk later


**071.** `17:59` **Meredith Lamb (+14169386001)**

Reality check\. My childhood best friend’s hubby just diagnosed with cancer\. Life is short\.


**072.** `18:00` **Meredith Lamb (+14169386001)**

Grew up with him also\.


**073.** `18:01` **You**

Ah that sucks\.\.  I have lost a few friends along the way recently too\.


**074.** `18:01` **Meredith Lamb (+14169386001)**

😬


**075.** `18:01` **You**

I mean this is kind of what i said to you about us getting older and me wanting to make the most of the time we have


**076.** `18:02` **Meredith Lamb (+14169386001)**

Our limited time lol


**077.** `18:02` **You**

For now limited


**078.** `18:02` **You**

For later I am hoping daily\.


**079.** `18:03` **Meredith Lamb (+14169386001)**

We can dream :\)


**080.** `18:04` **You**

I mean I have to hope\. It is what I want so it is what it is will plan for


**081.** `18:05` **You**

Spending whatever time I have for however long we get is what I want


**082.** `18:07` **You**

Or whatever time you will have me for maybe when I get old you will be like meh whatever


**083.** `18:08` **Meredith Lamb (+14169386001)**

>
I would never… 👎

*💬 Reply*

**084.** `18:09` **You**

lol well I hope to get to see ☺️


**085.** `18:10` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
You will ❤️


**086.** `18:12` **You**

Still thinking about the rock\.  Wish we had 20 extra years so much I want to do with you\.


**087.** `18:13` **You**

Well about to drive into the shitstorm best of luck with yours let me know if you decide\. To tell kids as I hope it goes ok\.  Otherwise at gym tonight again can chat whenever


**088.** `18:16` **Meredith Lamb (+14169386001)**

K ttyl xo


**089.** `18:16` **You**

Do


**090.** `18:16` **You**

Xo


**091.** `18:17` **Meredith Lamb (+14169386001)**

Ps\. Andrew at a “happy hour”


**092.** `18:17` **Meredith Lamb (+14169386001)**

lol


**093.** `18:22` **You**

Ffs I wish we could get another happy hour


**094.** `18:23` **You**

The last few were kinda fun


**095.** `18:24` **Meredith Lamb (+14169386001)**

Totally


**096.** `18:25` **Meredith Lamb (+14169386001)**

Depending on what time he gets home not sure if telling kids tonight\. Sigh this happy hour was last minute


**097.** `18:26` **You**

lol maybe he needs liquid courage?


**098.** `18:26` **You**

Shit


**099.** `18:26` **You**

I forgot he doesn’t drink


**100.** `18:26` **You**

What is happy hour the


**101.** `18:26` **You**

Then


**102.** `18:26` **Meredith Lamb (+14169386001)**

lol


**103.** `18:27` **You**

So confused


**104.** `18:41` **Meredith Lamb (+14169386001)**

On and on and on and on and on…\. This is the freaking neverending story

*📎 1 attachment(s)*

**105.** `18:44` **You**

Well you can give him the choice to be part
Of it or not but that to continue on this way will only further confuse the children to what they are surely catching on to by now and can only get worse as it drags on\.


**106.** `18:46` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**107.** `18:49` **Meredith Lamb (+14169386001)**

Omg he asked if we are preparing a script/notes or just winging it


**108.** `18:49` **Meredith Lamb (+14169386001)**

I can’t even anymore…\.\.


**109.** `18:49` **Meredith Lamb (+14169386001)**

A script


**110.** `18:49` **Meredith Lamb (+14169386001)**

wtf


**111.** `18:52` **You**

I mean I think you just need to say you are done he doesn’t set the time table you have been patient\.\. and accommodating, played your part bud the truth which you will continue to do from them and now his time is up


**112.** `18:52` **You**

lol I don’t know how you have the patience I would have snapped long before now


**113.** `18:54` **You**

I mean I think he will just continue to find excuses to delay it will be something else when he gets back \.\. I mean  I feel for you\.\. wish I could help more


**114.** `18:56` **You**

Sorry I am probably not helping


**115.** `18:56` **Meredith Lamb (+14169386001)**

I will likely just tell them myself lol


**116.** `18:56` **You**

I mean that might be your only option at this point because he will not seem to allow this to proceed


**117.** `18:58` **You**

Only thing is how will he react he won’t do anything stupid will he


**118.** `18:58` **You**

I know you can take care of yourself this isn’t that


**119.** `18:59` **Meredith Lamb (+14169386001)**

I will wait until he gets home from whatever he is doing 😝


**120.** `19:00` **You**

Again you never explained the happy hour thing just lol\.\. is this like wolf of wall street shit


**121.** `19:00` **Meredith Lamb (+14169386001)**

No idea\!


**122.** `19:00` **You**

Or just a bunch of guys


**123.** `19:00` **You**

Sh ok


**124.** `19:00` **Meredith Lamb (+14169386001)**

lol no not guys only


**125.** `19:00` **Meredith Lamb (+14169386001)**

I do know that


**126.** `19:00` **You**

Ah ok\.\. brazen


**127.** `19:00` **Meredith Lamb (+14169386001)**

It might be code for having dinner with someone\. Who knows


**128.** `19:01` **Meredith Lamb (+14169386001)**

Could be anything


**129.** `19:02` **You**

Man… I just…


**130.** `19:03` **Meredith Lamb (+14169386001)**

He used to do them a lot in his 30s\. Then an incident happened in 2016 and he stopped\. When we separated officially he started again lol


**131.** `19:03` **Meredith Lamb (+14169386001)**

I honestly don’t care but I wanted to tell them tonight


**132.** `19:04` **You**

I think it is valid will further force him to continue to move forward and not
Drag his feet\.


**133.** `19:06` **You**

While
You don’t plan on involving lawyers to negotiate they will be drawing up your contract right\.\. Andrew just doesn’t seem
Particularly trustworthy\.


**134.** `19:07` **Meredith Lamb (+14169386001)**

Yeah…


**135.** `19:08` **You**

Uggh this is sucky while I think you will feel better after telling them I still kinda wish he had have just gone to cottage


**136.** `19:12` **Meredith Lamb (+14169386001)**

Oh guess who arrived home when I threatened to tell them myself\. He was out of breath lol


**137.** `19:12` **You**

lol well good luck mer I know it is going to be challenging but at least one of you is an adult


**138.** `19:41` **Meredith Lamb (+14169386001)**

I found a big “mistake” in his spreadsheet and he says he doesn’t know how it happened


**139.** `19:41` **You**

Yeah sure he doesn’t


**140.** `19:42` **You**

lol


**141.** `19:42` **You**

Good for you


**142.** `19:42` **Meredith Lamb (+14169386001)**

My daughter is going to swimming so… gah


**143.** `19:42` **You**

Oh so blocked again


**144.** `19:42` **Meredith Lamb (+14169386001)**

It was $100k


**145.** `19:42` **You**

Ah well


**146.** `19:42` **You**

Monday


**147.** `19:42` **Meredith Lamb (+14169386001)**

Like wtf


**148.** `19:42` **You**

Or whenever it will happen eventually and then you can figure out what is next


**149.** `19:43` **Meredith Lamb (+14169386001)**

He was padding to make it look like I was getting more assets


**150.** `19:43` **You**

I mean you cannot trust him which is why lawyer\.\. the guy feels you are at fault he owes you nothing


**151.** `19:43` **Meredith Lamb (+14169386001)**

Now he’s all worried he has to sell


**152.** `19:43` **Meredith Lamb (+14169386001)**

Yeah contemplating a lawyer now\. Will think tonight


**153.** `19:59` **You**

Sucks mer tough spot and I know you wanted to move this forward well you can decide on lawyers at least to review it and inform you and maybe tell girls after swimming?


**154.** `19:59` **You**

So you can feel you made some progress


**155.** `20:52` **You**

You back in the budgets tonight?


**156.** `20:55` **You**

Well on my side took two hours of j screaming she is trapped
Here and it is my fault and she will need to live in some crappy townhouse etc… I said what do you think I will be living in …\.
She is just fucking mad because no one wants to go back to Moncton\.  Holy hell\.  At gym now going to work this out\.


**157.** `21:02` **You**

I told her I would take both of them and work it out but she won’t do that either


**158.** `21:14` **You**

Doing treadmill listening to our song now or at least I am calling it that


**159.** `21:14` **Meredith Lamb (+14169386001)**

Ugh\. Crappy night too\. Things have gotten very nasty\. I think now I might just take a $300k lump sum spousal \+ monthly child  and be done\.


**160.** `21:14` **Meredith Lamb (+14169386001)**

We are going to try to find a lawyer tomorrow


**161.** `21:14` **Meredith Lamb (+14169386001)**

Meet as soon as we can and be done


**162.** `21:14` **You**

Array hun


**163.** `21:14` **You**

Sorry


**164.** `21:14` **You**

Kids ok


**165.** `21:14` **Meredith Lamb (+14169386001)**

Not sure on telling kids


**166.** `21:14` **Meredith Lamb (+14169386001)**

Maelle at bronze cross


**167.** `21:15` **Meredith Lamb (+14169386001)**

Maelle’s bday is Monday and she wants me to take her to Yorkdale tomorrow night after work


**168.** `21:15` **Meredith Lamb (+14169386001)**

He said he’d stay home from cottage to tell them and I’m like ughhhhh ummmm


**169.** `21:15` **Meredith Lamb (+14169386001)**

I’d rather he go honestly


**170.** `21:16` **Meredith Lamb (+14169386001)**

I want to have a nice weekend


**171.** `21:16` **You**

I totally get it\.\. makes
Sense


**172.** `21:16` **Meredith Lamb (+14169386001)**

I’m thinking maybe we tell them wed or thurs


**173.** `21:16` **Meredith Lamb (+14169386001)**

If they want to stay home from school for a day they can


**174.** `21:17` **You**

Seems like you are trying best you can


**175.** `21:17` **Meredith Lamb (+14169386001)**

But we will see\. He is mad and doesn’t want to go to cottage now


**176.** `21:17` **Meredith Lamb (+14169386001)**

Ughhhhhhhhhhh


**177.** `21:17` **You**

Asshole


**178.** `21:17` **Meredith Lamb (+14169386001)**

He wants me to apologize for telling them in December when he was in the uk


**179.** `21:18` **You**

Tell him to apologize
In front of kids for text and for 2016


**180.** `21:18` **You**

And you would be happy to apologize for December


**181.** `21:18` **Meredith Lamb (+14169386001)**

I am not apologizing ever I told him


**182.** `21:19` **Meredith Lamb (+14169386001)**

That was directly correlated to his actions


**183.** `21:19` **Meredith Lamb (+14169386001)**

Will never apologize


**184.** `21:19` **You**

Yeah well he doesn’t deserve shit


**185.** `21:19` **You**

Not after that


**186.** `21:19` **You**

Or whatever came\. Edie’s


**187.** `21:19` **You**

Before


**188.** `21:19` **You**

Doesn’t sound like you had a happy life for a while


**189.** `21:20` **Meredith Lamb (+14169386001)**

We just need to live apart asap


**190.** `21:20` **Meredith Lamb (+14169386001)**

It is getting bad


**191.** `21:20` **You**

I am worried about the same thing


**192.** `21:20` **You**

For me I know you got you lol


**193.** `21:22` **Meredith Lamb (+14169386001)**

lol thank you


**194.** `21:22` **You**

Hehe


**195.** `21:22` **Meredith Lamb (+14169386001)**

Good save


**196.** `21:22` **You**

Reaction: ❤️ from Meredith Lamb
But listen I am not to proud you can rescue me whenever you want


**197.** `21:23` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/37LNNQNbL1YLyutBG6aWRx?si=NdlXu12xRt\-99WJWmsdllg


**198.** `21:24` **Meredith Lamb (+14169386001)**

Haha


**199.** `21:24` **Meredith Lamb (+14169386001)**

Actually a good song


**200.** `21:25` **You**

I know I like that song\.


**201.** `21:25` **You**

Back night workout with Morgan wallen se how this goes


**202.** `21:54` **You**

I mean I like him but not feeling it


**203.** `21:55` **You**

He is just to smooth need something with a kick to workout\.


**204.** `21:57` **You**

And that stache is so distracting


**205.** `22:01` **You**

https://open\.spotify\.com/track/6OMwRbRH5SnUDNNvga360Q?si=pAs9FjuKSpm7aaZOHv0Fog&context=spotify%3Asearch%3Achampion%2Bmiranda
Thinking of you my love you are this song\.


**206.** `22:03` **Meredith Lamb (+14169386001)**

Sorry, final conversation for the night\. Gah


**207.** `22:03` **Meredith Lamb (+14169386001)**

All done


**208.** `22:03` **You**

Sorry you had to go through all that been many lights in a row fucking sucks


**209.** `22:03` **You**

Listen to the song and feel better


**210.** `22:04` **Meredith Lamb (+14169386001)**

Yeah we are both done, exhausted and so done with each other\.


**211.** `22:05` **You**

I mean I am sad for what you have had to go through but I am happy if you are closer to where you want to be


**212.** `22:05` **Meredith Lamb (+14169386001)**

Yeah\. Lawyer next up\.


**213.** `22:05` **You**

Fack


**214.** `22:05` **Meredith Lamb (+14169386001)**

We are telling kids thurs


**215.** `22:05` **You**

Kk


**216.** `22:05` **Meredith Lamb (+14169386001)**

He’s going to cottage thank god


**217.** `22:06` **You**

Gl till then


**218.** `22:14` **You**

Not last chat?  Deja vu


**219.** `22:15` **Meredith Lamb (+14169386001)**

Huh? Sorry, just sitting here\. I miss you\.


**220.** `22:16` **You**

You ok??


**221.** `22:16` **Meredith Lamb (+14169386001)**

Yah


**222.** `22:16` **You**

Miss you always could give you a great big hug right now


**223.** `22:16` **You**

Sucks being apart\.\. any chance
You have to go out in your own this weekend anywhere during the day\.


**224.** `22:17` **You**

I could meet you just to say hey give you that big hug and chat for a few mins only


**225.** `22:17` **You**

I am ok if not


**226.** `22:17` **You**

Just thinking


**227.** `22:18` **Meredith Lamb (+14169386001)**

Yeah not 100%\. I have to buy Maelle bday gifts\.


**228.** `22:18` **You**

I know you got shopping tommorrow night and prep for bday I am sure over the weekend


**229.** `22:18` **You**

Just thought there might be an hour no worries mer just trying to lighten your load lol not make it worse


**230.** `22:18` **Meredith Lamb (+14169386001)**

I also have to get Maelle to a bat mitzvah for 6\.30pm on Sat night and Marlowe to a bat mitzvah for 7pm on Sat night\. 😵‍💫


**231.** `22:18` **Meredith Lamb (+14169386001)**

Somehow


**232.** `22:18` **You**

Sok


**233.** `22:18` **You**

Dun worry


**234.** `22:19` **Meredith Lamb (+14169386001)**

I might see if Marlowe can carpool


**235.** `22:19` **Meredith Lamb (+14169386001)**

I have some planning to do


**236.** `22:20` **You**

Yep take care of your stuff all
Good


**237.** `22:20` **Meredith Lamb (+14169386001)**

Are you worried we are going to drift if we don’t get to see each other?


**238.** `22:20` **Meredith Lamb (+14169386001)**

Is that what your head was thinking last night


**239.** `22:20` **You**

Nope


**240.** `22:21` **You**

I was worried you would think it not worth the trouble eventually


**241.** `22:21` **You**

Or maybe you might drift sure


**242.** `22:21` **You**

Possibly


**243.** `22:21` **You**

Not me


**244.** `22:21` **You**

And not you


**245.** `22:21` **You**

Really after this morning


**246.** `22:22` **You**

But I am still worried about the not worth the trouble you have other priorities


**247.** `22:22` **You**

More to lift than me


**248.** `22:22` **Meredith Lamb (+14169386001)**

Maybe you will think my busy life isn’t worth YOUR trouble lol


**249.** `22:23` **You**

No mer I would happily join you in that just life


**250.** `22:23` **You**

Happily


**251.** `22:24` **You**

Honestly I have pretty blunt even today in the office and last night there has never been and never will be anyone other than you for me I have never been more certain of anything in my life\.\. cannot say it more plainly


**252.** `22:24` **You**

I am just trying to find time to see you because I love you and want to hug you and make you feel better not rescue you\.


**253.** `22:24` **You**

Not because I am worried


**254.** `22:25` **Meredith Lamb (+14169386001)**

Yeah I wish we could…\.\.


**255.** `22:25` **You**

Well if you can find an hour at all I say or Sunday I will try to find a way to meet you halfway wherever you want\.  Open offer no expectations


**256.** `22:27` **Meredith Lamb (+14169386001)**

We will see\. Hard with my little shadow…


**257.** `22:27` **Meredith Lamb (+14169386001)**

:p


**258.** `22:27` **You**

I get it


**259.** `22:31` **You**

Well maybe we video chat tomorrow night whatever works mer I am up for it


**260.** `22:33` **Meredith Lamb (+14169386001)**

Hmmmh possible …


**261.** `22:37` **Meredith Lamb (+14169386001)**

I think I’m going to just go to bed early right now\. Feeling super exhausted and drained\.


**262.** `22:37` **Meredith Lamb (+14169386001)**

I love you, miss you, … 😕


**263.** `22:38` **You**

Love
You too same xoxox chat tomorrow if you have time


**264.** `22:41` **You**

Reaction: ❤️ from Meredith Lamb
Hope
You dream
Of home tonight and better times


**265.** `22:15` **Meredith Lamb (+14169386001)**

Huh? Sorry, just sitting here\. I miss you\.


**266.** `22:16` **You**

You ok??


**267.** `22:16` **Meredith Lamb (+14169386001)**

Yah


**268.** `22:16` **You**

Miss you always could give you a great big hug right now


**269.** `22:16` **You**

Sucks being apart\.\. any chance
You have to go out in your own this weekend anywhere during the day\.


**270.** `22:17` **You**

I could meet you just to say hey give you that big hug and chat for a few mins only


**271.** `22:17` **You**

I am ok if not


**272.** `22:17` **You**

Just thinking


**273.** `22:18` **Meredith Lamb (+14169386001)**

Yeah not 100%\. I have to buy Maelle bday gifts\.


**274.** `22:18` **You**

I know you got shopping tommorrow night and prep for bday I am sure over the weekend


**275.** `22:18` **You**

Just thought there might be an hour no worries mer just trying to lighten your load lol not make it worse


**276.** `22:18` **Meredith Lamb (+14169386001)**

I also have to get Maelle to a bat mitzvah for 6\.30pm on Sat night and Marlowe to a bat mitzvah for 7pm on Sat night\. 😵‍💫


**277.** `22:18` **Meredith Lamb (+14169386001)**

Somehow


**278.** `22:18` **You**

Sok


**279.** `22:18` **You**

Dun worry


**280.** `22:19` **Meredith Lamb (+14169386001)**

I might see if Marlowe can carpool


**281.** `22:19` **Meredith Lamb (+14169386001)**

I have some planning to do


**282.** `22:20` **You**

Yep take care of your stuff all
Good


**283.** `22:20` **Meredith Lamb (+14169386001)**

Are you worried we are going to drift if we don’t get to see each other?


**284.** `22:20` **Meredith Lamb (+14169386001)**

Is that what your head was thinking last night


**285.** `22:20` **You**

Nope


**286.** `22:21` **You**

I was worried you would think it not worth the trouble eventually


**287.** `22:21` **You**

Or maybe you might drift sure


**288.** `22:21` **You**

Possibly


