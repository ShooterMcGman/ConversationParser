# Daily Conversation: 2025-06-24 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-24 |
| **Day** | Tuesday |
| **Week** | 11 |
| **Messages** | 160 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-24T04:10 - 2025-06-24T22:36 |

## 📝 Daily Summary

This day contains **160 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:10` **You**

We will see\.\. I love you too\.\. hope you had a good sleep\. ❤️


**002.** `05:47` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
G’morn ❤️


**003.** `06:20` **Meredith Lamb (+14169386001)**

So I met this really nice agent over the phone and he’s helping me now


**004.** `06:21` **Meredith Lamb (+14169386001)**

Such a nice guy so I am feeling better about finding a place


**005.** `06:21` **Meredith Lamb (+14169386001)**

He sent me a whole bunch of places


**006.** `06:21` **Meredith Lamb (+14169386001)**

And asked for all the docs I need


**007.** `06:21` **Meredith Lamb (+14169386001)**

Like credit report, employment letter…


**008.** `06:22` **Meredith Lamb (+14169386001)**

A few of the places I hadn’t seen online


**009.** `06:22` **You**

Cool well hope you can find something that ticks all the boxes


**010.** `06:23` **Meredith Lamb (+14169386001)**

Well that will be impossible but looking better at least


**011.** `06:24` **You**

Impossible\.\. thought you didn’t like absolutes\.


**012.** `06:33` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28033947/2\-22\-college\-view\-avenue\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
I like this place even though it is really pricey\. Right near our place but not too close\. I dunno\.


**013.** `06:36` **You**

Beautiful\.\. but I think you need
To do a budget\.


**014.** `06:39` **You**

Maybe get big bro Jim to help🙂


**015.** `06:39` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 24 Jun 2025 06:39:46 \-0400
|
| I have done a budget
|
| Version: 1
| Sent: Tue, 24 Jun 2025 06:39:38 \-0400
|
| I have done a burger


**016.** `06:39` **You**

Mmmm


**017.** `06:39` **You**

Burger


**018.** `06:39` **Meredith Lamb (+14169386001)**

But I used $5k for rent


**019.** `06:40` **Meredith Lamb (+14169386001)**

Because I have the cottage too


**020.** `06:40` **Meredith Lamb (+14169386001)**

It’s like $1,500 a month


**021.** `06:40` **You**

Jesus lol


**022.** `06:40` **Meredith Lamb (+14169386001)**

lol


**023.** `06:41` **Meredith Lamb (+14169386001)**

This is why I need his $\.


**024.** `06:41` **Meredith Lamb (+14169386001)**

I only see myself in yeg area for another 5 years really


**025.** `06:43` **You**

I mean I can’t see you really building any savings for yourself in next 5\-7 years


**026.** `06:43` **You**

You might want to meet with an advisor


**027.** `06:44` **You**

This is why i thought it wad important to fight about the broken pension if you hadn’t have broken it you would be completely fine


**028.** `06:44` **You**

I just worry about you


**029.** `06:45` **Meredith Lamb (+14169386001)**

Yes yes I know


**030.** `06:45` **You**

lol dismissive rofl typical mer


**031.** `06:50` **Meredith Lamb (+14169386001)**

😇


**032.** `06:50` **You**

Got says you need between 330k and 350 k gross


**033.** `06:50` **You**

For your situation allowing you to responsibly save for yourself as well


**034.** `06:51` **You**

With a 5400 rent and another 1500 mortgage


**035.** `06:54` **You**

Reaction: 😂 from Meredith Lamb
Alright well I will see you from across the room work\.\. going to sauna and shower and then head in\.


**036.** `06:55` **Meredith Lamb (+14169386001)**

>
Gross what?

*💬 Reply*

**037.** `06:55` **You**

Salary


**038.** `06:55` **Meredith Lamb (+14169386001)**

Oh right


**039.** `06:56` **Meredith Lamb (+14169386001)**

Well it would be only for 5 yrs


**040.** `06:56` **Meredith Lamb (+14169386001)**

So almost like a 5 yr pause


**041.** `06:56` **Meredith Lamb (+14169386001)**

We can’t sell the cottage now


**042.** `06:56` **Meredith Lamb (+14169386001)**

I have no choice on that


**043.** `06:57` **Meredith Lamb (+14169386001)**

I can maybe get out in a couple years


**044.** `06:57` **You**

Ok hon\.\. well I will do whatever I can to help cause I love you and that’s what I’ll do\.


**045.** `06:57` **You**

Will chat in a bit\.


**046.** `06:57` **You**

❤️


**047.** `06:57` **Meredith Lamb (+14169386001)**

Reaction: 😂 from Scott Hicks
k going to finish this workout in my home sauna :p


**048.** `07:56` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/2a7NRfaVMfob2BvkBmOxA0?si=ukRe\_u9DRQaY3NUFgbpXCg
I asked ChatGPT what songs I would like and it gave me this one and I DID used to love this song and forgot about it\. Funny\.


**049.** `08:14` **You**

Listened to this recently when I was going through that self
Loathing phase


**050.** `08:14` **You**

Same time I listened to sia\.


**051.** `08:17` **Meredith Lamb (+14169386001)**

I hope you are not self loathing anymore lol


**052.** `08:21` **You**

…\.\.sometimes…\. I am
Just much more in control of my emotions now\.


**053.** `08:21` **You**

You are more likely now
To only see what I want you to… took me a fucking while to get back in control


**054.** `08:45` **Meredith Lamb (+14169386001)**

>
“sometimes”…\.omg i don’t get this at all\. You have absolutely zero to be self loathing about … blows my mind\.

*💬 Reply*

**055.** `08:46` **You**

Reaction: ❤️ from Meredith Lamb
Whatever it is me\.\. but I do have a lot more control than I did recently so I am quite pleased about that tbh\.


**056.** `09:07` **You**

You might not be though 😜


**057.** `09:09` **Meredith Lamb (+14169386001)**

lol


**058.** `09:31` **Meredith Lamb (+14169386001)**

I think I’m going to just attempt to secure that semi with no basement\. Live for a year and see how it goes\.


**059.** `09:31` **You**

Prolly smart tbh not optimal but within budget and you only have to do a year


**060.** `09:32` **Meredith Lamb (+14169386001)**

Yeah I told Diana and she seems happy


**061.** `09:50` **You**

I mean it is nice to have that support right nearby


**062.** `09:50` **You**

How far from current house?


**063.** `09:50` **You**

Like walk across park or something isn’t it


**064.** `09:54` **Meredith Lamb (+14169386001)**

Yup literally that close


**065.** `10:00` **Meredith Lamb (+14169386001)**

So what do I wear on Saturday? Is this like wedding dressy? Do I have to buy something? What are you wearing


**066.** `10:40` **You**

Probably khaikis and a dress shirt or collared golf shirt with dress shoes


**067.** `10:56` **Meredith Lamb (+14169386001)**

So not wedding dressy


**068.** `12:02` **You**

Reaction: 😂 from Meredith Lamb
Since Jessica is also a clergy person, she will be wearing a robe and stole\.
In the Episcopal Church, the ordination of a priest is a big deal and some people highlight the significance of that in their attire\. Other people don’t give a shit and wear whatever\.
However, I would certainly never want you to feel embarrassed because you felt underdressed\. Based on what I know about you, I think you would feel most comfortable with khakis and a button\-down shirt… Throw on a jacket if you like Jessica will wear a dress\. I’m so Meredith may want to take this chance to have a little fun with what she wears Keeping in mind that we’re going to church and not the club\.🤣


**069.** `13:55` **Meredith Lamb (+14169386001)**

Meredith is no fun ever in what she wears\. :\)


**070.** `15:00` **You**

ROFL


**071.** `15:00` **You**

You good btw you looked
Like you might be cranky when I walked by\.\. I tend to elicit that look from many people so I woildnt be surprised


**072.** `15:03` **Meredith Lamb (+14169386001)**

I have a head ache but am fine lol


**073.** `15:03` **Meredith Lamb (+14169386001)**

Not cranky


**074.** `15:03` **Meredith Lamb (+14169386001)**

Going to take my girls to see that place tonight at 8


**075.** `15:48` **You**

The one by Diane\.\. cook I hope they like it\.\. Mac won’t\.


**076.** `15:57` **Meredith Lamb (+14169386001)**

Mac will hate


**077.** `15:57` **You**

Yah not fancy no amenities


**078.** `15:57` **You**

She is used to a certain standard of living


**079.** `15:59` **Meredith Lamb (+14169386001)**

I could make it nice ENOUGH


**080.** `15:59` **Meredith Lamb (+14169386001)**

I will tell her I will have extra money for nice stuff


**081.** `16:02` **You**

Smart


**082.** `16:02` **You**

That is the selling feature


**083.** `16:42` **You**

Looking for me


**084.** `16:42` **You**

Almost done


**085.** `16:45` **Meredith Lamb (+14169386001)**

Not really was just looking :\)


**086.** `16:45` **You**

Omg what a fucking day


**087.** `16:46` **You**

Well I caught you


**088.** `16:46` **You**

😜


**089.** `16:48` **You**

So not staying late tonight \.\. fuck I am tired and cranky as hell


**090.** `16:48` **You**

Gracie called me
4
Times in the mgmt
Meeting


**091.** `16:52` **Meredith Lamb (+14169386001)**

Yikes why


**092.** `16:52` **You**

Cause she wants to give me a stroke\.


**093.** `16:57` **Meredith Lamb (+14169386001)**

Gahhh


**094.** `16:57` **Meredith Lamb (+14169386001)**

I am going to leave\. Tired and need to talk financial with Andrew tonight argh


**095.** `16:58` **Meredith Lamb (+14169386001)**

He’s been trying over text and I’m like I want to leave can we do this at home not on text


**096.** `16:58` **Meredith Lamb (+14169386001)**

Ffs


**097.** `17:02` **You**

Yeah I am right behind you\.\. have a good night


**098.** `17:02` **Meredith Lamb (+14169386001)**

“Good” …\. Definitely won’t be but oh well


**099.** `17:07` **You**

Reaction: ❤️ from Meredith Lamb
Love you\. ❤️


**100.** `17:08` **You**

Can’t really say that in parking lot lol


**101.** `17:08` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**102.** `17:09` **Meredith Lamb (+14169386001)**

lol wtf


**103.** `17:09` **You**

ROFL


**104.** `17:48` **You**

Not sus at all


**105.** `18:32` **Meredith Lamb (+14169386001)**

k Andrew and I done\. I’m having a nap\. I so want all of this done\. Omg


**106.** `18:33` **You**

Hope it was ok


**107.** `18:34` **Meredith Lamb (+14169386001)**

Not really


**108.** `18:34` **Meredith Lamb (+14169386001)**

But I need to nap for an hour


**109.** `18:34` **You**

Kk later then ❤️


**110.** `21:29` **Meredith Lamb (+14169386001)**

So the Edith place\. Rough


**111.** `21:30` **You**

Not fixable?


**112.** `21:30` **Meredith Lamb (+14169386001)**

So went to this place: https://realtor\.ca/real\-estate/28504794/196\-lawrence\-avenue\-w\-toronto\-lawrence\-park\-south\-lawrence\-park\-south?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**113.** `21:30` **Meredith Lamb (+14169386001)**

He’s going to try to get it for me tonight or tomorrow morning


**114.** `21:30` **Meredith Lamb (+14169386001)**

>
Not really\. Diana bummed for sure

*💬 Reply*

**115.** `21:31` **You**

Get it for you?


**116.** `21:31` **You**

Like for a walkthrough


**117.** `21:31` **Meredith Lamb (+14169386001)**

No to rent


**118.** `21:31` **You**

Or you getting it


**119.** `21:31` **You**

Jesus


**120.** `21:31` **You**

Ok


**121.** `21:31` **Meredith Lamb (+14169386001)**

Walked through it just now


**122.** `21:31` **You**

Kids like


**123.** `21:31` **Meredith Lamb (+14169386001)**

Only Maelle went with me


**124.** `21:31` **Meredith Lamb (+14169386001)**

She did


**125.** `21:31` **You**

Nice


**126.** `21:33` **Meredith Lamb (+14169386001)**

We will see\. Hopefully\. I just want to get a place and be done


**127.** `21:33` **You**

Yah makes
Sense


**128.** `21:34` **Meredith Lamb (+14169386001)**

Rough night


**129.** `21:34` **Meredith Lamb (+14169386001)**

Just overwhelming and Andrew wants spousal to go down $100k


**130.** `21:34` **Meredith Lamb (+14169386001)**

So lump sum of $214k instead of $330k


**131.** `21:35` **You**

You are going to have to push back and hard and mean\.\. and mean it unless you are
Willing to do what he wants\.\. he is just going to keep beating on you I feel\.\. and I am sorry he is doing it\.


**132.** `21:53` **Meredith Lamb (+14169386001)**

Well he is saying he is doing the high end of child so should be lower on spousal


**133.** `21:53` **Meredith Lamb (+14169386001)**

It’s hard to know what is right because his income is so high that the tables don’t work


**134.** `21:54` **Meredith Lamb (+14169386001)**

Can I use you as a reference on my application for rental\. Would that be weird


**135.** `21:54` **Meredith Lamb (+14169386001)**

I need 2 and not too many ppl know im applying\. Using Diana first


**136.** `21:55` **Meredith Lamb (+14169386001)**

You were my boss for quite a while so it works


**137.** `22:05` **You**

>
Yes

*💬 Reply*

**138.** `22:06` **You**

>
See what the mediator suggests\.\. she suggests 12 years\.\. your answer that seems reasonable to me timid the mid point

*💬 Reply*

**139.** `22:06` **You**

He tries to push x for 4% ask the mediator what the standard is\. Then agree maybe with something in the middle


**140.** `22:07` **You**

If he is doing 8 years out him big end on both of 12 maybe mid?


**141.** `22:07` **Meredith Lamb (+14169386001)**

The 214k is based on 12 yrs


**142.** `22:07` **You**

I dont think you agree to anything


**143.** `22:07` **Meredith Lamb (+14169386001)**

I’m going to ask him tonight why the floor and not in the middle


**144.** `22:07` **You**

Just tell him you are tired


**145.** `22:08` **You**

And that this is why you have a mediator


**146.** `22:08` **You**

We will see what her recommendation is and then I will provide my feedback


**147.** `22:15` **Meredith Lamb (+14169386001)**

Ugh I hate all of this so much


**148.** `22:15` **You**

What now


**149.** `22:15` **Meredith Lamb (+14169386001)**

No nothing new\. Just thinking out loud lol


**150.** `22:16` **You**

Oh I thought you said you were asking him and went and did it


**151.** `22:21` **You**

You watching tv


**152.** `22:22` **Meredith Lamb (+14169386001)**

No just sent through docs for the rental offer


**153.** `22:22` **Meredith Lamb (+14169386001)**

Had to fill out a bunch of stuff


**154.** `22:23` **Meredith Lamb (+14169386001)**

And download pay stubs


**155.** `22:23` **Meredith Lamb (+14169386001)**

Just finished


**156.** `22:23` **You**

Ah ok\.\.


**157.** `22:23` **You**

Didnt know if you went off to battle and if I should just go to bed lol\.\.


**158.** `22:32` **You**

I feel like you have had a busy night and are still in it\.\. I am going to go to bed\.\. my night was not great gracie fought with us most of night then j and I fought again\.


**159.** `22:33` **You**

So I am tired and going to sleep\.\.   love you\.\. night


**160.** `22:36` **Meredith Lamb (+14169386001)**

Love you too \- sleep well ❤️❤️


