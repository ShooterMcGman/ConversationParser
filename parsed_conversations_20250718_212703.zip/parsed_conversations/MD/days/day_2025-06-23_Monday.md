# Daily Conversation: 2025-06-23 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-23 |
| **Day** | Monday |
| **Week** | 11 |
| **Messages** | 314 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-23T04:04 - 2025-06-23T21:47 |

## 📝 Daily Summary

This day contains **314 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:04` **You**

Reaction: ❤️ from Meredith Lamb
Morning love\.\. last thought first thought\.❤️❤️❤️


**002.** `04:05` **You**

Going to see if a push workout at 8 pm can be followed by a pull workout at 5 am\.\. lol let’s see how I feel rofl\.


**003.** `05:22` **You**

Just starting and not feeling it lol\.\. this gonna hurt\.


**004.** `05:22` **You**

Hope you have better luck today with your workout


**005.** `05:45` **Meredith Lamb (+14169386001)**

>
Please don’t give yourself a heart attack 🙁

*💬 Reply*

**006.** `05:46` **Meredith Lamb (+14169386001)**

That would be very very sad


**007.** `05:46` **Meredith Lamb (+14169386001)**

You are going SO hard


**008.** `05:46` **You**

>
I don’t think you need to worry too
Much\.

*💬 Reply*

**009.** `05:47` **Meredith Lamb (+14169386001)**

>
I have cheat day and it is my favourite so I should be ok today :\)

*💬 Reply*

**010.** `05:47` **Meredith Lamb (+14169386001)**

>
I hope so\. You are going really hard right now

*💬 Reply*

**011.** `05:48` **Meredith Lamb (+14169386001)**

Love you \- coffee time tho lol


**012.** `05:48` **You**

Love you enjoy your coffee\.  ☺️


**013.** `06:39` **You**


*📎 1 attachment(s)*

**014.** `06:39` **You**


*📎 1 attachment(s)*

**015.** `06:40` **You**

Can never find a good place to do these


**016.** `06:41` **Meredith Lamb (+14169386001)**

Total law enforcement lol


**017.** `06:41` **Meredith Lamb (+14169386001)**

😍


**018.** `06:41` **You**

Prolly cause I was white and bald


**019.** `06:44` **Meredith Lamb (+14169386001)**

lol no


**020.** `06:45` **You**

Hmm I think so\.\. anyhow sauna showers then omw hope
Your morning is going well\.


**021.** `06:46` **Meredith Lamb (+14169386001)**

Going ok but our house is got so I’m dying


**022.** `06:46` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**023.** `06:46` **You**

Cold shower


**024.** `06:47` **You**

Ooh Russian twists


**025.** `06:47` **Meredith Lamb (+14169386001)**

Burpees and suicides are getting easier so babysteps is working


**026.** `06:47` **You**

Have fun with those


**027.** `06:47` **You**

lol


**028.** `06:47` **You**

You cannot do it any other way\.\. without hurting yourself\.\. you got it\.\. ❤️


**029.** `06:48` **Meredith Lamb (+14169386001)**

Supposed to be doing 3 sets of 12


**030.** `06:48` **Meredith Lamb (+14169386001)**

Moved up to 8


**031.** `06:48` **Meredith Lamb (+14169386001)**

Started at 6


**032.** `06:48` **Meredith Lamb (+14169386001)**

And they weren’t as like annoying today despite the heat


**033.** `06:49` **You**

Like you said to me\.\.
Don’t give yourself a heart attack 🥰


**034.** `06:49` **Meredith Lamb (+14169386001)**

If I stopped drinking I’d make much faster progress


**035.** `06:49` **Meredith Lamb (+14169386001)**

lol


**036.** `06:49` **You**

Heheh yeah but not likely


**037.** `06:49` **Meredith Lamb (+14169386001)**

Probably not right now


**038.** `06:52` **You**

Not this weekend for sure


**039.** `08:53` **You**

Good morning??


**040.** `09:04` **Meredith Lamb (+14169386001)**

Yeah pretty good\. But rushed and so hot\. Glad to be in normal a/c now


**041.** `09:32` **You**

Mmm I still find it a little warms


**042.** `09:37` **Meredith Lamb (+14169386001)**

Jim wanted the update on the parents


**043.** `09:38` **Meredith Lamb (+14169386001)**

lol


**044.** `09:38` **Meredith Lamb (+14169386001)**

I forgot to text him after


**045.** `10:08` **You**

lol you were drunk\.


**046.** `10:13` **Meredith Lamb (+14169386001)**

So are you ok meeting my 2 best friends Sunday night in London? Oddly, they are both around\. Just talking to them


**047.** `10:17` **You**

Cool


**048.** `10:17` **You**

Should be fun


**049.** `10:17` **You**

You comfortable with that?  I mean I am\.\.


**050.** `10:23` **Meredith Lamb (+14169386001)**

Yeah I am for sure\. :\)


**051.** `10:28` **You**

lol kk off we go then\.\.


**052.** `10:30` **Meredith Lamb (+14169386001)**

I haven’t seen them in a while so will be nice for us girls also


**053.** `10:31` **Meredith Lamb (+14169386001)**

My friend Mandy is having a hard time so needs it


**054.** `10:32` **You**

No worries we can meet and you can go have a girls night if you would like\.


**055.** `10:37` **You**

Like I don’t need to be a 4 th wheel or anything if you would have more fun just the three of you\.


**056.** `10:42` **Meredith Lamb (+14169386001)**

You wont be a 4th wheel


**057.** `10:42` **Meredith Lamb (+14169386001)**

lol


**058.** `10:42` **Meredith Lamb (+14169386001)**

Mandy’s partner has depression right now really bad tho so won’t be coming and not sure about Kim’s …


**059.** `10:45` **You**

We will see how it goes I can always pop out mid way through the night


**060.** `10:48` **Meredith Lamb (+14169386001)**

No no they are very easy going


**061.** `10:48` **You**

lol ok I will do whatever you tell me to\.\. is that better ☺️


**062.** `10:49` **Meredith Lamb (+14169386001)**

Jim thinks I might stress you out if I do too many intros too fast


**063.** `10:49` **Meredith Lamb (+14169386001)**

lol


**064.** `10:49` **You**

Ge is incorrect


**065.** `10:49` **You**

He


**066.** `10:51` **Meredith Lamb (+14169386001)**

You sure??


**067.** `10:53` **You**

Yeah\. I am def sure


**068.** `10:54` **You**

Not even a little bit stressed about
Intros\.


**069.** `10:58` **Meredith Lamb (+14169386001)**

K good because we are going to also have dinner with my SIL at keg on Monday night\. Walking distance from 4 points


**070.** `10:59` **Meredith Lamb (+14169386001)**

Not sure if Trent will come or not … he’s not a big socializer so I said no pressure


**071.** `11:01` **You**

Kk keep it coming\.\. all good


**072.** `11:05` **Meredith Lamb (+14169386001)**

That’ll be it\. No one else in London knows about you yet\. Lol


**073.** `11:42` **You**

Again I am good with whatever\.  All kinds of whatever


**074.** `11:51` **You**

We have been invited to dinner Saturday afternoon\- I think since we are staying in\. GR that night we can go?


**075.** `11:55` **Meredith Lamb (+14169386001)**

Sure


**076.** `11:55` **Meredith Lamb (+14169386001)**

Omg just finished safety course\. Took so long


**077.** `11:56` **You**

Hahaha


**078.** `11:56` **You**

Told you


**079.** `11:56` **You**

So bad


**080.** `12:01` **You**

This whole look but don’t touch thing sucks btw\.\. just so you know\.


**081.** `12:50` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I know, trust me, I know lol


**082.** `13:08` **You**

Ugggh


**083.** `13:10` **Meredith Lamb (+14169386001)**

Four days


**084.** `13:14` **You**

Still


**085.** `13:59` **You**

So Gracie cannot do dbt at Ontario shores while in Moncton and she won’t lie\.\. so now who the fuck knows what is going to happen\.


**086.** `14:02` **Meredith Lamb (+14169386001)**

Oh no


**087.** `14:02` **Meredith Lamb (+14169386001)**

Is it a tactic to stay in Ontario?


**088.** `14:02` **You**

Yeah I mean she is going to try to leverage this to stay and if she does it will basically break maddie and I\.


**089.** `14:04` **Meredith Lamb (+14169386001)**

Are there no resources in Moncton?


**090.** `14:05` **You**

Nope bit like Ontario


**091.** `14:05` **You**

I mean this is something Gracie can sort out on her own she just needs to grow the fuck up


**092.** `14:06` **Meredith Lamb (+14169386001)**

Are you sure?


**093.** `14:07` **Meredith Lamb (+14169386001)**

If she can’t even get on a bus or go buy her own shit…\.


**094.** `14:07` **You**

I think she can she does for her friends


**095.** `14:08` **Meredith Lamb (+14169386001)**

Hmmh


**096.** `14:08` **Meredith Lamb (+14169386001)**

Then why do you buy her carts


**097.** `14:08` **Meredith Lamb (+14169386001)**

I mean she is home all day


**098.** `14:19` **You**

I don’t know because if I don’t she loses
Her shit


**099.** `14:20` **Meredith Lamb (+14169386001)**

Vicious cycle


**100.** `14:29` **You**

Yep


**101.** `14:29` **You**

This could really impact
My life


**102.** `14:32` **Meredith Lamb (+14169386001)**

How could both girls stay here without their mom? I don’t understand that\.


**103.** `14:33` **Meredith Lamb (+14169386001)**

Wouldn’t Jaimie fall apart


**104.** `14:42` **You**

Probably but Gracie doesn’t care


**105.** `14:44` **Meredith Lamb (+14169386001)**

This doesn’t sound good


**106.** `14:48` **You**

Nope I am a little worried


**107.** `14:50` **You**

This doesn’t affect us to be clear


**108.** `14:50` **You**

In case you are worried


**109.** `14:51` **Meredith Lamb (+14169386001)**

Not worried about us\. More just your family in general\. Doesn’t sound great for anyone really\.


**110.** `14:56` **You**

Nope


**111.** `14:58` **You**

I am worried about my sanity


**112.** `14:59` **You**

And my job


**113.** `14:59` **You**

Because she will text and phone call bomb me all day


**114.** `15:02` **Meredith Lamb (+14169386001)**

Does Jaimie know about this new development? What are her thoughts?


**115.** `15:02` **You**

Like this is a serious issue\.\.


**116.** `15:02` **You**

J is on her way home


**117.** `15:02` **You**

We are going to discuss


**118.** `15:03` **Meredith Lamb (+14169386001)**

How long is the program again?


**119.** `15:13` **You**

13 weeks \.\. j is saying she is going to Moncton period


**120.** `15:13` **You**

So see if that holds


**121.** `15:14` **Meredith Lamb (+14169386001)**

“She” meaning Gracie or meaning herself


**122.** `15:25` **You**

Gracie


**123.** `15:25` **Meredith Lamb (+14169386001)**

Ah I see


**124.** `15:25` **Meredith Lamb (+14169386001)**

Hey did you get rid of the playlist you made on Spotify?


**125.** `15:25` **You**

Nope


**126.** `15:25` **You**

Why


**127.** `15:26` **You**

You deleted it eh\.\. thought… so lame\.\. and never gonna last so why keep it\.\. Eesh


**128.** `15:26` **You**

Ouch


**129.** `15:27` **Meredith Lamb (+14169386001)**

I don’t see it anymore


**130.** `15:27` **Meredith Lamb (+14169386001)**

Weird


**131.** `15:27` **You**

Deleted it


**132.** `15:27` **Meredith Lamb (+14169386001)**

I didn’t


**133.** `15:27` **Meredith Lamb (+14169386001)**

You did


**134.** `15:28` **You**

https://open\.spotify\.com/playlist/4o0w2C4v7JfY6AwQTKoWoD?si=W4D1GyHwRsaCgxkuHCVJZw&pi=h0AtizhKSbG19


**135.** `15:29` **You**

I changed the name so that no one would notice now no one can axcesss it anyways


**136.** `15:31` **Meredith Lamb (+14169386001)**

Ahh


**137.** `16:02` **You**

I want to see you 🤯…\. lol booooo shitty day\.\. 3\.5
Days


**138.** `16:03` **Meredith Lamb (+14169386001)**

:\(


**139.** `16:04` **You**

Fack


**140.** `16:17` **Meredith Lamb (+14169386001)**

I think I’m going to leave\. Ok?


**141.** `16:18` **Meredith Lamb (+14169386001)**

Did you leave?


**142.** `16:37` **You**

I am still here in with is


**143.** `16:37` **You**

Ian will be here late ish\.\. love you\.\.🥰


**144.** `16:46` **Meredith Lamb (+14169386001)**

Love you too xo I’m almost home :\)


**145.** `16:47` **You**

Kk chat later


**146.** `17:20` **You**

Just leaving now meh\.


**147.** `17:24` **Meredith Lamb (+14169386001)**

Be glad you have ac


**148.** `17:24` **Meredith Lamb (+14169386001)**

Ours has been off all day


**149.** `17:25` **Meredith Lamb (+14169386001)**

Just turned it on and it is a stupid mini split


**150.** `17:25` **Meredith Lamb (+14169386001)**

This house is ridiculous


**151.** `17:25` **Meredith Lamb (+14169386001)**

It’s 30 degrees inside


**152.** `17:29` **You**

Yucky


**153.** `17:29` **You**

Any word back from mediator


**154.** `17:30` **Meredith Lamb (+14169386001)**

Yeah we got the link but Andrew hasn’t let me know when he is available yet


**155.** `17:30` **Meredith Lamb (+14169386001)**

:p


**156.** `17:30` **You**

Ah ok\.\.
So this week then\. Not bad if a can do it


**157.** `17:30` **Meredith Lamb (+14169386001)**

I’m trying to get him to agree to Thursday


**158.** `17:31` **You**

Well here is hoping… progress is good


**159.** `17:32` **Meredith Lamb (+14169386001)**

Yeah and in the meantime I need to just find a place\. Harder than I thought


**160.** `17:33` **You**

Yeah I still don’t feel like he is being fair and if he goes from 12 to 8 years it is going to be really hard


**161.** `17:35` **You**

I mean if you believe in us\.\. and I do\.\. then we will be living together at some point and it will be a bit easier for both of us\.\. but I mean depending on him putting in a bullshit cohabitation clause\.\. fuck I will have nothing good to say to this guy ever\.


**162.** `17:37` **Meredith Lamb (+14169386001)**

He just got home and can’t do Thursday\. “No chance\. Fully booked day\.”


**163.** `17:37` **Meredith Lamb (+14169386001)**

Argh


**164.** `17:37` **Meredith Lamb (+14169386001)**

I will likely have to take Friday from hotel\.


**165.** `17:38` **You**

Kk


**166.** `17:38` **You**

That should be fine\.


**167.** `17:41` **Meredith Lamb (+14169386001)**

Argh Andrew’s bday is Wednesday\. It’s weird


**168.** `17:47` **You**

Big one too


**169.** `17:47` **You**

45


**170.** `17:48` **Meredith Lamb (+14169386001)**

He said he doesn’t want anything from anyone


**171.** `17:48` **Meredith Lamb (+14169386001)**

lol


**172.** `17:48` **Meredith Lamb (+14169386001)**

Ok done


**173.** `17:48` **You**

lol


**174.** `17:50` **Meredith Lamb (+14169386001)**

Omg everyone just left


**175.** `17:50` **Meredith Lamb (+14169386001)**

It is like heaven here


**176.** `17:50` **Meredith Lamb (+14169386001)**

All doing diff things


**177.** `17:51` **Meredith Lamb (+14169386001)**

Very hot like hell but peaceful like heaven


**178.** `17:51` **You**

And for me I am
Driving into the mouth of hell\!\!  lol


**179.** `17:51` **Meredith Lamb (+14169386001)**

lol


**180.** `17:51` **You**

This will be a long few days


**181.** `17:52` **Meredith Lamb (+14169386001)**

Yep


**182.** `17:52` **Meredith Lamb (+14169386001)**

Are you doing site visits on Thursday and Friday?


**183.** `17:53` **You**

Yep but done early Friday


**184.** `17:53` **Meredith Lamb (+14169386001)**

OK, no problem was just curious


**185.** `17:53` **You**

And not too late thurs


**186.** `17:53` **Meredith Lamb (+14169386001)**

I took Friday off


**187.** `17:53` **You**

But you will be


**188.** `17:54` **Meredith Lamb (+14169386001)**

Yes, I will be very late on Thursday


**189.** `17:54` **You**

Should I have some wine ready for you lol


**190.** `17:54` **Meredith Lamb (+14169386001)**

lol um


**191.** `17:54` **Meredith Lamb (+14169386001)**

It is so freaking hot here\. I’m shopping on Amazon for linen pants\. Lol


**192.** `17:55` **You**

Heheh


**193.** `17:55` **Meredith Lamb (+14169386001)**

I just wish I had them right now


**194.** `17:55` **Meredith Lamb (+14169386001)**

Gah


**195.** `17:55` **You**

Wear shorts


**196.** `17:55` **Meredith Lamb (+14169386001)**

I am but really light flowy pants feels better


**197.** `17:55` **Meredith Lamb (+14169386001)**

Shorts you get sticky to the leather furniture


**198.** `17:55` **Meredith Lamb (+14169386001)**

Not a big fan


**199.** `17:55` **You**

Mmm


**200.** `17:56` **You**

Fair enough


**201.** `18:42` **Meredith Lamb (+14169386001)**

Just finished uploading some final stuff for mediator\. Now going to try a show Jim recommended\. He gave me a couple today\. I think he is disappointed in my tv watching lately\. You have interrupted it


**202.** `18:42` **You**

So much joy here\!\!\!\!\!\!\!


**203.** `18:43` **You**

ROFL gahhhhhh


**204.** `18:43` **You**

What no I haven’t


**205.** `18:43` **You**

I leave you alone most of the time


**206.** `18:43` **You**

Reaction: ❤️ from Meredith Lamb
Pshhhh\.\. well I will say good day then\!\!\!\!


**207.** `18:45` **Meredith Lamb (+14169386001)**

Just distraction


**208.** `18:45` **Meredith Lamb (+14169386001)**

lol


**209.** `18:45` **You**

😝


**210.** `18:45` **Meredith Lamb (+14169386001)**

Everyone is miserable there?


**211.** `18:45` **You**

Ok well I will take an inventory of all of the things I say or do that may be distracting and I will refrain for a few days\.


**212.** `18:46` **Meredith Lamb (+14169386001)**

And they literally had to do nothing today?


**213.** `18:46` **You**

>
Mmmm kinda\.

*💬 Reply*

**214.** `18:46` **Meredith Lamb (+14169386001)**

>
Listen, I never said it Jim not me

*💬 Reply*

**215.** `18:46` **You**

Hmmmm nope I feel like you told Jim I was a distraction


**216.** `18:46` **Meredith Lamb (+14169386001)**

I totally did not\!


**217.** `18:47` **Meredith Lamb (+14169386001)**

I just haven’t been watching shows at my typical rate


**218.** `18:47` **Meredith Lamb (+14169386001)**

lol


**219.** `18:47` **Meredith Lamb (+14169386001)**

I am still further ahead than him on a bunch of things though


**220.** `18:47` **Meredith Lamb (+14169386001)**

lol


**221.** `18:48` **Meredith Lamb (+14169386001)**

He thought he was gonna be so good telling me about “dying for sex” and I had already seen it\. He literally went home and told Kristine 🙄


**222.** `18:48` **Meredith Lamb (+14169386001)**

I watched the whole season while he was in Scotland


**223.** `18:48` **Meredith Lamb (+14169386001)**

lol


**224.** `18:48` **Meredith Lamb (+14169386001)**

Do you know what happened today?


**225.** `18:48` **Meredith Lamb (+14169386001)**

So he gets a call and it’s clearly Christine


**226.** `18:48` **You**

Kk


**227.** `18:49` **Meredith Lamb (+14169386001)**

She asked him a question and I can tell and he goes “I will tell you later”


**228.** `18:49` **Meredith Lamb (+14169386001)**

I swear to god she was asking how it went with my parents


**229.** `18:49` **Meredith Lamb (+14169386001)**

lol


**230.** `18:49` **You**

Yeah no doubt


**231.** `18:49` **You**

He was kinda messing with me about it as we walked over to the desk


**232.** `18:49` **You**

And about meeting your friends


**233.** `18:50` **Meredith Lamb (+14169386001)**

He’s very concerned for you


**234.** `18:50` **You**

Why


**235.** `18:50` **Meredith Lamb (+14169386001)**

Well, he thinks that like they’re gonna grill you or something and they totally would not like not even close


**236.** `18:50` **Meredith Lamb (+14169386001)**

I think Christine’s friends must be different


**237.** `18:50` **You**

But why is he worried\.\. I can handle that


**238.** `18:51` **Meredith Lamb (+14169386001)**

He just said he would find it very nerve\-wracking


**239.** `18:51` **You**

Not me


**240.** `18:51` **Meredith Lamb (+14169386001)**

Especially after just meeting the parents


**241.** `18:51` **Meredith Lamb (+14169386001)**

lol


**242.** `18:51` **You**

Nope I don’t think he understands our relationship


**243.** `18:51` **You**

I don’t think many would


**244.** `18:51` **Meredith Lamb (+14169386001)**

Well, he hasn’t really been around us outside of work so like yeah


**245.** `18:52` **Meredith Lamb (+14169386001)**

And I can only talk about so much at work it just feels weird when you’re in an office


**246.** `18:52` **You**

Yeah we will have to actually spend some time there some night


**247.** `18:52` **You**

True


**248.** `18:52` **Meredith Lamb (+14169386001)**

Yeah, they have a busy summer though so no pressure so that’s good


**249.** `18:52` **You**

Yep


**250.** `18:53` **Meredith Lamb (+14169386001)**

It would be better when he’s not socially exhausted\. He always gets socially tired in summer


**251.** `18:55` **You**

lol I mean I will have to get used to some things as we are able to spend more time regularly with each other and I can do family stuff with you because it might be a lot at first but it is what I want


**252.** `18:55` **You**

Like very much


**253.** `18:56` **Meredith Lamb (+14169386001)**

We will both have to get used to “some things” 🙂


**254.** `18:59` **You**

I am looking forward to it\.\. not feeling like it is a burden


**255.** `19:00` **Meredith Lamb (+14169386001)**

Me neither, not at all\. I honestly don’t even think I will have anything to get used to but who knows\.


**256.** `19:03` **You**

Not with or for you\.\. nope


**257.** `19:35` **Meredith Lamb (+14169386001)**

Asking my mom what she thought about you


**258.** `19:35` **Meredith Lamb (+14169386001)**

lol


**259.** `19:38` **You**

Interested


**260.** `19:38` **You**

Also interested in what your dad thought


**261.** `19:38` **You**

I thought you already talked…


**262.** `19:40` **Meredith Lamb (+14169386001)**

I mean we talked the next day but I didn’t ask them\. They need time to process


**263.** `19:40` **Meredith Lamb (+14169386001)**

I could just gauge their moods etc etc how they talked and they were really good


**264.** `19:41` **Meredith Lamb (+14169386001)**

When I left she went to her sister Gail’s so I asked her what she told Gail lol


**265.** `19:44` **You**

Ah ok


**266.** `19:45` **Meredith Lamb (+14169386001)**

Meh  ~ this is very my mom

*📎 1 attachment(s)*

**267.** `19:46` **You**

That is reasonable


**268.** `19:47` **You**

And unsurprising she is your mum\.\. she cares about your well\-being\.\. and getting a signed agreement is importantly


**269.** `19:47` **You**

She is too much of a realist not a hopeless romantic


**270.** `19:49` **Meredith Lamb (+14169386001)**

Literally just typed: “Oh dear though\. I don’t like to be hugged but don’t tell him yet because it will bother him”


**271.** `19:50` **Meredith Lamb (+14169386001)**

Also: “You were the worst drinking that much\.”


**272.** `19:51` **You**

ROFL


**273.** `19:51` **Meredith Lamb (+14169386001)**

>
I said you did it because I told you not to and you were just being an ass and she goes: Oh good\. It’s OK for him to get an elbow then next hug\.

*💬 Reply*

**274.** `19:51` **You**

Maybe I don’t go for one next time\.\.


**275.** `19:52` **You**

Reaction: 😂 from Meredith Lamb
Sounds like she has some stark honesty too lol\.


**276.** `19:53` **You**

Mer she is\. Or going to like me right now


**277.** `19:53` **You**

lol leave her be


**278.** `19:53` **You**

Not going to


**279.** `19:53` **Meredith Lamb (+14169386001)**

Yes she is


**280.** `19:54` **You**

No she is focused on the right thing which is your situation\.


**281.** `19:54` **Meredith Lamb (+14169386001)**

She’s not gonna like me for drinking too much right now\. I told her I’m gonna stop again\.


**282.** `19:54` **Meredith Lamb (+14169386001)**

Eventually


**283.** `19:55` **You**

Well I am happy she doesn’t have bad things to say about me\.\. but you wouldn’t tell me anyways


**284.** `19:55` **Meredith Lamb (+14169386001)**

Oh, I totally would


**285.** `19:55` **Meredith Lamb (+14169386001)**

lol


**286.** `19:55` **You**

No I don’t think you would


**287.** `19:56` **Meredith Lamb (+14169386001)**

Yep, I would\. I’ve told Andrew all the negative things she said about him\.


**288.** `19:56` **You**

Stark


**289.** `19:56` **Meredith Lamb (+14169386001)**

lol


**290.** `19:57` **You**

Again I don’t think your mum understands the nature of our relationship and even if she did \.\.
I don’t think she would appreciate it\.


**291.** `19:57` **You**

Again I don’t blame
Her


**292.** `19:57` **Meredith Lamb (+14169386001)**

She doesn’t at all\. I haven’t told her that level of detail


**293.** `19:57` **You**

I think it would make it worse


**294.** `19:58` **Meredith Lamb (+14169386001)**

Yeah, she doesn’t need to know that it would just make her worry


**295.** `19:59` **Meredith Lamb (+14169386001)**

But we know 🙂


**296.** `19:59` **You**

That is true we do


**297.** `20:13` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**298.** `20:13` **Meredith Lamb (+14169386001)**

Is she enabling me?


**299.** `20:13` **Meredith Lamb (+14169386001)**

lol


**300.** `21:30` **You**

I think she is being a mom


**301.** `21:32` **You**

I kind of fell asleep watching a show/\.


**302.** `21:32` **You**

Not feeling the best tonight guess I just wanted it to be over with…


**303.** `21:35` **Meredith Lamb (+14169386001)**

I just watched the first episode of an interesting show that Jim told me to watch\. It’s on Apple called “friends and neighbors” starring John Hamm


**304.** `21:35` **Meredith Lamb (+14169386001)**

So he’s a guy that gets divorced and then he gets fired from his job for sleeping with someone at work


**305.** `21:35` **Meredith Lamb (+14169386001)**

lol


**306.** `21:36` **You**

Mmmm sounds interesting


**307.** `21:36` **Meredith Lamb (+14169386001)**

It was and I think he’s supposed to be 47


**308.** `21:36` **Meredith Lamb (+14169386001)**

lol


**309.** `21:37` **Meredith Lamb (+14169386001)**

I think that’s good that you got some extra sleep\. You should go back to sleep if you can\.


**310.** `21:40` **You**

Yeah I will try I guess\.\. you go enjoy your show\.  Chat tomorrow\.


**311.** `21:41` **Meredith Lamb (+14169386001)**

You ok?


**312.** `21:44` **You**

Just a shitty night\.\. but nothing to do with you\.  Anyhow love you… go enjoy yourself\. Xo\.


**313.** `21:46` **You**

Sorry I missed the rest
Of your mom chat hope it went well\.    Night\.\.


**314.** `21:47` **Meredith Lamb (+14169386001)**

Sorry you are feeling shitty\. Hopefully tomorrow is better\. Love you \(most\) ❤️


