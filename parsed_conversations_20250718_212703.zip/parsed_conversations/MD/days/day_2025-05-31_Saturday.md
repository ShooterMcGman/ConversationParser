# Daily Conversation: 2025-05-31 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-31 |
| **Day** | Saturday |
| **Week** | 7 |
| **Messages** | 457 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-31T00:01 - 2025-05-31T23:59 |

## 📝 Daily Summary

This day contains **457 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:01` **You**

lol did you run away


**002.** `00:05` **You**

or go to sleep


**003.** `00:07` **Meredith Lamb (+14169386001)**

Sorry bea in bathroom


**004.** `00:07` **Meredith Lamb (+14169386001)**

:p


**005.** `00:07` **Meredith Lamb (+14169386001)**

I took fresh towels into guest cottage and bea like hunched over\. Gah


**006.** `00:07` **Meredith Lamb (+14169386001)**

The others all watching a movie


**007.** `00:08` **You**

ah ok


**008.** `00:10` **Meredith Lamb (+14169386001)**

>
I think you said it above\. I guess I’m curious where you see this going in all senses\. I’m being cryptic\. Hmmh\. I’m not sure how to say thing ms without being starkly honest

*💬 Reply*

**009.** `00:10` **You**

be starkly honest


**010.** `00:11` **Meredith Lamb (+14169386001)**

Was stark the word?


**011.** `00:11` **You**

yep


**012.** `00:11` **Meredith Lamb (+14169386001)**

k couldn’t remember


**013.** `00:13` **Meredith Lamb (+14169386001)**

Stark honesty: So before Andrew I had a relationship \(or 2\) that was \(were\) really good and different\. Very much more open\. Anyway I would be happy if you were that way\. I feel like you might be but I’m not you\.


**014.** `00:14` **Meredith Lamb (+14169386001)**

And yes I deleted and retypes here and there


**015.** `00:15` **You**

ok so I have already answered that above\.\. leaving no room for uncertainty\.\.  I do not know what "open" means\.\. it could be a lot of things\.\. some yep\.\. I am good with\.\. others\.\. err no\.\.


**016.** `00:16` **You**

So tell me specifically what do you want to do\.\. stark honesty set to on\.\.\.


**017.** `00:16` **You**

>
also were these the relationships with the drugs?

*💬 Reply*

**018.** `00:18` **Meredith Lamb (+14169386001)**

I just mean like do you want to try different things sometimes in the future when we are like together together… games, etc


**019.** `00:17` **You**

If i had to guess


**020.** `00:18` **You**

probably J and C likely the two you were very comfortable with\.


**021.** `00:18` **Meredith Lamb (+14169386001)**

\(I will ChatGPT the rest\.\.\)


**022.** `00:18` **You**

>
Again you are being cryptic\.\. you can come right out and say it\.

*💬 Reply*

**023.** `00:19` **You**

>
I think you know who I mean\.\. I also feel like you are getting uncomfortable with these questions\.\. lol

*💬 Reply*

**024.** `00:20` **You**

only reason I ask is because that might be something impossible for me to replicate for you\.


**025.** `00:20` **Meredith Lamb (+14169386001)**

>
I’m curious if in the future, obviously not now you see things evolving\. Say, couple board game\. Would that be weird or no\. Just an example\.

*💬 Reply*

**026.** `00:21` **Meredith Lamb (+14169386001)**

>
I’m not looking to replicate\. Those were left for a reason\.

*💬 Reply*

**027.** `00:20` **You**

ahhhh that "open"


**028.** `00:21` **Meredith Lamb (+14169386001)**

It isn’t replication, it is more mindset\.


**029.** `00:22` **You**

ok gpt didn't help me here


**030.** `00:24` **Meredith Lamb (+14169386001)**

k, I just put Ben folds five on and am a bit stoned now so have to listen…


**031.** `00:27` **You**

kk


**032.** `00:28` **You**

you are going to need to focus in here Mer\.\. I really need you to


**033.** `00:28` **Meredith Lamb (+14169386001)**

You should go to bed


**034.** `00:28` **Meredith Lamb (+14169386001)**

:\)


**035.** `00:28` **You**

omg


**036.** `00:28` **You**

I cannot go to bed


**037.** `00:28` **You**

jesus


**038.** `00:28` **Meredith Lamb (+14169386001)**

What? Why?


**039.** `00:28` **You**

you cannot drop that and tell me to go to bed


**040.** `00:29` **Meredith Lamb (+14169386001)**

Drop what omg\. I explained


**041.** `00:29` **You**

So define "open" because GPT defines it two ways\.


**042.** `00:29` **Meredith Lamb (+14169386001)**

>
This was an example

*💬 Reply*

**043.** `00:29` **You**

One way is you and I play an interesting board game that we play together to engage differently etc\.


**044.** `00:29` **You**

the other definition


**045.** `00:29` **You**

was about us playing a couples\.\.\.\. board game\.\.


**046.** `00:30` **You**

Reaction: 😂 from Meredith Lamb
which is different\.\. lol


**047.** `00:30` **Meredith Lamb (+14169386001)**

>
Open to things maybe you have done the past 25 yrs

*💬 Reply*

**048.** `00:30` **Meredith Lamb (+14169386001)**

\*have not


**049.** `00:30` **Meredith Lamb (+14169386001)**

>
They seem the same actually

*💬 Reply*

**050.** `00:30` **You**

I already told you I was\.\. but it depends\.\. on what they are\.\.


**051.** `00:31` **Meredith Lamb (+14169386001)**

Ok very fair good answer


**052.** `00:31` **Meredith Lamb (+14169386001)**

lol


**053.** `00:31` **You**

Am I willing to have an Open relationship\.\. is that what you are asking


**054.** `00:31` **Meredith Lamb (+14169386001)**

No


**055.** `00:31` **Meredith Lamb (+14169386001)**

Not even close


**056.** `00:31` **Meredith Lamb (+14169386001)**

You think I could do that?


**057.** `00:31` **You**

ok\.\. that is what I thought you meant with the game\.


**058.** `00:32` **You**

well Mer\.\.


**059.** `00:32` **You**

again


**060.** `00:32` **Meredith Lamb (+14169386001)**

Nope


**061.** `00:32` **You**

you have shared some drunken stories


**062.** `00:32` **You**

stark truth and all


**063.** `00:32` **You**

lol


**064.** `00:32` **Meredith Lamb (+14169386001)**

Bed time


**065.** `00:32` **Meredith Lamb (+14169386001)**

lol


**066.** `00:32` **You**

and you have suggested some situations where the lines got a little fuzzy\.


**067.** `00:32` **Meredith Lamb (+14169386001)**

You can sleep now


**068.** `00:32` **You**

I think you and Jeremy and kind of even with the drugs you guys were like wtf\!\!


**069.** `00:32` **You**

sorry the memory thing


**070.** `00:33` **You**

I hear it I rarely forget


**071.** `00:33` **You**

I think it was you Jeremey Chris and friends\.


**072.** `00:33` **You**

if I recall\.


**073.** `00:33` **You**

so yeah that is why I asked about the "open"


**074.** `00:33` **Meredith Lamb (+14169386001)**

No no no no I haven’t done anything like that


**075.** `00:34` **You**

after you


**076.** `00:34` **You**

you were going to say something


**077.** `00:35` **Meredith Lamb (+14169386001)**

Not sure


**078.** `00:35` **You**

that is not true


**079.** `00:35` **You**

you wouldn't let me get away with that


**080.** `00:35` **Meredith Lamb (+14169386001)**

🫩


**081.** `00:35` **You**

what is that?


**082.** `00:36` **Meredith Lamb (+14169386001)**

lol


**083.** `00:37` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/3Uvx1TO0Kg5HgGPk58lHXv?si=hp\_R8i76Ri2eKghgGFVUAQ
Does this song make you feel sad for your marriage?


**084.** `00:37` **You**

ok I feel like you are really resisting\.\.


**085.** `00:37` **Meredith Lamb (+14169386001)**

I can hardly remember honestly


**086.** `00:37` **You**

so maybe we should just call it\.\. it is too bad I am really curious


**087.** `00:37` **Meredith Lamb (+14169386001)**

Yes Jeremy and I … and Chris and I, did a lot of drugs\. But then it ended\.


**088.** `00:38` **Meredith Lamb (+14169386001)**

>
I don’t even know what I’m not responding to

*💬 Reply*

**089.** `00:39` **You**

I am trying to understand what you want\.\. board games\.\.\. role playing\.\.\. I haven't ever done those things\.\. or whatever else you might be referring to\.\.\. that is what I am curious about\.\. specifics\.\. but I can tell you YES I would definitely be interested\.\. but doesn't help my curiosity\.


**090.** `00:40` **Meredith Lamb (+14169386001)**

I don’t really have super specifics atm\. Just curious if you see things evolving


**091.** `00:40` **Meredith Lamb (+14169386001)**

I’m honestly good either way but was just curious


**092.** `00:41` **You**

I mean I have never "evolved" I thought you had specific examples you were going to reference from those 2 past relationships you mentioned \- yo said they were more open\.\. I was just looking for details lol


**093.** `00:41` **Meredith Lamb (+14169386001)**

Sorry wasn’t actually like making a PLAN with a specific roadmap :p


**094.** `00:41` **You**

Reaction: 😂 from Meredith Lamb
well then examples\.\. more than board game examples\.


**095.** `00:43` **Meredith Lamb (+14169386001)**

I just am not sure if you have ever thought about it? That’s probably cryptic right?


**096.** `00:43` **Meredith Lamb (+14169386001)**

For instance, other than making someone happy have you ever thought about what you want?


**097.** `00:47` **You**

I tried to explain\.\. how can I say this differently


**098.** `00:48` **You**

If I understand your wants outside of let's say climax\.\. then I would know what to do\.  But I told you I am simple\.\. if I know I am making you happy sexually or any other way\.\. it actually gives me happiness\.


**099.** `00:49` **You**

>
yeah you have been really really cryptic tonight\.\. I am guessing you had way more than 1 gummy\.

*💬 Reply*

**100.** `00:49` **You**

:\(


**101.** `00:49` **You**

>
I want to be with you for the rest of my life\.

*💬 Reply*

**102.** `00:49` **You**

that is it


**103.** `00:50` **Meredith Lamb (+14169386001)**

>
No \- one\!

*💬 Reply*

**104.** `00:50` **Meredith Lamb (+14169386001)**

Few hrs ago


**105.** `00:50` **You**

you said you were stoned


**106.** `00:50` **Meredith Lamb (+14169386001)**

Bottle of wine tho


**107.** `00:50` **You**

you don't get stoned off one gummyt


**108.** `00:50` **Meredith Lamb (+14169386001)**

I actually did for like a while\. Surprising


**109.** `00:50` **You**

lol


**110.** `00:51` **Meredith Lamb (+14169386001)**

It’s gone now :\(


**111.** `00:51` **You**

anyways\.\. you have my thoughts above\.\. I would give you more if I had more to give you


**112.** `00:51` **Meredith Lamb (+14169386001)**

Did I scare you tonight? Lol


**113.** `00:51` **You**

hardly


**114.** `00:51` **Meredith Lamb (+14169386001)**

k good


**115.** `00:51` **You**

I mean I was more concerned with your focus on my relationship with Jaimie


**116.** `00:51` **You**

less about me and safe words\.\.


**117.** `00:51` **You**

:\)


**118.** `00:52` **Meredith Lamb (+14169386001)**

I’m not FOCUSED on it


**119.** `00:52` **You**

I feel like you might be a bit


**120.** `00:52` **Meredith Lamb (+14169386001)**

It is simple a part of the story


**121.** `00:52` **Meredith Lamb (+14169386001)**

Right now


**122.** `00:52` **You**

you asked a lot of questions about my sexual relationship with jaimie or lack there of\.\. and why\.\. and and lol


**123.** `00:52` **You**

I mean I am happy to answer\.


**124.** `00:52` **Meredith Lamb (+14169386001)**

Just trying to understand you more


**125.** `00:53` **Meredith Lamb (+14169386001)**

Context


**126.** `00:53` **You**

I am an enigma, wrapped in a riddle\.\. wrapped in a rhyme\.


**127.** `00:53` **Meredith Lamb (+14169386001)**

Nothing is really tmi for me to hear\. More just context


**128.** `00:53` **You**

KK then


**129.** `00:53` **Meredith Lamb (+14169386001)**

>
I would agree

*💬 Reply*

**130.** `00:53` **You**

give like you get\. lol


**131.** `00:53` **Meredith Lamb (+14169386001)**

Hmmh probably not


**132.** `00:53` **You**

you are super cagey and super cryptic


**133.** `00:54` **Meredith Lamb (+14169386001)**

lol


**134.** `00:54` **You**

why can't you put yourself out there\.\. take a risk\.\. trust that I love everything about you no matter what\.


**135.** `00:54` **You**

tell me what you want\.\.


**136.** `00:56` **Meredith Lamb (+14169386001)**

My feelings are as I expressed them\. I don’t have your ability to explain things…\. So super cagey it might be\.


**137.** `00:56` **You**

ok


**138.** `00:56` **Meredith Lamb (+14169386001)**

Just bear with me…


**139.** `00:56` **You**

let me ask the question a different way\.\. very specifically\.


**140.** `00:57` **Meredith Lamb (+14169386001)**

I am not so\!


**141.** `00:57` **Meredith Lamb (+14169386001)**

\*ai\!


**142.** `00:57` **Meredith Lamb (+14169386001)**

lol


**143.** `00:57` **Meredith Lamb (+14169386001)**

I went to your session today


**144.** `00:57` **Meredith Lamb (+14169386001)**

Did you forget


**145.** `00:59` **You**

Initially you references 2 relationships\. I knew who they were\. easy guess for me based on what you have shared\.\. I did suggest earlier\.\. that if these were the drug related relationships I might not be able to replicate the experiences\. Now you talked about how those relationships were much more open than that between you and Andrew\.\. and I can see why who likes to be told how to service their partner all the time\.  Certainly wouldn't make me want to be super open for fun and stuff\.  So you made the reference to the 2 previous relationships\.\. then to this couples board\.\. game\.\. gpt suggested games like \-  Monogamy
Our Moments \(for couples\)
The Discovery Game
Talk Flirt Dare
Let's Talk About Sex \(conversation card decks\)


**146.** `00:59` **You**

But that is one example\.


**147.** `00:59` **You**

I am asking if you can provide other specific examples from those relationships that you would like us to explore together\.


**148.** `00:59` **You**

activities\.\. sexual or otherwise\.\. games, anything\.\. I would like to get my mind around it\.


**149.** `01:00` **You**

then I might just need to get a little drunk\.\.\. 🥰 and we should be good to go\.


**150.** `01:01` **Meredith Lamb (+14169386001)**

I don’t have anything specific to share atm … maybe later\.


**151.** `01:01` **You**

like I don't know what you mean positions\.\. drugs\.\. I will do some\.


**152.** `01:01` **You**

>
no you wont

*💬 Reply*

**153.** `01:01` **Meredith Lamb (+14169386001)**

No drugs\.


**154.** `01:01` **Meredith Lamb (+14169386001)**

Bad drugs\.


**155.** `01:01` **You**

I promise it would be better for both if you shared now\.\.


**156.** `01:01` **Meredith Lamb (+14169386001)**

Hearts attacks and stuff


**157.** `01:01` **You**

it will be easier for you\.\. and you might be pleasantly surprised later\.


**158.** `01:02` **You**

like\.\. aids?? toys??


**159.** `01:02` **You**

other stuff?


**160.** `01:02` **You**

lol


**161.** `01:02` **You**

I read books you know\!\!


**162.** `01:02` **You**

rofl


**163.** `01:02` **You**

are you embarassed\.


**164.** `01:02` **You**

or shy


**165.** `01:02` **You**

or nervous


**166.** `01:03` **Meredith Lamb (+14169386001)**

Maybe I’m not thinking specific stuff but wondering… sigh … not embarrassed, shy\. I have nothing I want to replicate so it isn’t an easy question to answer\. Stuff will come up and I was just curious how you felt about us and if you think we will always be like this\.


**167.** `01:04` **You**

when you say be like this\.\. do you mean vanilla?


**168.** `01:04` **Meredith Lamb (+14169386001)**

Nope\. I mean super obsessed with each other\. Like literally cannot get enough


**169.** `01:04` **You**

sorry I am trying to use an analogy


**170.** `01:04` **You**

oh shit


**171.** `01:04` **You**

again


**172.** `01:05` **Meredith Lamb (+14169386001)**

lol


**173.** `01:05` **You**

you are worried I am going to get bored\.\. OR you are worried you will


**174.** `01:05` **You**

Let me tell you something in all honesty ok\.\.


**175.** `01:07` **You**

Being with you feels better than being with anyone else previously\.\. hand down no comparison\.\. not even close\.\. I will never get bored of you\.\. you will never need to do anything kinky or crazy to keep my interest\.\. that said I am also willing to do whatever you want\.\. because I love you, and I will always want to make you happy\.  That means trying new things\.\. taking risks etc\.


**176.** `01:08` **You**

So I am happy to evolve if that is what you want\.\. or I am happy to keep doing this\.\. or I am happy to do about anything\.  But with you it feels like electricity\.\. best way to explain it\.\. so again\.\. happy with anything and everything\.


**177.** `01:09` **Meredith Lamb (+14169386001)**

❤️❤️


**178.** `01:10` **You**

>
And while I do love you to death\.\. I think you are dodging here because it might be uncomfortable to talk about\.\. you might be comfortable listening to all my "stuff" but not sure you are equally comfortable sharing certain things\.

*💬 Reply*

**179.** `01:10` **You**

remember what I said about a week ago


**180.** `01:10` **You**

tonight


**181.** `01:10` **You**

oh wait no you don't


**182.** `01:10` **You**

LOL


**183.** `01:10` **You**

well played scott


**184.** `01:10` **Meredith Lamb (+14169386001)**

lol


**185.** `01:11` **You**

I was telling you what Deb warned me about\.


**186.** `01:11` **You**

do you remember


**187.** `01:11` **Meredith Lamb (+14169386001)**

😔


**188.** `01:11` **Meredith Lamb (+14169386001)**

Nope


**189.** `01:11` **Meredith Lamb (+14169386001)**

Moving on too quickly?


**190.** `01:11` **Meredith Lamb (+14169386001)**

Or was that my aunt?


**191.** `01:12` **You**

She said some people when they get in our situations\.\. tend to look backwards at what they had and yearn for it\.\. for the excitement, the adventure, the freedom\.  They want to feel that again\.\. sometimes that means going back to the people that they used to be with to experience that\.\. sometimes that means something else\.\. she just said be careful if that is what she wants, and you don't fit that mold for her\.


**192.** `01:13` **You**

Reaction: ❤️ from Meredith Lamb
I am willing to be whoever you want me to be with you \- I will always be me\.\. but with you I can be whatever you need me to be\.


**193.** `01:13` **You**

You just on your own are more than enough for me\.\. making you happy makes me happy\. And that is sustainable btw\.


**194.** `01:14` **You**

the rest of my life thing\.\. that is real\.\. even though it terrifies you to hear it\.


**195.** `01:15` **You**

but yeah the rest of my life hopefully is a long time\.\. and we can do all kinds of fun things but I think you need to reflect specifically on what it is you are looking for\.\. I still don't understand what prompted you to raise it whether it is out of something you desire, or out of concern for something else\.


**196.** `01:15` **Meredith Lamb (+14169386001)**

>
Doesn’t terrify me\!

*💬 Reply*

**197.** `01:16` **You**

So I gave you a shit ton of examples\.\. if you could now or later\.\. but sometime soon\.\. please clarfiy specifically what you are interested in\.\. without worry\.\. the sooner I know the sooner I can get my head around it and the sooner, we can begin our adventures :\)


**198.** `01:17` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/6liaHE9iHh23PLVvw7lK8V?si=cwlzdj0nRAeGditUWAWagg
After this song I’m passing our


**199.** `01:17` **Meredith Lamb (+14169386001)**

\*out


**200.** `01:17` **You**

ok\.\. i guess we can pick this up another time\.\. :\)


**201.** `01:17` **You**

Go to bed\.


**202.** `01:18` **Meredith Lamb (+14169386001)**

>
This is really interesting insight that I have never heard talked about\. Wonder if it is true?  I can see myself a BIT in that but not fully\. Those were some dysfunctional times…\.

*💬 Reply*

**203.** `01:19` **You**

It is true for many people


**204.** `01:19` **You**

I have seen it


**205.** `01:19` **You**

it is the reason a lot of people get divorced


**206.** `01:19` **Meredith Lamb (+14169386001)**

Huh?


**207.** `01:19` **Meredith Lamb (+14169386001)**

No


**208.** `01:19` **Meredith Lamb (+14169386001)**

Can’t be true


**209.** `01:19` **You**

People get tired of who they are with\.\. want to go back


**210.** `01:19` **Meredith Lamb (+14169386001)**

Finances and kids


**211.** `01:19` **You**

feel like they missed out


**212.** `01:19` **You**

made a bad decision


**213.** `01:19` **You**

want a do over


**214.** `01:19` **You**

it happens


**215.** `01:19` **You**

it is happening to my friend mark back home right now


**216.** `01:20` **Meredith Lamb (+14169386001)**

I don’t want to go back though\. Don’t want to go back to bat shit crazy land\.


**217.** `01:20` **You**

but you want to feel like it without the side effects\.


**218.** `01:20` **Meredith Lamb (+14169386001)**

Perhaps… not sure\. I should talk to ChatGPT about it


**219.** `01:20` **You**

so again\.\. you will need to work with me and share with me\.\. and we can see what we can do together\.


**220.** `01:21` **Meredith Lamb (+14169386001)**

To be crystal clear, I am so in love with you and love every second of our time together and ache for the next time\. Just thinking about the future


**221.** `01:22` **You**

I appreciate it\.\. and I didn't take it the wrong way Mer\.\. I took it 100% the right way\.  And yeah I really would like to "explore" for lack of a better term\.\. and tbh I wouldn't have been comfortable doing this with anyone else\.


**222.** `01:23` **You**

now go to bed\.\. relax\.\. kind of intense conversation\.\. but at least I kind of think I know a little about what you want\.\. so just give me some ideas\.\. or at least of all of the things I mentioned\.\. tell me what you aren't interested in\.


**223.** `01:25` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/5aDpULK8MbJmHl42kR5KNI?si=xIX\-sfHeRMao8guMe1U0ZA
Listen to this before you go to bed\. Oldie xo


**224.** `01:25` **You**

is a good song\.\.


**225.** `01:26` **Meredith Lamb (+14169386001)**

k, I’m passing out slowly


**226.** `01:25` **You**

I love you Mer\.\. get some sleep\.\. xoxo


**227.** `01:26` **You**

❤️❤️❤️


**228.** `01:26` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Need to go to bed\. Love you


**229.** `01:26` **Meredith Lamb (+14169386001)**

❤️


**230.** `09:32` **You**

Well I did not
Get up to a happy morning I was up till 2:30 am Gracie decided
To have another go j got involved another fight\.  I think I am going to spend a bit knife and rent a three bedroom townhouse\.\. Gracie seems to think unless I have three bedrooms it will be impossible for her to visit\.  So I will need to do some math\.\. the rent
Will be about half my take home\.\. so should be interesting\.\. with all the other expenses\.\. will basically be a year where I cannot save much except my bonus and ltip\.  After that I am doing what we talked about last night\.\. assuming you remember the very very interesting conversation we had
Last night ❤️


**231.** `09:34` **You**

Taking teddy to groomer at 10:30 then doing some house work picking her up gym and/or more housework\.\. need to review the roll
Over content\.\. would like to try
Playing ticket
To ride with you again tonight or something else if
You are up for it\.\. wish I could come up but that is just not doable\.  Maybe we can find a morning this week where I go to the park or maybe next
Weekend we can find just a bit of time\.\. not planning just hoping as you say\.


**232.** `09:35` **You**

Anyhow hope you are not too hung over\- fucking called it\!\! And I very much want to revisit the “open” conversation last night\.\. not because I want to make you feel uncomfortable, but I feel there is something there you are hoping for, and I if I am able, lol, I am willing\.\. but I do need a bit more info lol\.\.
Preferably from sober Meredith\.


**233.** `09:37` **You**

Ok back to work\.\. I love you mer xoxo dreamt about us last night,  it was great because it was nothing more than a normal future looking dream of us spending time together, just talking sitting ins couch somewhere in front of a fire\.\. it was winter out\.  All I remember


**234.** `09:37` **You**

❤️❤️❤️❤️


**235.** `10:19` **Meredith Lamb (+14169386001)**

Um, little hungover lol but I don’t have to do too much today\. A couple meals and cleaning\. Probably napping\. lol going to make girls bacon, sausage, eggs, hashbrowns this morning\. I will likely need it myself LOL


**236.** `10:20` **Meredith Lamb (+14169386001)**

>
I wish I had this dream\! 😍

*💬 Reply*

**237.** `10:20` **You**

You I\. Bed


**238.** `10:30` **Meredith Lamb (+14169386001)**

Yep\. I took griffin out at like 7\.30 and then went back to bed\.


**239.** `11:35` **Meredith Lamb (+14169386001)**

After breakfast I’m going to reread  last night\. Lol I wasn’t expecting for that conversation to go the way it went I don’t think\. 🤔 but I do love how you latch on to things and not let them go actually\. It can be annoying but I love that part of your personality 🙂


**240.** `11:37` **You**

It is only because I believe it is important to you\.  And while I don’t understand, I want to\.\. I don’t want you to shy away from sharing or being anxious, I am as here for you as much as you are for me\.  And mer I was honest I would love to try pretty much anything with you just because it is you ☺️


**241.** `11:37` **You**

So have a reread\.


**242.** `11:40` **You**

And please please ask questions and please please try to get comfortable enough to share with me what you are interested in\.  I want to know you as much as you want to know me\. And remember we are 47 time is a factor so let’s not waste any 😋


**243.** `13:17` **Meredith Lamb (+14169386001)**

Omg just finished brunch making and cleaning\. Phewwwwww


**244.** `13:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**245.** `13:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**246.** `13:25` **Meredith Lamb (+14169386001)**

This is challenging to process\.

*📎 1 attachment(s)*

**247.** `13:31` **You**

Holy shit


**248.** `13:32` **You**

What is challenging


**249.** `13:32` **You**

Reading back through?


**250.** `13:33` **You**

Reaction: 👍 from Meredith Lamb
You understand the context of that statement right… because it was part of a larger discussion\.


**251.** `13:39` **You**

Single was a reference to how I handled needs that was what you were asking about\. I went in to say that isn’t relevant anymore\.


**252.** `13:41` **You**

Reaction: ❤️ from Meredith Lamb
So confused not sure you you are processing things or from what angle I feel like you are trying to predict how I will behave with you when a\. I never behaved like that with anyone before and I had several long term relationships and b m\. You are my soulmate\.\. I believe it I am comfortable saying it\.\. it is like comparing apples and airplanes\.\. no point of comparison


**253.** `13:44` **Meredith Lamb (+14169386001)**

>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
I don’t think I fully read this last night but it is sort of what I was thinking\. I just was worried that if whatever is happening between us physically doesn’t last or stops for some reason, you’re not going to hole yourself up in the basement and shut me out\. Like there is other ways to connect and be intimate\. Really all I was trying to articulate in a really horrible manner LOL

*💬 Reply*

**254.** `13:57` **You**

What are you doing atm?


**255.** `13:57` **You**

Driving to gym call if you want easier to express this directly


**256.** `13:59` **Meredith Lamb (+14169386001)**

I just reread it all\!


**257.** `13:59` **Meredith Lamb (+14169386001)**

Holy\. Long


**258.** `13:59` **You**

Kk


**259.** `13:59` **You**

Avail if you are lol


**260.** `14:00` **Meredith Lamb (+14169386001)**

I am, back in bed


**261.** `14:00` **Meredith Lamb (+14169386001)**

lol


**262.** `14:00` **Meredith Lamb (+14169386001)**

Took and aleve and then started reading


**263.** `14:01` **You**

Kk if you want to text I can try when I get to gym driving now


**264.** `14:01` **Meredith Lamb (+14169386001)**

>
Okay, you may have a point\.

*💬 Reply*

**265.** `15:43` **You**

Maybe update photo today\.\. feeling good 😜


**266.** `15:43` **Meredith Lamb (+14169386001)**

🙂


**267.** `15:47` **Meredith Lamb (+14169386001)**

I’m not sure I could handle it but am happy to try\. :\) You were worried of me projecting on you and that I might be getting bored\. Furthest thing from the truth…\. I literally logged in yesterday just to hear you speak and your voice\. Today, just talking to you… honestly just that and I can’t stop thinking about you… so the projecting thing was kind of funny tbh\.
k, I have to go into town for the umpteenth time and then Mac wants me to set up a “photo wall” for them lol
I will wait patiently for your progress photo\. ⏳


**268.** `15:51` **You**

Reaction: 😋 from Meredith Lamb
God I love you\.\. Nuff said\.


**269.** `16:37` **Meredith Lamb (+14169386001)**

I forgot to tell you when I was hanging out with the girls last night they go “who is Scott?” And Mac goes “oh just her boyfriend”\. LOL


**270.** `16:47` **You**

Reaction: 😍 from Meredith Lamb
Pg

*📎 1 attachment(s)*

**271.** `16:48` **You**

Reaction: 😍 from Meredith Lamb
Pg 2

*📎 1 attachment(s)*

**272.** `16:49` **You**

One more coming just hanging on for bit happy with my progress need to compare back


**273.** `16:53` **You**

>
You can show them a safe pic if you haven’t already\.\. or who knows what you showed them lol\. You tend to go above and beyond sometimes lol\.

*💬 Reply*

**274.** `17:09` **Meredith Lamb (+14169386001)**

>
What is happening to you… god, so hot\. I’m feeling extremely slacky now for not starting to work out yet\.

*💬 Reply*

**275.** `17:25` **You**

Last one


**276.** `17:26` **You**

A

*📎 1 attachment(s)*

**277.** `17:27` **You**

Not quite Henry yet but I will get there\.


**278.** `17:32` **You**

>
Pshhh not hot don’t kid yourself just\. Try hard old man\.

*💬 Reply*

**279.** `17:41` **Meredith Lamb (+14169386001)**

>
Oh Whatever…\. No wonder why Jaimie is upset at you

*💬 Reply*

**280.** `17:42` **Meredith Lamb (+14169386001)**

Got my stupid wall done for their photos\. Gotta walk dogs now

*📎 1 attachment(s)*

**281.** `17:42` **Meredith Lamb (+14169386001)**

Now they want ANOTHER wall omg


**282.** `17:43` **Meredith Lamb (+14169386001)**

>
Am I above and beyond? No one has ever told me that before\. :p

*💬 Reply*

**283.** `17:43` **You**

You are extra


**284.** `17:44` **You**

J doesnt see me anymore so she doesn’t know


**285.** `17:45` **Meredith Lamb (+14169386001)**

>
Oh whatever\. Anyone can tell\. And you guys go “driving” places\. She sees you

*💬 Reply*

**286.** `17:45` **You**

I don’t send her the pics either 😜


**287.** `17:45` **Meredith Lamb (+14169386001)**

I’m not being jealous\. Just saying


**288.** `17:45` **Meredith Lamb (+14169386001)**

lol


**289.** `17:45` **You**

Not the same as shirtless stuff only you see that


**290.** `17:46` **You**

Not the same at all


**291.** `17:46` **Meredith Lamb (+14169386001)**

You can tell shirtless or not


**292.** `17:46` **You**

N uh uh


**293.** `17:47` **Meredith Lamb (+14169386001)**

Just trust me


**294.** `17:47` **You**

Reaction: 🙄 from Meredith Lamb
Nope I prefer to think my way\.\. I mean if it is no diff I could send her the shirtless pic I just sent you\.\.  shouldn’t matter right


**295.** `17:48` **You**

Reaction: ❤️ from Meredith Lamb
That emoji doesnt scare me lol


**296.** `17:49` **You**

Reaction: 😂 from Meredith Lamb
Besides you just don’t like logic traps\.


**297.** `17:50` **You**

>
I could always send this to Cote… ok done teasing……\.😈

*💬 Reply*

**298.** `17:50` **You**

All done


**299.** `17:50` **Meredith Lamb (+14169386001)**

That was MEAN


**300.** `17:50` **You**

Luv luv luv


**301.** `17:50` **Meredith Lamb (+14169386001)**

lol


**302.** `17:50` **You**

Luv luv luv


**303.** `17:50` **You**

lol


**304.** `17:50` **You**

Ok
Going to go get groceries then I have to cook
Supper
Then more
Work\.\.
Yay


**305.** `17:51` **Meredith Lamb (+14169386001)**

I have to make girls dinner soon also


**306.** `17:51` **You**

Cool\. Well j say and watched tv all day\.\. so so far she has been super helpful with the moving etc… Fack


**307.** `17:52` **Meredith Lamb (+14169386001)**

:\(


**308.** `17:58` **Meredith Lamb (+14169386001)**

Getting ready slowly for the special event dinner

*📎 1 attachment(s)*

**309.** `18:00` **You**

lol man Mac better give you a huge I love you and a hug and mean the hell out of it she is so lucky\.


**310.** `18:08` **Meredith Lamb (+14169386001)**

She will probably give constructive feedback ;\)


**311.** `18:10` **You**

lol 😆 man


**312.** `18:10` **Meredith Lamb (+14169386001)**

Always room for improvement


**313.** `18:13` **You**

>
Not for you\.\. not from my perspective\.

*💬 Reply*

**314.** `18:32` **Meredith Lamb (+14169386001)**

I have a million things to improve on… \#1\. Getting my act together :\)


**315.** `18:34` **You**

Again you can do whatever you want you are already perfect for me\.


**316.** `18:50` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**317.** `19:03` **You**

You baked all that amazing\!\!\!\!


**318.** `19:03` **You**

❤️❤️❤️❤️❤️❤️❤️❤️❤️


**319.** `19:06` **Meredith Lamb (+14169386001)**

No no no\. Baked their desserts yday\. Not all that


**320.** `19:07` **Meredith Lamb (+14169386001)**

Can’t you wait until your 50th? \(I like milestone bdays\)


**321.** `19:07` **You**

You in a birthday suit\.\.


**322.** `19:07` **You**

All I need


**323.** `19:10` **You**

I don’t like bdays\. I do love you\.\. you in a suit checks that box, checks our “fun” box\.  Checks all the good boxes\. lol


**324.** `19:14` **Meredith Lamb (+14169386001)**

Well if I am the boss then you will like your birthday going forward\. New rule\.


**325.** `19:19` **You**

I will like it but I get the birthday suit deal\.\. :\) agreed?


**326.** `19:21` **Meredith Lamb (+14169386001)**

It’s your birthday\. Whatever you want 🙂


**327.** `19:21` **You**

Oh


**328.** `19:21` **You**

One more thing


**329.** `19:21` **You**

Have you ever seen the movie true lies?


**330.** `19:24` **You**

Google true lies dance scene\. It is classic Jaimie Lee Curtis\. See I can play\.\. 🥰


**331.** `19:24` **You**

But that is 50


**332.** `19:24` **You**

To be clear


**333.** `19:24` **You**

Not 47


**334.** `19:24` **Meredith Lamb (+14169386001)**

Yes but haven’t seen it in years


**335.** `19:24` **You**

Cause I am still 46


**336.** `19:24` **You**

Well check
Out the dance scene you will know


**337.** `19:25` **Meredith Lamb (+14169386001)**

K making dinner\. Will later\. Girls are getting gussied up


**338.** `19:26` **You**

Nice have fun take pics\.


**339.** `19:26` **Meredith Lamb (+14169386001)**

Mac goes “don’t worry mom you don’t have to dress up”


**340.** `19:26` **Meredith Lamb (+14169386001)**

LOL


**341.** `19:26` **You**

Rofl 🙁


**342.** `19:49` **Meredith Lamb (+14169386001)**

They won’t let me make the pasta bc they want to take photos first\. So I’m like on call waiting \(with a glass of wine\)\. Getting late for me lol

*📎 1 attachment(s)*

**343.** `19:54` **You**

>
yeah they can't expect you to sit on glass number 4 very much longer

*💬 Reply*

**344.** `19:54` **Meredith Lamb (+14169386001)**

lol 3


**345.** `19:55` **You**

shit I started with 3


**346.** `19:55` **You**

but then I thought\.\. that is too optimistic


**347.** `19:55` **You**

LOL:


**348.** `19:57` **Meredith Lamb (+14169386001)**

It’s been a long afternoon


**349.** `19:58` **You**

It was a long weekend


**350.** `19:58` **You**

actually it has been a long month


**351.** `19:58` **You**

you have been building up for this for more than a month\.


**352.** `19:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**353.** `19:58` **Meredith Lamb (+14169386001)**

Those gummies won’t stop looking at me


**354.** `19:58` **Meredith Lamb (+14169386001)**

🤮


**355.** `19:59` **You**

I don't even want to think about whether or not you will take even some of that tonight\.


**356.** `19:59` **You**

cause I don't want to make a prediction lol


**357.** `20:18` **Meredith Lamb (+14169386001)**

I will not


**358.** `20:18` **Meredith Lamb (+14169386001)**

150%


**359.** `20:19` **You**

hmmm


**360.** `20:20` **You**

I will have to think about that\.\. one trait you do have\.\. is a penchant for liking to tread a little on the the naughty side\.\. you cannot seem to help it with regards to these kinds of things


**361.** `20:20` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**362.** `20:20` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**363.** `20:21` **You**

nice pic walls\.\. mom


**364.** `20:21` **You**

well done


**365.** `20:21` **You**

your talents are wasted you should be in event planning\.


**366.** `20:25` **Meredith Lamb (+14169386001)**

>
Always been a bit of a fault\. 🤷‍♀️

*💬 Reply*

**367.** `20:26` **You**

I know which is why in this I am slightly skeptical lol


**368.** `20:27` **You**

You have no safe gummies\.\.\.  I feel like 70% chance Mac breaks you off an appropriate piece and you trust her to do that and therefore ok to take\.


**369.** `20:27` **You**

Post supper cleanup\.\. my guess\.


**370.** `20:33` **Meredith Lamb (+14169386001)**

>
Nope\!

*💬 Reply*

**371.** `20:33` **Meredith Lamb (+14169386001)**

>
No they are eating actually

*💬 Reply*

**372.** `20:33` **You**

no no


**373.** `20:33` **You**

I am saying you will have your bite post supper cleanup after glass  6


**374.** `20:34` **You**

It's ok I will miss most of your fun tonight unfortuntately\.


**375.** `20:42` **Meredith Lamb (+14169386001)**

>
Does this bother you?

*💬 Reply*

**376.** `20:43` **You**

Only insofar as I worry about you\.\. nothing more than that\.\. I assure you\.


**377.** `20:44` **You**

I was like that too\.\. that is why we would have gotten along famously\.\. and probably gotten into some shit together too\.  I wasn't Jeremy or Chris\.\. but I was fun in my own ways\.\. and crossed all kinds of lines\.


**378.** `20:44` **Meredith Lamb (+14169386001)**

I mean I have made it to 47 so there is that


**379.** `20:45` **You**

I know look\.\. I will drop it\.\. like you said\.\. you are 47 and can make your own decisions\.  I love you all the same just as you are, but it doesn't mean I won't worry\.


**380.** `20:46` **You**

Go ahead and have fun\.\. I am sure  you and the girls will have a blast\.


**381.** `20:50` **You**

I am just going to play my game for a bit\.\. maybe watch a show and go to bed early\.


**382.** `20:56` **Meredith Lamb (+14169386001)**

Have to do happy birthday cake and then I think I get a break lol


**383.** `20:56` **Meredith Lamb (+14169386001)**

Just walking dogs bc griffin was growling at me


**384.** `20:56` **Meredith Lamb (+14169386001)**

Neglected


**385.** `20:57` **You**

Cool have fun\!  Enjoy the break you have certainly earned one\.


**386.** `20:59` **Meredith Lamb (+14169386001)**

Omg they are talking about all their plans for tonight\. It is going to be a late night\. Oh my God\.


**387.** `21:00` **Meredith Lamb (+14169386001)**

Not sure I will be able to handle it lol


**388.** `21:01` **Meredith Lamb (+14169386001)**

I heard from them should we get fried and drunk before we do the chocolate fountain or after?


**389.** `21:01` **Meredith Lamb (+14169386001)**

🥱


**390.** `21:01` **Meredith Lamb (+14169386001)**

Yawn


**391.** `21:03` **You**

Yeah sounds like you are in for some fun for sure\.


**392.** `21:08` **Meredith Lamb (+14169386001)**

Mackenzie made me send this\.

*📎 1 attachment(s)*

**393.** `21:09` **You**

Eesh\. Like a boss\.


**394.** `21:09` **You**

Impressive


**395.** `21:10` **You**

I would go straight shots with the little monkey and see how well she would do lol\.


**396.** `21:10` **You**

Cause I am a responsible adult\.


**397.** `21:11` **Meredith Lamb (+14169386001)**

She was wondering where the shot glasses came from and when I told her she had to take a video for u lol


**398.** `21:11` **You**

Heheh glad
She made good use of them\.


**399.** `21:19` **Meredith Lamb (+14169386001)**

I was doing dishes and I hear this Mom so I turn around and she goes\. We just took half of a gummy\.


**400.** `21:19` **Meredith Lamb (+14169386001)**

FACK


**401.** `21:20` **Meredith Lamb (+14169386001)**

Fucking Bea Again


**402.** `21:20` **You**

Let the good times roll\.


**403.** `21:20` **Meredith Lamb (+14169386001)**

She didn’t know they were extra strength


**404.** `21:20` **Meredith Lamb (+14169386001)**

Like didn’t look at the package


**405.** `21:20` **You**

Oh she is fucked


**406.** `21:20` **You**

Tell her no drinking


**407.** `21:20` **You**

No more


**408.** `21:20` **Meredith Lamb (+14169386001)**

I told her water water water


**409.** `21:20` **You**

Do you have any of the cbd?


**410.** `21:21` **Meredith Lamb (+14169386001)**

Not here


**411.** `21:21` **Meredith Lamb (+14169386001)**

In Toronto


**412.** `21:21` **You**

Water


**413.** `21:21` **You**

Then


**414.** `21:21` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**415.** `21:22` **You**

Mission accomplished best mom ever


**416.** `21:23` **Meredith Lamb (+14169386001)**

Done\.

*📎 1 attachment(s)*

**417.** `21:26` **You**

Great pic for the record books\.\. this is what Gracie wanted\.\. j and I were jist never big on parties\.\. maddie didnt care but Gracie did\.\. glad Mac had a great weekend\.


**418.** `21:28` **Meredith Lamb (+14169386001)**

Well if she doesn’t hate me I will throw her a party someday\. 😜


**419.** `21:29` **You**

Mmm hmmm


**420.** `21:31` **Meredith Lamb (+14169386001)**

https://www\.instagram\.com/lamberrybakes?igsh=MW1oangyZDQ2cWtsNQ%3D%3D&utm\_source=qr


**421.** `21:32` **Meredith Lamb (+14169386001)**

How do you not like parties?


**422.** `21:32` **You**

You are so extra\.\.
I am def not good enough for you\.\. Jesus\.\.
lol


**423.** `21:32` **Meredith Lamb (+14169386001)**

I don’t get that


**424.** `21:35` **Meredith Lamb (+14169386001)**

>
Because you don’t plan parties? 🙄

*💬 Reply*

**425.** `21:39` **You**

Just because you are amazing and I don’t measure up\. You are just a fantastic person\.\. your family is lucky\.


**426.** `21:40` **Meredith Lamb (+14169386001)**

Well I think you are fantastic so…\. :\)


**427.** `21:40` **Meredith Lamb (+14169386001)**

\(My friends all tease me for being extra btw\.  I know it isn’t normal\.\)


**428.** `21:41` **You**

Hard to keep up with\. Hard expectations to meet\. lol


**429.** `21:42` **Meredith Lamb (+14169386001)**

🫤


**430.** `21:42` **Meredith Lamb (+14169386001)**

No\.


**431.** `21:43` **Meredith Lamb (+14169386001)**

You have high expectations also\.  It is part of why I like you so much\.


**432.** `21:43` **Meredith Lamb (+14169386001)**

People that don’t are boring\.


**433.** `21:48` **You**

lol\. I have high expectations for work\.  I try to take people as they come\.


**434.** `21:51` **Meredith Lamb (+14169386001)**

I mean, I think if you have high expectations in one place you do everywhere\.


**435.** `21:51` **Meredith Lamb (+14169386001)**

You just dismiss them elsewhere because no one lives up to your standards lol


**436.** `21:51` **You**

Agree to disagree


**437.** `21:51` **Meredith Lamb (+14169386001)**

lol


**438.** `21:52` **Meredith Lamb (+14169386001)**

Maybe I need to get to know you better


**439.** `21:52` **You**

Perhaps\.


**440.** `21:53` **You**

I think I know you better than you know me\.\. and I think I have told you more…\. Ironic


**441.** `21:58` **You**

In in bed not sure what you have on the go but I can chat for a bit quietly if you want fam is watching survivor above me and I turned the fan on down here\.  You might have your hands full with chocolate fountains etc\.\. if so I will probably  turn on something and call it a night\.


**442.** `22:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**443.** `22:43` **You**


*📎 1 attachment(s)*

**444.** `22:45` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**445.** `23:30` **You**

Nite love you talk to
You tomorrow\.\.
Hope it is smooth sailing for you\. ❤️❤️❤️❤️❤️❤️❤️


**446.** `23:41` **Meredith Lamb (+14169386001)**

More throwing up so she is here now\. No other girl is in this condition\. They are all watching jumanji

*📎 1 attachment(s)*

**447.** `23:42` **You**

Hope she is ok\.\.☹️


**448.** `23:42` **You**

Still she had an epic weekend


**449.** `23:43` **Meredith Lamb (+14169386001)**

If this bowl stays clear all night it will be a win\. 😐


**450.** `23:49` **You**

Well take care of her\.\. she is a little you after all\.\. she needs to grow up find someone like me and drive them crazy\.


**451.** `23:50` **Meredith Lamb (+14169386001)**

Gah\. Lol


**452.** `23:51` **Meredith Lamb (+14169386001)**

I don’t drive you crazy\. You drive ME crazy\. 🙃


**453.** `23:52` **You**

No… I just love you like crazy\.\. and I really still don’t see what you see that would drive you crazy\.\. lol just simple guy with a lot of love
For you mer\.\.


**454.** `23:52` **You**

❤️


**455.** `23:57` **Meredith Lamb (+14169386001)**

I love you like crazy too 🤠 This next week will be interesting\. Sweet dreams\. 💤 ❤️


**456.** `23:58` **You**

Yeah it sure will be\!\!\! \*sarcasm\* love you too hon sleep well\.


**457.** `23:59` **You**

🥰🥰


