# Daily Conversation: 2025-05-20 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-20 |
| **Day** | Tuesday |
| **Week** | 6 |
| **Messages** | 115 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-20T04:27 - 2025-05-20T22:10 |

## 📝 Daily Summary

This day contains **115 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:27` **You**

Reaction: ❤️ from Meredith Lamb
Morning sunshine hope you actually went to sleep and got a good one\.❤️❤️❤️


**002.** `04:32` **You**

Reaction: 😂 from Meredith Lamb
Also I miss the dogs…\.\. 😢 well Rosie and Grif tbh\.


**003.** `06:30` **Meredith Lamb (+14169386001)**

Yeah I was happy to say bye to Bo lol


**004.** `06:30` **You**

Rofl bark bark bark holy fuck bark\.


**005.** `06:44` **You**

Phew well that was fun see you in at work when I see
You\.\. going to check out that terra park this morning to cool off for a walk after this… brutal\.


**006.** `08:00` **Meredith Lamb (+14169386001)**

Omg I fell back asleep and just woke up lol was supposed to take Maelle to school at 8\.10\. Argh


**007.** `08:01` **You**

Oops


**008.** `08:01` **Meredith Lamb (+14169386001)**

Getting her an uber now :p


**009.** `08:03` **You**

lol


**010.** `08:03` **You**

Eesh


**011.** `08:06` **You**

Maybe if I had have been there to wake you up\.


**012.** `08:07` **Meredith Lamb (+14169386001)**

Yes, make that happen please\. Lol


**013.** `08:09` **You**

2 years


**014.** `08:15` **Meredith Lamb (+14169386001)**

Omg fuck off


**015.** `08:16` **Meredith Lamb (+14169386001)**

Not allowed to say that joke before I’ve had my coffee


**016.** `08:18` **You**

At park now honey\.\.


**017.** `08:21` **You**

Couple of nice spots

*📎 5 attachment(s)*

**018.** `08:22` **You**

Bout 2 min walk in from where I parked\.


**019.** `08:23` **You**

And haven’t seen a soul


**020.** `08:24` **Meredith Lamb (+14169386001)**

Nice\. I will look later\. I am soooooooooooo late for Mia\.


**021.** `08:24` **You**

lol I know


**022.** `08:31` **Meredith Lamb (+14169386001)**

I’m cool lol

*📎 1 attachment(s)*

**023.** `08:32` **You**

You are def cool\.😎


**024.** `08:33` **You**

Back to the me sleeping with you\.\. I mean I would only be a good influence\.\. 😇


**025.** `08:34` **Meredith Lamb (+14169386001)**

Yeah let’s keep it real\. That is totally not true at all\.


**026.** `08:34` **You**



**027.** `08:34` **You**



**028.** `08:34` **You**



**029.** `08:35` **You**

I think you would be better off on the whole\.


**030.** `08:37` **Meredith Lamb (+14169386001)**

Whoah 3 deleted msgs


**031.** `08:37` **Meredith Lamb (+14169386001)**

Super unfair


**032.** `08:52` **Meredith Lamb (+14169386001)**

Did you fall in some water or something?


**033.** `08:52` **You**

Just in can explain after


**034.** `09:10` **You**

Reaction: 😂 from Meredith Lamb
So I had said I think you would be better off and it corrected two words on turned into in and whole turned into hole\.\. the other two messages after were omg on and whole, and then Jesus\!\!\!\! And when I realized you hadn’t read I deleted immediately lol


**035.** `09:16` **Meredith Lamb (+14169386001)**

Arrived\. Going straight to 3rd floor


**036.** `09:20` **You**

Kk have fun\.


**037.** `11:55` **You**

What a fucking day so far\. Jesus\.


**038.** `11:56` **Meredith Lamb (+14169386001)**

Why?


**039.** `11:56` **You**

Meetings stupid


**040.** `11:57` **Meredith Lamb (+14169386001)**

Oh…\.


**041.** `12:02` **You**

What did you think


**042.** `12:04` **Meredith Lamb (+14169386001)**

Who knows honestly\. Could be anything lol


**043.** `12:05` **Meredith Lamb (+14169386001)**

Tell me when you have a minute


**044.** `12:39` **You**

Listen it takes me at least 24\-48 hours to get depressed about us again gawd give me some
Credit ffs\. 😜


**045.** `13:57` **Meredith Lamb (+14169386001)**

You know what would be really awesome? Just going home together after work\.
😢😭


**046.** `14:05` **You**

Yeah agreed\.


**047.** `14:05` **You**

There’s always the park 😊


**048.** `14:09` **Meredith Lamb (+14169386001)**

lol we can try that


**049.** `14:10` **Meredith Lamb (+14169386001)**

Back and forth with Andrew on text\. Stopping now :p


**050.** `14:10` **You**

Hope it isn’t frustrating yku too
Much\.


**051.** `14:11` **You**

>
>
I would actually like to talk to you about this at
Some point in time\.\. there are some decisions I will need to make about my living situation that might be impacted by that conversation\.

*💬 Reply*

**052.** `14:22` **Meredith Lamb (+14169386001)**

I mean, I’m not actually expecting anything for years in that regard\. It would be nice but…\.\. complicated\.


**053.** `14:27` **You**

I know\.\. if it is many many years the\. That makes my decision easy\.


**054.** `14:28` **You**

We don’t even need to have the chat 👍


**055.** `14:28` **Meredith Lamb (+14169386001)**

I mean I don’t want it to be but I am a realist\.


**056.** `14:32` **You**

>
Yeah totally agree\.

*💬 Reply*

**057.** `14:52` **Meredith Lamb (+14169386001)**

Omg I can’t even explain the words spewing out of his mouth today\. ……\.


**058.** `14:53` **You**

Gah I wish he would just stop fighting and work towards a solution\.


**059.** `14:53` **Meredith Lamb (+14169386001)**

He’s all mad that the separation agreement won’t include anything I have to do for him:


**060.** `14:53` **Meredith Lamb (+14169386001)**

The separation agreement will include things that I need to do for you over the next 8 years \- essentially pay child support and spousal support\.  And it will have mutual obligations about sharing the kids\.  It will not have any things you need to do for me\.   Which is just the way it is\.  So you won’t need to resent me or feel unappreciated by me any more, which will be helpful I hope\.


**061.** `14:54` **Meredith Lamb (+14169386001)**

I told you \- he is very transactional


**062.** `14:55` **You**

Yeah that seems kind of fecked up\.\. here I am offering to help j with any ongoing documentation and shit for the home anyways\.\.


**063.** `14:55` **Meredith Lamb (+14169386001)**

First time he has ever said he appreciates something from me\. I’m kind of shell shocked tbh\.

*📎 1 attachment(s)*

**064.** `14:55` **You**

lol yeah because it is what he wants\!\!\! lol sorry in this I am a cynic


**065.** `14:59` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**066.** `15:00` **You**

I am never going to get in a fight with you\.  Ever\.


**067.** `15:01` **Meredith Lamb (+14169386001)**

I get the “please stop taking… blahblahblah” all the time now


**068.** `15:01` **Meredith Lamb (+14169386001)**

I told him he had to stop saying that


**069.** `15:01` **You**

Well like you said you were just clarifying and correcting


**070.** `17:08` **You**

Have to Remeber where I can say what


**071.** `17:09` **You**

A long way down from the weekend to fall…\.


**072.** `17:09` **You**

It will hit me soon enough\.


**073.** `17:13` **Meredith Lamb (+14169386001)**

Weekend to fall?


**074.** `17:14` **You**

I responded in teams and deleted it\.  A long way to fall from the happy weekend to the sad state we are in now\.


**075.** `17:19` **Meredith Lamb (+14169386001)**

I knoooooooow\. Emotional whiplash


**076.** `17:20` **You**

Very sucky\.  I am trying not to think about the next 3\-5 weeks or more like 6\-10


**077.** `17:46` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Just don’t get in your head about all the “be cautious” advice\. You are everything to me and have no reason for caution\.


**078.** `18:07` **You**

I am not slowing mer\.


**079.** `18:07` **You**

But I am hanging out with cm after hours\. 😝


**080.** `18:11` **You**

Reaction: ❤️ from Meredith Lamb
But in all seriousness I am all in, I already told you\.\. I am so in love with every aspect of you\.  I have never fallen in love like this and won’t again\.\. I know officially living together is a ways off but spending more regular evenings or let’s just say time in general with each other might not be that far away\.\. and I think that is what I am going to focus on\.  And getting whatever reasonable chance to spend minutes with you wherever I can because it all means something to me\.


**081.** `18:13` **You**

I think it is because I have fallen in like with you as much as I have fallen in love with you\.  Which might sound funny but I think it is one of those things that you need for it to be truly real and lasting\.


**082.** `18:20` **Meredith Lamb (+14169386001)**

Yeah I get it\. Ok, just didn’t want the caution caution ⚠️ alerts to get to you\. Lol


**083.** `18:21` **You**

No no I am already past the point of no return I think I was months ago to be honest\.\. even before Detroit\.


**084.** `18:23` **You**

Reaction: ❤️ from Meredith Lamb
This was like “you had me at hello” lol… 🥰


**085.** `18:30` **Meredith Lamb (+14169386001)**

Ditto\. So same page still\. Phew


**086.** `18:33` **You**

Yeah mer \-  nothing is going to change I am not
Looking backwards to relive old flings or explore what could have been or any shit like that\.\. I am not looking sideways because in either case no one can come close to what I believe we have\.  And I am assuming we are on the same page on everything honestly so even though I have irrational fears sometimes I try not to let it bother me too much\.


**087.** `18:36` **You**

I am also sorry if sharing what dev said caused you to worry… you have enough going on\.


**088.** `18:38` **Meredith Lamb (+14169386001)**

Didn’t worry per se 😉


**089.** `18:54` **You**

Per se lol


**090.** `18:54` **You**

Deleted??


**091.** `18:55` **Meredith Lamb (+14169386001)**

No was just doing volleyball drop off and then had to walk dogs\.


**092.** `18:55` **Meredith Lamb (+14169386001)**

Gah non stop crap to do


**093.** `18:55` **Meredith Lamb (+14169386001)**

Now I’m lying down for an hour until volleyball pick up lol


**094.** `18:55` **Meredith Lamb (+14169386001)**

Anyway I maybe did worry a bit but feel better now\.


**095.** `18:56` **Meredith Lamb (+14169386001)**

I wasn’t sure how much you would listen to the caution speakers\. 🙃


**096.** `18:56` **Meredith Lamb (+14169386001)**

If it might change anything or not


**097.** `19:23` **You**

No like I said no listening\.\. Just going to try trusting and leaning on each other to get through this to what is next\.


**098.** `19:48` **Meredith Lamb (+14169386001)**

Shortest nap ever :\(


**099.** `19:49` **Meredith Lamb (+14169386001)**

Back to 🏐


**100.** `20:17` **You**

Well I had more Gracie bullshit tonight\.\. so yay\.


**101.** `20:22` **Meredith Lamb (+14169386001)**

😬 same old or new content?


**102.** `20:24` **You**

Same shit different day\.\.


**103.** `20:24` **You**

If we are getting closer and closer to me signing off


**104.** `20:24` **You**

But


**105.** `20:30` **Meredith Lamb (+14169386001)**

But…\.?


**106.** `20:34` **You**

But we are getting closer to me just signing off\.\. I have been trying to connect and find ways\.\. but I mean she is 18 and she literally won’t stop fighting about everything including still wanting to live here and go to university but she actually wants to force the issue and live with me and maddie who hates her\.\. like it is impossible\. J was going to fly her up to see her friends and I am saying no now because she might refuse to get in the return flight back\.


**107.** `20:36` **Meredith Lamb (+14169386001)**

No words…\. It sounds impossible but hopefully she relents eventually


**108.** `20:37` **You**

I don’t think she will she has created all of these scenarios\.\.  I cannot even explain it to try to justify what she wants and none of them make sense


**109.** `21:20` **Meredith Lamb (+14169386001)**

:\(


**110.** `21:29` **You**

I have to go watch something g with fam for 10 mins then I coming downstairs if you want to chat for a few mins then I am going to bed\.


**111.** `21:30` **Meredith Lamb (+14169386001)**

k, watching handmaids tale and then going to bed too xo


**112.** `21:32` **You**

I will message you when I am back down if you still up


**113.** `21:59` **You**

Wow that was quite offensive


**114.** `21:59` **You**

Even for snl


**115.** `22:10` **You**

Must have missed you\.\. nite xo


