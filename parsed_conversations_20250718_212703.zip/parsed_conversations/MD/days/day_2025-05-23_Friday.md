# Daily Conversation: 2025-05-23 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-23 |
| **Day** | Friday |
| **Week** | 6 |
| **Messages** | 509 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-23T00:54 - 2025-05-23T22:42 |

## 📝 Daily Summary

This day contains **509 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:54` **You**

Yeah ok well that was super intense… call me when you get a chance and I can tell you what went down but I think Gracie knew a bit more than I thought\. And it came out enough tonight that Jaimie confronted me\. Let’s just say it didn’t help my relationship with her\.  But at least it is out now\.\. she has no interest in this coming out at work\.  I calmed Gracie down somewhat but we will see\.  So far they think we have only had discussions and that you only found out I was separating after the fact\.


**002.** `00:55` **You**

I mean that doesn’t make it easier on me from any perspective, certainly it isn’t accepted\.  But at least it won’t be a surprise later on\. I am surprised Jaimie could have taken it way worse\.


**003.** `00:55` **You**

No way I am going to gym tomorrow\.


**004.** `00:56` **You**

Reaction: 😡 from Meredith Lamb
I am going to bed now, love you,
Sorry this happened it is all my fault\.\. I am sure I will ruin everything by the end of this\.  Maybe you should cut ties and run away while you can ☹️ anyhow xoxo\.


**005.** `01:01` **You**

Oh and I told you the universe hates me and doesn’t want me to be happy remember lol just look at the last day rofl…\.\. like double whammy


**006.** `01:12` **You**

Please don’t give up on us…\.\.


**007.** `06:07` **Meredith Lamb (+14169386001)**

Ok I was not expecting to wake up to that\. Need a minute here\. 😳😵😵‍💫🤮


**008.** `06:22` **Meredith Lamb (+14169386001)**

So yeah this is unexpected to say the least\. For some reason I thought this would happen to me first \(being confronted\)\. I’m still expecting it on my end\. I am not going anywhere but shit, this just gets more and more complicated\. I couldn’t go anywhere now, seriously\. I love you\. I just may not be fully functional at all times\. God, especially in the office now\. I hope you are doing alright?


**009.** `06:38` **You**

Appreciate emoticon progression\.\. needs to be said first\.


**010.** `06:41` **You**

This is fresh right now so I expect things will settle a bit\.  Gracie is a wildacard\.  Just laying down for a bit more then getting up and will answer rest\.  I just needed to hear you say we aren’t over\.  Barely slept\.


**011.** `06:43` **Meredith Lamb (+14169386001)**

How did this happen last night though?


**012.** `06:44` **Meredith Lamb (+14169386001)**

And of course we are not over\. I mean the anxiety this gives me is enough to make me throw up but not even close to enough to erase how I feel about you, us, …


**013.** `06:44` **Meredith Lamb (+14169386001)**

Is she going to creep me and find out Andrew’s contact and contact him? Eek


**014.** `06:45` **You**

Reaction: 😬 from Meredith Lamb
Gracie had been doing the whole I know something bullshit


**015.** `06:45` **Meredith Lamb (+14169386001)**

I did that when I found out about Andrew and Maggie in 2016\. Went straight to her husband\.


**016.** `06:46` **You**

I don’t think Gracie would but I would recommend blocking Facebook to non friends\.


**017.** `06:46` **You**

Just to be on safe side


**018.** `06:46` **Meredith Lamb (+14169386001)**

Isn’t Facebook always like that?


**019.** `06:47` **You**

Well your friends list is private even from friends


**020.** `06:47` **You**

But photos can be further locked down


**021.** `06:47` **You**

Linked in


**022.** `06:48` **You**

Other than that nothing else really


**023.** `06:48` **Meredith Lamb (+14169386001)**

Instagram lol


**024.** `06:48` **Meredith Lamb (+14169386001)**

Tik tok


**025.** `06:48` **Meredith Lamb (+14169386001)**

Snapchat


**026.** `06:48` **Meredith Lamb (+14169386001)**

lol


**027.** `06:48` **You**

I don’t n in know how easy that would be to creep


**028.** `06:48` **You**

I don’t know those


**029.** `06:48` **Meredith Lamb (+14169386001)**

Flickr


**030.** `06:48` **Meredith Lamb (+14169386001)**

You tube


**031.** `06:48` **Meredith Lamb (+14169386001)**

I’m all over


**032.** `06:49` **You**

Reaction: 😂 from Meredith Lamb
🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮


**033.** `06:49` **Meredith Lamb (+14169386001)**

I can’t block everything


**034.** `06:49` **Meredith Lamb (+14169386001)**

lol


**035.** `06:49` **Meredith Lamb (+14169386001)**

I’m like a teenager online


**036.** `06:49` **You**

Yeah\.


**037.** `06:49` **Meredith Lamb (+14169386001)**

Pinterest


**038.** `06:50` **Meredith Lamb (+14169386001)**

I could go in probably


**039.** `06:50` **Meredith Lamb (+14169386001)**

:p


**040.** `06:51` **You**

I can tell you the whole thing a lot easier if we get a chance to teams easier that way\.  This is painful\.  I just know yesterday was literally the worst day I think I have had in years… I cannot remember…


**041.** `06:52` **Meredith Lamb (+14169386001)**

We can chat today


**042.** `06:52` **Meredith Lamb (+14169386001)**

If you don’t have a full day


**043.** `06:53` **Meredith Lamb (+14169386001)**

I have stuff but not too much


**044.** `06:54` **You**

I don’t either before 9 or later\.\. I am getting up now and will be online shortly\.  You do whatever you have to do and just let me know\.  I am sorry mer really am\.


**045.** `06:56` **You**

And I am sorry you feel past the ability to walk away from us it is silly\.  I love you completely nothing can change that\.  But I am worried about you and the decisions you might need to make\.


**046.** `06:56` **You**

I am past the ability\.\.


**047.** `06:57` **You**

I don’t know what you was in that sentence


**048.** `06:57` **You**

I am so far past


**049.** `06:57` **You**

lol


**050.** `06:57` **You**

There


**051.** `06:57` **Meredith Lamb (+14169386001)**

I’m pretty sure we are on the same page there\. Just have slightly different manners in dealing… not in how we feel


**052.** `06:58` **Meredith Lamb (+14169386001)**

Do you need to talk now?


**053.** `06:59` **You**

I need to get up and functioning and see what is going on\.  Let me do that\.


**054.** `07:00` **Meredith Lamb (+14169386001)**

k same and the Edmonton travellers are back here which is crowding my house\. Office during work will be fine tho


**055.** `08:02` **Meredith Lamb (+14169386001)**

So I guess I just need to wake up to a message like that if I don’t want to fall back asleep :p …\. Did the trick


**056.** `09:08` **You**

How are you right now


**057.** `09:20` **Meredith Lamb (+14169386001)**

Just took Maelle to school\. Pretty sick to my stomach tbh\. Your silence doesn’t help lol


**058.** `09:39` **You**

Tried calling driving


**059.** `11:07` **You**

Btw if you feel uncomfortable saying anything bit would rather address
It here that is fine too\.  I know it can be difficult, but I don’t want  you to hold back if you feel you need to say or share something\.


**060.** `11:09` **Meredith Lamb (+14169386001)**

I am not holding back anything\.


**061.** `11:09` **Meredith Lamb (+14169386001)**

I do feel like my brain is processing a SHIT TON though\. Omg


**062.** `11:10` **You**

I wasn’t trying to be critical\.\. I just wanted to give you whatever leeway you need


**063.** `11:12` **You**

Like this is why I feel like I just need to retreat away for a while and leave you alone\.\. or…\.


**064.** `11:13` **Meredith Lamb (+14169386001)**

Honestly just let me process this “my family knows now”…\.


**065.** `11:13` **You**

Ok just let me know when you want to connect again\.\. will wait until you are ready not trying
To push\.


**066.** `11:14` **Meredith Lamb (+14169386001)**

Are you feeling super stressed by this new development?


**067.** `11:14` **Meredith Lamb (+14169386001)**

I think I’m having chest pain lol


**068.** `11:14` **You**

I am more worried about your reaction\.


**069.** `11:15` **Meredith Lamb (+14169386001)**

I mean I knew it was inevitable but …\. Whoah


**070.** `11:16` **You**

Yep\. I know again just take your time process, and let me know I will back off give you space\.  I feel like you feel trapped pressured etc\.\.


**071.** `11:18` **Meredith Lamb (+14169386001)**

I do not feel trapped\. Well I do in my current living situation and not being able to actually be with you but I don’t feel trapped in anything with you\. When I am with you, it feels safe, comfortable, amazing etc\. it is the aftermath I struggle with…


**072.** `11:19` **You**

But now this\.


**073.** `11:19` **You**

I get it


**074.** `11:20` **Meredith Lamb (+14169386001)**

My daughter just got 2 teeth pulled\. Gotta pay and get back to my laptop


**075.** `11:24` **You**

Kk hope she is ok


**076.** `11:26` **You**

Meeting with octo done early need to step away for a moment to just go for a walk will be back I\. A min or two\.


**077.** `11:52` **You**

Just plugging away on ai workshop right through to one of you need anything


**078.** `11:54` **Meredith Lamb (+14169386001)**

You can call me if you want to chat\. Just not sure if you want to…


**079.** `14:52` **Meredith Lamb (+14169386001)**

So my mom thinks someone in your family is going to call up Andrew and tell him\.


**080.** `14:52` **Meredith Lamb (+14169386001)**

😵‍💫


**081.** `14:54` **You**

I got home spoke to Jaimie and Gracie… Gracie was worried about friends Jaimie was cold but fine\.\.


**082.** `14:54` **You**

I don’t think so mer


**083.** `14:54` **Meredith Lamb (+14169386001)**

Guess we will see


**084.** `14:54` **You**

Tell your mother I am sorry


**085.** `14:54` **You**

My fault


**086.** `14:55` **You**

I should have just left it alone


**087.** `14:55` **Meredith Lamb (+14169386001)**

My mom says you sound naive and don’t know women very well\.


**088.** `14:55` **Meredith Lamb (+14169386001)**

LOL


**089.** `14:56` **You**

Tell her she is right on all counts


**090.** `14:56` **You**

Regardless


**091.** `14:56` **You**

Jaimie assured me she wasn’t


**092.** `14:56` **You**

This morning


**093.** `14:58` **You**

Maybe we stop all
Communi action I will tell them we broke it off and then just hope for the best as you say


**094.** `14:58` **Meredith Lamb (+14169386001)**

No


**095.** `14:58` **Meredith Lamb (+14169386001)**

Definite no


**096.** `14:58` **You**

Your well\-being is more important to me than my own


**097.** `14:59` **You**

I will still be here after


**098.** `14:59` **You**

If you can wait


**099.** `15:02` **You**

All I really care about is you in this\.\. o cannot be the reason you get hurt


**100.** `15:02` **You**

And that is exactly what I am doing already even before last night


**101.** `15:18` **Meredith Lamb (+14169386001)**

Well we are not going no contact\.


**102.** `15:18` **Meredith Lamb (+14169386001)**

I just need to get in this new role\.


**103.** `15:18` **Meredith Lamb (+14169386001)**

But you can’t accelerate it and be too good about it\.


**104.** `15:18` **Meredith Lamb (+14169386001)**

Because you wouldn’t be like that normally\.


**105.** `15:19` **You**

I will be on vacation anyways that week\.


**106.** `15:19` **You**

So when I get back I will just take it over


**107.** `15:19` **You**

Doesn’t matter anyways will be fine


**108.** `15:31` **Meredith Lamb (+14169386001)**

Just don’t be too accelerate\.


**109.** `15:33` **You**

I will just wait to see what happens\.\. not going to push anything\.  She was open to a transition period\.\. I will just leave it alone ok\.\. not sure what else to do\.


**110.** `15:50` **Meredith Lamb (+14169386001)**

Yeah just leave it alone\.


**111.** `16:13` **Meredith Lamb (+14169386001)**

Still talking to my mom\.


**112.** `16:13` **Meredith Lamb (+14169386001)**

lol


**113.** `16:13` **Meredith Lamb (+14169386001)**

Maybe you need a talk with her\.


**114.** `16:13` **Meredith Lamb (+14169386001)**

Hahaha


**115.** `16:13` **You**

I already feel like shit\.\. I don’t think it could get much worse


**116.** `16:13` **Meredith Lamb (+14169386001)**

lol


**117.** `16:14` **Meredith Lamb (+14169386001)**

My mom would whip you into shape


**118.** `16:14` **Meredith Lamb (+14169386001)**

She is military


**119.** `16:15` **You**

I am not sure that would be her aim\.\.


**120.** `16:15` **Meredith Lamb (+14169386001)**

My mom is very like that


**121.** `16:17` **You**

She is not going to want to pick me up mer I came in to an already difficult situation\.\. and I made it soo much worse\.  I was supposed to help you and instead I fell completely in love with you and pretty much fucked everything up\.\. so no I don’t think she wants to whip me into anything\.


**122.** `16:18` **Meredith Lamb (+14169386001)**

My mom has strong opinions so no matter what you say, she will tell you what she thinks\. Like Deb\.


**123.** `16:18` **Meredith Lamb (+14169386001)**

lol


**124.** `16:18` **Meredith Lamb (+14169386001)**

I always use to compare her to Tina\. lol


**125.** `16:19` **You**

I am happy she is there for you mer\.


**126.** `16:23` **Meredith Lamb (+14169386001)**

I think she’d be there for you if you wanted her to be\. :\)


**127.** `16:24` **You**

Mer there is no way she is going to like me after this\.\. listen it’s fine you don’t have to try to make me feel better like I said I just need you to take care of you… that will make me happy\.


**128.** `16:25` **Meredith Lamb (+14169386001)**

That is not true\. You do not know my mother


**129.** `16:27` **You**

I know\.\. I wish I did\.\. she sounds amazing to me\.\. but like I said my head is not anywhere near a good place atm and will not likely be anywhere near one for a really long time\.\. and I don’t want to keep bringing you down, or if you are down making it worse\.\. you have enough to focus on and I will focus on keeping things calm here\.


**130.** `16:28` **Meredith Lamb (+14169386001)**

Just make sure no one contacts Andrew\. Lol


**131.** `16:28` **Meredith Lamb (+14169386001)**

\(I know you can’t do that\)


**132.** `16:29` **You**

That is all I am focused on


**133.** `16:34` **Meredith Lamb (+14169386001)**

Did everything go ok with teddy?


**134.** `16:41` **Meredith Lamb (+14169386001)**

Do you care if I get really drunk tonight? I think I’m going to start drinking\.


**135.** `16:41` **Meredith Lamb (+14169386001)**

I have no driving responsibilities


**136.** `16:59` **Meredith Lamb (+14169386001)**

My mom is talking about supper vs\. Dinner


**137.** `16:59` **Meredith Lamb (+14169386001)**

🙄


**138.** `17:00` **You**

Sorry talking to j


**139.** `17:00` **You**

Give me a few


**140.** `17:01` **Meredith Lamb (+14169386001)**

kk


**141.** `17:43` **Meredith Lamb (+14169386001)**

Omg my mother


**142.** `17:43` **Meredith Lamb (+14169386001)**

80 year olds


**143.** `17:58` **You**

>
Yes all tests good we think the antibiotic eyedrops irritated her eyes\.

*💬 Reply*

**144.** `17:58` **You**

>
Do whatever you want mer\.\. whatever you need to do\.

*💬 Reply*

**145.** `17:58` **You**

>
East coast rules\.

*💬 Reply*

**146.** `18:00` **You**

I am 99% sure not only will j not tell Andrew I don’t even think it entered her mind\.


**147.** `18:02` **Meredith Lamb (+14169386001)**

I think it entered her mind\.


**148.** `18:02` **You**

I just don’t think she wants to run into you she is worried about that she would feel humiliated and angry\.


**149.** `18:02` **You**

>
Omg everyone contradicts me today…

*💬 Reply*

**150.** `18:02` **You**

I know this woman


**151.** `18:02` **You**

She isn’t like that


**152.** `18:02` **Meredith Lamb (+14169386001)**

>
I would feel the same way\.

*💬 Reply*

**153.** `18:03` **You**

Let’s say if she saw you in a bar she might slap you\.\. that is Jaimie\.\. and that is might and that is if you smirked at her


**154.** `18:03` **You**

That is the extent\.


**155.** `18:03` **Meredith Lamb (+14169386001)**

????


**156.** `18:03` **Meredith Lamb (+14169386001)**

For real?


**157.** `18:04` **You**

Jaimie is simple country girl rough\.\. that is how she was raised


**158.** `18:04` **You**

She would never think to try to destroy your life that way\.


**159.** `18:04` **You**

I told her generally what happened to you\.\. she might hate this situation but she understands that\.


**160.** `18:04` **Meredith Lamb (+14169386001)**

>
You know I grew up in the country right?

*💬 Reply*

**161.** `18:05` **You**

You don’t come across as rough


**162.** `18:05` **Meredith Lamb (+14169386001)**

Town population 2,000


**163.** `18:05` **You**

How many fist fights you been in


**164.** `18:06` **You**

Again you are not her\.\. but she is also not nefarious


**165.** `18:06` **You**

She wouldn’t go to those lengths or even think of them


**166.** `18:06` **You**

You asked me to take care of it\.\. fairly certain I have verified it won’t happen\.\. I just need to figure out a way to last here\.\. I almost walked out and left


**167.** `18:07` **Meredith Lamb (+14169386001)**

I mean many ppl don’t hi k im Toronto\. I’m not\.


**168.** `18:07` **You**

We did fight of course and I was
Going to get a place for a month


**169.** `18:07` **Meredith Lamb (+14169386001)**

\*im


**170.** `18:07` **Meredith Lamb (+14169386001)**

Fight tonight?


**171.** `18:07` **You**

But then she said we wouldn’t be able to get the house done


**172.** `18:08` **You**

Anyhow just put a pin in it\.\. how many drinks in are
You\.


**173.** `18:08` **Meredith Lamb (+14169386001)**

I just got off the phone with my mom


**174.** `18:08` **Meredith Lamb (+14169386001)**

Many drinks in


**175.** `18:08` **You**

So 3


**176.** `18:08` **You**

Or 4


**177.** `18:08` **You**

lol


**178.** `18:08` **You**

Nailed it


**179.** `18:08` **Meredith Lamb (+14169386001)**

I can’t talk to her without drinking


**180.** `18:08` **You**

Or more


**181.** `18:08` **You**

Well she probably
Thinks I am a fucking idiot so yay me


**182.** `18:09` **Meredith Lamb (+14169386001)**

My mom? No


**183.** `18:09` **Meredith Lamb (+14169386001)**

She’s invested


**184.** `18:09` **Meredith Lamb (+14169386001)**

She’s like me


**185.** `18:09` **Meredith Lamb (+14169386001)**

I turned her


**186.** `18:09` **Meredith Lamb (+14169386001)**

Lol


**187.** `18:10` **You**

She is invested in what


**188.** `18:10` **Meredith Lamb (+14169386001)**

Listen, my mom is 80\. She is invested in me\. So now she is invested in you\. 😇


**189.** `18:10` **You**

I do t think it works that way


**190.** `18:10` **You**

But I am naive about women


**191.** `18:11` **Meredith Lamb (+14169386001)**

Well yeah most men are…


**192.** `18:11` **Meredith Lamb (+14169386001)**

In her opinion


**193.** `18:11` **Meredith Lamb (+14169386001)**

She was born in 45 and grew up in the 60s


**194.** `18:12` **You**

Again I think you might be overestimating her investment but I am glad
You seem to feel a bit better or at least drunk so you care less


**195.** `18:13` **Meredith Lamb (+14169386001)**

I think I know her by now 🙄


**196.** `18:13` **You**

Ok then


**197.** `18:14` **Meredith Lamb (+14169386001)**

Come on, you don’t think I’m wrong?


**198.** `18:15` **You**

I think you are optimistic\. How could she have any respect for a man who would take advantage of a situation where someone came to him for help\.\. his subordinate and we end up here\.\. lol\.  I mean that is what most people would see from the outside\.


**199.** `18:15` **Meredith Lamb (+14169386001)**

I did not go to you for help\. She knows that n


**200.** `18:16` **Meredith Lamb (+14169386001)**

She knows me


**201.** `18:16` **Meredith Lamb (+14169386001)**

I did not in any means go to you for help


**202.** `18:16` **Meredith Lamb (+14169386001)**

Like no t even close


**203.** `18:16` **Meredith Lamb (+14169386001)**

Not even in the realm


**204.** `18:18` **You**

I still made your situation way worse\.


**205.** `18:18` **You**

And I caused you a ton of stress


**206.** `18:23` **Meredith Lamb (+14169386001)**

No


**207.** `18:23` **Meredith Lamb (+14169386001)**

How


**208.** `18:26` **You**

I loved you really hard\.\. and made you go crazy\.


**209.** `18:27` **You**

sorry\.\. I was putting food on\.


**210.** `18:27` **You**

and trying to calm J down\.\. which I did by agreeing to drive her somewhere tomorrow\.\.


**211.** `18:44` **Meredith Lamb (+14169386001)**

>
Yes\. You are accurately correctly\.

*💬 Reply*

**212.** `18:44` **Meredith Lamb (+14169386001)**

>
???

*💬 Reply*

**213.** `18:44` **Meredith Lamb (+14169386001)**

Why does she need a driver?


**214.** `18:45` **Meredith Lamb (+14169386001)**

Andrew and I just had a big heart to heart … kid related only


**215.** `18:48` **You**

>
Trying to calm J down from our fight\.\. we need to be able to live together\.\. she wanted to go to the outlets to go buy some shit tomorrow because she doesn't feel like she will want or have the chance to and asked me to drive her\.

*💬 Reply*

**216.** `18:48` **You**

so I said yes so as to calm her ass down\.


**217.** `18:48` **You**

>
how did that come up\.\. I am glad you found something to connect on\.

*💬 Reply*

**218.** `18:52` **Meredith Lamb (+14169386001)**

>
Wait, she cant drive?

*💬 Reply*

**219.** `18:52` **You**

>
which in turn basically made you frantic\.\. then I pushed you for more and more\.\. like an idiot\.

*💬 Reply*

**220.** `18:53` **You**

>
Sure she can\.\. but she hates driving out that way\.  It is a really really small thing for me to do to try to keep the peace after last night, this morning, and today\.

*💬 Reply*

**221.** `18:53` **Meredith Lamb (+14169386001)**

Sure, ok


**222.** `18:53` **You**

>
If I had have stopped\.\. this never would have happened\.

*💬 Reply*

**223.** `18:54` **You**

Reaction: 😂 from Meredith Lamb
ok there are three things we are talking about but you are focusing in on the driving one\.\. which is like MEH


**224.** `18:55` **You**

She fucking hates my guts\.\. lol\.\. she said some horrible shit tonight\.\. she will never forgive me\.\. but if I drive her somewhere\.\. and try to just shut up and go along here\.\. she might just not make my life a living hell for the next 2 months of being here on my own\.


**225.** `18:56` **You**

You already know what I want\.\. and that cannot happen\.\. so you please don't get mad and focus in on the driving thing\.\. I have to survive this and it is going to be brutal\.\.


**226.** `18:56` **You**

>
the other 1

*💬 Reply*

**227.** `18:56` **Meredith Lamb (+14169386001)**

>
Suuuuuuuuuure

*💬 Reply*

**228.** `18:56` **You**

>
the other 2

*💬 Reply*

**229.** `18:57` **You**

Reaction: 😂 from Meredith Lamb
>
😭

*💬 Reply*

**230.** `18:58` **Meredith Lamb (+14169386001)**

>
I’m okay with you doing what you need to do

*💬 Reply*

**231.** `18:58` **You**

I feel like you wrote three different responses before landing on that one\.


**232.** `18:59` **Meredith Lamb (+14169386001)**

Haha


**233.** `18:59` **Meredith Lamb (+14169386001)**

I’m okay with you surviving whatever you need to in order to end up with us


**234.** `18:59` **Meredith Lamb (+14169386001)**

At least I am tonight 😇


**235.** `19:01` **Meredith Lamb (+14169386001)**

I honestly don’t get why you need to be a chauffeur for an adult\. I get it for a teen but…\.\.


**236.** `19:01` **Meredith Lamb (+14169386001)**

\(Ignore\)


**237.** `19:04` **You**

>
That is literally the only thing I care about\.

*💬 Reply*

**238.** `19:04` **You**

>
bump

*💬 Reply*

**239.** `19:05` **You**

>
bump this one

*💬 Reply*

**240.** `19:06` **Meredith Lamb (+14169386001)**

>
? Not understanding this

*💬 Reply*

**241.** `19:06` **You**

i had asked you a question lol


**242.** `19:06` **Meredith Lamb (+14169386001)**

I know but I don’t understand


**243.** `19:06` **You**

you said you had a heart to heart\.\. I said glad for you how did it come up


**244.** `19:06` **Meredith Lamb (+14169386001)**

“The other


**245.** `19:07` **You**

I replied to the wrong chat


**246.** `19:07` **Meredith Lamb (+14169386001)**

Oh


**247.** `19:07` **You**

that was why the bump this one


**248.** `19:07` **Meredith Lamb (+14169386001)**

I’m so confused\. You know I’m drinking right


**249.** `19:07` **Meredith Lamb (+14169386001)**

lol


**250.** `19:07` **You**

I know\.\.


**251.** `19:08` **Meredith Lamb (+14169386001)**

So I have no idea what the question is\. Heart to heart with Andrew?


**252.** `19:08` **You**

>
you said

*💬 Reply*

**253.** `19:09` **Meredith Lamb (+14169386001)**

So Maelle is the middle child always neglected\.


**254.** `19:09` **Meredith Lamb (+14169386001)**

He’s been trying to get her on team\.


**255.** `19:09` **Meredith Lamb (+14169386001)**

Whether right or right


**256.** `19:09` **Meredith Lamb (+14169386001)**

Wrong


**257.** `19:09` **Meredith Lamb (+14169386001)**

No ideal


**258.** `19:09` **Meredith Lamb (+14169386001)**

But looks like he did


**259.** `19:09` **Meredith Lamb (+14169386001)**

It’s annoying


**260.** `19:10` **Meredith Lamb (+14169386001)**

We got out of Mac’s driving and now have to add Maelle in


**261.** `19:10` **Meredith Lamb (+14169386001)**

😳😳😳😳


**262.** `19:10` **Meredith Lamb (+14169386001)**

My mom thinks it is good


**263.** `19:10` **You**

That doesn't feel like a heart to heart\.\.  heart to hearts are usually good


**264.** `19:10` **You**

the way you make it sound is not lol


**265.** `19:10` **Meredith Lamb (+14169386001)**

Maelle is neglected a lot


**266.** `19:10` **Meredith Lamb (+14169386001)**

Heart to heart is my world
Is more just “real”


**267.** `19:11` **You**

ah ok


**268.** `19:11` **Meredith Lamb (+14169386001)**

Not good or bad but real


**269.** `19:11` **You**

well still good that Maelle will have something even if it does keep life busy\.


**270.** `19:11` **You**

if SHE wants it of course


**271.** `19:11` **You**

which is what is most important


**272.** `19:11` **Meredith Lamb (+14169386001)**

😜


**273.** `19:11` **Meredith Lamb (+14169386001)**

Time will tell


**274.** `19:11` **Meredith Lamb (+14169386001)**

My mom thinks she wants it


**275.** `19:12` **Meredith Lamb (+14169386001)**

She just spent the weekend with her and talked to her a lot


**276.** `19:12` **You**

well that is a good thing then hopefully


**277.** `19:12` **Meredith Lamb (+14169386001)**

Meh we will see


**278.** `19:12` **Meredith Lamb (+14169386001)**

Just means more driving


**279.** `19:13` **Meredith Lamb (+14169386001)**

😳


**280.** `19:13` **You**

at least you and andrew aren't fighting


**281.** `19:13` **Meredith Lamb (+14169386001)**

We are not\. Weird right?


**282.** `19:13` **Meredith Lamb (+14169386001)**

I’m paranoid about that


**283.** `19:13` **You**

>
reconciliation in the air?? 🤪

*💬 Reply*

**284.** `19:13` **You**

back at yah


**285.** `19:14` **Meredith Lamb (+14169386001)**

Omg stop


**286.** `19:14` **You**

that's for the driving\.


**287.** `19:14` **Meredith Lamb (+14169386001)**

I literally told him my salary won’t be decreasing and asked how his new job has been


**288.** `19:14` **Meredith Lamb (+14169386001)**

That’s IT


**289.** `19:15` **You**

aww that's nice though\.


**290.** `19:15` **Meredith Lamb (+14169386001)**

LOL


**291.** `19:15` **Meredith Lamb (+14169386001)**

SO NICE


**292.** `19:15` **Meredith Lamb (+14169386001)**

AWWWWWW


**293.** `19:15` **You**

that's some good communication\.\. you can build on that Mer\.


**294.** `19:15` **Meredith Lamb (+14169386001)**

OMG STOP


**295.** `19:16` **Meredith Lamb (+14169386001)**

relentless


**296.** `19:16` **You**

>
one of my many traits

*💬 Reply*

**297.** `19:16` **Meredith Lamb (+14169386001)**

I mean I have to worry about your daughter messaging Andrew


**298.** `19:16` **Meredith Lamb (+14169386001)**

Hello


**299.** `19:16` **You**

she won't


**300.** `19:17` **Meredith Lamb (+14169386001)**

Being all “you know what your F’ing wife is doing”


**301.** `19:17` **Meredith Lamb (+14169386001)**

Sure


**302.** `19:17` **Meredith Lamb (+14169386001)**

My mom is convinced she will


**303.** `19:17` **You**

>
hmm someone is getting saucy

*💬 Reply*

**304.** `19:17` **Meredith Lamb (+14169386001)**

A woman scorned


**305.** `19:17` **You**

feels like you feel scorned


**306.** `19:18` **Meredith Lamb (+14169386001)**

My mom is very worried\. Makes me like 30% more paranoid


**307.** `19:18` **You**

Ok\.\. here is what happened last night\.


**308.** `19:18` **You**

Gracie never suggested anything like that\.\. she wouldn't even think to do it\.


**309.** `19:19` **You**

However she did say she would message you\.


**310.** `19:19` **You**

and J lost it on her


**311.** `19:19` **Meredith Lamb (+14169386001)**

>
I mean, maybe with a few more hours she would

*💬 Reply*

**312.** `19:19` **You**

basically told her if Gracie did that, I would go nuclear on everything lawyer up and burn it down\.


**313.** `19:20` **Meredith Lamb (+14169386001)**

You know in 2016 I co tact Maggie and her husband? I just told my parents that tonight’s


**314.** `19:20` **Meredith Lamb (+14169386001)**

\*tonight


**315.** `19:20` **You**

Gracie is going to a late night movie with her friend tonight\.\. we have not had any negative interaction, and had some positive texts


**316.** `19:20` **Meredith Lamb (+14169386001)**

🙄


**317.** `19:21` **Meredith Lamb (+14169386001)**

I mean I’m fine if she contacts me


**318.** `19:21` **Meredith Lamb (+14169386001)**

Just if she contacts Andrew I’m fucked


**319.** `19:21` **You**

you aren't fucked


**320.** `19:21` **Meredith Lamb (+14169386001)**

k


**321.** `19:21` **Meredith Lamb (+14169386001)**

lol


**322.** `19:22` **You**

what can he do you are separated\.\. you still have so many weapons to bring to bear


**323.** `19:22` **You**

you don't even understand the leverage you have here


**324.** `19:22` **Meredith Lamb (+14169386001)**

She’s going to get wasted and contact him


**325.** `19:22` **You**

omg you are going to give me a panic attack\.


**326.** `19:22` **Meredith Lamb (+14169386001)**

>
Do you want to meet him?

*💬 Reply*

**327.** `19:23` **You**

Do you want me to?


**328.** `19:23` **You**

I think you are drunk atm


**329.** `19:23` **You**

lol


**330.** `19:23` **Meredith Lamb (+14169386001)**

I mean if your daughter is going to contact him, yes


**331.** `19:23` **You**

Walk me through that logic


**332.** `19:24` **Meredith Lamb (+14169386001)**

Omg seriously


**333.** `19:24` **You**

I would meet him\.\. whatever you want\.


**334.** `19:24` **You**

If that is how you want to tell him


**335.** `19:25` **You**

I just don't understand how the two connect


**336.** `19:25` **You**

Gracie and me meeting him


**337.** `19:25` **Meredith Lamb (+14169386001)**

I mean I don’t want Gracie to tell him


**338.** `19:25` **You**

So you want me to tell him


**339.** `19:25` **Meredith Lamb (+14169386001)**

No


**340.** `19:26` **You**

Reaction: ❓ from Meredith Lamb
I think this is going to be an early night\.


**341.** `19:26` **Meredith Lamb (+14169386001)**

I am worried about Gracie reaching out to him


**342.** `19:26` **You**

I understand\.\. so why the Do you want to meet him?


**343.** `19:26` **You**

>
you are pretty active lol and it is only 7:30

*💬 Reply*

**344.** `19:26` **Meredith Lamb (+14169386001)**

I forget that part


**345.** `19:27` **Meredith Lamb (+14169386001)**

lol


**346.** `19:27` **You**

>
lol

*💬 Reply*

**347.** `19:27` **You**

really


**348.** `19:27` **You**

that was just a random thing


**349.** `19:27` **Meredith Lamb (+14169386001)**

My mom was like “I have to go”
\(You are getting drunk\)


**350.** `19:27` **You**

>
yah\.\. I get that

*💬 Reply*

**351.** `19:28` **Meredith Lamb (+14169386001)**

It’s a difficult time


**352.** `19:28` **You**

I don't think it is helping your paranoia\.


**353.** `19:28` **You**

you should pound like 6 gummies


**354.** `19:28` **Meredith Lamb (+14169386001)**

I just want my therapist back from vacay and Jim back from vacay


**355.** `19:28` **Meredith Lamb (+14169386001)**

>
I had one a while ago

*💬 Reply*

**356.** `19:29` **You**

>
I know\.\. Meredith: "Jim, Scott's wife and kids know\!\!\!"  Jim: "Wait what?"

*💬 Reply*

**357.** `19:29` **Meredith Lamb (+14169386001)**

This is actually kind of crazy\. Should I tell him?


**358.** `19:29` **You**

Sure


**359.** `19:29` **You**

why not


**360.** `19:30` **Meredith Lamb (+14169386001)**

He’s like my comfort zone


**361.** `19:30` **You**

Yeah\.\. go dive on into the comfort zone\.


**362.** `19:30` **Meredith Lamb (+14169386001)**

lol


**363.** `19:30` **Meredith Lamb (+14169386001)**

I guess I can do what I want right?


**364.** `19:30` **You**

Sure can


**365.** `19:30` **Meredith Lamb (+14169386001)**

I mean you did


**366.** `19:30` **Meredith Lamb (+14169386001)**

:p


**367.** `19:30` **You**

Reaction: 😂 from Meredith Lamb
I totally wanted that you are right


**368.** `19:31` **Meredith Lamb (+14169386001)**

Sorry


**369.** `19:31` **Meredith Lamb (+14169386001)**

Honestly feel bad about that comment


**370.** `19:32` **You**

>
you don't need to feel bad\.\. my situation is completely fucked for like 60\+ days\.\. it is kind of funny in a twisted and depressed way\.\. ;p

*💬 Reply*

**371.** `19:33` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/7bLFtDcAmwVD3pw7zTUfmy?si=mQSOTJ2KRuOmDPs3gBhP\-g


**372.** `19:36` **Meredith Lamb (+14169386001)**

Yeah this song is already on my liked play list\. Late to the game lol


**373.** `19:37` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/297PYWIVLP38C1a92ND8Kv?si=obpeckITT\-aG2PkEZZShAg


**374.** `19:38` **You**

>
Dirty\.\.  we cannot do dirty talk\.  Cause that sounds familiar to me\.

*💬 Reply*

**375.** `19:39` **Meredith Lamb (+14169386001)**

k, wait, I’ confused all of a sudden


**376.** `19:39` **You**

The rude song\.\.


**377.** `19:39` **You**

I like it\.\. but pretty suggestive :\)


**378.** `19:39` **You**

feels familiar


**379.** `19:40` **You**

>
why do you like this one\.\. usually your songs mean something

*💬 Reply*

**380.** `19:44` **Meredith Lamb (+14169386001)**

I am not usually not sure\. Liked the song… honestly the poetry is very an amazing\.


**381.** `19:45` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Maybe I had a paranoid thought you were going to ruin me\.


**382.** `19:45` **Meredith Lamb (+14169386001)**

😝


**383.** `19:46` **You**

I am writing in my journal again\.\. I need to get some stuff out\.\.


**384.** `19:49` **You**

>
This was pretty rough\.\.\.

*💬 Reply*

**385.** `19:58` **Meredith Lamb (+14169386001)**

Sorry I am ha hi donut with Mac


**386.** `19:58` **Meredith Lamb (+14169386001)**

\*am hanging out with


**387.** `19:58` **Meredith Lamb (+14169386001)**

Sooooo fun


**388.** `19:59` **Meredith Lamb (+14169386001)**

I gave her the box of my vapes


**389.** `20:00` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**390.** `20:00` **Meredith Lamb (+14169386001)**

She is giving the story behind every 60 vape


**391.** `20:01` **Meredith Lamb (+14169386001)**

“Mom this is 80$ of stealth bodies”

*📎 1 attachment(s)*

**392.** `20:02` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**393.** `20:03` **You**

glad you are having fun\.


**394.** `20:05` **Meredith Lamb (+14169386001)**

Just lying on h t bed


**395.** `20:05` **Meredith Lamb (+14169386001)**

\*her


**396.** `20:05` **Meredith Lamb (+14169386001)**

lol


**397.** `20:06` **Meredith Lamb (+14169386001)**

Apparently I can uber eats vapes


**398.** `20:06` **Meredith Lamb (+14169386001)**

\*can”t


**399.** `20:10` **Meredith Lamb (+14169386001)**

Mac is so annoyed with me\.


**400.** `20:10` **Meredith Lamb (+14169386001)**

lol


**401.** `20:10` **You**

well that seems unfair\.\. since you gave the vapes back


**402.** `20:23` **Meredith Lamb (+14169386001)**

We are vaping tonight


**403.** `20:24` **Meredith Lamb (+14169386001)**

I lost my phone and was upstairs getting every one to call it


**404.** `20:24` **Meredith Lamb (+14169386001)**

Ugh


**405.** `20:24` **Meredith Lamb (+14169386001)**

Was in Mac’s rooms


**406.** `20:24` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**407.** `20:31` **Meredith Lamb (+14169386001)**

…


**408.** `20:31` **Meredith Lamb (+14169386001)**

…\.\.


**409.** `20:31` **You**

?????????????


**410.** `20:32` **Meredith Lamb (+14169386001)**

?????????????


**411.** `20:32` **You**

mer what's up?


**412.** `20:33` **You**

or is this Mac?


**413.** `20:33` **Meredith Lamb (+14169386001)**

lol tonight is up


**414.** `20:33` **You**

Reaction: 😂 from Meredith Lamb
Still not sure who\.\. that could come from either of you


**415.** `20:33` **Meredith Lamb (+14169386001)**

I am with Mac


**416.** `20:34` **You**

yeah\.\. I know you are\.\. look you can go have fun with her\.\. don't worry about me\.


**417.** `20:34` **Meredith Lamb (+14169386001)**

By am


**418.** `20:34` **Meredith Lamb (+14169386001)**

I am


**419.** `20:35` **Meredith Lamb (+14169386001)**

She is on her phone\. I’m on kine


**420.** `20:35` **Meredith Lamb (+14169386001)**

\*mind


**421.** `20:35` **Meredith Lamb (+14169386001)**

Mine


**422.** `20:35` **Meredith Lamb (+14169386001)**

lol


**423.** `20:35` **Meredith Lamb (+14169386001)**

She was my shoot box now


**424.** `20:35` **You**

Reaction: 😂 from Meredith Lamb
yes the keyboard gets correspondingly smaller in relation to the number of glasses and gummies you consume


**425.** `20:36` **Meredith Lamb (+14169386001)**

Make this as a mine stone less


**426.** `20:36` **Meredith Lamb (+14169386001)**

She showed me joennys


**427.** `20:36` **Meredith Lamb (+14169386001)**

His are 10 pack for mgh


**428.** `20:37` **Meredith Lamb (+14169386001)**

I took a BITE


**429.** `20:37` **You**

all caps bite = big bite?


**430.** `20:39` **Meredith Lamb (+14169386001)**

I’m trying to do math with her


**431.** `20:39` **Meredith Lamb (+14169386001)**

lol


**432.** `20:39` **You**

yeah I mean words seem hard right now\.\. guessing math is harder


**433.** `20:40` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**434.** `20:40` **You**

jesus mer


**435.** `20:40` **Meredith Lamb (+14169386001)**

I asked if I could see the back ton the back age


**436.** `20:40` **Meredith Lamb (+14169386001)**

She goes “mom0


**437.** `20:40` **Meredith Lamb (+14169386001)**

lol


**438.** `20:40` **You**

I didn't understand any of that


**439.** `20:41` **You**

except mom


**440.** `20:41` **Meredith Lamb (+14169386001)**

lol


**441.** `20:41` **Meredith Lamb (+14169386001)**

It all makes sense to me


**442.** `20:41` **You**

kk


**443.** `20:42` **Meredith Lamb (+14169386001)**

Omg do you want to talk on park


**444.** `20:42` **Meredith Lamb (+14169386001)**

Person


**445.** `20:42` **You**

i don't think I can


**446.** `20:43` **You**

give me a min though


**447.** `20:43` **You**

give me amin


**448.** `20:43` **Meredith Lamb (+14169386001)**

😝 it’s ok


**449.** `20:43` **You**

no no I will i just need to get outside


**450.** `20:43` **Meredith Lamb (+14169386001)**

I’m hanging with Mac vaping lol


**451.** `20:43` **Meredith Lamb (+14169386001)**

Biggest loser\!


**452.** `20:44` **You**

ok so did you want to talk or no\.\. because that might have been a fleeting drunk/stoned idea who's time has passed\.\.


**453.** `20:45` **Meredith Lamb (+14169386001)**

I mean I’m just in the basement


**454.** `20:45` **Meredith Lamb (+14169386001)**

Don’t go outside\.


**455.** `20:45` **Meredith Lamb (+14169386001)**

Sus\.


**456.** `20:46` **You**

it wouldn't be sus\.\. I am stuck down here all the fucking time\.\. taking teddy out for a walk is a good excuse


**457.** `20:47` **Meredith Lamb (+14169386001)**

You are such a good human being\.


**458.** `20:53` **You**

Call?


**459.** `20:53` **Meredith Lamb (+14169386001)**

Mackenzie thinks you guys are weird


**460.** `20:53` **Meredith Lamb (+14169386001)**

K


**461.** `20:54` **You**

You call when you want


**462.** `21:23` **Meredith Lamb (+14169386001)**

My mom thinks I light be messed up\. Lol 🤔


**463.** `21:23` **You**

how


**464.** `21:23` **Meredith Lamb (+14169386001)**

\*might


**465.** `21:24` **Meredith Lamb (+14169386001)**

Sorry Mac’s gummies 11–\!crazy


**466.** `21:25` **You**

??


**467.** `21:25` **You**

why does your mom think you might be messed up


**468.** `21:25` **You**

this is why I get so worried mer\.\.


**469.** `21:26` **Meredith Lamb (+14169386001)**

Experience


**470.** `21:27` **You**

😢 I am sorry my brain isn't taking me to good places at the moment\.


**471.** `21:28` **Meredith Lamb (+14169386001)**

:\(


**472.** `21:28` **Meredith Lamb (+14169386001)**

I am here


**473.** `21:29` **You**

no mer\.\. not tonight\.\. just please take care of yourself tonight is all\.


**474.** `21:29` **You**

Reaction: 🤔 from Meredith Lamb
you are pretty messed up and that can lead to stupid things happening\.


**475.** `21:30` **You**



**476.** `21:32` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/1LzNfuep1bnAUR9skqdHCK?si=a8QoUCtLRKSicX16a8pAdA


**477.** `21:37` **Meredith Lamb (+14169386001)**



**478.** `21:37` **You**

mackenzie said if you go what?


**479.** `21:38` **You**

sorry I didn't get all of that it was either cut off short, or you deleted before I could finish\.


**480.** `21:39` **Meredith Lamb (+14169386001)**

I Mac is fully supportive of you\.


**481.** `21:39` **Meredith Lamb (+14169386001)**

She will lead the eventual tribe\.


**482.** `21:40` **Meredith Lamb (+14169386001)**

I said have my own i minor monologue to be and it understood…\.


**483.** `21:41` **Meredith Lamb (+14169386001)**

Get that?


**484.** `21:41` **Meredith Lamb (+14169386001)**

lol


**485.** `21:43` **You**

No I don't understand it but as I said earlier I am concerned\.\. I think if I was that messed up here right now you might be as well\.


**486.** `21:44` **You**

I am so confused\.\. 😟


**487.** `21:46` **Meredith Lamb (+14169386001)**

Yeah I don’t that\. Not confused at all\.


**488.** `21:47` **You**

yeah i know mer\.\. i know\.\. 😥


**489.** `21:49` **Meredith Lamb (+14169386001)**

??


**490.** `21:56` **Meredith Lamb (+14169386001)**

Rainbows as damir would say… but his is an invitation for so many coordination

*📎 1 attachment(s)*

**491.** `21:58` **You**

So yeah I should probably go to bed\.\. I am feeling a little sick to my stomach\.\. and my brain is beating the shit out of me\.  I am having a hard time understanding you, and I am really worried\.\.\. worst two days in a long time, and I just don't feel the universe is done punishing me yet\.  Please again, be careful tonight to not do anything stupid\.


**492.** `21:59` **You**

you probably don't understand this right now, but maybe you will tomorrow\.


**493.** `22:03` **You**

annnnd now you are gone lol\.


**494.** `22:07` **Meredith Lamb (+14169386001)**

I understood\. Lol but I’m going to pass oh too soon soon…\. :p


**495.** `22:07` **You**

good night mer\.


**496.** `22:09` **Meredith Lamb (+14169386001)**

Nite xoxo


**497.** `22:15` **You**



**498.** `22:16` **You**

😢❤️😢


**499.** `22:18` **Meredith Lamb (+14169386001)**

I’m not actually going to sleep if you are staying up…\.\.


**500.** `22:19` **You**

Mer… I just have to wait 5 mins and you will pass out\.\. just pls go to bed\. Ok\.\. we can talk tomorrow sometime\.


**501.** `22:20` **You**

Or whenever


**502.** `22:26` **Meredith Lamb (+14169386001)**

Maelle got home\. Range the doorbell etc anyway


**503.** `22:27` **Meredith Lamb (+14169386001)**

She was funny


**504.** `22:27` **Meredith Lamb (+14169386001)**

You need some of that?


**505.** `22:27` **You**

Some of what?


**506.** `22:33` **You**

Ok mer I am actually done for the night now\.


**507.** `22:34` **You**

Goodnight\.


**508.** `22:39` **You**

Reaction: ❤️ from Meredith Lamb
Please remember what I said earlier


**509.** `22:42` **You**

Ugh


