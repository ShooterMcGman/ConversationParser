# Daily Conversation: 2025-06-07 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-07 |
| **Day** | Saturday |
| **Week** | 8 |
| **Messages** | 692 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-07T06:10 - 2025-06-07T23:59 |

## 📝 Daily Summary

This day contains **692 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `06:10` **You**

Enjoy your workout this morning love\.\. ☺️


**002.** `06:11` **You**

My day off


**003.** `08:09` **Meredith Lamb (+14169386001)**

I woke up at 5\.10 for some reason and couldn’t get back to sleep


**004.** `08:09` **Meredith Lamb (+14169386001)**

My head wouldn’t stop thinking about shit\. I could not turn it off\. Ughhhh


**005.** `08:10` **You**

What shit are you thinking about met what’s wrong


**006.** `08:11` **You**

You can nap today\.


**007.** `08:11` **You**

Bad stuff?


**008.** `08:13` **Meredith Lamb (+14169386001)**

No just everything\.


**009.** `08:13` **Meredith Lamb (+14169386001)**

Anyway so I’m just making coffee


**010.** `08:13` **Meredith Lamb (+14169386001)**

Running later but still working out


**011.** `08:14` **You**

Reaction: ❤️ from Meredith Lamb
Ok I am at gym then a few quick stops then to Novotel called to confirm reservation was paranoid that it wouldn’t go through


**012.** `08:14` **You**

We can talk later


**013.** `08:17` **You**

Just sauna shower today\. Will chat in a bit\.\. try to relax\.


**014.** `08:17` **You**

Not sure what triggered you but we can chat it out


**015.** `08:27` **Meredith Lamb (+14169386001)**

>
Lots triggers me\. Even living in this house\. This situation is just becoming untenable for me\. I need out, actually separated\. Oh I was also contemplating what our separation date should be and the impacts of earlier or later depending on bank statement

*💬 Reply*

**016.** `08:48` **You**

Dun worry about bank statement unless he dropped a ton in house or cottage\.


**017.** `08:48` **You**

In fact technically a later date might be better for investment


**018.** `08:48` **You**

Since markets rebounded from late march


**019.** `09:35` **Meredith Lamb (+14169386001)**

Been talking to Andrew\. Still talking


**020.** `09:35` **Meredith Lamb (+14169386001)**

I now need to get ready\!


**021.** `09:36` **Meredith Lamb (+14169386001)**

Trying to get out of this convo\. It isn’t bad but it is going on


**022.** `09:46` **You**

Hey if this is going somewhere and you want to keep working with him on it Remeber I can still cancel no charge\.


**023.** `09:48` **You**

If you could let me know before I head to the hotel and pay though that would be good :\)


**024.** `09:50` **Meredith Lamb (+14169386001)**

I’m going to go get ready now and then leave


**025.** `09:54` **Meredith Lamb (+14169386001)**

Ok I need 20 min to get ready


**026.** `09:54` **You**

See you at noon lol


**027.** `10:11` **Meredith Lamb (+14169386001)**

Sorry sorry sorry I’m rushing\!\!


**028.** `10:11` **Meredith Lamb (+14169386001)**

lol


**029.** `10:11` **Meredith Lamb (+14169386001)**

Will tell you why I got stalled when I get t there


**030.** `10:13` **You**

Parked c13 underground parking\.


**031.** `10:13` **You**

Ok


**032.** `10:29` **You**

Front desk you tell them your name show if you are in room 1717 and there is a key for you at the desk\.


**033.** `10:32` **Meredith Lamb (+14169386001)**

K just leaving


**034.** `10:33` **You**

Gonna have a nap maybe\.


**035.** `10:37` **Meredith Lamb (+14169386001)**

K eta 10\.54


**036.** `10:45` **You**

Yep 12 noon Roger


**037.** `10:54` **Meredith Lamb (+14169386001)**

Where is the Novotel parking tho


**038.** `17:12` **You**

Hey can you send me the mls of the house by Jim’s when you get a chance?


**039.** `17:25` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28433868/842\-primrose\-court\-pickering\-liverpool\-liverpool?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**040.** `17:25` **Meredith Lamb (+14169386001)**

He never sent it to me but I think it is this one


**041.** `17:25` **Meredith Lamb (+14169386001)**

He lives on primrose


**042.** `17:26` **You**

Thx ❤️


**043.** `17:39` **You**

Reaction: ❤️ from Meredith Lamb
Btw you asked what I will be doing tonight… thinking about today\.\. and the next day and the next next…\.\. ☺️


**044.** `17:42` **Meredith Lamb (+14169386001)**

Same :\)


**045.** `17:42` **Meredith Lamb (+14169386001)**

I was sober today so will remember it all lol


**046.** `17:43` **You**

Yeah that was unique lol


**047.** `17:45` **Meredith Lamb (+14169386001)**

Sad 😭


**048.** `17:45` **You**

Lots more opportunities for that


**049.** `17:46` **You**

But tbh with time constraints it is tough


**050.** `17:46` **Meredith Lamb (+14169386001)**

Thank you for setting that up today though…


**051.** `17:46` **You**

I would have loved to get out for a walk with you


**052.** `17:47` **You**

Was happy to


**053.** `17:47` **Meredith Lamb (+14169386001)**

I’m still waiting in car for Maelle\. Hasn’t come out of work yet\. I was told to be here at 5\.40\. :p


**054.** `17:47` **You**

I love all of you not just that although that is fun\!\!


**055.** `17:48` **Meredith Lamb (+14169386001)**

I know, I feel the same but I do feel my body/soul literally ache sometimes for you so today was nice


**056.** `17:50` **You**

Yeah I feel like that a lot\.\. again partly why I felt I had to open up as
Much as I did\.  This was great\.\. and there will be more of these but I do look forward towards the real deal one day\.\. yeah that’d be nice


**057.** `18:08` **Meredith Lamb (+14169386001)**

Real deal… that would be nice ❤️❤️


**058.** `18:12` **You**

Every day till something breaks rofl


**059.** `18:15` **You**

You go to lcbo?


**060.** `18:15` **You**

Or is it an uber night lol


**061.** `18:19` **Meredith Lamb (+14169386001)**

There right now


**062.** `18:20` **Meredith Lamb (+14169386001)**

Look at price\. One of Mac’s friends parents sent this up to cottage\. Good lord

*📎 1 attachment(s)*

**063.** `18:24` **Meredith Lamb (+14169386001)**

I’m getting an old favourite


**064.** `18:25` **You**

ROFL


**065.** `18:26` **You**

Reaction: 👍 from Meredith Lamb
Will see how close to two glasses you stay


**066.** `18:30` **Meredith Lamb (+14169386001)**

Is that a dare?


**067.** `18:30` **You**

I am guessing 6


**068.** `18:30` **Meredith Lamb (+14169386001)**

No


**069.** `18:30` **You**

Yep


**070.** `18:30` **You**

6


**071.** `18:31` **You**

Bet


**072.** `18:31` **You**

Only 2 of my glasses


**073.** `18:35` **Meredith Lamb (+14169386001)**

lol


**074.** `18:43` **Meredith Lamb (+14169386001)**

You can probably infer the prompt somewhat\. Response…That’s powerful—and deeply telling\.
Two months in, most people are still hovering in the physical and emotional shallows\. But you’re describing a connection that keeps deepening with each encounter\. That’s not just chemistry—it’s emotional gravity\. The kind that pulls two people closer not just in body, but in trust, vulnerability, and mutual care\.
When making love becomes more intense and more meaningful over time, it usually means something bigger is taking shape beneath the surface\. You’re not just sharing bodies—you’re unfolding into each other\. It’s as if each time brings a new layer of truth or tenderness, like your hearts are slowly becoming less guarded, more known\.
It’s beautiful—and probably a little scary too\. Because when it means more, it carries more weight\. More potential\. More risk\. More “what now?” questions, even as your body and heart say yes\.
How are you feeling about this? Does it feel safe, or does it stir something uncertain in you too?


**075.** `18:44` **You**

Reaction: 😂 from Meredith Lamb
Had to stop to read when I started someone almost ran into me\.\. in Oshawa mall\.


**076.** `18:48` **You**

Reaction: ❤️ from Meredith Lamb
Yeah I felt that each time but especially today\.\. I honestly have never felt
Like this \.\. I have never been happier
Or more comfortable with anyone\.  Never wanted anyone as much as I want you, never felt as complete or even close with anyone\.  Again I wasn’t lying about before, even before the last 25
Years it has never been like this for me, it has never been better not even close\.\. I am so fucking lucky to have found you regardless of the shitstorm all around us\.\.  ❤️


**077.** `18:49` **You**

I think you have to paste the prompt in though therms the rules


**078.** `18:49` **You**

Your rules


**079.** `18:54` **Meredith Lamb (+14169386001)**

The prompt is pretty boring\. I was more just chatting with ai back and forth\. Do that sometimes now


**080.** `18:54` **Meredith Lamb (+14169386001)**

lol


**081.** `18:54` **Meredith Lamb (+14169386001)**

But I liked the response 🙂


**082.** `18:56` **You**

Yeah I could relate to it\.\. helped me articulate my response… it is a bit insane\.\. but it is very real\.\. I don’t see this burning out\.


**083.** `18:59` **You**

>
Yeah yeah sure my next promotion will be equally boring and inconsequential 😊

*💬 Reply*

**084.** `19:03` **Meredith Lamb (+14169386001)**

\*promotion or prompt


**085.** `19:08` **You**

Prompt


**086.** `19:09` **Meredith Lamb (+14169386001)**

No I’m just chatting\. :\) more… insightful\. ChatGPT knows me now\.
You’re loving someone fully, openly, and with your whole self—and that’s brave\. But it’s also exposing\. When the connection keeps deepening, so does the risk\. It’s no longer just wanting him—it’s needing him in some emotional way\. That shift can feel both beautiful and terrifying\.
You might be thinking:
- What if he pulls away?
- What if I’ve tied my happiness to something that can’t be secure in the long run?
Loving someone while still in the shadow of uncertainty—because of circumstance, timing, secrecy, or power dynamics—is a tightrope walk\. And even when it feels safe in the moment, the “what ifs” can start whispering\.
But the fact that you’re not ignoring those whispers—that you’re giving them air here—means you’re taking care of your heart\. You’re not naïve\.


**087.** `19:10` **Meredith Lamb (+14169386001)**

K going to walk the dogs … griff crying and scratching me argh\!


**088.** `19:17` **You**

My gpt
Tried
To reverse engineer the prompts you might have used\.
Here are a few pared\-down, everyday prompts she might have tried—each in a couple of quick back\-and\-forths, with none of the fancier phrasing lifted from the reply:
⸻
Prompt Set A
1\.	“We’re about two months in and our lovemaking feels stronger every time—what’s up with that?”
2\.	“How do I even make sense of how it’s making me feel?”
⸻
Prompt Set B
1\.	“Me and my partner both just got out of rough splits and now, two months later, sex keeps getting more intense\. Is that normal?”
2\.	“What should I be asking myself about it?”
⸻
Prompt Set C
1\.	“It’s been eight weeks together and every time we’re intimate it feels deeper\. Why do you think that is?”
2\.	“Any thoughts on how I should think through what this means?”
⸻


**089.** `19:21` **Meredith Lamb (+14169386001)**

Wow, reverse\-engineer\. Now I know where Gracie gets it from\. 😜


**090.** `19:23` **Meredith Lamb (+14169386001)**

For the record, they are all kind of correct\. Mine was worded slightly differently… more conversational\. Literally was having a convo back and forth


**091.** `19:24` **You**

Ah I see lol she doesn’t have my skills yet


**092.** `19:25` **Meredith Lamb (+14169386001)**

Maybe she was born with them\. Part of her DNA


**093.** `19:26` **You**

I mean be you don’t know it yet but this is an ultra modern version of Roxanne you are actually I love with the telling me everything to say and do… 😆


**094.** `19:29` **Meredith Lamb (+14169386001)**

Roxanne?


**095.** `19:29` **Meredith Lamb (+14169386001)**

I do not tell you what to say and do\! Lol


**096.** `19:29` **You**

Classic Steve Martin movie


**097.** `19:29` **Meredith Lamb (+14169386001)**

Oh I haven’t seen that in forever


**098.** `19:30` **Meredith Lamb (+14169386001)**

Was hoping you didn’t mean the police song


**099.** `19:30` **You**

The ai is steve Martin not you


**100.** `19:31` **You**

You know the man behind the man\.


**101.** `19:31` **Meredith Lamb (+14169386001)**

Not really but whatever


**102.** `19:31` **Meredith Lamb (+14169386001)**

Forget that movie


**103.** `19:31` **You**

Steve Martin helped a woman fall in love with another man


**104.** `19:31` **You**

But she was really in love with him and didn’t know it\.


**105.** `19:32` **You**

Explaining kills it…\. BOOOOOOOOOO


**106.** `19:32` **Meredith Lamb (+14169386001)**

lol totally


**107.** `19:33` **You**

I am super
Curious about all your gpt
Conversations now they must be pretty deep


**108.** `19:40` **Meredith Lamb (+14169386001)**

Depends on the day really


**109.** `19:41` **Meredith Lamb (+14169386001)**

I don’t worry about people getting into mine so I talk to it pretty freely but I do delete also


**110.** `19:41` **You**

I am not worried at all\.


**111.** `19:44` **You**

I mean again I think everyone basically knows what is going to happen with us\. So while I still try to keep it off the radar, I am not worried anymore\.


**112.** `19:47` **Meredith Lamb (+14169386001)**

I honestly wish my family knew\. But maybe I’m naive\. We will see eventually I guess\. lol


**113.** `19:48` **You**

I mean most does already lol


**114.** `19:49` **Meredith Lamb (+14169386001)**

True\!


**115.** `19:49` **Meredith Lamb (+14169386001)**

Andrew told me this morning I’m too open and tell too much\. In my head: “you have no idea”


**116.** `19:50` **Meredith Lamb (+14169386001)**

It’s not like I tell lies


**117.** `19:54` **You**

No you don’t at all


**118.** `19:55` **You**

I think it is more about the recipient and can they handle all of the truth\.\. lol… what I try not to think about is all the stuff you don’t tell me because you realize what I can and cannot handle now lol\.


**119.** `19:57` **You**

I know it shouldn’t matter\.\. but you know how you feel about me being yours\.\. well I feel like that about you too\.\.  but for some reason the past still bugs me\.\. I want to love you so much and so hard the past just fades\.\. but that isn’t how it works\.\.
Still it doesnt stop me from trying lol\.


**120.** `20:00` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
You are mine now\. 😍 But not in the past, and that’s OKAY\!
Maybe I’m on the spectrum … can’t tell what people can handle socially\. lol


**121.** `20:02` **You**

I am def on spectrum


**122.** `20:03` **Meredith Lamb (+14169386001)**

I don’t think so\.


**123.** `20:10` **You**

>
>
I am 100% on board with me being yours lol

*💬 Reply*

**124.** `20:12` **Meredith Lamb (+14169386001)**

k, and it can’t be temporary 😜


**125.** `20:15` **You**

It’s not


**126.** `20:16` **You**

This is all I want\.\. not changing\. Too happy\.


**127.** `20:18` **Meredith Lamb (+14169386001)**

k, you should go spend some time  watching movies or something with the girls and not be distracted… no?


**128.** `20:19` **You**

They are fighting


**129.** `20:19` **You**

I am distracting myself from the fighting


**130.** `20:20` **Meredith Lamb (+14169386001)**

Oh no


**131.** `20:22` **Meredith Lamb (+14169386001)**

My girls are all in good moods\. It’s weird


**132.** `20:22` **Meredith Lamb (+14169386001)**

Even Mac just had to tell me about her whole day


**133.** `20:22` **Meredith Lamb (+14169386001)**

I’m like, uh huh uh huh yeah yeah


**134.** `20:22` **Meredith Lamb (+14169386001)**

lol


**135.** `20:24` **Meredith Lamb (+14169386001)**

\#2 and then I’m done 😇

*📎 1 attachment(s)*

**136.** `20:28` **You**

ROFL that is a big glass


**137.** `20:29` **You**

And I still don’t believe you but if you want to veg out I will leave
You be no more watching a show Gracie flipped on maddie then stomped upstairs maddie went to her room I am now in basement\. Lo


**138.** `20:30` **Meredith Lamb (+14169386001)**

It is not a big glass\. It is just closest in the photo lol


**139.** `20:31` **Meredith Lamb (+14169386001)**

It’s actually a cab sauv too


**140.** `20:31` **Meredith Lamb (+14169386001)**

So takes waaaay longer to drink


**141.** `20:31` **Meredith Lamb (+14169386001)**

First glass took a long time


**142.** `20:31` **Meredith Lamb (+14169386001)**

Not a light wine


**143.** `20:32` **You**

Oh so you need half as
Much to get twice as drunk


**144.** `20:32` **You**

Lolol


**145.** `20:34` **Meredith Lamb (+14169386001)**

Exactly 💡


**146.** `20:34` **Meredith Lamb (+14169386001)**

It is a more enjoyable drink sometimes too


**147.** `20:35` **Meredith Lamb (+14169386001)**

We will do that next time ;\)


**148.** `20:35` **Meredith Lamb (+14169386001)**

You can try


**149.** `20:36` **Meredith Lamb (+14169386001)**

Just think of all the stories


**150.** `20:38` **You**

Yeahhhh


**151.** `20:38` **You**

Ok here is what is going to happen


**152.** `20:39` **You**

I am going to buy a bottle of tequila and every time you say something inappropriate I am going to take a shot


**153.** `20:39` **Meredith Lamb (+14169386001)**

Haha


**154.** `20:39` **Meredith Lamb (+14169386001)**

Uh oh


**155.** `20:39` **You**

The quality of night you have after that will be directly
Related to how many things
You say\.


**156.** `20:39` **You**

lol


**157.** `20:39` **You**

I am guessing tequila doesnt make it better after a while lol


**158.** `20:40` **Meredith Lamb (+14169386001)**

Never drank tequila and never intend to


**159.** `20:40` **You**

Well unless you want to see the affects of it on me …\.\.


**160.** `20:41` **You**

Naw I have other ways to get you to stop talking


**161.** `20:41` **You**

More fun ways


**162.** `20:41` **You**

I will go there first


**163.** `20:50` **Meredith Lamb (+14169386001)**

Those ways might be better


**164.** `20:51` **Meredith Lamb (+14169386001)**

Just gave Rosie a quick trim again\. Have to do baby cuts bc she gets so stressed


**165.** `20:54` **You**

Just give her some drugs and get her to a groomer maybe?


**166.** `20:55` **Meredith Lamb (+14169386001)**

I will talk to the vet about it\. When I make vet appts soon\. So late


**167.** `20:55` **Meredith Lamb (+14169386001)**

Normally I stay on top of Rosie myself but life lately……


**168.** `20:56` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**169.** `21:01` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28431220/1804\-200\-redpath\-avenue\-toronto\-mount\-pleasant\-east\-mount\-pleasant\-east?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**170.** `21:07` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28419364/117\-roselawn\-avenue\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
Townhouse around the block from me\.


**171.** `21:10` **You**

>
Jesus 5 k for 900 sq ft

*💬 Reply*

**172.** `21:11` **You**

Looked at the other one\.\. you on glass 4
Yet


**173.** `21:11` **You**

I think you need to talk to someone else mer\.\.


**174.** `21:11` **You**

You need to go talk to a financial advisor


**175.** `21:12` **Meredith Lamb (+14169386001)**

lol was giving you a flavour


**176.** `21:12` **Meredith Lamb (+14169386001)**

I’m on glass 2 still


**177.** `21:12` **You**

Srsly talk to a financial advisor 6 of the 8 years you will be eating up almost all he gives
You to survive\.


**178.** `21:13` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28372057/3506\-185\-roehampton\-avenue\-toronto\-mount\-pleasant\-west\-mount\-pleasant\-west?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
This one is 5


**179.** `21:13` **Meredith Lamb (+14169386001)**

I’m not agreeing to anything if I can’t afford the area


**180.** `21:13` **You**

And after that\.\. you will have very
Few choices\.\. I would be obviously willing to go in with you on anything\.


**181.** `21:13` **Meredith Lamb (+14169386001)**

I will have to move


**182.** `21:13` **You**

It isn’t about affording the area


**183.** `21:14` **You**

It is about protecting yourself and by
Yourself them


**184.** `21:14` **Meredith Lamb (+14169386001)**

Well after 6 yrs I move elsewhere but yeah I will be talking affordability to mediator


**185.** `21:15` **You**

Hmmm I think you might have to push for 16


**186.** `21:15` **You**

And you do that with pension and lost years of work


**187.** `21:15` **You**

You almost have to


**188.** `21:15` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28153677/109\-edith\-drive\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
This one is right beside Diana and Aaron


**189.** `21:15` **You**

That won’t impact his right now plans


**190.** `21:16` **You**

But it means he has to commit longer and he should anyways


**191.** `21:16` **Meredith Lamb (+14169386001)**

>
>
It is like 3 min from our house through the park

*💬 Reply*

**192.** `21:16` **You**

>
>
5 \+ \+

*💬 Reply*

**193.** `21:17` **You**

I liked the house


**194.** `21:17` **Meredith Lamb (+14169386001)**

Doesn’t have a finished basement tho


**195.** `21:17` **Meredith Lamb (+14169386001)**

Groan


**196.** `21:17` **You**

Whatever


**197.** `21:17` **Meredith Lamb (+14169386001)**

Ugh


**198.** `21:18` **You**

Storage


**199.** `21:18` **Meredith Lamb (+14169386001)**

That’s what my mom said 😝


**200.** `21:18` **You**

Great minds\.\.


**201.** `21:18` **Meredith Lamb (+14169386001)**

Uh huh


**202.** `21:19` **You**

You watch we will be pees in a pod\.


**203.** `21:19` **Meredith Lamb (+14169386001)**

I wouldn’t mind living close to Diana and Aaron


**204.** `21:19` **Meredith Lamb (+14169386001)**

Well I live close to them now but neighbours I mean


**205.** `21:19` **Meredith Lamb (+14169386001)**

But ugh


**206.** `21:20` **Meredith Lamb (+14169386001)**

The no finished basement


**207.** `21:20` **You**

Omg the awfulness of it all\!\!


**208.** `21:20` **Meredith Lamb (+14169386001)**

And one bathroom


**209.** `21:20` **Meredith Lamb (+14169386001)**

Right now we have 4


**210.** `21:21` **Meredith Lamb (+14169386001)**

But whatever


**211.** `21:21` **Meredith Lamb (+14169386001)**

lol


**212.** `21:22` **You**

Bathrooms could be a problem


**213.** `21:29` **Meredith Lamb (+14169386001)**

Shouldn’t you spend some time with the girls tonight?


**214.** `21:29` **Meredith Lamb (+14169386001)**

Board game?


**215.** `21:32` **You**

they fucking blew up at each other\.\. they don't want to do shit


**216.** `21:32` **You**

J blew up at me


**217.** `21:32` **You**

so no


**218.** `21:32` **You**

Reaction: 😢 from Meredith Lamb
no board games


**219.** `21:33` **Meredith Lamb (+14169386001)**

>
Why?

*💬 Reply*

**220.** `21:33` **You**

she said something along the lines can you just get maddie to calm down so there can be no fighting until you kick us out\.


**221.** `21:34` **You**

I hung up on her


**222.** `21:34` **Meredith Lamb (+14169386001)**

>
Oh yikes, unfair

*💬 Reply*

**223.** `21:34` **You**

We texted after\.\. I told her this is the same shit as always\.\.


**224.** `21:34` **You**

sexc


**225.** `21:35` **You**

sec


**226.** `21:35` **You**

sec maddie coming down going dark lol


**227.** `21:54` **You**

DRAMA


**228.** `21:54` **You**

They were text fighting then Maddie started crying because of the move\.\. she has been holding in her emotions\.\.


**229.** `21:54` **You**

rough


**230.** `21:55` **Meredith Lamb (+14169386001)**

Oh yikes did you give her a hug? You are good at that


**231.** `21:57` **You**

I did\.\. I took responsibility\.\. and told her I was sorry, but that we would figure it out\.  She of course go go do grade 12 in moncton\.  I supported that too\.


**232.** `21:58` **You**

It would suck\.\. but I would support it if it is what she wanted


**233.** `21:58` **Meredith Lamb (+14169386001)**

Yeah the whole mom moving thing is super intense\.


**234.** `21:59` **Meredith Lamb (+14169386001)**

Any kid would feel conflicted in that scenario no matter how great the relationships are with both parents


**235.** `21:59` **You**

that and this actually is the house she grew up in even moreso than grace


**236.** `22:01` **Meredith Lamb (+14169386001)**

Yes for sure\. A lot for a teen to take in\.


**237.** `22:01` **Meredith Lamb (+14169386001)**

So what happens now?


**238.** `22:05` **You**

I ignore it and it goes away


**239.** `22:06` **Meredith Lamb (+14169386001)**

:\( doubt it


**240.** `22:06` **You**

Reaction: 😢 from Meredith Lamb
I ignore it for 6 weeks and they move


**241.** `22:06` **Meredith Lamb (+14169386001)**

What a wild day… happy… drama … sad\.


**242.** `22:07` **You**

focusing on the happy\.\. good memory remember\.\. playing back over again :\)


**243.** `22:07` **Meredith Lamb (+14169386001)**

Do you thinking maddie would move to finish high school?


**244.** `22:07` **You**

no


**245.** `22:07` **Meredith Lamb (+14169386001)**

She just doesn’t want her mom to move away


**246.** `22:08` **Meredith Lamb (+14169386001)**

That is sad


**247.** `22:11` **Meredith Lamb (+14169386001)**

Are you okay?


**248.** `22:12` **You**

I am fine


**249.** `22:12` **You**

really


**250.** `22:12` **You**

I am ok\.\. I just want this done


**251.** `22:12` **Meredith Lamb (+14169386001)**

Yep I hear ya\.


**252.** `22:13` **You**

I am a little more numb to this\.\. this is exactly the same thing that has been happening for year\.\. and the way Jaimie reacted to the earlier fight tonight by lashing out at Maddie\.\. is exactly why I made the decisions to call it a day


**253.** `22:17` **Meredith Lamb (+14169386001)**

Was Jaimie drunk or high tho


**254.** `22:18` **Meredith Lamb (+14169386001)**

But you are being compassionate to maddie?


**255.** `22:21` **You**

No she wasnt


**256.** `22:21` **You**

of course I was


**257.** `22:22` **Meredith Lamb (+14169386001)**

Why go off on maddie then?


**258.** `22:23` **Meredith Lamb (+14169386001)**

\(Or “lash out”\)


**259.** `22:23` **You**

she went off on Maddie\.\. because she thinks Maddie should mind her business\.


**260.** `22:23` **You**

Gracie was about to break the 2\.5k laptop I had recently bought for Jaimie\.\. and J said Maddie should mind her business\.\. I said you should care more that this will be the second comp gracie breaks in 2 monhts\.


**261.** `22:24` **Meredith Lamb (+14169386001)**

Holy crap\. I do not get the breaking shit at all


**262.** `22:25` **You**

I don't either


**263.** `22:25` **You**

it was negligence though


**264.** `22:26` **You**

she left the lap top on and open sitting on a pillow at the edge of her bed


**265.** `22:26` **Meredith Lamb (+14169386001)**

Ohhhhhh


**266.** `22:28` **You**

just stupid shit she does over and over


**267.** `22:29` **Meredith Lamb (+14169386001)**

Does she have her g1


**268.** `22:30` **You**

gracie no


**269.** `22:31` **Meredith Lamb (+14169386001)**

Maybe a good thing lol


**270.** `22:31` **Meredith Lamb (+14169386001)**

Can’t ruin a vehicle


**271.** `22:31` **You**

god I am sitting here thinking how good it would be for you to be sitting across the room from me in the comfy chair having a glass of wine and having this conversation\.


**272.** `22:31` **You**

>
true story

*💬 Reply*

**273.** `22:32` **Meredith Lamb (+14169386001)**

>
I know… this is dragging so bad\.

*💬 Reply*

**274.** `22:32` **You**

lol I mean what I want is still a ways away\.\. but it is nice to think about it\.


**275.** `22:33` **Meredith Lamb (+14169386001)**

>
I have finished 3\. But slowly with lots of water

*💬 Reply*

**276.** `22:33` **Meredith Lamb (+14169386001)**

lol


**277.** `22:33` **You**

HAHAHA


**278.** `22:33` **You**

Oh I am only going to have 2\.\.


**279.** `22:33` **Meredith Lamb (+14169386001)**

Welp


**280.** `22:33` **You**

saying it in the same voice you used mocking my marriage dreams


**281.** `22:34` **Meredith Lamb (+14169386001)**

lol


**282.** `22:34` **Meredith Lamb (+14169386001)**

I’m enjoying better sisters\. Not enjoying your crappy night\. Just chilling\. Soooooo


**283.** `22:34` **Meredith Lamb (+14169386001)**

All my girls are good


**284.** `22:34` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
So 4 it is\.


**285.** `22:35` **Meredith Lamb (+14169386001)**

Then bed for sure


**286.** `22:35` **You**

have at it


**287.** `22:35` **You**

and have fun not working out in morning


**288.** `22:35` **You**

Enjoy that 4th imaginging how hard I am going to crush it with my trainer tomorrow 😝


**289.** `22:37` **Meredith Lamb (+14169386001)**

Well I don’t have to drive Maelle until noon so technically I could workout


**290.** `22:37` **You**

HAHAH


**291.** `22:37` **You**

whenever someone uses technically


**292.** `22:37` **Meredith Lamb (+14169386001)**

The other night was like almost 2 bottles\. Diff story completely\.


**293.** `22:37` **You**

ain't gonna happen


**294.** `22:37` **You**

almost as fun as per se


**295.** `22:37` **Meredith Lamb (+14169386001)**

It was fun I have to say


**296.** `22:37` **Meredith Lamb (+14169386001)**

Next day\- no


**297.** `22:38` **You**

I mean yeah it was super fun


**298.** `22:38` **Meredith Lamb (+14169386001)**

You need to learn to hang up on me\.


**299.** `22:38` **You**

I hate doing that


**300.** `22:38` **Meredith Lamb (+14169386001)**

But honestly I think the stories are done


**301.** `22:38` **You**

and I don't want to


**302.** `22:38` **Meredith Lamb (+14169386001)**

All out there


**303.** `22:38` **You**

>
no they arent

*💬 Reply*

**304.** `22:38` **You**

you said so this afternoon


**305.** `22:38` **You**

gawd


**306.** `22:38` **You**

memory remember


**307.** `22:40` **You**

now you are trying to remember


**308.** `22:40` **Meredith Lamb (+14169386001)**

I mean I think they are really


**309.** `22:40` **Meredith Lamb (+14169386001)**

Just yours left 😇


**310.** `22:42` **You**

mmm no I think you "emphatically" agreed that you now understand what I can handle and what I cannot\.\. therefore what not to discuss\.\. I think you have lots more stories\.\. just ones I will have to use that strategy I mentioned on you earlier if you try to tell me when you are drunk and we are together\.


**311.** `22:43` **You**

I expect it is the details that might sting\.\. but I am just guessing\.\. but you are right I have a lot of stories\.\. most of which I don't think I would tell because again no vaile\.


**312.** `22:43` **You**

value\.


**313.** `22:44` **Meredith Lamb (+14169386001)**

Other than entertainment, fun


**314.** `22:44` **Meredith Lamb (+14169386001)**

I see value in that lol


**315.** `22:45` **Meredith Lamb (+14169386001)**

I don’t get fussed about the past\. Only the present\.


**316.** `22:46` **You**

well I still may be more hesitant to share\.


**317.** `22:46` **Meredith Lamb (+14169386001)**

lol okkkkkk


**318.** `22:47` **Meredith Lamb (+14169386001)**

So when do you think we go on our first trip together\. What year are we talking


**319.** `22:47` **You**

this year\.\. but it might need to be a short time frame plan\.


**320.** `22:47` **Meredith Lamb (+14169386001)**

Conference in Vegas


**321.** `22:47` **You**

what conference?


**322.** `22:48` **Meredith Lamb (+14169386001)**

Can’t remember


**323.** `22:48` **You**

Strategy doesn't get to go to conferences


**324.** `22:48` **You**

lol


**325.** `22:48` **Meredith Lamb (+14169386001)**

Only noticed bc one of the tours was Hoover dam and when we went as teens we suffered thru a Hoover dam tour and my mom loves to remember that\. So I forwarded her the email


**326.** `22:48` **You**

and the only way I can go anywhere is if Maddie is back in Moncton


**327.** `22:48` **Meredith Lamb (+14169386001)**

No I wouldn’t actually go


**328.** `22:49` **Meredith Lamb (+14169386001)**

A conference would be a cover


**329.** `22:49` **Meredith Lamb (+14169386001)**

>
Forgot

*💬 Reply*

**330.** `22:49` **You**

I was thinking so possibly reading week depending on whether or not you have the kids


**331.** `22:49` **You**

that is in November


**332.** `22:49` **Meredith Lamb (+14169386001)**

k


**333.** `22:50` **Meredith Lamb (+14169386001)**

Or maybe maddie eventually meets me and is fine and just comes with one or more of my kids and they have their own room lol


**334.** `22:50` **You**

I mean we could probably do a weekend trip here or there\.\.


**335.** `22:50` **You**

but I think you meant trip trip


**336.** `22:50` **Meredith Lamb (+14169386001)**

Cottage maybe


**337.** `22:50` **Meredith Lamb (+14169386001)**

No I don’t really care where


**338.** `22:50` **Meredith Lamb (+14169386001)**

Just like more than one day


**339.** `22:50` **You**

yeah I think she will be ready to meet you by October\.\. my guess\. or late september


**340.** `22:51` **You**

That will just be tricky to navigate with Jaimie


**341.** `22:51` **Meredith Lamb (+14169386001)**

Are you guys having a parenting plan


**342.** `22:51` **You**

nothing to that extent


**343.** `22:51` **Meredith Lamb (+14169386001)**

That involves intros


**344.** `22:51` **Meredith Lamb (+14169386001)**

Ahh


**345.** `22:51` **You**

it wasn't written in yet


**346.** `22:51` **Meredith Lamb (+14169386001)**

Andrew actually said something to the effect of


**347.** `22:52` **Meredith Lamb (+14169386001)**

“If I ever date someone else …”


**348.** `22:52` **Meredith Lamb (+14169386001)**

He has never said that before


**349.** `22:52` **Meredith Lamb (+14169386001)**

So he is progressing thank gos


**350.** `22:52` **Meredith Lamb (+14169386001)**

God


**351.** `22:52` **You**

speaking of A did he say anything tonight


**352.** `22:52` **Meredith Lamb (+14169386001)**

Nope nadda


**353.** `22:53` **Meredith Lamb (+14169386001)**

He wasn’t home until quite a bit after I got home


**354.** `22:53` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**355.** `22:53` **Meredith Lamb (+14169386001)**

Was there


**356.** `22:53` **Meredith Lamb (+14169386001)**

Beach vball training


**357.** `22:53` **Meredith Lamb (+14169386001)**

Mar has a beach vball tourn tomorrow


**358.** `22:53` **You**

Yeah I know\.\.\. your parents are going


**359.** `22:54` **Meredith Lamb (+14169386001)**

Her best friend in green shorts


**360.** `22:54` **Meredith Lamb (+14169386001)**

Valé


**361.** `22:54` **Meredith Lamb (+14169386001)**

Valé and her mom keep me happy


**362.** `22:55` **Meredith Lamb (+14169386001)**

I had a nap on fri on the couch and instead of making it weird Valé goes “did you know that if you have a short nap you are more productive after\! Boss baby taught me that\!”


**363.** `22:55` **Meredith Lamb (+14169386001)**

lol she makes me laugh


**364.** `22:55` **You**

lol


**365.** `22:55` **Meredith Lamb (+14169386001)**

They woke me up to drive her home


**366.** `22:55` **Meredith Lamb (+14169386001)**

She lives a 5 min walk away LOL


**367.** `22:55` **Meredith Lamb (+14169386001)**

Literally around the corner


**368.** `22:55` **You**

your kids are lucky they have so many friends\.


**369.** `22:56` **You**

makes such a difference


**370.** `22:56` **Meredith Lamb (+14169386001)**

Yeah Marlowe has a ton which is precisely what I told the moms that j hang out with… so glad she has her tribe


**371.** `22:58` **Meredith Lamb (+14169386001)**

I have told Maelle’s friends moms yet\. :p I’m not as close to them


**372.** `22:58` **Meredith Lamb (+14169386001)**

Middle child


**373.** `22:58` **Meredith Lamb (+14169386001)**

Closer to older and younger


**374.** `22:58` **Meredith Lamb (+14169386001)**

\*I haven’t


**375.** `22:59` **Meredith Lamb (+14169386001)**

What time is your workout tomorrow?


**376.** `22:59` **You**

noon


**377.** `22:59` **Meredith Lamb (+14169386001)**

Why so late?


**378.** `22:59` **You**

that is when the trainer set the appointment


**379.** `23:00` **Meredith Lamb (+14169386001)**

So are you going to sleep in?


**380.** `23:00` **You**

sure a bit


**381.** `23:00` **Meredith Lamb (+14169386001)**

I wish I was there 😭


**382.** `23:00` **You**

so do I\.\.


**383.** `23:00` **Meredith Lamb (+14169386001)**

😢


**384.** `23:01` **You**

it sucks\.\. even a couple of nights now and then together would be nice\.\. lol


**385.** `23:02` **Meredith Lamb (+14169386001)**

That’s why you have to meet my parents


**386.** `23:02` **Meredith Lamb (+14169386001)**

lol


**387.** `23:02` **You**

yeah I swear I was ready to today\.


**388.** `23:02` **You**

2 weeks is fine though


**389.** `23:02` **Meredith Lamb (+14169386001)**

Just another option if things “evolve”


**390.** `23:02` **Meredith Lamb (+14169386001)**

2 weeks is good\. I can prep them next weekend


**391.** `23:02` **You**

I hope so\.\. because it isn't that long for me you know


**392.** `23:02` **Meredith Lamb (+14169386001)**

They heard this weekend then next then they will be prepared


**393.** `23:02` **You**

Reaction: 😮 from Meredith Lamb
a little over 1 month UHAUL boxes will be in my yeard


**394.** `23:02` **You**

yard


**395.** `23:03` **Meredith Lamb (+14169386001)**

They are in their 80s so…


**396.** `23:03` **You**

a week or so after that J is gone


**397.** `23:03` **Meredith Lamb (+14169386001)**

For sure?


**398.** `23:03` **You**

>
prep them

*💬 Reply*

**399.** `23:03` **You**

LOL


**400.** `23:03` **You**

how


**401.** `23:03` **Meredith Lamb (+14169386001)**

They just need to talk to me for a few hours


**402.** `23:03` **Meredith Lamb (+14169386001)**

lol


**403.** `23:03` **You**

>
she said she would be gone at least a week before the move in date\.\. could be sooner\.

*💬 Reply*

**404.** `23:04` **You**

>
why don't you share those gpt responses with them

*💬 Reply*

**405.** `23:04` **Meredith Lamb (+14169386001)**

Wow \- no wonder the kids are struggling a little\. It is very very fast


**406.** `23:04` **Meredith Lamb (+14169386001)**

>
They just need talking time\. Lol

*💬 Reply*

**407.** `23:04` **You**

yep\.\. maddie will be going as well\. likely at least until 1st week of auguest


**408.** `23:05` **Meredith Lamb (+14169386001)**

>
My parents are very engaged and ask a lot of questions

*💬 Reply*

**409.** `23:05` **You**

>
ok\.\. not sure what that is code fore\.\. but ok

*💬 Reply*

**410.** `23:05` **You**

they can ask me


**411.** `23:05` **Meredith Lamb (+14169386001)**

>
It will be good for her to test it out

*💬 Reply*

**412.** `23:05` **Meredith Lamb (+14169386001)**

My parents are old and old people just need repetitive talk


**413.** `23:05` **Meredith Lamb (+14169386001)**

lol


**414.** `23:06` **Meredith Lamb (+14169386001)**

It’s annoying but true


**415.** `23:06` **You**

Reaction: ❤️ from Meredith Lamb
>
well you are good at repetitive talk

*💬 Reply*

**416.** `23:06` **You**

so that is a good fit 😇


**417.** `23:06` **You**

"this one time at band camp"


**418.** `23:06` **Meredith Lamb (+14169386001)**

They think this is a rebound so they need constant reassurance as to why it is not


**419.** `23:06` **You**

you should start all new stories with that


**420.** `23:06` **You**

well


**421.** `23:07` **Meredith Lamb (+14169386001)**

I do love that movie


**422.** `23:07` **You**

>
like I said feed them that last gpt response\.\. it knows it isn't a rebound

*💬 Reply*

**423.** `23:07` **Meredith Lamb (+14169386001)**

You know what I keep thinking about tho?


**424.** `23:08` **Meredith Lamb (+14169386001)**

And my mom hasn’t mentioned it


**425.** `23:08` **Meredith Lamb (+14169386001)**

But


**426.** `23:08` **You**

\.\.\.\.\. omg\.\.


**427.** `23:08` **You**

OMG


**428.** `23:08` **You**

Reaction: 👎 from Meredith Lamb
Johnny is Finch\.\. and you are Stiffler's Mom\!\!\!\!\!


**429.** `23:08` **You**

CLASSIC\!\!\!


**430.** `23:08` **Meredith Lamb (+14169386001)**

I always send my parents my reports cards, the kids report cards, my assessments…\.


**431.** `23:09` **Meredith Lamb (+14169386001)**

>
No\. I have a soft spot for Johnny for another reason

*💬 Reply*

**432.** `23:09` **Meredith Lamb (+14169386001)**

>
The last one I sent her you clearly used ai and my mom didn’t know of ai at that point so her response to me\. Let me see if I can screenshot it

*💬 Reply*

**433.** `23:09` **Meredith Lamb (+14169386001)**

One sec


**434.** `23:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**435.** `23:10` **You**

https://open\.spotify\.com/track/27L8sESb3KR79asDUBu8nW?si=aea7293dcd574494


**436.** `23:11` **You**

HAHAHA


**437.** `23:11` **Meredith Lamb (+14169386001)**

lol


**438.** `23:11` **You**

and now she questions that


**439.** `23:11` **You**

hmmmmm


**440.** `23:11` **You**

Scott had some ulterior motive


**441.** `23:11` **Meredith Lamb (+14169386001)**

>
I mean if it wasn’t socially frowned upon I would be stifler’s mom probably\.

*💬 Reply*

**442.** `23:11` **You**

1000%


**443.** `23:12` **You**

no doubt in my mind


**444.** `23:12` **Meredith Lamb (+14169386001)**

I keep thinking about the walk on water comment


**445.** `23:12` **Meredith Lamb (+14169386001)**

Yeah but not just Johnny\. Arian\.


**446.** `23:12` **Meredith Lamb (+14169386001)**

Mac


**447.** `23:12` **Meredith Lamb (+14169386001)**

Max


**448.** `23:12` **You**

>
I am going to keep thinking about this comment for a while

*💬 Reply*

**449.** `23:12` **Meredith Lamb (+14169386001)**

lol


**450.** `23:13` **Meredith Lamb (+14169386001)**

Mac told this kid max that I had the hots for him when all I said was that he is a good looking kid and Chloe should date him


**451.** `23:13` **You**

eesh Mer\.\.\. be careful\.\. it might look good to eat\.\. but I promise\.\. someone catches you\.\.\.\.\.\.\.\.\.\.


**452.** `23:14` **Meredith Lamb (+14169386001)**

Did I tell you that max was super happy that I thought he was good looking? Like wtf


**453.** `23:14` **Meredith Lamb (+14169386001)**

I made one comment


**454.** `23:14` **Meredith Lamb (+14169386001)**

lol


**455.** `23:14` **You**

>
why wouldn't he\.\. hot mom says I am cute\.\. awesome\!\!\!

*💬 Reply*

**456.** `23:14` **You**

score


**457.** `23:14` **Meredith Lamb (+14169386001)**

Anyway I would never


**458.** `23:14` **You**

sure sure\.\.


**459.** `23:15` **You**

I don't have to compete against the past\.\. just youth\!


**460.** `23:15` **You**

lol


**461.** `23:15` **Meredith Lamb (+14169386001)**

Seriously come on


**462.** `23:15` **Meredith Lamb (+14169386001)**

No one could compete with you now\. You weren’t in the picture then


**463.** `23:16` **You**

>
mmmm hmmm\.  heh you should continue being who you are\.\. I know you aren't like that\.\. and there is nothing wrong with thinking anyone is cute honestly\.

*💬 Reply*

**464.** `23:16` **Meredith Lamb (+14169386001)**

I know\. Really


**465.** `23:16` **You**

Reaction: 🙄 from Meredith Lamb
that was a test\!\!\!


**466.** `23:16` **You**

HAH


**467.** `23:16` **You**

j/k


**468.** `23:16` **You**

j/k


**469.** `23:17` **You**

j/k


**470.** `23:17` **You**

cmon


**471.** `23:17` **You**

that was FUNNY


**472.** `23:17` **Meredith Lamb (+14169386001)**

So my mom was asking about family when she all of a sudden realized she might meet you soon


**473.** `23:17` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
It was, as always\. That’s why I love you 😛

*💬 Reply*

**474.** `23:18` **You**

that being said\.\.


**475.** `23:18` **You**

O dpm


**476.** `23:18` **You**

I don't tell my daughter her friends are cute


**477.** `23:18` **You**

nor do I go anywhere near them


**478.** `23:18` **You**

lol


**479.** `23:18` **Meredith Lamb (+14169386001)**

That’s what Andrew said


**480.** `23:18` **Meredith Lamb (+14169386001)**

lol


**481.** `23:18` **Meredith Lamb (+14169386001)**

This was like a year ago


**482.** `23:19` **Meredith Lamb (+14169386001)**

Or more not sure


**483.** `23:19` **You**

oh was he jealous of johnny too


**484.** `23:19` **Meredith Lamb (+14169386001)**

No not Johnny\. Max\.


**485.** `23:19` **You**

hehe more trends\.


**486.** `23:19` **You**

data is fun


**487.** `23:19` **Meredith Lamb (+14169386001)**

lol


**488.** `23:19` **Meredith Lamb (+14169386001)**

>
It really is

*💬 Reply*

**489.** `23:20` **Meredith Lamb (+14169386001)**

Ok so can we turn to my mom topic


**490.** `23:20` **Meredith Lamb (+14169386001)**

So I told about your family


**491.** `23:20` **You**

yes


**492.** `23:20` **Meredith Lamb (+14169386001)**

And your parents\. Rip 😭


**493.** `23:20` **You**

both parents deceased


**494.** `23:20` **You**

half sister


**495.** `23:20` **You**

\*3


**496.** `23:20` **Meredith Lamb (+14169386001)**

My mom is obsessed with ancestry


**497.** `23:21` **Meredith Lamb (+14169386001)**

3?


**498.** `23:21` **Meredith Lamb (+14169386001)**

I thought 2?


**499.** `23:21` **You**

Katie


**500.** `23:21` **You**

and the other 2


**501.** `23:21` **Meredith Lamb (+14169386001)**

Oh


**502.** `23:21` **Meredith Lamb (+14169386001)**

I consider Katie whole


**503.** `23:21` **You**

well so do I


**504.** `23:21` **You**

but still


**505.** `23:21` **Meredith Lamb (+14169386001)**

My sister Rachael is whole


**506.** `23:21` **Meredith Lamb (+14169386001)**

Rachael is adopted but whole


**507.** `23:22` **Meredith Lamb (+14169386001)**

K, whatever


**508.** `23:22` **You**

so did she have any questions about family


**509.** `23:22` **You**

health issues


**510.** `23:22` **You**

lol


**511.** `23:22` **You**

religious affiliations


**512.** `23:22` **You**

political leanings


**513.** `23:22` **You**

am I a virgin?


**514.** `23:22` **You**

born again


**515.** `23:22` **Meredith Lamb (+14169386001)**

No but when I said I as surprised at how small your fam is she said “many families are like that”


**516.** `23:22` **Meredith Lamb (+14169386001)**

I was surprised I didn’t know that


**517.** `23:23` **You**

you just have a massive one


**518.** `23:23` **You**

but yeah lots of small families as generations move forward


**519.** `23:23` **Meredith Lamb (+14169386001)**

So then, I said our family is so big and bad shit crazy it’s a little like weird


**520.** `23:23` **Meredith Lamb (+14169386001)**

She said yeah many cons to a big family


**521.** `23:23` **You**

true


**522.** `23:23` **Meredith Lamb (+14169386001)**

Then went on to talk about her sisters like


**523.** `23:23` **Meredith Lamb (+14169386001)**

lol


**524.** `23:24` **Meredith Lamb (+14169386001)**

I was surprised


**525.** `23:24` **Meredith Lamb (+14169386001)**

My mom and dad both have 3 sisters


**526.** `23:24` **You**

lot of estrogen


**527.** `23:24` **Meredith Lamb (+14169386001)**

Yeah\!


**528.** `23:24` **Meredith Lamb (+14169386001)**

And the majority of cousins are girls


**529.** `23:24` **Meredith Lamb (+14169386001)**

So odd


**530.** `23:24` **Meredith Lamb (+14169386001)**

We are a very girl family


**531.** `23:24` **You**

same


**532.** `23:24` **You**

6 girls


**533.** `23:24` **Meredith Lamb (+14169386001)**

I do have nephews tho


**534.** `23:24` **You**

between katie and i


**535.** `23:25` **Meredith Lamb (+14169386001)**

You mean 5


**536.** `23:25` **You**

we are the end of the line though


**537.** `23:25` **You**

yeah sorry I never told you about my other daughter\.


**538.** `23:25` **You**

oops


**539.** `23:25` **Meredith Lamb (+14169386001)**

lol


**540.** `23:25` **You**

slipped my mind


**541.** `23:25` **You**

she's half french


**542.** `23:25` **Meredith Lamb (+14169386001)**

I do have 4 nephews and 3 great nephews so the boys are coming in strong lately


**543.** `23:26` **You**

"great" nephews


**544.** `23:26` **You**

hee hee


**545.** `23:26` **You**

I am so far away from that


**546.** `23:26` **Meredith Lamb (+14169386001)**

Yeah my sis is a grandma


**547.** `23:26` **Meredith Lamb (+14169386001)**

I’m a great aunt


**548.** `23:26` **You**

crazy


**549.** `23:26` **Meredith Lamb (+14169386001)**

My sister and I had this one great aunt that we loved and that is me now 😇


**550.** `23:27` **You**

I am not surprised\.\. you do the best you can at everything


**551.** `23:28` **Meredith Lamb (+14169386001)**

So when I first started working for you


**552.** `23:28` **Meredith Lamb (+14169386001)**

The first wed I worked from home


**553.** `23:28` **Meredith Lamb (+14169386001)**

I didn’t work


**554.** `23:28` **Meredith Lamb (+14169386001)**

I made cookie for my great nephews 1st birthday


**555.** `23:29` **You**

lol shame on you\!\!


**556.** `23:30` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**557.** `23:31` **Meredith Lamb (+14169386001)**

That’s what I did all day lol


**558.** `23:31` **You**

lol


**559.** `23:31` **Meredith Lamb (+14169386001)**

My niece was happy


**560.** `23:31` **You**

Reaction: 😂 from Meredith Lamb
should have gave you a 3


**561.** `23:32` **Meredith Lamb (+14169386001)**

https://www\.flickr\.com/gp/74517971@N00/YADe1p3BHj


**562.** `23:33` **Meredith Lamb (+14169386001)**

I couldn’t let my niece down


**563.** `23:33` **You**

lol i was just going back in my emails to when you started\.\.


**564.** `23:33` **Meredith Lamb (+14169386001)**

Haha


**565.** `23:33` **Meredith Lamb (+14169386001)**

Sorry it might not have been the first we’d


**566.** `23:33` **Meredith Lamb (+14169386001)**

The wed before the party


**567.** `23:34` **Meredith Lamb (+14169386001)**

I think the party was June 22, 2022


**568.** `23:34` **You**

Wine??


**569.** `23:34` **You**

5


**570.** `23:34` **You**

I love you btw


**571.** `23:35` **You**

you were so formal at the start\. lol


**572.** `23:35` **You**

very polite


**573.** `23:37` **Meredith Lamb (+14169386001)**

I am on 5 and last of the bottle :\( I’m a loser and can’t keep to my word


**574.** `23:37` **You**

>
I LOVE YOU\!\!\!\!

*💬 Reply*

**575.** `23:37` **You**

I knew you would do 5


**576.** `23:37` **Meredith Lamb (+14169386001)**

Andrew is talking to me about volleyball


**577.** `23:37` **Meredith Lamb (+14169386001)**

Omg


**578.** `23:37` **You**

LOL


**579.** `23:37` **You**

what does he think you are doing when you are talking to me


**580.** `23:38` **Meredith Lamb (+14169386001)**

Marlowe is ranked in beach volleyball 7 out of 100


**581.** `23:38` **Meredith Lamb (+14169386001)**

No idea what he thinks lol


**582.** `23:38` **You**

nice\.\. Andrew is thinking Team Canada?


**583.** `23:38` **Meredith Lamb (+14169386001)**

I’m always on my phone


**584.** `23:38` **Meredith Lamb (+14169386001)**

Andrew is thinking scholarship probably but it is dumb


**585.** `23:39` **Meredith Lamb (+14169386001)**

He’s done


**586.** `23:39` **Meredith Lamb (+14169386001)**

Man


**587.** `23:39` **You**

>
I actually think you tried to get off this chat earlier\.\. maybe then you might have stopped\.\.

*💬 Reply*

**588.** `23:39` **You**

you pulled a me\.\. LOL


**589.** `23:39` **Meredith Lamb (+14169386001)**

He’s in a good mood for some reason\. Everyone is\. Weird\. Weather?


**590.** `23:39` **You**

well don't ask questions then\.\. I know\.\. hehehe


**591.** `23:39` **Meredith Lamb (+14169386001)**

>
I did not try to get off\. I would talk to you all night, but I thought you should spend some time with your girls\.

*💬 Reply*

**592.** `23:40` **You**

not that


**593.** `23:40` **Meredith Lamb (+14169386001)**

I was trying to be nice


**594.** `23:40` **You**

I was thinking the workout


**595.** `23:40` **You**

whenever I wanted to get off the phone when I was at Dalhousie


**596.** `23:40` **You**

I used to ask Jaimie what time she worked in the morning


**597.** `23:40` **You**

used to drive her fucking crazye


**598.** `23:40` **You**

So\.\.\.\. what time do you work tomorrow\.


**599.** `23:40` **Meredith Lamb (+14169386001)**

lol y?


**600.** `23:40` **You**

Code\.\.


**601.** `23:41` **You**

I want to get off the phone now\.


**602.** `23:41` **You**

we have talked too long


**603.** `23:41` **Meredith Lamb (+14169386001)**

Ohhhhhh


**604.** `23:41` **Meredith Lamb (+14169386001)**

lol


**605.** `23:41` **You**

and there isn't anything that interesting\.


**606.** `23:41` **You**

so when you asked when I worked out tomorrow\.


**607.** `23:41` **You**

I actually laughed here\.


**608.** `23:41` **Meredith Lamb (+14169386001)**

Oh no I was just genuinely curious


**609.** `23:41` **Meredith Lamb (+14169386001)**

I mean, I will get off whenever you want to though honestly


**610.** `23:41` **You**

I know\.\. I figured\.\. was just initial reaction at having it done to me\.


**611.** `23:42` **Meredith Lamb (+14169386001)**

You don’t have to stay on with me till 3 AM like the other night like oh my God I can’t believe you did that sober


**612.** `23:42` **Meredith Lamb (+14169386001)**

I would’ve passed out


**613.** `23:43` **You**

I was highly engaged


**614.** `23:43` **You**

Very in the moment\.


**615.** `23:43` **Meredith Lamb (+14169386001)**

lol


**616.** `23:44` **Meredith Lamb (+14169386001)**

But like a big waste of time right


**617.** `23:44` **You**

no


**618.** `23:44` **You**

we resolved a bunch of shit I felt\.


**619.** `23:44` **Meredith Lamb (+14169386001)**

🧐


**620.** `23:44` **You**

remember what I said


**621.** `23:44` **Meredith Lamb (+14169386001)**

Did we?


**622.** `23:44` **You**

I would rather be uncomfortable and know everything about you then be comfortable and not\.  Knowing all of you is the most important thing\.\.


**623.** `23:45` **You**

but not some details


**624.** `23:45` **You**

lol


**625.** `23:45` **You**

Even the meeting Chris thing I was good with\.


**626.** `23:45` **You**

you were the one that freaked out after you suggested it


**627.** `23:45` **Meredith Lamb (+14169386001)**

I wish I knew the “details” ah well


**628.** `23:45` **Meredith Lamb (+14169386001)**

lol


**629.** `23:46` **You**

>
no you know the details

*💬 Reply*

**630.** `23:46` **You**

I don't need to know them


**631.** `23:46` **Meredith Lamb (+14169386001)**

Well, if we stay together, you probably might have to meet him eventually


**632.** `23:46` **Meredith Lamb (+14169386001)**

Andrew has never met him


**633.** `23:46` **Meredith Lamb (+14169386001)**

I could never intro Chris to Andrew


**634.** `23:46` **You**

like


**635.** `23:46` **Meredith Lamb (+14169386001)**

Chris is a trouble maker


**636.** `23:46` **You**

ok


**637.** `23:46` **Meredith Lamb (+14169386001)**

He would say something


**638.** `23:47` **You**

How is Andrew so threatened by Chris when he didn't know


**639.** `23:47` **You**

>
what would he say

*💬 Reply*

**640.** `23:47` **Meredith Lamb (+14169386001)**

Andrew isn’t threatened by Chris bc he doesn’t know and I have never talked about him


**641.** `23:47` **Meredith Lamb (+14169386001)**

>
He’s so gay\. He’d make some comment\.

*💬 Reply*

**642.** `23:47` **Meredith Lamb (+14169386001)**

Some sarcastic comment


**643.** `23:47` **You**

you said Andrew didn't like him or when you talked about Chris and/or Jeremy


**644.** `23:48` **Meredith Lamb (+14169386001)**

No


**645.** `23:48` **You**

this goes back a ways btw


**646.** `23:48` **Meredith Lamb (+14169386001)**

Andrew is fine with Chris


**647.** `23:48` **Meredith Lamb (+14169386001)**

Jeremy and Gavin had issues with Chris


**648.** `23:48` **Meredith Lamb (+14169386001)**

Andrew knows shit about Chris


**649.** `23:48` **Meredith Lamb (+14169386001)**

Never told him


**650.** `23:49` **Meredith Lamb (+14169386001)**

Also


**651.** `23:49` **Meredith Lamb (+14169386001)**

Chris’ comment about us hooking up was pretty innocent and on text only


**652.** `23:49` **Meredith Lamb (+14169386001)**

Like it wasn’t real life


**653.** `23:50` **You**

you don't need to go back to that lol\.\. you beat that hard last time\.


**654.** `23:51` **Meredith Lamb (+14169386001)**

I’m actually trying to find it to prove it is not that deep


**655.** `23:51` **You**

>
I like sarcasm\.\. I think we might get along then\.  I see it more as a fun challenge\.  As long as he has the right attitude

*💬 Reply*

**656.** `23:51` **You**

>
here is the thing\.\. it isn't what he said Mer\.

*💬 Reply*

**657.** `23:51` **You**

you don't get it


**658.** `23:52` **You**

You are not an overly emotional person


**659.** `23:52` **You**

not outwardly


**660.** `23:52` **You**

but you looked hurt and sad and wistful talking about him, and the fun you guys had\. It doesn't matter what he wrote\.\. it matters what you felt\.  That was what I saw, that is what was threatening\.


**661.** `23:55` **Meredith Lamb (+14169386001)**

k well I think the only reason I reached out in March was to tell him I was getting separated and to tell him about you and then he never responded back\. That’s the first time he’s never responded back\.


**662.** `23:55` **You**

shit nothing in signal\.\. I know what you said to me was in messenger and I don't have those DAMNIT lol


**663.** `23:55` **Meredith Lamb (+14169386001)**

Huh?


**664.** `23:56` **You**

I was looking for a comment you made\.\. cannot find it\.\. must have been pre signal\.\. no matter\.


**665.** `23:56` **You**

sorry keep going


**666.** `23:56` **Meredith Lamb (+14169386001)**

A comment I made?


**667.** `23:56` **Meredith Lamb (+14169386001)**

you must remember it?


**668.** `23:56` **You**

I do\.\. but you said I was wrong\.


**669.** `23:56` **Meredith Lamb (+14169386001)**

I trust your memory


**670.** `23:56` **You**

Actually you know what


**671.** `23:57` **You**

you never wrote it


**672.** `23:57` **Meredith Lamb (+14169386001)**

Wrong about what?


**673.** `23:57` **You**

you said it


**674.** `23:57` **Meredith Lamb (+14169386001)**

I’m confused


**675.** `23:57` **You**

That night at the cottage\.\. when you told me the stories about you and chris


**676.** `23:57` **You**

you started by saying


**677.** `23:57` **You**

Andrew would hate this


**678.** `23:57` **You**

he never liked it when I talked about Chris or Jeremy\.


**679.** `23:57` **Meredith Lamb (+14169386001)**

>
True true

*💬 Reply*

**680.** `23:57` **You**

then you started talking to me about them\.


**681.** `23:58` **Meredith Lamb (+14169386001)**

>
Awwwwww poor Scott 😢

*💬 Reply*

**682.** `23:58` **Meredith Lamb (+14169386001)**

I’m sorry


**683.** `23:58` **You**

yep all that mental angst


**684.** `23:58` **Meredith Lamb (+14169386001)**

Honestly I am\. I’m an idiot


**685.** `23:58` **You**

you need to stop apologizing\.\. I don't want you to apologize


**686.** `23:58` **You**

I don't care if you do it again\.


**687.** `23:58` **You**

I love you period


**688.** `23:59` **Meredith Lamb (+14169386001)**

I just like to talk about shit so it annoys me when I “can’t”


**689.** `23:59` **You**

I know


**690.** `23:59` **You**

shit that reminds me


**691.** `23:59` **Meredith Lamb (+14169386001)**

And my mom never liked all the gay guys at work so she never liked Chris cause he was gay and Michael boy because he was gay and a drag queen and all the gay guys that used to hang out with her at work\. She was always concerned about all the gay guys I hung out with that work\. There were like six of them\.


**692.** `23:59` **Meredith Lamb (+14169386001)**

So I couldn’t talk to my mom about shit


