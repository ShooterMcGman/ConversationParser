# Daily Conversation: 2025-05-27 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-27 |
| **Day** | Tuesday |
| **Week** | 7 |
| **Messages** | 375 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-27T04:20 - 2025-05-27T22:20 |

## 📝 Daily Summary

This day contains **375 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:20` **You**

Mmm another sun shiny day incoming… meh\.  Bit of a scrap last night\.\. j seems to be paranoid that people at work know about us even though I assured her no one did\.  Anyways not\. Super fun night\.\. if that becomes the norm I will need to leave for a bit I think we will see how it goes\.


**002.** `04:20` **You**

Well off to gym hope you slept well since you got to bed early


**003.** `06:42` **You**

Reaction: ❤️ from Meredith Lamb
Getting there will need to put together a timeline eventually\.

*📎 1 attachment(s)*

**004.** `06:51` **You**

Heading into sauna shower then going to my morning spot to do some thinking see you when I see you have a good morning\.❤️❤️


**005.** `07:01` **Meredith Lamb (+14169386001)**

I don’t think I should go into work\. My throat is worse\. Ugh…


**006.** `07:04` **Meredith Lamb (+14169386001)**

>
It is honestly crazy how fast you have done this 😍… timeline for ??

*💬 Reply*

**007.** `07:05` **Meredith Lamb (+14169386001)**

>
I get her paranoia\. Walking into work felt weirder for me yesterday\. Walking down to Haris’ office felt weirder\. Is what it is\.

*💬 Reply*

**008.** `07:13` **Meredith Lamb (+14169386001)**

>
Scrap that\. I’m going to go in\. It isn’t too bad\. It’s weird\.

*💬 Reply*

**009.** `07:13` **Meredith Lamb (+14169386001)**

I’m using that word a lot


**010.** `07:13` **Meredith Lamb (+14169386001)**

Need coffee lol


**011.** `07:13` **You**

>
Ur call

*💬 Reply*

**012.** `07:14` **You**

Just going to get dressed get a smooth and go see the birdies\.  Cheers\.


**013.** `07:14` **You**

>
Yeah I know but she was fucking pissed at me last night\.

*💬 Reply*

**014.** `07:15` **You**

Anyways it is fine she is in and out\. I told her to quit now and I would cover her salary\.


**015.** `07:15` **You**

But she won’t


**016.** `07:15` **You**

Anyhow time for birdies and peace and happier thoughts\.\. or at least I will try for em\.  See you later\.


**017.** `07:16` **Meredith Lamb (+14169386001)**

Sorry I won’t be there … just got out of shower so running a bit behind


**018.** `07:17` **You**

I didn’t expect you to be all good\.


**019.** `09:16` **You**

Going off teams


**020.** `09:16` **You**

Yeah I feel like I need to, I feel you need it to\.  I think it makes it more real for both of us when someone else knows


**021.** `09:16` **You**

Which I think is likely more reassuring as well


**022.** `09:17` **Meredith Lamb (+14169386001)**

Chagpt said telling a trust work friend is good and ChatGPT knows everything sooooooo……


**023.** `09:17` **You**

Yeah sure not biased at all


**024.** `09:17` **Meredith Lamb (+14169386001)**

lol


**025.** `09:17` **You**

Ask it to run a pro cons and risk bs reward analysis\.\. and then assess the overall upside vs downside


**026.** `09:18` **Meredith Lamb (+14169386001)**

But it doesn’t even know Jim


**027.** `09:18` **Meredith Lamb (+14169386001)**

lol


**028.** `09:18` **You**

Characterize him an old and trusted friend\.\. like a mentor or big brother


**029.** `09:20` **Meredith Lamb (+14169386001)**

Pros
1\. Emotional support and grounding perspective
A trusted colleague or mentor can offer wisdom, support, and a grounded outside view—especially helpful when you’re navigating the emotional complexity of your relationship and work dynamics\.
2\. Trusted sounding board
They may help you think through difficult decisions, like future disclosures, boundary\-setting, or how to protect your reputations\.
3\. Reduced sense of secrecy
If you’ve been carrying the relationship quietly, telling one trusted person can reduce the emotional burden of secrecy\.
4\. Safe test case
This can be a way to see how disclosure feels and gauge how someone outside the relationship reacts—before considering broader transparency, if ever\.
⸻
Cons
1\. Risk of unintentional spread
Even trusted colleagues can slip up or feel conflicted about keeping the information private, especially if they feel loyalty to others or organizational policies\.
2\. Change in perception
Even with good intentions, your mentor might view either of you differently after knowing—perhaps more protectively, but potentially more critically\.
3\. Possible ethical discomfort
If the mentor is senior or has formal obligations \(e\.g\., part of leadership or HR\-adjacent\), they may feel they should report it—even if they don’t want to\.
4\. Impact on work dynamics
Once someone knows, the way they interact with you \(or Scott\) at work may shift—more cautious, more involved, or more concerned\.
⸻
Considerations Before Telling
- Is this person outside your reporting lines?
- Has this person proven discretion in sensitive matters?
- Are you and Scott aligned on sharing? \(You’d want mutual agreement\.\)
- What’s your purpose in telling them—support, guidance, relief?


**030.** `09:21` **You**

lol I don’t feel like I am worried about those cons


**031.** `09:21` **You**

He is pretty mature and grounded he would never joke about it or make light


**032.** `09:22` **Meredith Lamb (+14169386001)**

Yeah exactly\. He is literally the only person here I would ever consider telling \(after you lol\)


**033.** `09:23` **You**

Agreed but I will need to reiterate this cannot get around it would have catastrophic affects on me\.


**034.** `09:23` **You**

I will see how he feels before I decide


**035.** `09:24` **Meredith Lamb (+14169386001)**

We can wait until I’m officially not reporting to you


**036.** `09:24` **Meredith Lamb (+14169386001)**

I’m okay with that


**037.** `09:26` **You**

I feel like this is going to happen today\.  I kind of need someone\.  With the stuff at home it makes everything else worse even more so than it already was\.  But I am trying to keep it all to myself\.


**038.** `09:33` **Meredith Lamb (+14169386001)**

Yeah it sounds pretty bad at home\. :\(


**039.** `09:34` **Meredith Lamb (+14169386001)**

I get all of her anger and feelings tho


**040.** `09:34` **You**

Yep not good\.\. and no escape\.


**041.** `09:35` **Meredith Lamb (+14169386001)**

I don’t really think anyone understands the depth of our relationship… even my family and friends seem to think it is this rebound fling


**042.** `09:36` **Meredith Lamb (+14169386001)**

Jaimie may think that and hence the “don’t see her anymore”


**043.** `09:36` **Meredith Lamb (+14169386001)**

If ppl understood things they wouldn’t bother suggesting that


**044.** `09:36` **You**

No I could never explain to her how I really feel\.\. if I did it would completely break her and I don’t want that\.


**045.** `09:36` **Meredith Lamb (+14169386001)**

I know\.


**046.** `09:37` **Meredith Lamb (+14169386001)**

You have a strong protection instinct which is admirable and good


**047.** `09:38` **Meredith Lamb (+14169386001)**

I likely won’t take that approach with Andrew but again, different situations


**048.** `09:38` **You**

Yeah I get it\.\. it won’t matter when she eventually finds out our lines of communication will pretty
Much be zero until or if she decides to get over it\.


**049.** `09:41` **Meredith Lamb (+14169386001)**

I’m sure she will move on to a new phase eventually but it may not be full acceptance but I think the anger will dull


**050.** `09:41` **Meredith Lamb (+14169386001)**

I stayed in the anger phase with Andrew for a good couple months


**051.** `09:42` **You**

Well she is a bit different


**052.** `09:42` **Meredith Lamb (+14169386001)**

I got therapy tho


**053.** `09:42` **You**

She can hold on to shit forever


**054.** `09:42` **Meredith Lamb (+14169386001)**

That helped diffuse some of my anger I think


**055.** `09:42` **You**

So we will see


**056.** `09:42` **You**

Perhaps


**057.** `09:42` **Meredith Lamb (+14169386001)**

How will you be if she stays super angry forever?


**058.** `09:44` **You**

I will live with it\.


**059.** `09:46` **Meredith Lamb (+14169386001)**

As long as it doesn’t mess with your head too much\. You aren’t a horrible person for this\. I mean we probably could have moved a bit slower but the reality is that we didn’t but I don’t think we are horrible people\.


**060.** `09:48` **You**

I don’t think I am or you are\.\. again this happened it wasn’t planned and it is unique imho\.  It won’t mess with my head\.\. I want to be able to have my kids engage with you and your but it might just end up being maddie\.\.  not sure\.


**061.** `09:50` **Meredith Lamb (+14169386001)**

Just give it time\. I think we both see this being years so it is hard to predict how things will be years later…


**062.** `09:52` **You**

Meaning we see this lasting years\.\. yeah I don’t think about that because I don’t want to think about a potential end\.


**063.** `09:52` **You**

Just how my mind likes to work


**064.** `09:54` **Meredith Lamb (+14169386001)**

>
I’m not thinking about an end…\. But we will both be old and die eventually lol not getting any younger

*💬 Reply*

**065.** `09:57` **You**

You are so morbid…\. I told you the other night I want more than 25\.\.  I just don’t think you can deal with my… I don’t know intensity commitment certainty\.\. we are built differently for sure\.


**066.** `09:58` **Meredith Lamb (+14169386001)**

lol I am not morbid\!


**067.** `10:00` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
It we had 25 years together, I would feel very lucky\. Honestly I feel really lucky to be with you despite all the mess around us


**068.** `10:07` **You**

I am really looking forward to some sense of normalcy\.\. even just a bit\.\.


**069.** `12:15` **You**

Do you want to come down to 4105


**070.** `12:15` **You**

If you are available


**071.** `13:32` **You**

I feel very much better


**072.** `13:32` **You**

I hope you do too\.


**073.** `13:37` **Meredith Lamb (+14169386001)**

Uh yeah, super awkward but feel better\. I felt super awkward when I told him of my separation so I knew this would feel similar


**074.** `13:38` **Meredith Lamb (+14169386001)**

I didn’t like talking to him this morning and him not knowing\. Was starting to feel deceptive


**075.** `13:38` **You**

I didn’t find the conversation at lunch awkward


**076.** `13:38` **You**

Yeah I get it


**077.** `13:39` **You**

He was happy almost immediately


**078.** `13:39` **Meredith Lamb (+14169386001)**

>
I came in blind tho lol not knowing what you had said\!

*💬 Reply*

**079.** `13:39` **You**

Nothing bad all good


**080.** `13:39` **You**

You are amazing what can I say that is bad


**081.** `13:39` **Meredith Lamb (+14169386001)**

Did he not know who was going to be walking in??


**082.** `13:49` **You**

No


**083.** `13:49` **You**

Not a clue


**084.** `13:49` **You**

I have 10 mins if you have any questions before my next meeting


**085.** `14:37` **You**

High point noon low point incoming lol\.


**086.** `14:40` **Meredith Lamb (+14169386001)**

?


**087.** `14:47` **You**

End of day low point see you in several weeks lol


**088.** `14:48` **You**

Think I am going to leave early getting a bit antsy\.


**089.** `14:50` **Meredith Lamb (+14169386001)**

We won’t see each other next week?


**090.** `14:50` **Meredith Lamb (+14169386001)**

Remind me


**091.** `14:50` **Meredith Lamb (+14169386001)**

I have to leave right at 4 today


**092.** `14:50` **You**

I am on vacation next week


**093.** `14:52` **Meredith Lamb (+14169386001)**

Oh right\.


**094.** `14:52` **You**

It’s fine you go nothing we can do about it anyways


**095.** `15:01` **Meredith Lamb (+14169386001)**

>
Didn’t really need this reminder… 😔

*💬 Reply*

**096.** `15:02` **You**

Sorry I kind of lost track the realized \.\. fucked


**097.** `15:02` **You**

I am leaving at 4 too\.\. don’t feel like being here\.
Will do work from home later


**098.** `15:04` **You**

This is why I told you I might need to shut down the other night\.\. will see how it goes\.\. might still have to will see\.


**099.** `15:06` **Meredith Lamb (+14169386001)**

Please just wait and see\.


**100.** `15:36` **You**

With what is going on at home right now I don’t know that I have much of a choice regardless\.\. just trying to manage expectations\.\. but if I go offline and don’t come back on you will know why at least\.


**101.** `15:37` **Meredith Lamb (+14169386001)**

What the heck??


**102.** `15:37` **Meredith Lamb (+14169386001)**

Literally in a meeting


**103.** `15:37` **You**

Pocket dial


**104.** `15:37` **Meredith Lamb (+14169386001)**

Omg


**105.** `15:37` **You**

So am I


**106.** `15:37` **You**

I don’t know why it did that


**107.** `15:37` **Meredith Lamb (+14169386001)**

TWICE


**108.** `15:37` **You**

I am deleting this app right now


**109.** `15:38` **Meredith Lamb (+14169386001)**

What no


**110.** `15:39` **You**

We’ll see\.\. refer to earlier comment


**111.** `15:39` **You**

Leaving at 4 bet I beat you out of here


**112.** `15:39` **You**

So agitated


**113.** `15:55` **Meredith Lamb (+14169386001)**

My nerves are feeling a little tense also which is surprising\. Not sure if it is the Jim thing or the Jaimie telling you not to see me anymore thing


**114.** `15:56` **You**

Why is that surprising


**115.** `15:57` **Meredith Lamb (+14169386001)**

I thought I’d feel better telling Jim


**116.** `15:57` **You**

Packing up to leave now \.\. too much


**117.** `15:58` **Meredith Lamb (+14169386001)**

Oh and Andrew just asked me if I covered the ring on purpose


**118.** `15:58` **You**

Perfect


**119.** `15:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**120.** `15:59` **You**

Reaction: 😂 from Meredith Lamb
That was a weak ass ask


**121.** `15:59` **You**

Do you want me to wait for you


**122.** `15:59` **You**

Downstairs


**123.** `16:00` **You**

Reaction: 😢 from Meredith Lamb
I was going to run away without seeing you because\.\. hurts but if you want me to stay I can


**124.** `16:02` **You**

Frck shoulx have left


**125.** `16:03` **You**

Cya


**126.** `16:04` **Meredith Lamb (+14169386001)**

Cya :p


**127.** `16:21` **You**

>
It is the Jaimie thing and the next few weeks and now the ring camera nothing to worry about on your end

*💬 Reply*

**128.** `16:31` **You**

You just need to focus on what is in front of you\.


**129.** `16:31` **Meredith Lamb (+14169386001)**

After I left did Jim say if he saw this coming?


**130.** `16:31` **You**

I need to do something else


**131.** `16:31` **You**

No


**132.** `16:31` **You**

But I essentially told him I was in love with you


**133.** `16:32` **You**

He didn’t bat an eye


**134.** `16:32` **You**

Totally engaged\.\. completely believed


**135.** `16:33` **You**

Sorry if you didn’t want me to do that


**136.** `16:33` **Meredith Lamb (+14169386001)**

I’m cool with that\. Just totally curious what he thought\. I will ask him lol


**137.** `16:34` **Meredith Lamb (+14169386001)**

You didn’t tell Jaimie that tho


**138.** `16:34` **You**

Kk


**139.** `16:34` **You**

No


**140.** `16:34` **You**

Mike knows


**141.** `16:34` **You**

Katie knows


**142.** `16:35` **You**

Jon knows


**143.** `16:38` **Meredith Lamb (+14169386001)**

Sorry just at my appt


**144.** `16:41` **You**

I know it’s fine


**145.** `16:51` **Meredith Lamb (+14169386001)**

I think I’m having ONE glass of wine tonight to calm my nerves lol


**146.** `16:52` **You**

Do what you need to\.  You are leaving early tomorrow right


**147.** `16:53` **Meredith Lamb (+14169386001)**

I think so yeah\. Another get up early


**148.** `16:54` **You**

Kk well just do your thing and go to bed


**149.** `16:54` **You**

You got vball wine bed


**150.** `16:55` **Meredith Lamb (+14169386001)**

Yeehaw


**151.** `16:55` **Meredith Lamb (+14169386001)**

I have therapy tomorrow\. Should be interest


**152.** `16:55` **Meredith Lamb (+14169386001)**

Interesting


**153.** `16:55` **Meredith Lamb (+14169386001)**

She was on vacay last week


**154.** `16:56` **You**

I am not going to bug you tonight so you should have a quiet night no stress\. Hope the therapy goes well\.  I still need to find one might look tonight\.


**155.** `16:56` **Meredith Lamb (+14169386001)**

You do not bug me\. Stop with that


**156.** `16:57` **You**

Yeah I do I know what kind of mood I will be in so staying offline


**157.** `16:57` **Meredith Lamb (+14169386001)**

Accident


**158.** `16:58` **Meredith Lamb (+14169386001)**

>
Things might ease off …\. Just give it some time\.

*💬 Reply*

**159.** `16:59` **You**

Regardless I hope you have a good night


**160.** `17:13` **You**



**161.** `17:13` **Meredith Lamb (+14169386001)**

🤔


**162.** `15:34` **Meredith Lamb (+14169386001)**

What did you delete?


**163.** `17:58` **You**

It was nothing disregard\.


**164.** `18:35` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
From Jim: Well I have to be honest\. I did not suspect anything between you too\. So no I did not see that coming\. lol\. Having said that I am happy for both of you\. I know you both have been going through some tough relationships and you both deserve to be happy\. I am flattered you both wanted to tell me and look forward to the day when we can hang out as couples\. That’s of course if you’re ok at hanging out with a couple of old folks\. 😂


**165.** `18:39` **You**

Jim is the best


**166.** `18:45` **Meredith Lamb (+14169386001)**

Omg get this


**167.** `18:45` **Meredith Lamb (+14169386001)**

lol\. Well we know he gets a bit anxious over things\. It was funny when I got back to my desk\. Carolyn sent me a chat asking me if Scott was meeting with me to talk about your role\. lol\.


**168.** `18:45` **You**

He told me that


**169.** `18:45` **Meredith Lamb (+14169386001)**

Carolyn was calendar stalking you


**170.** `18:45` **You**

Came in to see me


**171.** `18:45` **Meredith Lamb (+14169386001)**

Omg


**172.** `18:54` **You**

>
she was trying to book a time at 1pm for a meeting re: the rollover forecast and TRC calcs\.

*💬 Reply*

**173.** `18:54` **You**

she would have seen me double book my lunch


**174.** `18:55` **You**

still it is very carolyn


**175.** `18:56` **Meredith Lamb (+14169386001)**

Ahhh I see


**176.** `18:56` **Meredith Lamb (+14169386001)**

That is pretty funny


**177.** `19:09` **Meredith Lamb (+14169386001)**

I told my mom what you did to Jim today\. She enjoyed that\. Lol she’s heard a lot about Jim


**178.** `19:14` **You**

Just got off with Cara Lynn


**179.** `19:14` **Meredith Lamb (+14169386001)**

Just catching up?


**180.** `19:20` **You**

I mean she likes me\.\.


**181.** `19:20` **You**

We connected when she was the boss\.\.


**182.** `19:21` **Meredith Lamb (+14169386001)**

Everyone likes you\.


**183.** `19:21` **You**

“Connected” even


**184.** `19:21` **You**

😜


**185.** `19:21` **You**

It can get interesting with bosses yah know


**186.** `19:22` **Meredith Lamb (+14169386001)**

I wouldn’t know anything about that\.


**187.** `19:22` **You**

Well not about me and Cara we were discreet unlike others…\.


**188.** `19:24` **Meredith Lamb (+14169386001)**

Hey, Jim had NO idea\. That is the definition of discreet\!


**189.** `19:24` **You**

He was just saying that to be nice to you


**190.** `19:24` **You**

I was talking to her about the eval mgr position\.


**191.** `19:25` **You**

I think sophear bent will likely get
It\.\. she is a high performer looking for an opportunity\.\. and has been trying to get back in dsm a while


**192.** `19:25` **You**

Net\.


**193.** `19:28` **Meredith Lamb (+14169386001)**

>
Really? You think he suspected?

*💬 Reply*

**194.** `19:28` **You**

no fucking with you


**195.** `19:29` **Meredith Lamb (+14169386001)**

Oh


**196.** `19:29` **Meredith Lamb (+14169386001)**

Geez


**197.** `19:29` **You**

ez


**198.** `19:29` **You**

:P


**199.** `19:29` **Meredith Lamb (+14169386001)**

>
Really…\.

*💬 Reply*

**200.** `19:29` **You**

yep\.\. she wanted your job and carolyns


**201.** `19:29` **You**

she told me she wants this one


**202.** `19:29` **You**

called me today\.


**203.** `19:29` **You**

Then it got funny


**204.** `19:29` **You**

I told her I was applying\.


**205.** `19:30` **You**

she was like \- well then maybe I am not applying afterall\.


**206.** `19:30` **Meredith Lamb (+14169386001)**

lol


**207.** `19:30` **You**

She said she doesn't want to get beat by me again


**208.** `19:30` **Meredith Lamb (+14169386001)**

Sounds like a popular role\!


**209.** `19:30` **You**

everyone is looking to escape


**210.** `19:30` **You**

daniel craig\.\. me


**211.** `19:31` **You**

Bailey wants to advance Sophear wants to advance


**212.** `19:32` **Meredith Lamb (+14169386001)**

Craig is applying you think?


**213.** `19:32` **You**

100%


**214.** `19:32` **Meredith Lamb (+14169386001)**

Oh wow


**215.** `19:33` **You**

hmmm I am not doing well with radio silence\.\. I will have to do a better job\.


**216.** `19:33` **Meredith Lamb (+14169386001)**

Radio silence from me??


**217.** `19:33` **Meredith Lamb (+14169386001)**

I’m multitasking


**218.** `19:33` **You**

well from you but not in the way you think\.


**219.** `19:34` **You**

again\.\. just trying to prepare\.\. it is like fasting\.


**220.** `19:34` **You**

nm\.\. fuck it\.\. I already know it will make you miserable\.\.


**221.** `19:35` **Meredith Lamb (+14169386001)**

You could come up to cottage tomorrow night


**222.** `19:35` **You**

you are gonna want to chat at me all weekend about the girls etc


**223.** `19:35` **You**

>
no you know I cannot \- I don't have an excuse to get away\.

*💬 Reply*

**224.** `19:35` **Meredith Lamb (+14169386001)**

I know but just said it anyway


**225.** `19:36` **You**

see thing is sometime you are going to do that\.\. and I am going to say sure see you there\.\. and you are going to be like uhhhhhhhhhhhhh


**226.** `19:36` **You**

Andrew's driving kids up tomorrow night


**227.** `19:36` **Meredith Lamb (+14169386001)**

Andrew is driving kids up Thursday night


**228.** `19:37` **You**

Reaction: 🙁 from Meredith Lamb
still no logical excuse\. and SOOOOO Sus\.\. if I try to pull some bullshit\.


**229.** `19:37` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**230.** `19:38` **You**

9:45 check ring really close to make sure it is working and has a free view in all directions\.


**231.** `19:39` **You**

that kind of thing I will need advanced planning and notice\.


**232.** `19:40` **Meredith Lamb (+14169386001)**

I know


**233.** `19:40` **You**

and at best it would need to be weeknight\.


**234.** `19:40` **Meredith Lamb (+14169386001)**

I don’t actually expect anything\.


**235.** `19:40` **You**

no more weekends until this is done\.


**236.** `19:40` **Meredith Lamb (+14169386001)**

It is a weeknight


**237.** `19:40` **You**

but again\.\. we aren't planning shit anymore\.\. too risky\.\. especially for you\.


**238.** `19:41` **Meredith Lamb (+14169386001)**

Tomorrow would not be risky for me\. Just you\.


**239.** `19:41` **You**

yep\.\. the perception would be too obvious\.\. where do I need to go to be away overnight\.\. and what would I do thursday lol\.


**240.** `19:42` **Meredith Lamb (+14169386001)**

You would go to work Thursday afternoon\. Drive in the morning


**241.** `19:42` **You**

yeah\.\. too risky\.\. I would do it otherwise\.


**242.** `19:42` **Meredith Lamb (+14169386001)**

>
You just need to be with me\. That’s all\.

*💬 Reply*

**243.** `19:43` **You**

I know


**244.** `19:44` **You**

The other thing is\.\. they call me and try to video me\.\. and shit\.\. well Gracie cannot anymore\.\. like we would need to go to a hotel\.\. not the cottage\.


**245.** `19:44` **You**

so if I did get a call or a video request I could show a hotel room\.


**246.** `19:45` **Meredith Lamb (+14169386001)**

Hotel would be hard\. I have 2 dogs\.


**247.** `19:45` **You**

I know\.


**248.** `19:46` **You**

Sry I don't see how I could spin it\.\. with J the way she is now\.\. it would need to be a clear work function\.\. and I would need to not be at risk on a video call\.


**249.** `19:47` **Meredith Lamb (+14169386001)**

Yeah I know\.


**250.** `19:47` **Meredith Lamb (+14169386001)**

It’s okay \- we will have lots of time together eventually\. Just get our agreements finalized\.


**251.** `19:48` **Meredith Lamb (+14169386001)**

Andrew has promised to do the taxes tonight


**252.** `19:50` **You**

hmmm


**253.** `19:58` **Meredith Lamb (+14169386001)**

Hmmm


**254.** `20:06` **You**

Maybe


**255.** `20:18` **Meredith Lamb (+14169386001)**

Excuse me?


**256.** `20:24` **Meredith Lamb (+14169386001)**

Please elaborate


**257.** `20:40` **You**

Saying I might come and sdo on Thursday\.


**258.** `20:41` **You**

But with the ring and everything seems risky still doesnt it


**259.** `20:47` **Meredith Lamb (+14169386001)**

What the heck would you tell your family? I feel like if you come you would basically be saying fuck it\.


**260.** `20:47` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**261.** `20:47` **Meredith Lamb (+14169386001)**

That is the ring\. It has blown over a bit


**262.** `20:48` **Meredith Lamb (+14169386001)**

I can’t go to dump wed or thurs\. Closed\.


**263.** `20:48` **Meredith Lamb (+14169386001)**

Have to go Friday so I have no excuse to remove that stuff right away


**264.** `20:49` **Meredith Lamb (+14169386001)**

See closed\.

*💬 Reply*

**265.** `20:50` **Meredith Lamb (+14169386001)**

The ring is not the problem, your family is the challenge\. So I completely 180% understand that and wasn’t expecting you to swing it\.


**266.** `20:54` **You**

I have a narrative


**267.** `20:54` **You**

Believable


**268.** `20:55` **You**

Believed


**269.** `20:55` **Meredith Lamb (+14169386001)**

Hmmh


**270.** `20:55` **Meredith Lamb (+14169386001)**

Would love to hear it


**271.** `20:55` **You**

Later


**272.** `20:55` **Meredith Lamb (+14169386001)**

lol


**273.** `20:55` **Meredith Lamb (+14169386001)**

k


**274.** `20:56` **Meredith Lamb (+14169386001)**

Well I’m aiming to leave here at 6am 🥱🥱🥱🥱🥱


**275.** `20:56` **Meredith Lamb (+14169386001)**

I have a 9am with Pauline


**276.** `20:56` **You**

Nice


**277.** `20:58` **You**

When would you want me there


**278.** `20:58` **You**

and when would I leave noon ish?


**279.** `20:59` **Meredith Lamb (+14169386001)**

Whenever you want


**280.** `20:59` **Meredith Lamb (+14169386001)**

9am


**281.** `20:59` **Meredith Lamb (+14169386001)**

lol


**282.** `21:01` **You**

I could t leave till 2 pm earliest


**283.** `21:08` **Meredith Lamb (+14169386001)**

Wait what day were you asking about Wed and Thurs or just Wed?


**284.** `21:09` **Meredith Lamb (+14169386001)**

To me, honestly I didn’t think this had any chance so the time doesn’t matter to me


**285.** `21:09` **You**

Just wed Andrew is coming up third


**286.** `21:09` **You**

So I would leave


**287.** `21:09` **Meredith Lamb (+14169386001)**

Right but were you asking when you had to leave thurs?


**288.** `21:09` **You**

Yeah what time


**289.** `21:10` **Meredith Lamb (+14169386001)**

Oh I don’t care but I should go to Huntsville to get groceries


**290.** `21:10` **Meredith Lamb (+14169386001)**

In afternoon


**291.** `21:10` **Meredith Lamb (+14169386001)**

Andrew and girls won’t get there until 9\.30pm


**292.** `21:11` **You**

Ok


**293.** `21:11` **You**

I think I can manage it


**294.** `21:12` **You**

I think


**295.** `21:12` **Meredith Lamb (+14169386001)**

I still don’t understand how you can do this


**296.** `21:14` **Meredith Lamb (+14169386001)**

Are you sure it isn’t going to make things worse?


**297.** `21:32` **You**

things are already shit


**298.** `21:32` **You**

ok


**299.** `21:32` **You**

so I am taking next week and the week of the 19th of june off\.


**300.** `21:32` **You**

which is the week the team goes to chatham


**301.** `21:33` **You**

I suggested i should make that up tomorrow night before I head out on vacation \- she was in complete agreement


**302.** `21:33` **Meredith Lamb (+14169386001)**

Make up the Chatham trip?


**303.** `21:33` **You**

yeah because I never go enough\.\. I am missing the mgmt meeting in chatham


**304.** `21:34` **Meredith Lamb (+14169386001)**

But that makes no sense


**305.** `21:34` **You**

so I will go tomorrow to visit the team\.\.'


**306.** `21:34` **Meredith Lamb (+14169386001)**

There is no mgt meeting tomorrow


**307.** `21:34` **You**

ok step 1


**308.** `21:34` **You**

there is a mgmt team in 2 weeks that I will be missing \- it is in chatham for a reason


**309.** `21:34` **You**

step 2 I am missing it


**310.** `21:34` **Meredith Lamb (+14169386001)**

Ok ok


**311.** `21:34` **You**

so instead


**312.** `21:34` **Meredith Lamb (+14169386001)**

I get it


**313.** `21:34` **You**

I go tomorrow


**314.** `21:34` **You**

lol


**315.** `21:34` **Meredith Lamb (+14169386001)**

But like she believes that for real?


**316.** `21:34` **You**

yah


**317.** `21:34` **Meredith Lamb (+14169386001)**

Okey dokey


**318.** `21:35` **Meredith Lamb (+14169386001)**

What if you get a call tho?


**319.** `21:35` **You**

We had a bit of a fight about something else tonight\.\. I won't be taking calls


**320.** `21:36` **Meredith Lamb (+14169386001)**

😬


**321.** `21:36` **Meredith Lamb (+14169386001)**

k…


**322.** `21:36` **You**

I mean if you are nervous we don't have to do you brought it up lol


**323.** `21:36` **Meredith Lamb (+14169386001)**

Well if this goes badly I will feel bad


**324.** `21:36` **Meredith Lamb (+14169386001)**

No I want to but your family life seems like very thin ice right now


**325.** `21:37` **You**

I mean this whole thing is a shit show\.


**326.** `21:37` **You**

like it just is what it is at this point\.


**327.** `21:40` **Meredith Lamb (+14169386001)**

Well if you feel comfortable enough, I certainly am so kind of your final call


**328.** `21:41` **Meredith Lamb (+14169386001)**

Andrew and Mac just got home and I confirmed the plan and it still is the same


**329.** `21:41` **Meredith Lamb (+14169386001)**

Andrew has some town hall he needs to speak at from 1\-3pm Thursday aft and that won’t be changing


**330.** `21:43` **You**

ok


**331.** `21:43` **You**

so then this could work


**332.** `21:43` **Meredith Lamb (+14169386001)**

Then he is taking Marlowe to some vball thing in Markham right after school for her


**333.** `21:43` **Meredith Lamb (+14169386001)**

Then coming back to Yonge and Eg and packing and getting girls


**334.** `21:44` **You**

sec


**335.** `21:44` **You**

I think we are fine\.\. just need a few mins kl


**336.** `21:44` **Meredith Lamb (+14169386001)**

Yup watching a doc


**337.** `21:59` **You**

I am coming


**338.** `22:00` **You**

leaving 2:30 ish tomorrow\.\. planning on being back supper ish Thursday if that works for you\.


**339.** `22:00` **Meredith Lamb (+14169386001)**

Crazy\!


**340.** `22:00` **Meredith Lamb (+14169386001)**

And yes of course that works for me lol


**341.** `22:01` **You**

ok\.\.\. see you need to be careful what you say\.\. cause then crazy things happen\.


**342.** `22:02` **Meredith Lamb (+14169386001)**

lol I’m a little shocked \(pleasantly\)


**343.** `22:02` **You**

I am too\.\. but should be fine\.\. I am taking an SDO thursday\.\. so we will have most of thursday for whatever\.\. party prep etc\.


**344.** `22:04` **Meredith Lamb (+14169386001)**

I do have stuff to do for sure but will try to do some tomorrow on and off


**345.** `22:04` **You**

kk well now we have something to look forward to\.


**346.** `22:05` **Meredith Lamb (+14169386001)**

🎉


**347.** `22:05` **You**

hey listen though


**348.** `22:05` **You**

you sure you good\. this is not a guilt thing right?


**349.** `22:05` **Meredith Lamb (+14169386001)**

Omg no


**350.** `22:05` **You**

like if it isn't convenient


**351.** `22:06` **Meredith Lamb (+14169386001)**

I wouldn’t have put it out there if I didn’t want to\!


**352.** `22:07` **Meredith Lamb (+14169386001)**

I would see you everyday if we could


**353.** `22:11` **You**

yeah same I truly want to get there\.\. somehow


**354.** `22:14` **You**

well committed now


**355.** `22:14` **You**

Reaction: ❤️ from Meredith Lamb
SDO request in


**356.** `22:14` **You**

doing a wash


**357.** `22:14` **You**

not going to gym so I can stay up late\.\.


**358.** `22:14` **You**

all plans in motion :\)


**359.** `22:15` **Meredith Lamb (+14169386001)**

Well I’m excited ❤️


**360.** `22:15` **You**

and we are playing ticket to ride


**361.** `22:15` **You**

and maybe watching some shows\.\. and doing some other stuff\.


**362.** `22:16` **You**

and the dogs\!\!\! :\)


**363.** `22:16` **You**

very happy


**364.** `22:16` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
No Bo


**365.** `22:16` **Meredith Lamb (+14169386001)**

lol


**366.** `22:18` **You**

ok well you need to get up early\.\. so I will let you be\.\. go watch your doc and go to sleep\.\. Looking forward to seeing you tomorrow a lot alot a alot\.


**367.** `22:19` **Meredith Lamb (+14169386001)**

I’m going to watch 10 min more and get to bed\. Very excited for tomorrow but don’t want to jinx anything so will leave it at that xoxo


**368.** `22:19` **You**

oh I can bring some gummies if you want some\.


**369.** `22:19` **Meredith Lamb (+14169386001)**

🙄


**370.** `22:19` **You**

Love you\!\!\!\!\!\!


**371.** `22:20` **Meredith Lamb (+14169386001)**

Already packed my own


**372.** `22:20` **You**

XOXOXOXO


**373.** `22:20` **You**

Reaction: 😂 from Meredith Lamb
yeah NO DOUBT\!\!


**374.** `22:20` **You**

ok\.\. night\.\. ❤️❤️❤️


**375.** `22:20` **Meredith Lamb (+14169386001)**

Nite ❤️


