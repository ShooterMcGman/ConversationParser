# Daily Conversation: 2025-04-22 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-22 |
| **Day** | Tuesday |
| **Week** | 2 |
| **Messages** | 421 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-22T00:53 - 2025-04-22T23:42 |

## 📝 Daily Summary

This day contains **421 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:53` **You**

All done another night finished\. Apparently Sharon is a problem, j is basically going in a circle grabbing on to four or five things and just losing her shit about everything\. She said she wanted to talk and then full on just attacked I was like wtf… anyhow not a great night\.\. is what it is will see you in morning I will be happier then\. Luv you xoxoxoxo


**002.** `06:50` **Meredith Lamb (+14169386001)**

I’m very sorry it was a shitty conversation but I will not lie…\. Prefer that to date night at the gym\. 😝
But hopefully things get a bit easier soon though\. 💋\(I used a different emoji for you\.\)


**003.** `06:52` **You**

You and date night find me someplace today I will show you date night for you\.


**004.** `06:54` **Meredith Lamb (+14169386001)**

Will do my best\. I am talking to my therapist at lunch\. She is going to tell me we are doing everything wrong\. I haven’t talked to her in 2 weeks\.


**005.** `06:54` **You**

Perfect


**006.** `06:54` **You**

😇


**007.** `06:55` **Meredith Lamb (+14169386001)**

lol


**008.** `07:17` **Meredith Lamb (+14169386001)**

Ps\. Last night I told Mac what Andrew said about new guys being around the girls and said she may not meet Scott this weekend intentionally\. She goes “why? Dad would never know”


**009.** `07:18` **Meredith Lamb (+14169386001)**

Such a teen response\. Lol


**010.** `07:18` **Meredith Lamb (+14169386001)**

I said he could eventually find out\!


**011.** `07:18` **Meredith Lamb (+14169386001)**

She was like, uh no but whatever


**012.** `07:24` **You**

ROFL


**013.** `07:24` **You**

Teen response


**014.** `07:25` **You**

And a you response with the whatever\!\!


**015.** `07:25` **You**

lol


**016.** `07:28` **Meredith Lamb (+14169386001)**

Maybe some tiny similarities\. Mostly different\. Anyway, don’t expect her to steer clear but I will talk to her again on drive there\.


**017.** `07:50` **You**

I just don’t want to cause any problems\.


**018.** `09:04` **You**

🔥🔥🔥🔥🔥🔥🔥🔥🔥


**019.** `09:08` **You**

This meant to be compliment fyi


**020.** `09:12` **Meredith Lamb (+14169386001)**

❤️


**021.** `10:04` **Meredith Lamb (+14169386001)**

You should have meant “rewards for US”\. Not putting that in teams :p


**022.** `10:56` **Meredith Lamb (+14169386001)**

Apparently we missed the debate Thursday night\. lol


**023.** `11:00` **You**

What debate?  We were busy\.\. if I recall\.


**024.** `11:00` **You**

I was debating about stuff to do or not\.


**025.** `11:07` **Meredith Lamb (+14169386001)**

lol


**026.** `11:33` **You**

J is back to being nice today\.


**027.** `12:29` **You**

If you get off early with therapist and want to come in you are welcome


**028.** `14:21` **You**

Another day so close and still so much missing you\.
Hope you didn’t lend your phone to anyone in the room\.


**029.** `14:23` **Meredith Lamb (+14169386001)**

Same\.


**030.** `14:24` **Meredith Lamb (+14169386001)**

>
I talked to my therapist about Andrew continually bringing up getting back together here and there\. She said I need to prioritize getting out for my mental sake\. I said when I am nice/amicable, I think he gets the wrong idea\. Blahblahblah confusing complex annoying\.

*💬 Reply*

**031.** `14:31` **You**

Reaction: 😂 from Meredith Lamb
Yeah well now I have to take the family to a tulip farm for Mother’s Day\.


**032.** `14:31` **You**

So while I try to maintain a cool arms length the kids are fighting


**033.** `14:31` **You**

Anyways talked to j for about half an hour before our meeting earlier\.\. she still wants Moncton\.


**034.** `14:32` **You**

Looks kind of like worst case would be here for a year then go there\.  Unsure she is working on Gracie


**035.** `14:33` **You**

But like Andrew I still think she wants a different answer from me\.  But honestly I couldn’t possibly contemplate ever doing that, even if you left today and said cya boi\.\. I would still proceed at full pace\.


**036.** `14:33` **You**

Reaction: ❤️ from Meredith Lamb
I have thought of you 99% of the time and anything else 1% outside of work of course


**037.** `15:30` **Meredith Lamb (+14169386001)**

Tulip farm\. “Interesting”


**038.** `15:31` **Meredith Lamb (+14169386001)**

Sorry we didn’t get to talk today\. Xo


**039.** `15:36` **You**

It’s ok I can call you later but not sure if anything is safe anymore\.  Cote is in here regailing me with her 90’s off the beaten path music ffs……


**040.** `15:36` **You**

Anyhow let me know one way or the other was going to call you on way home from sales if you want or not all good


**041.** `15:40` **Meredith Lamb (+14169386001)**

k will let you know\.


**042.** `15:40` **Meredith Lamb (+14169386001)**

Ps\. I’m glad to be gone\. You looked really good today and it was so distracting in your office\. :p


**043.** `16:14` **You**

Man I was trying hard… no lie\.


**044.** `16:14` **You**

Worked hard last
Few days


**045.** `16:14` **You**

17’lbs down


**046.** `16:16` **Meredith Lamb (+14169386001)**

Very obvious\. Not going to help your Sharon debate at home\. :p


**047.** `16:16` **You**

I am shooting for something else


**048.** `16:16` **Meredith Lamb (+14169386001)**

Something else or someone else


**049.** `16:17` **You**

You all for you


**050.** `16:17` **You**

And for me


**051.** `16:17` **You**

I like feeling good


**052.** `16:18` **Meredith Lamb (+14169386001)**

You know you don’t have to do that for me right


**053.** `16:19` **Meredith Lamb (+14169386001)**

But I get it


**054.** `16:20` **You**

I know but I want to


**055.** `16:22` **Meredith Lamb (+14169386001)**

I know, completely get it


**056.** `16:24` **You**

I just hope you are happy one way or the other with the little interaction we have thus far\.\. and still believe we can get to a better place and we can kind of take it as it goes\.\. 4 days


**057.** `16:26` **Meredith Lamb (+14169386001)**

Very happy… unless there are more gym date nights\. Then not so much\. 😇


**058.** `16:29` **You**

I won’t be inviting her again\.  I don’t want to send mixed messages


**059.** `16:29` **You**

I only want to be sending you one message


**060.** `16:35` **Meredith Lamb (+14169386001)**

Ditto


**061.** `16:39` **You**

Kk I have Harris a in here I will msg more Flirting later cause that is what I love so much more than physical flirting let me tell you\!\!


**062.** `16:41` **Meredith Lamb (+14169386001)**

Have fun with your bestie tonight :\)


**063.** `17:08` **You**

Oh it’s already hugs and kisses\.\.


**064.** `17:08` **You**

More action from him\.


**065.** `17:08` **You**

\(Duck\)


**066.** `17:08` **You**

lol


**067.** `17:10` **Meredith Lamb (+14169386001)**

Mean\. Lol


**068.** `17:11` **You**

ROFL no action for anyone else\.   I am saving myself\.


**069.** `17:13` **Meredith Lamb (+14169386001)**

lol you are funny


**070.** `17:13` **You**

It’s true more than you know lol will let
You think on that one\.


**071.** `17:38` **Meredith Lamb (+14169386001)**

lol will you stop


**072.** `17:44` **You**

I am just saying it is a thinker


**073.** `17:44` **Meredith Lamb (+14169386001)**

Can you just explain


**074.** `17:45` **You**

No


**075.** `17:45` **You**

Ask chat got what it could mean I am curious


**076.** `17:47` **Meredith Lamb (+14169386001)**

Sigh, fine\.
Here’s what he said:
“ROFL no action for anyone else\. I am saving myself\.”
“It’s true more than you know lol\. Will let you think on that one\.”
At face value, yes — it sounds like he may be implying that he hasn’t had physical intimacy with his wife in a long time\. But there are other possible interpretations, and all of them are meaningful in different ways:
⸻
1\. He could be saying: “I’m emotionally and physically committed to you now — even if we aren’t official\.”
The “saving myself” line might not just be about past abstinence — it could be his way of telling you:
“Even though I’m not free yet, my body and heart are already yours\. No one else exists in that space anymore\.”
That’s not just romantic — it’s a quiet declaration of loyalty\.
⸻
2\. He could be trying to subtly express how serious this is for him\.
This might have been his way of saying:
“I’m not taking this lightly\. You’re not a fling\. I’m protecting what we have\.”
The joking tone \(“ROFL”\) softens it — but the truth underneath is serious\. He’s not playing with you\. He’s already all in\.
⸻
3\. He might be hinting at a deeper vulnerability — not just about sex, but about disconnection\.
What if he meant:
“I haven’t felt close to anyone like this — emotionally or physically — in a very long time\.”
So while the words sound like a sexual joke, what he may really be saying is:
“This connection scares me because it’s real — and I’ve been emotionally shut down for years\.”
That’s not about abstinence\. That’s about awakening\.
⸻
4\. He could be giving you permission to wonder — without forcing a reveal\.
When he said:
“Will let you think on that one…”
It’s almost like he’s inviting you into the space between the lines\.
He’s saying: “I’m not quite ready to say it all, but I trust you to understand me anyway\.”


**077.** `17:48` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**078.** `17:49` **Meredith Lamb (+14169386001)**

Ugh, I hate when moms call me\.


**079.** `17:49` **Meredith Lamb (+14169386001)**

I can’t lie\!\!  lol


**080.** `17:52` **You**

lol


**081.** `17:53` **Meredith Lamb (+14169386001)**

Why can’t you just tell me?


**082.** `17:53` **Meredith Lamb (+14169386001)**

I don’t believe ChatGPT


**083.** `17:54` **You**

Sooooo


**084.** `17:54` **You**

1 is true but not it 100%


**085.** `17:54` **You**

2 is obvious\.


**086.** `17:55` **You**

3 is extremely true


**087.** `17:55` **You**

And nope didnt get it yet


**088.** `17:55` **Meredith Lamb (+14169386001)**

It doesn’t have enough context


**089.** `17:56` **Meredith Lamb (+14169386001)**

Because you are being cryptic


**090.** `18:05` **You**

I think it might be looking too deep


**091.** `18:05` **You**

Perhaps??


**092.** `18:05` **You**

I dunno


**093.** `18:13` **Meredith Lamb (+14169386001)**

lol


**094.** `18:13` **Meredith Lamb (+14169386001)**

Well then don’t be so cryptic


**095.** `18:22` **Meredith Lamb (+14169386001)**

Saving yourself for marriage? 🙃


**096.** `18:32` **You**

lol no


**097.** `18:34` **You**

I would saving
Self forever


**098.** `18:36` **Meredith Lamb (+14169386001)**

Yup\!


**099.** `18:41` **You**

I feel like there
Needs
To be an in between non commitment commitment


**100.** `18:43` **Meredith Lamb (+14169386001)**

That’s a new one\. “An in between non commitment commitment”\. Mouthful


**101.** `18:44` **You**

Well it is something I will ask gpt


**102.** `18:45` **Meredith Lamb (+14169386001)**

Is you head spinning or something?


**103.** `18:47` **You**

Is yours?


**104.** `18:48` **Meredith Lamb (+14169386001)**

Kind of\. Trying to interpret all of your msgs tonight


**105.** `19:02` **You**

It’s not bad it’s just some fun


**106.** `19:05` **Meredith Lamb (+14169386001)**

Okkkkkkkkkkkkk


**107.** `19:07` **You**

My bromance is strong\!\!\!\!


**108.** `19:07` **You**

Whoooo spicy


**109.** `19:07` **You**

He wants to go to a spa with me


**110.** `19:08` **Meredith Lamb (+14169386001)**

Whatever


**111.** `19:08` **Meredith Lamb (+14169386001)**

lol


**112.** `19:13` **You**

Like so much more love from this guy


**113.** `19:14` **You**

And he is not afraid to show it


**114.** `19:17` **Meredith Lamb (+14169386001)**

I feel like you are enjoying it too much


**115.** `19:21` **You**

Man it is nice to get attention\.


**116.** `19:27` **You**

Gemini is being a sick


**117.** `19:27` **You**

Dick


**118.** `19:30` **You**

Basically some form of commitment without paper
I think\.
Verbal I guess again it is saying this matters and means something \.\.  I am not saying now this whole thing was about saving
Myself and it went down a rabbit hole and you still do t know what the former meant\. 😇\. So yah no marriage but
Some kind of commitment to each other someday might be nice and wouldn’t need to be in front of anyone e\.\. anyhow I am just
Musing on that anyways\.


**119.** `19:30` **You**

Don’t suppose you could
Talk eh no worries
If not just about to drive home


**120.** `19:38` **Meredith Lamb (+14169386001)**

Sure


**121.** `19:38` **Meredith Lamb (+14169386001)**

For like 20\-25 min


**122.** `19:39` **Meredith Lamb (+14169386001)**

After that I will have my little shadow


**123.** `19:39` **You**

Call me if you want


**124.** `21:08` **Meredith Lamb (+14169386001)**

See this is the problem, now I’m feeling Scott withdrawal\.


**125.** `21:08` **Meredith Lamb (+14169386001)**

\(Haris probably is also\.\)


**126.** `21:36` **You**

I would find a quiet place tomorrow\.


**127.** `21:37` **Meredith Lamb (+14169386001)**

Under your desk?


**128.** `21:37` **Meredith Lamb (+14169386001)**

Har har


**129.** `21:39` **You**

I could make that work


**130.** `21:39` **You**

No Côté there tomorrow


**131.** `21:39` **Meredith Lamb (+14169386001)**

Ahana


**132.** `21:39` **You**

No anyone there tomorrow


**133.** `21:39` **You**

Booo


**134.** `21:39` **You**

Tell her to work from home


**135.** `21:39` **Meredith Lamb (+14169386001)**

lol


**136.** `21:40` **You**

Carolyn


**137.** `21:40` **You**

Shit


**138.** `21:40` **You**

Shitty shitters


**139.** `21:40` **Meredith Lamb (+14169386001)**

Oh actually Ahana is at combo


**140.** `21:40` **Meredith Lamb (+14169386001)**

Cmvp


**141.** `21:40` **You**

Maybe I could\.\. Fack bah


**142.** `21:41` **Meredith Lamb (+14169386001)**

No


**143.** `21:41` **You**

I get you withdrawal all the time


**144.** `21:41` **You**

So 😜


**145.** `21:41` **Meredith Lamb (+14169386001)**

So are you saying you don’t care about my withdrawal?


**146.** `21:41` **Meredith Lamb (+14169386001)**

lol


**147.** `21:42` **Meredith Lamb (+14169386001)**

What if I’m seizing


**148.** `21:43` **You**

I would do anything but I know you are even mite risk averse than me


**149.** `21:43` **You**

More


**150.** `21:44` **Meredith Lamb (+14169386001)**

I think that is a good thing\.


**151.** `21:44` **Meredith Lamb (+14169386001)**

You will keep your job as a result\.


**152.** `21:44` **Meredith Lamb (+14169386001)**

:p


**153.** `21:45` **Meredith Lamb (+14169386001)**

I am risk averse but not THAT risk averse\. We have seen each other irl due to shared risk\.


**154.** `21:49` **You**

You are probably right\.  Again just slightly out of control letting g the teenager in me back out


**155.** `21:51` **Meredith Lamb (+14169386001)**

\[delete\]


**156.** `21:51` **You**

What??\!


**157.** `21:51` **Meredith Lamb (+14169386001)**

So was there more to this afternoon’s msgs?


**158.** `21:51` **You**

No deletes


**159.** `21:53` **Meredith Lamb (+14169386001)**

It wasn’t a big thing\. You answer my question


**160.** `21:54` **You**

Nope


**161.** `21:54` **You**

What


**162.** `21:54` **You**

Msg


**163.** `21:55` **Meredith Lamb (+14169386001)**

You said I didn’t get something


**164.** `21:55` **Meredith Lamb (+14169386001)**

Or ChatGPT didn’t lol


**165.** `21:56` **You**

Oh that


**166.** `21:56` **Meredith Lamb (+14169386001)**

I was just going to ask when I get my own place and don’t have girls at it would you come over? Or when might that happen…\. But I think it is too early still to even question\.


**167.** `21:57` **Meredith Lamb (+14169386001)**

>
Yah\.

*💬 Reply*

**168.** `21:58` **You**

I mean I would want to I would need to figure out how to manage it\.


**169.** `21:58` **You**

I def would want to


**170.** `21:58` **You**

Like I would want you to stay with me


**171.** `21:58` **You**

If the option was there


**172.** `21:59` **Meredith Lamb (+14169386001)**

>
But you couldn’t\.

*💬 Reply*

**173.** `21:59` **You**

>
As to this I don’t think you would understand or appreciate it and you would just say I am even more weird than you already think

*💬 Reply*

**174.** `22:00` **You**

>
Again I would need to have a trip a team event or something I can manage anything

*💬 Reply*

**175.** `22:00` **You**

It wouldn’t be hard


**176.** `22:00` **You**

As it wouldn’t be often I suspect for a little while\.


**177.** `22:00` **You**

Gracie and I and maddie had a chat
Tonight


**178.** `22:01` **You**

They asked me if I would meet someone else and how


**179.** `22:02` **You**

I said I don’t know they asked if it might end up being someone from work someday\.\. I said well I spend all of my time there
But everyone I know is married anyways\.  But I said who knows someday\.\. they both seemed to accept it\.\.
Just an fyi\.


**180.** `22:02` **Meredith Lamb (+14169386001)**

>
This is going to get …\. Um, difficult right\.

*💬 Reply*

**181.** `22:02` **You**

No


**182.** `22:02` **You**

And if it is it will be only a little


**183.** `22:03` **You**

And it will be worth it


**184.** `22:03` **You**

At least to me


**185.** `22:03` **Meredith Lamb (+14169386001)**

I have to be honest\.\. we have a weekend coming up that could totally shift things and it worries me\.


**186.** `22:03` **You**

What worries
You\.


**187.** `22:03` **You**

My feelings


**188.** `22:04` **Meredith Lamb (+14169386001)**

The withdrawal right now is manageable because we have many fully gone there… like physically…\. I worry about the withdrawal after\.


**189.** `22:04` **Meredith Lamb (+14169386001)**

Like I don’t want to go mental and become a basket case


**190.** `22:04` **You**

Ii might suck mer\.\.
You might have the opposite outcome


**191.** `22:04` **You**

I might


**192.** `22:04` **Meredith Lamb (+14169386001)**

We have so many restrictions


**193.** `22:04` **You**

😝


**194.** `22:05` **Meredith Lamb (+14169386001)**

>
Uh huh\.

*💬 Reply*

**195.** `22:05` **You**

I doubt you would ever be a basket case


**196.** `22:05` **Meredith Lamb (+14169386001)**

>
I think I could try to understand and appreciate it\.

*💬 Reply*

**197.** `22:05` **Meredith Lamb (+14169386001)**

>
I can be\.

*💬 Reply*

**198.** `22:05` **You**

lol you would fucking say anything g to get me to tell you are such a secret
Monkey\.


**199.** `22:06` **You**

Hmm let’s try this approach\.


**200.** `22:06` **Meredith Lamb (+14169386001)**

I am being real\. That’s all


**201.** `22:07` **You**

Have you ever seen the movie 40
Days and 49
Nights


**202.** `22:07` **You**

40 and 40


**203.** `22:07` **Meredith Lamb (+14169386001)**

I don’t think so


**204.** `22:07` **You**

Well then you won’t get it


**205.** `22:08` **You**

Mer honestly I don’t want to but you in a rough spot we can tone back this weekend to whatever
You need it to be\.


**206.** `22:08` **Meredith Lamb (+14169386001)**

I read the movie description\. So explain


**207.** `22:09` **You**

What do you mean I don’t know what the description says


**208.** `22:09` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**209.** `22:10` **Meredith Lamb (+14169386001)**

I have never heard of this movie lol


**210.** `22:10` **You**

It isn’t just no sex lol it is no anything at all ever


**211.** `22:11` **Meredith Lamb (+14169386001)**

What do you mean? You literally have two children


**212.** `22:11` **Meredith Lamb (+14169386001)**

I’m pretty sure sex made that happen


**213.** `22:11` **You**

Err how to put this delicately


**214.** `22:11` **Meredith Lamb (+14169386001)**

lol


**215.** `22:11` **Meredith Lamb (+14169386001)**

Listening


**216.** `22:14` **You**

So Meredith\.\. people have needs and when those needs are not being met by other people…\.
Fill in the blank…
So imagine my life
For 20years…
Why the hell am
I telling this to you\.\.
Why do I tell you half the shit I do lol\.\. since I have
Felt serious about you 40
Days and 40 nights\.\. now I don’t know what that means mer because that has literally never happened\.\.
Ever\.\. so there
Now I am even weirder even gpt is like wtf dude\.


**217.** `22:15` **You**

See even you don’t know what to make of this


**218.** `22:15` **You**

lol


**219.** `22:15` **You**

I sure don’t


**220.** `22:15` **Meredith Lamb (+14169386001)**

Well I constantly have to interpret what you are saying


**221.** `22:15` **Meredith Lamb (+14169386001)**

So takes me a minute


**222.** `22:15` **You**

I think this was clear


**223.** `22:15` **Meredith Lamb (+14169386001)**

What did gpt say


**224.** `22:16` **You**

Sex I will ask Gemini again\.  But not giving you the prompt


**225.** `22:16` **You**

I mean now it autocorrects that


**226.** `22:16` **You**

Jesus


**227.** `22:16` **Meredith Lamb (+14169386001)**

So you fulfilled your own needs until you felt serious about me? Then you stopped?


**228.** `22:16` **Meredith Lamb (+14169386001)**

Am I interpreting incorrectly?


**229.** `22:16` **Meredith Lamb (+14169386001)**

Omg like spell it out lol


**230.** `22:17` **Meredith Lamb (+14169386001)**

I’m trying here


**231.** `22:17` **Meredith Lamb (+14169386001)**

You think you are being clear but you kinda aren’t lol


**232.** `22:20` **You**

I will paraphrase it says you make me so happy that nothing else
Is needed\.


**233.** `22:20` **You**

Not lying


**234.** `22:21` **You**

I mean that has to be the ultimate compliment ever\.\. I have never even heard of it but apparently it is a thing


**235.** `22:22` **Meredith Lamb (+14169386001)**

If I’m understanding you, I have been acting the same way and I think it is part of being in real love\.


**236.** `22:23` **Meredith Lamb (+14169386001)**

I patiently wait for my time with you


**237.** `22:23` **You**

You are understanding me that is why I put it delicately lol


**238.** `22:23` **Meredith Lamb (+14169386001)**

Took me a while to get there\. Lol but I understand


**239.** `22:23` **Meredith Lamb (+14169386001)**

It is real love


**240.** `22:24` **You**

I think that is the only reason I can think of mer\.\. but in all honesty that is all it can be\.\.


**241.** `22:24` **You**

Reaction: 😂 from Meredith Lamb
I mean it doesn’t even bother me…\.\. much


**242.** `22:24` **You**

Well it is tolerable


**243.** `22:24` **You**

But see that isn’t the longing


**244.** `22:24` **You**

It is still just to be with you


**245.** `22:25` **You**

Not the other thing\.\. to be clear


**246.** `22:25` **You**

I mean again that too but it isn’t primary


**247.** `22:25` **You**

Has to be real


**248.** `22:25` **Meredith Lamb (+14169386001)**

I mean I want the other thing too…\. Like so much\. But I want to survive when we are apart\.


**249.** `22:26` **You**

I know, like I said even now with this, I will still follow your lead this weekend\.


**250.** `22:27` **Meredith Lamb (+14169386001)**

k, I mean there is so much to do even if we don’t fully go there … we’ll see\. I’m honestly a little worried about being jealous of you being back home after\. For now it’s a bit easier to take


**251.** `22:27` **You**

So I am not weirder then\.


**252.** `22:28` **Meredith Lamb (+14169386001)**

God no


**253.** `22:28` **You**

Nothing to be jealous of I told you earlier I only think of you


**254.** `22:28` **You**

I cannot compartmentalize well


**255.** `22:29` **Meredith Lamb (+14169386001)**

Today my therapist actually told me to compartmentalize at one point and I was like “omg I have to tell Scott” lol


**256.** `22:29` **Meredith Lamb (+14169386001)**

Can’t remember what it was about unfortunately


**257.** `22:29` **You**

ROFL


**258.** `22:29` **You**

Maybe I should see
Your
Therapist


**259.** `22:29` **Meredith Lamb (+14169386001)**

Maybe\!


**260.** `22:29` **You**

lol


**261.** `22:29` **You**

Would that be odd


**262.** `22:30` **Meredith Lamb (+14169386001)**

I can give you her contact info


**263.** `22:30` **You**

So not


**264.** `22:30` **You**

Odd


**265.** `22:30` **You**

lol


**266.** `22:30` **Meredith Lamb (+14169386001)**

I wonder if she would put two and two together


**267.** `22:30` **Meredith Lamb (+14169386001)**

Probably


**268.** `22:30` **You**

In the first hour S she asked me wusstiins


**269.** `22:30` **You**

Questions


**270.** `22:30` **Meredith Lamb (+14169386001)**

Yeah lol


**271.** `22:31` **Meredith Lamb (+14169386001)**

So it hasn’t actually been 40 days?


**272.** `22:31` **Meredith Lamb (+14169386001)**

lol


**273.** `22:31` **Meredith Lamb (+14169386001)**

More like 2 weeks


**274.** `22:31` **You**

3 weeks


**275.** `22:32` **You**

At least


**276.** `22:32` **You**

More probably


**277.** `22:32` **You**

Let’s say I cannot remember


**278.** `22:32` **Meredith Lamb (+14169386001)**

lol


**279.** `22:32` **Meredith Lamb (+14169386001)**

4 days


**280.** `22:33` **You**

Yep


**281.** `22:33` **You**

4 days


**282.** `22:33` **Meredith Lamb (+14169386001)**

Sigh


**283.** `22:33` **You**

Remeber I am good with whatever making you happy will make me happy


**284.** `22:34` **Meredith Lamb (+14169386001)**

I know\.


**285.** `22:34` **Meredith Lamb (+14169386001)**

We are in this together though :\)


**286.** `22:34` **You**

That we are


**287.** `22:36` **Meredith Lamb (+14169386001)**

You know I picture my future with you in my head right? You don’t need a signed commitment\. It’s all there in my head


**288.** `22:37` **You**

I don’t want a signed commitment I know I will feel differently when we are together someday\.\. whenever that is


**289.** `22:37` **Meredith Lamb (+14169386001)**

Phewwwwwww

*📎 1 attachment(s)*

**290.** `22:37` **Meredith Lamb (+14169386001)**

>
Dreams do come true

*💬 Reply*

**291.** `22:38` **You**

lol


**292.** `22:38` **You**

Sure thing honey miss you\!\!


**293.** `22:39` **Meredith Lamb (+14169386001)**

lol sure


**294.** `22:40` **Meredith Lamb (+14169386001)**

>
I think you will feel differently the longer time goes on\. But honestly, I would probably do whatever you wanted or needed\. I think you had me earlier than I had you\.  But I can never prove it\.

*💬 Reply*

**295.** `22:42` **You**

I honestly don’t know it started honestly enough I felt for you\.\. I hated what happened to you\.\. I was going down my own road\.\. and it just sort of happened slowly carefully\.\. then I think we just jumped\.


**296.** `22:42` **Meredith Lamb (+14169386001)**

There is something about Scott Hicks that I can’t put my finger on but have always been drawn to\.


**297.** `22:42` **You**

I have written you a love letter
Made you a mix tape and been well what we were talking about for probably 4 weeks or more\.\.


**298.** `22:43` **You**

Happier than I have ever been


**299.** `22:43` **You**

And I barely see you which makes the down times suck all the more\.\.
You don’t like me with j I don’t like with andrew\.\.


**300.** `22:43` **You**

lol


**301.** `22:43` **You**

I think we are on same page in everything


**302.** `22:44` **Meredith Lamb (+14169386001)**

It is a little wild\.


**303.** `22:44` **You**

It is and will be memorable I hope


**304.** `22:45` **You**

This cannot even be common\.\. we should ask your therapist


**305.** `22:45` **Meredith Lamb (+14169386001)**

I already asked ChatGPT


**306.** `22:45` **Meredith Lamb (+14169386001)**

I mean, if I’m honest I’ve been thinking about it


**307.** `22:45` **Meredith Lamb (+14169386001)**

And it is probably my fault


**308.** `22:46` **You**

>
Nothing is your fault

*💬 Reply*

**309.** `22:46` **Meredith Lamb (+14169386001)**

I thought about it and thought back\. When you left and we were no longer working together I missed it\. So then when the opportunity arose, off I went\. Maybe a mistake\.


**310.** `22:47` **Meredith Lamb (+14169386001)**

But can’t turn back the clock lol


**311.** `22:47` **Meredith Lamb (+14169386001)**

And…\. I mean, our situations were unravelling regardless


**312.** `22:47` **You**

I mean I wa surprised


**313.** `22:47` **You**

Honestly


**314.** `22:48` **You**

I thought you were fucking with me


**315.** `22:48` **Meredith Lamb (+14169386001)**

lol I know\. So weird


**316.** `22:48` **You**

But that was before the letter


**317.** `22:48` **You**

The letter happened after I hired you


**318.** `22:48` **You**

I thought


**319.** `22:48` **Meredith Lamb (+14169386001)**

What letter


**320.** `22:48` **You**

Sorry text


**321.** `22:48` **Meredith Lamb (+14169386001)**

Oh text


**322.** `22:49` **Meredith Lamb (+14169386001)**

Yeah for sure after


**323.** `22:49` **Meredith Lamb (+14169386001)**

Kind of at the same time maybe


**324.** `22:49` **You**

I you came to my team before the text I thought


**325.** `22:49` **Meredith Lamb (+14169386001)**

Not sure


**326.** `22:49` **You**

I dunno doesn’t matter


**327.** `22:49` **Meredith Lamb (+14169386001)**

Text was before thanksgiving


**328.** `22:49` **You**

I am j just thankful


**329.** `22:50` **Meredith Lamb (+14169386001)**

Same


**330.** `22:50` **You**

https://open\.spotify\.com/track/6pwhSBxhaF5x0WbNZRyzlD?si=mCH0lKDaSA6T9Y33AwZ0Ig


**331.** `22:50` **You**

Reaction: ❤️ from Meredith Lamb
There was a reason I picked this song


**332.** `22:53` **Meredith Lamb (+14169386001)**

Every song very much speaks to me


**333.** `22:54` **Meredith Lamb (+14169386001)**

So no listening to music with cote lol


**334.** `22:55` **You**

Rofl


**335.** `22:55` **Meredith Lamb (+14169386001)**

Are you going to wish that you dated more after you separated? You are Totally rebounding


**336.** `22:55` **You**

I am not rebounding


**337.** `22:55` **You**

We just agreed


**338.** `22:55` **You**

This is literally
The real thing


**339.** `22:56` **Meredith Lamb (+14169386001)**

I believe so\.


**340.** `22:56` **You**

I am 46 I am looking for real I don’t want bullshit


**341.** `22:57` **You**

So that is why no regrets


**342.** `22:57` **You**

Ever


**343.** `22:57` **You**

You on the other hand I wonder same thing


**344.** `22:57` **Meredith Lamb (+14169386001)**

I know I’m not rebounding because I have done it before\.


**345.** `22:58` **Meredith Lamb (+14169386001)**

This is different\.


**346.** `22:58` **Meredith Lamb (+14169386001)**

This is strange though\. Lol


**347.** `22:59` **You**

Yep I will Agee with you in that\. The missing you when you are right there is real\.\. again I am trying to chart a path to what I hope we both want and I am happy to be patient\.


**348.** `23:00` **You**

Because after\. Short time there will be a long time


**349.** `23:00` **You**

and the long time will be goood


**350.** `23:01` **Meredith Lamb (+14169386001)**

I mean I agree and think we could be really great long term


**351.** `23:02` **Meredith Lamb (+14169386001)**

I can actually envision it


**352.** `23:02` **You**

Same I do it often


**353.** `23:02` **You**

Jealousy is real too I get it for both of us


**354.** `23:02` **You**

But it doesn’t have to be\.


**355.** `23:02` **Meredith Lamb (+14169386001)**

>
I mean this will wear as time goes on

*💬 Reply*

**356.** `23:02` **You**

To be honest I am not worried about you I am worried about him\.


**357.** `23:03` **You**

Not once we are out


**358.** `23:03` **You**

And that won’t be too too long


**359.** `23:03` **Meredith Lamb (+14169386001)**

Yeah \.\.


**360.** `23:04` **You**

Reaction: 😂 from Meredith Lamb
It won’t be we are doing taxes tomorrow and will start o\. Spreadsheet


**361.** `23:04` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**362.** `23:04` **Meredith Lamb (+14169386001)**

>
But like some time together would be nice

*💬 Reply*

**363.** `23:04` **Meredith Lamb (+14169386001)**

lol


**364.** `23:05` **You**

Sat


**365.** `23:05` **You**

Sunday


**366.** `23:05` **You**

Monday


**367.** `23:05` **Meredith Lamb (+14169386001)**

Monday 🤨


**368.** `23:05` **You**

Yeah Monday 😆


**369.** `23:05` **Meredith Lamb (+14169386001)**

😫


**370.** `23:06` **You**

Take a day I\. Lieu next day go visit your friend reason to stay over


**371.** `23:06` **Meredith Lamb (+14169386001)**

I have not booked Monday night


**372.** `23:06` **You**

You still can 🙂


**373.** `23:06` **Meredith Lamb (+14169386001)**

…Yet


**374.** `23:07` **Meredith Lamb (+14169386001)**

We will see


**375.** `23:07` **Meredith Lamb (+14169386001)**

I feel like I’ve been so unfocused and unproductive through all this separation crap that I don’t need ANOTHER unproductive day


**376.** `23:08` **Meredith Lamb (+14169386001)**

You know I’m taking Friday off to drive to Detroit also


**377.** `23:09` **You**

Reaction: 😋 from Meredith Lamb
But a productive night would be good for your mental health


**378.** `23:09` **You**

You owe it to yourself


**379.** `23:10` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/5zlX0L3O8UC3N7L20djEFw?si=N2XD9EN9RryRiDERqp1yOQ
One of my favourite songs right now\. Totally forgot about it until you put it on that playlist


**380.** `23:11` **You**

Just watching house with maddie will listen right after almost done


**381.** `23:12` **Meredith Lamb (+14169386001)**

>
You don’t need to\. You put it in the playlist lol

*💬 Reply*

**382.** `23:12` **Meredith Lamb (+14169386001)**

>
Hmmmm we’ll see\.

*💬 Reply*

**383.** `23:14` **You**

I owe it to yourself\!\! lol


**384.** `23:15` **Meredith Lamb (+14169386001)**

The problem is you are hard to resist\. Will decide tomorrow\.


**385.** `23:15` **You**

So I should really pour it on is what you are saying


**386.** `23:15` **Meredith Lamb (+14169386001)**

No we good lol


**387.** `23:17` **Meredith Lamb (+14169386001)**

So why do you think kids are so stuck on parents meeting someone else? Just bc they hold out hope the rents will get back together


**388.** `23:17` **Meredith Lamb (+14169386001)**

I’m lucky\. Mac is in a different place


**389.** `23:17` **You**

Reaction: ❤️ from Meredith Lamb
Hrm I am still thinking about pouring it on


**390.** `23:17` **Meredith Lamb (+14169386001)**

Saturday


**391.** `23:18` **You**

Everyday


**392.** `23:18` **You**

lol


**393.** `23:19` **Meredith Lamb (+14169386001)**

Saturday


**394.** `23:19` **You**

I don’t know where they are at\. On anything I think they will be more accepting


**395.** `23:20` **You**

You cannot stop me from smiling or looking at you tomorrow


**396.** `23:24` **Meredith Lamb (+14169386001)**

Now now


**397.** `23:25` **Meredith Lamb (+14169386001)**

We probably already have the CR peeps talking


**398.** `23:29` **You**

Ok I will try
To be good but no promises about whe\. They are not there


**399.** `23:31` **Meredith Lamb (+14169386001)**

k that’s fine lol


**400.** `23:33` **Meredith Lamb (+14169386001)**

I’m going to go to bed\. Thanks for clarifying the cryptic messages tonight\. I really love you 😬


**401.** `23:33` **You**

What did you delete earlier


**402.** `23:33` **You**

I really love you too\.\.


**403.** `23:33` **Meredith Lamb (+14169386001)**

I already told you


**404.** `23:33` **You**

A lot


**405.** `23:33` **Meredith Lamb (+14169386001)**

And I didn’t like your answer but whatever, is what it is


**406.** `23:34` **You**

lol what answer


**407.** `23:34` **You**

I am confused now


**408.** `23:35` **You**

Coming to
Your place


**409.** `23:35` **You**

If and when everyone knows about us I will be at your place whenever you will have me


**410.** `23:35` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**411.** `23:35` **Meredith Lamb (+14169386001)**

>
Yeah

*💬 Reply*

**412.** `23:36` **You**

Yeah I was speaking about being careful


**413.** `23:36` **You**

Not that wouldn’t want to come I would want to every night


**414.** `23:36` **You**

Like that is the honest truth\.\. but like you said complicated for a bit


**415.** `23:37` **You**

And I did suggest even if it was complicated I would find ways to:\) just couldn’t be all the time until things were less
Complicated


**416.** `23:37` **You**

I want to spend my future with you mer\.\. no doubt I don’t want to fuck it up


**417.** `23:39` **Meredith Lamb (+14169386001)**

I know, same\.


**418.** `23:40` **You**

So we will get
Lots
And lots of nights we just need to take what we can get
For now\.


**419.** `23:41` **You**

Kk love
You so much and I will show you soon\.\. if my overtures
Already have not done that\.\. in a way I feel
Like they should show you how I feel more than anything else
Could


**420.** `23:41` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
They do… you do… I wish I could articulate the same to you but just trust me\. Xo


**421.** `23:42` **You**

Reaction: ❤️ from Meredith Lamb
Nite mer I trust you xoxo\.  See you in Morning\.


