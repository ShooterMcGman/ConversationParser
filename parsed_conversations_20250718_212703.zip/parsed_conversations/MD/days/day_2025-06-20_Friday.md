# Daily Conversation: 2025-06-20 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-20 |
| **Day** | Friday |
| **Week** | 10 |
| **Messages** | 485 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-20T04:43 - 2025-06-20T22:36 |

## 📝 Daily Summary

This day contains **485 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:43` **You**

1 more sleep still seems so far away\.    Hope the day goes by fast\.  Getting up to hit the gym again \.\. man 6 days on Eesh\.\.


**002.** `04:44` **You**

Reaction: ❤️ from Meredith Lamb
I love you\.\.  hope you have a great morning and a great workout\.  Will chat with you a bit later\. ❤️❤️❤️❤️❤️


**003.** `07:01` **Meredith Lamb (+14169386001)**

Bit late this morning\. Lol sore and tired\. Omg


**004.** `07:14` **You**

Hungover


**005.** `07:14` **You**

Too maybe


**006.** `07:14` **You**

I had a late start too just not as late as you


**007.** `07:14` **You**

lol


**008.** `07:23` **Meredith Lamb (+14169386001)**

Maybe a little hungover but not a lot\. Lol but maybe a little


**009.** `07:23` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Worth it tho


**010.** `07:23` **You**

ROFL


**011.** `08:28` **Meredith Lamb (+14169386001)**

Hungover but still did an arms workout\. BUT I workout like shit after drinking now\. Old\. I gotta quit it during the week\. Fucks up the workout way more than it used to…\. 🫤

*📎 1 attachment(s)*

**012.** `08:48` **You**

lol


**013.** `08:48` **You**

Emoji matches


**014.** `08:48` **You**

Just getting dressed now was a nice core and cardio morning


**015.** `08:48` **You**

With some stretching


**016.** `08:54` **Meredith Lamb (+14169386001)**

Omg I can’t stretch\. Too sore lol


**017.** `08:54` **You**

I need to stretch hip flexors bad


**018.** `08:54` **You**

So I spent 10 mins on those


**019.** `10:38` **Meredith Lamb (+14169386001)**

Was talking to Jim\. I’m sure you noticed lol


**020.** `10:39` **Meredith Lamb (+14169386001)**

We talked about you fyi haha


**021.** `10:40` **You**

😢


**022.** `10:40` **You**

I wasn't checking up on you\.\. I was talking to CM and you both dinged\.\. so yeah kinda


**023.** `10:40` **Meredith Lamb (+14169386001)**

lol it was good


**024.** `10:40` **You**

sure sure


**025.** `10:40` **Meredith Lamb (+14169386001)**

I think he is no longer like concerned about us\. Seems full acceptance mode now


**026.** `10:40` **Meredith Lamb (+14169386001)**

Something has switched


**027.** `10:41` **You**

Hmm?


**028.** `10:44` **Meredith Lamb (+14169386001)**

Hmm?


**029.** `10:45` **You**

Reaction: ❤️ from Meredith Lamb
Meant to share… baby abs\. ☹️ got a ways to go there

*📎 1 attachment(s)*

**030.** `10:46` **Meredith Lamb (+14169386001)**

Gah


**031.** `10:47` **You**

gah what


**032.** `10:52` **Meredith Lamb (+14169386001)**

Just a lot to process when we are only 24 hrs ish away from seeing each other


**033.** `10:53` **Meredith Lamb (+14169386001)**

Photos make me want to see you immediately\. So I need to look away and work


**034.** `10:53` **Meredith Lamb (+14169386001)**

lol


**035.** `10:54` **You**

>
I talked to him yesterday a bit about all the shit J and I were going through\.\. and mentioned that our situation didn't help things \- more like the idea of our situation\.

*💬 Reply*

**036.** `10:54` **You**

>
don't worry no more coming\.

*💬 Reply*

**037.** `10:55` **Meredith Lamb (+14169386001)**

>
Yeah he mentioned…

*💬 Reply*

**038.** `10:56` **You**

so i don't know what has changed


**039.** `10:56` **Meredith Lamb (+14169386001)**

Time… probably talking to me more too now that we sit closer\. He has more context


**040.** `10:58` **You**

>
kk well I am happy he is more accepting for sure\.\. felt weird\.\.

*💬 Reply*

**041.** `11:02` **Meredith Lamb (+14169386001)**

Did it feel better when you talked to him yday?


**042.** `11:02` **You**

I mean kinda


**043.** `11:02` **Meredith Lamb (+14169386001)**

“Kinda”


**044.** `11:03` **You**

I wouldn't say back to old Jim and Scott


**045.** `11:03` **Meredith Lamb (+14169386001)**

Well that might not happen immediately


**046.** `11:04` **Meredith Lamb (+14169386001)**

I think he has learned a lot about j from you that he didn’t know before


**047.** `11:04` **Meredith Lamb (+14169386001)**

So he is sort of processing some of that it seems


**048.** `11:04` **You**

ah ok


**049.** `11:04` **Meredith Lamb (+14169386001)**

I think he had a different view of your relationship before


**050.** `11:04` **Meredith Lamb (+14169386001)**

Not sure if you ever painted it fully to him prior?


**051.** `11:05` **You**

Probably not


**052.** `11:05` **Meredith Lamb (+14169386001)**

Doesn’t sound like it


**053.** `11:05` **Meredith Lamb (+14169386001)**

So he’s a bit confused on some stuff


**054.** `11:05` **Meredith Lamb (+14169386001)**

As was I tbh


**055.** `11:05` **You**

what were you confused on?


**056.** `11:05` **Meredith Lamb (+14169386001)**

Like why you two were together, etc etc etc etc


**057.** `11:06` **You**

you were confused about why J and I were together\.\. from when\.\. from back when you met me


**058.** `11:06` **You**

just didn't see the match?


**059.** `11:23` **Meredith Lamb (+14169386001)**

Well yeah kinda\. I think Jim is wondering also


**060.** `11:25` **Meredith Lamb (+14169386001)**

I think he is just processing


**061.** `11:25` **Meredith Lamb (+14169386001)**

I’m not to be clear


**062.** `11:26` **You**

You are processing other things\.\. always processing… still processing…


**063.** `11:27` **You**

Oh don’t forget to text Katie that you can’t talk to her lol


**064.** `11:47` **Meredith Lamb (+14169386001)**

What’s her number again? I don’t want to scroll up


**065.** `11:57` **You**

\+1 \(506\) 850\-6001


**066.** `13:02` **Meredith Lamb (+14169386001)**

Talking to Anna in a couple minutes


**067.** `13:02` **Meredith Lamb (+14169386001)**

Talked to Erin today and did not get the sense that she is mad at you\. Just frustrated on the ai thing\. I can update u later


**068.** `13:14` **You**

kk


**069.** `13:14` **You**

I told katie you would reach out


**070.** `13:14` **You**

:P


**071.** `13:15` **Meredith Lamb (+14169386001)**

I did


**072.** `13:16` **You**

kk


**073.** `15:16` **Meredith Lamb (+14169386001)**

Went and saw that condo


**074.** `15:16` **Meredith Lamb (+14169386001)**

Very tiny but Mac loved it


**075.** `15:19` **You**

nice


**076.** `15:19` **You**

well small isn't


**077.** `15:19` **You**

but w/e


**078.** `15:22` **Meredith Lamb (+14169386001)**

Yeah not sure how I feel about it\.


**079.** `15:23` **You**

>
why

*💬 Reply*

**080.** `15:24` **Meredith Lamb (+14169386001)**

So small


**081.** `15:28` **You**

Reaction: ❓ from Meredith Lamb
I mean\.\. nm


**082.** `15:28` **You**

lol


**083.** `15:29` **You**

nothing was going to make a joke\.\. but was like naw\.


**084.** `15:30` **Meredith Lamb (+14169386001)**

🫩


**085.** `15:30` **You**

>
see I don't know what that is

*💬 Reply*

**086.** `15:30` **Meredith Lamb (+14169386001)**

Not amused


**087.** `15:31` **Meredith Lamb (+14169386001)**

lol


**088.** `15:31` **Meredith Lamb (+14169386001)**

Was literally talking about a condo


**089.** `15:31` **Meredith Lamb (+14169386001)**

And you take it…


**090.** `15:31` **You**

I am a boy\!\!\!


**091.** `15:31` **You**

comeon


**092.** `15:31` **You**

that is what we do\.\. cause we are dumb and immature


**093.** `15:31` **You**

AND I am bored


**094.** `15:31` **You**

doing more legal shit all day


**095.** `15:32` **You**

If it is too small it is too small\.\. I am a functional person and I don't need a lot of space\.\. but with three kids\.\. different story


**096.** `15:32` **You**

plus


**097.** `15:32` **You**

you might like a place easier for dogs


**098.** `15:32` **You**

see I can be serious


**099.** `15:32` **You**

:P


**100.** `15:32` **Meredith Lamb (+14169386001)**

>
I know \- hence the unamused face lol

*💬 Reply*

**101.** `15:33` **You**

>
well that is part of who I am\.\. so 🤪

*💬 Reply*

**102.** `15:34` **Meredith Lamb (+14169386001)**

>
Yeah\. There is a third floor terrace for dogs though lol

*💬 Reply*

**103.** `15:34` **You**

hmm\.\. I mean I was thinking already small space 3 kids you and 2 big dogs\.


**104.** `15:35` **Meredith Lamb (+14169386001)**

Rosie wouldn’t be able to go to that place


**105.** `15:35` **Meredith Lamb (+14169386001)**

Too busy of an area


**106.** `15:35` **You**

yeah you said that


**107.** `15:35` **Meredith Lamb (+14169386001)**

She’d freak out


**108.** `15:35` **You**

so do the house with no basement?


**109.** `15:35` **You**

still too small?


**110.** `15:36` **Meredith Lamb (+14169386001)**

Going to consider something else


**111.** `15:36` **You**

just something else or something else specific


**112.** `15:36` **You**

are you cranky today by any chance?


**113.** `16:18` **Meredith Lamb (+14169386001)**

First time driving somewhere with Andrew in FOREVER\. omg how do you do this…\.?


**114.** `16:18` **Meredith Lamb (+14169386001)**

Painful


**115.** `16:23` **You**

Um well I usually drive and again j and I have this kind of anti emotional agnostic relationship\.\. not really even friends more like roommates we have had it for years


**116.** `16:26` **Meredith Lamb (+14169386001)**

30 min drive\. Ugggh


**117.** `16:27` **You**

ROFL aww you can bond and have long conversations about better times


**118.** `16:31` **Meredith Lamb (+14169386001)**

🙄


**119.** `16:34` **You**

Yeah those drives they bring you closer


**120.** `16:35` **You**

Especially the longer ones


**121.** `16:43` **You**

🥰


**122.** `17:05` **Meredith Lamb (+14169386001)**

lol not exactly\. Been a little tense\.


**123.** `17:17` **You**

Aww that sucks


**124.** `17:22` **You**

Then you get to sit side by side all night


**125.** `17:34` **Meredith Lamb (+14169386001)**

Better not be all night omg


**126.** `17:37` **You**

lol


**127.** `17:37` **You**

I bet wine when you get home too much you get hung over maybe I see you by noon?? There isn’t a sad laugh emoticon…\. I hope you don’t have a bad night honestly


**128.** `17:41` **Meredith Lamb (+14169386001)**

I am not going to be late tomorrow\. You will see\.


**129.** `17:44` **You**

Ok we will both see


**130.** `17:47` **You**

Only 3 hours left


**131.** `17:49` **Meredith Lamb (+14169386001)**

Dayne is peaking now


**132.** `17:50` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**133.** `17:53` **You**

Mmmmmmmmm Dayne\!\!\!\!


**134.** `17:54` **You**

Those glasses…\. Phew


**135.** `17:54` **You**

I remember what you told me\.\. lol


**136.** `17:56` **You**

You give me a rolled eyes emoji later


**137.** `17:56` **Meredith Lamb (+14169386001)**

🤓


**138.** `18:14` **Meredith Lamb (+14169386001)**

I kinda forgot to eat today\. Was busy\. Struggling now\. Ugh


**139.** `18:19` **You**

Mm that sucks sorry mer\.


**140.** `18:19` **You**

I have been working all day so tired


**141.** `18:22` **Meredith Lamb (+14169386001)**

You should have napped\!


**142.** `18:23` **You**

Nope go to bed early save energy


**143.** `18:26` **You**

If I napped I would be up too late


**144.** `18:29` **Meredith Lamb (+14169386001)**

About half way done here 😩


**145.** `18:31` **You**

Ooof


**146.** `18:31` **You**

That really sucks


**147.** `18:31` **Meredith Lamb (+14169386001)**

Not sure where she is…\. But we are in the same massive room

*📎 1 attachment(s)*

**148.** `18:31` **You**

Specially when you are tired and hungry


**149.** `18:31` **You**

Hahah you both on same page


**150.** `18:42` **You**

how much yawning are you doing vs stomach grumbling?


**151.** `18:43` **Meredith Lamb (+14169386001)**

I’m actually not even hungry per se \(💉\) I think it had just affected my energy and mood\. Yawning is out of control…\.


**152.** `18:43` **You**

hrm\.\. that sucks\.\. man that medication is really doing a job on you\.


**153.** `18:44` **You**

messing up all kinds of shit\.


**154.** `18:44` **Meredith Lamb (+14169386001)**

I mean it is pretty good stuff tho lol


**155.** `18:44` **You**

mmm true


**156.** `18:45` **Meredith Lamb (+14169386001)**

Given me a big head start …\.


**157.** `18:45` **Meredith Lamb (+14169386001)**

Omg on the last class


**158.** `18:45` **You**

I think you are doing great\.\. just bet the side effects suck'


**159.** `18:45` **You**

>
lol

*💬 Reply*

**160.** `18:56` **You**

there is some stuff in here I don't understand


**161.** `18:58` **Meredith Lamb (+14169386001)**

Really


**162.** `18:59` **You**

yeah just how they treated some of the assets I guess\. but it probably doesn't matter\.\.


**163.** `19:00` **Meredith Lamb (+14169386001)**

Omg special awards done\. Now valedictorian


**164.** `19:00` **Meredith Lamb (+14169386001)**

Gahhhhh


**165.** `19:01` **You**

>
lol

*💬 Reply*

**166.** `19:02` **You**

almost done then another nice drive


**167.** `19:21` **Meredith Lamb (+14169386001)**

On way home …\.


**168.** `19:22` **You**

nice\.\.\. quiet drive\.\. bet you are looking forward to a glass


**169.** `19:24` **Meredith Lamb (+14169386001)**

Yes, one and pizza


**170.** `19:31` **You**

Yeah food you def need that


**171.** `19:55` **Meredith Lamb (+14169386001)**

Oh my God, never driving anywhere together ever again


**172.** `19:55` **Meredith Lamb (+14169386001)**

So I don’t think he’s happy with the numbers and he keeps asking me 1 million times if I’m satisfied


**173.** `19:56` **Meredith Lamb (+14169386001)**

So he finally asked me again and I’m like OK\. I’m sensing that you’re not happy and you wanna negotiate and he says no I just want acknowledgment that my proposal is … and I left\.


**174.** `19:56` **Meredith Lamb (+14169386001)**

Basically, he wants me to tell him that I think he’s giving me more money than he needs to


**175.** `19:56` **Meredith Lamb (+14169386001)**

So he wants acknowledgement when he won’t acknowledge shit for me


**176.** `19:56` **Meredith Lamb (+14169386001)**

I will be acknowledging nothing


**177.** `19:56` **Meredith Lamb (+14169386001)**

So fucking pissed off


**178.** `19:57` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**179.** `20:03` **You**

Errrrrr


**180.** `20:03` **You**

Sorry kinda figure this was coming why I asked earlier


**181.** `20:07` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 20 Jun 2025 20:07:53 \-0400
|
| He is just so mad he has to give me money\.
|
| Version: 1
| Sent: Fri, 20 Jun 2025 20:07:45 \-0400
|
| He is just so mad he had to give me money\.


**182.** `20:08` **Meredith Lamb (+14169386001)**

And he thinks I don’t care about his situation


**183.** `20:08` **Meredith Lamb (+14169386001)**

\(He has to cash in his rrsps and won’t have any safety net if he loses his job\. It is stressing him out\.\)


**184.** `20:08` **Meredith Lamb (+14169386001)**

And I get that


**185.** `20:09` **Meredith Lamb (+14169386001)**

It is stressful


**186.** `20:09` **Meredith Lamb (+14169386001)**

But it is just reality


**187.** `20:09` **Meredith Lamb (+14169386001)**

If he loses his job we pivot and adjust


**188.** `20:09` **Meredith Lamb (+14169386001)**

Like geez


**189.** `20:11` **You**

Yeah see j is more flex like that way


**190.** `20:11` **You**

Just hates me and wants me to die


**191.** `20:11` **Meredith Lamb (+14169386001)**

I think I’d rather have this


**192.** `20:11` **Meredith Lamb (+14169386001)**

The wanting to die triggers me


**193.** `20:12` **Meredith Lamb (+14169386001)**

>
I read this as “wants to die” because of your situation the other night

*💬 Reply*

**194.** `20:13` **Meredith Lamb (+14169386001)**

I don’t think she would REALLY want you to die


**195.** `20:13` **Meredith Lamb (+14169386001)**

lol


**196.** `20:13` **Meredith Lamb (+14169386001)**

I wouldn’t want Andrew to


**197.** `20:13` **Meredith Lamb (+14169386001)**

Even though I can’t stand him


**198.** `20:18` **You**

No I don’t think she actually wants that\.\. she is the one that wouldnt ask for more because she believes there needs to be balance


**199.** `20:18` **You**

But she sure as hell hates me


**200.** `20:24` **Meredith Lamb (+14169386001)**

Yeah this reaction has made me glad I didn’t tell him about us\.


**201.** `20:25` **Meredith Lamb (+14169386001)**

I think he is going to feel the same\. 😬


**202.** `20:26` **You**

Whatever


**203.** `20:26` **You**

He didn’t deserve you ffs


**204.** `20:26` **You**

And I am not just saying that cause I love you


**205.** `20:26` **Meredith Lamb (+14169386001)**

>
Sure… lol\.
The only thing, if he hates hates me, it might mess with is cottage coordination\.

*💬 Reply*

**206.** `20:27` **You**

Well I am sure we can work it out


**207.** `20:27` **Meredith Lamb (+14169386001)**

Yeah and he is now saying he likely won’t be in a position to buy me out


**208.** `20:27` **Meredith Lamb (+14169386001)**

So we would have to sell


**209.** `20:28` **Meredith Lamb (+14169386001)**

Or have his mom buy in


**210.** `20:28` **Meredith Lamb (+14169386001)**

Which is fine


**211.** `20:28` **Meredith Lamb (+14169386001)**

I’m fine keeping for the time being


**212.** `20:28` **You**

Mmm hmmm


**213.** `20:28` **You**

lol


**214.** `20:28` **Meredith Lamb (+14169386001)**

I don’t want to stress him out toooooooo much


**215.** `20:28` **You**

Save this page


**216.** `20:28` **Meredith Lamb (+14169386001)**

He is so miserable right now


**217.** `20:28` **Meredith Lamb (+14169386001)**

>
Wdym

*💬 Reply*

**218.** `20:29` **You**

The cottage


**219.** `20:31` **You**

I think you might look back and go oops


**220.** `20:31` **Meredith Lamb (+14169386001)**

Oops to 50/50?


**221.** `20:32` **You**

Oops to this didnt work out like I thought


**222.** `20:33` **Meredith Lamb (+14169386001)**

Well I don’t think it will work out great but the cottage market is shit right now


**223.** `20:33` **Meredith Lamb (+14169386001)**

We would lose money if we tried to sell


**224.** `20:33` **Meredith Lamb (+14169386001)**

And it would take forever


**225.** `20:33` **You**

Yep I get it\.\. I could buy half


**226.** `20:33` **You**

lol


**227.** `20:33` **Meredith Lamb (+14169386001)**

In a normal market probably worth $1\.5m


**228.** `20:34` **Meredith Lamb (+14169386001)**

Based on comparables on lake


**229.** `20:34` **Meredith Lamb (+14169386001)**

But not in this market


**230.** `20:34` **Meredith Lamb (+14169386001)**

Cottage slump right now


**231.** `20:34` **You**

Mm yeah I could buy half I could buy you out then Andrew and I coukd be cottage buddies


**232.** `20:35` **Meredith Lamb (+14169386001)**

Omg


**233.** `20:35` **Meredith Lamb (+14169386001)**

You will never be any kind of buddies lol


**234.** `20:36` **You**

Supper duper buddies


**235.** `20:37` **Meredith Lamb (+14169386001)**

No words


**236.** `20:37` **You**

I just want to make your life easier


**237.** `20:37` **You**

Willing to do anything


**238.** `20:37` **You**

lol


**239.** `20:38` **Meredith Lamb (+14169386001)**

lol you being buddies does not equal easier life lol


**240.** `20:39` **You**

I think it would


**241.** `20:39` **Meredith Lamb (+14169386001)**

No def not


**242.** `20:39` **Meredith Lamb (+14169386001)**

Anyone who is buddies with him I don’t like


**243.** `20:39` **Meredith Lamb (+14169386001)**

It would be a total turn off


**244.** `20:40` **You**

Ok enemies\.\. I will crush him mentally\.


**245.** `20:40` **Meredith Lamb (+14169386001)**

lol


**246.** `20:40` **Meredith Lamb (+14169386001)**

That turned quickly


**247.** `20:40` **You**

Like I said whatever youneant


**248.** `20:40` **You**

You want


**249.** `20:41` **Meredith Lamb (+14169386001)**

Geez, where have you been all my life? Anything I want


**250.** `20:41` **Meredith Lamb (+14169386001)**

🤔


**251.** `20:41` **You**

Yep


**252.** `20:41` **You**

Anything


**253.** `20:41` **Meredith Lamb (+14169386001)**

Wow


**254.** `20:43` **You**

So any ideas


**255.** `20:43` **You**

Priorities


**256.** `20:43` **Meredith Lamb (+14169386001)**

Priority \#1 tomorrow


**257.** `20:44` **You**

So what am I doing tomorrow


**258.** `20:44` **You**

???


**259.** `20:45` **You**

You have to be specific


**260.** `20:45` **Meredith Lamb (+14169386001)**

It’s funny because I feel so desperate for time with you I have no specificity …


**261.** `20:45` **Meredith Lamb (+14169386001)**

Beggars can’t be choosers


**262.** `20:46` **You**

Well we have a full day all day


**263.** `20:46` **Meredith Lamb (+14169386001)**

And it will feel like 10 minutes


**264.** `20:46` **You**

Ummm well maybe after


**265.** `20:46` **Meredith Lamb (+14169386001)**

I meant the whole day


**266.** `20:46` **You**

Yeah I know


**267.** `20:46` **You**

But then next weekend


**268.** `20:47` **You**

That’s almost 5 days


**269.** `20:47` **Meredith Lamb (+14169386001)**

Yes that is what we need\. I wish that started tomorrow


**270.** `20:47` **Meredith Lamb (+14169386001)**

But it’s ok


**271.** `20:47` **You**

What we need is every day


**272.** `20:48` **You**

And joy


**273.** `20:48` **Meredith Lamb (+14169386001)**

I have to update Jim after you meet my folks 🤣


**274.** `20:48` **Meredith Lamb (+14169386001)**

I have to


**275.** `20:48` **You**

lol


**276.** `20:48` **Meredith Lamb (+14169386001)**

Not you


**277.** `20:48` **You**

I am scared


**278.** `20:48` **Meredith Lamb (+14169386001)**

lol


**279.** `20:48` **Meredith Lamb (+14169386001)**

Today mac was like “I can’t imagine introducing one of my bfs to Nan”


**280.** `20:48` **Meredith Lamb (+14169386001)**

She says weird things sometimes


**281.** `20:49` **You**

Hehe well she will get a kick out of it I am sure


**282.** `20:50` **Meredith Lamb (+14169386001)**

She will be awkward\. I will enjoy that


**283.** `20:50` **You**

I am going to hug her and call her mom


**284.** `20:50` **Meredith Lamb (+14169386001)**

😇


**285.** `20:51` **Meredith Lamb (+14169386001)**

>
She will die

*💬 Reply*

**286.** `20:51` **Meredith Lamb (+14169386001)**

Literally


**287.** `20:51` **Meredith Lamb (+14169386001)**

lol


**288.** `20:51` **You**

Maybe hug then


**289.** `20:51` **Meredith Lamb (+14169386001)**

Same


**290.** `20:51` **Meredith Lamb (+14169386001)**

She doesn’t hug


**291.** `20:51` **Meredith Lamb (+14169386001)**

Ever


**292.** `20:51` **Meredith Lamb (+14169386001)**

Like never


**293.** `20:53` **You**

Big hug incoming then


**294.** `20:53` **You**

Warn her


**295.** `20:54` **You**

Tell her I am a hugger


**296.** `20:54` **Meredith Lamb (+14169386001)**

I will do no such thing


**297.** `20:54` **Meredith Lamb (+14169386001)**

I didn’t even get a chance to talk to her today


**298.** `20:54` **Meredith Lamb (+14169386001)**

Turned into a busy day


**299.** `20:54` **You**

Ok she will just have to take it then


**300.** `20:54` **Meredith Lamb (+14169386001)**

I talked to Anna for an hour


**301.** `20:54` **Meredith Lamb (+14169386001)**

FYI


**302.** `20:55` **Meredith Lamb (+14169386001)**

She was shocked we talked the whole time\. I had to go to get to the condo and she was like “wow im surprised we talked this whole time”


**303.** `20:55` **Meredith Lamb (+14169386001)**

lol


**304.** `20:55` **Meredith Lamb (+14169386001)**

She is not in favour of Julian


**305.** `20:56` **Meredith Lamb (+14169386001)**

She is not a fan of working with him on the projects she has worked on with him


**306.** `20:56` **Meredith Lamb (+14169386001)**

Interesting bc I like Julian


**307.** `20:56` **Meredith Lamb (+14169386001)**

She was very not surprised about the Pauline situation


**308.** `20:57` **Meredith Lamb (+14169386001)**

She always thought it was weird that Pauline thought it was “her job”


**309.** `20:57` **You**

So lots of chatting and gossiping


**310.** `20:57` **Meredith Lamb (+14169386001)**

Basically


**311.** `20:57` **Meredith Lamb (+14169386001)**

All the tea


**312.** `20:57` **Meredith Lamb (+14169386001)**

I’m not her supe anymore so I can do that now


**313.** `20:57` **Meredith Lamb (+14169386001)**

We are peers 😜


**314.** `20:58` **You**

ROFL


**315.** `20:59` **Meredith Lamb (+14169386001)**

She said that even tho Brianna doesn’t support her employees, as long as they are independent and have some “gumption” they are fine\. I was like “ask Ahana and Whitney what they think lol”


**316.** `20:59` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 20 Jun 2025 20:59:22 \-0400
|
| Anna said pros and cons to bri
|
| Version: 1
| Sent: Fri, 20 Jun 2025 20:59:13 \-0400
|
| Anna said pros and cons to bro


**317.** `20:59` **You**

So who does she want


**318.** `20:59` **You**

Want to know a secret


**319.** `20:59` **You**

Like you cannot say anything


**320.** `20:59` **You**

At all


**321.** `20:59` **Meredith Lamb (+14169386001)**

Ok


**322.** `20:59` **Meredith Lamb (+14169386001)**

I won’t if you tell me not to


**323.** `20:59` **You**

Matthew applied


**324.** `20:59` **Meredith Lamb (+14169386001)**

Moroso?


**325.** `21:00` **You**

Berta


**326.** `21:00` **Meredith Lamb (+14169386001)**

Oh\!


**327.** `21:00` **Meredith Lamb (+14169386001)**

Interesting


**328.** `21:00` **Meredith Lamb (+14169386001)**

He did ask a lot of questions about my job once I remember


**329.** `21:01` **Meredith Lamb (+14169386001)**

Maybe when we were standing in line forever at rc show together


**330.** `21:01` **Meredith Lamb (+14169386001)**

Are you going to interview him?


**331.** `21:01` **Meredith Lamb (+14169386001)**

Anna would die if you hired him lol


**332.** `21:01` **You**

I dunno


**333.** `21:01` **Meredith Lamb (+14169386001)**

Anna kind of indicated she might leave if Julian got it


**334.** `21:01` **Meredith Lamb (+14169386001)**

I was like 😱


**335.** `21:02` **You**

lol


**336.** `21:02` **You**

Julian not getting


**337.** `21:02` **Meredith Lamb (+14169386001)**

I had no idea she disliked him so much


**338.** `21:02` **Meredith Lamb (+14169386001)**

I don’t even think it is dislike


**339.** `21:02` **Meredith Lamb (+14169386001)**

She just doesn’t respect the way he works


**340.** `21:02` **Meredith Lamb (+14169386001)**

Anna doesn’t know Mia


**341.** `21:03` **Meredith Lamb (+14169386001)**

I think bri is something she knows


**342.** `21:03` **You**

Mia has a good chance


**343.** `21:03` **You**

Now if bailey doesnt get manager


**344.** `21:03` **You**

Hmmmm


**345.** `21:03` **Meredith Lamb (+14169386001)**

When are they deciding that


**346.** `21:03` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 20 Jun 2025 21:03:54 \-0400
|
| I didn’t even mention Bailey
|
| Version: 1
| Sent: Fri, 20 Jun 2025 21:03:39 \-0400
|
| I don’t even mention Bailey


**347.** `21:03` **You**

Soon


**348.** `21:04` **Meredith Lamb (+14169386001)**

I gave Anna a compliment and she didn’t take it


**349.** `21:04` **Meredith Lamb (+14169386001)**

Interesting


**350.** `21:04` **You**

lol


**351.** `21:05` **Meredith Lamb (+14169386001)**

I told her that after she left I noticed a gap bc she was a sr advisor the team went to as a sounding board etc and she was a great team lead and took some pressure off the supe\. She didnt think so\. I was like you are wrong\. Jacky doesn’t do it but I said he may develop into it\.


**352.** `21:06` **You**

Yeah she left a gap for sure


**353.** `21:06` **Meredith Lamb (+14169386001)**

Andrew is being so fucking annoying omg


**354.** `21:07` **You**

What


**355.** `21:07` **Meredith Lamb (+14169386001)**

>
I believe so and she didn’t\. I thought that was interesting bc she is a very confident person but couldn’t accept that compliment and just say “I appreciate that” … she disagreed with me and was all “well they just used to talk to me casually” and I was like “EXACTLY” lol

*💬 Reply*

**356.** `21:08` **You**

You don’t accept compliments


**357.** `21:08` **Meredith Lamb (+14169386001)**

I’m not getting ready for the sleepover because I fucking get ready for every sleepover and I don’t feel like I should have to tonight so now he’s all pissed off that he has to do something


**358.** `21:08` **You**

Wow


**359.** `21:09` **Meredith Lamb (+14169386001)**

He’s just mad at me right now regarding money


**360.** `21:13` **You**

Yeah I know sucks,\.


**361.** `21:15` **You**

Done watching Gracie’s movie or at least for now


**362.** `21:15` **You**

Was watching how to train your dragon


**363.** `21:15` **You**

Love that movie want to go see th slice version


**364.** `21:15` **You**

Live


**365.** `21:18` **You**

You went to go do the sleepover stuff


**366.** `21:19` **You**

I bet lol


**367.** `21:19` **Meredith Lamb (+14169386001)**

I did a bit and I’m out


**368.** `21:19` **You**

Knew it


**369.** `21:19` **Meredith Lamb (+14169386001)**

I set up snacks and cleaned a bit of Mac’s shit


**370.** `21:20` **Meredith Lamb (+14169386001)**

He can do the rest


**371.** `21:20` **You**

You are a good mom


**372.** `21:20` **Meredith Lamb (+14169386001)**

Like literally knows nothing


**373.** `21:20` **You**

Reaction: ❤️ from Meredith Lamb
And an awesome gf btw


**374.** `21:20` **You**

If i don’t say that enough


**375.** `21:20` **Meredith Lamb (+14169386001)**

This literally is most not my house anymore


**376.** `21:21` **Meredith Lamb (+14169386001)**

Yet he’s asking all these questions


**377.** `21:21` **Meredith Lamb (+14169386001)**

Gah


**378.** `21:21` **You**

Hmm??


**379.** `21:21` **Meredith Lamb (+14169386001)**

He’s upset he has to help


**380.** `21:21` **You**

What questions


**381.** `21:21` **Meredith Lamb (+14169386001)**

lol


**382.** `21:21` **Meredith Lamb (+14169386001)**

It is hard not having a full time wife


**383.** `21:21` **You**

Oh you mean he will have to do this al on his own


**384.** `21:21` **You**

Yah


**385.** `21:21` **You**

I’m a like doing it on my own


**386.** `21:21` **You**

I will have my systems


**387.** `21:21` **You**

An order to things


**388.** `21:22` **You**

Really fun stuff lol


**389.** `21:25` **Meredith Lamb (+14169386001)**

He is used to having a full\-time wife


**390.** `21:26` **Meredith Lamb (+14169386001)**

I am not used do to that so life will be no different for me


**391.** `21:26` **Meredith Lamb (+14169386001)**

He was like “are you not going to clean the basement for Maelle?”


**392.** `21:26` **Meredith Lamb (+14169386001)**

Like wtf


**393.** `21:26` **Meredith Lamb (+14169386001)**

Fuck off


**394.** `21:27` **Meredith Lamb (+14169386001)**

It is just going to be a difficult transition for him, but I think it will be fine once he gets through it\. Maybe\.


**395.** `21:27` **Meredith Lamb (+14169386001)**

Either that or he meets a sucker who does everything for him


**396.** `21:29` **You**

He might


**397.** `21:29` **You**

People chase lonely


**398.** `21:29` **You**

Money


**399.** `21:29` **You**

And security


**400.** `21:34` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 20 Jun 2025 21:34:46 \-0400
|
| So I just set up all the snacks the chips, the candy, the cupcakes, two cakes, disposable plates, knives to cut the cakes, napkins, and look at them and go …good?
|
| Version: 1
| Sent: Fri, 20 Jun 2025 21:34:10 \-0400
|
| So I just set up all the snacks the chips, the candy, the cupcakes, two cakes, disposable plates, knifes to cut the cakes, napkins, and look at them and go …good?


**401.** `21:34` **Meredith Lamb (+14169386001)**

He sighs and goes “yep”


**402.** `21:34` **Meredith Lamb (+14169386001)**

He didn’t buy any of that shit I bought that all in advance two days ago


**403.** `21:37` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28473921/117\-helendale\-avenue\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
Talked to the realtor on this one today\. I could have this place Aug 1st\. I would have to keep the mini tho bc driveway tight\.


**404.** `21:37` **Meredith Lamb (+14169386001)**

All the stuff would be gone\. Current tenants stuff


**405.** `21:38` **Meredith Lamb (+14169386001)**

Close to current home and Diana


**406.** `21:39` **You**

Sec


**407.** `21:40` **You**

Yah you could make that work


**408.** `21:40` **Meredith Lamb (+14169386001)**

I think I could make it nice maybe


**409.** `21:40` **Meredith Lamb (+14169386001)**

Lot of work but I could do it


**410.** `21:40` **You**

>
He is nowhere near ready

*💬 Reply*

**411.** `21:40` **Meredith Lamb (+14169386001)**

Especially if I don’t have kids full time


**412.** `21:40` **You**

You could I am sure\.\. I would help


**413.** `21:40` **You**

Reaction: ❤️ from Meredith Lamb
I am helpful\.\.lol


**414.** `21:41` **You**

Kind of


**415.** `21:41` **Meredith Lamb (+14169386001)**

>
No, he will find someone quickly\.

*💬 Reply*

**416.** `21:41` **Meredith Lamb (+14169386001)**

He needs help so he will have to


**417.** `21:47` **You**

lol


**418.** `21:47` **You**

Give me 10
Mins need a quick shower


**419.** `21:53` **Meredith Lamb (+14169386001)**

Omg major fight picking constantly


**420.** `21:53` **Meredith Lamb (+14169386001)**

He’s so mad


**421.** `21:54` **You**

Just sec big issue here


**422.** `21:54` **You**

While I shower


**423.** `21:54` **You**

I want you to think about


**424.** `21:54` **You**

………


**425.** `21:54` **You**

What do I wear tomorrow


**426.** `21:55` **You**

☺️


**427.** `21:55` **Meredith Lamb (+14169386001)**

Shower thoughts are actually helpful tbh


**428.** `21:55` **You**

Kk you think about shower thoughts and what I wear brb


**429.** `21:55` **Meredith Lamb (+14169386001)**

Wear regular clothes


**430.** `22:05` **You**

So much better


**431.** `22:05` **You**

So jeans


**432.** `22:05` **You**

T shirt


**433.** `22:05` **You**

Don’t you want me to look pretty for them


**434.** `22:10` **You**

>
What are you fighting about now??

*💬 Reply*

**435.** `22:16` **You**

Either you went to bed or you going to war… ☹️ or maybe helping with sleepover that would be better


**436.** `22:19` **Meredith Lamb (+14169386001)**

>
Eeek

*💬 Reply*

**437.** `22:20` **Meredith Lamb (+14169386001)**

He’s so mad at the $ I’m getting


**438.** `22:20` **You**

Are you still fighting?


**439.** `22:20` **You**

Or done


**440.** `22:20` **Meredith Lamb (+14169386001)**

Well he is “disappointed”


**441.** `22:20` **Meredith Lamb (+14169386001)**

No done now


**442.** `22:20` **You**

Ffs


**443.** `22:20` **You**

Mistake


**444.** `22:21` **Meredith Lamb (+14169386001)**

You can go to bed yunno … it’s past 8pm\. Just noticed


**445.** `22:21` **Meredith Lamb (+14169386001)**

lol


**446.** `22:21` **You**

Meh


**447.** `22:21` **You**

Getting up at 5 not 4


**448.** `22:21` **Meredith Lamb (+14169386001)**

Girls aren’t home from grad party yet


**449.** `22:21` **You**

Have some time


**450.** `22:21` **You**

You prolly want to go drink more and watch your show though


**451.** `22:22` **Meredith Lamb (+14169386001)**

I mean I’m going to finish a 3rd glass and then that’s it tonight\. Can’t be hungover tomorrow


**452.** `22:22` **Meredith Lamb (+14169386001)**

Jim was in same condition as me today lol


**453.** `22:22` **You**

You can be whatever you want tomorrow


**454.** `22:23` **You**

I will see you at 11:30 😜


**455.** `22:23` **Meredith Lamb (+14169386001)**

lol no


**456.** `22:23` **Meredith Lamb (+14169386001)**

Mac was upset bc we were arguing and Liana was over


**457.** `22:23` **Meredith Lamb (+14169386001)**

She was like “you’re being weird\!”


**458.** `22:24` **Meredith Lamb (+14169386001)**

I go “Leanna already knows I’m weird\!”


**459.** `22:24` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 20 Jun 2025 22:26:39 \-0400
|
| Then I hear Leanna start laughing in McKenzie’s bedroom
|
| Version: 1
| Sent: Fri, 20 Jun 2025 22:24:14 \-0400
|
| Then I hear Leanna start laughing and McKenzie’s bedroom


**460.** `22:24` **Meredith Lamb (+14169386001)**

lol


**461.** `22:24` **Meredith Lamb (+14169386001)**

Liana has seen me at my worst


**462.** `22:24` **Meredith Lamb (+14169386001)**

🙈


**463.** `22:26` **You**

ROFL


**464.** `22:26` **You**

Andrew needs to chill out


**465.** `22:26` **Meredith Lamb (+14169386001)**

He said he thinks he just needs to suck it up and time


**466.** `22:27` **You**

And then you tell him about me


**467.** `22:27` **Meredith Lamb (+14169386001)**

He’s like “you’re not going to propose anything different and I already agreed so…”


**468.** `22:27` **You**

🤯


**469.** `22:27` **Meredith Lamb (+14169386001)**

I knooooooooooow


**470.** `22:27` **Meredith Lamb (+14169386001)**

I wasn’t concerned until today lol


**471.** `22:28` **You**

Ok I love you mer but I want to SEEEEEEEE YOU… so


**472.** `22:28` **You**

I am going to sleep


**473.** `22:28` **You**

Because I will see you faster that way


**474.** `22:28` **You**

LOVE YOU XOXOXOXOXOX❤️❤️❤️❤️❤️❤️❤️❤️❤️


**475.** `22:29` **You**

I don’t care if it feels
Like 10 mins I will make the most of it\.


**476.** `22:32` **You**

You going to be fighting all night 😢


**477.** `22:32` **You**

Reaction: ❤️ from Meredith Lamb
Kk sleeping now love u night\.


**478.** `22:33` **Meredith Lamb (+14169386001)**

>
Xmas morning 🎅

*💬 Reply*

**479.** `22:34` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
I was actually talking to Mac and Liana lol we are good again

*💬 Reply*

**480.** `22:34` **Meredith Lamb (+14169386001)**

k, go to bed \- xoxo love you


**481.** `22:34` **You**

>
Love you most\.  ❤️

*💬 Reply*

**482.** `22:35` **Meredith Lamb (+14169386001)**

>
Don’t start this, you won’t win\. Lol

*💬 Reply*

**483.** `22:35` **You**

Reaction: 😜 from Meredith Lamb
That’s why I skipped more\.


**484.** `22:35` **You**

And I would win\.\. night hon\.\.


**485.** `22:36` **Meredith Lamb (+14169386001)**

>
Nite ❤️

*💬 Reply*

