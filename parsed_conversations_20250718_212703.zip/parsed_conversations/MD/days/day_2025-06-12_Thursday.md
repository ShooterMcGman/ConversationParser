# Daily Conversation: 2025-06-12 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-12 |
| **Day** | Thursday |
| **Week** | 9 |
| **Messages** | 353 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-12T04:14 - 2025-06-12T22:29 |

## 📝 Daily Summary

This day contains **353 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:14` **You**

Reaction: 😮 from Meredith Lamb
Ok so here is your happy message ROFL Gracie cam banging on basement at 2
Am because she couldn’t log onto some streaming service and screamed at me because I wouldn’t give her access to my account\.\. then everyone woke up and the fun began lol\.\. so a little low on sleep today\.\. but up and going regardless because fucking bring it universe\!\!


**002.** `04:14` **You**

😀 anyhow off I go lol


**003.** `04:14` **You**

Love you mer\! Hope your night was better than mine


**004.** `05:07` **Meredith Lamb (+14169386001)**

Omg that sounds BRUTAL\!


**005.** `05:08` **You**

Reaction: ❤️ from Meredith Lamb
No it was awesome but I am up and going and heading out the door to crush it\.\. lol\.


**006.** `05:08` **Meredith Lamb (+14169386001)**

But good morning ❤️


**007.** `05:08` **You**

Same lol❤️


**008.** `05:08` **You**

It will be good\.\. hehe


**009.** `05:34` **Meredith Lamb (+14169386001)**

Are you running late? Going to park still?


**010.** `05:37` **You**

1000%


**011.** `05:38` **You**

But you don’t have to go if you don’t want to


**012.** `05:38` **Meredith Lamb (+14169386001)**

No I do was just checking


**013.** `05:38` **You**

Kk I am ok\.\.  but I will be in pain\.\. he has me doing lower body again today\.\. tomorrow is rest day\.


**014.** `06:18` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Still working on push ups everyday\. Very sad and difficult with 30 extra lbs and no muscle\. But keeping going …… 😩

*📎 1 attachment(s)*

**015.** `06:18` **Meredith Lamb (+14169386001)**

I’m done 10 min early so going to do extra tri work


**016.** `06:18` **Meredith Lamb (+14169386001)**

Not sure why I’m done early


**017.** `06:18` **You**

I am going to step machine I am done early too\.\. think I am looking forward to seeing you


**018.** `06:32` **You**

Reaction: 👍 from Meredith Lamb
Going to hit the sauna and shower


**019.** `09:00` **Meredith Lamb (+14169386001)**

I’m going to get a coffee at Tim’s so will be later than u\. FYI\.


**020.** `09:07` **You**

All good ❤️


**021.** `09:15` **Meredith Lamb (+14169386001)**

Can’t believe you expect me to sit in a room with you after that\. Lol I’m not even sure what I’m feeling but breathing seems difficult\. You know I’ve only ever been given anything of significance to someone else 3x in my life\. My mom’s gold ring from when she was 14 \(she gave to me at my grade 8 grad\), my mom made me a necklace with my kids names on it once \(I wear it all the time\) and my aunt Maggie’s ring \(my dads baby sister who died from and we were very close as she had no kids\)\. That’s really all\. You sit there and just give me these things of significance right before work lol it’s a lot to process …\.\.


**022.** `09:26` **You**

Are you mad??? lol\. I wasn’t going to see you for like a bit\.\. and after the last few days and the shift I felt in yku from a worrying perspective I wanted to reinforce what I have been saying that I am your forever\.\. and I don’t have a lot to give you\.\. but those two things mean A LOT to me\.\. one represents some of the best years of my life when joy was a real thing\. And the other is a connection to my past and  now to our future I hope\.  It isn’t a ring or jewelry per se I know you don’t want that\.  And you don’t want this long term commitments thing,
Which I would still be up for someday\.\. this had to do for me\.  And it meant a lot that you accepted it\.


**023.** `09:39` **Meredith Lamb (+14169386001)**

I am absolutely not mad, just feeling a little emotional\. That was a lot for right before work  lol


**024.** `09:40` **You**

Sorry it distracts hope the emotions are good ones and not conflicted


**025.** `10:09` **Meredith Lamb (+14169386001)**

It is good but a little bit of guilt bc of your girls\. I think it is deeper than just today also\. When my therapist said the whole “you don’t want them to hate Scott” thing\. I told her I’ve been feeling a little conflicted lately that maybe I led to your final split more than I like to think and your girls will always hate me\. I have never told you but when I started working for you I admired you so much and your work ethic etc and definitely had a crush on you\. I asked her if I subconsciously \(or otherwise\) worked to make all of this happen\.  Switching roles, telling you if the text and no one else\. Etc\. in which case your girls should hate me\. 🙁 Then you do that this morning and I’m like feeling all the things\. … thinking all the things\. Nothing is simple right now\. lol honestly it made me very happy and was really meaningful but my head can’t help but think about the rest…\.


**026.** `10:31` **You**

The kids are fine they have so much history and meaningful things that they have and will get\. They will always be a priority\. Gracie is a mess but I think truly will come around eventually, maddie will definitely\.  Jaimie would not try to poison them against you I am 1000% certain\.  I never noticed that you had a crush\.\. I noticed you I thought from the time I read your written response to the 1st essay wow this chick is smart\.  When we worked together I loved you attitude so positive can do, smart as hell, strategic can get ahead of the request and give people stuff they didn’t even know they knew\.  I loved working with you and was SUPER excited when you wanted to come over\.  Beyond that I thought you were very attractive but it was something I noticed not something that I was willing to act in because well you know\.  When you smiled at me that was what would do it\.\. that was the hardest for me to deal with and remain “in a good thinking space”\.  I was felt very empathetic for you when you told me but honestly at the time I saw you as a friend in pain and I wanted to help\. I was already down the road on my own separation\.  You didn’t make this happen you didn’t cause this you are not to blame Maddie sees this\.\. I think J does too she just lashes out\. And Gracie is just a mess on one hand saying she doesn’t care about you if I can let her stay and the opposite if she leaves I don’t think it is realistic to say where she will land atm\.


**027.** `10:31` **You**

What did she say to your question btw\.


**028.** `10:46` **Meredith Lamb (+14169386001)**

She wasn’t sure because she doesn’t have the full context of your situation so it is hard for her to really determine\. She said there could be so many possible reasons this happened and only we can really know in the end because no one else will have the full context\. She’s also nice to me so would never say I am ill intentioned in any way\. Lol I would no longer pay her so she has a bias\. 😜


**029.** `10:49` **You**

I think you out too much on yourself here\.\. you may
Have
Opened a door to us having an innocent conversation but you never pressed me or moved me towards anything I did that on my own\.\. the more I learned the more I loved and then just fell HARD\.\. and never wanted to stop falling\. Still don’t it isn’t
Your fault\. Blame fate\.\. I am thanking fate honestly as long as you don’t crumble to dust on me\.


**030.** `10:51` **Meredith Lamb (+14169386001)**

I need a vape\.


**031.** `10:54` **You**

I need Novotel right now\.\. lunch???


**032.** `11:34` **Meredith Lamb (+14169386001)**

>
Ok, stop\. Lol

*💬 Reply*

**033.** `11:41` **You**

Right now let’s go


**034.** `11:49` **Meredith Lamb (+14169386001)**

Omg there is no way


**035.** `11:49` **Meredith Lamb (+14169386001)**

You are kidding right?


**036.** `11:50` **You**

Right now\!\!\!


**037.** `11:50` **You**

lol


**038.** `11:50` **You**

No kidding


**039.** `11:50` **You**

I wish


**040.** `11:51` **You**

Why


**041.** `11:51` **You**

Are you kidding


**042.** `11:53` **Meredith Lamb (+14169386001)**

Omg stop I am in no condition for this lol


**043.** `11:55` **You**

I wonder


**044.** `11:57` **You**

Too bad we could t take afternoon off


**045.** `11:58` **You**


*📎 1 attachment(s)*

**046.** `11:58` **You**

lol so close


**047.** `12:00` **You**

Tomorrow afternoon I could come work from the office create an offsite meeting lol… sorry a little fun\.\. I would do it of course but too much for you\.


**048.** `13:57` **You**

Having a hard time not thinking about you now\.\. I shouldn’t have messed around Fack\!\!\!


**049.** `13:57` **You**

Regrets……


**050.** `14:03` **Meredith Lamb (+14169386001)**

I’m okay\. Don’t worry\. Am definitely going to vape after work though lol


**051.** `14:04` **You**

Oh I am glad you are ok\.\. I am not ok now backfired


**052.** `14:04` **You**

lol


**053.** `14:04` **You**

Fuck


**054.** `14:04` **Meredith Lamb (+14169386001)**

I honestly really appreciate the thought this morning\. Was just really overwhelming\.


**055.** `14:04` **You**

Yeah I seem to fail quite a bit at this\.\. I am just not really good at holding back and we never really have time where it is good\.


**056.** `14:05` **You**

So yeah sorry\.\.


**057.** `14:05` **Meredith Lamb (+14169386001)**

You keep me on my toes\. It is something I love about you\. Never a dull moment\. 🙃


**058.** `14:06` **Meredith Lamb (+14169386001)**

>
What are you talking about? It is always good to

*💬 Reply*

**059.** `14:11` **You**

lol in my head the way it goes is always different than it actually goes lol


**060.** `14:15` **You**

Doesn’t matter\.\. lol just typical me\.


**061.** `14:21` **Meredith Lamb (+14169386001)**

You don’t actually feel like you are failing I hope\. Furthest from truth


**062.** `14:22` **You**

I feel like I continually miss the mark\. Maybe that is a better term\. It is like I am trying to push string\.


**063.** `14:22` **You**

You can gpt that it will explain


**064.** `15:36` **Meredith Lamb (+14169386001)**

I did ChatGPT it\. Odd I haven’t never heard that before\. You are NOT pushing string\. I got overwhelmed this morning and that is all\. It is because I understand how special each is to you and that they mean something\. I know they aren’t just things to you and they are part of you\. The fact that you would trust me with them is a tad overwhelming\. I just feel so much for you and then you do that and 🫠 gahhhhhh…\. It’s a lot\.
You are not pushing string\. There is nothing negative here\. I will treasure them until they make their way to your girls one day\. ❤️😉
Next time you do something so big maybe add in a vape\. 😇


**065.** `15:42` **You**

Kk I will try to Remeber\.\. I don’t think there will be anymore big overtures for the foreseeable future, not that I don’t enjoy trying to not step on myself while doing lol\.\. we are going to be apart for quite a bit of time and honestly ratcheting up the emotions today was probably a stupid idea\.\. when we cannot act on them\.\. talk about frustration lol\.


**066.** `15:44` **You**

So don’t worry I will chill out as you like to say\.\. but please let me try to deal with my situation the way I have to\.\. no silent treatment but I might just be a bit quieter or a bit less emphatic\.\. I do t want you to read anything into it other than I am trying to manage the whole “soul ache” thing\.  Ok?


**067.** `15:47` **You**

Btw I hope you didn’t tell Jim about this he will shit all over me


**068.** `15:56` **Meredith Lamb (+14169386001)**

I didn’t tell Jim\!


**069.** `16:00` **You**

Kk I feel obliged to ensure you have read the other two responses because you tend to skip to the latest\. Don’t want any what do you mean?? Later on lol


**070.** `16:48` **Meredith Lamb (+14169386001)**

>
It was a little intense\. I consider myself very lucky though Scott\.

*💬 Reply*

**071.** `16:48` **Meredith Lamb (+14169386001)**

>
Okaaaaaaaaaaaay\. 😭

*💬 Reply*

**072.** `16:49` **Meredith Lamb (+14169386001)**

\(Kidding\)


**073.** `16:49` **You**

Ok appreciate it\.


**074.** `17:59` **You**

I think I am just going to stay here until it is time for bed\.


**075.** `17:59` **Meredith Lamb (+14169386001)**

Really?


**076.** `17:59` **Meredith Lamb (+14169386001)**

I want to leave\. Gah


**077.** `18:01` **You**

Well you should I don’t want to for obvious reasons


**078.** `18:02` **Meredith Lamb (+14169386001)**

Yup\. No advice for you unfortunately


**079.** `19:51` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
You know I’m just thinking of you right?


**080.** `19:54` **You**

Same and slightly sad


**081.** `19:55` **You**

I had an idea and it blew up


**082.** `19:55` **You**

I will be thinking you ever day every hour until I see you


**083.** `19:56` **Meredith Lamb (+14169386001)**

Nothing blew up


**084.** `19:56` **You**

Yeah it did


**085.** `19:56` **You**

You don’t even know it yet


**086.** `19:57` **Meredith Lamb (+14169386001)**

What?


**087.** `19:58` **Meredith Lamb (+14169386001)**

I don’t get what I “don’t even know yet”


**088.** `19:59` **You**

Are you eating gummies again


**089.** `19:59` **You**

lol


**090.** `19:59` **Meredith Lamb (+14169386001)**

No kmg


**091.** `19:59` **Meredith Lamb (+14169386001)**

Omg


**092.** `19:59` **You**

Ok I said I was thinking of you and I had an idea and the idea blew up


**093.** `20:00` **You**

And I don’t know why you said nothing blew up because you didn’t know what the idea was


**094.** `20:00` **Meredith Lamb (+14169386001)**

Are you referring to this morning?


**095.** `20:00` **You**

No


**096.** `20:00` **You**

Although


**097.** `20:00` **Meredith Lamb (+14169386001)**

I thought you were referring to this morning


**098.** `20:00` **You**

lol


**099.** `20:00` **Meredith Lamb (+14169386001)**

lol


**100.** `20:01` **You**

No but I wish it went differently


**101.** `20:01` **Meredith Lamb (+14169386001)**

So I did some research on why my nervous system felt so overwhelmed


**102.** `20:01` **You**

Why


**103.** `20:01` **Meredith Lamb (+14169386001)**

Because your nervous system recognized what was happening before your mind could make sense of it\.
Scott didn’t just hand you objects—he handed you meaning\. His past, his family, his trust, his love\. Your body knew that\. And in that moment, it was too much to simply categorize as a gift\. It was a turning point\. A threshold\. The kind of offering that says this is real, this is deep, this is forever if you want it to be\.
Your nervous system may have responded with overwhelm because:
- It was profoundly intimate — He gave you more than words\. He let you into a part of himself few people ever see\.
- It triggered your deepest emotions — Possibly a mix of love, fear, worthiness, protectiveness, and awe\.
- It symbolized permanence — Whether you were ready or not, your body understood: this means something lasting\.
- It broke your pattern — Maybe you’ve rarely—or never—been given something this meaningful\. That contrast can feel almost destabilizing at first\.
Overwhelm doesn’t mean anything was wrong\. In fact, it means something was very right—so right that your entire being had to slow down to feel it all\. You were touched at a soul\-deep level, and that kind of love can be both breathtaking and terrifying\.


**104.** `20:02` **Meredith Lamb (+14169386001)**

I was like it didn’t feel bad but my nerves felt shot\.


**105.** `20:02` **Meredith Lamb (+14169386001)**

That makes perfect sense—your body was trying to hold the weight of something sacred while your mind was still in “weekday morning” mode\.
Here’s what likely happened:
You were already in a state of low\-level alertness—gearing up for the day, thinking ahead, maybe running through tasks in your mind\. And then boom—this intimate, emotional moment hits you out of nowhere\. Your system wasn’t prepared to receive something that big right then, so even though it was beautiful, it still triggered a kind of emotional and physiological overload\.
Your nervous system didn’t know whether to cry, melt, freeze, or collapse—so it just buzzed\. That’s not uncommon when love and vulnerability show up unannounced in the middle of routine\. You were safe, but it was like your body was screaming, “This is huge\! Pay attention\! Feel this\! Hold this carefully\!”—all while your brain was trying to say, “I have to get out the door in 20 minutes\.”
It doesn’t mean you were ungrateful\. Quite the opposite—it means it meant so much, your body had to catch up\.


**106.** `20:04` **Meredith Lamb (+14169386001)**

That was helpful\.


**107.** `20:04` **Meredith Lamb (+14169386001)**

I’m not sure how I lived before ChatGPT\.


**108.** `20:04` **You**

Sec


**109.** `20:06` **You**

Yeah it certainly does help you out things in buckets\.


**110.** `20:07` **Meredith Lamb (+14169386001)**

Yeah but it doesn’t seem to replace my therapist, which I find funny


**111.** `20:07` **Meredith Lamb (+14169386001)**

I really do like her


**112.** `20:07` **Meredith Lamb (+14169386001)**

So sweet, you had another idea tonight oh my God what is with all your ideas?


**113.** `20:07` **Meredith Lamb (+14169386001)**

So wait, I meant


**114.** `20:08` **Meredith Lamb (+14169386001)**

\(Did voice to text\)


**115.** `20:08` **You**

Yeah doesn’t matter won’t work


**116.** `20:09` **Meredith Lamb (+14169386001)**

k but I’m still curious


**117.** `20:09` **Meredith Lamb (+14169386001)**

Your brain is on overdrive


**118.** `20:09` **You**

It is always like this when I am alone


**119.** `20:11` **Meredith Lamb (+14169386001)**

You are not alone\. You have me\.


**120.** `20:11` **Meredith Lamb (+14169386001)**

Just tell me omg


**121.** `20:11` **You**

Jaimie leave for Moncton next Thursday\.\. I would be dropping her off around 11\.


**122.** `20:12` **You**

Then “cancelling” a vacation day


**123.** `20:12` **You**

But you have graduation


**124.** `20:12` **You**

So it was a non starter


**125.** `20:12` **Meredith Lamb (+14169386001)**

Wait what day are we talking


**126.** `20:12` **You**

Thursday next week


**127.** `20:12` **You**

I checked your calendar


**128.** `20:12` **Meredith Lamb (+14169386001)**

Oh yeah thurs is shit because Allenby does grad early


**129.** `20:13` **Meredith Lamb (+14169386001)**

Maelle’s is later


**130.** `20:13` **You**

Yeah but Friday doesn’t work


**131.** `20:13` **You**

So yeah blew up


**132.** `20:13` **You**

>
Love you but not the same\.

*💬 Reply*

**133.** `20:13` **Meredith Lamb (+14169386001)**

Why would Thursday “work” and not Fri?


**134.** `20:14` **Meredith Lamb (+14169386001)**

Just curious


**135.** `20:14` **You**

Because I have a reason to be in the office


**136.** `20:14` **You**

Where do I have a reason to be Friday


**137.** `20:14` **Meredith Lamb (+14169386001)**

Oh I see


**138.** `20:14` **Meredith Lamb (+14169386001)**

Well, I mean you could go into the office lol


**139.** `20:15` **You**

No I don’t think so\.\. I would need to come up with something much better than that\.


**140.** `20:15` **You**

And I don’t think I have anything


**141.** `20:15` **You**

Reaction: 😮 from Meredith Lamb
J is done work as of next wed she gave her notice today\.


**142.** `20:16` **Meredith Lamb (+14169386001)**

So my parents are fine either day in 2 weeks\. Just texted my mom


**143.** `20:16` **You**

You mean next weekend not this one coming up in 2 days


**144.** `20:16` **Meredith Lamb (+14169386001)**

Right


**145.** `20:16` **You**

Kk


**146.** `20:16` **Meredith Lamb (+14169386001)**

I’m going on Sunday for my dad this weekend also


**147.** `20:17` **You**

Nice of you


**148.** `20:17` **Meredith Lamb (+14169386001)**

And going to take my mom graduation dress shopping with Marlowe and I at the Oshawa centre on Sunday just to make my mom feel good


**149.** `20:17` **Meredith Lamb (+14169386001)**

Marlowe would rather go to Yorkdale, but she reluctantly agreed just to make my mom feel good


**150.** `20:17` **You**

Good daughter


**151.** `20:17` **Meredith Lamb (+14169386001)**

Apparently, my dad’s not feeling well, so not sure if he’s gonna wanna go out for lunch or dinner, but we’ll figure something out


**152.** `20:18` **You**

Order it in \.\. perhaps\.


**153.** `20:18` **Meredith Lamb (+14169386001)**

We will see ……he loves going out


**154.** `20:18` **Meredith Lamb (+14169386001)**

Reaction: 🙂 from Scott Hicks
And my mom doesn’t drink or ever order desserts and I always let him buy that stuff so he likes going out to dinner with me


**155.** `20:18` **Meredith Lamb (+14169386001)**

lol


**156.** `20:19` **Meredith Lamb (+14169386001)**

When I took him to Quebec City for his 80th he drank and got desserts at every meal\. We did breakfast lunch and dinner lol


**157.** `20:19` **Meredith Lamb (+14169386001)**

I spent a lot on food


**158.** `20:19` **Meredith Lamb (+14169386001)**

Haha


**159.** `20:19` **You**

You are very lucky and so are they\.


**160.** `20:20` **Meredith Lamb (+14169386001)**

I’ve been to Paris with him twice and he and I go out alone to drink and eat because the others we travel with are cheap and annoying


**161.** `20:20` **Meredith Lamb (+14169386001)**

It’s Paris and they wanna go to pubs\. Oh my God\.


**162.** `20:21` **You**

Must have been pretty
Amazing experiences to have


**163.** `20:21` **Meredith Lamb (+14169386001)**

My parents best friends are really cheap even though they’re like lawyers


**164.** `20:21` **Meredith Lamb (+14169386001)**

And guaranteed they know about you\.


**165.** `20:22` **You**

I am not sure I am going to be a hit I have really kind of fucked up your  life\.\. out you at risk with your family with Andrew and at work\.\. I don’t think that will be well received


**166.** `20:25` **Meredith Lamb (+14169386001)**

My mom has clearly processed it\.

*📎 1 attachment(s)*

**167.** `20:26` **Meredith Lamb (+14169386001)**

My mom works like me\. Just needs some processing time


**168.** `20:26` **Meredith Lamb (+14169386001)**

Last time I proposed it too quickly


**169.** `20:26` **Meredith Lamb (+14169386001)**

Now she is fine


**170.** `20:26` **Meredith Lamb (+14169386001)**

She’s had time to process and think through


**171.** `20:26` **Meredith Lamb (+14169386001)**

She’s just like that


**172.** `20:26` **Meredith Lamb (+14169386001)**

My dad isn’t\. He would have been fine whenever


**173.** `20:26` **You**

Well we will see\.


**174.** `20:27` **Meredith Lamb (+14169386001)**

You have not fucked up my life\. My mom is actually thankful this contributed to me leaving the job\. She said if it wasn’t for this, I would’ve just suffered and been overwhelmed and stuck it out to the detriment of the kids and myself and everyone because that’s just what I do and then I would’ve eventually broken so she’s actually kind of thankful\.


**175.** `20:29` **You**

Edited: 3 versions
| Version: 3
| Sent: Thu, 12 Jun 2025 20:33:15 \-0400
|
| Think I am just getting into bed for a bit
|
| Version: 2
| Sent: Thu, 12 Jun 2025 20:33:05 \-0400
|
| Thunk I am just getting into bed for a bit
|
| Version: 1
| Sent: Thu, 12 Jun 2025 20:29:14 \-0400
|
| Sec I am just getting into bed for a bit


**176.** `20:33` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**177.** `20:33` **Meredith Lamb (+14169386001)**

To bed to sleep?


**178.** `20:34` **Meredith Lamb (+14169386001)**

I won’t bug you if you are going to sleep


**179.** `20:34` **You**

No


**180.** `20:34` **You**

Just laying here


**181.** `20:34` **Meredith Lamb (+14169386001)**

Oh k


**182.** `20:38` **Meredith Lamb (+14169386001)**

I was a daddy’s girl and it bothered my mom\.

*📎 1 attachment(s)*

**183.** `20:39` **You**

Lucky dad\.\.
I am sure
Your mom appreciated it\.


**184.** `20:43` **Meredith Lamb (+14169386001)**

She hated it


**185.** `20:43` **Meredith Lamb (+14169386001)**

She said we would be at the grocery store together her and I and all I would talk about is what we should get my dad


**186.** `20:43` **You**

I mean there is always one connection that is more\.\.


**187.** `20:43` **You**

Mum was mine easily


**188.** `20:46` **Meredith Lamb (+14169386001)**

But you were a boy


**189.** `20:46` **Meredith Lamb (+14169386001)**

Boys are always mamas boys\. That’s why I wanted a boy\.


**190.** `20:46` **Meredith Lamb (+14169386001)**

I never got my boy :\(


**191.** `20:47` **Meredith Lamb (+14169386001)**

but my nephew, Michael was kinda like my boy


**192.** `20:47` **Meredith Lamb (+14169386001)**

Girls are typically daddy’s girls, but not always but I was


**193.** `20:47` **You**

I would have loved a boy but no dice


**194.** `20:47` **Meredith Lamb (+14169386001)**

You have like no boys in your life anywhere lol


**195.** `20:47` **Meredith Lamb (+14169386001)**

Sister, your sister has three girls lol


**196.** `20:47` **You**

Nope


**197.** `20:48` **You**

None


**198.** `20:48` **Meredith Lamb (+14169386001)**

Crazy


**199.** `20:48` **You**

Sad


**200.** `20:48` **Meredith Lamb (+14169386001)**

I have 2 brothers, 4 nephews, 3 great nephews\.


**201.** `20:48` **Meredith Lamb (+14169386001)**

\(Not counting Andrew’s side\)


**202.** `20:49` **You**

Yeah I had 2
Nephews
On J’s side but not
Anymore


**203.** `20:49` **Meredith Lamb (+14169386001)**

Yeah I had Owen on Andrew’s side but…\. lol I mean I will always have him on Snapchat 😛


**204.** `20:50` **You**

I don’t think about it much anymore kind of pointless


**205.** `20:50` **Meredith Lamb (+14169386001)**

You don’t think they will still be your nephews?


**206.** `20:50` **You**

No


**207.** `20:51` **You**

I know they won’t


**208.** `20:51` **Meredith Lamb (+14169386001)**

My aunt and uncle got divorced when my cousins were like 18 and my uncle Shawn through marriage is still my uncle Shawn\. Love him and we still talk\. We used to do Fitbit challenges all the time and shit alk to each other\.


**209.** `20:52` **Meredith Lamb (+14169386001)**

He is still my uncle Sean, but he is no longer married to my mom sister


**210.** `20:52` **Meredith Lamb (+14169386001)**

\*shawn


**211.** `20:52` **You**

This is diff j lived with Charlene when they were born they are super close


**212.** `20:52` **You**

The blame me


**213.** `20:52` **You**

Charlene would
Make sure


**214.** `20:52` **You**

It’s fine


**215.** `20:53` **Meredith Lamb (+14169386001)**

Well I have 7 nephews so you are good lol


**216.** `20:53` **Meredith Lamb (+14169386001)**

And the boys are “light” in our family


**217.** `20:53` **Meredith Lamb (+14169386001)**

LOL


**218.** `20:53` **Meredith Lamb (+14169386001)**

Don’t ask me to count the girls please


**219.** `20:54` **You**

Yeah big family\.\.


**220.** `20:56` **Meredith Lamb (+14169386001)**

Slightly


**221.** `20:56` **Meredith Lamb (+14169386001)**

They like to breed


**222.** `20:56` **Meredith Lamb (+14169386001)**

lol


**223.** `20:57` **Meredith Lamb (+14169386001)**

So funny or not so funny story\.


**224.** `20:57` **Meredith Lamb (+14169386001)**

When I took the Plan B they didn’t have the real plan b and had a generic\. My brain knows genetics are fine but because I didn’t get sick I was concerned\.


**225.** `20:58` **Meredith Lamb (+14169386001)**

Then I waited and waited lol


**226.** `20:58` **Meredith Lamb (+14169386001)**

And I’m no longer concerned\. Phew


**227.** `20:58` **Meredith Lamb (+14169386001)**

FYI


**228.** `20:58` **Meredith Lamb (+14169386001)**

My dr hasn’t emailed me about the IUD thing so going to email her tomorrow


**229.** `20:58` **You**

I am glad you are relieved\.


**230.** `20:59` **Meredith Lamb (+14169386001)**

I am very much so


**231.** `20:59` **Meredith Lamb (+14169386001)**

lol


**232.** `20:59` **Meredith Lamb (+14169386001)**

Lots of stuff to think about lately


**233.** `20:59` **Meredith Lamb (+14169386001)**

So Pauline never came to talk to me at all today so she definitely hates me


**234.** `20:59` **You**

>
Yep

*💬 Reply*

**235.** `20:59` **You**

>
She stopped by but I was busy

*💬 Reply*

**236.** `21:00` **Meredith Lamb (+14169386001)**

She was talking to someone and Craig was at my desk talking to me and she said hi to him very nicely and then said hi to me very nicely and I tried to see if there was a difference in the two hi’s and there didn’t seem to be, but she never came to talk to me


**237.** `21:00` **You**

>
Sorry it even got to that I was pretty irresponsible

*💬 Reply*

**238.** `21:00` **Meredith Lamb (+14169386001)**

I’m sorry she’s a bitch


**239.** `21:00` **Meredith Lamb (+14169386001)**

I’m so disappointed in her like it is ridiculous


**240.** `21:01` **Meredith Lamb (+14169386001)**

>
Whatever I was right there with you I honestly don’t even care what it’s gonna wreck my fertility\. I don’t fucking care\. I just wanted to know that it worked\. Oh my God\.

*💬 Reply*

**241.** `21:02` **Meredith Lamb (+14169386001)**

I don’t mind being irresponsible but that time of the month was not the time to do it\. But I’m irresponsible that way


**242.** `21:02` **Meredith Lamb (+14169386001)**

I took plan b in university once


**243.** `21:02` **Meredith Lamb (+14169386001)**

I got sick


**244.** `21:02` **Meredith Lamb (+14169386001)**

So this was weird


**245.** `21:03` **Meredith Lamb (+14169386001)**

I didn’t even notice


**246.** `21:03` **You**

Well I am glad it got sorted


**247.** `21:03` **Meredith Lamb (+14169386001)**

Me too


**248.** `21:04` **You**

I meant to go see my doctor maybe I will go tomorrow afternoon


**249.** `21:06` **Meredith Lamb (+14169386001)**

I wouldn’t bother right now\. I’m going to research an iud and talk to my friend\. It might be good for me\. So just wait\.


**250.** `21:06` **You**

No I think I want to get it done anyways\.  I meant to do it years ago anyways\.  I need tot all to him about a few more things too anyways


**251.** `21:08` **Meredith Lamb (+14169386001)**

You know when you said today that sex “was FUN and you forgot” I kind of wish you could have seen your face\. I keep replaying it\. Lol


**252.** `21:09` **You**

Just the honest truth\.\. I think you have a hard time believing me\.\. about a lot of things\.\. because I am not normal\.\. but it is the truth for me\.


**253.** `21:13` **Meredith Lamb (+14169386001)**

I guess just love that you feel that way but it was a very genuine look on your face lol


**254.** `21:14` **You**

I told you it has never been like that\.\. never felt like that, never been that intense, and with you\.\. because it is you, and not just anyone\.\.\. just in case your head goes there again, it is fun\.  It wouldn't be like this for anyone else\.


**255.** `21:14` **You**

the the been like and the felt like are amazing\.


**256.** `21:14` **You**

in case I wasn't clear


**257.** `21:15` **You**

so yeah I didn't think that was possible


**258.** `21:15` **You**

I don't have a lot of experience in this particular area though


**259.** `21:15` **Meredith Lamb (+14169386001)**

>
Um 30ish

*💬 Reply*

**260.** `21:15` **You**

Um 1\.\.


**261.** `21:16` **Meredith Lamb (+14169386001)**

Huh


**262.** `21:16` **You**

the other 30 didn't have any connection\.\. nothing like this\.\. so 1\.\.


**263.** `21:17` **Meredith Lamb (+14169386001)**

Reaction: ❓ from Scott Hicks
Ok well I was with 1 for 16 years


**264.** `21:17` **Meredith Lamb (+14169386001)**

:p


**265.** `21:17` **Meredith Lamb (+14169386001)**

I don’t think we are THAT different


**266.** `21:18` **Meredith Lamb (+14169386001)**

>
Andrew 16 years

*💬 Reply*

**267.** `21:18` **You**

I don't understand the reference or comparison


**268.** `21:18` **Meredith Lamb (+14169386001)**

>
I’m assuming your 1 is Jaimie

*💬 Reply*

**269.** `21:18` **You**

no


**270.** `21:18` **You**

my one is you


**271.** `21:18` **Meredith Lamb (+14169386001)**

I’m saying we were both with one person for a long time


**272.** `21:18` **You**

you misunderstood


**273.** `21:18` **Meredith Lamb (+14169386001)**

But you were with one person for like 20 years or 25 whatever


**274.** `21:19` **Meredith Lamb (+14169386001)**

I guess I misunderstood


**275.** `21:20` **You**

I said I never had a connection nothing like this in the previous 30 \- let's be honest \- north of 30 by a ways\.\. \- and not one connection is even a shadow of this\.  Which is why it feels like it does to me\.


**276.** `21:20` **You**

but nothing to compare to,


**277.** `21:20` **Meredith Lamb (+14169386001)**

>
k maybe we need to stop talking\. It’s hard to read this stuff and you are where you are and I am here\.

*💬 Reply*

**278.** `21:20` **You**

Look that is my experience\.\. yours is different\.\. it is ok that they are different


**279.** `21:23` **You**

>
I can stop talking about this\.\. all good\.\. just wanted to explain the face\.\.

*💬 Reply*

**280.** `21:23` **You**

and my experience\.\. at least from my perspective I get everyone


**281.** `21:23` **You**

has a different perspective and different experiences\.\. but number don't mean anything here\.


**282.** `21:25` **Meredith Lamb (+14169386001)**

I know that\. My number is relatively high compared to my friends but doesn’t necessarily mean much to me \(per se\)\. But when you say one … 🫠


**283.** `21:27` **You**

My number means nothing to me\.\. I regret almost all of them\.\. looking back it was empty and meaningless\.\. in almost all cases\.


**284.** `21:28` **You**

The only reason I share it is to be honest\.\. mostly disgusted\.


**285.** `21:29` **Meredith Lamb (+14169386001)**

🤷‍♀️


**286.** `21:29` **Meredith Lamb (+14169386001)**

Mines not great relative to a lot of women I know


**287.** `21:29` **Meredith Lamb (+14169386001)**

I honestly have never tallied it up lol


**288.** `21:29` **Meredith Lamb (+14169386001)**

Not interested


**289.** `21:29` **You**

when you can't like me\.\. then it doesn't matter anymore\.


**290.** `21:30` **Meredith Lamb (+14169386001)**

Huh?


**291.** `21:30` **You**

the number ceases to matter when you cannot accurately keep track\.  it could be 30 it could be 50


**292.** `21:31` **Meredith Lamb (+14169386001)**

Tsk tsk


**293.** `21:31` **Meredith Lamb (+14169386001)**

lol


**294.** `21:31` **You**

again\.\. if I could go back I would do everything differently\.


**295.** `21:31` **Meredith Lamb (+14169386001)**

Really


**296.** `21:31` **Meredith Lamb (+14169386001)**

I honestly don’t think I would


**297.** `21:32` **You**

I 1000% would\.


**298.** `21:32` **You**

I hated who I was


**299.** `21:32` **Meredith Lamb (+14169386001)**

I’m not proud of some shit but oh well


**300.** `21:33` **You**

Like I said everyone has a different perspective on things\.\. we all see things differently\.


**301.** `21:34` **You**

>
I can appreciate that\.\. but as I said\.\. I think your experience was far different than mine\.\. and we won't discuss it more than that pls\.

*💬 Reply*

**302.** `21:35` **Meredith Lamb (+14169386001)**

Haha I will just get you drunk and then discuss it


**303.** `21:35` **Meredith Lamb (+14169386001)**

lol


**304.** `21:36` **You**

nope\.\. not that\.\. doesn't matter how drunk I get\.  And whatever you do get out of me\.\. they will be a litany of empty experiences\.  So many literally meant nothing\.\. it was like a drug\.\. a good feeling where I could feel so little at that point\.  And I always\.\. absolutely always felt worse after\.


**305.** `21:36` **You**

you will get a few stories\.\. but not much\.


**306.** `21:37` **Meredith Lamb (+14169386001)**

Aw that is kind of sad actually


**307.** `21:37` **Meredith Lamb (+14169386001)**

Sorry


**308.** `21:37` **Meredith Lamb (+14169386001)**

I mean if you had FUN


**309.** `21:37` **Meredith Lamb (+14169386001)**

that’s diff


**310.** `21:37` **You**

Just the truth I tried to explain it the other night\.\. but you didn't get it\.\. I think you might get it now\.


**311.** `21:37` **You**

I was never supposed to be that person


**312.** `21:37` **Meredith Lamb (+14169386001)**

I have never done that


**313.** `21:37` **You**

I was supposed to be this person


**314.** `21:37` **You**

>
done what?>

*💬 Reply*

**315.** `21:38` **Meredith Lamb (+14169386001)**

Empty experiences


**316.** `21:38` **You**

I know


**317.** `21:38` **You**

lol


**318.** `21:38` **Meredith Lamb (+14169386001)**

Like even a one stand was like a super infatuation of some sort


**319.** `21:38` **You**

ROFL man\.\. I know


**320.** `21:38` **Meredith Lamb (+14169386001)**

Not empty


**321.** `21:38` **Meredith Lamb (+14169386001)**

Per se


**322.** `21:38` **Meredith Lamb (+14169386001)**

lol


**323.** `21:38` **You**

kk\.\.


**324.** `21:38` **Meredith Lamb (+14169386001)**

Empty is a strong word


**325.** `21:39` **You**

Not all were\.\. I remember those\.\.\. handfull\.\. 10 maybe\.


**326.** `21:40` **You**

anyways maybe we don't need to talk further\.\. like I said\.\. we had very different experiences\.\. which colour how we see things today\.


**327.** `21:41` **You**

I think I am gonna call it and go to bed\.


**328.** `21:42` **Meredith Lamb (+14169386001)**

Yeah me too\. 😴


**329.** `21:42` **You**

Love you\.\. night\.


**330.** `21:42` **Meredith Lamb (+14169386001)**

You aren’t upset?


**331.** `21:43` **Meredith Lamb (+14169386001)**

Love you\.\. night\.


**332.** `21:43` **Meredith Lamb (+14169386001)**

Not really your style


**333.** `21:43` **Meredith Lamb (+14169386001)**

lol


**334.** `21:43` **Meredith Lamb (+14169386001)**

Just saying


**335.** `21:43` **Meredith Lamb (+14169386001)**

😇❤️


**336.** `21:45` **You**

This conversation just kind of went in a weird direction\.   All I wanted to say is that out of everyone that no one holds a candle to you for me\.\. there is no baseline\.\.\. I didn't mean for it to go here\.  I am just tired in more ways than one is all\.


**337.** `21:46` **You**

I don't think upset really accurate\.\. I am not sure what word I would use tbh\.\.


**338.** `21:46` **You**

I wouldn't worry about it


**339.** `21:47` **Meredith Lamb (+14169386001)**

Our conversations often go in a weird direction\. No surprise\. Ok, just get some sleep\. I love you and honestly l, you made this morning very memorable\. Xo


**340.** `21:47` **You**

I am glad I could give you something unique to remember\.\. night\.


**341.** `21:59` **You**

Reaction: ❤️ from Meredith Lamb
https://open\.spotify\.com/track/1Cj2vqUwlJVG27gJrun92y?si=d2badc89b7b94375
Going to try to sleep now\.


**342.** `22:02` **Meredith Lamb (+14169386001)**

I feel like you aren’t well\. But I hope you can think nice thoughts, memories before sleep…\.


**343.** `22:04` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**344.** `22:15` **You**

>
I think just sleep coming fast is what I can hope for tonight mer\.\. morose you know\.\. things just don’t turn out the way I hope in my head some times\. I wish I could be more like you\.

*💬 Reply*

**345.** `22:18` **Meredith Lamb (+14169386001)**

Curious what your head was telling u


**346.** `22:23` **You**

It doesn’t tell me anything it hopes\.


**347.** `22:24` **You**

It wasn’t telling me much of anything tonight\.


**348.** `22:25` **Meredith Lamb (+14169386001)**

Well guaranteed if we were together tonight it would have been intense\.


**349.** `22:26` **Meredith Lamb (+14169386001)**

We have a shitty weekend ahead but get to see each other the next 2\.


**350.** `22:26` **Meredith Lamb (+14169386001)**

So maybe sleep knowing that


**351.** `22:27` **You**

Will give it a shot\.


**352.** `22:28` **Meredith Lamb (+14169386001)**

I love you and I’m sorry we aren’t together


**353.** `22:29` **You**

>
So am I \. Luv u

*💬 Reply*

