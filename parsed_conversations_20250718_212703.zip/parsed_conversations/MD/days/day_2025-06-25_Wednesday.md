# Daily Conversation: 2025-06-25 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-25 |
| **Day** | Wednesday |
| **Week** | 11 |
| **Messages** | 430 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-25T04:08 - 2025-06-25T21:33 |

## 📝 Daily Summary

This day contains **430 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:08` **You**

Good morning\.\. love ❤️ ❤️❤️❤️
Sorry I tried
To stay awake but again felt like you were distracted regardless and didn’t want to add to it\.  Hope everything ended well for you and that there was no further fighting\.


**002.** `04:10` **You**

Reaction: 😢 from Meredith Lamb
Going to go to gym\.\. I had quite the bad night last night so just going to work it out\.\. not much I can do\.\. Gracie just screaming she won’t go and Jaimie blaming me for forcing the issue, and me defending myself and then attacking back\.\.  I just have to let all of this happen I have to take the blame and get through these last few weeks without trying to even really defend myself anymore\.  Will see how it goes\.


**003.** `04:11` **You**

So good luck getting that home I will give a great reference\.\. looking forward to seeing it for myself eventually\.  Kk gonna get going Love you so much\.


**004.** `06:37` **You**

New pb\.

*📎 3 attachment(s)*

**005.** `06:42` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**006.** `06:42` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**007.** `06:42` **You**

You haven’t been holding up your end with the pics btw\.


**008.** `07:06` **Meredith Lamb (+14169386001)**

I’m tiiiiiired and skipping this morning\. Last night was a lot all around\. Going to sleep some more\.


**009.** `07:32` **You**

Did you guys keep going after you said good night\.\. well I guess whenever you wake up and perhaps if A is not working from home we could chat on teams? Have a good extra sleep


**010.** `08:16` **Meredith Lamb (+14169386001)**

Yeah, we talked a bit more, but it didn’t go too late\. It’s just with all of this and the apartment searching\. I don’t have maelle ready for camp so I might have to take a vacation day tomorrow\.


**011.** `08:16` **Meredith Lamb (+14169386001)**

Just feeling a bit overwhelmed\.


**012.** `08:16` **Meredith Lamb (+14169386001)**

A lot happening at once\.


**013.** `08:17` **Meredith Lamb (+14169386001)**

And Marlowe didn’t react well to house hunting\. Wouldn’t go to the second


**014.** `08:17` **Meredith Lamb (+14169386001)**

Then couldn’t get ahold of Mackenzie at midnight


**015.** `08:17` **Meredith Lamb (+14169386001)**

Freaked me out


**016.** `08:17` **Meredith Lamb (+14169386001)**

I can always get ahold of her


**017.** `08:17` **Meredith Lamb (+14169386001)**

And she was far away


**018.** `08:17` **Meredith Lamb (+14169386001)**

But finally she called back


**019.** `08:17` **You**

Uggh


**020.** `08:17` **Meredith Lamb (+14169386001)**

I told her to be home by 1am


**021.** `08:17` **Meredith Lamb (+14169386001)**

Wasn’t


**022.** `08:18` **Meredith Lamb (+14169386001)**

But was in an uber


**023.** `08:18` **You**

I mean if you are overwhelmed maybe don’t come tomorrow


**024.** `08:18` **Meredith Lamb (+14169386001)**

But for home after 1am\. Little fucker


**025.** `08:18` **Meredith Lamb (+14169386001)**

No I will be good if I can get Maelle packed\.


**026.** `08:18` **Meredith Lamb (+14169386001)**

She hasn’t started and is away for 3 wks


**027.** `08:18` **You**

Can I help with anything off the record?


**028.** `08:19` **Meredith Lamb (+14169386001)**

I’ve bought her some things, but I never know what else to buy until she actually freaking starts to pack\!


**029.** `08:19` **You**

Ie work related


**030.** `08:19` **You**

Like I could look at ai thing and just give you my\. Thoughts\. Jus to you to use


**031.** `08:19` **Meredith Lamb (+14169386001)**

No, work isn’t big right now


**032.** `08:19` **You**

Anything to help


**033.** `08:19` **Meredith Lamb (+14169386001)**

Ai thing lol


**034.** `08:19` **You**

Kk


**035.** `08:20` **You**

I tried some stuff last night on my own for irs\.\. it is hard


**036.** `08:20` **You**

And that is with all the tools
I have


**037.** `08:20` **You**

I am going to keep at it in my spare time


**038.** `08:20` **Meredith Lamb (+14169386001)**

I don’t think it was tested for IRs?


**039.** `08:21` **You**

No no but they want it to be able to do something ir related


**040.** `08:21` **You**

And I don’t think they understand the difficulties


**041.** `08:21` **You**

So I am trying to build a workflow to show them


**042.** `08:21` **You**

Them being Erin


**043.** `08:21` **You**

And Daniel


**044.** `08:22` **Meredith Lamb (+14169386001)**

We should have kept alpha :p


**045.** `08:22` **You**

I am not going to rise to that one\.


**046.** `08:23` **Meredith Lamb (+14169386001)**

lol


**047.** `08:23` **Meredith Lamb (+14169386001)**

I’m going to get Austin to show me the tool


**048.** `08:23` **Meredith Lamb (+14169386001)**

See what he thinks


**049.** `08:24` **Meredith Lamb (+14169386001)**

Curious on his thoughts


**050.** `08:24` **You**

Kk


**051.** `08:27` **Meredith Lamb (+14169386001)**

I just moved my vac day to tomorrow and I will work on fri


**052.** `08:28` **Meredith Lamb (+14169386001)**

Have to do mediation anyway


**053.** `08:29` **You**

Kk well just let me know when you plan to hit the road so I can either let you check in on my behalf or I can check in in between my site visit and supper and have a key waiting for you\.


**054.** `08:30` **You**

Oh and bring a bathing suit or shorts and a short
Or whatever\.\. just in case swimming or hot tub\.


**055.** `09:01` **Meredith Lamb (+14169386001)**

So I had to fill out more docs this morn and I should hear by tomorrow morning


**056.** `09:03` **You**

Cool\.\. good luck :\)


**057.** `09:06` **You**

https://chatgpt\.com/g/g\-67a93c84dd7c8191b9f579cc38ea90cf\-deepcognition\-os\-v2


**058.** `09:07` **You**

Try using this link when you gpt next\.


**059.** `09:13` **Meredith Lamb (+14169386001)**

k, want to chat before your meetings start


**060.** `10:49` **You**

eesh breathe for a sec


**061.** `12:05` **You**

therapy time\.\. then if done early packing for trip yay\!\!


**062.** `12:15` **Meredith Lamb (+14169386001)**

I cancelled my therapy for today\. Too annoyed and don’t feel like it


**063.** `12:15` **Meredith Lamb (+14169386001)**

And too much to do generally


**064.** `12:15` **You**

yeah I understand\.\.


**065.** `12:15` **You**

sorry you are annoyed


**066.** `12:16` **You**

Reaction: 😂 from Meredith Lamb
you will be a treat tomorrow and Friday right LOL


**067.** `12:16` **Meredith Lamb (+14169386001)**

I have a permanent head ache lol


**068.** `12:16` **Meredith Lamb (+14169386001)**

>
I will not be\.

*💬 Reply*

**069.** `12:16` **Meredith Lamb (+14169386001)**

lol


**070.** `12:16` **Meredith Lamb (+14169386001)**

I took tomorrow and Friday off\. Self preservation mode


**071.** `12:17` **You**

:\(


**072.** `12:17` **Meredith Lamb (+14169386001)**

I have to set up new bank account and credit card tomorrow


**073.** `12:17` **You**

😢


**074.** `12:18` **You**

sounds like first 2 days gonna be AWESOME\!\!


**075.** `12:18` **You**

lol


**076.** `12:22` **Meredith Lamb (+14169386001)**

I will be okay 😇


**077.** `12:25` **You**

mmmm hmmmmm


**078.** `12:25` **Meredith Lamb (+14169386001)**

😇


**079.** `12:26` **You**

SURE\.\. will see


**080.** `12:27` **You**

Maybe i will just hang out with Harris later on Friday\.\. give you more time to cool down\.


**081.** `12:38` **Meredith Lamb (+14169386001)**

Bromance\.
Will be an interesting day I’m sure :p


**082.** `12:42` **You**

Well it might be safer


**083.** `12:43` **You**

He might be gentler with me\.


**084.** `12:44` **Meredith Lamb (+14169386001)**

Likely


**085.** `12:44` **You**

Well play it safe I guess will be back
Before lights out\.


**086.** `12:45` **Meredith Lamb (+14169386001)**

😋


**087.** `12:46` **You**

Kk gonna tell Haris\.\. I am sure he will be excited\.\. will let you know\.


**088.** `13:08` **You**

this is my first eda experience\.


**089.** `13:08` **Meredith Lamb (+14169386001)**

lol Whitney’s bestie


**090.** `13:08` **You**

yeah she was very emphatic


**091.** `13:17` **You**

this presentation needs to be revised\.\. no one cares about these numbers\.


**092.** `13:17` **You**

they are meaningless\.


**093.** `13:19` **Meredith Lamb (+14169386001)**

Yep


**094.** `13:19` **Meredith Lamb (+14169386001)**

The whole thing is ridiculous


**095.** `13:19` **Meredith Lamb (+14169386001)**

It is honestly so painful


**096.** `13:26` **You**

I am so unhappy


**097.** `13:27` **Meredith Lamb (+14169386001)**

I could have given this presentation in 10 minutes


**098.** `13:27` **You**

less


**099.** `13:31` **You**

I literally just told her this\.


**100.** `13:37` **You**

I am hammering Chantal on the side here\.


**101.** `13:37` **Meredith Lamb (+14169386001)**

lol


**102.** `13:37` **You**

Reaction: ❤️ from Meredith Lamb
Awww the RC show\.\. our first teen date\.


**103.** `13:38` **You**

walking around no holding hands\.


**104.** `13:38` **Meredith Lamb (+14169386001)**

Per


**105.** `13:38` **You**

chaparone


**106.** `13:38` **You**

made sense


**107.** `13:39` **Meredith Lamb (+14169386001)**

Did you make Chantal cry so she went off camera?


**108.** `13:40` **You**

I am not sure\.\. I basically told her I was directing my team to be more discerning and to support activities where there is a clear line of site to measureable outcomes\.


**109.** `13:40` **You**

she seems fine


**110.** `13:41` **Meredith Lamb (+14169386001)**

>
Looking back, this was so wrong lol

*💬 Reply*

**111.** `13:42` **You**

😭 no it wasn't


**112.** `13:42` **You**

😢


**113.** `13:42` **Meredith Lamb (+14169386001)**

lol ok


**114.** `13:42` **You**

now I have to go off camera


**115.** `13:42` **Meredith Lamb (+14169386001)**

I mean from like a work perspective


**116.** `13:44` **You**

If I didn't do that would it have made a difference?


**117.** `13:44` **Meredith Lamb (+14169386001)**

Probably not at all


**118.** `13:45` **Meredith Lamb (+14169386001)**

Just kind of funny\. No wonder Deb was confused


**119.** `13:46` **You**

And I told my therapist I was doing so well\.\.\.\. gah\!\!


**120.** `13:51` **Meredith Lamb (+14169386001)**

lol stawp


**121.** `13:51` **You**

This is what regression feels like\.\. I always wondered\.


**122.** `13:51` **Meredith Lamb (+14169386001)**

You are not serious?


**123.** `13:52` **You**

😬


**124.** `13:52` **You**

😝


**125.** `13:52` **You**

No


**126.** `13:52` **Meredith Lamb (+14169386001)**

I can’t tell sometimes


**127.** `13:52` **You**

that is the saddest thing you have said yet\.\.


**128.** `13:52` **You**

😢


**129.** `13:52` **You**

lol


**130.** `13:52` **Meredith Lamb (+14169386001)**

Omg what exactly


**131.** `13:53` **You**

said another way\.\. you have been such a consistent baby\.\. cry baby cry\!\!  that I cannot tell when you are joking about it or actually crying \- yah big baby\!\!\!


**132.** `13:53` **You**

again kidding


**133.** `13:53` **You**

butnot kidding


**134.** `13:53` **Meredith Lamb (+14169386001)**

lol


**135.** `13:54` **Meredith Lamb (+14169386001)**

I didn’t say anything close to that


**136.** `13:54` **You**

Going to have to have a Chatgpt night again\.


**137.** `13:54` **Meredith Lamb (+14169386001)**

Omg dramatic


**138.** `13:55` **You**

I am including all of these chats\.\. :P


**139.** `13:55` **Meredith Lamb (+14169386001)**

k that actually made me laugh


**140.** `13:55` **You**

I noticed LOL


**141.** `13:55` **You**

what do you think I am doing off camera right now


**142.** `13:55` **You**

not crying


**143.** `13:55` **Meredith Lamb (+14169386001)**

Reaction: ❓ from Scott Hicks
Chester


**144.** `13:56` **Meredith Lamb (+14169386001)**

Going off camera is cheating


**145.** `13:56` **You**

mmmm yeah totally I couldn't help smiling at all during this exchange you are way better than I am


**146.** `13:59` **You**

you didn't need to come to this meeting yah know\.


**147.** `14:00` **You**

or are you like sad that your calendar looks so bare\.\.


**148.** `14:00` **Meredith Lamb (+14169386001)**

Chantal asked me to in person and I told her I would


**149.** `14:00` **Meredith Lamb (+14169386001)**

:p


**150.** `14:01` **You**

Hmmmm\.\. well now she gets to deal with me\.


**151.** `14:01` **You**

good feelings gone\.


**152.** `14:01` **Meredith Lamb (+14169386001)**

Honestly I think Edith or Austin should be attending meetings like these to learn more about programs


**153.** `14:02` **You**

nope\.\.


**154.** `14:02` **You**

denied


**155.** `14:02` **Meredith Lamb (+14169386001)**

:p


**156.** `14:02` **Meredith Lamb (+14169386001)**

How are they supposed to learn


**157.** `14:02` **You**

reading


**158.** `14:02` **Meredith Lamb (+14169386001)**

Oh god


**159.** `14:02` **You**

learning from their ELDERS


**160.** `14:02` **Meredith Lamb (+14169386001)**

You are stubborn sometimes


**161.** `14:02` **You**

not me\./


**162.** `14:02` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 14:02:54 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Wed, 25 Jun 2025 14:02:30 \-0400
| >
| > You are stubborn sometimes
|
| Put this in chat gpt
|
| Version: 1
| Sent: Wed, 25 Jun 2025 14:02:44 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Wed, 25 Jun 2025 14:02:30 \-0400
| >
| > You are stubborn sometimes
|
| Put this in chat for


**163.** `14:04` **You**

Reaction: 🙄 from Meredith Lamb
Reaction: 😂 from Scott Hicks
It would suggest that perception is everything, and that one person's perception of stubborn is another person's perception of perseverance, dedication, etc etc \(\#Iamawesome\)


**164.** `14:04` **You**

I didn't need gpt for that\.


**165.** `14:04` **Meredith Lamb (+14169386001)**

>
So like harassing me everyday?

*💬 Reply*

**166.** `14:04` **You**

yep


**167.** `14:04` **Meredith Lamb (+14169386001)**

Awesome


**168.** `14:04` **You**

I would drop but I said I would meet whitney and Mus after


**169.** `14:05` **Meredith Lamb (+14169386001)**

lol


**170.** `14:05` **You**

then I have to go get car


**171.** `14:05` **You**

then pack


**172.** `14:05` **Meredith Lamb (+14169386001)**

When are you driving there


**173.** `14:05` **You**

4 am


**174.** `14:05` **You**

5 am


**175.** `14:05` **You**

do OC meeting at 9am in chatham


**176.** `14:06` **You**

and then meet with some chatham folks


**177.** `14:06` **You**

then to Windsor for noon


**178.** `14:06` **You**

site visit 2pm


**179.** `14:06` **You**

supper at Keg


**180.** `14:06` **You**

likely hotel in between\.


**181.** `14:06` **You**

depends kind of on when you expect to arrive


**182.** `14:06` **Meredith Lamb (+14169386001)**

Honestly not sure yet


**183.** `14:07` **Meredith Lamb (+14169386001)**

I have stuff to do here tomorrow


**184.** `14:07` **Meredith Lamb (+14169386001)**

So won’t be early


**185.** `14:07` **You**

yeah  get it\.\. I wasn't planning on that\.\. was more like are you going to be there at 4 or 7 or 10


**186.** `14:07` **Meredith Lamb (+14169386001)**

Hmmmh


**187.** `14:07` **Meredith Lamb (+14169386001)**

Depends on Maelle


**188.** `14:07` **Meredith Lamb (+14169386001)**

Little shit is so bad at packing


**189.** `14:08` **You**

well I will probably just go to hotel around 4 before supper drop my shit off tell them you are coming\.\. have a key there for you if you want it\.


**190.** `14:08` **You**

I mean if you don't leave until 4 you won't be there until well after 8 regardless\.\. so likely won't matter


**191.** `14:09` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 14:09:26 \-0400
|
| Exactly\. Can I just keep you updated tomorrow? “Play it by ear” lol
|
| Version: 1
| Sent: Wed, 25 Jun 2025 14:09:17 \-0400
|
| Exactly\. Can I just keep you updated tomorrow? “Play it be ear” lol


**192.** `14:09` **You**

idc\.\. lol whatever works for you


**193.** `14:33` **You**

maybe don't tell me anything and just surprise me when you show up\.\.


**194.** `14:33` **You**

:P


**195.** `14:34` **Meredith Lamb (+14169386001)**

I feel like you are cranky today also\. We will be a good pair together?


**196.** `14:35` **You**

No no not cranky at all\.\. not even a bit\.\. anxious to get going\.\. looking forward to seeing you\.\. well I was…\.
lol


**197.** `14:36` **Meredith Lamb (+14169386001)**

😢


**198.** `14:37` **You**

I mean I am I am lol\.\. just that you are going to be all mad and shit\.


**199.** `14:38` **You**

I caught myself staring at
You in the meeting yesterday\.\. I was like WTF…


**200.** `14:38` **Meredith Lamb (+14169386001)**

>
I will not be “all mad and shit”\. Just a little anxious

*💬 Reply*

**201.** `14:38` **You**

So yeah sooo looking forward and I will take you however you come and do what I can to make you happy


**202.** `14:39` **Meredith Lamb (+14169386001)**

>
Meetings are brutal\. Whyyyyyyyyyy

*💬 Reply*

**203.** `15:12` **You**

lol


**204.** `15:12` **You**

I couldn’t help it


**205.** `15:13` **You**

Then I start thinking nice things and distracted


**206.** `15:24` **Meredith Lamb (+14169386001)**

I find you very distracting\. Constantly\. It’s been easier not being in your group though but still distracting lol


**207.** `15:25` **You**

Reaction: ❤️ from Meredith Lamb
Well I hope that never changes Meredith I don’t expect it will for me\.


**208.** `15:29` **You**

Btw I was curious we are
Going for dinner with your sil\.  What are we doing with your friends?


**209.** `15:30` **Meredith Lamb (+14169386001)**

Not sure yet\. Need to check in\. I was thinking just drinks bc not sure on timing


**210.** `15:30` **You**

Well we can leave as early as you want to on Sunday


**211.** `15:30` **You**

To get to London whenever you want to\.


**212.** `15:52` **Meredith Lamb (+14169386001)**

My parents here


**213.** `15:55` **You**

nice have fun with the pics\.\. give your mum a big hug and a kiss from me\.\. and tell her I am not afraid of elbows\!


**214.** `16:40` **Meredith Lamb (+14169386001)**

She’s giving me a break from pix bc I am literally full of anxiety


**215.** `16:41` **You**

why what's wrong mer\.\.


**216.** `16:41` **You**

like calm


**217.** `16:41` **Meredith Lamb (+14169386001)**

Just everything


**218.** `16:41` **Meredith Lamb (+14169386001)**

These people are reluctant to rent to me bc of my salary


**219.** `16:41` **Meredith Lamb (+14169386001)**

Meeting the owner at 6\.30pm


**220.** `16:42` **You**

Tell them to call me


**221.** `16:42` **You**

I am aware of everything


**222.** `16:42` **You**

so I can speak to that


**223.** `16:42` **Meredith Lamb (+14169386001)**

It’ll isn’t even all that\. Just everything coming to a head at once


**224.** `16:42` **Meredith Lamb (+14169386001)**

At least I’m not dealing with c/i though lol


**225.** `16:43` **You**

please let me help\.\. just tell me what you need, I can be the reference fuck I just wish I could come in with you on this\.


**226.** `16:44` **Meredith Lamb (+14169386001)**

This is not the thing causing anxiety\. It is one thing


**227.** `16:44` **Meredith Lamb (+14169386001)**

They also want no pets


**228.** `16:44` **You**

ok well maybe this is not the palce


**229.** `16:44` **Meredith Lamb (+14169386001)**

I feel like any place I have to agree to no pets


**230.** `16:44` **You**

place


**231.** `16:44` **Meredith Lamb (+14169386001)**

It is illegal to evict bc of pets


**232.** `16:44` **Meredith Lamb (+14169386001)**

So just going with it\.


**233.** `16:45` **Meredith Lamb (+14169386001)**

Realtor said to and they aren’t even full time


**234.** `16:45` **Meredith Lamb (+14169386001)**

Anyway plus Andrew being an ass


**235.** `16:45` **Meredith Lamb (+14169386001)**

I think Marlowe is sad too bc I took her to a house to view :p


**236.** `16:45` **Meredith Lamb (+14169386001)**

She feels bad for her dad also


**237.** `16:45` **You**

So you are overwhelmed


**238.** `16:45` **Meredith Lamb (+14169386001)**

Yes\!


**239.** `16:45` **You**

so you need to stop looking at everything


**240.** `16:45` **You**

and you need to focus on one thing


**241.** `16:45` **You**

only


**242.** `16:46` **You**

ignore the rest


**243.** `16:46` **You**

do that


**244.** `16:46` **You**

that is how i did it


**245.** `16:46` **Meredith Lamb (+14169386001)**

Tomorrow I have to deal with bank and credit card and Maelle’s camp


**246.** `16:46` **Meredith Lamb (+14169386001)**

Agh


**247.** `16:46` **You**

that was on top of being completely infatuated and in love with you\.\. which I still am but I am in much better control now\.


**248.** `16:46` **You**

So you have this call\.\. that is next\.\. focus on that Fuck Andrew\.


**249.** `16:47` **You**

if you don't need the place\.\. then don't worry about it


**250.** `16:47` **You**

you will get another\.\. and be in a better place to once agreement is signed


**251.** `16:48` **You**

Marlow \- that is just reality\.\. you decided you don't want to destroy her perception of her dad\.\. it is going to be tough\.\. just have to be supportive of her and patient with her\.\. that will be fine\.\.


**252.** `16:48` **You**

Bank is fucking easy\.\. just time\.


**253.** `16:48` **Meredith Lamb (+14169386001)**

>
I want this place though if I can get it\. If not no biggie but ugh more looking

*💬 Reply*

**254.** `16:48` **You**

yeah but now you have a guy


**255.** `16:48` **You**

he will look for you


**256.** `16:49` **You**

he knows what you want\.\. well guy or girl\.\. not sure


**257.** `16:49` **You**

he/she??


**258.** `16:49` **You**

lol


**259.** `16:49` **Meredith Lamb (+14169386001)**

He


**260.** `16:49` **Meredith Lamb (+14169386001)**

Dennis


**261.** `16:49` **You**

so he can look for you and will be motivated to


**262.** `16:50` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Everything will be ok, I know this logically\. My nervous system is just a bit shot


**263.** `16:50` **You**

So Marlow \- sorted for now\.\. nothing you can do so don't worry\.  Phone call you are ready\.\. you have references\.\. and you don't need it anyways\.  Andrew \- I don't even know now what he is on about\.\.  Maelle after phone call and tomorrow\.


**264.** `16:50` **You**

and Bank is easy


**265.** `16:50` **You**

Reaction: 😂 from Meredith Lamb
before the call\.\. have one glass of wine\.\.


**266.** `16:50` **Meredith Lamb (+14169386001)**

I will feel better when we can hang out :\)


**267.** `16:51` **You**

to calm down


**268.** `16:51` **Meredith Lamb (+14169386001)**

>
It’s at 11\.30

*💬 Reply*

**269.** `16:51` **Meredith Lamb (+14169386001)**

lol


**270.** `16:51` **You**

>
I am really really looking forward to this weekend\.

*💬 Reply*

**271.** `16:51` **You**

>
no with the owner tonight

*💬 Reply*

**272.** `16:51` **You**

not the mediator


**273.** `16:51` **Meredith Lamb (+14169386001)**

Oh going back to the place to meet the owner


**274.** `16:52` **Meredith Lamb (+14169386001)**

Probably bring Mac this time


**275.** `16:52` **You**

ah ok\.\. well your job is uber secure\.\. and you have the cash to do 1/4 of the year\.\.


**276.** `16:52` **Meredith Lamb (+14169386001)**

I told her to dress preppy and not slutty


**277.** `16:52` **You**

Is Andrew being a dick about the cash down\.


**278.** `16:52` **Meredith Lamb (+14169386001)**

No


**279.** `16:52` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 16:52:54 \-0400
|
| He doesn’t like the no pet thing
|
| Version: 1
| Sent: Wed, 25 Jun 2025 16:52:45 \-0400
|
| He doesn’t like the nonpersons


**280.** `16:52` **You**

?


**281.** `16:52` **You**

ah


**282.** `16:53` **Meredith Lamb (+14169386001)**

But it isn’t even full time


**283.** `16:53` **Meredith Lamb (+14169386001)**

So Dennis said don’t mention it


**284.** `16:53` **You**

yeah I wouldn't and if they do ask, you can suggest that you might have your pets visit every once in a while\.\. but you would sign a waiver to cover any damages which I think you already do anyways\.


**285.** `16:54` **Meredith Lamb (+14169386001)**

Yeah


**286.** `16:55` **Meredith Lamb (+14169386001)**

My mom is making me take pix


**287.** `16:55` **You**

kk send them to me please\.\. at least the ones with you in them you owe me\.


**288.** `16:55` **You**

Love you\.


**289.** `16:55` **You**

❤️


**290.** `17:02` **Meredith Lamb (+14169386001)**

You don’t want\. Family photo


**291.** `17:02` **Meredith Lamb (+14169386001)**

Sucky photo


**292.** `17:02` **You**

kk


**293.** `17:03` **You**

totally understand you wouldn't want a photo with J in it I am sure\.\. :\)


**294.** `17:05` **Meredith Lamb (+14169386001)**

Nope don’t want those


**295.** `17:05` **Meredith Lamb (+14169386001)**

You are 100% correct


**296.** `17:05` **Meredith Lamb (+14169386001)**

lol


**297.** `17:05` **You**

well I don't have anything decent to share with you\.\. so I guess we are shit outta luck\.


**298.** `17:06` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
We can take photos together this weekend lol


**299.** `17:07` **You**

I would love to\.


**300.** `17:07` **You**

and i hate having my pic taken


**301.** `17:07` **Meredith Lamb (+14169386001)**

Pretty sure it is safe on my phone but likely not yours


**302.** `17:07` **You**

yeah my photos are local\.\.


**303.** `18:02` **Meredith Lamb (+14169386001)**

You never told me how therapy went


**304.** `18:02` **Meredith Lamb (+14169386001)**

I thought you weren’t going to go anymore


**305.** `18:02` **You**

it was short\.


**306.** `18:03` **You**

and then I cancelled the rest for now


**307.** `18:03` **Meredith Lamb (+14169386001)**

How long is short?


**308.** `18:03` **You**

I told him about the weekend\.\. specifically about meeting the parents


**309.** `18:03` **You**

I talked a bit about the fights with J and Gracie\.\.


**310.** `18:03` **You**

that was basically it\.\. he didn't have a lot to say\.\. was a waste of time\.


**311.** `18:03` **You**

thus me cancelling the rest\.


**312.** `18:04` **Meredith Lamb (+14169386001)**

Interesting \- well maybe that is good news


**313.** `18:05` **You**

I already told you the good news for me, the slightly less good news for you, is that I am back in control of all of my emotions\.\. so not as needy\.\. but still so much love it hurts\.\. so nothing to worry about lol\.\. still got the constant absence ache\.\. I just hide it better\.


**314.** `18:05` **You**

I think you like being able to read me\.\. that won't be as easy but I will still have cranky moments etc\.\. just like you\.


**315.** `18:06` **You**

I am still apprehensive and nervous about some things, still have self doubts and insecurities


**316.** `18:07` **You**

I still feel fear for the future\.\. lol so I am still me\.\. but just better control


**317.** `18:07` **Meredith Lamb (+14169386001)**

I am happy about that… it is good for me too lol I don’t want you feeling in turmoil\. Believe it or not lol


**318.** `18:07` **You**

I mean again\.\.\.\. lol distinction


**319.** `18:07` **You**

I feel it\.\. but I control it\.


**320.** `18:08` **You**

it doesn't control me\.\. so at least there is that


**321.** `18:08` **Meredith Lamb (+14169386001)**

Now you can get some work done again … who are you hiring?


**322.** `18:08` **You**

I cannot talk about that\.


**323.** `18:09` **Meredith Lamb (+14169386001)**

lol


**324.** `18:09` **You**

Nice try


**325.** `18:10` **Meredith Lamb (+14169386001)**

I will have to get you drunk


**326.** `18:10` **Meredith Lamb (+14169386001)**

Then ask


**327.** `18:10` **You**

won't tell you that drunk\.\.


**328.** `18:10` **You**

I might tell you other things


**329.** `18:11` **You**

I already agreed to get drunk\.\.


**330.** `18:11` **You**

but I mean\.\. here is how I KNOW it will go\.


**331.** `18:11` **You**

you will have the intent to get me drunk and then take advantage and ask questions etc\.\. and then other stuff


**332.** `18:11` **You**

but


**333.** `18:11` **You**

what will happen


**334.** `18:11` **You**

is that you will just get drunker than me\.


**335.** `18:11` **You**

and it won't work


**336.** `18:11` **You**

lol


**337.** `18:11` **Meredith Lamb (+14169386001)**

lol


**338.** `18:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Touché


**339.** `18:12` **You**

I mean I do drink fast\.\.  I could put some effort into it\.


**340.** `18:12` **You**

get out ahead of you at least


**341.** `18:13` **Meredith Lamb (+14169386001)**

You do drink fast\.


**342.** `18:14` **Meredith Lamb (+14169386001)**

K, gotta go meet this owner with Mac\. Will ttyl ❤️


**343.** `18:14` **You**

>
good luck ❤️

*💬 Reply*

**344.** `19:13` **Meredith Lamb (+14169386001)**

Done\. That was interesting\. Young engaged couple


**345.** `19:13` **Meredith Lamb (+14169386001)**

Will be interested to see what happens\. They tried to sell the house in Dec but it didn’t sell and market is too bad now


**346.** `19:31` **You**

Any thoughts on where you will land?


**347.** `19:32` **You**

Oh it looks like Gracie is going to try to stay through until September\.  It is going to piss off maddie immensely and fuck up my world but I told Jaimie there will be rules\. Or she goes home\.


**348.** `19:32` **You**

Still I am really pissed


**349.** `19:34` **Meredith Lamb (+14169386001)**

Oh yikes, hopefully it doesn’t go too badly


**350.** `19:55` **You**

It will be a fucking disaster


**351.** `19:55` **You**

It is Gracie


**352.** `19:55` **You**

I wrote the rules and sent to j I am not moving on it\.


**353.** `19:59` **Meredith Lamb (+14169386001)**

You should make her sign a contract


**354.** `19:59` **You**

It wouldn’t matter


**355.** `19:59` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 19:59:56 \-0400
|
| Looks like I got the house, but obviously it won’t be done until everything is all fine then I provide the money and all that stuff so still lots to do
|
| Version: 1
| Sent: Wed, 25 Jun 2025 19:59:40 \-0400
|
| At the house, but obviously it won’t be done until everything is all fine then I provide the money and all that stuff so still lots to do


**356.** `19:59` **You**

J has to review everything with maddie then Gracie


**357.** `20:00` **You**

Then we discuss


**358.** `20:00` **You**

>
Wow congrats

*💬 Reply*

**359.** `20:00` **You**

That was fast


**360.** `20:00` **You**

Apparently you impressed


**361.** `20:00` **Meredith Lamb (+14169386001)**

Probably McKenzie because she dressed preppy instead of slutty


**362.** `20:01` **Meredith Lamb (+14169386001)**

Jk


**363.** `20:01` **You**

lol


**364.** `20:01` **You**

Oh don’t forget your passport


**365.** `20:01` **Meredith Lamb (+14169386001)**

I know I actually have a to do list and that is on it because my passport is currently in the Buick


**366.** `20:01` **You**



**367.** `20:02` **You**

Eesh


**368.** `20:21` **Meredith Lamb (+14169386001)**

Andrew is all upset the lease starts July 1


**369.** `20:22` **Meredith Lamb (+14169386001)**

I’m like “we need to not be living together”


**370.** `20:22` **Meredith Lamb (+14169386001)**

It’s driving me crazy


**371.** `20:23` **Meredith Lamb (+14169386001)**

He seems fine


**372.** `20:23` **Meredith Lamb (+14169386001)**

wtf


**373.** `20:23` **Meredith Lamb (+14169386001)**

How do I even discuss that


**374.** `20:24` **You**

He went from upset to fine


**375.** `20:24` **You**

Confused in reading this lol


**376.** `20:25` **Meredith Lamb (+14169386001)**

He just thinks I should have a plan to move before I rent


**377.** `20:25` **Meredith Lamb (+14169386001)**

I said all I need is a mattress and a suitcase


**378.** `20:25` **Meredith Lamb (+14169386001)**

Honestly


**379.** `20:26` **You**

lol


**380.** `20:26` **You**

Man drama


**381.** `20:29` **Meredith Lamb (+14169386001)**

Yeah and it is a small place so I won’t even need much tbh


**382.** `20:30` **Meredith Lamb (+14169386001)**

The whole moving thing is kind of hitting me though like mentally


**383.** `20:31` **Meredith Lamb (+14169386001)**

You are going to have to be extra nice to me this weekend lol


**384.** `20:31` **Meredith Lamb (+14169386001)**

I look at the backyard here or the dogs or Marlowe’s room and I’m like, ugh shit


**385.** `20:33` **You**

Reaction: ❤️ from Meredith Lamb
>
We will have to be nice to each other I think lol

*💬 Reply*

**386.** `20:33` **You**

Extra extra nice


**387.** `20:34` **You**

I have already told you I am all about being super nice


**388.** `20:34` **You**

Actually I am going to turn the tables on you


**389.** `20:34` **You**

Hahaha


**390.** `20:34` **You**

I just had a great idea


**391.** `20:34` **You**

Not telling you either


**392.** `20:35` **Meredith Lamb (+14169386001)**

So confused


**393.** `20:35` **You**

It might involve getting you drunk and asking you things


**394.** `20:35` **Meredith Lamb (+14169386001)**

That would likely not go well for you remember


**395.** `20:35` **You**

You don’t know the questions I am going to ask


**396.** `20:35` **Meredith Lamb (+14169386001)**

I can speculate


**397.** `20:36` **You**

And you still think it would be bad\.\. errrr ok 😞 scratch that\.


**398.** `20:36` **Meredith Lamb (+14169386001)**

No not for any particular reason


**399.** `20:37` **Meredith Lamb (+14169386001)**

Other than it has gone poorly before


**400.** `20:37` **You**

lol I will just not\.\. easier\.


**401.** `20:37` **Meredith Lamb (+14169386001)**

Haha


**402.** `20:37` **You**

Was a fun idea maybe not so fun in reality


**403.** `20:37` **Meredith Lamb (+14169386001)**

Just ask me after like 3\-4 glasses but no more than that


**404.** `20:38` **You**

Nope


**405.** `20:38` **You**

We good \- like you said should have learned my lesson


**406.** `20:39` **Meredith Lamb (+14169386001)**

I shouldn’t get very drunk anyways bc we have stuff to do


**407.** `20:39` **Meredith Lamb (+14169386001)**

I think I’m going to have to set up utilities and insurance on Friday likely


**408.** `20:39` **Meredith Lamb (+14169386001)**

Lots of phone calls\. Gah


**409.** `20:39` **You**

Well you will have lots of peace
And quiet


**410.** `20:41` **Meredith Lamb (+14169386001)**

Except for 11\.30\-1\.30 :p


**411.** `20:42` **You**

Yep gonna be fun\!\!\!\!


**412.** `20:50` **Meredith Lamb (+14169386001)**

So I forget what sept 15 was… remind me


**413.** `20:52` **You**

When you sign your agreement


**414.** `20:54` **Meredith Lamb (+14169386001)**

No chance


**415.** `20:54` **Meredith Lamb (+14169386001)**

Will be way earlier


**416.** `20:55` **You**

Yep now I think it will\. But I still don’t want you to settle


**417.** `20:55` **You**

Now sept 15 will be the new day we check to see if I am still sane


**418.** `21:03` **Meredith Lamb (+14169386001)**

Aw no ugh


**419.** `21:04` **Meredith Lamb (+14169386001)**

I will keep you sane don’t worry


**420.** `21:04` **Meredith Lamb (+14169386001)**

I mean, as best I can lol


**421.** `21:05` **Meredith Lamb (+14169386001)**

From a distance lol


**422.** `21:05` **Meredith Lamb (+14169386001)**

😝


**423.** `21:06` **You**

Mmm hmm that has proven to be very effective thus far… lol


**424.** `21:08` **Meredith Lamb (+14169386001)**

Totally\. This whole situation is amazing\.


**425.** `21:08` **Meredith Lamb (+14169386001)**

Easy breezy


**426.** `21:12` **You**

Yep it’s all turning up snake eyes\!\!


**427.** `21:17` **Meredith Lamb (+14169386001)**

Except this weekend\. Then back to snake eyes\.


**428.** `21:33` **You**

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 21:33:19 \-0400
|
| Ok I am going to bed
|
| Version: 1
| Sent: Wed, 25 Jun 2025 21:33:09 \-0400
|
| I I am going to bed


**429.** `21:33` **Meredith Lamb (+14169386001)**

k, I am soon\. Love you ❤️❤️


**430.** `21:33` **You**

Love you too ❤️


