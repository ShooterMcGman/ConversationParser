# Daily Conversation: 2025-06-19 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-19 |
| **Day** | Thursday |
| **Week** | 10 |
| **Messages** | 557 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-19T03:37 - 2025-06-19T22:28 |

## 📝 Daily Summary

This day contains **557 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `03:37` **Meredith Lamb (+14169386001)**

Sorry to hear\. That’s loooong\. I passed out watching tv at like 7pm\. Not even kidding\. ❤️❤️


**002.** `03:37` **Meredith Lamb (+14169386001)**

Love you too and miss you


**003.** `04:08` **You**

I love you too and miss you like crazy\. I will be thinking of you every minute of today\.  I really hope the thing at noon goes as well as it can\.


**004.** `04:09` **You**

>
That’s what I figured and was actually kind of glad you confirmed it\.\. alternative being maybe same shit as me\.

*💬 Reply*

**005.** `04:10` **Meredith Lamb (+14169386001)**

Can’t sleep now but 4am wake ups aren’t my thing\. Feels weird lol


**006.** `04:10` **You**

lol get used to it how do you think I am going to wake you up


**007.** `04:10` **Meredith Lamb (+14169386001)**

Petting Rosie


**008.** `04:10` **Meredith Lamb (+14169386001)**

lol


**009.** `04:10` **You**

I will find creative ways


**010.** `04:11` **Meredith Lamb (+14169386001)**

I will have to go to bed at 7pm


**011.** `04:11` **Meredith Lamb (+14169386001)**

lol


**012.** `04:11` **You**

No doubt


**013.** `04:11` **You**

I am used to to this now


**014.** `04:11` **Meredith Lamb (+14169386001)**

Why’d you guys fight so long?


**015.** `04:11` **You**

In fact 7 hours is too much sleep


**016.** `04:12` **You**

Reaction: ❓ from Meredith Lamb
It got personal


**017.** `04:12` **Meredith Lamb (+14169386001)**

>
Not for me\!\!

*💬 Reply*

**018.** `04:12` **Meredith Lamb (+14169386001)**

Like mean personal


**019.** `04:12` **Meredith Lamb (+14169386001)**

Or civil personal


**020.** `04:13` **You**

Yeah mean\.  And I think I mentioned I kind of said we were going to happen\.


**021.** `04:13` **You**

That is probably what bothers her most


**022.** `04:13` **You**

Honestly


**023.** `04:13` **Meredith Lamb (+14169386001)**

Yeah you mentioned that\.


**024.** `04:13` **You**

But again it is just an excuse


**025.** `04:13` **Meredith Lamb (+14169386001)**

Just because it is so fast


**026.** `04:13` **Meredith Lamb (+14169386001)**

Feels like cheating?


**027.** `04:14` **You**

To not address what really happened


**028.** `04:14` **You**

You know what it never felt like that to me


**029.** `04:14` **You**

Honestly


**030.** `04:14` **Meredith Lamb (+14169386001)**

But to her


**031.** `04:14` **You**

Oh yah


**032.** `04:14` **You**

Emotional cheating


**033.** `04:15` **Meredith Lamb (+14169386001)**

Ohhh


**034.** `04:15` **You**

Like ………


**035.** `04:15` **You**

And I tried to explain…


**036.** `04:15` **You**

But yeah my therapist was right


**037.** `04:16` **Meredith Lamb (+14169386001)**

They tend to be right lol


**038.** `04:16` **Meredith Lamb (+14169386001)**

Why I’m listening to mine


**039.** `04:16` **Meredith Lamb (+14169386001)**

The best I can


**040.** `04:16` **You**

She didn’t like that either


**041.** `04:16` **Meredith Lamb (+14169386001)**

Like what?


**042.** `04:16` **You**

I almost left at one point still might


**043.** `04:16` **You**

He said at this point I can’t convince her of shit so stop trying


**044.** `04:17` **You**

Just let her belies what she wants I know me and who I am


**045.** `04:17` **Meredith Lamb (+14169386001)**

Yeah she is in too much turmoil


**046.** `04:17` **You**

And I am awful in this situation 20 years of this and the last 5 and especially last year


**047.** `04:17` **You**

But it isn’t who I am and they don’t get it


**048.** `04:17` **You**

And it bothers me


**049.** `04:18` **You**

And that is partly why we fight


**050.** `04:18` **Meredith Lamb (+14169386001)**

For sure I get that


**051.** `04:18` **You**

Because she says I am some piece of trash and it bugs me


**052.** `04:18` **You**

There is lots that’s true


**053.** `04:18` **You**

But it that


**054.** `04:18` **You**

Not


**055.** `04:18` **Meredith Lamb (+14169386001)**

She is hurting and pissed off


**056.** `04:18` **Meredith Lamb (+14169386001)**

Doesn’t want this


**057.** `04:18` **You**

Yah


**058.** `04:18` **Meredith Lamb (+14169386001)**

Same as Andrew


**059.** `04:20` **You**

I just want this to be fucking done


**060.** `04:21` **Meredith Lamb (+14169386001)**

Yep, same same


**061.** `04:21` **You**

Reaction: ❤️ from Meredith Lamb
Getting up gotta get ready for a pull day\.\. gonna hurt but idc\.  Nick is surprised I haven’t broke yet lol


**062.** `04:21` **Meredith Lamb (+14169386001)**

I honestly am surprised also


**063.** `04:22` **You**

Too determined this is who I am\.  This sounds bad but j always held me back


**064.** `04:22` **You**

Smoking


**065.** `04:22` **You**

I wanted to quit at 25


**066.** `04:23` **You**

She wouldn’t I tried a dozen times


**067.** `04:23` **You**

So many more examples


**068.** `04:23` **Meredith Lamb (+14169386001)**

:\( aw ,, k get up
k I will talk to you later 🙂 no idea whether I will get up or not


**069.** `04:24` **You**

I will be around if you bored just getting dressed and shit\.  Maybe more photos\.\.  you owe me btw


**070.** `04:25` **Meredith Lamb (+14169386001)**

lol I don’t owe u, I paid up


**071.** `04:25` **You**

Nooooooo


**072.** `04:25` **You**

You get like 4 pics a day


**073.** `04:25` **Meredith Lamb (+14169386001)**

Basically


**074.** `04:25` **You**

Absolutely not


**075.** `04:25` **Meredith Lamb (+14169386001)**

We will see


**076.** `04:25` **Meredith Lamb (+14169386001)**

lol


**077.** `04:26` **You**

Bs lol maybe you don’t get any today then 😝


**078.** `04:26` **Meredith Lamb (+14169386001)**

Now now


**079.** `04:27` **Meredith Lamb (+14169386001)**

Don’t be going all 3 hr fight mode on me…


**080.** `04:27` **Meredith Lamb (+14169386001)**

lol


**081.** `04:27` **Meredith Lamb (+14169386001)**

Go work that out at the gym


**082.** `04:27` **You**

Maybe I start dropping pics on you at
12:45
And at 1:15


**083.** `04:27` **You**

ROFL


**084.** `04:27` **Meredith Lamb (+14169386001)**

Haha


**085.** `04:27` **You**

Really good ones too


**086.** `04:27` **You**

Hahaha


**087.** `04:27` **Meredith Lamb (+14169386001)**

You wouldn’t do that


**088.** `04:28` **You**

Not distracting at all\.\. lol no I wouldn’t


**089.** `04:28` **Meredith Lamb (+14169386001)**

I know


**090.** `04:28` **You**

Reaction: ❤️ from Meredith Lamb
Kk I am going luv you chat later❤️❤️❤️❤️❤️


**091.** `06:09` **You**

You up


**092.** `06:44` **You**

So that’s a no?? lol


**093.** `06:45` **You**

Reaction: ❤️ from Meredith Lamb
Back day again

*📎 1 attachment(s)*

**094.** `06:46` **You**

And front… well biceps

*📎 1 attachment(s)*

**095.** `06:46` **You**

I would appreciate something back doesnt even matter just a smile…☺️ and not an emoji


**096.** `07:53` **You**

Oooooh sleeping in a long time lol


**097.** `08:05` **Meredith Lamb (+14169386001)**

I’m 1/4 sleeping, 1/4 listening to my anxiety, 1/4 thinking about you and 1/4 listening to my girls get ready\. Not out of bed yet\.


**098.** `08:06` **You**

You need to 3/4 think about us


**099.** `08:06` **You**

For 15 mins


**100.** `08:06` **You**

No anxiety


**101.** `08:07` **Meredith Lamb (+14169386001)**

I had anxiety in my chest earlier but not now\. Just my head is a little haywire\.


**102.** `08:07` **Meredith Lamb (+14169386001)**

Going to workout tho which should help


**103.** `08:07` **You**

Kk go work it out\.\. I got my own stuff lol will be thinking about you though


**104.** `08:08` **Meredith Lamb (+14169386001)**

Need coffee first lol


**105.** `08:09` **Meredith Lamb (+14169386001)**

I’m also sore from the past 2 days so think I’m increasing the weights and stuff right finally


**106.** `08:15` **Meredith Lamb (+14169386001)**

Last week after my lower I wasn’t sore so I knew I was being a baby


**107.** `08:16` **Meredith Lamb (+14169386001)**

Today\. Very sore\. I smartened up on the lower yday


**108.** `08:16` **Meredith Lamb (+14169386001)**

lol


**109.** `08:16` **Meredith Lamb (+14169386001)**

Baby steps


**110.** `08:19` **You**

ROFL


**111.** `08:19` **You**

I mean do you just kind of figure it out\.\. I started by looking at a custom fitness ChatGPT and had it build me a program based on what I knew about myself


**112.** `08:20` **You**

And then from there I fiddled a bit just told it my goals what I had to work with etc


**113.** `08:28` **Meredith Lamb (+14169386001)**

No I do my challenge but the first while I wasn’t using enough weight bc 1\. Out of shape with zero muscle and 2\. Trying to get some memory back


**114.** `08:29` **Meredith Lamb (+14169386001)**

This week I’m using more regular weight


**115.** `08:33` **You**

:\)


**116.** `08:34` **You**

I wonder how much weight I am gonna do\.\. I mean I still have a ways to go for Henry


**117.** `08:34` **You**

Reaction: 😂 from Meredith Lamb
but he's worth it\!\!


**118.** `08:34` **Meredith Lamb (+14169386001)**

But I’m so sore today it is a little ridiculous for what I actually did lol


**119.** `08:34` **You**

naw\.\. it is progressive


**120.** `08:34` **You**

you will be good


**121.** `08:36` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I hate photos of me without make up existing so these go nowhere\. No magic oldie web recovery machines\. Lol

*📎 1 attachment(s)*

**122.** `08:37` **Meredith Lamb (+14169386001)**

This is one of my favourite coffee mugs\. Look at the photo\. My one child who isn’t a morning person \(since birth\)\.

*📎 1 attachment(s)*

**123.** `08:38` **Meredith Lamb (+14169386001)**

Our nanny took that photo years ago when Maelle came down to meet her in kitchen in morning\. One of my favourites


**124.** `08:38` **You**

ROFL


**125.** `08:39` **You**

the photos go in my vault


**126.** `08:39` **Meredith Lamb (+14169386001)**

Thank you


**127.** `08:39` **You**

and then on my wall


**128.** `08:39` **You**

poster sized


**129.** `08:39` **Meredith Lamb (+14169386001)**

🙄


**130.** `08:39` **You**

LOVE YOU


**131.** `08:39` **Meredith Lamb (+14169386001)**

lol


**132.** `08:41` **Meredith Lamb (+14169386001)**

I’m doing shoulders today which I desperately need and they aren’t sore so should be ok


**133.** `08:43` **You**

hehe bet you will be sore sat


**134.** `08:43` **You**

have to take it easy


**135.** `09:03` **Meredith Lamb (+14169386001)**

Define “easy”


**136.** `09:06` **You**

Like easy


**137.** `09:09` **Meredith Lamb (+14169386001)**

lol k


**138.** `10:02` **You**

That was a fun car ride


**139.** `10:04` **Meredith Lamb (+14169386001)**

Omg I forgot you had that this morning


**140.** `10:04` **Meredith Lamb (+14169386001)**

I just finished working out but have nothing to do so going to do some extra mat work just to kill some time


**141.** `10:07` **You**

Wanna chat


**142.** `10:08` **Meredith Lamb (+14169386001)**

k then I’m having more coffee 🙂


**143.** `10:09` **You**

Call me when ready


**144.** `12:15` **You**

❤️


**145.** `14:07` **Meredith Lamb (+14169386001)**

Ermagawd


**146.** `14:07` **Meredith Lamb (+14169386001)**

Done


**147.** `14:07` **You**

are you ok


**148.** `14:07` **Meredith Lamb (+14169386001)**

Think so


**149.** `14:07` **Meredith Lamb (+14169386001)**

We can chat if you want either on teams or here


**150.** `14:07` **You**

let's teams give me a sec


**151.** `14:07` **Meredith Lamb (+14169386001)**

K


**152.** `14:08` **Meredith Lamb (+14169386001)**

Just in macs room with her vape lol


**153.** `14:08` **Meredith Lamb (+14169386001)**

Sorry


**154.** `14:09` **Meredith Lamb (+14169386001)**

K back at my laptop


**155.** `14:09` **You**

kk lol\.\. teams me when ready just set yourself to show offline


**156.** `14:09` **Meredith Lamb (+14169386001)**

I am already


**157.** `14:09` **Meredith Lamb (+14169386001)**

Have been all day


**158.** `14:09` **You**

kk good to go then


**159.** `15:02` **You**

have fun\.\. chat later :\) ❤️


**160.** `16:06` **Meredith Lamb (+14169386001)**

Guess which one is my kid :p

*📎 1 attachment(s)*

**161.** `16:06` **You**

lol the look


**162.** `16:07` **You**

I have gotten a look like that before


**163.** `18:10` **Meredith Lamb (+14169386001)**

Girls all dropped off at the party and now I am going home to have a drink\. I think I deserve it tonight\. Lol


**164.** `18:14` **You**

Nice grats


**165.** `18:27` **Meredith Lamb (+14169386001)**

I didn’t do the yearbook this year but they used my rainbow lion mascot on it :\)

*📎 1 attachment(s)*

**166.** `18:35` **You**

lol


**167.** `18:35` **You**

Just got back from driving Maddies friends


**168.** `18:35` **You**

Tired


**169.** `18:36` **Meredith Lamb (+14169386001)**

Same…\. Drink, tv


**170.** `18:37` **You**

Kk well you have fun with that


**171.** `18:38` **Meredith Lamb (+14169386001)**

Documentary time lol


**172.** `18:39` **You**

I am just looking forward to 9 so I can go to bed\.


**173.** `18:41` **Meredith Lamb (+14169386001)**

Rough day?


**174.** `18:41` **Meredith Lamb (+14169386001)**

Or just bored


**175.** `18:41` **You**

a little of both\.\. the fighting with J this morning\.\. maddie had some kids over so fed them sent them to pool\.\. gracie and I traded barbs\.\.


**176.** `18:42` **You**

it is just wierd when you don't have a relationship with your daughter\.\. it isn't like she is my child it is very messed up


**177.** `18:42` **You**

so that fighting just never stops\.\. and I got 2 more hours and all tomorrow\.


**178.** `18:42` **You**

then I am free for a day


**179.** `18:42` **You**

still haven'


**180.** `18:42` **You**

t


**181.** `18:43` **You**

booked


**182.** `18:43` **You**

because I thought something might come up for you


**183.** `18:43` **Meredith Lamb (+14169386001)**

Maybe she will turn around when she is older and maybe with help


**184.** `18:43` **Meredith Lamb (+14169386001)**

What happened with the psychiatrist


**185.** `18:43` **You**

maybe\.\. just really awkward now\.


**186.** `18:43` **You**

she has to live in Ontario to be part of this DBT class


**187.** `18:43` **You**

even though it is online


**188.** `18:43` **You**

13 weeks


**189.** `18:43` **You**

that would put her here to the end of september I think\.\.


**190.** `18:44` **Meredith Lamb (+14169386001)**

What does dbt stand for


**191.** `18:44` **You**

and between then and now I need to get back to fucking work\.\. get jaimie moves, get the house ready to sell, buy a new place\.


**192.** `18:44` **You**

or rent


**193.** `18:44` **You**

DBT \(Dialectical Behavior Therapy\) training in psychology focuses on equipping individuals with the skills to manage intense emotions, improve interpersonal relationships, and reduce self\-destructive behaviors\. It's a specialized form of cognitive behavioral therapy, particularly effective for those struggling with borderline personality disorder and other conditions characterized by emotional dysregulation\.


**194.** `18:45` **Meredith Lamb (+14169386001)**

Oh wow


**195.** `18:45` **Meredith Lamb (+14169386001)**

Inteeeeeense


**196.** `18:45` **You**

Reaction: 😮 from Meredith Lamb
yeah this is my every day for 5 years


**197.** `18:46` **Meredith Lamb (+14169386001)**

>
Nothing is coming up\. I already told Andrew I’m going to my parents for the day

*💬 Reply*

**198.** `18:48` **You**

what time did you want to go see your parents?


**199.** `18:49` **Meredith Lamb (+14169386001)**

Doesn’t matter but not early


**200.** `18:50` **Meredith Lamb (+14169386001)**

They don’t do early especially my dad


**201.** `18:50` **You**

well hotel goes till 5 or 6 in some cases


**202.** `18:50` **Meredith Lamb (+14169386001)**

They stay up late


**203.** `18:50` **Meredith Lamb (+14169386001)**

Yeah after that is good


**204.** `18:50` **Meredith Lamb (+14169386001)**

I told Andrew I might just stay over


**205.** `18:51` **You**

My story has me out late possibly drinking possibly ubering\.


**206.** `18:51` **You**

fyi


**207.** `18:56` **Meredith Lamb (+14169386001)**

Drinking?? Hmmh


**208.** `18:56` **Meredith Lamb (+14169386001)**

lol


**209.** `18:56` **You**

well\.\. we could do that\.\. but at your parents??


**210.** `18:57` **Meredith Lamb (+14169386001)**

Well depends if you are actually driving


**211.** `18:57` **You**

well what I would do is this\.\.


**212.** `18:57` **You**

We would go to Novotel\.


**213.** `18:58` **You**

I liked it\.\. bit more expensive but nicer room\.\. was comfortable\.


**214.** `18:58` **Meredith Lamb (+14169386001)**

We could visit with my parents and then hang out in basement\. We don’t tell them we hung out all day of course\. Lol


**215.** `18:58` **You**

then drop my car off\.\. somewhere


**216.** `18:58` **You**

and sure hang out\.


**217.** `18:58` **You**

whatever makes you happy\.


**218.** `18:59` **You**

you ok with novotel?


**219.** `19:00` **Meredith Lamb (+14169386001)**

>
We don’t need to drink lol

*💬 Reply*

**220.** `19:01` **Meredith Lamb (+14169386001)**

>
Yes of course

*💬 Reply*

**221.** `19:01` **You**

I mean we can still hang out\.\.


**222.** `19:01` **You**

ow whatever


**223.** `19:01` **You**

lol


**224.** `19:01` **You**

Reaction: 🙄 from Meredith Lamb
you might be sick of me by then


**225.** `19:01` **You**

too much of me for one day


**226.** `19:01` **Meredith Lamb (+14169386001)**

I’m going to talk to my mom tomorrow on phone bc she wants to know how mediators went but said she can wait until tomorrow cuz I was busy


**227.** `19:01` **Meredith Lamb (+14169386001)**

I will tell her plan\. Will leave out Novotel lol


**228.** `19:02` **You**

kk


**229.** `19:03` **You**

so Novotel is 10 am\.\. to 5pm\.\. just saying\.


**230.** `19:09` **You**

honestly wish it was tomorrow lol

*📎 1 attachment(s)*

**231.** `19:09` **You**

but I can wait an extra day :\)


**232.** `19:14` **Meredith Lamb (+14169386001)**

>
Just saying what?

*💬 Reply*

**233.** `19:14` **Meredith Lamb (+14169386001)**

lol


**234.** `19:14` **Meredith Lamb (+14169386001)**

10\-5 is good no?


**235.** `19:15` **Meredith Lamb (+14169386001)**

>
Same

*💬 Reply*

**236.** `19:15` **Meredith Lamb (+14169386001)**

We were hustling discussing cottage weekend omg


**237.** `19:15` **Meredith Lamb (+14169386001)**

Planning


**238.** `19:15` **Meredith Lamb (+14169386001)**

Mac is going to bring a couple friends


**239.** `19:15` **Meredith Lamb (+14169386001)**

She’s so annoying


**240.** `19:15` **You**

>
it is as long as you don't come at 11

*💬 Reply*

**241.** `19:15` **Meredith Lamb (+14169386001)**

I won’t this time


**242.** `19:16` **You**

>
will that make things more difficult

*💬 Reply*

**243.** `19:16` **Meredith Lamb (+14169386001)**

>
Why doesn’t this say the $

*💬 Reply*

**244.** `19:16` **Meredith Lamb (+14169386001)**

>
No makes it more easier for everyone

*💬 Reply*

**245.** `19:16` **Meredith Lamb (+14169386001)**

She is less bitchy


**246.** `19:16` **Meredith Lamb (+14169386001)**

lol


**247.** `19:16` **Meredith Lamb (+14169386001)**

She doesn’t want to go


**248.** `19:16` **You**

>
160\+ i dunno something

*💬 Reply*

**249.** `19:16` **Meredith Lamb (+14169386001)**

Canada Day Parties here in Toronto


**250.** `19:17` **You**

remember my fun card\.\. I am not worried about $$


**251.** `19:17` **Meredith Lamb (+14169386001)**

>
k

*💬 Reply*

**252.** `19:17` **Meredith Lamb (+14169386001)**

I know I know


**253.** `19:17` **You**

are we staying until Monday or tuesday


**254.** `19:17` **Meredith Lamb (+14169386001)**

Doesn’t matter to me


**255.** `19:17` **You**

that is 5 nights though\.\. andrew might get cranky


**256.** `19:18` **Meredith Lamb (+14169386001)**

Andrew’s sister visiting from cali and they will be with her in Newmarket on Tuesday for Canada Day


**257.** `19:18` **Meredith Lamb (+14169386001)**

His sis has a young girl who loves the girls


**258.** `19:18` **Meredith Lamb (+14169386001)**

Like 4 or 5ish


**259.** `19:18` **You**

ok\.\. I can start to look at that trip too\.\. might as well plan it out


**260.** `19:18` **Meredith Lamb (+14169386001)**

Soooooooo glad I no longer have to visit with his sis lol


**261.** `19:19` **You**

would you drive up on Thursday after work?


**262.** `19:22` **Meredith Lamb (+14169386001)**

I think that would make most sense


**263.** `19:31` **You**

DoubleTree by Hilton Windsor Hotel & Suites?? nice hotel in windsor?


**264.** `19:33` **Meredith Lamb (+14169386001)**

I honestly don’t even care so sure\.


**265.** `19:33` **You**

what do you mean you don't care lol


**266.** `19:33` **Meredith Lamb (+14169386001)**

I mean I’d stay in a motel with you I really don’t care tbh


**267.** `19:33` **You**

rofl\.\. ok will keep that in mind\.\. maybe it is the 3 glasses of wine talking


**268.** `19:34` **Meredith Lamb (+14169386001)**

Whatever one is cheaper\. How about that


**269.** `19:34` **Meredith Lamb (+14169386001)**

And I have had one and a half SMALL glasses


**270.** `19:34` **You**

um well Enbridge is paying for first night


**271.** `19:34` **You**

:\)


**272.** `19:34` **Meredith Lamb (+14169386001)**

I honestly don’t care \- for real


**273.** `19:35` **Meredith Lamb (+14169386001)**

This isn’t about luxury\. It is about having some time together


**274.** `19:50` **You**

in planning mode


**275.** `19:50` **Meredith Lamb (+14169386001)**

in photo mode \(Flickr\)


**276.** `19:51` **You**

lol


**277.** `19:52` **You**

what are you looking at


**278.** `19:53` **Meredith Lamb (+14169386001)**

Just adding marmar’s grad photos\. Trying to better\. I took some years off and trying… it’s hard tho


**279.** `19:58` **Meredith Lamb (+14169386001)**

Came across… what I’m working towards…

*📎 1 attachment(s)*

**280.** `19:59` **Meredith Lamb (+14169386001)**

This morning … gahhhhh

*📎 1 attachment(s)*

**281.** `19:59` **Meredith Lamb (+14169386001)**

Top photo 20lbs\. Bottom 15 lbs and too heavy


**282.** `20:06` **You**

>
when was tius

*💬 Reply*

**283.** `20:07` **Meredith Lamb (+14169386001)**

2019 or 2020 not sure …would have to go back and look and moved on to other things lol


**284.** `20:08` **Meredith Lamb (+14169386001)**

I know that because I had less body fat before 2019/2020


**285.** `20:08` **Meredith Lamb (+14169386001)**

But I wasn’t very “healthy”


**286.** `20:09` **Meredith Lamb (+14169386001)**

I was healthier here


**287.** `20:09` **Meredith Lamb (+14169386001)**

Overall


**288.** `20:14` **You**

err mah gerd


**289.** `20:14` **You**

HOLY FARM


**290.** `20:14` **You**

FARK


**291.** `20:14` **Meredith Lamb (+14169386001)**

I was a little obsessed before that like you are now lol


**292.** `20:15` **You**

Reaction: 😮 from Meredith Lamb
I booked Hyatt for Thursday\.\. and called them to just extend it onto my Friday personal card\.\. 20 minute convo


**293.** `20:15` **Meredith Lamb (+14169386001)**

Then I got more balanced …


**294.** `20:15` **Meredith Lamb (+14169386001)**

Then Covid


**295.** `20:15` **Meredith Lamb (+14169386001)**

And it all went to hell


**296.** `20:15` **You**

shit yeah you got lats and everything


**297.** `20:16` **You**

originally I was going to go to Grand Rapids Sat morning\.\. and back to Detroit\.\. but if you give zero shits\.\. we can just stay in Grand Rapids\.\. and we can head back to Detroit for Sunday Monday or do whatever you want


**298.** `20:16` **You**

less driving in one day if we do that


**299.** `20:18` **You**

I will dial back the $$ LOL after this because apparently you just want me for my body and don't care where we stay\.\.\. I am good with that\.\. or was it my mind?? or my glasses?


**300.** `20:20` **Meredith Lamb (+14169386001)**

👓


**301.** `20:21` **Meredith Lamb (+14169386001)**

I’m going to give you $$ btw


**302.** `20:21` **Meredith Lamb (+14169386001)**

Will just have to be creative in how I give it to you 🙂


**303.** `20:21` **You**

no


**304.** `20:21` **You**

just love


**305.** `20:21` **Meredith Lamb (+14169386001)**

Meaning cash


**306.** `20:21` **Meredith Lamb (+14169386001)**

No


**307.** `20:21` **You**

yes


**308.** `20:21` **Meredith Lamb (+14169386001)**

No


**309.** `20:21` **You**

hugs


**310.** `20:21` **You**

Reaction: 😂 from Meredith Lamb
and stuff


**311.** `20:21` **You**

more hugs


**312.** `20:22` **You**

I mena


**313.** `20:22` **You**

mean


**314.** `20:22` **Meredith Lamb (+14169386001)**

I’m good with “stuff” but will also give you $


**315.** `20:22` **Meredith Lamb (+14169386001)**

lol


**316.** `20:22` **You**

I don't like it\.


**317.** `20:22` **You**

you pay for food


**318.** `20:23` **Meredith Lamb (+14169386001)**

Just chill\.


**319.** `20:24` **Meredith Lamb (+14169386001)**

Sure I will pay for food


**320.** `20:24` **Meredith Lamb (+14169386001)**

But I’m giving you some money


**321.** `20:24` **You**

shhhhhhh stop talking about money\.\.\.


**322.** `20:24` **You**

go get another glass


**323.** `20:24` **Meredith Lamb (+14169386001)**

lol


**324.** `20:24` **Meredith Lamb (+14169386001)**

I mean, Andrew knows I’m going away with friends so obviously it cost money


**325.** `20:24` **You**

if you give me the money it has to be cash and you have to slip it to me on the low low\.


**326.** `20:25` **Meredith Lamb (+14169386001)**

lol


**327.** `20:26` **Meredith Lamb (+14169386001)**

kk got it


**328.** `20:26` **You**

or


**329.** `20:26` **You**

don't


**330.** `20:26` **You**

:\)


**331.** `20:26` **You**

that also works


**332.** `20:26` **Meredith Lamb (+14169386001)**

Uh huh


**333.** `20:45` **You**

not ignoring focused


**334.** `20:46` **Meredith Lamb (+14169386001)**

Same actually


**335.** `20:49` **You**

what are you focused on


**336.** `20:50` **Meredith Lamb (+14169386001)**

Just going through old pix and adding here and there to Flickr albums


**337.** `20:50` **Meredith Lamb (+14169386001)**

I was negligent for a long time


**338.** `20:50` **You**

ah ok memory lane time'


**339.** `20:59` **Meredith Lamb (+14169386001)**

Going too hard at this time …\.

*📎 1 attachment(s)*

**340.** `21:01` **Meredith Lamb (+14169386001)**

Had knee surgery 2 months prior to this


**341.** `21:03` **Meredith Lamb (+14169386001)**

Apparently we are now having a sleepover tonight\. And tomorrow\.


**342.** `21:03` **Meredith Lamb (+14169386001)**

Yaye


**343.** `21:04` **Meredith Lamb (+14169386001)**

Tonight is the young one tho


**344.** `21:05` **You**

yay


**345.** `21:05` **You**

ok


**346.** `21:05` **You**

grand rapids booked


**347.** `21:06` **You**


*📎 1 attachment(s)*

**348.** `21:07` **You**

honestly didn't plan on hyatt again was just a really good deal


**349.** `21:07` **You**

>
why too hard?

*💬 Reply*

**350.** `21:07` **You**

>
oh so much fun\.\.\.\.\. YAY\!\!

*💬 Reply*

**351.** `21:08` **You**

this one is a NICE room


**352.** `21:08` **You**

and it was for the same rate as rest


**353.** `21:08` **You**

so like why not


**354.** `21:08` **You**

ok now I will downscale\.\.


**355.** `21:08` **You**

lol


**356.** `21:08` **Meredith Lamb (+14169386001)**

>
Just too much for me\. I think\. I got really thin eventually and it wasn’t sustainable\. Working out 6 days a week hard\.

*💬 Reply*

**357.** `21:08` **You**

so thurs fri in windsor sat in grand rapids


**358.** `21:08` **You**

yeah


**359.** `21:09` **You**

you cannot go hard when losing weight


**360.** `21:09` **You**

you almost need to do body weight only


**361.** `21:09` **You**

or you need to hit your macros


**362.** `21:09` **You**

eat protein and actually redistribute fat to muscle


**363.** `21:09` **You**

kinda what I am doing


**364.** `21:09` **You**

I am not losing really any weight but I look thinner


**365.** `21:09` **You**

still wanna lose 10 lbs


**366.** `21:09` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 19 Jun 2025 21:10:15 \-0400
|
| Yeah I wasn’t very smart\. I was eating a lot of protein but not doing doing macros
|
| Version: 1
| Sent: Thu, 19 Jun 2025 21:09:54 \-0400
|
| Yeah I wasn’t very smart\. I was eating malt of protein but not doing doing macros


**367.** `21:13` **You**

I don't care what you do\.\. I just want you to feel good about yourself\.\. be healthy, and have "energy" LOL  I just want you to be happy mer\.\. I don't care about anything else\.


**368.** `21:14` **You**

so that get's through to Sunday\.\. where do we want to go\.\. did you want to see your friend in detroit


**369.** `21:14` **You**

should we come straight back to Canada where it is cheaper?? lol


**370.** `21:14` **You**

did you want to stay at another hotel\.\. or we could drive to a BNB for Sunday/Monday night


**371.** `21:14` **You**

I am open


**372.** `21:14` **Meredith Lamb (+14169386001)**

>
No haven’t even mentioned it to her

*💬 Reply*

**373.** `21:14` **Meredith Lamb (+14169386001)**

>
Yes

*💬 Reply*

**374.** `21:14` **You**

ok


**375.** `21:15` **You**

bnb or hotel?? any thoughts\.\. any ideas where?


**376.** `21:15` **You**

likes?? that place you mentioned


**377.** `21:15` **You**

Grand something


**378.** `21:15` **Meredith Lamb (+14169386001)**

Hmmh


**379.** `21:15` **Meredith Lamb (+14169386001)**

Grand bend\. Kind of out of the way tho


**380.** `21:16` **You**

ok\.\. well if you have any ideas I don't need to book tonight


**381.** `21:17` **Meredith Lamb (+14169386001)**

Could just stay in London?


**382.** `21:17` **You**

stomping grounds


**383.** `21:17` **You**

sure


**384.** `21:17` **Meredith Lamb (+14169386001)**

Have you ever been there?


**385.** `21:17` **Meredith Lamb (+14169386001)**

lol


**386.** `21:17` **You**

show me around


**387.** `21:17` **You**

all the trouble spots


**388.** `21:17` **Meredith Lamb (+14169386001)**

lol


**389.** `21:17` **You**

that is where the web company was no?


**390.** `21:17` **Meredith Lamb (+14169386001)**

No


**391.** `21:17` **You**

MBA?


**392.** `21:18` **Meredith Lamb (+14169386001)**

King street Toronto was dot com


**393.** `21:18` **Meredith Lamb (+14169386001)**

I didn’t undergrad and mba in London


**394.** `21:18` **Meredith Lamb (+14169386001)**

My bro and SIL live there


**395.** `21:18` **Meredith Lamb (+14169386001)**

I have many friends there


**396.** `21:18` **You**

ok\.\.


**397.** `21:18` **You**

London it is


**398.** `21:19` **You**

yes\.\. I am sure there some interesting things we can do there :\)


**399.** `21:20` **Meredith Lamb (+14169386001)**

London is ok\.


**400.** `21:20` **Meredith Lamb (+14169386001)**

lol


**401.** `21:21` **Meredith Lamb (+14169386001)**

My SIL would LOVE to meet you I bet


**402.** `21:21` **Meredith Lamb (+14169386001)**

lol


**403.** `21:21` **Meredith Lamb (+14169386001)**

not my bro in London tho


**404.** `21:21` **Meredith Lamb (+14169386001)**

Socially awkward


**405.** `21:21` **Meredith Lamb (+14169386001)**

My SIL is sooooooo social


**406.** `21:21` **You**

where did you live in London when you lived there


**407.** `21:21` **Meredith Lamb (+14169386001)**

Depends


**408.** `21:22` **Meredith Lamb (+14169386001)**

Undergrad diff than mba


**409.** `21:22` **You**

If I could select an Air BNB where would you like it to be near?


**410.** `21:22` **Meredith Lamb (+14169386001)**

My bro lives in whiteoaks area near four points Sheraton


**411.** `21:23` **You**

I mean we can do that\.\. I was thinking staying someplace you might want to walk around\.


**412.** `21:23` **Meredith Lamb (+14169386001)**

Just not near airport / east London


**413.** `21:23` **Meredith Lamb (+14169386001)**

East London is the bad part


**414.** `21:23` **You**

but if you want whiteoks I can look there


**415.** `21:26` **Meredith Lamb (+14169386001)**

Well let me look\. Masonville is good too


**416.** `21:28` **You**

ROFL


**417.** `21:28` **You**

we could stay at IVY Spencer Leadership


**418.** `21:28` **You**

BLECh


**419.** `21:28` **Meredith Lamb (+14169386001)**

Aw memories


**420.** `21:28` **Meredith Lamb (+14169386001)**

That’s Masonville area


**421.** `21:28` **You**

ROFL\.\. of you flirting with me


**422.** `21:29` **You**

yeah


**423.** `21:29` **You**

I remember


**424.** `21:30` **Meredith Lamb (+14169386001)**

>
Unintentional

*💬 Reply*

**425.** `21:31` **You**

mmmmm hmmmm


**426.** `21:31` **You**

sure it was part of the plan


**427.** `21:31` **You**

Reaction: 😂 from Meredith Lamb
you were charming


**428.** `21:31` **You**

had me hooked even then


**429.** `21:31` **You**

I was def into you at that point


**430.** `21:31` **You**

for real


**431.** `21:31` **Meredith Lamb (+14169386001)**

>
Aka\. Drunk\.

*💬 Reply*

**432.** `21:31` **You**

no happy smiling infectious


**433.** `21:32` **You**

also reported to me\.\. as I was painfully aware


**434.** `21:32` **You**

honestly if you hadn't reported to me\.\. and you still came to me with that I probably would have said something sooner to you\.\. I think\.


**435.** `21:32` **Meredith Lamb (+14169386001)**

Doubt it\.


**436.** `21:32` **Meredith Lamb (+14169386001)**

lol


**437.** `21:32` **You**

smitten


**438.** `21:33` **You**

remember I had already decided in Jan\.\.\.\. I still wasn't looking\.\. but I did like you already


**439.** `21:34` **Meredith Lamb (+14169386001)**

Reaction: 🙂 from Scott Hicks
It was a good time\. I just drank too much\. Blame Jim\.


**440.** `21:34` **Meredith Lamb (+14169386001)**

Not like it hadn’t ever happened before tho\. Lol


**441.** `21:34` **You**

you always blame jim


**442.** `21:34` **Meredith Lamb (+14169386001)**

It’s always his fault\.


**443.** `21:34` **You**

not with me around


**444.** `21:34` **You**

there was another offsite but I didn't go


**445.** `21:35` **Meredith Lamb (+14169386001)**

Jim and I used to work for this guy Ed \(he’s on my facebook\) and he liked TO DRINK


**446.** `21:35` **Meredith Lamb (+14169386001)**

Phew


**447.** `21:35` **Meredith Lamb (+14169386001)**

I had a hard time keeping up to Ed but he was fun


**448.** `21:35` **Meredith Lamb (+14169386001)**

>
The most recent one?

*💬 Reply*

**449.** `21:36` **You**

No I went to the one in Feb


**450.** `21:36` **You**

remember we froze outside


**451.** `21:36` **You**

there was one before that I think i missed but I thought you went


**452.** `21:36` **Meredith Lamb (+14169386001)**

But you kissed one this week


**453.** `21:36` **You**

yeah I wasn't counting this one


**454.** `21:36` **Meredith Lamb (+14169386001)**

>
No

*💬 Reply*

**455.** `21:36` **You**

ah ok


**456.** `21:37` **Meredith Lamb (+14169386001)**

Now that I’m not a ppl leader I won’t have to drink with Alison anymore


**457.** `21:37` **Meredith Lamb (+14169386001)**

lol


**458.** `21:37` **Meredith Lamb (+14169386001)**

Used to do that at Bay Street gatherings


**459.** `21:37` **Meredith Lamb (+14169386001)**

She’s a good drinker


**460.** `21:38` **You**

yeah I know


**461.** `21:38` **You**

I have drank with her before


**462.** `21:38` **You**

she can hold


**463.** `21:41` **Meredith Lamb (+14169386001)**

She really can


**464.** `21:41` **Meredith Lamb (+14169386001)**

Her voice gets LOWER


**465.** `21:41` **Meredith Lamb (+14169386001)**

lol


**466.** `21:41` **You**

I know I told you that the other day


**467.** `21:41` **You**

the alison that curses and swears


**468.** `21:41` **You**

and has a lower voice lol


**469.** `21:42` **Meredith Lamb (+14169386001)**

Yeah we talked in the hall for 20 min or so a couple weeks ago and no high voice at all\. Thank god


**470.** `21:42` **Meredith Lamb (+14169386001)**

Ian interrupted us twice and she was so rude to him


**471.** `21:42` **Meredith Lamb (+14169386001)**

I found it really odd


**472.** `21:42` **You**

OK I am about to book 4 points sheraton or do I hold


**473.** `21:42` **You**

most of these are non refundable for better rates\.


**474.** `21:42` **Meredith Lamb (+14169386001)**

Is the rate ok or no


**475.** `21:42` **Meredith Lamb (+14169386001)**

What is it


**476.** `21:43` **You**

336 two nights


**477.** `21:43` **You**

150 \+ tax for a king


**478.** `21:43` **You**

not bad


**479.** `21:43` **Meredith Lamb (+14169386001)**

150 per


**480.** `21:43` **You**

yeah


**481.** `21:43` **Meredith Lamb (+14169386001)**

Yeah just do that


**482.** `21:43` **Meredith Lamb (+14169386001)**

It is right near my SIL


**483.** `21:43` **You**

I am not staying in a crap place this trip\.\. first trip\.\. staying in decent places\.\. after that you can get cheap me\.


**484.** `21:43` **You**

LOL


**485.** `21:43` **Meredith Lamb (+14169386001)**

If she is home we can meet her lol


**486.** `21:43` **You**

and the stuff I mentioned earlier\.\., you will have to live with that


**487.** `21:44` **Meredith Lamb (+14169386001)**

I’m honestly not picky\. Andrew is\. I’m not\.


**488.** `21:44` **Meredith Lamb (+14169386001)**

I grew up with my rents


**489.** `21:44` **Meredith Lamb (+14169386001)**

I will tell you about our trips to Paris sometime and where we stayed


**490.** `21:45` **You**

booked


**491.** `21:45` **You**

ok windsor thurs fri grand rapids sat sun sun night back to London \- bit of a drive\.\. lol but then there until leaving tuesday


**492.** `21:46` **You**

ok\.\. now I feel good Sat is booked\.\. next weekend is booked\.


**493.** `21:46` **You**

now just stupid tomorrow\.


**494.** `21:46` **You**

boooooo


**495.** `21:46` **Meredith Lamb (+14169386001)**

I might go to my parents tomorrow night\. Will see\.


**496.** `21:46` **Meredith Lamb (+14169386001)**

Probably not tho


**497.** `21:46` **Meredith Lamb (+14169386001)**

Would be easier to get out


**498.** `21:47` **Meredith Lamb (+14169386001)**

But I think I can get out easy here too


**499.** `21:47` **You**

you got a sleep over\.\. but yeah the second thing


**500.** `21:47` **Meredith Lamb (+14169386001)**

Would rather stay over there sat night


**501.** `21:47` **You**

yeah better call\.


**502.** `21:47` **You**

Reaction: ❤️ from Meredith Lamb
K I am going to watch a show with Gracie\.\. grab a light snack and go to bed\.\. cardio and core tomorrow morning/


**503.** `21:47` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**504.** `21:48` **Meredith Lamb (+14169386001)**

Grad is tiring\.

*💬 Reply*

**505.** `21:48` **You**

🤮🤮🤮🤮🤮🤮🤮🤮🤮


**506.** `21:48` **You**

Sorry\.\. lol  the niceities


**507.** `21:48` **Meredith Lamb (+14169386001)**

Good luck


**508.** `21:48` **Meredith Lamb (+14169386001)**

Love you


**509.** `21:49` **You**

Love you to mer xoxo❤️❤️❤️


**510.** `21:49` **You**

will message you in morning looking forward to tomorrow being over :\)


**511.** `21:50` **Meredith Lamb (+14169386001)**

>
If you met valé you would understand it is all sincere and not niceties\. She is the coolest kid I’ve ever met\. She always makes me feel better\. Such a strange kid\.

*💬 Reply*

**512.** `21:50` **You**

It's nice to know someone like that\.\. you are the one that always makes me feel better\.\. but you are only a little strange\.


**513.** `21:51` **You**

strange in a hot mom kinda way I mean


**514.** `21:51` **You**

🥰


**515.** `21:52` **Meredith Lamb (+14169386001)**

Ciria and I are actually closer than that text exchange indicates\. In person she is Mexican so English as a second language


**516.** `21:52` **Meredith Lamb (+14169386001)**

G’nite ❤️❤️


**517.** `21:52` **You**

I mean a lot of emoji usage


**518.** `21:52` **You**

:\)


**519.** `21:52` **You**

luv you\.\. night lol


**520.** `21:53` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**521.** `21:53` **Meredith Lamb (+14169386001)**

😋😋😐😂😕🙄😇🤪🤓🙁🤓🧐❤️🙃😬🤔😛😍😝😝🙂🥳😢😱😵‍💫🫩


**522.** `21:53` **Meredith Lamb (+14169386001)**

Emoji usage


**523.** `21:53` **Meredith Lamb (+14169386001)**

lol


**524.** `21:57` **You**

Hehe


**525.** `21:58` **You**

❤️


**526.** `22:01` **You**

Not watching show running to get a Carte what a life


**527.** `22:01` **Meredith Lamb (+14169386001)**

wtf?


**528.** `22:01` **Meredith Lamb (+14169386001)**

You should make her go with you at least


**529.** `22:02` **You**

No she offered I didn’t want her to


**530.** `22:02` **Meredith Lamb (+14169386001)**

You should make her


**531.** `22:02` **Meredith Lamb (+14169386001)**

What is a Carte btw


**532.** `22:02` **You**

I didn’t want the company


**533.** `22:02` **You**

Vape with we’d


**534.** `22:03` **You**

Weed


**535.** `22:03` **You**

Nothing you need


**536.** `22:03` **You**

lol


**537.** `22:03` **Meredith Lamb (+14169386001)**

Oh and you just buy this shit for her\.  Scott…\.\.


**538.** `22:03` **You**

Yeah if I don’t she puts hokes in walls


**539.** `22:04` **You**

It’s like being held hostage


**540.** `22:04` **You**

She does that j defends her


**541.** `22:04` **Meredith Lamb (+14169386001)**

😵‍💫


**542.** `22:05` **You**

Yep


**543.** `22:05` **You**

Drives me insane


**544.** `22:10` **Meredith Lamb (+14169386001)**

I mean you can’t do this forever so eventually it will end


**545.** `22:12` **You**

She will be gone


**546.** `22:12` **You**

That is when


**547.** `22:15` **Meredith Lamb (+14169386001)**

And hopefully grown / self sufficient at some point :\)


**548.** `22:15` **Meredith Lamb (+14169386001)**

Hopefully


**549.** `22:15` **You**

I do t know about that


**550.** `22:15` **You**

Set you go to bed love I am almost home appreciate you talking to me


**551.** `22:21` **Meredith Lamb (+14169386001)**

Nite going to just think of you for a bit before I drift…\. xoxo


**552.** `22:24` **You**

Love you too thinking about you right now


**553.** `22:24` **You**

Thinking of say


**554.** `22:24` **You**



**555.** `22:24` **You**

Sat


**556.** `22:24` **Meredith Lamb (+14169386001)**

❤️


**557.** `22:28` **You**

❤️


