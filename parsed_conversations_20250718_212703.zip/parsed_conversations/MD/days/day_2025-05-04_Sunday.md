# Daily Conversation: 2025-05-04 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-04 |
| **Day** | Sunday |
| **Week** | 4 |
| **Messages** | 627 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-04T02:47 - 2025-05-04T22:15 |

## 📝 Daily Summary

This day contains **627 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `02:47` **You**

Reaction: ❤️ from Meredith Lamb
>
Rofl well played………

*💬 Reply*

**002.** `02:48` **You**

Sigh ❤️


**003.** `02:51` **You**

How are you awake


**004.** `02:52` **Meredith Lamb (+14169386001)**

On and off…


**005.** `02:52` **You**

Messy?


**006.** `02:52` **Meredith Lamb (+14169386001)**

lol no


**007.** `02:52` **Meredith Lamb (+14169386001)**

I wish


**008.** `02:53` **Meredith Lamb (+14169386001)**

Though


**009.** `02:53` **You**

I just woke up will be hard to go back to sleep now


**010.** `02:53` **Meredith Lamb (+14169386001)**

Too much to do tomorrow


**011.** `02:53` **Meredith Lamb (+14169386001)**

You shouldnt have gotten on your phone


**012.** `02:54` **You**

I had to check 1st thing I thought about


**013.** `02:55` **You**

If you are tired though I will leave you be


**014.** `02:55` **Meredith Lamb (+14169386001)**

I’m always tired these days\. :p


**015.** `02:56` **You**

Well then I should leave you to try to sleep\.


**016.** `02:56` **Meredith Lamb (+14169386001)**

Will you sleep?


**017.** `02:56` **You**

Not likely


**018.** `02:57` **Meredith Lamb (+14169386001)**

But you will try


**019.** `02:58` **You**

I mean sure I guess pretty awake tho\.  It’s fine I slept straight since 1120


**020.** `02:58` **Meredith Lamb (+14169386001)**

That’s not much sleep


**021.** `02:59` **You**

More than I get a lot of times


**022.** `02:59` **Meredith Lamb (+14169386001)**

Maybe you just need more sleep to feel better


**023.** `03:00` **Meredith Lamb (+14169386001)**

Maybe lack of sleep is driving you nuts


**024.** `03:01` **You**

Maybe you are really tired and should just go to bed lol sound like it\.  Don’t worry about me I will do whatever


**025.** `03:01` **Meredith Lamb (+14169386001)**

I am tired\.


**026.** `03:02` **Meredith Lamb (+14169386001)**

And I worry about you\.


**027.** `04:07` **You**

Night love you\.


**028.** `06:10` **You**

Reaction: ❤️ from Meredith Lamb
Stayed home and dreamed of us\.  Was nice ❤️


**029.** `09:54` **Meredith Lamb (+14169386001)**

Slept in…\. Still not up\. Gummies are good for my sleep apparently\.


**030.** `09:59` **You**

Yeah I am getting up now need to do work


**031.** `10:00` **You**

Another super fun day\!\! Whee


**032.** `10:07` **You**

Demotivated for a number of reasons no matter how successful I am in one place something else falls
Apart
It seems\.\. here there everywhere\. What a mess\.  Changed my Hyksos last night to declutterring my mind and getting rid of negative thoughts but it will take some time to work I think


**033.** `10:13` **Meredith Lamb (+14169386001)**

I think it will eventually all come together but there is a lot of fall out you will probably be dealing with for a long time… I don’t think it means everything is falling apart tho\.


**034.** `10:13` **Meredith Lamb (+14169386001)**

Just bumps in the road


**035.** `10:14` **Meredith Lamb (+14169386001)**

Really big pot holes


**036.** `10:20` **Meredith Lamb (+14169386001)**

I was thinking about your control comment and I’m not doing that intentionally by any means\. But I can see what you mean\. It isn’t you though it is more my life and everything going on and just protecting speed, flow, intensity \(not that I’ve done a good job\)\. This has moved really fast\. Like really… and we aren’t even out of our respective situations yet\. My kids don’t even know\. Gah\. Yet I’m looking at a rental tonight and will have to make some story to them about where I am\.


**037.** `10:20` **You**

The only thing I have positive movement on is me physically


**038.** `10:20` **You**

lol


**039.** `10:20` **You**

228 today


**040.** `10:20` **You**

So there is that


**041.** `10:20` **You**

I started
252


**042.** `10:21` **Meredith Lamb (+14169386001)**

>
Very amazing … you and Mackenzie right Joe…

*💬 Reply*

**043.** `10:21` **Meredith Lamb (+14169386001)**

\*now


**044.** `10:21` **You**

>
The control thing is about protecting yourself

*💬 Reply*

**045.** `10:21` **You**

It isn’t about wanting to own me


**046.** `10:21` **You**

I think it will break down in time


**047.** `10:22` **You**

As you become more comfortable


**048.** `10:22` **You**

I was just 85% comfortable
With you immediately


**049.** `10:22` **You**

And was willing to put a lot on trust


**050.** `10:22` **You**

Am willing


**051.** `10:22` **Meredith Lamb (+14169386001)**

>
I have a lot to protect right now\. My life is a shitstorm\.

*💬 Reply*

**052.** `10:22` **You**

I meant yourself


**053.** `10:22` **You**

Not everything


**054.** `10:22` **You**

Just you


**055.** `10:22` **Meredith Lamb (+14169386001)**

Yeah


**056.** `10:23` **You**

I think you have a harder time to let go to give
Over
To someone else
To trust


**057.** `10:23` **Meredith Lamb (+14169386001)**

Well you could impulsively change your mind on me tomorrow\. You do that with decisions and ppl


**058.** `10:23` **You**

And rightly so


**059.** `10:23` **You**

No


**060.** `10:23` **You**

I dont


**061.** `10:23` **Meredith Lamb (+14169386001)**

Yes


**062.** `10:23` **You**

I told you I thought about this thing for years


**063.** `10:23` **You**

Before deciding to pull the trigger


**064.** `10:23` **You**

But when I pull it I am sure


**065.** `10:24` **You**

That is the diff


**066.** `10:24` **You**

And with you I have been nearly 100% transparent and honest which is like\. I thing before the buys I hold back are to protect me and my perception of what you might do if I open up all the way


**067.** `10:25` **You**

So honestly you have nothing to worry about I am saying this and don’t correct me… I am never leaving


**068.** `10:25` **You**

Ever


**069.** `10:25` **You**

I don’t care about the process


**070.** `10:25` **You**

This is not impulsive it is something else
Revelationary


**071.** `10:25` **You**

It I am as certain of this and of using absolutes


**072.** `10:26` **You**

Again barring you don’t do something terrible which I cannot foresee or believe you would do to me


**073.** `10:26` **You**

There that is all there is


**074.** `10:26` **Meredith Lamb (+14169386001)**

And I think I know all that deep down but my head has a very strong protect mode perhaps


**075.** `10:27` **Meredith Lamb (+14169386001)**

Not sure


**076.** `10:27` **You**

I head and heart


**077.** `10:27` **Meredith Lamb (+14169386001)**

I really believe what you say like 90%


**078.** `10:27` **You**

There are no detours here me


**079.** `10:27` **You**

Mer


**080.** `10:27` **Meredith Lamb (+14169386001)**

There is a piece of me that is all “mm Hmmh”


**081.** `10:27` **You**

No off ramps


**082.** `10:27` **You**

This is not a game


**083.** `10:27` **You**

And I have never been more serious


**084.** `10:28` **Meredith Lamb (+14169386001)**

I will try to believe you with everything that I have because I really hope that is true for both of us


**085.** `10:28` **You**

Again problem is I cannot show you lol


**086.** `10:28` **Meredith Lamb (+14169386001)**

Yeah


**087.** `10:29` **You**

Please
Don’t try please just believe doubt is the killer of relationships my doubt of you and Andrew almost
Broke me


**088.** `10:29` **You**

It still bothers me but I can shut it down


**089.** `10:30` **You**

I know there is nothing going on I know you aren’t going back to him\.\. I say that over and over\.\. and I force doubt to fuck off\.


**090.** `10:31` **Meredith Lamb (+14169386001)**

I don’t sit and live in doubt\. I just for sure have it but I don’t focus on it tbh and if I could see you, feel you, taste you … it would all go away…\.\.


**091.** `10:31` **You**

Yeah and my worry is you cannot last… despite my concerns I know I can last it will just hurt a lot\. But be worth it in the end


**092.** `10:32` **You**

I still have that concern\.\. cannot help that one \.  Which is why I wanted to get to a scenario where we could have some
Predictable interaction


**093.** `10:32` **You**

And then last night that sounded way the fuck off


**094.** `10:32` **You**

So yeah it was a little fought


**095.** `10:32` **You**

Rough


**096.** `10:32` **Meredith Lamb (+14169386001)**

I will figure something out


**097.** `10:33` **Meredith Lamb (+14169386001)**

I think I can last


**098.** `10:33` **Meredith Lamb (+14169386001)**

It will just impact my behaviour


**099.** `10:33` **Meredith Lamb (+14169386001)**

But I will do my best obviously\.


**100.** `10:33` **Meredith Lamb (+14169386001)**

All of this is a lot and I still have so much to deal with here


**101.** `10:34` **Meredith Lamb (+14169386001)**

So I’m not too concerned short term


**102.** `10:34` **You**

You don’t need to compromise yourself
For this


**103.** `10:34` **Meredith Lamb (+14169386001)**

More longer time


**104.** `10:34` **You**

I told you I will deal


**105.** `10:34` **You**

The weekends are just the absolute worst


**106.** `10:35` **Meredith Lamb (+14169386001)**

Yeah and getting more and more so


**107.** `10:35` **Meredith Lamb (+14169386001)**

Not even staying the same


**108.** `10:35` **You**

Look you keep on with your thing\.\. this is what I am worried about for you things will
Get worse and you will be like fuck it not worth it


**109.** `10:36` **Meredith Lamb (+14169386001)**

No I will not Scott\.


**110.** `10:36` **You**

So just don’t let me affect you I will try to keep down the emotions for a while


**111.** `10:37` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I can lie here and imagine kissing your neck and I feel better


**112.** `10:37` **Meredith Lamb (+14169386001)**

I will be fine


**113.** `10:37` **Meredith Lamb (+14169386001)**

lol


**114.** `10:37` **You**

Reaction: 😂 from Meredith Lamb
In fact
Lets
Put a moritorium in my emotions for a while\.


**115.** `10:37` **You**

>
That is very much one of the numbers for me

*💬 Reply*

**116.** `10:38` **Meredith Lamb (+14169386001)**

I will find them all\. Don’t tell me


**117.** `10:39` **You**

>
It will mean shorter convos I think\.\.  because eventually they come out\. I matter what I do\.\. but I think I can manage that\.

*💬 Reply*

**118.** `10:40` **Meredith Lamb (+14169386001)**

I like your emotions but not when they are pulling you into a deep dark hole\.


**119.** `10:40` **You**

I also won’t bug you about trip idea anymore as I think it just puts pressure on you\.


**120.** `10:41` **You**

Reaction: 😢 from Meredith Lamb
>
Yeah I know that but deep dark holes seem to be the norm lately\.

*💬 Reply*

**121.** `10:41` **Meredith Lamb (+14169386001)**

>
You haven’t been bugging me\. Relax\.

*💬 Reply*

**122.** `10:41` **You**

I still have no problems telling you how I feel about you and that hasn’t chenged an inch through all of this only gotten stronger


**123.** `10:42` **You**

>
Well it is that and knowing you cannot do anything about it\.  I get disappointed so best to just forget about it\.\. for now at least\.  I will take some time for me because I need it I will figure out what that looks like

*💬 Reply*

**124.** `10:43` **Meredith Lamb (+14169386001)**

When Mackenzie and Andrew and Mar Mar are in Edmonton at nationals maybe we can swing something


**125.** `10:43` **Meredith Lamb (+14169386001)**

Work dinner lol


**126.** `10:44` **Meredith Lamb (+14169386001)**

We will see … I’m not opposed to a trip at all but it can’t be suspicious and I need to get my ass moved out of this house so I may need to take time off to move


**127.** `10:48` **You**

Yep understood I get it\.\. sorry I just had to go upstairs to make my morning drink and take my pills


**128.** `10:49` **You**

Again somehow I need to shit down a bit for a while lower expectations\.\. and I think that will help me cope\.\. if I can do that or not is a good question\.


**129.** `10:50` **You**

But I cannot remain this open and vulnerable all the time and not take body blows every days


**130.** `10:50` **You**

Like it isn’t what you are doing to me it is life


**131.** `10:51` **You**

Deleted?


**132.** `10:51` **You**

lol


**133.** `10:52` **Meredith Lamb (+14169386001)**

I hope it isn’t me\. I will open up to you about anything you want\. I just may not exactly initiate these big msgs of emotional revelations on the fly while focusing on all this other crap


**134.** `10:52` **You**

I don’t need you too especially not now


**135.** `10:53` **Meredith Lamb (+14169386001)**

Finding balancing all of the stuff …\. Challenging\. And holy, the secrecy piece is about to make me lose it\. I have 2 secrecy pieces : 1\. My kids and then 2\. Us


**136.** `10:54` **Meredith Lamb (+14169386001)**

I feel like I’m navigating this strange world where everyone in my life knows a different version of my reality right now and I have to try to remember what that version is constantly


**137.** `10:54` **Meredith Lamb (+14169386001)**

😜


**138.** `10:54` **You**

Yep I know that feeling \.\. but I was built for that\.


**139.** `10:54` **You**

That is exactly how my brain helps me\.


**140.** `10:55` **You**

When it is not stomping on everything else I don’t know why it does this to me it is really distressing but it has consistently through my whole life\.


**141.** `10:55` **You**

Might be a childhood thing


**142.** `10:56` **You**

I was never good enough\.\. as much as
I loved
My mum and we were as tight as
You could be, that is how I was raised and it was kind of relentless and brutal


**143.** `10:56` **You**

And I mean that shapes you


**144.** `10:56` **Meredith Lamb (+14169386001)**

>
This tracks incredibly…\.

*💬 Reply*

**145.** `10:56` **You**

Yep


**146.** `10:56` **You**

I would be compared
To
Others to my sister but always in a manner Thant
Made
Me less than


**147.** `10:57` **Meredith Lamb (+14169386001)**

I feel it in your anxieties about us


**148.** `10:57` **You**

Because she thought it would motivate me


**149.** `10:57` **Meredith Lamb (+14169386001)**

They are all related to not being good enough it seems or either fucking something up


**150.** `10:57` **You**

You are soo important to me it is not even rational


**151.** `10:57` **You**

So yeah my brain went into overdrive, and so did my heart same time


**152.** `10:57` **You**

And my heart had t done shit for a
Long long time


**153.** `10:57` **Meredith Lamb (+14169386001)**

Our relationship is not built on performance though\. I am not connected to you for that reason\.


**154.** `10:58` **You**

It isn’t necessarily performance it is connection


**155.** `10:58` **You**

I mean I worry about performance don’t get me wrong we talked kind of about that the other night


**156.** `10:58` **Meredith Lamb (+14169386001)**

I mean performance is all aspects


**157.** `10:58` **You**

You got drunk disk your tap dance passed out


**158.** `10:58` **You**

And we avoided further discussion


**159.** `10:58` **You**

lol


**160.** `10:59` **Meredith Lamb (+14169386001)**

lol I tapped danced? Wow


**161.** `10:59` **You**

You can scroll back and see if you are curious


**162.** `10:59` **Meredith Lamb (+14169386001)**

Oh I did scroll back yday


**163.** `10:59` **You**

Selective responses etc


**164.** `10:59` **You**

How far back did you go


**165.** `10:59` **Meredith Lamb (+14169386001)**

To the beginning of the night


**166.** `11:00` **You**

Of yesterday or the night before


**167.** `11:00` **Meredith Lamb (+14169386001)**

Night before


**168.** `11:00` **You**

Ah ok then you got to reread all the fun


**169.** `11:00` **You**

lol


**170.** `11:00` **Meredith Lamb (+14169386001)**

Yep and I wasn’t avoiding per se\. I seriously was really stoned\.


**171.** `11:01` **You**

Kk well don’t worry again I am not needing you to open up about anything right now so we can all relax
And take a breath


**172.** `11:02` **You**

The timeline has changed and expected accessibility has changed so speed has changed


**173.** `11:02` **You**

So I need to change


**174.** `11:02` **You**

Not in a bad way mer


**175.** `11:02` **You**

❤️❤️❤️❤️


**176.** `11:02` **Meredith Lamb (+14169386001)**

lol


**177.** `11:02` **You**

It isn’t just your neck I want\.\.


**178.** `11:03` **You**

Fyi


**179.** `11:03` **Meredith Lamb (+14169386001)**

Is there something that is like super annoying you that I am not sharing out loud? Or just that weekend because I wouldn’t let you


**180.** `11:04` **Meredith Lamb (+14169386001)**

>
Same…\. ❤️

*💬 Reply*

**181.** `11:04` **You**

That isn’t super annoying me\. It was frustrating me because 1\. Fair play lol\.  2\. It has been my experience that that is enjoyable for others and I wanted to please you


**182.** `11:04` **Meredith Lamb (+14169386001)**

So here’s my insecurity


**183.** `11:04` **You**

That is all and then the refusal
Obviously begs questions but wait


**184.** `11:05` **You**

You don’t have
To


**185.** `11:05` **You**

I told you you don’t need to do this I can wait fine


**186.** `11:06` **You**

These are pretty tough topics we don’t need to wade
In now\.\.


**187.** `11:07` **Meredith Lamb (+14169386001)**

But it is so cliché I hate even talking about it\. I have never dated anyone 1\. Post kids and 2\. At this weight\. Like never been in this realm before even weight wise\. So it is all kind of unsettling and new to me\. Andrew was used to it but when we got together even I was very fit\. Anyway it is an odd one for me and definitely an insecurity\. Especially after 3 c sections\. Even when I get fit and work out etc etc etc I have a c section shelf\. I try not to focus on all that crap but it definitely bothers me when like lights are shone on it\.


**188.** `11:08` **Meredith Lamb (+14169386001)**

I never complain about it bc it is even annoying hearing it come out of my mouth\. Never complained to Andrew about it until recently\.


**189.** `11:08` **Meredith Lamb (+14169386001)**

The whole $200k thing


**190.** `11:08` **Meredith Lamb (+14169386001)**

I was like “are you fucking kidding me?\!” I have a c section shelf for life and you care about $200k


**191.** `11:08` **Meredith Lamb (+14169386001)**

He didn’t even know what the fuck it was


**192.** `11:08` **Meredith Lamb (+14169386001)**

Had to google it


**193.** `11:08` **You**

We are
Generally talking about intimacy here\. I think


**194.** `11:08` **Meredith Lamb (+14169386001)**

My last c section was 12 yrs ago\.


**195.** `11:08` **You**

Not specifics


**196.** `11:09` **Meredith Lamb (+14169386001)**

>
This was more related to last weekend and my “control”

*💬 Reply*

**197.** `11:09` **You**

Ok I mean if it bothers you that much I paid 15 k for Jaimie to have a surgery that she wanted that I gave zero fucks about


**198.** `11:09` **You**

But she did it for herself


**199.** `11:10` **You**

Like I think you are beautiful


**200.** `11:10` **You**

Every inch


**201.** `11:10` **You**

Nothing to be self conscious about


**202.** `11:10` **You**

At all


**203.** `11:10` **Meredith Lamb (+14169386001)**

I wanted to have that surgery also\. Andrew got mad at me when I suggested it\. 🙄


**204.** `11:10` **You**

It is your body mer


**205.** `11:10` **Meredith Lamb (+14169386001)**

That’s not the way he worked…\. Entirely\.  🙄


**206.** `11:11` **You**

If you are ever curious and want to know I will tell you\.


**207.** `11:11` **You**

But it IS your body not his not
Mine\.


**208.** `11:12` **You**

I just want to make you happy in every way that I can\.\.  but if it makes you uncomfortable
Then I don’t want to do it\.


**209.** `11:12` **You**

Because
It will achieve the opposite and I would hate to find out you did something you didn’t want to to make me happy


**210.** `11:12` **You**

Like it would really bother me


**211.** `11:13` **You**

But j 100% had that surgery actually it was more like 5000 she also had a breast reduction which she very
Much regrets now\.


**212.** `11:13` **Meredith Lamb (+14169386001)**

I’m just in a major transition period\. So I’m not super concerned\. Trying to get back to me weight of like 1\-2 years ago and get back to working out \.\. all while going through this separation crap and kids\.


**213.** `11:13` **You**

I think it was 5 for stomach and 10’for all else


**214.** `11:14` **Meredith Lamb (+14169386001)**

>
Oh I was talking about breast reduction what surgery are you talking about?

*💬 Reply*

**215.** `11:14` **You**

Yeah I know\.\. part
Of why I want us to get together finally we can support each other and grow together as we do it


**216.** `11:14` **You**

Well you said something about shelf


**217.** `11:14` **You**

Which is what Jaimie had removed


**218.** `11:14` **You**

Maybe not same thing


**219.** `11:14` **Meredith Lamb (+14169386001)**

Did she have c sections


**220.** `11:15` **You**

She did not but she had a shelf
Or whatever she called it


**221.** `11:15` **You**

There is a word


**222.** `11:15` **You**

And it wouldn’t go away


**223.** `11:15` **Meredith Lamb (+14169386001)**

Ah


**224.** `11:15` **You**

No matter how much she lost


**225.** `11:15` **You**

You feel you need a breast reduction?


**226.** `11:15` **Meredith Lamb (+14169386001)**

Mine is c section related


**227.** `11:15` **Meredith Lamb (+14169386001)**

C section shelf can’t be fixed to my knowledge\. It goes so deep\. The incision


**228.** `11:16` **You**

I mean I have nothing but positive things to say in that department mind you but wiuld support whatever you want lol


**229.** `11:16` **Meredith Lamb (+14169386001)**

Like it is actually numb all around the incision and you can feel how deep it goes\. I cant see them removing that


**230.** `11:16` **Meredith Lamb (+14169386001)**

>
I mean of course but he freaked out in my ass\.

*💬 Reply*

**231.** `11:16` **Meredith Lamb (+14169386001)**

\*on


**232.** `11:17` **Meredith Lamb (+14169386001)**

We have a major argument


**233.** `11:17` **Meredith Lamb (+14169386001)**

\*had omg autocorrect


**234.** `11:17` **Meredith Lamb (+14169386001)**

Major argument \(no yelling tho lol\)


**235.** `11:17` **You**

So I will suggest


**236.** `11:17` **Meredith Lamb (+14169386001)**

So I just didn’t do it


**237.** `11:17` **You**

The following


**238.** `11:17` **You**

You go see a plastic surgeon


**239.** `11:18` **You**

Because j did not


**240.** `11:18` **Meredith Lamb (+14169386001)**

When I lose weight it becomes less of an issue for me


**241.** `11:18` **You**

And she has no feeling there anymore


**242.** `11:18` **You**

And it never came back


**243.** `11:18` **Meredith Lamb (+14169386001)**

Yes I read about complications like that


**244.** `11:18` **You**

And she is fucking miserable about that


**245.** `11:18` **Meredith Lamb (+14169386001)**

My lower abdomen is like that from c section\. Definitely weird feeling


**246.** `11:19` **You**

Gemini says for the shelf thing it is very similar to j and there are 2\-3 surgical options coupled with non surgical


**247.** `11:19` **You**

Some of which would be covered by benefits


**248.** `11:19` **You**

Do you want me to paste it


**249.** `11:19` **Meredith Lamb (+14169386001)**

And I can just lose weight and work out\. It isn’t as much of an issue if I’m doing that


**250.** `11:19` **Meredith Lamb (+14169386001)**

No I’m going to start working out again


**251.** `11:19` **You**

For sure same things for upper body


**252.** `11:19` **You**

Push\-ups


**253.** `11:20` **Meredith Lamb (+14169386001)**

That’s actually my favourite exercise


**254.** `11:20` **You**

It has an effect so I am told


**255.** `11:20` **You**

Yeah I like push\-ups


**256.** `11:21` **You**

Not sure what I am at in a one time trial but it would be about 50 okus I think\.\. I have done\. Fair bit of work on upper body


**257.** `11:21` **Meredith Lamb (+14169386001)**

I used to do 100 every workout


**258.** `11:21` **Meredith Lamb (+14169386001)**

Built up to that tho


**259.** `11:21` **Meredith Lamb (+14169386001)**

Over time


**260.** `11:22` **You**

Well I want you to know in the future if
You ever wanted to consider anything g I would be 100% supportive but know I love as
Much as I do just as you are right this second


**261.** `11:22` **You**

That is a lot of push\-ups\.\. lol


**262.** `11:22` **Meredith Lamb (+14169386001)**

Everyone used to make fun of me


**263.** `11:22` **Meredith Lamb (+14169386001)**

It is really only 4 sets of 25


**264.** `11:22` **You**

Why\.\. it is awesome


**265.** `11:23` **You**

If
You are doing 4 sets of straight 25
Push\-ups that is boss\.


**266.** `11:23` **You**

I will resist the urge to lift tonight and just go back in to walk and shit\.


**267.** `11:23` **You**

When is Andrew getting back\.\. tonight sometime I guess


**268.** `11:24` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
One of my goals to get back\. If I can get back to regular workouts I don’t need any surgeries

*📎 1 attachment(s)*

**269.** `11:24` **Meredith Lamb (+14169386001)**

He gets back tomorrow morning


**270.** `11:25` **You**

Yeah I think we will get along fine\.\. I think you just need the space and the comfort to be intense I don’t think we are that far
Off
From each other I think you will be surprised


**271.** `11:25` **You**

I think when you love
Someone that deep a lot of things change


**272.** `11:26` **You**

I am about 4% from abs again I think end of this week you def had abs srsly


**273.** `11:26` **Meredith Lamb (+14169386001)**

>
I’m internally intense\. You are externally\.

*💬 Reply*

**274.** `11:26` **You**

I am both internally with myself


**275.** `11:27` **You**

And then I let it out in the form of emotions


**276.** `11:27` **You**

Which again and I apologize has not happened like this before


**277.** `11:28` **Meredith Lamb (+14169386001)**

You do not have to apologize to me\. I’m also experiencing something on a level that I have not before and I guess I just process it differently…


**278.** `11:28` **Meredith Lamb (+14169386001)**

But I am processing it\.


**279.** `11:31` **Meredith Lamb (+14169386001)**

And I’m dealing with so many other factors punching me in the head\. Example… Andrew making such a big deal about his fucking $200k\. This shit bugs me and I have to process it too at the same time as all of us/this\. It is just a lot


**280.** `11:33` **You**

Yeah I know


**281.** `11:34` **You**

I am trying not to think about it


**282.** `11:35` **Meredith Lamb (+14169386001)**

Plus my mom might be legit like dying or something\.  There’s that too…\.  And Andrew keeps saying shit about my family in this whole separation\. He is basically like nails on a chalkboard\.


**283.** `11:36` **Meredith Lamb (+14169386001)**

She’s having a colonoscopy and endoscopy this Wednesday


**284.** `11:36` **Meredith Lamb (+14169386001)**

More tests


**285.** `11:36` **Meredith Lamb (+14169386001)**

😵‍💫


**286.** `11:36` **You**

I really want to meet her


**287.** `11:36` **You**

Would she be willing


**288.** `11:37` **You**

For real


**289.** `11:37` **You**

Coffee tea or anything


**290.** `11:37` **You**

I would take her out


**291.** `11:37` **You**

Just me though


**292.** `11:37` **You**

Not you


**293.** `11:37` **Meredith Lamb (+14169386001)**

She’s pretty sick


**294.** `11:37` **Meredith Lamb (+14169386001)**

Not me


**295.** `11:37` **Meredith Lamb (+14169386001)**

What


**296.** `11:37` **You**

I want her to get to know me


**297.** `11:38` **You**

I want to get to know her


**298.** `11:38` **You**

It is important to me


**299.** `11:38` **You**

I thought there was more time


**300.** `11:38` **Meredith Lamb (+14169386001)**

You will be getting a different version of her\. But she is still kind of there


**301.** `11:38` **Meredith Lamb (+14169386001)**

There likely is but who knows


**302.** `11:38` **Meredith Lamb (+14169386001)**

They don’t know what is wrong with her and she legit hasn’t been able to eat in almost a year


**303.** `11:39` **Meredith Lamb (+14169386001)**

She’s lost like 35–40 lbs


**304.** `11:39` **You**

I am gentle\.  And I get it


**305.** `11:39` **You**

Only if she wants to


**306.** `11:40` **You**

It the offer is there


**307.** `11:40` **Meredith Lamb (+14169386001)**

She will tell you that you are stupid and reckless lol


**308.** `11:40` **You**

If were her I would want to meet me


**309.** `11:40` **You**

She might and i will tell her my story


**310.** `11:41` **Meredith Lamb (+14169386001)**

It would able an interesting conversation for sure lol


**311.** `11:41` **You**

I mean it is your call if you are comfortable feel free to share the offer with her \.\. I would be interested in her response


**312.** `11:41` **Meredith Lamb (+14169386001)**

Gotta do her bday next weekend and get that over with


**313.** `11:42` **Meredith Lamb (+14169386001)**

Maelle tomorrow, mom next weekend, then Mac June 1


**314.** `11:42` **Meredith Lamb (+14169386001)**

Then I’m free


**315.** `11:42` **Meredith Lamb (+14169386001)**

From birthday duties for a while


**316.** `11:43` **Meredith Lamb (+14169386001)**

Until a couple of virgos I know


**317.** `11:43` **You**

Like i said I will leave it with you I always wanted to meet her but when you said that I felt a sense of urgency


**318.** `11:43` **You**

I don’t do birthdays


**319.** `11:43` **Meredith Lamb (+14169386001)**

You and my dad are both virgos


**320.** `11:44` **You**

I do them for other people


**321.** `11:44` **Meredith Lamb (+14169386001)**

Oh you are doing your birthday this year


**322.** `11:44` **You**

I will let other people do shit because it made them happy how it always was


**323.** `11:44` **Meredith Lamb (+14169386001)**

I mean same


**324.** `11:44` **Meredith Lamb (+14169386001)**

But you and I will do it properly


**325.** `11:44` **Meredith Lamb (+14169386001)**

Not about that


**326.** `11:45` **Meredith Lamb (+14169386001)**

Just a day to properly thank the universe for all things Scott


**327.** `11:46` **You**

lol that is a long way off mer\.\. not focusing that far out yet\.


**328.** `11:46` **You**

So next week is her bday right\.


**329.** `11:46` **Meredith Lamb (+14169386001)**

No may 14


**330.** `11:46` **Meredith Lamb (+14169386001)**

We are doing it next week tho


**331.** `11:46` **Meredith Lamb (+14169386001)**

Andrew was mad


**332.** `11:47` **Meredith Lamb (+14169386001)**

He’s like “I guess I will go to my moms ALONE on Mother’s Day”


**333.** `11:47` **Meredith Lamb (+14169386001)**

I looked at him and was like “you know I’m a fucking mother too right?”


**334.** `11:47` **Meredith Lamb (+14169386001)**

Jesus Christ


**335.** `11:47` **Meredith Lamb (+14169386001)**

I can’t even with him anymore


**336.** `11:47` **You**

Eesh


**337.** `11:48` **Meredith Lamb (+14169386001)**

Little concerned about sharing the cottage\. Another stressor / thing to process now


**338.** `11:48` **Meredith Lamb (+14169386001)**

But I think I’m going to do it anyway


**339.** `11:48` **You**

Yeah I know\.\. you will for
Your kids thigh


**340.** `11:48` **You**

Though I already knew that


**341.** `11:48` **Meredith Lamb (+14169386001)**

It is just going to require conversations either him


**342.** `11:48` **Meredith Lamb (+14169386001)**

Ughhhhh


**343.** `11:48` **Meredith Lamb (+14169386001)**

\*with him


**344.** `11:49` **You**

I think part of me is concerned that until we actually can get to a point where everyone knows and then everyone is comfortable and then Andrew doesn’t freak if I am around kids\.\. we are a long ways off from spending time together\.\. like a long long something I thought about last night


**345.** `11:49` **You**

You guys will have busy weekends all summer right\.\. like it is what it is… just thinking through


**346.** `11:50` **Meredith Lamb (+14169386001)**

My therapist would say Andrew has no right to any of my decisions\.


**347.** `11:50` **You**

He does re his children


**348.** `11:50` **Meredith Lamb (+14169386001)**

>
No\. We hardly went up together last year\. Mostly separately\. When I was babysitting those 5 dogs he was in the uk, for example\. I go up a lot by myself\.

*💬 Reply*

**349.** `11:51` **You**

Ah k\.\. well I will be challenged anyways unless I y maddie home for a week
Or two in summer


**350.** `11:51` **Meredith Lamb (+14169386001)**

>
What? No\. If I want to have ppl around my children, they are old enough\. My choice at this point imo

*💬 Reply*

**351.** `11:51` **You**

Which would be only likely if I can get Jaimie to buy


**352.** `11:51` **You**

Which I am trying again today


**353.** `11:52` **You**

>
I just want to be careful
Don’t want them to hate me or give Andrew cause\.\.
And we can only do that after job shift
I think

*💬 Reply*

**354.** `11:52` **You**

Which at this point knowing how you feel about the job still
Might make
The most sense for you


**355.** `11:52` **You**

And anyone would take you as a 620


**356.** `11:52` **You**

510


**357.** `11:52` **You**

Anyone lol


**358.** `11:53` **Meredith Lamb (+14169386001)**

Yeah I will be careful also… for my kids sake\.


**359.** `11:53` **Meredith Lamb (+14169386001)**

And your sake\.


**360.** `11:53` **You**

You could suggest work life balance
Given everything else


**361.** `11:53` **You**

Yeah I really want them to like me


**362.** `11:53` **Meredith Lamb (+14169386001)**

I think I will have options\.


**363.** `11:53` **Meredith Lamb (+14169386001)**

I just need to get in a rental first\.


**364.** `11:54` **Meredith Lamb (+14169386001)**

Honestly if I have to move and move jobs at the same time, my getting wasted weekends will increase\.


**365.** `11:54` **Meredith Lamb (+14169386001)**

Too much\.


**366.** `11:54` **Meredith Lamb (+14169386001)**

Need to focus on getting out first\.


**367.** `11:54` **Meredith Lamb (+14169386001)**

We haven’t separated our bank accounts yet either


**368.** `11:54` **You**

No I get it but as I said to j sometimes timing doesn’t work


**369.** `11:55` **Meredith Lamb (+14169386001)**

True


**370.** `11:55` **Meredith Lamb (+14169386001)**

But there are no work opps right now


**371.** `11:56` **You**

Yeah I know but I will know what is coming too


**372.** `11:56` **You**

I get it mer it is a lot same here


**373.** `11:57` **Meredith Lamb (+14169386001)**

>
k, well I am all for moving if there is something\. It isn’t that I don’t like the role, it is just so difficult right now with separating and you/i\. I can’t focus at all

*💬 Reply*

**374.** `11:59` **You**

I will help you


**375.** `11:59` **You**

Not rescue you


**376.** `11:59` **You**

Help you\.\. just like you do me\.


**377.** `12:00` **You**

Reaction: ❤️ from Meredith Lamb
I totally see you as a partner and an equal and awesome in every
Way\.\. I am so excited\.\. part
If the problem if I could
Just focus on excitement and nothing else I would be I\. A high for months and months\.


**378.** `12:02` **You**

Going to need a
Min
Being summoned but the above is all
True


**379.** `12:04` **Meredith Lamb (+14169386001)**

I think your love language is service\. Lol it’s ok\. I appreciate the non\-rescuing though\. :\) I would like us to not have that dynamic too much in one direction … if it is balanced I’m ok with it\. k, I should shower and take this kid to Yorkdale :p Yaye gah


**380.** `12:16` **You**

Yeah go get it done enjoy the shower\.\. my love language is love\.\. period\.\. me wanting to help or make
You happy or do anything is just part
Of that it doesn’t define it


**381.** `12:26` **You**

Holy fuck you need to watch snl opening from last night and the weekend report\.


**382.** `12:26` **You**

Literally 90’s Level offensive I loved
It\.


**383.** `12:33` **You**

Srsly though I would ask one thing if it is not too much I would love to see if there is any way to try the morning thing\.\. I do think it would make a difference for
Both of us\.


**384.** `12:33` **You**

Anyhow you get going I have to get to work here\.


**385.** `12:34` **Meredith Lamb (+14169386001)**

>
Will watch tonight

*💬 Reply*

**386.** `12:35` **Meredith Lamb (+14169386001)**

>
Ok 🙂

*💬 Reply*

**387.** `12:35` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Sold


**388.** `12:35` **Meredith Lamb (+14169386001)**

That was difficult eh ;\)


**389.** `12:37` **You**

Ok I will have several options for
You to consider later
lol\.\. my wake up time is going to be interesting tomorrow\.


**390.** `12:39` **You**

She just agreed to speak with my realtor/best friend back home\.\. like immediately… so that is a good sign\.


**391.** `12:47` **Meredith Lamb (+14169386001)**

That’s good\.


**392.** `13:03` **Meredith Lamb (+14169386001)**

One thing you don’t know about me\. I used to be super obsessed with rowing until Covid happened\. My laser skull was my baby\. Then Covid happened and everything all went to shit and my skull has sat untouched for probably 3 years

*📎 1 attachment(s)*

**393.** `13:12` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**394.** `13:13` **Meredith Lamb (+14169386001)**

Even in the freezing cold I would row and row and row\. Escape my kids and family constantly lol

*📎 1 attachment(s)*

**395.** `13:14` **Meredith Lamb (+14169386001)**

The only nice thing Andrew ever bought me\. Altho he would argue the skull is half his I bet


**396.** `13:28` **Meredith Lamb (+14169386001)**

Sort of a private obsession\.
People: “what did you do off work?”
Me: “take care of my kids 🙈”


**397.** `13:28` **Meredith Lamb (+14169386001)**

I did but I did a lot rowing too


**398.** `13:28` **Meredith Lamb (+14169386001)**

lol


**399.** `13:36` **You**

Would you teach me


**400.** `13:36` **You**

I have never and would love to go with you


**401.** `13:36` **You**

And please keep sending me as many pics as you want especially of you\.


**402.** `13:37` **You**

The call was amazing with Mike I will send you the house she is looking at\.\. it is new and beautiful\.\. but it means a quicker closing and means I have to sort out a ton of financial shit
Asap


**403.** `13:37` **You**

And cancel my viewing tomorrow


**404.** `13:37` **You**

Because I will be in this house
For a while\.


**405.** `13:42` **You**

Check out this listing
https://realtor\.ca/real\-estate/27592698/71\-petersfield\-street\-lower\-coverdale?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**406.** `13:43` **You**

Would want to get her a generator since it is a ways from town she would be in sceptic and well\.\. all manageable needs
Finished basement but I know a guy\.


**407.** `13:47` **Meredith Lamb (+14169386001)**

>
Yeah but some ppl hate it\. Requires a lot of balance\.

*💬 Reply*

**408.** `13:47` **You**

I have that


**409.** `13:47` **You**

Not worried even a little


**410.** `13:47` **Meredith Lamb (+14169386001)**

lol a lot of ppl lose it on a skull


**411.** `13:48` **Meredith Lamb (+14169386001)**

I have confidence in you though


**412.** `13:49` **You**

So ego \- there aren’t a lot of things that I have tried that require some degree of strength balance coordination reaction time\.\. that I haven’t been able to get good at\.


**413.** `13:49` **You**

Also I am insane when it comes to challenges


**414.** `13:49` **You**

And even more insane when it comes to you\.


**415.** `13:49` **You**

You think I was motivated to learn guitar\.\. I will crush skulling


**416.** `13:49` **You**

😝


**417.** `13:50` **Meredith Lamb (+14169386001)**

Have you kayaked?


**418.** `13:51` **You**

Yep


**419.** `13:51` **You**

It a ton but it wasn’t hard


**420.** `13:51` **Meredith Lamb (+14169386001)**

Good start \- a lot easier to balance


**421.** `13:51` **You**

Not


**422.** `13:52` **You**

And again I will learn fast


**423.** `13:52` **You**

I don’t have insecurities there


**424.** `13:52` **Meredith Lamb (+14169386001)**

Kayaking is great … it is the easiest for sure\.


**425.** `13:52` **Meredith Lamb (+14169386001)**

We have 2 kayaks but one is more of a kid one


**426.** `13:53` **You**

I will buy one when the time is right and add the rowing machine to my workout


**427.** `13:53` **You**

My back is pretty solid but can always get better and it is good for upper body and back anyways


**428.** `13:54` **Meredith Lamb (+14169386001)**

Just do push ups


**429.** `13:54` **Meredith Lamb (+14169386001)**

Rowing is easy if you do push ups I find


**430.** `13:54` **You**

Ok…\.


**431.** `13:54` **Meredith Lamb (+14169386001)**

Otherwise I struggle\. Like now I would struggle so badly


**432.** `13:56` **Meredith Lamb (+14169386001)**

Cottages are for fit ppl\. I struggle there now


**433.** `13:56` **You**

Reaction: 😮 from Meredith Lamb

*📎 1 attachment(s)*

**434.** `13:56` **You**

I am not worried


**435.** `13:58` **You**

We can struggle and get good together


**436.** `14:00` **You**

Also after
Chest
Day yesterday… maybe would be better with a few days off

*💬 Reply*

**437.** `14:03` **Meredith Lamb (+14169386001)**

I’m at Yorkdale and opened that lol


**438.** `14:13` **You**

I told my sister


**439.** `14:14` **You**

Well it only matters if you watched it and were like dammmmmmmm


**440.** `14:14` **Meredith Lamb (+14169386001)**

>
I was and it makes me want to start again

*💬 Reply*

**441.** `14:14` **Meredith Lamb (+14169386001)**

>
And…\.

*💬 Reply*

**442.** `14:14` **You**

She was super happy


**443.** `14:14` **You**

Honestly


**444.** `14:14` **You**

She asked your name and wanted to know all kinds of shit


**445.** `14:14` **You**

But her daughter was coming to the car


**446.** `14:15` **You**

So we will connect again


**447.** `14:15` **You**

Maybe if we can talk later I can fill you in more similar
To last night if
Little shadow isn’t
Lurking lol


**448.** `14:16` **Meredith Lamb (+14169386001)**

lol kk


**449.** `14:18` **You**

I told you Katie will absolutely adore you and she was shocked at how I felt she remembers how
I was\.


**450.** `14:18` **You**

She said you get one kick at the can\.\. go for it as hard as have to\.


**451.** `14:18` **You**

We are alike in some ways


**452.** `14:20` **Meredith Lamb (+14169386001)**

Well I look forward to meeting her


**453.** `14:21` **Meredith Lamb (+14169386001)**

I feel like I would give her a fist just to see her super thankful reaction lol kidding


**454.** `14:23` **You**

Reaction: ❤️ from Meredith Lamb
She honestly said she hadn’t seen me like this I walked her through the whole thing she just sat there kind of
Mesmerized


**455.** `14:24` **You**

Reaction: ❤️ from Meredith Lamb
It was nice to have that kind of support


**456.** `14:24` **You**

She is mentally tough like you though she would tell me to put on my big boy pants\.


**457.** `14:24` **You**

Younger sisters pshh


**458.** `14:25` **You**

I have helped her through her shit too though\. So she owes me\.


**459.** `14:26` **Meredith Lamb (+14169386001)**

>
Older brothers pshhh\. They are worse\.

*💬 Reply*

**460.** `14:29` **You**

Nope we are awesome and we scare off other bad boys


**461.** `14:29` **Meredith Lamb (+14169386001)**

So your sister didn’t feel bad for j?


**462.** `14:29` **You**

Walking around the corner to an open house listed at 1\.4 million not nearly as nice as ares no finished basement but a bit bigger


**463.** `14:29` **You**

>
No

*💬 Reply*

**464.** `14:29` **You**

Will get into that later


**465.** `14:29` **You**

Love you\.


**466.** `14:29` **Meredith Lamb (+14169386001)**

K


**467.** `14:29` **Meredith Lamb (+14169386001)**

Love you too


**468.** `14:34` **Meredith Lamb (+14169386001)**

lol having a hard time not smirking\.

*📎 1 attachment(s)*

**469.** `14:38` **You**

Smirk away


**470.** `14:38` **You**

lol


**471.** `14:38` **You**

Just got myself a real estate
Agent


**472.** `14:40` **Meredith Lamb (+14169386001)**

Nice


**473.** `14:52` **You**

Positive directional
Movement makes me happy identified
Mortgage
Specialists from Moncton reaching out to seek out competitive mortgage
Rates\.\. etc
Etc\. guy coming back from
Trinidad next week will fix my house\.\. if j goes most of the house goes so I can stage
It\.


**474.** `14:52` **You**

This is where brain is happy\.\.  he needs to fix shit


**475.** `15:05` **Meredith Lamb (+14169386001)**

Wow that is a lot of movement


**476.** `15:16` **You**

Yep mowing lawn getting shit done already have a meeting set up with realtor\.\. cancelling viewing tomorrow\.


**477.** `15:37` **You**

Reaction: 🙂 from Meredith Lamb
Next… man this feels so much better than last few nights just need to keep seeing wins\.


**478.** `15:45` **You**

I can almost here the be careful it could all
Turn around and kick you in the ass tomorrow…
lol


**479.** `15:49` **Meredith Lamb (+14169386001)**

I mean it could tonight\. Lol


**480.** `15:49` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Seems to be my experience\. No day is safe


**481.** `15:54` **You**

Maybe I don’t call at the gym and ride my high and no more naughty photos for you\! 😝


**482.** `16:09` **Meredith Lamb (+14169386001)**

No call no photos\. How is that a high lol


**483.** `16:11` **You**

Well if you think I am just going to come down\.\. maybe you don’t want to talk to me


**484.** `16:15` **Meredith Lamb (+14169386001)**

Oh\!


**485.** `16:15` **Meredith Lamb (+14169386001)**

I didn’t get that cause and effect reference lol


**486.** `16:16` **Meredith Lamb (+14169386001)**

Still out with girls


**487.** `16:25` **You**

Ah ok well many my logic is a bit off with my being a bit happy\.  Still feels right somehow\.  I mean odds are
You won’t be able to talk to me tonight anyways\.  All the little
One’s will be home\.


**488.** `16:25` **You**

Hope shopping is going well spend lots and lots of money


**489.** `16:36` **Meredith Lamb (+14169386001)**

Finally home\.


**490.** `16:36` **Meredith Lamb (+14169386001)**

Spent lots\. Lol


**491.** `16:38` **You**

Good for you I don’t even want to know\.\. if you can spend 550 on random stuff at a volleyball tournament I shudder to think\.


**492.** `16:38` **You**

Yorkdale err mah gerd\!\!\!\!\!\!\!\!\!\!\!


**493.** `16:42` **Meredith Lamb (+14169386001)**

lol I will refrain


**494.** `16:42` **Meredith Lamb (+14169386001)**

From sharing


**495.** `16:43` **You**

I won't be able to afford to keep up with you\.


**496.** `16:43` **You**

true story


**497.** `16:43` **You**

I need to be a VP\.


**498.** `16:44` **Meredith Lamb (+14169386001)**

It’s what child support is for lol


**499.** `16:44` **You**

but after


**500.** `16:46` **Meredith Lamb (+14169386001)**

Well my kids will have to chill\. It will be a gradual thing


**501.** `16:46` **Meredith Lamb (+14169386001)**

lol


**502.** `16:47` **You**

maybe\.\. we'll see


**503.** `16:48` **You**

either way I feel like I need to consider advancement where I don't think I would have previously\.\. more for me than anything\.


**504.** `16:50` **Meredith Lamb (+14169386001)**

Omg stooooooop


**505.** `16:51` **Meredith Lamb (+14169386001)**

You do not need to fund me\. Seriously\.


**506.** `16:51` **Meredith Lamb (+14169386001)**

Like not at all


**507.** `16:51` **You**

I wasn't suggesting that\.


**508.** `16:51` **You**

but pls don't look at it that way


**509.** `16:52` **You**

I don't want to have to ask permission if I want to give you something


**510.** `16:52` **You**

and vice versa


**511.** `16:52` **You**

unless it is excessive\.\. ok then we can have some boundaries


**512.** `16:53` **Meredith Lamb (+14169386001)**

All of my spending is excessive right now\. That will change extremely soon\.


**513.** `16:54` **Meredith Lamb (+14169386001)**

I don’t even care honestly\.


**514.** `16:54` **You**

I absolutely believe you\.


**515.** `16:54` **You**

and I promise our being happy will have nothing to do with money\.


**516.** `16:54` **You**

I never expected it would\.\. even a bit\.


**517.** `16:56` **Meredith Lamb (+14169386001)**

I tried spending more and it doesn’t make ppl happier\. Teens maybe\.


**518.** `16:56` **You**

It definitely does not \- Jaimie spent a shit ton\!\! lol didn't make her happy\.


**519.** `16:57` **You**

I mean we know the only thing that really helps\.\.\.\.\.


**520.** `16:57` **You**

gummies, thc drinks, and wine


**521.** `16:57` **You**

LOTS and LOTS


**522.** `16:57` **You**

:\)


**523.** `16:57` **Meredith Lamb (+14169386001)**

I mean that doesn’t make one happy but it certainly numbs the pain\. 😫


**524.** `16:58` **You**

Yeah numb is yucky\.\. but so is pain\.


**525.** `18:29` **You**

Built j a financial model found another house cause first one I shared was built on a slab and had a conditional offer


**526.** `18:42` **You**

Sending something else your way later
For your consideration heading to gym soon, inquiring if you thought you might be able
To chat again you could tell me all about your shopping etc if not no worries I will just focus in more on working out


**527.** `18:45` **Meredith Lamb (+14169386001)**

I fell asleep in couch lol Well I have to go see the rental at 7\.25pm


**528.** `18:45` **Meredith Lamb (+14169386001)**

That should be quick


**529.** `18:49` **You**

Kk well let me know if you want to call later
I will leave
That with you\.


**530.** `18:49` **You**

Have fun at rental


**531.** `18:51` **Meredith Lamb (+14169386001)**

For sure \- when I’m back maybe depending on when you go


**532.** `18:52` **Meredith Lamb (+14169386001)**

I need to wrap some gifts tonight so will be by myself for that lol


**533.** `18:54` **You**

I am going now and will be there until 10


**534.** `18:56` **You**

no pics though since you mocked my ability to remain happy\.\. that seems fair\.  No faith\.


**535.** `19:02` **Meredith Lamb (+14169386001)**

I wasn’t mocking\. Merely mentioning the reality of late\.


**536.** `19:16` **You**

Mmm hmmm well…\.\.


**537.** `19:20` **You**

I dunno


**538.** `19:29` **Meredith Lamb (+14169386001)**

You can’t argue with that\.


**539.** `19:29` **You**

Well maybe you need a night off then\.\. 😝


**540.** `19:29` **You**

Below is a structured, step\-by\-step “isochrone” \(drive\-time\) model for identifying increasingly distant meeting spots from 500 Consumers Drive, Toronto, with a focus on quiet, private, and naturally romantic settings\. We’ll sketch out the methodology first, then populate three concentric “rings” \(5\-, 10\-, and 15\-minute drive times\) while biasing away from westward options\.
⸻
1\. Methodology: Building Your Drive\-Time Isochrones
1\.	Pick your drive\-time thresholds\.
- Ring 1: ~5 minutes
- Ring 2: ~10 minutes
- Ring 3: ~15 minutes
2\.	Use an isochrone tool \(e\.g\., Google Maps Platform, Mapbox Isochrone API\) centered at 500 Consumers Dr to generate these polygons\.
- Filter out western arcs if you want to minimize west\-ward travel\.
- Export the geojson for each ring\.
3\.	Overlay parks/natural areas\.
- Import the isochrone polygons into a GIS or even Google My Maps\.
- Layer on Toronto parks, ravines, gardens data\.
4\.	Score candidate spots by:
- Privacy: smaller parks or off\-path trails
- Romance factor: gardens, water features, sunrise views
- Morning access: open area by ~6 AM
5\.	Select top 3–5 per ring and test drive\-time in real traffic \(especially on weekday mornings\)\.
⸻
2\. Candidate Locations by Ring
Ring	Drive\-Time ≤ …	Direction Bias	Examples \(quiet · romantic\)
1	5 minutes	North / East	\- Crothers Woods \(small ravine trails\)
\- Taylor Creek Park East \(tree\-lined path\)
\- Sunnybrook Park \(western edge\) \(hidden meadows\)
2	10 minutes	North / East	\- Edwards Gardens \(formal gardens & benches\)
\- Toronto Botanical Garden \(private alcoves\)
South	\- Ashbridges Bay Park \(harbor sunrise views\)\*
3	15 minutes	North / South	\- Ravine in David Balfour Park \(wooded shelter\)
East	\- Tommy Thompson Park \(tip peninsula, water vistas\)
Northeast	\- Bluffs lookout near Glen Rouge \(expansive horizon\)
\*Ashbridges Bay can be breezy and semi\-public; go weekday and early\.
⸻
3\. Cascading Impacts & Trade\-Offs
1\.	Closer rings \(5 min\)
- Pros: ultra\-short commute, minimal morning delay\.
- Cons: fewer truly private pockets; small ravines can get dog\-walkers\.
2\.	Mid\-range \(10 min\)
- Pros: formal gardens with benches, more “designed” privacy\.
- Cons: may require parking; sometimes ticketing starts early\.
3\.	Outer ring \(15 min\)
- Pros: dramatic viewpoints \(harbor, bluffs\), lots of greenery\.
- Cons: pushes into heavier traffic corridors; risk arriving late\.
⸻
4\. Next Steps & Checkpoint
1\.	Run the actual isochrone in your favorite mapping API, export the rings\.
2\.	Visit 1–2 top picks from each ring on a weekend morning to confirm vibe\.
3\.	Decide on your sweet spot \(e\.g\. 10\-minute ring at Edwards Gardens bench \#7\)\.
4\.	Establish a recurring “sunrise date” reminder \(I can help schedule that, if you’d like\)\.
⸻
Quick question to keep us aligned:
Do you want me to draft the Google Maps\-based workflow \(with sample API calls\), or would you prefer I skip straight to refining the shortlist of specific bench/patio coordinates?


**541.** `19:29` **You**

I don’t know these places but built N algorithm


**542.** `19:32` **Meredith Lamb (+14169386001)**

Just at the rental\. That seems like a long read lol


**543.** `19:32` **Meredith Lamb (+14169386001)**

Not tomorrow tho right? Musarrat starts tomorrow\.


**544.** `19:32` **Meredith Lamb (+14169386001)**

I need to print her off some stuff in morning


**545.** `19:34` **You**

Whenever you want up to you\.\. you ignored my smart ass comment not as fun when you ignore it\.


**546.** `19:34` **Meredith Lamb (+14169386001)**

What smart ass comment


**547.** `19:34` **You**

The one before the long ass read


**548.** `19:35` **Meredith Lamb (+14169386001)**

Oh


**549.** `19:35` **Meredith Lamb (+14169386001)**

I’m really sharp today


**550.** `19:35` **Meredith Lamb (+14169386001)**

I think I need a sober weekend


**551.** `19:37` **You**

Enjoy the rental\.\. all dressed heading upstairs to work\.


**552.** `19:38` **Meredith Lamb (+14169386001)**

My stupid 12 yr old is tracking me on find my


**553.** `19:38` **You**

Well I mean shouldn’t matter much should it


**554.** `19:55` **Meredith Lamb (+14169386001)**

I told her I was talking to Diana bc Diana is 3 doors down from the rental place


**555.** `19:55` **Meredith Lamb (+14169386001)**

She’s just so annoying about that shit


**556.** `19:56` **You**

Ah ok


**557.** `19:56` **You**

Well
Little shadow


**558.** `20:15` **You**

Hope
Your is going well


**559.** `20:15` **You**

Tour


**560.** `20:15` **Meredith Lamb (+14169386001)**

Meh


**561.** `20:16` **Meredith Lamb (+14169386001)**

Is fine\. Would be fine\. Just not amazing\. But would totally work


**562.** `20:16` **You**

Then don’t settle


**563.** `20:52` **Meredith Lamb (+14169386001)**

Looking at that place by myself was a bit heavier than I thought it would be\. Maybe it was having to hide it from girls…\.


**564.** `20:53` **You**

Guilt?


**565.** `20:53` **You**

Regret?


**566.** `20:55` **Meredith Lamb (+14169386001)**

I’m not even sure honestly\.


**567.** `20:55` **Meredith Lamb (+14169386001)**

Not regret


**568.** `20:55` **Meredith Lamb (+14169386001)**

I have no regrets\.


**569.** `20:55` **Meredith Lamb (+14169386001)**

A bit of fear


**570.** `20:55` **Meredith Lamb (+14169386001)**

A bit of grief


**571.** `20:56` **Meredith Lamb (+14169386001)**

\(Not the same as regret\)


**572.** `20:56` **You**

Yeah I think I understand… I do better with those emotions


**573.** `20:56` **Meredith Lamb (+14169386001)**

A bit of disbelief


**574.** `20:56` **Meredith Lamb (+14169386001)**

A bit of loneliness


**575.** `20:56` **Meredith Lamb (+14169386001)**

A bit of everything really


**576.** `20:58` **You**

I mean it does sound like regret\.\. a kind of at least


**577.** `20:59` **Meredith Lamb (+14169386001)**

No, no regret\.


**578.** `20:59` **You**

🙄


**579.** `20:59` **Meredith Lamb (+14169386001)**

Omg honestly


**580.** `20:59` **Meredith Lamb (+14169386001)**

I swear


**581.** `21:07` **You**

Pose pic?


**582.** `21:07` **You**



**583.** `21:07` **You**

Aww darn


**584.** `21:10` **Meredith Lamb (+14169386001)**

🙄


**585.** `21:11` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**586.** `21:11` **You**

This wasn’t it


**587.** `21:12` **You**

I so for gthink you like big dudes anywayy th a


**588.** `21:12` **You**

I should trim down


**589.** `21:12` **Meredith Lamb (+14169386001)**

>
?

*💬 Reply*

**590.** `21:12` **Meredith Lamb (+14169386001)**

lol


**591.** `21:13` **You**

It is this bag I am in shower I said I don’t think u like big dudes


**592.** `21:14` **Meredith Lamb (+14169386001)**

What are you talking about? How would you know?


**593.** `21:14` **You**

Just a guess


**594.** `21:14` **Meredith Lamb (+14169386001)**

Based on


**595.** `21:14` **You**

This one was earlier I keep these for time series


**596.** `21:15` **You**


*📎 1 attachment(s)*

**597.** `21:15` **You**

Feel should delete fast


**598.** `21:16` **Meredith Lamb (+14169386001)**

No you don’t have to delete\.


**599.** `21:17` **You**

Sok you can laugh


**600.** `21:17` **You**

I am


**601.** `21:17` **Meredith Lamb (+14169386001)**

I actually prefer bigger guys\. Andrew was always insecure about it lol


**602.** `21:17` **You**

Surprised


**603.** `21:17` **Meredith Lamb (+14169386001)**

Why?


**604.** `21:17` **You**

Dunno just didn’t figure


**605.** `21:18` **Meredith Lamb (+14169386001)**

Becaaaaaaause………


**606.** `21:22` **You**

>
Btw most guys are insecure about this fyi

*💬 Reply*

**607.** `21:22` **You**

Sry just shaving 5 years off 😆


**608.** `21:24` **Meredith Lamb (+14169386001)**

I wasn’t sure how to respond to either of those msgs lol


**609.** `21:27` **You**

Well the first one is obvious the second is just loving post shaves\. Feel younger


**610.** `21:28` **You**

But it doesn’t require a response


**611.** `21:28` **You**

It is an observation and one I think is common


**612.** `21:36` **Meredith Lamb (+14169386001)**

When you’re feeling even beyond overwhelmed, it can move into what psychologists sometimes call:
- Emotional flooding – when your nervous system is overloaded and you feel unable to process or respond clearly\. It can come with tears, numbness, irritability, or even a shutdown feeling\.
- Dysregulation – when your emotions are so heightened that your mind and body can’t stay balanced\. It’s like your inner system is short\-circuiting\.
- Overcapacity – not a clinical term, but a deeply real one\. It means your mental, emotional, and physical bandwidth has been maxed out, and even small things feel enormous\.
- Disintegration – the opposite of feeling integrated or whole\. It’s when your usual coping tools and sense of self feel like they’re coming apart, even if temporarily\.
- Collapse – when the system doesn’t fight or flee anymore—it just drops\. You may feel flat, hopeless, or disconnected\.
These states are often signs that your body and heart are begging for gentleness, not more pressure to “deal with it\.”


**613.** `21:37` **Meredith Lamb (+14169386001)**

Question lol: Tonight I’m feeling even beyond overwhelmed\. What is that called?


**614.** `21:38` **You**

I think it is more like you are realizing what is about to happen\.\. the difficult moments are here and you are feeling what I call dread


**615.** `21:38` **You**

And I am sorry mer I would hug you if I could


**616.** `21:39` **You**

To bad the morning couldn’t work


**617.** `21:41` **You**

For the record I feel that way a lot


**618.** `21:42` **Meredith Lamb (+14169386001)**

I thought you were going to tell my about your sister


**619.** `21:42` **You**

When we talk not texting it


**620.** `21:42` **You**

Just getting dressed and going to car


**621.** `21:42` **You**

But if we can’t chat maybe we can find some time tomorrow


**622.** `21:43` **Meredith Lamb (+14169386001)**

Ah k


**623.** `21:47` **You**

You alright?  Heading to car now


**624.** `21:47` **You**

If you want to


**625.** `21:48` **Meredith Lamb (+14169386001)**

k, I think my shadow is upstairs


**626.** `21:49` **You**

Kk ca
Whenever


**627.** `22:15` **You**

Sorry a means call and I am waiting on you because I don’t know when it is safe\.


