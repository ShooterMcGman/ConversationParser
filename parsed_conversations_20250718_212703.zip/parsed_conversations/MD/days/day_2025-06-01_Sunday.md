# Daily Conversation: 2025-06-01 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-01 |
| **Day** | Sunday |
| **Week** | 8 |
| **Messages** | 389 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-01T00:14 - 2025-06-01T22:48 |

## 📝 Daily Summary

This day contains **389 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:14` **Meredith Lamb (+14169386001)**

Reaction: 🥇 from Meredith Lamb
Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**002.** `06:52` **You**

Look at you\!\!


**003.** `06:52` **You**

Reaction: ❤️ from Meredith Lamb
I slept through my alarm heading to gym now


**004.** `06:54` **You**

Had a fucked up dream last night about war… wonder what that means\.  I used to have really vivid dreams\.  But not often anymore\.   This however was one of ‘em\.


**005.** `06:55` **You**

Alright up I get really hope Mac feels better this morning\.\. she’s a beast I am proud of her\!


**006.** `06:55` **You**

Love you\.\. ❤️❤️❤️ ur a beast too\!


**007.** `07:50` **You**

https://open\.spotify\.com/track/73zawW1ttszLRgT9By826D?si=gtv40nloTwatV6RCo6PIrQ&context=spotify%3Aplaylist%3A37i9dQZF1DZ06evO2zJOi2
Liking this song this morning\. No hidden meanings here
lol
Just really like the song\.


**008.** `08:37` **You**

Loving this new workout setup\.\. supersets are way to go for me for sure\.


**009.** `08:38` **Meredith Lamb (+14169386001)**

Ii only got up because griffin was whining to go out again …don’t they know his stomach is well


**010.** `08:38` **Meredith Lamb (+14169386001)**

Mac can’t find her phone but is otherwise fine, just hungover lol


**011.** `08:40` **You**

>
Good to hear

*💬 Reply*

**012.** `08:40` **Meredith Lamb (+14169386001)**

>
War dream? Interesting… like you were off at war?

*💬 Reply*

**013.** `08:40` **You**

Yep


**014.** `08:40` **You**

But it was local


**015.** `08:41` **You**

Meaning in Canada Toronto or something Mike that


**016.** `08:41` **You**

Like


**017.** `08:41` **Meredith Lamb (+14169386001)**

Whitby war in rural Whitby


**018.** `08:41` **You**

And all of these people from high school
We’re with me


**019.** `08:41` **You**

Kinda messed


**020.** `08:41` **You**

Reaction: 😂 from Meredith Lamb
I will just ignore the mocking\.


**021.** `08:45` **Meredith Lamb (+14169386001)**

I wonder what that means\. War going on in your head maybe … conflicting thoughts


**022.** `08:47` **You**

Fighting for your attention?


**023.** `08:48` **You**

Not worth playing this kinda game with me\.\.


**024.** `08:48` **You**

lol


**025.** `08:48` **You**

I got a million of em\.


**026.** `08:48` **You**

❤️


**027.** `08:49` **Meredith Lamb (+14169386001)**

lol


**028.** `08:49` **Meredith Lamb (+14169386001)**

I’m half asleep


**029.** `08:49` **Meredith Lamb (+14169386001)**

Just saying


**030.** `08:51` **You**

Yeah maybe go back to sleep lol


**031.** `08:51` **Meredith Lamb (+14169386001)**

Going to try for a bit ❤️


**032.** `08:52` **You**

Love you I could be fighting for our future,
Fighting for time, fighting for you love, fighting to defend you for on whatever, foghting to protect t myself from pain\. It was an invasion after all\.\. so many interpretations will ask chstgpr about all of these and orovide situational context


**033.** `09:02` **Meredith Lamb (+14169386001)**

Andrew is here dogs barking ugh\. Seeing as how he is here wonder if we should go for a drive somewhere? 😜 kidding\. Going to try to sleep for a bit for real


**034.** `09:03` **You**

Reaction: ❤️ from Meredith Lamb
Hey listen you go for a drive\.\. I am going to go help Sharon with her “form”


**035.** `09:03` **You**

See\.\. lol ❤️


**036.** `09:08` **You**

Would much rather help you youe form though 😜


**037.** `10:02` **You**

Reaction: ❤️ from Meredith Lamb
Todays update

*📎 1 attachment(s)*

**038.** `10:02` **You**

Sauna and shower love you\.\. hope you enjoyed your drive\.\. ❤️


**039.** `10:59` **Meredith Lamb (+14169386001)**

Just waking up for real


**040.** `10:59` **Meredith Lamb (+14169386001)**

Omg so exhausted


**041.** `10:59` **Meredith Lamb (+14169386001)**

Yesterday seemed so long and so late


**042.** `10:59` **You**

Yep I bet it was


**043.** `11:00` **Meredith Lamb (+14169386001)**

I tried to stay up and play ticket to ride and then watched tv


**044.** `11:00` **Meredith Lamb (+14169386001)**

Finally I was like fuck it bed\.


**045.** `11:00` **You**

lol


**046.** `11:00` **Meredith Lamb (+14169386001)**

Think it was 1\.30am


**047.** `11:02` **You**

Well I just finished everything was on way out mgr flagged me might meet with a trainer for 5 mins\. Just waiting


**048.** `11:02` **You**

I added Jim to signal and created a group


**049.** `11:02` **You**

You should see it


**050.** `11:06` **Meredith Lamb (+14169386001)**

I literally cannot get out of bed lol


**051.** `11:07` **You**

Hung over again…


**052.** `11:07` **Meredith Lamb (+14169386001)**

No just so tired


**053.** `11:07` **You**

Did you have a little bite of goodness? Or did you resist?


**054.** `11:07` **Meredith Lamb (+14169386001)**

No way that shit is poison to me


**055.** `11:07` **You**

lol


**056.** `11:08` **Meredith Lamb (+14169386001)**

I was sick for like 2 days after\!


**057.** `11:08` **You**

Well your dose was probably like 5X the recommended


**058.** `11:08` **Meredith Lamb (+14169386001)**

It was just different too tho


**059.** `11:08` **You**

If you ate 10 packs of gummies you would be equally fucked


**060.** `11:08` **Meredith Lamb (+14169386001)**

lol


**061.** `11:08` **Meredith Lamb (+14169386001)**

Maybe


**062.** `11:08` **You**

No def\.


**063.** `11:09` **You**

I am showing the trainer the Henry caville picture and say I want that\.\. and see what he says lol


**064.** `11:09` **Meredith Lamb (+14169386001)**

Haha


**065.** `11:10` **You**

Either that or the other dude I showed you\.\. reacher


**066.** `11:18` **Meredith Lamb (+14169386001)**

lol

*📎 1 attachment(s)*

**067.** `11:36` **You**

Erin probably got a kick out of that\.


**068.** `11:37` **Meredith Lamb (+14169386001)**

Whenever I show her anything of mackenzies she is like “those girls scare me\. They were mean to me in high school”


**069.** `11:37` **Meredith Lamb (+14169386001)**

lol


**070.** `11:38` **You**

And you were those girls… aww mer the mean girl\.\.


**071.** `11:38` **You**

Trainer thinks I am slightly insane


**072.** `11:38` **Meredith Lamb (+14169386001)**

He’s not wrong


**073.** `11:39` **You**

lol


**074.** `12:01` **You**

You busy?


**075.** `12:02` **Meredith Lamb (+14169386001)**

Just cleaning by myself


**076.** `12:02` **Meredith Lamb (+14169386001)**

Told girls to chill


**077.** `12:03` **Meredith Lamb (+14169386001)**

They are watching Harry Potter and comparing photos


**078.** `12:07` **You**

Kk just driving home you do your cleaning maybe we can chat later


**079.** `12:07` **Meredith Lamb (+14169386001)**

We can chat\. I can take a break


**080.** `12:07` **You**

Up to you


**081.** `12:08` **You**

Call when yoj settled


**082.** `12:41` **You**

Like how I dropped that in there at the end lol\.


**083.** `12:42` **Meredith Lamb (+14169386001)**

The absolute thing?


**084.** `12:43` **You**

No the even if you are still confused and unsure about what you want\.


**085.** `12:43` **You**

Bah you missed it\.\. no fun\.


**086.** `12:46` **Meredith Lamb (+14169386001)**

I caught it but don’t agree\. I am NOT confused\!


**087.** `12:46` **You**

Kk


**088.** `12:46` **Meredith Lamb (+14169386001)**

Honestly, wanting to be with you is the least confusing thing right now\.


**089.** `12:47` **You**

I love you\.\. will chat with you later\.\. ❤️❤️❤️❤️\.  Yeah I guess so\.\. maybe confused is wrong word\.\. hesitant / afraid\.  That was what I felt the other night\.\. cautious\.  I dunno you give off a vibe sometime\. Especially when you get quiet\.


**090.** `12:51` **Meredith Lamb (+14169386001)**

k, yeah those things maybe\. Confused, not at all\.


**091.** `12:52` **Meredith Lamb (+14169386001)**

Love you too xo


**092.** `13:21` **You**

No chance for them going to have to set ai to hard\.

*📎 1 attachment(s)*

**093.** `13:38` **Meredith Lamb (+14169386001)**

lol


**094.** `13:38` **Meredith Lamb (+14169386001)**

Yeah I didn’t even finish my cards but still won


**095.** `13:41` **You**

I spanked them this game was easy


**096.** `13:41` **Meredith Lamb (+14169386001)**

>
Was thinking while cleaning\. Not “hesitant” but you are kind of scary so “afraid” could be accurate but that seems severe\. More anxious

*💬 Reply*

**097.** `13:42` **You**

Scary how?  ☹️


**098.** `13:51` **Meredith Lamb (+14169386001)**

I guess just your history of shutting off so completely and not for a short time, for many years\. It’s a bit scary\. But it’s okay, I understand it and it is part of who you are so I’m processing it and trying NOT to be afraid\. You are worth it\. :\)


**099.** `13:53` **You**

Mer\.\. sigh\.\. before I shut down\.\. to protect my feelings\.\. but I never stopped trying with j not until January of this year\.\. and even after that I still tried to support make smarter decisions take care of herself etc\.


**100.** `13:54` **You**

I think you think me shutting down means I give up\.\. it doesn’t\.  Problem with j and I was the spark was never there to begin with\.\.


**101.** `13:57` **You**

And I still committed was there for her supported her\. Yeah obligation and loyalty was big and loyalty is core to me\. But I don’t think you will ever need to worry about that honestly\.   You engage\.  I think if we ever ran into a tough time\.\. 1 we would communicate, I have already shown the level of communication you can expect from me\.\. 2 we support each other\.\. shutting down isn’t my first second third etc etc option\.  3 I don’t think you would let me, you have demonstrated that already and you have seen how I have reacted\.


**102.** `13:58` **You**

This is new and really hard for me to care this much for you and manage my emotions when they weren’t around for sooo long\.


**103.** `13:58` **You**

It wasn’t that I shut them off they didn’t exist\.


**104.** `13:58` **You**

I figured you were
More afraid of how intensely I felt about you or something more along those lines


**105.** `13:58` **You**

I could get that


**106.** `13:59` **Meredith Lamb (+14169386001)**

I think I understand, really, logically I do but because I wasn’t there to experience it, there are some tricky gaps sometimes that come up in my head\. \(Not now\.\)
Why would I be afraid of how you feel when I feel the same way but just am not as verbally expressive?


**107.** `13:59` **You**

But even if i shut down now because of how challenging this is\.\. it isn’t that I want to shut you out\.  I want to preserve myself for when we can be together


**108.** `14:00` **You**

>
>
I don’t know I put it out there hard\.\. I could see how it could be off putting\.

*💬 Reply*

**109.** `14:02` **You**

Reaction: ❤️ from Meredith Lamb
If you hurt me I won’t shut down I will tell you\.  I told you right away on Friday when I was having a hard time\.\. I didn’t shut you out\.\. we can deal with shit mer I am not worried about that\.\. I am not worried for when we have our first “fight” “disagreement” or whatever you want to call it\.\.  I was for a long time\.\. because we hadn’t really defined what this is\.\. I am not worried about that anymore\.


**110.** `14:03` **You**

And the closer we get to a normal relationship a lot of this stuff will just completely go away\.  As I get used to you, the evolving situation, and my crazy feelings\.


**111.** `14:03` **You**

So hopefully that eases your anxiety a bit\.


**112.** `14:05` **You**

I know you only have one real reference point for me\.\. but it would be like me completely comparing your behaviour with Andrew with how you might behave with me in the future\.


**113.** `14:06` **You**

Completely nonsensical?


**114.** `14:06` **Meredith Lamb (+14169386001)**

>
I mean off putting if the other person is feeling differently perhaps\.

*💬 Reply*

**115.** `14:06` **Meredith Lamb (+14169386001)**

>
It does\.

*💬 Reply*

**116.** `14:07` **Meredith Lamb (+14169386001)**

>
This is a really good point I hadn’t thought of actually\.

*💬 Reply*

**117.** `14:07` **Meredith Lamb (+14169386001)**

They are sending me to town for pizza and then I guess we are leaving at 4


**118.** `14:09` **You**

Pizza is great next day food…


**119.** `14:10` **You**

Edited: 2 versions
| Version: 2
| Sent: Sun, 1 Jun 2025 14:10:54 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Sun, 1 Jun 2025 14:06:54 \-0400
| >
| > It does\.
|
| I am glad\. there are likely going to be little fears for awhile\.\. but not forever\.\. you need a new baseline and that will be us\.  Eventually lol\.\. after months and years of patiently waiting rofl\.
|
| Version: 1
| Sent: Sun, 1 Jun 2025 14:10:24 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Sun, 1 Jun 2025 14:06:54 \-0400
| >
| > It does\.
|
| I am glad there are likely going to be little fears for awhile\.\. but not forever\.\. you need a new baseline and that will be us\.  Eventually lol\.\. after months and years of patiently waiting rofl\.


**120.** `14:10` **You**



**121.** `14:10` **Meredith Lamb (+14169386001)**

Kitchen and dining area are clean now so I feel ok\. Rest can be cleaned next time\. :p


**122.** `14:11` **You**

Oh shit you can edit didnt know that


**123.** `14:12` **You**

>
I am sure you will have a chance to get a thorough cleaning in before your girls weekend\.

*💬 Reply*

**124.** `14:18` **Meredith Lamb (+14169386001)**

>
Yeah, the baseline is definitely completely messed up right now\.

*💬 Reply*

**125.** `14:21` **You**

It won’t be though\.  Every chance we get to spend time I feel “better” no other word for it\. Once the settlement agreements are in place
That will be huge\. Once you move out and Jaimie goes to Moncton will be another massive milestone\.\. in the meantime we take, find or make small opportunities\.


**126.** `14:21` **Meredith Lamb (+14169386001)**

Foodland \- you can get got pizzas so I don’t have to deal with oven


**127.** `14:21` **Meredith Lamb (+14169386001)**

\*hot


**128.** `14:21` **You**

Well that makes it easier for sure


**129.** `14:22` **Meredith Lamb (+14169386001)**

>
Yeah I feel consistently “better” also\. Especially with the upcoming work situation becoming official in a week\.

*💬 Reply*

**130.** `14:22` **Meredith Lamb (+14169386001)**

Helps me feel like you won’t lose your job 😵‍💫


**131.** `14:23` **You**

I wouldn’t and won’t\.\.


**132.** `14:23` **You**

But I am glad it will be a relief for you


**133.** `14:24` **Meredith Lamb (+14169386001)**

>
If Jaimie said anything they would have to do an investigation\. That would be annoying, potentially lengthy, intrusive, etc

*💬 Reply*

**134.** `14:25` **You**

She won’t because it would embarrass her and it would put the kids future inheritance at risk\.


**135.** `14:25` **Meredith Lamb (+14169386001)**

Scorned women sometimes act out


**136.** `14:25` **Meredith Lamb (+14169386001)**

But in a week it won’t matter


**137.** `14:26` **You**

So from a logical perspective she definitely won’t\.\. even if she didn’t care about that she still wouldn’t, I trust her in that and how she reacted when I suggested she might do it\.


**138.** `14:26` **You**

Sry hurt and offended I would suggest it


**139.** `14:26` **You**

Very


**140.** `14:26` **You**

Again I know you emailed or called that girl


**141.** `14:27` **Meredith Lamb (+14169386001)**

And her husband


**142.** `14:27` **You**

She would never do that\.\. more likely to say something mean to you under her breath…


**143.** `14:27` **Meredith Lamb (+14169386001)**

I may have talked to them on phone\. Can’t remember


**144.** `14:27` **You**

If she saw you


**145.** `14:27` **Meredith Lamb (+14169386001)**

I was extremely pissed


**146.** `14:27` **You**

For good reason


**147.** `14:27` **Meredith Lamb (+14169386001)**

I didn’t care if he lost his job\. I wasn’t thinking at all


**148.** `14:28` **You**

Yeah she is not there


**149.** `14:28` **Meredith Lamb (+14169386001)**

Was working at union with 3 young kids


**150.** `14:28` **You**

Maybe if this was a brutal cheat or an affair


**151.** `14:28` **You**

Yeah but even then\.\. I don’t know\.\.


**152.** `14:28` **Meredith Lamb (+14169386001)**

Admirable


**153.** `14:29` **You**

Again too much attention to herself


**154.** `14:32` **You**

I don’t think it would yield anything there was no undue influence no unfair benefit you got the position back in September\. Like


**155.** `14:33` **You**

Even if they felt we slightly crossed the line even being emotional with each other there is nothing major here\. And you made the move to switch jobs\.\.


**156.** `14:35` **Meredith Lamb (+14169386001)**

True but an investigation would suck so bad


**157.** `14:36` **Meredith Lamb (+14169386001)**

And we obviously crossed some line because we hit it from everyone


**158.** `14:36` **You**

Mmm I don’t agree with your logic


**159.** `14:37` **You**

I think that assuming people would naturally think we crossed a line is the reason\. I feel like that is as reasonable as your suggestions\.  We hid it because we were afraid what people would think or draw conclusions that might not be true\.


**160.** `14:38` **You**

Not necessarily that we actually did what people might think\.


**161.** `14:38` **Meredith Lamb (+14169386001)**

>
All of the conclusions drawn would have been true though lol

*💬 Reply*

**162.** `14:38` **You**

But not provable


**163.** `14:39` **Meredith Lamb (+14169386001)**

Omg lol


**164.** `14:39` **You**

Lawyered\!


**165.** `14:39` **Meredith Lamb (+14169386001)**

So my logic is sound, but just can’t be proven


**166.** `14:39` **You**

Yes


**167.** `14:40` **You**

Proven by others


**168.** `14:41` **Meredith Lamb (+14169386001)**

I do believe with our families, though proving doesn’t matter that only matters at work


**169.** `14:41` **Meredith Lamb (+14169386001)**

Families will think they will think I’m being able to prove it doesn’t matter at all or change anything


**170.** `14:42` **You**

Yeah they already think whatever I am not worried about that\.\. I am worried about how we communicate to maddie eventually\.


**171.** `14:42` **You**

Remeber


**172.** `14:42` **You**

Mac can’t tell maddie lol


**173.** `14:43` **You**

Ok I have to go do some work to pack etc\.\.
Love you…chat later probably after you get home
Tonight?


**174.** `14:48` **Meredith Lamb (+14169386001)**

Yup leaving 4ish


**175.** `14:58` **Meredith Lamb (+14169386001)**

Reading emails\. SC meeting …\. Groan\.


**176.** `15:15` **You**

Yep


**177.** `15:16` **You**

Sry


**178.** `15:52` **Meredith Lamb (+14169386001)**

When is it


**179.** `15:54` **You**

Afternoon tomorrow


**180.** `15:54` **You**

I sent an invite I thought


**181.** `15:54` **You**

I might just attend myself


**182.** `15:54` **You**

Save you the trouble


**183.** `15:55` **Meredith Lamb (+14169386001)**

I don’t see an invite


**184.** `15:55` **You**

Ah well maybe I will just attend anyways


**185.** `15:55` **Meredith Lamb (+14169386001)**

So the girls said the weekend was “baller”


**186.** `15:55` **You**

Yeah I knew it was awesome


**187.** `15:56` **Meredith Lamb (+14169386001)**

But they go “why do you and Scott FaceTime 24/7?”


**188.** `15:56` **Meredith Lamb (+14169386001)**

I’m like “we do not”


**189.** `15:56` **Meredith Lamb (+14169386001)**

They were like “but you were last night and this morning”


**190.** `15:56` **Meredith Lamb (+14169386001)**

Me: “that is hardly 24/7 but ok”


**191.** `15:57` **Meredith Lamb (+14169386001)**

They said I’m cool when I’m FaceTiming tho and not annoying like Liana and costa\. Lol


**192.** `15:57` **You**

ROFL


**193.** `15:57` **Meredith Lamb (+14169386001)**

Teenagers are weird when they start talking


**194.** `16:00` **You**

I am surprised they are so cool with it honestly\.


**195.** `16:02` **Meredith Lamb (+14169386001)**

Cool with what?


**196.** `16:02` **Meredith Lamb (+14169386001)**

Us?


**197.** `16:12` **You**

Yeah us


**198.** `16:12` **You**

Of course


**199.** `16:13` **Meredith Lamb (+14169386001)**

They just like me so they are cool with whatever I’m cool with lol


**200.** `16:13` **You**

Oh so I am accepted
Through relation\.


**201.** `16:14` **You**

Good enough


**202.** `16:14` **You**

Edited: 2 versions
| Version: 2
| Sent: Sun, 1 Jun 2025 16:14:55 \-0400
|
| Well pool
| Is cleaned hot
| Tub is cleaned now mow the lawn not what I wanted to be focused on but such is my life
|
| Version: 1
| Sent: Sun, 1 Jun 2025 16:14:39 \-0400
|
| Well pool
| Is cleaned hot
| Tub is cleaned now mow the lawn not what I wanted to be focused on but suck is my life


**203.** `16:50` **You**

Drive safe


**204.** `16:53` **Meredith Lamb (+14169386001)**

Omg just leaving


**205.** `17:25` **You**

Wow that sucks thought you left well before that


**206.** `18:17` **Meredith Lamb (+14169386001)**

Stopping for star bucks and washroom break\.  Apparently they drank too much water :p


**207.** `18:22` **You**

lol just chilling in basement while rest of fam fights\. Got a lot of housework done today but no packing


**208.** `18:23` **Meredith Lamb (+14169386001)**

More fights…\. Oh boy\. Neverending


**209.** `18:23` **You**

Nope always going


**210.** `18:24` **You**

Just strengthens
Argument they cannot live together maddie and Gracie


**211.** `18:24` **Meredith Lamb (+14169386001)**

Well most siblings part at about this age so it is pretty normal for them to split


**212.** `18:26` **You**

yeah cannot happen soon enough


**213.** `18:27` **Meredith Lamb (+14169386001)**

Omg the girls are taking so long


**214.** `18:27` **Meredith Lamb (+14169386001)**

Sitting here with griffin lol


**215.** `18:28` **You**

just enjoy the peace


**216.** `18:30` **Meredith Lamb (+14169386001)**

If I have to hear “low key” one more time


**217.** `18:31` **You**

Tormenting Jim atm


**218.** `18:31` **Meredith Lamb (+14169386001)**

K we are off again


**219.** `18:31` **You**

Try and disconnect will ya?
6m
I can't I have to move this forward dude
I need to get to the end of this road\.\. and I feel like I am the only one lifting the weight
4m
I not referring to your transition\. I am talking about work\.
3m
well I am losing Mer\.\. so I kind of have to keep on top of some things\.
god if only someone who I was really close to and trusted with pretty much anything would apply for the role\.
😜
I don't think Bailey will apply though
1m
Ha ha ha\.
Now
HAHAHAHAHA
yeah son\!\!\!
gocha\!\!


**220.** `18:33` **Meredith Lamb (+14169386001)**

lol


**221.** `18:33` **You**

I thought I was funny\.


**222.** `18:33` **You**

I would love him to come over though\.\. but no dice


**223.** `18:33` **Meredith Lamb (+14169386001)**

I think I convinced him it is too much work lol sorry


**224.** `18:33` **You**

wow


**225.** `18:33` **Meredith Lamb (+14169386001)**

\(Had to send Mac in to get me milk for my coffee\)


**226.** `18:33` **You**

way to go for teamwork


**227.** `18:34` **You**

Hey I am going to leave and make sure other good people don't come


**228.** `19:56` **Meredith Lamb (+14169386001)**

>
No it’s just that he’s heard me talk about it over time\. I didn’t say anything intentional

*💬 Reply*

**229.** `19:56` **Meredith Lamb (+14169386001)**

Dropping girls off now


**230.** `19:57` **You**

>
Mmmhmmm a likely story\.

*💬 Reply*

**231.** `20:10` **Meredith Lamb (+14169386001)**

Seriously


**232.** `20:13` **You**

This was a joke mer\.\. I know you would never do that\.\. 🙁 did you Actually think you would believe inwould\.\.
I kinda hope you are messing with me now\.


**233.** `20:13` **You**

You really are anxious/on edge\.


**234.** `20:18` **You**

Be back I\. A few Gracie wants to play a Ballard game


**235.** `20:18` **You**

Board


**236.** `20:29` **Meredith Lamb (+14169386001)**

k, I’m visiting with my girls


**237.** `20:37` **You**

Kk don’t forget to come back to my question you sometimes do that\.


**238.** `20:38` **Meredith Lamb (+14169386001)**

What question?


**239.** `20:42` **You**

>
This and those that followed

*💬 Reply*

**240.** `20:47` **Meredith Lamb (+14169386001)**

Not sure I understand the question bc of the typo but no I figured you were kidding but sort of kidding\. I just wanted to make sure you knew I didn’t say anything like “don’t go for that job\!” lol


**241.** `20:47` **Meredith Lamb (+14169386001)**

Wasn’t like that


**242.** `20:47` **Meredith Lamb (+14169386001)**

But over the past few months it has just been busy


**243.** `20:47` **Meredith Lamb (+14169386001)**

And we talk all the time


**244.** `20:47` **Meredith Lamb (+14169386001)**

That’s all


**245.** `20:47` **Meredith Lamb (+14169386001)**

There were no “those that followed”


**246.** `20:49` **You**

Kk nm must have misread\.


**247.** `21:00` **Meredith Lamb (+14169386001)**

Think I’m going to go to bed early tonight even tho I slept in\. But I had a coffee on way home so am not feeling tired\. Ughhhhhh


**248.** `21:15` **You**

Done my game now if you are still up


**249.** `21:15` **You**

I am going to bed early too was
Working on an ai project


**250.** `21:16` **Meredith Lamb (+14169386001)**

Just making a tea and then going upstairs


**251.** `21:16` **Meredith Lamb (+14169386001)**

One sec


**252.** `21:16` **You**

Kk


**253.** `21:30` **You**

>
sorry I never cleared this up earlier\.\. was just surprised you would believe I would think that of you in any serious way\.\. maybe my sarcasm is not amped up enough\.

*💬 Reply*

**254.** `21:32` **Meredith Lamb (+14169386001)**

Ok\. I am finally lying in bed\. Omg\. Marlowe is going on her 3 day grade 6 grad trip tomorrow so just needed to make sure she was all packed good


**255.** `21:32` **You**

cool \- yeah so busy\.\.\. bet the kids missed you


**256.** `21:32` **Meredith Lamb (+14169386001)**

They were busy enough with stuff so I think they were ok


**257.** `21:33` **Meredith Lamb (+14169386001)**

They liked hearing about Mac’s friends tho


**258.** `21:33` **You**

I am sure\.\. they are probably looking forward to their own epic parties now


**259.** `21:35` **Meredith Lamb (+14169386001)**

Did you do your little analysis you said you were going to do?


**260.** `21:36` **You**

Doin another analysis


**261.** `21:36` **You**

related


**262.** `21:36` **Meredith Lamb (+14169386001)**

>
They both want the same for their 16ths\. 🤪

*💬 Reply*

**263.** `21:36` **You**

>
I might be able to help with those\.

*💬 Reply*

**264.** `21:37` **Meredith Lamb (+14169386001)**

>
I mean, you helped with this one\!

*💬 Reply*

**265.** `21:37` **You**

well maybe I could be there with you perhaps\.


**266.** `21:38` **Meredith Lamb (+14169386001)**

Fortunately, years away\. Phew\. I need a break from planning for a bit\.


**267.** `21:38` **You**

rofl


**268.** `21:38` **Meredith Lamb (+14169386001)**

One month off then I will start planning for aug7\-10 weekend


**269.** `21:38` **You**

until next week


**270.** `21:39` **You**

I was thinking about the august thing too


**271.** `21:39` **Meredith Lamb (+14169386001)**

Yeah I will want to make that one good


**272.** `21:40` **Meredith Lamb (+14169386001)**

Plus I may get pulled into another one in the summer\. Usually do\. Graduation or birthday or something


**273.** `21:40` **You**

not surprised


**274.** `21:40` **Meredith Lamb (+14169386001)**

3 graduations this year


**275.** `21:40` **Meredith Lamb (+14169386001)**

Usually we do a party for that


**276.** `21:40` **Meredith Lamb (+14169386001)**

Sigh


**277.** `21:40` **Meredith Lamb (+14169386001)**

I might get a reprieve because of the separation


**278.** `21:41` **Meredith Lamb (+14169386001)**

So tell me about your analysis


**279.** `21:41` **You**

You should try to keep it as normal as possible


**280.** `21:41` **You**

despite the separation\.


**281.** `21:41` **You**

no it isn't worth it\.


**282.** `21:41` **You**

the analysis


**283.** `21:41` **Meredith Lamb (+14169386001)**

Why


**284.** `21:41` **Meredith Lamb (+14169386001)**

Not interesting?


**285.** `21:41` **You**

Not conclusive\.\. not enough information\.


**286.** `21:41` **Meredith Lamb (+14169386001)**

How on earth


**287.** `21:42` **You**

I was trying to get help with how to approach the "open" concept\.\. just not enough context or information\.\. it tried to help me\.\. it was very kind and understanding lol\.\.\. but nadda\.


**288.** `21:43` **Meredith Lamb (+14169386001)**

LOL


**289.** `21:43` **Meredith Lamb (+14169386001)**

kind and understanding


**290.** `21:43` **You**

it was at that


**291.** `21:43` **You**

it appreciated my efforts\.\. LOL


**292.** `21:44` **Meredith Lamb (+14169386001)**

I thought you were intending to do some different analysis about me being honest or something g


**293.** `21:44` **You**

I am


**294.** `21:44` **You**

I had a quandry though


**295.** `21:45` **You**

it is one of those things that you know to be true but you fall into the trap anyways\.\. anyhow GPT was very helpful\.\.


**296.** `21:46` **Meredith Lamb (+14169386001)**

It was?


**297.** `21:48` **You**

Query \- Is there an adage in relationships about not trying to compete with what came before—especially meaningful or positive memories? My girlfriend and I are both 47 and coming out of significant, long\-term relationships\. She’s mentioned that she’s interested in us exploring things a little more openly—perhaps reconnecting with a different kind of energy or freedom she experienced in earlier chapters of her life, long before her last relationship\.
She hasn’t fully explained what that means yet, and I get the sense it might be hard to put into words—or maybe she’s still figuring it out\. I also know I have some insecurities of my own\. I’m not trying to compare myself to the past, and I don’t want to feel jealous of it—but I’d be lying if I said I wasn’t still finding my footing with it all\.


**298.** `21:49` **Meredith Lamb (+14169386001)**

Is it weird if I found it odd reading “my girlfriend and I” 🙂


**299.** `21:50` **You**

Reaction: ❤️ from Meredith Lamb
I mean\.\. like I said\.\. that is what I have called you to a few people\.\. I don't know what else to say\.\. you feel like more than that\.\. but that also feels like the appropriate term\.


**300.** `21:50` **You**

Here is the response\.\. which I found very relevant\.
Scott, this is deeply thoughtful—and emotionally honest\. You're absolutely right: you can’t and shouldn’t compete with the past, especially someone’s emotional or romantic history\. There is a kind of adage here, though it’s more wisdom than a single quote\. It’s something like:
“You’re not here to replace the past; you’re here to build what comes next\.”
Here’s the heart of the matter:
🧠 Perspective: Past vs\. Present vs\. Future
The past is like a photo album—it can be cherished but not relived\.
You are her present—and maybe her future—not her past\. That’s already incredibly meaningful\.
Memories aren’t threats unless we make them so\. They’re reference points, not rivals\.
❤️ The Emotional Equation
You’re both 47, which means you carry more than just luggage—you’ve got trunks of experiences\. But you’re not starting over, you’re starting from\.
Your insecurity makes sense—especially when the conversation turns to opening up emotionally or sexually in ways that echo her past\. But being different from the past doesn’t make you less than it\. It makes you real, present, and chosen\.
She may not be able to articulate what she wants because:
She’s still discovering it\.
She's testing if it’s safe to explore it with you\.
She may want freedom without chaos, spontaneity without recklessness—something she didn’t know how to balance before\.
🛡️ What You Can Do Instead of Competing
Here’s your power move:
Don’t compete\. Co\-create\.
Start asking questions like:
“What about those past experiences made you feel alive or free?”
“How can we safely explore something new that still makes us feel secure?”
“What’s something adventurous or meaningful we could do—just the two of us?”
🧩 A Framing to Try:
“I’m not jealous of who you were, or what you did\. But I care about who you’re becoming—and who we can be together\. Let’s write our story, not edit someone else’s\.”
You don’t need to be wild, or huge, or crazy to matter\.
You just need to be the man she trusts to bring her forward, not drag her back\.
Let me know if you’d like help crafting how to say this to her in your own voice\.


**301.** `21:57` **Meredith Lamb (+14169386001)**

Pretty good response no?


**302.** `21:57` **Meredith Lamb (+14169386001)**

One sec


**303.** `21:57` **You**

yeah I thought it was


**304.** `22:01` **Meredith Lamb (+14169386001)**

I asked ai to articulate for me and it said this which I agree with but could never write on my own:
You’re not asking for novelty just for the sake of “trying new things\.” You’re also not drawing on past relationships as a blueprint\. In fact, you’re deliberately not trying to recreate what came before\. You’re craving a kind of intimacy that’s emotionally alive, co\-created, and attuned to this relationship—not stuck in old grooves\.
And the heart of it is this:
You’ve seen what it looks like when someone shuts down—sexually and emotionally—and you’re afraid of that happening again\. That fear makes you want to invite openness now, before anything gets stuck or withdrawn\. But when you asked him about evolving together, he zeroed in on “what exactly do you mean?”—because he was trying to do something “right,” when really you were speaking to a way of being\.
Here’s a different way you could try to explain it to him:
⸻
\*\*“When I asked about being more open and evolving together sexually and emotionally, I wasn’t asking you to change who you are, or to perform, or to guess what I want\. I was really saying: please don’t shut down with me\. That’s what I’m afraid of—because I know what it feels like when intimacy quietly disappears in a relationship\.
I think you may have felt I was referring to some old flame or past experience that you need to measure up to\. But I’m not\. I’m not trying to recreate something I had before—I’m trying to stay connected and alive with you, in this relationship, as it grows\.
When I talk about openness, I mean the kind of energy where we can explore—not just sex in the physical sense, but the safety to be emotionally close, playful, curious\. Even vulnerable\. That doesn’t require a list of things we have to try\. It’s more about making sure we don’t drift into silence or avoidance—because when that happens, we both lose each other a little\.”\*\*


**305.** `22:01` **Meredith Lamb (+14169386001)**

I think I’m just always afraid\.


**306.** `22:01` **Meredith Lamb (+14169386001)**

It basically comes down to that\.


**307.** `22:02` **Meredith Lamb (+14169386001)**

Like honestly the relief I feel that Mac’s weekend was a big success\. I was so afraid it wouldn’t be\.


**308.** `22:02` **You**

"You’ve seen what it looks like when someone shuts down—sexually and emotionally—and you’re afraid of that happening again" \- is this your perspective of me?


**309.** `22:02` **You**

>
I think you set awfully high bars for yourself\.

*💬 Reply*

**310.** `22:02` **Meredith Lamb (+14169386001)**

>
This happened to me with Andrew\.

*💬 Reply*

**311.** `22:03` **Meredith Lamb (+14169386001)**

I do believe it happened to you also\.


**312.** `22:03` **Meredith Lamb (+14169386001)**

I just overthink and especially when I’m drinking and taking gummies


**313.** `22:04` **You**

sigh\.\.


**314.** `22:05` **Meredith Lamb (+14169386001)**

But was that ChatGPT helpful?


**315.** `22:05` **Meredith Lamb (+14169386001)**

It really captures where I was going … when or if one of us shuts down, it all goes to hell\.


**316.** `22:09` **You**

I feel a bit I don't know\.\. like I am not communicating well\.\. Mer\.\. maybe this is where we are disconnecting\.\. I felt I have already shown you I am "open" especially with you\.  In fact you and no one else\.  Ok I understand the shut down thing\.\. but I think you are looking at two different things\.  1\. me shutting down now\.\. is just temporary protection\.\. not permanent\.\. like stasis\.  But it was inconsiderate\.\. because it would be hurting you too\.\. so I agreed not to do that\.\. not to pull away\.\. to stay and communicate\.\. oh and yes not to make any friends\.\. 2\. Me shutting down later or as more of a permanent thing\.  You cannot compare our relationships even a little\.  They are so different\.\. even our pasts were different\.\. you got to experience so much more in your 20's I didn't I went straight into a meh relationships that was 180 degrees from this\.  I don't know what "open" means to me or to you\.\. I just know that whatever it is or we decide it is, I am in it with you, with little to no reservation or fear\.\. maybe some nervousness\.\. but that is just me\.\. not very confident\.\. lol\.  So does that help you\.\. it honestly hurts to read this because I know how much I love you, and I just don't think you do yet\.\. I think you think you do\.\. but you don't\.\. not really\.


**317.** `22:09` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**318.** `22:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**319.** `22:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**320.** `22:11` **You**

kk All of that\.\. I am good with\.\. but I have to be with you for that to work right\.\. chat only gets you so far\.\.\.\.\. So tell me what you are wearing tonight?????  lol


**321.** `22:12` **You**

I think I have shown that I want to find every opportunity big or small to be with you\.\. not just to jump your bones\.\. but to look at you hold your hand\.\. talk about shit\.\. laugh with each other\.\. just be there\.


**322.** `22:12` **You**

that is what the park idea always was about\.


**323.** `22:12` **You**

to stay connected


**324.** `22:13` **Meredith Lamb (+14169386001)**

I know\. I was just drunk and talking that night\.


**325.** `22:13` **Meredith Lamb (+14169386001)**

You latched on hard


**326.** `22:13` **Meredith Lamb (+14169386001)**

lol


**327.** `22:13` **You**

I am "open" and will remain that way\.\. ok\.\. not going to change\.\. but neither is my intensity\.\. it might be that as I get older I cannot literally be as intense\.\. rofl\.\. but as a % of what I am capablle of at any given time you will get 100% of what I have\.\.rofl\.


**328.** `22:13` **You**

because of your past


**329.** `22:14` **You**

The exploits of you Chris and Jeremy\.\. were not conveyed anywhere near like what you described open to gpt\.


**330.** `22:14` **You**

so I had a hard time reconciling


**331.** `22:15` **You**

but the point should be


**332.** `22:15` **Meredith Lamb (+14169386001)**

Exploits lol


**333.** `22:15` **You**

I was trying to desparately\.\. because it was important to me


**334.** `22:15` **You**

to find a way to connect with you the way you wanted


**335.** `22:15` **Meredith Lamb (+14169386001)**

You had exploits


**336.** `22:15` **You**

I don't think they were quite like yours\.


**337.** `22:15` **You**

I am just guessing\.


**338.** `22:16` **Meredith Lamb (+14169386001)**

Maybe you are guessing wrong\. Who knows


**339.** `22:16` **You**

And by guessing I mean not thinking about it at all specifically because I don't want to really\.\.


**340.** `22:16` **You**

but yeah\.\. I don't see the connection between what you told me\.\. and the gpt\.


**341.** `22:16` **Meredith Lamb (+14169386001)**

In any case, this topic got blown up huge\. lol


**342.** `22:16` **You**

so I was just a bit confused\.


**343.** `22:17` **Meredith Lamb (+14169386001)**

>
What??

*💬 Reply*

**344.** `22:17` **You**

I still don't understand it mer\.\. but yeah\.\. maybe just put it to bed\.


**345.** `22:17` **Meredith Lamb (+14169386001)**

Explain


**346.** `22:17` **You**

You wouldn't remember\./


**347.** `22:17` **You**

so it doesn't matter lol


**348.** `22:17` **Meredith Lamb (+14169386001)**

Sure I would


**349.** `22:17` **Meredith Lamb (+14169386001)**

I reread it all


**350.** `22:17` **You**

No you were really really drunk


**351.** `22:17` **You**

and you told me about it


**352.** `22:17` **You**

you didn't write it


**353.** `22:18` **Meredith Lamb (+14169386001)**

Oh damn, now I have zero knowledge lol


**354.** `22:18` **You**

it was the first night of the long weekend\.\.


**355.** `22:18` **You**

and yeah you got pretty messed\.


**356.** `22:18` **You**

and you started talking about you and Chris\.\. for quite a while actually\.\. probably like an hour\.


**357.** `22:18` **You**

then you talked about you and Jeremy for about 45 mins I guess\.\. maybe


**358.** `22:18` **Meredith Lamb (+14169386001)**

Man I need to stop…


**359.** `22:19` **Meredith Lamb (+14169386001)**

Why didn’t you stop me lol


**360.** `22:19` **Meredith Lamb (+14169386001)**

Omg


**361.** `22:19` **You**

I didn't know what to do\.\.


**362.** `22:19` **You**

That is where the stark truth comment came from


**363.** `22:19` **You**

lol


**364.** `22:19` **Meredith Lamb (+14169386001)**

I guess lol


**365.** `22:19` **You**

I was just kind of like, holy detail\.\. and then I just drank every time you looked at me expecting me to respond\.\. so you continued\.


**366.** `22:20` **You**

anyways\.\. I could do without the knowledge\.\. but it is what it is\.


**367.** `22:20` **You**

no worries


**368.** `22:20` **Meredith Lamb (+14169386001)**

I feel bad for you… seriously\. I am stupid


**369.** `22:22` **Meredith Lamb (+14169386001)**

So given the fact that I’m not really clear on the level of detail my stupid messed up self went into, regardless of that, I apologize, that was dumb of me\. And if you want me to clarify anything \(groan\) I will\. But if you want to never speak of it ever again, I’m equally good \(or thrilled\) with that


**370.** `22:23` **You**

There was enough detail for me to fill in some blanks\.  so maybe the second option\.


**371.** `22:24` **Meredith Lamb (+14169386001)**

Sold\.


**372.** `22:25` **You**

I mean I thought you might have remembered this\.\. so when you referenced open and then J and C I thought ok I might get something specific here\.\. but then nothing\.\. then I thought back and tried to figure it out myself\.\. but could not\.\. only word that I think sums up both relationships well is "Intense"


**373.** `22:25` **You**

Yeah should have left this one alone\. Sorry for bringing it up\.


**374.** `22:26` **You**

I was just trying to figure out what to do\. just too much there to think through


**375.** `22:26` **Meredith Lamb (+14169386001)**

No don’t apologize\. Apparently I brought it up\! Lol


**376.** `22:29` **Meredith Lamb (+14169386001)**

Just to re\-iterate, I’m not looking to re\-create anything there\. Yes I had fun and yes, it was a very different vibe than my time with Andrew however, there were a lot of negatives that haven’t been discussed at all\. So keep that in mind\.
You and I have started something so much more amazing for so many different reasons\. I think I am just fearful of it going away\. Honestly\. I think that is where this all stemmed from\.


**377.** `22:29` **Meredith Lamb (+14169386001)**

\(Despite you not believing that\.\)


**378.** `22:33` **Meredith Lamb (+14169386001)**

Please just tell me you are all good\.


**379.** `22:35` **You**

Like I said people are honest when they are drunk\.\. lol\.\. I do believe what you are saying "You and I have started something so much more amazing for so many different reasons\."  But I have told you before I was worried that I could not keep up or keep you interested\.\. because of the "interesting" things you have shared with me\.  I mean let me unpack this a bit differently\.\. I am a people pleaser \- You are an internalizer and challenging to read\.  So hard to tell what works and what doesn't because again communication\.\.\.\. I think we have an amazing time together\.  Then a conversation goes to concerns that my level of intensity might not last, and am I "open" and wondering if our relationship is going to evolve\.\. which I am just not sure to what you are referring because there was so much, am I not doing the right things\.\. sending the right signals\.  I mean it just makes me question myself\.  But yeah we are all good\.\. just again alot to process Mer\.\. that's all\.


**380.** `22:36` **You**

So yeah\.\. I will put the open thing in a box with the other stuff\.\. I mean I thought I was showing that already\.\. but maybe not\.\.  and I will just keep moving forward\.


**381.** `22:39` **Meredith Lamb (+14169386001)**

You have been for sure \- incredibly \- but again, was just anxious and I’m still figuring us out too\. I was just talking and not really thinking it would be taken as you are doing anything incorrectly\. You are not\. At all\. Ugh, I wish I knew everything I said that night but I will have sit with that one\. Price I pay\. Please don’t question yourself\.


**382.** `22:40` **You**

It's fine\.\. I will just sleep it off\.\. stuck in my head for the moment\.\. but it will likely get relegated to the back with the rest of the shit I remember\.\. as long as I don't think about it it is fine\.


**383.** `22:42` **Meredith Lamb (+14169386001)**

Gah\. I’m sorry\. I fucked that night up royally\.


**384.** `22:42` **Meredith Lamb (+14169386001)**

I will be in a better place soon\.


**385.** `22:43` **You**

>
No you didn't I think you just wanted to share\.\. I just wasn't sure why\.\. again it doesn't matter\.\. I don't feel like you are in a bad place\.\. I just try to piece together all of the stuff I hear\.\. and it is confusing\.\. that's all\.

*💬 Reply*

**386.** `22:44` **You**

KK I think I am going to call\.\. it\.\. should probably go to bed now\.


**387.** `22:47` **Meredith Lamb (+14169386001)**

Same\. So tired\.
\(And for the record, yes, 100% I am in a bad place\. Managing the best I can though in the way I tend to\. Definitely not the best\.\)


**388.** `22:47` **Meredith Lamb (+14169386001)**

Sleep well ❤️ I love you and really am sorry


**389.** `22:48` **You**

NIte\.\. I love you too ❤️\.  Get some sleep\.\. work will come fast\.


