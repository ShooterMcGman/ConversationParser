# Daily Conversation: 2025-05-19 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-19 |
| **Day** | Monday |
| **Week** | 6 |
| **Messages** | 132 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-19T17:50 - 2025-05-19T23:30 |

## 📝 Daily Summary

This day contains **132 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `17:50` **Meredith Lamb (+14169386001)**

Just leaving for home now ❤️


**002.** `18:31` **You**

I just got home now\.\. talked the whole way had some interesting conversations will share later\.\. if you have any energy and don’t fall straight to sleep\.


**003.** `18:31` **You**

I hope I didn’t leave yku with too much to do…


**004.** `18:33` **You**

Love you too btw had the best time with you\.\. all of it\.\. I hope there are many more years of that in front of us\.


**005.** `18:33` **You**

❤️


**006.** `21:10` **Meredith Lamb (+14169386001)**

Home and waiting for bo’s parents and talking to my parents\.


**007.** `21:35` **You**

glad you got home ok\.\. just puttering around here\.


**008.** `21:53` **Meredith Lamb (+14169386001)**

So who did you talk to?


**009.** `21:54` **You**

Straight to it eh\.\.


**010.** `21:54` **Meredith Lamb (+14169386001)**

lol


**011.** `21:54` **Meredith Lamb (+14169386001)**

Just sat down


**012.** `21:54` **Meredith Lamb (+14169386001)**

Watching Conan OBrien Must Go


**013.** `21:56` **You**

I am just doing a bit of research\.\. got my shit all good to go for tomorrow morning\.


**014.** `21:56` **You**

trying to plan my day tomorrow\.\. and then the rest of the week\.


**015.** `22:07` **You**

I spoke with Katie, Michael, And Deborah\.


**016.** `22:09` **You**

Katie and I spoke for a while\.\. she asked a lot of questions, liked the answers\.\. and was genuinely happy for me\.  She is not a fan of Jaimie, and never really was, always thought a bad match\.  She was curious as to what next\.\. I advised we are all just trying to figure that out\.\. but first and foremost we have to get our own shit out of the way\.  She creeped you on my facebook friends, and gave a thumbs up\.


**017.** `22:10` **You**

Mike and I chatted for about 15\-20 minutes\.\. he just wanted to catch up\.\. was curious how the weekend, went, was happy for me\.\. we talked about my potential living situation options that I should consider for later on this year, and depending on what I want to do in the long term\.


**018.** `22:11` **You**

Deborah spoke for about 1\.5 hours\.\. Deb is Mikes mom\.\. and is as close to a second mom as I have\.  She knows me almost as well as Shawnee and her and I were really close all through my teenage years, up until I essentially married Jaimie\.\. again she did not approve\.


**019.** `22:13` **You**

Deb had a lot to say about my situation\.\. we went into a lot of detail about my relationship at home, how it got to where it got to, our history, how we got to where we got to, she also creeped you lol\.\. says you are beautiful, and can tell your personality from your smile lines\.  She says if I described you accurately, she is not surprised I connected with you the way I did\.  However\.


**020.** `22:16` **You**

She is very worried\.\. we talked a lot about pre 17 year old me and post\.\. again she knew everything about me back then\.\. She says she remembers the change in me and what triggered it, and remembers how hurt I was prior to making that change\.  She said she was happy for me at the time, because I had had some really bad luck, and I got hurt pretty horribly\.\. she felt that I was better off protecting myself for a while\.  When she heard me talking to her tonight\.\. and sharing with her what we had talked about\.\. she is worried I am going to get hurt again\.  I told her she had nothing to worry about\.\. she said I was being naive, and needed to be more careful\.  I asked her if she believed in soul mates, and she said she did\.\. I said this is mine\.


**021.** `22:19` **You**

We talked for a while longer\.\. she is still worried\.\. she said everyone has history and stories, and other lives they have lived previously\.\. she said everything is much more complicated than I am trying to make it seem\.  For instance\.\. following the death of Ian, instead of moving forward with someone new, who she was beginning to get involved with, she reconnected with a high school sweetheart and lived with him for about 10 years\.\. before he passed\.  Neither death was attributed to her\.\. and she felt that was a mistake looking back but people tend to go to what is familiar she said\.  Anyways, I am sure she is just really concerned for me, she remembers what I was like, so I get it\.  But I told her we were fine, we were plotting through this, and as time progressed I felt more comfortable and less concerned about getting hurt\.  Anyways deep conversations\.\. kept me busy pretty much the entire drive\.


**022.** `22:20` **You**

KK I am done typing lol you either went to sleep or got busy\.\. I will wait until you read before getting into anything else\.


**023.** `22:20` **You**

If I don't hear back from you in 10 mins though, going to go to bed\.\. don't want to be up too late\.


**024.** `22:23` **Meredith Lamb (+14169386001)**

Sorry was cleaning kitchen and got distracted


**025.** `22:25` **You**

All good\.\. just didn’t want you to come back and wonder where I went\.


**026.** `22:27` **Meredith Lamb (+14169386001)**

Wow that was a lot of conversations


**027.** `22:27` **Meredith Lamb (+14169386001)**

Holy


**028.** `22:27` **You**

Reaction: ❤️ from Meredith Lamb
Well you like details


**029.** `22:27` **Meredith Lamb (+14169386001)**

I feel like I should check what ppl can see on my Facebook\. A few years ago I deleted a lot so I don’t have much to ppl that aren’t friends


**030.** `22:27` **Meredith Lamb (+14169386001)**

\(I don’t think\)


**031.** `22:28` **You**

I don’t think there is anything there to be concerned with


**032.** `22:28` **Meredith Lamb (+14169386001)**

I’m not understanding the familiar thing


**033.** `22:28` **You**

Hrmmm what familiar thing


**034.** `22:29` **You**

There was a lot there lol you will need to be specific


**035.** `22:29` **Meredith Lamb (+14169386001)**

Deborah said she went with what was familiar and regrets it


**036.** `22:29` **Meredith Lamb (+14169386001)**

Was she warning you of that?


**037.** `22:30` **Meredith Lamb (+14169386001)**

Everyone is like REBOUND


**038.** `22:30` **Meredith Lamb (+14169386001)**

lol


**039.** `22:31` **You**

Yes she said many people tend to look back at what was comforting prior to the last
Relationship to reconnect with something that was happier\.\. that was how her and Chet connected\.  I cannot Remeber who she was seeing when Chet came back on the scene\.  But he was gone pretty quick lol


**040.** `22:32` **You**

>
Not sure what you meant here

*💬 Reply*

**041.** `22:32` **Meredith Lamb (+14169386001)**

I feel like she was warning you of rebounding


**042.** `22:32` **You**

No


**043.** `22:32` **Meredith Lamb (+14169386001)**

Just different words


**044.** `22:32` **You**

Rebounding is jumping in too fast she warned me of that too but I rebuffed her there this is different


**045.** `22:33` **You**

This is about getting in too fast people having second thoughts which is what she did\.\. admittedly regretting it also lol


**046.** `22:34` **Meredith Lamb (+14169386001)**

>
What did you say to this? Curious

*💬 Reply*

**047.** `22:34` **You**

That is the looking back piece she meant I think\. Anyways\.\. she just worries about me is all\.


**048.** `22:35` **You**

She asked me about what I knew of you previous\.\. I said you had been pretty open and to some degree had a similarly adventurous time for a number of years\.\. which we agreed so did I even though it was a bit different and a bit younger than you\.


**049.** `22:36` **You**

She did not ask if I thought you would do what she did\.\. she just warned me to be careful and maybe not to be so open\.\. which again I said I wasn’t sure I could do that\.\. I feel what I feel and I am where I am\.  And honestly I don’t want to change it even if I do get hurt\.


**050.** `22:37` **You**

She just thinks that usually after a big split people can do crazy things\.\. she has seen it happen\. And sometimes others get hurt\.\. it didn’t really phase me tbh\.


**051.** `22:38` **Meredith Lamb (+14169386001)**

Interesting\. Yeah it doesn’t phase me either\. Our situation feels different because we have gotten to know each other slowly over 3 years\.


**052.** `22:38` **You**

I did tell her you might be feeling same way as me\.


**053.** `22:38` **Meredith Lamb (+14169386001)**

I might be? Lol


**054.** `22:39` **Meredith Lamb (+14169386001)**

You’re a good


**055.** `22:39` **Meredith Lamb (+14169386001)**

Goof


**056.** `22:39` **You**

I meant insecure and worried


**057.** `22:39` **Meredith Lamb (+14169386001)**

Ah yeah


**058.** `22:40` **You**

And I did tell here that was a huge difference that we are friends\.\. and that having that as a base is a big deal\.


**059.** `22:41` **You**

Anyways she loves me, and is just worried\.\. she had was saw everything close
Up for years and years\.  She wasn’t overly happy when I changed


**060.** `22:41` **Meredith Lamb (+14169386001)**

Is your sister worried?


**061.** `22:43` **You**

Umm


**062.** `22:44` **You**

She is happy for me but yeah
Worried\.


**063.** `22:44` **Meredith Lamb (+14169386001)**

Worried specifically about you getting hurt?


**064.** `22:44` **You**

I mean don’t take it personally lol


**065.** `22:44` **You**

Yeah


**066.** `22:44` **Meredith Lamb (+14169386001)**

lol wow


**067.** `22:45` **Meredith Lamb (+14169386001)**

No one is worried about me in that specific way lol


**068.** `22:45` **Meredith Lamb (+14169386001)**

What’s that say?


**069.** `22:45` **You**

Mer they had a front row seat to me getting run over three times I\. A row


**070.** `22:45` **You**

Before I shut down


**071.** `22:45` **Meredith Lamb (+14169386001)**

Okay makes sense then


**072.** `22:45` **Meredith Lamb (+14169386001)**

I will not run you over


**073.** `22:45` **Meredith Lamb (+14169386001)**

😜


**074.** `22:46` **You**

Mer I don’t think you would ever do anything intentionally to hurt me but I’ve is very complicated and you have priorities\.  You might feel like there is a better choice given your circumstances, I couldn’t hold
It against you if you were doing the best you could for you and the kids\.


**075.** `22:47` **You**

I am not worried\.\. I am just being honest\.


**076.** `22:47` **You**

Not whining either


**077.** `22:48` **You**

Just sighing


**078.** `22:48` **Meredith Lamb (+14169386001)**

Listen, a person can have multiple priorities in life and you have become one of mine\.


**079.** `22:49` **Meredith Lamb (+14169386001)**

So just understand that


**080.** `22:50` **You**

No I appreciate it\.\. you are def in my priority list\.  Look if this whole conversation thing bothers you… please just reference the one thing that mattered that I said to deb\.


**081.** `22:51` **Meredith Lamb (+14169386001)**

It doesn’t bother me at all\. I’m glad you have people that care about your well being\.


**082.** `22:54` **You**

She was impressed
When I described your choices
For your children, how you behaved how in many ways you were like Shawnee\.  She
Said that always bothered her about j and I because she was nothing like that\.\. Katie said same thing\.\. so I think she is cautiously hopeful for us\.


**083.** `22:55` **You**

>
I am not sure we had similar experiences\.\. maybe we did and you just
Dealt better\.

*💬 Reply*

**084.** `22:58` **Meredith Lamb (+14169386001)**

I don’t think we did in that area\.


**085.** `22:58` **Meredith Lamb (+14169386001)**

I’m glad there is cautious hope\. Better than no hope I guess\! Lol


**086.** `22:59` **You**

I didn’t say I had no hope\.\. they are just worried about me and they don’t know you\. I have lots of hope\.\.


**087.** `23:03` **Meredith Lamb (+14169386001)**

They won’t spill the beans I assume\.


**088.** `23:03` **You**

No


**089.** `23:04` **You**

None of them really like Jaimie anyways\.  But regardless they wouldn’t


**090.** `23:04` **Meredith Lamb (+14169386001)**

Does Jaimie know this?


**091.** `23:05` **You**

No


**092.** `23:05` **You**

Katie knows her best and was most vocal


**093.** `23:05` **Meredith Lamb (+14169386001)**

Has no idea they thought bad match?


**094.** `23:06` **You**

I mean they didn’t push on me hard but mum and Katie did ask if I was sure when we got back togethrr


**095.** `23:06` **You**

They thought the reason I made the decision in the first place hadn’t changed


**096.** `23:06` **You**

They were right


**097.** `23:07` **Meredith Lamb (+14169386001)**

And now, greener pastures 😍


**098.** `23:07` **You**

lol


**099.** `23:07` **You**

Greener pastures interesting way to put it\.\.


**100.** `23:07` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Country bumpkin


**101.** `23:08` **You**

Hardly


**102.** `23:08` **Meredith Lamb (+14169386001)**

lol


**103.** `23:09` **Meredith Lamb (+14169386001)**

Bed time?


**104.** `23:10` **You**

Unless
You want to keep
Talking otherwise sure I am not that tired but could do whatever\.


**105.** `23:11` **Meredith Lamb (+14169386001)**

I’m sooooooooooooo exhausted\.


**106.** `23:11` **You**

I mean curious \- did you watch the rest of fallout\.\. did you and Andrew trade any more fun chatter\.


**107.** `23:11` **Meredith Lamb (+14169386001)**

I finished fallout yes


**108.** `23:11` **You**

Kk then go to bed


**109.** `23:11` **Meredith Lamb (+14169386001)**

I have not spoken with Andrew no


**110.** `23:12` **Meredith Lamb (+14169386001)**

I got this on my drive home\. Weird

*📎 1 attachment(s)*

**111.** `23:13` **Meredith Lamb (+14169386001)**

How was it for you and the fam tonight?


**112.** `23:13` **You**

Maybe he is giving her a hard time about the money\.


**113.** `23:13` **Meredith Lamb (+14169386001)**

My house is lovely\. Only Maelle and I


**114.** `23:14` **You**

Mm it was meh I came home mowed the lawn cause I one else did\. Then I cleaned up a bunch of shit made my supper ate\.


**115.** `23:14` **Meredith Lamb (+14169386001)**

>
Maybe\. Not sure\. Think he is just in a bad mood generally\.

*💬 Reply*

**116.** `23:14` **You**

Prepped for tomorrow


**117.** `23:14` **You**

We tried to talk to Gracie about Crandall university in Moncton she was having nine of it\.


**118.** `23:15` **Meredith Lamb (+14169386001)**

That’s too bad


**119.** `23:15` **You**

Still wants to go tonight radio tech\.\. I think that is straight ticket to fail\.\. I doubt she makes it through the semester


**120.** `23:15` **You**

Yeah it sucks\.


**121.** `23:15` **You**

Well I am glad
You have a good week ahead of you and when he gets back you can just go back out to the cottage lol\.


**122.** `23:16` **Meredith Lamb (+14169386001)**

Seems like I may be ordered to\. We will see\. I didn’t make beds or the bra long but there is still time\.


**123.** `23:17` **Meredith Lamb (+14169386001)**

I told my parents I am unsure about keeping cottage\. Andrew and I will have to talk about it again


**124.** `23:18` **You**

Are you unsure because of finances?


**125.** `23:18` **You**

Or the ongoing\. Connection


**126.** `23:18` **Meredith Lamb (+14169386001)**

So many things\. All of the above\.


**127.** `23:19` **You**

Sorry to hear that
You are in\. Tough situation and I don’t think he is trying to make it any easier on you\.


**128.** `23:28` **You**

Alright honey go to bed \- I love
You\.\. I know you are tired\.\. and the last few nights… well as super fun as they were, and I would def go again tonight given the opportunity\.\. you need to sleep\.


**129.** `23:28` **You**

❤️❤️❤️❤️❤️


**130.** `23:30` **Meredith Lamb (+14169386001)**

Yeah I am super exhausted and I also had super fun\. Best weekend in a long time even if I feel kind of irresponsible for getting so wasted\. Lol I am going to sleep now\. Xoxox


**131.** `23:30` **Meredith Lamb (+14169386001)**

See you tomorrow \- love you


**132.** `23:30` **You**

Same love
You too\.
See you at the office\.\. will be sure to wave lol\.


