# Daily Conversation: 2025-06-18 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-18 |
| **Day** | Wednesday |
| **Week** | 10 |
| **Messages** | 261 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-18T04:08 - 2025-06-18T21:38 |

## 📝 Daily Summary

This day contains **261 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:08` **You**

See now I have a face to wake up to\.\. well at least the pic\.\. not the real thing but a LOT better than nothing Eesh\.  😋


**002.** `04:10` **You**

Reaction: ❤️ from Meredith Lamb
I hope you had a good sleep love and that all that nonsense from yesterday just stays in yesterday\.  Regardless mediation comes tomorrow and as much as Andrew wants to just focus on numbers, context does in fact matter in some cases\.  Do not be afraid to hit hard\.\. you are not the person responding to those fucking unreasonable demands he was making anymore\.


**003.** `04:11` **You**

Sorry if I overstep\.\. cannot help but feel a bit protective right now\.\. I feel like you might be same way if our roles were reversed\.


**004.** `04:12` **You**

Reaction: 😂 from Meredith Lamb
Well it is a full body workout today\.\. I mean to easy for me to make an innuendo out of that right?  lol 😂\. I love you mer hope you have an uninterrupted workout this morning\. ❤️❤️❤️❤️❤️


**005.** `05:40` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
Probably :\) you aren’t overstepping

*💬 Reply*

**006.** `05:43` **You**

Looked at that pic while I went to sleep 🙂 thx\.


**007.** `05:46` **You**

Can’t help but wondering sometime what you will feel
Looking back at these texts… hope it is good thoughts\.\.


**008.** `05:47` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Scott, I wake up feeling lucky\. I’m all this craziness, I wake up feeling lucky\. So odd\! So yes, I always think good thoughts with anything related to you, us, moving forward, etc ❤️❤️ k gotta make coffee …\. Yawn


**009.** `05:51` **You**

Enjoy your coffee and your uninterrupted workout ☺️ chat later\.


**010.** `05:54` **You**

Reaction: 😂 from Meredith Lamb
https://open\.spotify\.com/track/5hWdgGVcfTeLPAiHM6EZG9?si=riPLJWONTaWXahLVgJOdww
Your workout song of the morning lol\.


**011.** `06:33` **Meredith Lamb (+14169386001)**

During my coffee I read another sex/split up up email from May 2010\. lol I’m addicted\. These are awful\. Done now\.


**012.** `06:34` **Meredith Lamb (+14169386001)**

The email is like “you have been complaining about this for a year now and I don’t think I can take much more\.\.” 15 years later…\.


**013.** `06:34` **You**

Kk now I need to see this is insane


**014.** `06:34` **You**

Like WTF


**015.** `06:34` **You**

Man


**016.** `06:35` **You**

Hey just saw my Morgan wallen buddy\!\!\!\!


**017.** `06:36` **You**

Was gonna take a pic and share but nope fuck that shit


**018.** `06:36` **Meredith Lamb (+14169386001)**

:\(


**019.** `06:36` **You**

Of him


**020.** `06:36` **You**

But I will if you want lol


**021.** `06:38` **You**

I will see if he is still here when I come down


**022.** `06:38` **You**

Or come out from sauna


**023.** `06:40` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**024.** `06:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**025.** `06:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**026.** `06:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**027.** `06:43` **Meredith Lamb (+14169386001)**

There are like 30 emails in this exchange so very long\. But it was always the same crap\. I talk about splitting and he convinces me not to\. Then it repeats over and over for 15 years


**028.** `06:46` **You**

I mean that shit is more intense than j and I for sure


**029.** `06:46` **You**

Like way more


**030.** `06:46` **You**

I wouldn’t even get in that discussion it was just no


**031.** `06:47` **You**

I think some day maybe you should time lock and archive a bunch of this shit


**032.** `06:48` **You**

I mean you talk about me going down rabbit holes this cannot be healthy mer


**033.** `06:48` **You**

Anyhow I just worry about you


**034.** `06:49` **Meredith Lamb (+14169386001)**

I’m going to stop\. I just find it kind of validating so that part feels healthyish\. lol


**035.** `06:51` **You**

Ok it just seems to me that you might be beating yourself up at the same time


**036.** `06:52` **Meredith Lamb (+14169386001)**

For not leaving? And being stupid? Uh, yeah\. It is quite something to read it all in print vs remembering back\.


**037.** `06:53` **You**

Yeah but it is going to make what you are dealing with much more difficult those thoughts are going to be too of kind for every discussion and you are going to explode


**038.** `06:55` **You**

Hard to read those\.\. they don’t affect me mind you\.  Just feel bad\.


**039.** `06:56` **You**

Not Morgan Wallen but it’s what you get\.

*📎 1 attachment(s)*

**040.** `06:56` **Meredith Lamb (+14169386001)**

>
Is it the weekend yet? 😋

*💬 Reply*

**041.** `07:00` **You**

Nope not yet… sigh 3 days ffs


**042.** `07:00` **You**

At least j flies out tomorrow\.


**043.** `07:01` **You**

Maddie will be done exams tomorrow and then on sat she will begin her online driving courses so she will be busy Saturday not sure what Gracie will do\.\. not bother me for sure


**044.** `07:09` **Meredith Lamb (+14169386001)**

Phew Andrew left for work so he isn’t wfh today thank god


**045.** `07:34` **You**

Good must feel like you are trapped there maybe after meeting with the mediator you can get a sense of at least what the low end of support looks like\.\. then go get yourself a place\.\.


**046.** `07:47` **Meredith Lamb (+14169386001)**

So just finished\. Wednesdays are lower\. My least favourite but I did it all\. 1 hr sigh


**047.** `07:47` **Meredith Lamb (+14169386001)**

My muscle memory and form isn’t back yet\. Still working on it


**048.** `07:47` **You**

Oh it will remember lol


**049.** `07:48` **Meredith Lamb (+14169386001)**

Need stronger back and shoulders … that is thurs/fri :\)

*📎 1 attachment(s)*

**050.** `07:48` **You**

Tomorrow when it all hurts


**051.** `07:48` **You**

As your puppy cheers you in


**052.** `07:48` **You**

On


**053.** `07:48` **You**

>
❤️

*💬 Reply*

**054.** `07:49` **Meredith Lamb (+14169386001)**

She’s so funny\. Watches me the whole time\. Hardly sleeps


**055.** `07:49` **You**

My issue atm is grip strength and nick won’t let me use straps\.\. only way to get stronger\.\. but I can lift more than my grip can handle so awkward\.


**056.** `07:50` **Meredith Lamb (+14169386001)**

Hmm interesting


**057.** `07:50` **You**

Are those your special new pants?


**058.** `07:50` **Meredith Lamb (+14169386001)**

Haven’t heard of that issue


**059.** `07:50` **Meredith Lamb (+14169386001)**

Maybe it means you are lifting too heavy


**060.** `07:50` **Meredith Lamb (+14169386001)**

lol


**061.** `07:50` **You**

Reaction: 😮 from Meredith Lamb
Well I am deadlifting 225 lbs 30 times 3 sets of 10


**062.** `07:50` **You**

So grip can be a little ehhh


**063.** `07:50` **Meredith Lamb (+14169386001)**

Good lord


**064.** `07:51` **You**

Or like a farmers Cary 2 70
Lb dumbbells for a minute


**065.** `07:51` **You**

I mean it will get there


**066.** `07:51` **Meredith Lamb (+14169386001)**

>
Yeah they aren’t hot\. Our house is so hot bc a/c not working right

*💬 Reply*

**067.** `07:51` **You**

That sucks


**068.** `07:51` **You**

Ick


**069.** `07:51` **You**

Today is going to be bad too


**070.** `07:52` **Meredith Lamb (+14169386001)**

I gotta girls up and shower etc


**071.** `07:53` **You**

Kk have fun chat later


**072.** `09:44` **You**

At docs now going to talk about snippy snip\.


**073.** `09:44` **You**

Among other things\.


**074.** `09:53` **Meredith Lamb (+14169386001)**

Oh boy


**075.** `09:53` **You**

Yeah I know exciting


**076.** `09:54` **You**

I can tell you are excited too\.\. or conflicted not sure which lol


**077.** `09:54` **Meredith Lamb (+14169386001)**

Mac wants me to do this:

*📎 1 attachment(s)*

**078.** `09:55` **You**

lol


**079.** `09:55` **Meredith Lamb (+14169386001)**

>
Not sure\. I just feel like you are jumping\. I got an email from my dr about birth control but haven’t had mental energy to process

*💬 Reply*

**080.** `09:57` **You**

Jumping?? I will never have another child the only way I would have would have been with you… but impossible for so many reasons\.  So I do t care about that\.\. I wanted to get it done anyways years ago\.\. so this isn’t me just being impatient\.


**081.** `10:10` **You**

Reaction: 😂 from Meredith Lamb

*📎 1 attachment(s)*

**082.** `10:12` **You**

I can do better


**083.** `10:12` **You**

Bored waiting for doctor


**084.** `10:16` **You**


*📎 1 attachment(s)*

**085.** `10:18` **Meredith Lamb (+14169386001)**

Much more accurate


**086.** `10:40` **You**

All done heading to healthy planet Costco then maddie then home then therapy


**087.** `10:40` **You**

Got a referral


**088.** `10:42` **Meredith Lamb (+14169386001)**

Wow busy day


**089.** `10:53` **You**

Well somewhat


**090.** `11:17` **You**

How is your day


**091.** `11:19` **Meredith Lamb (+14169386001)**

Busy\. Laundry cleaning house\. Trying not to work too hard on work work lol going to start officially Monday


**092.** `11:20` **You**

lol


**093.** `11:20` **You**

Officially


**094.** `11:20` **Meredith Lamb (+14169386001)**

Erin knows I have the big “showdown” \(as she put it” tomorrow


**095.** `11:20` **Meredith Lamb (+14169386001)**

Slacking off for now


**096.** `11:20` **Meredith Lamb (+14169386001)**

Catching up on shit


**097.** `11:20` **You**

Yep get your kind rights


**098.** `11:20` **You**

Mind


**099.** `11:20` **Meredith Lamb (+14169386001)**

Not doing Andrew’s laundry


**100.** `11:21` **You**

Shouldn’t have to


**101.** `11:21` **Meredith Lamb (+14169386001)**

I’m very much 100% done after the other day


**102.** `11:21` **Meredith Lamb (+14169386001)**

Oh yesterday


**103.** `11:21` **Meredith Lamb (+14169386001)**

Feels longer lol


**104.** `11:21` **You**

Yeah yesterday


**105.** `11:22` **Meredith Lamb (+14169386001)**

I will be civil but I’m no longer being nice


**106.** `11:22` **You**

Yah know if I had have acted like that Jaimie would have divorced me I think


**107.** `11:22` **You**

I did other shit but not like that


**108.** `11:23` **You**

You have every right to say fuck it done


**109.** `11:23` **Meredith Lamb (+14169386001)**

I’m honestly not sure why I didn’t


**110.** `11:23` **Meredith Lamb (+14169386001)**

Kids


**111.** `11:23` **Meredith Lamb (+14169386001)**

Constant convincing not to


**112.** `11:23` **Meredith Lamb (+14169386001)**

If he would have agreed to it we would have split up long ago


**113.** `11:23` **Meredith Lamb (+14169386001)**

Mac said he cried on her on Sunday


**114.** `11:23` **Meredith Lamb (+14169386001)**

But about Marlowe


**115.** `11:24` **Meredith Lamb (+14169386001)**

Not Mac


**116.** `11:24` **Meredith Lamb (+14169386001)**

He was all “Maelle’s is going to be at camp this summer so you have to be there more for Marlowe”


**117.** `11:24` **You**

Man a lot of tears


**118.** `11:24` **Meredith Lamb (+14169386001)**

He is


**119.** `11:25` **Meredith Lamb (+14169386001)**

I am definitely feeling anxious about tomorrow tho


**120.** `11:25` **Meredith Lamb (+14169386001)**

Long time to wait 24 hrs


**121.** `11:25` **Meredith Lamb (+14169386001)**

:p


**122.** `11:25` **You**

Suggest bit reading any more past


**123.** `11:25` **You**

Unless it is financially related


**124.** `11:25` **You**

You will just work yourself up further


**125.** `11:26` **You**

You want him to be the one to get emotional and aggravated


**126.** `11:26` **You**

You be calm and dispassionate


**127.** `11:26` **Meredith Lamb (+14169386001)**

I’m not going to read anymore


**128.** `11:27` **You**

It will drive him nuts if you just state facts and nothing else


**129.** `11:28` **You**

And you need to be prepared to use lost wages advancement and pension


**130.** `11:28` **You**

Imho


**131.** `11:28` **You**

Not saying have to prepared to


**132.** `11:30` **Meredith Lamb (+14169386001)**

Yeah ugh


**133.** `11:31` **You**

During this time Andrew was able to complete one post secondary defree that I knew of while I took on all the duties around house and kids etc setting aside my job my pension and career advancement as well as my cpp contributions\. Oh and another post secondary defree that I wasn’t even aware of\.


**134.** `11:31` **You**

Stated matter of facty\. And let him react


**135.** `11:32` **Meredith Lamb (+14169386001)**

He did the second while I was at Enbridge\. Not sure when he started tho


**136.** `11:32` **You**

Probably had to start
Before


**137.** `11:32` **You**

But who knows


**138.** `11:32` **You**

That is kind of telling in and of itself


**139.** `11:32` **You**

Curious was it a fight when you wanted to go back to work or just that you went to Enbridge


**140.** `11:33` **Meredith Lamb (+14169386001)**

Just that I went to Enbridge\. He was fine with me going back to work as long as I still did everything\. We had big blow ups initially\. He didn’t pick up ANY slack initially


**141.** `11:33` **Meredith Lamb (+14169386001)**

Started doing more driving after


**142.** `11:34` **Meredith Lamb (+14169386001)**

Just believe when I say it has always been not great :p all 16 years


**143.** `11:34` **You**

Mmmm well I think you have lots and lots of ammo and leverage 2016 recent text all that goes before a judge if he fights\.\.


**144.** `11:35` **You**

I believe you you don’t need to convince me\.\. I am not threatened by your past with Andrew at least many aspects of it\.


**145.** `11:35` **You**

No convincing necessary lol


**146.** `11:35` **Meredith Lamb (+14169386001)**

Good :p


**147.** `11:50` **You**

You still want to meet my sister?


**148.** `11:51` **Meredith Lamb (+14169386001)**

Of course


**149.** `11:51` **You**

Would just be you and her


**150.** `12:04` **You**

Katie: 506\-850\-6001


**151.** `12:04` **You**

Friday afternoon any time\.


**152.** `12:05` **You**

she is very much looking forward to meeting you\.


**153.** `12:13` **Meredith Lamb (+14169386001)**

K so fri aft is a bit eek\. Viewing a condo, then Maelle’s graduation\. Also catching up with Anna at 1 and already rebooked her


**154.** `12:13` **You**

Reaction: 😡 from Meredith Lamb
kk\.\. I will tell her not interested :\) :P


**155.** `12:13` **Meredith Lamb (+14169386001)**

I didn’t put the condo in my calendar bc I’m just going


**156.** `12:14` **Meredith Lamb (+14169386001)**

I didn’t know you’d book without me\!


**157.** `12:14` **Meredith Lamb (+14169386001)**

Andrew


**158.** `12:14` **Meredith Lamb (+14169386001)**

:p


**159.** `12:14` **Meredith Lamb (+14169386001)**

\(Sorry\)


**160.** `12:14` **You**

I didn't book


**161.** `12:14` **Meredith Lamb (+14169386001)**

Well basically


**162.** `12:14` **You**

that is when she is available if you cannot it isn't a big deal


**163.** `12:14` **You**

LOL


**164.** `12:14` **You**

I didn't commit you nut


**165.** `12:14` **You**

\#not\-andrew


**166.** `12:14` **Meredith Lamb (+14169386001)**

lol


**167.** `12:14` **You**

\#bite me


**168.** `12:14` **Meredith Lamb (+14169386001)**

Haha


**169.** `12:16` **Meredith Lamb (+14169386001)**

1\-2 Anna, 2\-2\.30 travel to condo and wait, 2\.30\-3\.30 tour? 3\.30\-4, go home, get home and go to Maelle’s grad


**170.** `12:16` **You**

hey I am not judging


**171.** `12:16` **Meredith Lamb (+14169386001)**

I have to walk to condo bc not sure where I can park


**172.** `12:17` **You**

I was just presenting an opportunity\.\.\. now I suggest you text her and you two can organize it\.


**173.** `12:18` **Meredith Lamb (+14169386001)**

Okay


**174.** `12:18` **Meredith Lamb (+14169386001)**

She’s not apprehensive like my mom was?


**175.** `12:18` **You**

no


**176.** `12:18` **You**

sec therapist


**177.** `12:22` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
k going to appt also 💉lol


**178.** `12:56` **You**

Reaction: 😂 from Meredith Lamb
ooh he had lots to say about you today\.\. chat later\.


**179.** `12:56` **You**

gotta go get maddie\.


**180.** `13:03` **Meredith Lamb (+14169386001)**

You are such a tease


**181.** `13:10` **You**

lol


**182.** `13:11` **Meredith Lamb (+14169386001)**

My blood pressure is 118/75\. I should check it after mediation tomorrow\. :p


**183.** `13:21` **You**

That is amazing


**184.** `13:21` **You**

Holy shit


**185.** `13:22` **Meredith Lamb (+14169386001)**

It’s actually a tad high for me lol


**186.** `13:36` **You**

Mine was 130 over 76


**187.** `13:36` **You**

Reaction: 🙂 from Meredith Lamb
doc was happy


**188.** `13:49` **You**

screening your calls\.\. nice\!\!\! lol :P


**189.** `14:09` **You**

>
this one\.'

*💬 Reply*

**190.** `16:43` **Meredith Lamb (+14169386001)**

Daughter \#2 entering the glasses world today 😐


**191.** `17:30` **You**

lol you love the glasses world


**192.** `17:30` **You**

We are hot


**193.** `17:41` **Meredith Lamb (+14169386001)**

I know it is just $


**194.** `17:41` **Meredith Lamb (+14169386001)**

lol


**195.** `17:41` **You**

benefits


**196.** `17:41` **Meredith Lamb (+14169386001)**

She only needs it for distance\. Small need at this point


**197.** `17:42` **You**

that's me


**198.** `17:43` **You**

both you benefits and andrews should leave you with zero cost


**199.** `17:43` **You**

btw I think Erin is pissed at me lol


**200.** `17:44` **You**

I asked her something about the rollover \- she told me\.\. then said appreciate it and congrats on the work done well\.\. and radio silence\.\. lol\.


**201.** `17:44` **Meredith Lamb (+14169386001)**

lol doubt it


**202.** `17:44` **Meredith Lamb (+14169386001)**

Vet time


**203.** `17:44` **You**

have fun\.\. but I am right


**204.** `17:54` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 18 Jun 2025 17:55:07 \-0400
|
| Over the ai stuff?
|
| Version: 1
| Sent: Wed, 18 Jun 2025 17:54:54 \-0400
|
| Over the so stuff?


**205.** `17:55` **You**

Probably\.\. unless she is green and somehow away from computer\.\. or just ignoring me\.\. lol


**206.** `17:55` **You**

I messaged her again on something else\.\. just to see\.\. no response\.\. so who knows\.


**207.** `17:56` **You**

it's fine you cannot investigate it would be suspicious\.


**208.** `18:01` **Meredith Lamb (+14169386001)**

I’m at vet anyway


**209.** `18:01` **Meredith Lamb (+14169386001)**

Griffin is 100\.9 lbs


**210.** `18:01` **Meredith Lamb (+14169386001)**

😬


**211.** `18:02` **You**

eesh big boy\!\!


**212.** `18:02` **You**

what is optimal weight


**213.** `18:04` **Meredith Lamb (+14169386001)**

Not sure


**214.** `18:04` **Meredith Lamb (+14169386001)**

He’s just getting blood drawn for heart worm\. Not a real appt but they always weigh


**215.** `18:04` **Meredith Lamb (+14169386001)**

My head is splitting\. Like crazy stress head ache all afternoon and tylonol not working\. Think it is tomorrow related


**216.** `18:05` **You**

probably\.\. you should skip workout\.\.


**217.** `18:05` **You**

have a gummy


**218.** `18:05` **You**

sleep in


**219.** `18:05` **Meredith Lamb (+14169386001)**

No that wouldn’t be smart I don’t think


**220.** `18:06` **You**

ok go to bed early?


**221.** `18:06` **Meredith Lamb (+14169386001)**

Just going to take an aleve after this appt and lie in bed and maybe try The Survivors\. Jim said it is good


**222.** `18:06` **You**

kk sounds like a plan


**223.** `18:06` **Meredith Lamb (+14169386001)**

You clean? Or just work?


**224.** `18:07` **You**

I cleaned a bit upstairs got in a fight with Gracie\.\. J came home\.\. ordered swiss chalet\.\. and came back downstairs to eat


**225.** `18:08` **Meredith Lamb (+14169386001)**

Is it going to be weird when you don’t have to fight everyday?


**226.** `18:08` **You**

blessing


**227.** `18:11` **You**

I mean I don't need to ask you\.\. how will you feel not to have to worry about when Andrew is going to walk in every day\.


**228.** `18:13` **Meredith Lamb (+14169386001)**

Very much free


**229.** `18:15` **You**

same\.\. then maybe you will want to go sow your oats\.\.


**230.** `18:15` **You**

or whatever it is for girls\.


**231.** `18:15` **You**

Reaction: 😂 from Meredith Lamb
“Scatter her wildflowers”
– Keeps the agricultural image but uses a more delicate, floral metaphor\. Conjures freedom and growth\.
“Spread her wings”
– A classic for anyone testing their independence, with an avian twist that signals flight and exploration\.
“Chase her butterflies”
– Suggests pursuing fleeting joys and experiences—playful and instantly visual\.
“Paint the town petals”
– A spin on “paint the town red,” swapping in flowers for a distinctly feminine flourish\.


**232.** `18:15` **Meredith Lamb (+14169386001)**

We are doing that together :\)


**233.** `18:15` **You**

gpt suggest the following


**234.** `18:16` **You**

LOL


**235.** `18:17` **You**

omg\.\. gpt is so bad\.\. lol


**236.** `18:18` **You**

Deleted that query\.\. if you ever want to have fun\.\. ask it any question\.\. then ask it for a nsfw version\.\. holy shit\.\. rofl


**237.** `18:19` **Meredith Lamb (+14169386001)**

lol


**238.** `18:19` **You**

lol anyways\.\. deleted and buried omg literally almost choked and laughed at same time


**239.** `18:26` **You**

maybe she actually is green and away somehow\.\.


**240.** `18:31` **Meredith Lamb (+14169386001)**

I love how invested in this you are


**241.** `18:31` **Meredith Lamb (+14169386001)**

lol


**242.** `18:31` **You**

it bothers me\.\. I must be liked damnit\!\!\!


**243.** `18:32` **You**

no she has never done this\.\. must be an explanation\.\. like green and not there\.


**244.** `18:32` **Meredith Lamb (+14169386001)**

Well you are one of the few ppl that can’t see when ppl read your msgs


**245.** `18:32` **Meredith Lamb (+14169386001)**

There is a setting


**246.** `18:33` **You**

tell me the setting lol\!\!\! I will beb


**247.** `18:33` **You**

brb


**248.** `18:33` **Meredith Lamb (+14169386001)**

Erin told me a long time ago that you and I were the only ones that didn’t have that setting on


**249.** `18:37` **Meredith Lamb (+14169386001)**

So I put the setting on


**250.** `18:37` **Meredith Lamb (+14169386001)**

She showed me when I was working for her


**251.** `18:37` **Meredith Lamb (+14169386001)**

I’d have to look\. Can’t remember


**252.** `18:38` **Meredith Lamb (+14169386001)**

ChatGPT it lol


**253.** `18:38` **Meredith Lamb (+14169386001)**

Still at vet\. Taking forever


**254.** `21:00` **You**

Fighting since yku sent that


**255.** `21:05` **You**

3 hours straight fighting


**256.** `21:05` **You**

Omfg


**257.** `21:05` **You**

I am so fucking done…


**258.** `21:10` **You**

I hope you are resting or sleeping already and not fighting too\.


**259.** `21:10` **You**

We fought about you again I pretty much said you and I are going to happen that is all I can do atm


**260.** `21:38` **You**

Finally going to bed luv you sorry I missed you hope
You are sleeping and your headache is gone\.


**261.** `21:38` **You**

Xoxo ❤️❤️❤️


