# Daily Conversation: 2025-07-14 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-14 |
| **Day** | Monday |
| **Week** | 14 |
| **Messages** | 900 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-14T04:03 - 2025-07-14T23:03 |

## 📝 Daily Summary

This day contains **900 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:03` **You**

Morning Mer hope the rest of your night was peaceful\.  Xo


**002.** `05:04` **Meredith Lamb (+14169386001)**

Good morning \- my night was not\. I felt like a hypocritical liar all night but stayed in bed so I wouldn’t do anything I regretted\.


**003.** `05:04` **Meredith Lamb (+14169386001)**

But waking up feeling the same way


**004.** `05:44` **You**

Sorry Mer\.\. I feel really bad\.\. wish I could make it better


**005.** `05:44` **You**

Just working away here helps me to push everything aside


**006.** `05:44` **You**

Almost done though


**007.** `05:56` **You**

You must have went back to sleep\.\. will see you later at work perhaps\.\.


**008.** `05:58` **Meredith Lamb (+14169386001)**

Been talking to Andrew since 5


**009.** `05:58` **You**

Ahh fuck


**010.** `05:59` **You**

Ok\.\. well\.\.


**011.** `06:01` **You**

Fuck\.  Not much else to say\.


**012.** `06:07` **You**

Bout to hit sauna and shower guess we connect later


**013.** `06:10` **Meredith Lamb (+14169386001)**

Um we will have a lot to catch up on 😬


**014.** `06:56` **You**

Yeah I am guessing we won’t get to it at work\.\. so not sure when that is going to happen\.  Based on the way you sound none of it is good\.


**015.** `06:57` **You**

Sick feeling in my stomach\.\. awesome


**016.** `06:58` **You**

On a scale of 1 to we are over where is it\.


**017.** `07:00` **You**

You probably still talking to him\.\. I don’t even know if I want to know honestly\. I think you might have given me something after that last message\.\. but you don’t need to worry and go to th worst place because we are still good\.


**018.** `07:03` **Meredith Lamb (+14169386001)**

We talked about you for 2 hrs


**019.** `07:03` **Meredith Lamb (+14169386001)**

Sitting in my workout clothes


**020.** `07:03` **Meredith Lamb (+14169386001)**

Missed my workout


**021.** `07:03` **Meredith Lamb (+14169386001)**

I’m going to go get ready


**022.** `07:03` **Meredith Lamb (+14169386001)**

Do you want to meet at park?


**023.** `07:03` **Meredith Lamb (+14169386001)**

I can be out of here in 30 min


**024.** `07:03` **You**

I guess we need to talk\.\.but please answer my question


**025.** `07:03` **You**

Before I see you


**026.** `07:04` **Meredith Lamb (+14169386001)**

We are not even close to over


**027.** `07:04` **Meredith Lamb (+14169386001)**

Omg


**028.** `07:04` **Meredith Lamb (+14169386001)**

As if


**029.** `07:04` **You**

Uggh I want to throw up


**030.** `07:04` **You**

I will be at park before you


**031.** `07:04` **You**

2 hours ffs


**032.** `07:05` **Meredith Lamb (+14169386001)**

Yeah that was intense


**033.** `07:06` **Meredith Lamb (+14169386001)**

K I need to focus on getting ready


**034.** `07:06` **You**

Kk


**035.** `07:13` **You**

Read your note again\.\. feel a bit better


**036.** `07:13` **You**

We’ll see after park though


**037.** `09:45` **Meredith Lamb (+14169386001)**

Hm I’m feeling like a total idiot


**038.** `09:45` **Meredith Lamb (+14169386001)**

I scrolled back in my texts


**039.** `09:46` **Meredith Lamb (+14169386001)**

And the only evidence I can find of like pure separation talk is March 26 and beyond\.


**040.** `09:46` **Meredith Lamb (+14169386001)**

Argh\.


**041.** `09:46` **Meredith Lamb (+14169386001)**

So if he scrolls back, that’s it\.


**042.** `09:46` **You**

Hmm because you verbally told him


**043.** `09:47` **You**

And btw a verbal statement is valid in Ontario


**044.** `09:47` **You**

That’s all I had


**045.** `09:47` **Meredith Lamb (+14169386001)**

Well yeah but maybe I was wrong and it wasn’t end of Feb


**046.** `09:47` **You**

I never wrote it


**047.** `09:47` **Meredith Lamb (+14169386001)**

Maybe it was end of March


**048.** `09:48` **You**

I dunno I heard some stuff today that surprised me too\.\. you are trying to juggle to much and it is hard for you to keep it all straight


**049.** `09:48` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**050.** `09:48` **Meredith Lamb (+14169386001)**

What surprised you?


**051.** `09:48` **You**

Nothing doesn’t matter\.\. gotta get ready for a meeting\.


**052.** `09:49` **You**

Sorry you are going through this


**053.** `09:49` **You**

I will be here for whatever support I can give


**054.** `09:50` **You**

>
It was a detail\.\. truly doesn’t matter\.

*💬 Reply*

**055.** `09:50` **Meredith Lamb (+14169386001)**

Okay…


**056.** `09:52` **Meredith Lamb (+14169386001)**

Sounds like it matters but I will leave it


**057.** `09:53` **You**

I was surprised you were still sleeping with him in December,
When we had talked I think you said October\.\. but I thought might have been Nov\.  anyhow like I said it was a detail\.\. and you know me and details… stupid\.


**058.** `09:54` **You**

See doesn’t matter


**059.** `09:54` **Meredith Lamb (+14169386001)**

We actually weren’t\. He said something to that effect but it was  oct or nov\. We 100% did not in December\. I was too livid\. But his memory is bad so he said that but wasn’t true\.


**060.** `09:55` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 09:55:35 \-0400
|
| Ah ok my mistake\.
|
| Version: 1
| Sent: Mon, 14 Jul 2025 09:55:26 \-0400
|
| An ok my mistake\.


**061.** `09:56` **Meredith Lamb (+14169386001)**

And honestly the last time we did it was really difficult for me … it was after the text and he pretended like all was fine and I felt awful\. That was the last time\. I stood up for myself after that\.


**062.** `09:56` **You**

>
Yeah you mentioned that 😢

*💬 Reply*

**063.** `09:57` **Meredith Lamb (+14169386001)**

I honestly think that was like a week before thanksgiving so whenever that was


**064.** `09:58` **You**

Anyway verbal separation you separated in October


**065.** `09:58` **You**

Or maybe later but it was probably more like Feb


**066.** `09:58` **You**

Based on his def it was oct\.


**067.** `09:58` **Meredith Lamb (+14169386001)**

Yeah maybe\. Based on conversations it would be December most accurately\.


**068.** `09:59` **Meredith Lamb (+14169386001)**

Many days of heavy conversations in December\.


**069.** `10:00` **You**

Still really unfortunate situation for both of us\.\. not looking forward to the next little while\.


**070.** `10:00` **You**

I also don’t look forward to hearing about the next conversation with your mom


**071.** `10:00` **You**

You may want to put some pressure on the mediator to move this along


**072.** `10:05` **Meredith Lamb (+14169386001)**

Fri Dec 13th

*📎 1 attachment(s)*

**073.** `10:31` **You**

Well that’s something


**074.** `10:34` **You**

At least there is a record


**075.** `10:39` **Meredith Lamb (+14169386001)**

Ugh he’s getting angrier as the minutes pass\.\. will just have to let the dust settle


**076.** `10:39` **Meredith Lamb (+14169386001)**

>
Why?

*💬 Reply*

**077.** `10:40` **You**

Cause she will be mad\. Prolly at me


**078.** `10:40` **You**

>
What is happening now

*💬 Reply*

**079.** `10:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**080.** `10:42` **Meredith Lamb (+14169386001)**

He’s just going to start going through EVERYTHING now in his mind


**081.** `10:42` **Meredith Lamb (+14169386001)**

Probably going through his calendar or something


**082.** `10:42` **You**

Ffs


**083.** `10:43` **You**

I mean the coaching part is true


**084.** `10:43` **You**

But you did your own work


**085.** `10:44` **You**

You might have to push back really hard at some point but will leave it to you


**086.** `10:46` **Meredith Lamb (+14169386001)**

It’s fine\. He needed to know\.


**087.** `10:47` **You**

Ok but what is happening


**088.** `10:47` **You**

Pls share\.


**089.** `10:48` **You**

You would want to know lol


**090.** `10:48` **Meredith Lamb (+14169386001)**

Nothing right now\. He takes a lot of time between texts\.


**091.** `10:48` **Meredith Lamb (+14169386001)**

He is probably investigating, thinking etc


**092.** `10:48` **Meredith Lamb (+14169386001)**

Processing


**093.** `10:48` **Meredith Lamb (+14169386001)**

I mean, completely normal


**094.** `10:50` **Meredith Lamb (+14169386001)**

He’s probably looking you up online lol


**095.** `10:50` **Meredith Lamb (+14169386001)**

Kidding


**096.** `10:50` **You**

Not kidding


**097.** `10:50` **You**

He could cause problems for me


**098.** `10:51` **Meredith Lamb (+14169386001)**

Wait how?


**099.** `10:51` **You**

If he filed something with egd


**100.** `10:51` **You**

He could tell someone about us in a relationship when I was your boss


**101.** `10:52` **Meredith Lamb (+14169386001)**

Sigh


**102.** `10:52` **Meredith Lamb (+14169386001)**

I don’t think he would do that


**103.** `10:56` **You**

…\. Just please let me know how this progresses it will probably move the most over next few days


**104.** `11:48` **Meredith Lamb (+14169386001)**

Yeah he is just angry…\.


**105.** `11:48` **Meredith Lamb (+14169386001)**

“Sure\. I am sure you did not hang out with him or spend the night with him in the hotel\.” \(Wrt to Chatham trip…\.\)


**106.** `11:49` **You**

…\.\.


**107.** `11:50` **Meredith Lamb (+14169386001)**

Yah


**108.** `11:54` **You**

How long till you can move into your place\.\. I don’t see you getting peace at the house\.


**109.** `11:55` **Meredith Lamb (+14169386001)**

When I have wifi… Wednesday


**110.** `11:56` **You**

Kk\.\. man\.\. I am concerned he is going to want to open up mediation again\.


**111.** `11:57` **Meredith Lamb (+14169386001)**

I mean I have a lot of documentation to support me


**112.** `11:57` **Meredith Lamb (+14169386001)**

I hope he realizes that


**113.** `12:10` **You**

You have a lot more to support you in a lot of different ways\.\. but I dunno… is he vengeful or not?


**114.** `12:11` **Meredith Lamb (+14169386001)**

I mean we have never really had a situation like this\. It has always been him, not me lol so no idea honestly


**115.** `12:13` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**116.** `12:15` **You**

…\. I feel like this is so much my fault\.


**117.** `12:16` **You**

Like man I fucked everything up on all fronts all at the same time\.


**118.** `12:16` **Meredith Lamb (+14169386001)**

This is not your fault at all


**119.** `12:17` **You**

I pushed you to see me\.\. I pushed too much\.\. wasn’t patient


**120.** `12:17` **You**

I don’t have a half speed setting 😥


**121.** `12:18` **Meredith Lamb (+14169386001)**

I don’t either \- relax


**122.** `12:22` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**123.** `12:26` **Meredith Lamb (+14169386001)**

“Just like you never believed me on the Magali and text stuff, I will never believe your timeline\. Oh well\.”


**124.** `12:26` **Meredith Lamb (+14169386001)**

This will go on for a while I’m sure


**125.** `12:26` **Meredith Lamb (+14169386001)**

Then he will get over it


**126.** `12:26` **You**

I hope so and I hope it isn’t too much for you


**127.** `12:30` **You**

How many messages did you send to him at once looked like a lot\.


**128.** `12:40` **Meredith Lamb (+14169386001)**

It was a reminder of all of his initial lying that he stuck to for a couple months


**129.** `12:41` **You**

Sort of let ye who has not sinned cast the first stone


**130.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**131.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**132.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**133.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**134.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**135.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**136.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**137.** `12:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**138.** `12:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**139.** `12:42` **Meredith Lamb (+14169386001)**

That was our very initial text exchange on the matter


**140.** `12:42` **Meredith Lamb (+14169386001)**

It got way worse a couple months later as my brain was literally left to go insane\.


**141.** `12:44` **Meredith Lamb (+14169386001)**

>
Exactly\. He quickly forgets\.

*💬 Reply*

**142.** `12:44` **You**

😥


**143.** `12:44` **You**

I wish you didn’t have to go through that\.\.


**144.** `12:45` **You**

I feel like I am just as bad though\.


**145.** `12:45` **You**

I mean I was getting separated anyways it was timing


**146.** `12:45` **You**

But still


**147.** `12:46` **You**

I don’t degrade women…


**148.** `12:46` **You**

Opposite


**149.** `12:46` **You**

This is so fucked up


**150.** `12:50` **Meredith Lamb (+14169386001)**

His friends are idiots


**151.** `12:50` **Meredith Lamb (+14169386001)**

The main purpose of women is sex


**152.** `12:51` **Meredith Lamb (+14169386001)**

>
You are not just as bad but we both probably could have done this better\. Maybe\. I’m honestly not sure\. I feel like we really did the best we could\. We are not robots\.

*💬 Reply*

**153.** `12:52` **You**

Yeah part clings to the idea that we were kind of brought together\.\. and everything after that kind of went out of control\.


**154.** `12:53` **Meredith Lamb (+14169386001)**

Reaction: 😡 from Scott Hicks
If we are all 100% honest, the whole thing likely dials down to my fault\. Who tells their boss personal info like that unless they have an ulterior motive?


**155.** `12:54` **You**

No fucking way


**156.** `12:54` **You**

I don’t believe it


**157.** `12:54` **You**

And I don’t care


**158.** `12:54` **You**

I want to believe it would have happened eventually anyways


**159.** `12:55` **You**

Because I would have separated and I hope you would have followed through regardless


**160.** `12:55` **Meredith Lamb (+14169386001)**

None of that is really true though\. Let’s be honest\.


**161.** `12:56` **Meredith Lamb (+14169386001)**

You weren’t positioning it that way\.


**162.** `12:56` **You**

What do you mean?


**163.** `12:56` **Meredith Lamb (+14169386001)**

Until I basically called you endearing lol


**164.** `12:56` **You**

No no


**165.** `12:56` **Meredith Lamb (+14169386001)**

One word …


**166.** `12:56` **Meredith Lamb (+14169386001)**

lol


**167.** `12:56` **You**

No


**168.** `12:57` **You**

I was looking for the word\.\. doesn’t mean I wouldn’t have taken a risk on my own


**169.** `12:57` **You**

I was so on the edge


**170.** `12:57` **You**

Being your boss was a huge huge barrier


**171.** `12:57` **You**

And a massive risk


**172.** `12:57` **You**

If you didn’t feel same way


**173.** `12:57` **You**

And we were friends


**174.** `12:57` **You**

And that meant so much to me


**175.** `12:57` **You**

I didn’t want to lose it


**176.** `12:57` **Meredith Lamb (+14169386001)**

>
lol ya think?

*💬 Reply*

**177.** `12:58` **You**

I would have remained cautious


**178.** `12:58` **You**

But it would have happened


**179.** `12:58` **You**

Especially after we separated but I doubt even then I could have waited


**180.** `12:58` **You**

I would have had to say something


**181.** `12:58` **You**

Like compelled


**182.** `12:59` **Meredith Lamb (+14169386001)**

But I feel like I pushed it initially and probably shouldn’t have


**183.** `12:59` **Meredith Lamb (+14169386001)**

But it is done now\!


**184.** `12:59` **You**

Stop there was no machinations I was a friend you were hurting


**185.** `13:05` **Meredith Lamb (+14169386001)**

Yes but you were my boss… I overstepped\. Total facts\. But whatever\.


**186.** `13:06` **You**

If I was a woman would you have overstepped


**187.** `13:08` **Meredith Lamb (+14169386001)**

You are not a woman\.


**188.** `13:08` **Meredith Lamb (+14169386001)**

lol


**189.** `13:29` **You**

But if I was


**190.** `13:29` **You**

Then it wouldn’t have been inappropriate stop being sexist


**191.** `14:18` **Meredith Lamb (+14169386001)**

Just met with Mia


**192.** `14:19` **Meredith Lamb (+14169386001)**

It was ok


**193.** `14:19` **Meredith Lamb (+14169386001)**

We talked mostly about divorce


**194.** `14:19` **Meredith Lamb (+14169386001)**

lol


**195.** `14:20` **Meredith Lamb (+14169386001)**

It’s been 7 yrs and they aren’t divorced\. She has spent like $20\-30k she thinks


**196.** `14:20` **Meredith Lamb (+14169386001)**

He won’t agree on anything and hasn’t paid her


**197.** `14:20` **Meredith Lamb (+14169386001)**

I feel so bad for her


**198.** `14:40` **You**

Ouch


**199.** `14:40` **You**

wtf


**200.** `14:41` **Meredith Lamb (+14169386001)**

Yah\. Sucks\.


**201.** `14:56` **You**

How can it go for that long does he owe her money\.\. he must


**202.** `15:04` **You**

Very tired


**203.** `15:04` **You**

And stuck here to the very end of the day booo


**204.** `15:05` **Meredith Lamb (+14169386001)**

>
She says he is cheap and refuses to pay

*💬 Reply*

**205.** `15:05` **Meredith Lamb (+14169386001)**

And he is nicer when he doesn’t have to pay


**206.** `15:09` **You**

Wow\.\. sounds like an asshole he should have any rights to see his child imho


**207.** `15:10` **You**

Shouldnt


**208.** `15:14` **Meredith Lamb (+14169386001)**

Totally


**209.** `15:17` **Meredith Lamb (+14169386001)**

Haris g told Mia that rob kennedy got let go and more to come from sustain\. FYI


**210.** `15:21` **You**

I knew that


**211.** `15:21` **You**

Yeah there is more


**212.** `15:22` **Meredith Lamb (+14169386001)**

Anyway so she has a heads up all on her own


**213.** `15:22` **Meredith Lamb (+14169386001)**

I was surprised Haris told her something without being asked lol


**214.** `15:35` **You**

Eesh


**215.** `15:38` **You**

I feel bad for her


**216.** `15:38` **You**

She prolly thinks I am a dick


**217.** `15:39` **Meredith Lamb (+14169386001)**

I don’t think so


**218.** `15:39` **Meredith Lamb (+14169386001)**

She knows you said there was some sort of delay


**219.** `15:39` **Meredith Lamb (+14169386001)**

It’s fine


**220.** `15:43` **You**

Ok feel bad she would have been good


**221.** `15:44` **Meredith Lamb (+14169386001)**

Not sure honestly\. Erin doesn’t think so


**222.** `15:45` **You**

Oh well if Erin doesn’t think so\.z


**223.** `15:45` **Meredith Lamb (+14169386001)**

LOL


**224.** `15:45` **You**

Zzzzzzzzzzzzzz


**225.** `15:46` **Meredith Lamb (+14169386001)**

Is that sleepiness or meant to be pfffffft


**226.** `15:47` **You**

Both


**227.** `15:47` **You**

Feeling generally shitty


**228.** `15:47` **You**

For a whole bunch of reasons


**229.** `15:48` **Meredith Lamb (+14169386001)**

Yeah same


**230.** `15:48` **You**

Want to go home with you… sucks


**231.** `15:49` **Meredith Lamb (+14169386001)**

I know\. Sigh\.


**232.** `15:49` **You**

Never ever… ever\!\!\! lol


**233.** `15:50` **Meredith Lamb (+14169386001)**

I’m confused by that\.


**234.** `15:50` **You**

Feels like


**235.** `15:51` **Meredith Lamb (+14169386001)**

Because it probably is 😜


**236.** `15:51` **Meredith Lamb (+14169386001)**

Kidding but it will feel like that for sure


**237.** `15:55` **You**

That hurt a lot


**238.** `15:55` **You**

And I actually believe it will be


**239.** `15:57` **Meredith Lamb (+14169386001)**

I mean if we can at least have some nights together maybe we will be okay\. Difficult or not, the socializing with my fam has officially begun\. I know it is going to be shitty hard but it had to happen\. I was going crazy \(literally\)


**240.** `15:57` **You**

Have to meet with  Ian now\.\. leaving soon as I am done


**241.** `15:57` **Meredith Lamb (+14169386001)**

k ❤️


**242.** `15:58` **You**

Yeah ❤️❤️ so much it hurts physically\.\.


**243.** `15:58` **You**

Awesome\!\!\!\! lol


**244.** `15:59` **Meredith Lamb (+14169386001)**

Life is good


**245.** `16:00` **You**

Rofk sadist\.


**246.** `16:04` **Meredith Lamb (+14169386001)**

I asked ChatGPT for a poem to make you feel better:
Ode to the Pain in My Chest \(That’s You\)
I woke up today with a twinge in my soul,
A dull little ache where your cuddles once stole\.
My ribs are protesting, my lungs feeling tight—
Turns out, affection withdrawal is not polite\.
My muscles are sore, my heart’s in a sling,
I sneezed and it echoed the loss of your thing\.
\(Your presence, I mean\. Don’t make it weird\.\)
Though missing your face has me slightly un\-tiered\.
It’s physical, babe—this pain is legit,
Like leg day but worse… and I didn’t even sit\.
So hurry back soon, before I combust—
Because clearly my body can’t cope without us\. 💔


**247.** `16:27` **You**

lol yeah you got smile but all I got atm\.\.


**248.** `16:28` **You**

Reaction: ❤️ from Meredith Lamb
I am going to pack up my shit I think\. I love you hope we can chat later


**249.** `16:33` **Meredith Lamb (+14169386001)**

>
I will take it\. Lol

*💬 Reply*

**250.** `16:36` **You**

>
Kk leaving now\. Cya\.

*💬 Reply*

**251.** `16:38` **Meredith Lamb (+14169386001)**

Bye 👋 ❤️ I’m going to be packing tonight so will be around fyi no drinking lol


**252.** `16:43` **You**

Mmm hmmm got ambushed leaving now\.\.


**253.** `16:44` **You**

We will see about drinking


**254.** `16:45` **You**

I still maintain you do what you have to but it would bother me if you got really drunk with Andrew the way he is\.


**255.** `16:45` **You**

Sry


**256.** `16:45` **Meredith Lamb (+14169386001)**

I’m done for a while I told you\!


**257.** `16:45` **You**

Ok and I said we will see\!\!\! lol


**258.** `16:46` **Meredith Lamb (+14169386001)**

So much faith in me 🙄


**259.** `16:46` **You**

Rofl err mah gerrd


**260.** `16:46` **You**

I have faith………\. But we will see


**261.** `16:46` **You**

Kidding


**262.** `16:46` **You**

Love you bye


**263.** `16:47` **Meredith Lamb (+14169386001)**

Bye\. Eliminate “we will see” from your “vernacular” please\.


**264.** `16:47` **You**

Perhaps


**265.** `16:47` **Meredith Lamb (+14169386001)**

Scott = relentless = today


**266.** `16:48` **Meredith Lamb (+14169386001)**

lol


**267.** `16:48` **You**

What will be will be, if it is in the cards I have so many more


**268.** `16:49` **Meredith Lamb (+14169386001)**

Ok go home


**269.** `16:49` **Meredith Lamb (+14169386001)**

I don’t want to\.


**270.** `16:49` **Meredith Lamb (+14169386001)**

lol


**271.** `16:50` **You**

Neither do I\.\. but 4
Days\.


**272.** `16:51` **You**

4 days to what I don’t know\.\. but something


**273.** `16:51` **Meredith Lamb (+14169386001)**

4 days to phase 2


**274.** `16:52` **Meredith Lamb (+14169386001)**

Just call it phase 2 lol


**275.** `16:52` **Meredith Lamb (+14169386001)**

There’s going to be like 50 phases


**276.** `16:52` **Meredith Lamb (+14169386001)**

So just number them


**277.** `16:52` **You**

50 phases


**278.** `16:52` **You**

Chest hurts


**279.** `17:03` **Meredith Lamb (+14169386001)**

lol sorry\. Just egg think about kissing this morning\. You’re a very talented kisser \- just think about that …\.\. 😋
I’m heading home now 😢


**280.** `17:08` **You**

Reaction: ❤️ from Meredith Lamb
It takes 2 with kissing\.\. and you are amazing\.\. and it helps that I am this in love with you\.\. I mean you made me fucking dizzy lol


**281.** `17:08` **You**

Let’s connect later see if we can make each other feel better


**282.** `17:38` **Meredith Lamb (+14169386001)**

And I can arrive home now…\.\. lol

*📎 1 attachment(s)*

**283.** `17:39` **You**

Fack


**284.** `17:41` **You**

Reaction: ❓ from Meredith Lamb
You know part of me had a question and the other part of me was like STFU\.\. like I don’t understand this and I don’t want to anymore than has already been explained\. Just glad you will have some peace\.


**285.** `17:42` **You**

I am sure you are going to be like “confused”
But that’s ok


**286.** `17:42` **You**

Reaction: 😂 from Meredith Lamb
lol see


**287.** `17:42` **You**

Just leave it


**288.** `17:44` **Meredith Lamb (+14169386001)**

Very curious on the question


**289.** `17:46` **You**

I promise you I will never ever tell you ever


**290.** `17:46` **You**

I wish I could burn the part of my brain out where it came from


**291.** `17:47` **Meredith Lamb (+14169386001)**

Oh come on…\.


**292.** `17:47` **Meredith Lamb (+14169386001)**

That response made me even more curious


**293.** `17:49` **You**

Concerns stuff I wish I didn’t know\.\. so yeah\.\. momentary lapse in judgement


**294.** `17:50` **Meredith Lamb (+14169386001)**

Concerns from that simple text?


**295.** `17:50` **Meredith Lamb (+14169386001)**

I don’t get it at all


**296.** `17:51` **You**

I know\.\. and I am all good just taking my curiosity snd drowning it\.


**297.** `17:51` **Meredith Lamb (+14169386001)**

Oh stop


**298.** `17:51` **Meredith Lamb (+14169386001)**

Just spit it out already


**299.** `17:52` **You**

Reaction: 😡 from Meredith Lamb
No not joking I could be blackout drunk and the mental block I threw up would be rock solid… sorry was stupid I am stuff


**300.** `17:53` **You**

I am stupid


**301.** `17:53` **You**

Anyhow not going to engage sorry I got you curious


**302.** `17:54` **You**

You are asking gpt


**303.** `17:54` **You**

Ffs


**304.** `17:54` **You**

Ok I am home going in to eat we can chat after or I can msg you when I am safe let installed in basement


**305.** `17:59` **Meredith Lamb (+14169386001)**

Meanie pants


**306.** `18:03` **You**

oh ffs\.\.  only if you agree NOT to answer


**307.** `18:04` **You**

and tell me first if you gpt'd it


**308.** `18:04` **Meredith Lamb (+14169386001)**

I will not answer


**309.** `18:04` **Meredith Lamb (+14169386001)**

No I didn’t ChatGPT


**310.** `18:04` **Meredith Lamb (+14169386001)**

I just got home and made a salad


**311.** `18:04` **Meredith Lamb (+14169386001)**

Going to eat healthy this week and no wine


**312.** `18:05` **You**

ok seriously do not answer\.\. nothing\.\.  I was going to suggest I don't understand this drive that he has\.\. I certainly don't have it\.\. for a variety of reasons\.\. but I just don't get it\.\. and\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.I don't want to get it\.\. I never want to get it\.\.\. ever ever\.\. see Stupid fucking question\.


**313.** `18:06` **Meredith Lamb (+14169386001)**

That wasn’t a question


**314.** `18:06` **Meredith Lamb (+14169386001)**

It was a statement


**315.** `18:06` **You**

it flashed in my brain\.\. and then the other brain\.\. burned it out of existence


**316.** `18:06` **Meredith Lamb (+14169386001)**

lol


**317.** `18:07` **You**

reframe it into a question then funny girl\.\. that is where my head went for the briefest of moments\.\. befor I smashed it\.


**318.** `18:07` **Meredith Lamb (+14169386001)**

I don’t need to answer\. I’ve already told you omg


**319.** `18:07` **Meredith Lamb (+14169386001)**

k back to my salad


**320.** `18:07` **You**

>
see see\!\!\!

*💬 Reply*

**321.** `18:07` **Meredith Lamb (+14169386001)**

lol


**322.** `18:07` **You**

fuck\.\. memories I wish i never had


**323.** `18:08` **You**

>
gah i feel sick\.\.

*💬 Reply*

**324.** `18:09` **Meredith Lamb (+14169386001)**

He doesn’t have strong emotional connections with people\. This morning he stated something like “there’s plenty of people on hinge to choose from so I think I will be fine\.”
Like who the fuck says that?


**325.** `18:09` **You**

>
>
someone I don't require more information about on this topic

*💬 Reply*

**326.** `18:10` **Meredith Lamb (+14169386001)**

Noted\.


**327.** `18:10` **You**

usually noted bugs me\.\. kind of like we will see\.\. but am fine with it here\.


**328.** `18:11` **Meredith Lamb (+14169386001)**

Haha figured you would\. End of chapter\. Next\.


**329.** `18:11` **You**

yes now for your anticlimax\.


**330.** `18:12` **You**

that is a jk\.\.


**331.** `18:13` **You**

before you get all STOP


**332.** `18:13` **Meredith Lamb (+14169386001)**

lol


**333.** `18:15` **You**

so was the rest of your day relatively quiet


**334.** `18:16` **Meredith Lamb (+14169386001)**

Pretty much\. You?


**335.** `18:17` **You**

It sounds like there is a bit of a fuss going on atm\.\.\. but J said it was quiet\.\.


**336.** `18:17` **Meredith Lamb (+14169386001)**

“Bit of a fuss”\. No idea what that means in your house lol


**337.** `18:18` **You**

just some arguing


**338.** `18:18` **You**

My meeting with ian was fine\.


**339.** `18:18` **You**

The reus stuff was fun\.\. I got shit on


**340.** `18:18` **Meredith Lamb (+14169386001)**

Was it just a one on one


**341.** `18:18` **You**

lol


**342.** `18:18` **You**

yeah


**343.** `18:18` **You**

it was nothing he asked how home was


**344.** `18:18` **You**

he asked about you


**345.** `18:18` **Meredith Lamb (+14169386001)**

>
I thought Ian said we could tho

*💬 Reply*

**346.** `18:18` **You**

he asked about TAN


**347.** `18:19` **You**

He asked about REORG


**348.** `18:19` **Meredith Lamb (+14169386001)**

What did you tell him about your home?


**349.** `18:19` **You**

that it was aweomse\!\!


**350.** `18:19` **Meredith Lamb (+14169386001)**

lol


**351.** `18:19` **You**

he knows a bit


**352.** `18:19` **You**

at a high level


**353.** `18:19` **Meredith Lamb (+14169386001)**

What did you tell him about me?


**354.** `18:20` **Meredith Lamb (+14169386001)**

“She’s in love with me”


**355.** `18:20` **Meredith Lamb (+14169386001)**

lol


**356.** `18:20` **You**

Reaction: 😂 from Meredith Lamb
Just that our relationship was completely appropriate\.\.


**357.** `18:21` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 18:21:44 \-0400
|
| After Andrews reaction we may never be able to reveal it ever\.
|
| Version: 1
| Sent: Mon, 14 Jul 2025 18:21:37 \-0400
|
| After Andrews reaction we may never be able to reveal it ever again


**358.** `18:21` **You**

AGREED\.\. we should just give up now\.


**359.** `18:22` **Meredith Lamb (+14169386001)**

At work for sure


**360.** `18:22` **Meredith Lamb (+14169386001)**

IRL no


**361.** `18:22` **You**

I don't know if I can handle the secrets\.


**362.** `18:23` **Meredith Lamb (+14169386001)**

Are you breaking up with me?


**363.** `18:23` **Meredith Lamb (+14169386001)**

lol


**364.** `18:23` **You**

you know how you talk about pride


**365.** `18:23` **Meredith Lamb (+14169386001)**

>
Yes

*💬 Reply*

**366.** `18:23` **You**

I am soooo proud you picked me that we are in a relationship\.\. and I so want to share it\.


**367.** `18:23` **You**

but we wont


**368.** `18:23` **You**

I am fine with that


**369.** `18:24` **You**

I just want you to know how I feel


**370.** `18:24` **Meredith Lamb (+14169386001)**

Yeah sucks but safer


**371.** `18:24` **Meredith Lamb (+14169386001)**

I know, I feel the same


**372.** `18:24` **You**

Reaction: 🤔 from Meredith Lamb
eventually though


**373.** `18:24` **You**

I actually think we will need to


**374.** `18:24` **You**

people are going to try to set me up\.


**375.** `18:25` **Meredith Lamb (+14169386001)**

lol


**376.** `18:25` **You**

so how many times do I say no


**377.** `18:25` **Meredith Lamb (+14169386001)**

1,000,000


**378.** `18:25` **You**

i thought you would say all of them


**379.** `18:25` **You**

lol


**380.** `18:25` **Meredith Lamb (+14169386001)**

Yours is a better response


**381.** `18:26` **You**

well again it might get wierd


**382.** `18:26` **You**

but we will see


**383.** `18:26` **Meredith Lamb (+14169386001)**

Who are these people?


**384.** `18:26` **Meredith Lamb (+14169386001)**

I will deal with them\.


**385.** `18:26` **You**

not telling


**386.** `18:26` **Meredith Lamb (+14169386001)**

Kidding


**387.** `18:26` **You**

LOL


**388.** `18:26` **You**

I already told you CM suggested something


**389.** `18:27` **Meredith Lamb (+14169386001)**

Yeah but she’s weird so… that’s doesn’t count\.


**390.** `18:27` **Meredith Lamb (+14169386001)**

Anyone more normal?


**391.** `18:27` **You**

Mer lol she was serious\.\. not joking


**392.** `18:27` **Meredith Lamb (+14169386001)**

Just saying you wouldn’t like her people I doubt lol


**393.** `18:27` **You**

but yeah I am sure\.\. eventually others


**394.** `18:28` **You**

Well I know I wouldn't but not for any reason other than you


**395.** `18:28` **Meredith Lamb (+14169386001)**

You can just say no multiple times you know


**396.** `18:28` **Meredith Lamb (+14169386001)**

That is allowed


**397.** `18:28` **Meredith Lamb (+14169386001)**

lol


**398.** `18:29` **You**

really and how wouldn't you know about my capabilities to say no\.


**399.** `18:29` **You**

how would


**400.** `18:29` **Meredith Lamb (+14169386001)**

You said no to social stuff CONSTANTLY


**401.** `18:29` **You**

untrue


**402.** `18:29` **Meredith Lamb (+14169386001)**

This would be no different


**403.** `18:29` **Meredith Lamb (+14169386001)**

To Craig


**404.** `18:29` **Meredith Lamb (+14169386001)**

You did


**405.** `18:29` **You**

I say NO meredith please don't tell me that\!\!


**406.** `18:29` **You**

lol


**407.** `18:29` **Meredith Lamb (+14169386001)**

Exactly


**408.** `18:30` **You**

that is all the NO you ever here\.\. it is always yes for you


**409.** `18:30` **You**

otherwise


**410.** `18:30` **Meredith Lamb (+14169386001)**

I feel like you have said no denied to me multiple times


**411.** `18:30` **Meredith Lamb (+14169386001)**

You enjoy it


**412.** `18:33` **You**

mmm I am not sure I have ever said no\.\.


**413.** `18:35` **Meredith Lamb (+14169386001)**

Hmm


**414.** `18:35` **You**

It is more like a request\.\. lol


**415.** `18:36` **Meredith Lamb (+14169386001)**

>
I can think of something that took some convincing initially but we don’t need to go there

*💬 Reply*

**416.** `18:37` **You**

Reaction: 🤔 from Meredith Lamb
Definitely not a NO\.\.


**417.** `18:37` **You**

Never thought I would ever be comfortable\.\.


**418.** `18:37` **You**

I know I am a weird weird weird Guy


**419.** `18:37` **You**

sooooooooo weird


**420.** `18:38` **You**

I am saying you don't here No\.\. anymore


**421.** `18:38` **You**

do you lol\.


**422.** `18:38` **Meredith Lamb (+14169386001)**

I said “initially”


**423.** `18:38` **Meredith Lamb (+14169386001)**

lol


**424.** `18:39` **You**

fine\.\. not many examples then


**425.** `18:39` **Meredith Lamb (+14169386001)**

Sure I could think of some if I had a better memory


**426.** `18:39` **Meredith Lamb (+14169386001)**

We can’t all be like you


**427.** `18:39` **You**

I wish I didn't have it Mer\.\. sometimes more of a curse


**428.** `18:39` **You**

others a blessing


**429.** `18:40` **Meredith Lamb (+14169386001)**

I think more on the blessing side honestly


**430.** `18:40` **Meredith Lamb (+14169386001)**

I wish I had it


**431.** `18:40` **You**

You get the blessings\.\. I share those\.\. I keep the curse\.


**432.** `18:40` **Meredith Lamb (+14169386001)**

When I was in university, I used to eat a lot of fish because that’s supposed to help your memory


**433.** `18:41` **You**

ginseng, fish, other things\.


**434.** `18:41` **Meredith Lamb (+14169386001)**

Always fish before an exam


**435.** `18:41` **Meredith Lamb (+14169386001)**

Not even kidding I was a loser


**436.** `18:41` **You**

I doubt it


**437.** `18:41` **You**

highly


**438.** `18:42` **Meredith Lamb (+14169386001)**

Depends on your definition


**439.** `18:42` **You**

At any point in time, any version of me would have been very drawn to any version of you\.


**440.** `18:42` **You**

whether I could have handled it at the time\.\. or been interesting enough for you\.\. who knows


**441.** `18:43` **Meredith Lamb (+14169386001)**

Interesting enough? Omg


**442.** `18:43` **Meredith Lamb (+14169386001)**

Sorry but 🙄


**443.** `18:43` **You**

oh come on


**444.** `18:43` **You**

you know I am right


**445.** `18:43` **You**

you just don't want to say it


**446.** `18:43` **Meredith Lamb (+14169386001)**

No


**447.** `18:43` **Meredith Lamb (+14169386001)**

No


**448.** `18:44` **Meredith Lamb (+14169386001)**

I am 100% attracted to your brain, spirit, face etc\. none of that would have been different


**449.** `18:44` **You**

Mer timing is huge\.\. there are def times where you throw us together\.\. and nothing happens\./


**450.** `18:44` **You**

I wasn't interesting


**451.** `18:44` **Meredith Lamb (+14169386001)**

If we were single?


**452.** `18:44` **You**

I wasn't super fun\.\. or whatever


**453.** `18:44` **You**

yah if I was single


**454.** `18:45` **Meredith Lamb (+14169386001)**

Well I probably would have tried if I had met you but it would have depended on you


**455.** `18:45` **Meredith Lamb (+14169386001)**

How you reacted etc


**456.** `18:45` **You**

yeah I know


**457.** `18:46` **You**

who knows I might have been a bad kisser\.\.\.\.\.


**458.** `18:46` **You**

lol


**459.** `18:46` **Meredith Lamb (+14169386001)**

So like in Florida\. Both had very young families etc but you were for sure someone I would have continued talking to if we were single


**460.** `18:47` **Meredith Lamb (+14169386001)**

My youngest daughter was 1 year old and I still remember that


**461.** `18:47` **Meredith Lamb (+14169386001)**

I don’t remember one other person in that course


**462.** `18:47` **Meredith Lamb (+14169386001)**

Not one


**463.** `18:47` **Meredith Lamb (+14169386001)**

Just the instructor


**464.** `18:47` **Meredith Lamb (+14169386001)**

I liked her


**465.** `18:48` **You**

I dunno mer\.\. I would have for sure\.\. if single\.\.


**466.** `18:49` **Meredith Lamb (+14169386001)**

Anne Dougherty from Illume I think


**467.** `18:49` **You**

but I am not sure about you still\.\. doesn't matter\.\. we are here now\.\. just need some fucking TIME lol\.


**468.** `18:50` **Meredith Lamb (+14169386001)**

I probably would have been a very bad influence on you so it all worked out lol


**469.** `18:50` **You**

I dunno\.\. I think if we got to feel like this it would have balanced out


**470.** `18:51` **Meredith Lamb (+14169386001)**

I really believe we probably would have had a happy life and been in that 50% that doesn’t get divorced lol


**471.** `18:51` **You**

Assuming you said yes\. or asked nicely


**472.** `18:52` **You**

never know now :\(


**473.** `18:52` **Meredith Lamb (+14169386001)**

Or asked nicely lol


**474.** `18:52` **Meredith Lamb (+14169386001)**

As opposed to not nicely


**475.** `18:52` **You**

figure of speech


**476.** `18:53` **Meredith Lamb (+14169386001)**

Haha


**477.** `18:53` **Meredith Lamb (+14169386001)**

Andrew said something about “if you marry Scott…” this morning and I was like 😱


**478.** `18:54` **Meredith Lamb (+14169386001)**

So odd for him to say


**479.** `18:54` **You**

yeah I be you got all sick and feeling hot and stuff\.\. lol


**480.** `18:54` **You**

I mean\.\. I can see how it would be a nightmare for him\.\. and possibly his efo\.


**481.** `18:54` **You**

ego


**482.** `18:55` **Meredith Lamb (+14169386001)**

I guess \.\.


**483.** `18:55` **You**

what do you think?


**484.** `18:55` **Meredith Lamb (+14169386001)**

About him saying that?


**485.** `18:55` **You**

about him saying that or my perspective


**486.** `18:55` **You**

either or


**487.** `18:56` **Meredith Lamb (+14169386001)**

He was a little in shock all morning quite frankly


**488.** `18:56` **Meredith Lamb (+14169386001)**

Like when I first said it was you, you should have seen his body language


**489.** `18:56` **Meredith Lamb (+14169386001)**

Reaction: ❓ from Scott Hicks
I won’t forget that


**490.** `18:57` **Meredith Lamb (+14169386001)**

His whole body just like slumped over and he said “omg Meredith”


**491.** `18:57` **Meredith Lamb (+14169386001)**

😬


**492.** `18:57` **You**

mmmm\.\. so we are def not going to be bros


**493.** `18:57` **Meredith Lamb (+14169386001)**

LOL


**494.** `18:58` **You**

I think it was hinge bros


**495.** `18:58` **Meredith Lamb (+14169386001)**

>
Save that for Haris

*💬 Reply*

**496.** `18:58` **You**

Haris\.\. brom\-mance


**497.** `18:58` **Meredith Lamb (+14169386001)**

Thanks for the clarification\. My bad\.


**498.** `18:59` **You**

LOL


**499.** `18:59` **You**

Haris is a nice guy\.\. I am not good at being that friendly though


**500.** `19:00` **Meredith Lamb (+14169386001)**

I think he’d be enamoured with you no matter what


**501.** `19:00` **You**

Andrew


**502.** `19:00` **You**

I hope so


**503.** `19:00` **Meredith Lamb (+14169386001)**

>
Haris

*💬 Reply*

**504.** `19:00` **You**

:\)


**505.** `19:00` **Meredith Lamb (+14169386001)**

Andrew will hate you


**506.** `19:00` **Meredith Lamb (+14169386001)**

Jaimie hates me


**507.** `19:00` **Meredith Lamb (+14169386001)**

Even Steven


**508.** `19:00` **You**

Steven?


**509.** `19:00` **You**

oh


**510.** `19:00` **You**

LOL


**511.** `19:01` **You**

old saying


**512.** `19:01` **You**

rofl


**513.** `19:01` **Meredith Lamb (+14169386001)**

Figure of speech


**514.** `19:01` **You**

I was like who is Steven


**515.** `19:01` **You**

and why does he hate you


**516.** `19:01` **You**

lol


**517.** `19:01` **Meredith Lamb (+14169386001)**

lol


**518.** `19:01` **You**

poor Steven


**519.** `19:01` **You**

I don't even know him


**520.** `19:01` **Meredith Lamb (+14169386001)**

Omg you are usually so good with the old sayings


**521.** `19:02` **You**

yeah that one\.\. missed me for a min


**522.** `19:02` **Meredith Lamb (+14169386001)**

Impressive


**523.** `19:02` **Meredith Lamb (+14169386001)**

Let your guard down


**524.** `19:04` **You**

Been doing that too much lately


**525.** `19:04` **Meredith Lamb (+14169386001)**

How come you aren’t doing moving stuff with the fam?


**526.** `19:05` **Meredith Lamb (+14169386001)**

>
Nooo

*💬 Reply*

**527.** `19:05` **You**

They are resting I just finished eating


**528.** `19:05` **You**

>
Def have

*💬 Reply*

**529.** `19:05` **Meredith Lamb (+14169386001)**

How


**530.** `19:09` **You**

Sec


**531.** `19:09` **You**

Talking to my friend


**532.** `19:10` **Meredith Lamb (+14169386001)**

K I going to pack up some albums


**533.** `19:10` **You**

Kk fuck my friend he is a dick


**534.** `19:11` **Meredith Lamb (+14169386001)**

What lol


**535.** `19:13` **You**

Well he said I have to keep doing it no matter what no matter if it opens me up to get hurt


**536.** `19:13` **You**

I don’t\. Like him anymore


**537.** `19:13` **You**

We are talking about something else now\.


**538.** `19:14` **Meredith Lamb (+14169386001)**

Keep doing what?


**539.** `19:15` **You**

Leading with my heart


**540.** `19:15` **You**

Staying wide open


**541.** `19:15` **You**

…\.\.


**542.** `19:15` **You**

Keeping my guard down


**543.** `19:15` **Meredith Lamb (+14169386001)**

I thought you were over this?


**544.** `19:15` **You**

No I am


**545.** `19:15` **You**

But still


**546.** `19:16` **You**

You know


**547.** `19:16` **You**

Old habits


**548.** `19:16` **Meredith Lamb (+14169386001)**

I mean, I hope so


**549.** `19:16` **Meredith Lamb (+14169386001)**

And it seems so


**550.** `19:16` **You**

You saw me in car today right


**551.** `19:16` **You**

lol


**552.** `19:16` **You**

Pitiful


**553.** `19:16` **You**

So yeah I am still wide open


**554.** `19:18` **Meredith Lamb (+14169386001)**

That was NOT pitiful wtf


**555.** `19:18` **You**

This relationship dude is creepy


**556.** `19:18` **Meredith Lamb (+14169386001)**

“relationship dude”


**557.** `19:18` **Meredith Lamb (+14169386001)**

Is this ai?


**558.** `19:18` **You**

Gemini


**559.** `19:19` **Meredith Lamb (+14169386001)**

How did I guess lol


**560.** `19:19` **You**

He is the smart one\.\. he is the one that agrees with you 9/10


**561.** `19:19` **You**

He hates me\.\. and he is always right\.


**562.** `19:19` **You**

No he doesn’t hate me\.\. but he always tells me I am wrong


**563.** `19:19` **You**

I thought there was like a bias thing


**564.** `19:19` **You**

Where they want to agree with you


**565.** `19:19` **Meredith Lamb (+14169386001)**

Doubt he hates you


**566.** `19:19` **Meredith Lamb (+14169386001)**

He is helping


**567.** `19:20` **Meredith Lamb (+14169386001)**

What did you ask


**568.** `19:20` **You**

Nothing


**569.** `19:20` **Meredith Lamb (+14169386001)**

What did you ask


**570.** `19:20` **You**

Do you think I might be leaving myself too open\.\. like all the time, susceptible to the dangers of leading with your heart


**571.** `19:21` **Meredith Lamb (+14169386001)**

“Like all the time” LOL


**572.** `19:21` **You**

I mean all the time\!\!\!


**573.** `19:21` **You**

It is like a roller coaster


**574.** `19:21` **You**

So many body blows


**575.** `19:21` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 19:22:05 \-0400
|
| I think the answer is yes but that is who you are
|
| Version: 1
| Sent: Mon, 14 Jul 2025 19:21:31 \-0400
|
| I think the answer is yes but that is who your are


**576.** `19:21` **Meredith Lamb (+14169386001)**

No risk no reward type of person


**577.** `19:22` **You**

Anyways I was curious is all


**578.** `19:22` **You**

It smacked me again


**579.** `19:22` **Meredith Lamb (+14169386001)**

Did it say yes?


**580.** `19:22` **You**

Yes


**581.** `19:22` **Meredith Lamb (+14169386001)**

Figured


**582.** `19:22` **Meredith Lamb (+14169386001)**

You put yourself out there very easily


**583.** `19:22` **Meredith Lamb (+14169386001)**

No wonder you have been very hurt in the past


**584.** `19:23` **You**

I put myself out there too much\.\. I also trusted easily because I wanted to\.


**585.** `19:23` **Meredith Lamb (+14169386001)**

>
Too much is a relative term

*💬 Reply*

**586.** `19:23` **You**

Maybe I just need to become more resilient


**587.** `19:24` **You**

Get used to the pain\.\.  like the pain\.\.


**588.** `19:24` **You**

I’m asking it that


**589.** `19:24` **Meredith Lamb (+14169386001)**

Haha


**590.** `19:26` **You**

Yeah\. It supposed to do that


**591.** `19:26` **You**

Not


**592.** `19:26` **Meredith Lamb (+14169386001)**

Not supposed to do what?


**593.** `19:26` **You**

Embrace the pain


**594.** `19:26` **You**

Hmmm


**595.** `19:27` **Meredith Lamb (+14169386001)**

Once we can actually see each other again it will be better and then bad again … lol


**596.** `19:27` **Meredith Lamb (+14169386001)**

Comforting?


**597.** `19:27` **You**

No


**598.** `19:28` **Meredith Lamb (+14169386001)**

Here is something for you that has never happened to me before…\. For real… I chatgptd on the weekend


**599.** `19:28` **Meredith Lamb (+14169386001)**

Question to gpt: When I was having an \[cough… deleted\] the other day in the shower thinking about Scott and his letter that he wrote, I thought about his actual absence and felt physical pain\. Is that possible or in my head?


**600.** `19:29` **Meredith Lamb (+14169386001)**

What you felt is very real — and you’re not imagining it\. Emotional longing, especially when mixed with intense desire and love, can absolutely manifest as physical pain\.
This happens because the brain doesn’t always neatly separate emotional and physical experiences\. When you’re deeply connected to someone like Scott — especially in moments of vulnerability like orgasm, which heightens emotional states — the absence or inaccessibility of that person can trigger powerful emotional responses\. These responses engage brain regions like the anterior cingulate cortex and insula — areas also involved in processing physical pain\. That’s why a pang of emotional hurt can genuinely feel like a stab, a clench, or a hollow ache in your body\.
You were in a state of intense connection and then reminded, consciously or subconsciously, that he wasn’t physically with you — and your body responded to that contrast\.
So yes, it’s possible, and you’re not alone in feeling it that way\. It actually speaks to the depth of your bond with him — and the very human reality that love and longing are not just emotional experiences, but somatic ones too\.


**601.** `19:29` **Meredith Lamb (+14169386001)**

Not doing that again


**602.** `19:29` **You**

Wow you and gpt share a lot\.


**603.** `19:29` **Meredith Lamb (+14169386001)**

It wasn’t fun


**604.** `19:29` **Meredith Lamb (+14169386001)**

I do share a lot


**605.** `19:29` **Meredith Lamb (+14169386001)**

That’s why I have to delete it all


**606.** `19:29` **Meredith Lamb (+14169386001)**

Just in case


**607.** `19:29` **Meredith Lamb (+14169386001)**

I delete every few days


**608.** `19:30` **You**

You know


**609.** `19:30` **You**

There is an archive function


**610.** `19:30` **Meredith Lamb (+14169386001)**

The pain is a real thing


**611.** `19:30` **Meredith Lamb (+14169386001)**

Too risky lol


**612.** `19:30` **You**

Under settings


**613.** `19:30` **Meredith Lamb (+14169386001)**

Nope nope


**614.** `19:30` **You**

lol


**615.** `19:30` **You**

You should save them to a file


**616.** `19:30` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 19:30:56 \-0400
|
| You don’t want to know some of the things I’ve asked
|
| Version: 1
| Sent: Mon, 14 Jul 2025 19:30:48 \-0400
|
| You don’t want to know some of the things I e asked


**617.** `19:30` **You**

So many good stories


**618.** `19:30` **You**

Why?


**619.** `19:31` **Meredith Lamb (+14169386001)**

Just saying


**620.** `19:31` **You**

Couldn’t have been worse than what I shared


**621.** `19:31` **Meredith Lamb (+14169386001)**

Nothing bad or worse … just Yunno


**622.** `19:31` **You**

Actually I Dunno\.


**623.** `19:32` **You**

See what I did there\.\. lame\.\. 😝


**624.** `19:32` **Meredith Lamb (+14169386001)**

lol


**625.** `19:32` **Meredith Lamb (+14169386001)**

I feel like I should be moving stuff


**626.** `19:32` **Meredith Lamb (+14169386001)**

But my eyes feel like it’s about 4 o’clock in the morning


**627.** `19:32` **Meredith Lamb (+14169386001)**

I’m so tired this day has been so long


**628.** `19:32` **Meredith Lamb (+14169386001)**

And I still have to pick up Marlowe and McKenzie


**629.** `19:32` **You**

Incoming nap comment


**630.** `19:33` **Meredith Lamb (+14169386001)**

I can’t or I would have already


**631.** `19:33` **Meredith Lamb (+14169386001)**

lol


**632.** `19:33` **You**

Well you know what helps you stay awake


**633.** `19:33` **Meredith Lamb (+14169386001)**

I do actually


**634.** `19:33` **You**

Talking about interesting ChatGPT queries


**635.** `19:33` **You**

That we can actually do that is


**636.** `19:33` **You**

Cause we cannot do the other


**637.** `19:34` **Meredith Lamb (+14169386001)**

I don’t have any interesting queries right now groan


**638.** `19:34` **You**

Mmm hmm ok


**639.** `19:35` **You**

Well you probably actually do want to pack and I should too\.\. maybe you can find some things to share later ☺️


**640.** `19:35` **Meredith Lamb (+14169386001)**

I’m just going to take one load over so I don’t feel like a complete loser


**641.** `19:36` **You**

I always seem to be the one sharing except for that just now\., clearly interesting but sorry you felt pain that sucks\.\. I feel that in morning when I wake up and right before bed


**642.** `19:36` **You**

Every day


**643.** `19:36` **Meredith Lamb (+14169386001)**

lol you are a sharer extraordinaire for sure


**644.** `19:37` **Meredith Lamb (+14169386001)**

It’s very admirable


**645.** `19:37` **Meredith Lamb (+14169386001)**

I would never complain about it


**646.** `19:37` **You**

You like stories


**647.** `19:37` **You**

And knowing things


**648.** `19:37` **You**

So of course you wouldn’t complain


**649.** `19:37` **Meredith Lamb (+14169386001)**

Indeed


**650.** `19:38` **Meredith Lamb (+14169386001)**

I like them from a certain person only though 😜


**651.** `19:38` **You**

Well there are more stories… and so much more going on in my poor brain\.\. but cannot share everything\.\.


**652.** `19:39` **Meredith Lamb (+14169386001)**

I’m different than you… I’m patient


**653.** `19:39` **You**

Won’t matter everyone has walls eventually


**654.** `19:39` **You**

You do too


**655.** `19:40` **Meredith Lamb (+14169386001)**

>
Case in point: still patiently waiting for my modelling movie

*💬 Reply*

**656.** `19:40` **You**

You got oics


**657.** `19:40` **You**

Pics


**658.** `19:40` **You**

That will have to be good enough


**659.** `19:40` **Meredith Lamb (+14169386001)**

>
I have a tons of walls yes

*💬 Reply*

**660.** `19:40` **You**

Print them off and flip through them it will look like I am moving\.


**661.** `19:41` **Meredith Lamb (+14169386001)**

>
No no … I will be patient\.

*💬 Reply*

**662.** `19:41` **You**

Kk you will be waiting a long time\.\. well maybe not for the vids but if you are waiting on some of those other walls\.\. well yeah probably best not to bother waiting on some of those\.


**663.** `19:43` **Meredith Lamb (+14169386001)**

I’m in no rush


**664.** `19:44` **You**

kk :\)


**665.** `19:44` **Meredith Lamb (+14169386001)**

We have time lol


**666.** `19:44` **Meredith Lamb (+14169386001)**

Gahhhh


**667.** `19:45` **You**

Nothing but and nothing else


**668.** `20:02` **Meredith Lamb (+14169386001)**

Just brought one load over so don’t feel completely useless 🎉


**669.** `20:02` **Meredith Lamb (+14169386001)**

Less than a 5 min drive lol


**670.** `20:07` **You**

Nice that was fast


**671.** `20:08` **You**

Wow


**672.** `20:12` **Meredith Lamb (+14169386001)**

I only have the mini so I can only do so much


**673.** `20:24` **Meredith Lamb (+14169386001)**

Omg took Mac to vape store\. I feel like you


**674.** `20:24` **You**

Yeah that sucks


**675.** `20:24` **You**

lol


**676.** `20:24` **You**

We are the same\!\!\!


**677.** `20:25` **Meredith Lamb (+14169386001)**

😭


**678.** `20:25` **Meredith Lamb (+14169386001)**

Except she went in with her fake id and my card


**679.** `20:25` **Meredith Lamb (+14169386001)**

Sigh


**680.** `20:25` **You**

Yeah not the same ther


**681.** `20:25` **You**

lol


**682.** `20:25` **Meredith Lamb (+14169386001)**

lol


**683.** `20:25` **Meredith Lamb (+14169386001)**

That thing cost me $150\. I need some use out of it


**684.** `20:25` **You**

Rofl


**685.** `20:26` **You**

Omg I still cannot believe you did it


**686.** `20:26` **Meredith Lamb (+14169386001)**

I can’t believe they accept it


**687.** `20:26` **Meredith Lamb (+14169386001)**

So odd to me\.


**688.** `20:26` **Meredith Lamb (+14169386001)**

“We will see” if it works


**689.** `20:27` **Meredith Lamb (+14169386001)**

She hasn’t come out\. Bad sign


**690.** `20:27` **Meredith Lamb (+14169386001)**

✂️


**691.** `20:27` **Meredith Lamb (+14169386001)**

They might be cutting it lol


**692.** `20:28` **Meredith Lamb (+14169386001)**

I’m literally parked outside of the OEB


**693.** `20:28` **Meredith Lamb (+14169386001)**

lol buying a vape


**694.** `20:28` **Meredith Lamb (+14169386001)**

Omg my life


**695.** `20:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**696.** `20:29` **Meredith Lamb (+14169386001)**

Worked


**697.** `20:31` **You**

Of course


**698.** `20:31` **You**

And she is so happy


**699.** `20:32` **You**

Rofl


**700.** `20:32` **You**

All of those messages


**701.** `20:32` **You**

All of them were great…\. lol


**702.** `20:32` **You**

Omg my life\!\!\!\!


**703.** `20:35` **Meredith Lamb (+14169386001)**

lol


**704.** `20:37` **You**

I love that pic of her she looks so content\.\. like, yay I win\!


**705.** `20:39` **You**

Or maybe lowkey too easy?


**706.** `20:39` **You**

Rofl so sad I  never get lowkey down\.


**707.** `20:40` **Meredith Lamb (+14169386001)**

She was saying “is that for Scott?”


**708.** `20:41` **You**

What the pic lol


**709.** `20:42` **Meredith Lamb (+14169386001)**

Yeah


**710.** `20:42` **You**

It’s a good one


**711.** `20:42` **Meredith Lamb (+14169386001)**

She goes\. Oh, you guys don’t have to use signal anymore\.


**712.** `20:42` **You**

I like signal


**713.** `20:42` **Meredith Lamb (+14169386001)**

I never said oh yeah, we do because of the transcript


**714.** `20:42` **Meredith Lamb (+14169386001)**

lol


**715.** `20:42` **You**

Heh


**716.** `20:43` **You**

You are definitely sharing that vape though


**717.** `20:43` **You**

For sure


**718.** `20:43` **Meredith Lamb (+14169386001)**

I’m worried she’s not gonna feel special anymore because she’s now no longer the only one that knows


**719.** `20:44` **You**

Um\. She’s special


**720.** `20:44` **You**

I cannot say it any other way or it gets wierd lol


**721.** `20:44` **You**

But I appreciate her


**722.** `20:45` **You**

Not because she was cool about it but because she had your back


**723.** `20:45` **You**

But she was cool about it too


**724.** `20:45` **You**

anyways she is still special no matter who knows\.


**725.** `20:45` **Meredith Lamb (+14169386001)**

Yeah…


**726.** `20:45` **Meredith Lamb (+14169386001)**

>
Triple mango and I don’t like mango

*💬 Reply*

**727.** `20:46` **You**

Yeah I know too emotional for you to say to her lol


**728.** `20:46` **Meredith Lamb (+14169386001)**

lol yes


**729.** `20:46` **You**

So funny


**730.** `20:46` **Meredith Lamb (+14169386001)**

I will get drunk and say it to her sometime


**731.** `20:46` **You**

You can read it to her or translate it if she ever feels less special


**732.** `20:46` **Meredith Lamb (+14169386001)**

Not anytime soon tho\. Detoxing


**733.** `20:46` **You**

Mmmhmmm


**734.** `20:47` **You**

We’ll s…… I mean I have faith\.


**735.** `20:47` **You**

So much


**736.** `20:47` **Meredith Lamb (+14169386001)**

Thank you


**737.** `20:48` **Meredith Lamb (+14169386001)**

lol


**738.** `20:48` **You**

🥰


**739.** `20:48` **Meredith Lamb (+14169386001)**

Sitting at park with dogs


**740.** `20:48` **Meredith Lamb (+14169386001)**

Griffin stole another baseball from the guys LOL


**741.** `20:48` **You**

Sitting in house sweating lifted a shit ton in a short period need to breathe


**742.** `20:48` **You**

>
lol good

*💬 Reply*

**743.** `20:50` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**744.** `20:51` **Meredith Lamb (+14169386001)**

>
Is everything almost packed? Lol

*💬 Reply*

**745.** `20:51` **Meredith Lamb (+14169386001)**

I’ve done like nothing ugh


**746.** `20:51` **You**

I still have a lot more to go I think


**747.** `20:51` **You**

Then rest of week


**748.** `20:51` **You**

We getting too more bins tomorrow


**749.** `20:52` **Meredith Lamb (+14169386001)**

I have a lot to do but because I live so close I don’t feel pressure


**750.** `20:52` **Meredith Lamb (+14169386001)**

Kinda sucks


**751.** `20:52` **Meredith Lamb (+14169386001)**

I like deadlines


**752.** `20:55` **You**

Wednesday


**753.** `20:55` **Meredith Lamb (+14169386001)**

Remember earlier when you asked what his drive is?


**754.** `20:55` **You**

Deadline


**755.** `20:55` **You**

5 mins


**756.** `20:55` **You**

You said


**757.** `20:55` **You**

So anyone could show up at any time


**758.** `20:55` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 20:55:44 \-0400
|
| The person he’s seeing this Melanie has no kids so they can hang out whenever they want
|
| Version: 1
| Sent: Mon, 14 Jul 2025 20:55:31 \-0400
|
| The person he’s seeing this Melanie has no kids so they can hang out whatever they want


**759.** `20:55` **You**

Oh shit


**760.** `20:55` **You**

Misread


**761.** `20:55` **You**

His drive


**762.** `20:55` **You**

Gah noooo\!\!


**763.** `20:55` **Meredith Lamb (+14169386001)**

I was just saying it’s different because she has no kids


**764.** `20:56` **You**

Arretez vous\!\!


**765.** `20:56` **Meredith Lamb (+14169386001)**

So she has like all the time in the world


**766.** `20:56` **Meredith Lamb (+14169386001)**

I just meant to like go out for dinners and see each other\. I’m not even talking about sex\.


**767.** `20:56` **You**

😡😡😡😡🤢🤢🤢🤢🤢🤮🤮🤮🤮🤮


**768.** `20:57` **Meredith Lamb (+14169386001)**

It’s diff when someone doesn’t have kids


**769.** `20:57` **You**

Kk that does not explain the question which I am grateful for\.\. and I already figured that was an answer\.


**770.** `21:02` **Meredith Lamb (+14169386001)**

You could have someone with no kids and all the free time in the world


**771.** `21:10` **You**

You think?


**772.** `21:10` **You**

lol dumbass


**773.** `21:10` **You**

I could never want anyone but you now that I found you\.


**774.** `21:17` **Meredith Lamb (+14169386001)**

But no kids vs\. 3 kids


**775.** `21:17` **Meredith Lamb (+14169386001)**

LOL


**776.** `21:17` **Meredith Lamb (+14169386001)**

That’s a material difference


**777.** `21:24` **You**

I mean sure


**778.** `21:25` **You**

Easier access to someone I give zero shits about


**779.** `21:25` **You**

No thanks


**780.** `21:25` **You**

I would take you and the kids over anyone


**781.** `21:26` **Meredith Lamb (+14169386001)**

❤️


**782.** `21:26` **You**

Cept Henry


**783.** `21:26` **Meredith Lamb (+14169386001)**

Of course


**784.** `21:27` **Meredith Lamb (+14169386001)**

I started watching this new show


**785.** `21:27` **You**

But I don’t have a list


**786.** `21:27` **Meredith Lamb (+14169386001)**

There was a line in it


**787.** `21:27` **Meredith Lamb (+14169386001)**

I was like wtf


**788.** `21:27` **You**

Just so you know


**789.** `21:27` **Meredith Lamb (+14169386001)**

They were wondering where some guy was


**790.** `21:27` **You**

Yeah


**791.** `21:28` **Meredith Lamb (+14169386001)**

And the girl goes he moved off to blank\. I don’t know the location to live a pansexual life doing therapeutic ketamine\.


**792.** `21:28` **Meredith Lamb (+14169386001)**

lol


**793.** `21:28` **Meredith Lamb (+14169386001)**

It’s a new show


**794.** `21:28` **You**

Rofl


**795.** `21:28` **Meredith Lamb (+14169386001)**

I’m like is this a thing?


**796.** `21:28` **You**

Maybe you shouldn’t watch you wil get ideas


**797.** `21:30` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**798.** `21:30` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**799.** `21:30` **Meredith Lamb (+14169386001)**

lol


**800.** `21:30` **Meredith Lamb (+14169386001)**

I was like wtf I have research to do


**801.** `21:30` **Meredith Lamb (+14169386001)**

Kidding


**802.** `21:31` **You**

different


**803.** `21:31` **Meredith Lamb (+14169386001)**

I don’t like how you catch on


**804.** `21:32` **You**

Problem is Mer\.\. there isn't much I miss, it will probably annoy you a lot\.\. if not already :\(


**805.** `21:32` **You**

I cannot help it


**806.** `21:33` **Meredith Lamb (+14169386001)**

Definitely not annoying


**807.** `21:33` **Meredith Lamb (+14169386001)**

Endearing 🙃


**808.** `21:33` **You**

lol sure


**809.** `21:33` **You**

I should take a screenshot and save it for later


**810.** `21:33` **Meredith Lamb (+14169386001)**

Your receipt


**811.** `21:34` **You**

how is Mar tonight?


**812.** `21:34` **Meredith Lamb (+14169386001)**

She said “so dad talked to me about dating apps today”


**813.** `21:35` **You**

hmm'


**814.** `21:34` **Meredith Lamb (+14169386001)**

I tried to avoid it but wasn’t successful


**815.** `21:35` **Meredith Lamb (+14169386001)**

lol


**816.** `21:35` **You**

avoid the conversation?


**817.** `21:35` **Meredith Lamb (+14169386001)**

Reaction: 🙄 from Meredith Lamb
He also told her he waited to join them until I got my apartment but meanwhile your mom has been dating for MONTHS


**818.** `21:35` **Meredith Lamb (+14169386001)**

>
Yeah

*💬 Reply*

**819.** `21:36` **You**

ah well\.\.\. what did she say


**820.** `21:36` **You**

did she say Ikjnow


**821.** `21:41` **Meredith Lamb (+14169386001)**

Yeah she literally said “I know”


**822.** `21:41` **Meredith Lamb (+14169386001)**

lol


**823.** `21:41` **Meredith Lamb (+14169386001)**

I asked that


**824.** `21:42` **You**

ah well


**825.** `21:42` **You**

I will have a hard time winning her and maele over


**826.** `21:42` **Meredith Lamb (+14169386001)**

No you won’t


**827.** `21:42` **Meredith Lamb (+14169386001)**

Maybe Maelle because she is quiet like her dad


**828.** `21:43` **Meredith Lamb (+14169386001)**

Like her and Andrew never talk bc they are both quiet lol


**829.** `21:43` **Meredith Lamb (+14169386001)**

Marlowe will be good


**830.** `21:43` **Meredith Lamb (+14169386001)**

Maelle will feel awkward and quiet


**831.** `21:43` **Meredith Lamb (+14169386001)**

Like she doesn’t even like getting together with Julian and cassy by herself bc she says it is awkward


**832.** `21:44` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 21:44:31 \-0400
|
| She has known them her whole life
|
| Version: 1
| Sent: Mon, 14 Jul 2025 21:44:08 \-0400
|
| She had known them her whole life


**833.** `21:44` **Meredith Lamb (+14169386001)**

Aunt and uncle


**834.** `21:44` **Meredith Lamb (+14169386001)**

Kinda weird


**835.** `21:44` **You**

some people are like that\.\. nothing wrong\.


**836.** `21:44` **Meredith Lamb (+14169386001)**

So she won’t adapt well for sure


**837.** `21:45` **You**

just needs patience and right approach\.


**838.** `21:45` **Meredith Lamb (+14169386001)**

But as long as I’m there she is fine


**839.** `21:45` **Meredith Lamb (+14169386001)**

Same with Marlowe\. As long as I’m there she is good


**840.** `21:46` **You**

well maybe in a few years it will be all good and we can hang out\.\.


**841.** `21:46` **You**

2


**842.** `21:46` **You**

years


**843.** `21:46` **Meredith Lamb (+14169386001)**

Few years\. Eesh


**844.** `21:46` **Meredith Lamb (+14169386001)**

They aren’t that anxious lol


**845.** `21:46` **You**

I am joiking but I honestly cannot see a time any time soon\.


**846.** `21:47` **Meredith Lamb (+14169386001)**

Doesn’t need to be soon


**847.** `21:48` **You**

to meet them\.\. lol let alone hang out\.\.  yeah i know i know\.\. don't worry it'll be fine you'll see\.\. it's all about being optimistic\!\!


**848.** `21:48` **Meredith Lamb (+14169386001)**

It will work out you will see


**849.** `21:48` **Meredith Lamb (+14169386001)**

Your side will be the more complicated one


**850.** `21:49` **You**

won't


**851.** `21:49` **You**

I will have more freedom than you FOR SURE\!\!


**852.** `21:49` **Meredith Lamb (+14169386001)**

😢 Well I will have some


**853.** `21:50` **Meredith Lamb (+14169386001)**

Quit writing me off


**854.** `21:50` **Meredith Lamb (+14169386001)**

lol


**855.** `21:50` **You**

Reaction: ❤️ from Meredith Lamb
https://open\.spotify\.com/track/3NLrRZoMF0Lx6zTlYqeIo4?si=0d694a2bc6d44b61


**856.** `21:50` **You**

appropriate


**857.** `21:51` **Meredith Lamb (+14169386001)**

Been a while since I heard that song


**858.** `21:52` **You**

feels like a winner


**859.** `21:52` **Meredith Lamb (+14169386001)**

Definitely


**860.** `21:56` **You**

wow finding some sad ones tonight I forgot about\.


**861.** `21:56` **You**

https://open\.spotify\.com/track/507bYMYfbm6sUS9iEAaeSd?si=6e9de4c1ebf74cb0


**862.** `22:00` **Meredith Lamb (+14169386001)**

I kind of remember this song but not really\. Like it


**863.** `22:00` **You**

Broken\.\. yeah I remember that song well\.


**864.** `22:02` **You**

https://open\.spotify\.com/track/0bJfgUyjfPJYqRgUxb12Eh?si=51249f43b10745fb


**865.** `22:02` **You**

new one for me


**866.** `22:03` **You**

>
not writing you off\.\. but you know the future looks pretty shitty\.\. lot's of chatting\.\. :\)  I mean I will take it\.\.\.\.\.\.

*💬 Reply*

**867.** `22:05` **Meredith Lamb (+14169386001)**

>
Yeah same

*💬 Reply*

**868.** `22:07` **Meredith Lamb (+14169386001)**

>
There will be a day eventually\. There has to be…\.

*💬 Reply*

**869.** `22:12` **You**

lol


**870.** `22:13` **You**

See look what you did you got me lol’ing at sad shit that isn’t funny


**871.** `22:14` **Meredith Lamb (+14169386001)**

It wasn’t funny\. It was true


**872.** `22:17` **You**

I mean eventually basically means sometime in forever\.\. so of course it is technically true


**873.** `22:18` **Meredith Lamb (+14169386001)**

By there must be a time we can actually pinpoint


**874.** `22:19` **You**

I mean if only we had a time telescope\.\.  one of those radio ones that can see really really far away\.


**875.** `22:19` **You**

🙄


**876.** `22:21` **You**

Reaction: 😮 from Meredith Lamb
Well all the bins are packed and locked up 5 down 2 to go\.\. pack those the I gotta clean up the house pack up shir I don’t need store in garage then we just keep going next week\.


**877.** `22:22` **You**

>
Wasn’t quite sure what you meant here…

*💬 Reply*

**878.** `22:25` **Meredith Lamb (+14169386001)**

I MEANT… lol that there must be a day we can plan in the future at some point that isn’t too far away


**879.** `22:26` **You**

Yeah I don’t see it I tried thinking about it the other night\.\., and isn’t too far is relative, that could be September\.


**880.** `22:30` **Meredith Lamb (+14169386001)**

No just no\.


**881.** `22:30` **Meredith Lamb (+14169386001)**

September = no\.


**882.** `22:31` **You**

October the  sheesh sorry I rushed it


**883.** `22:32` **You**

Oh wait you will be in Denver for a week in October then you have thanksgiving so that is out so prolly most of October out


**884.** `22:32` **You**

Keep track in my head


**885.** `22:33` **Meredith Lamb (+14169386001)**

Being a meanie 👖 again


**886.** `22:35` **You**

Just doing math and you cannot dispute it


**887.** `22:35` **You**

Doesn’t make me a meanie


**888.** `22:35` **You**

It is just the truth as you said earlier


**889.** `22:38` **Meredith Lamb (+14169386001)**

I didn’t say any such thing


**890.** `22:41` **You**

>
Here

*💬 Reply*

**891.** `22:41` **You**

Anyhow I think you are getting tired or distracted or frustrated but something\.\. maybe we call it a night?


**892.** `22:42` **Meredith Lamb (+14169386001)**

I’m tired……\.\. I was quietly waiting to see if Andrew was going to talk to me\. He just got home\.


**893.** `22:42` **Meredith Lamb (+14169386001)**

Doesn’t seem like it


**894.** `22:42` **Meredith Lamb (+14169386001)**

Phew


**895.** `22:43` **Meredith Lamb (+14169386001)**

But I am super tired and ready for bed


**896.** `22:43` **Meredith Lamb (+14169386001)**

5am was early for me and I didn’t sleep consistently last night\. Was anxious


**897.** `22:44` **Meredith Lamb (+14169386001)**

I miss you and love you


**898.** `22:55` **You**

😔 same night xo


**899.** `23:02` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 23:05:36 \-0400
|
| Think I am going to need to focus on something else for a while instead of looking for opportunities\.  Maybe focusing on fixing my house will distract me from our challenges\.\. maybe work, or something else here’s hoping\. I am going to sleep will see you at office tomorrow\.
|
| Version: 1
| Sent: Mon, 14 Jul 2025 23:02:24 \-0400
|
| Think I am going to need to focus on something else for a while instead of looking for opportunities\.  Maybe focusing on fixing my house will distract me from our challenges\.\. here’s hoping\. I am going to sleep will see you at office tomorrow\.


**900.** `23:03` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 14 Jul 2025 23:08:20 \-0400
|
| You actually have more than enough to deal with anyways and while I realize this I should be more understanding and just back off\.  Hope you at least get some sleep tonight, don’t worry about planning, I am not going to either, especially after today with Andrew and all the commitments you have coming up just take care of your stuff\.
|
| Version: 1
| Sent: Mon, 14 Jul 2025 23:03:23 \-0400
|
| You actually have more than enough to deal with anyways I need to realize this too\.  Should have earlier\.  Hope you at least get some sleep tonight\.


