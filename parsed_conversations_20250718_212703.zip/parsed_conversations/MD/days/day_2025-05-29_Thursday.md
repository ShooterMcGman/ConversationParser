# Daily Conversation: 2025-05-29 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-29 |
| **Day** | Thursday |
| **Week** | 7 |
| **Messages** | 109 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-29T09:24 - 2025-05-29T23:36 |

## 📝 Daily Summary

This day contains **109 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `09:24` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**002.** `15:32` **You**

I called her she didn’t let on to anything


**003.** `15:34` **You**

Don’t worry about me


**004.** `15:50` **You**

❤️ u amazing night


**005.** `16:07` **Meredith Lamb (+14169386001)**

Plan b obtained\. We really are acting like teenagers\. 😜


**006.** `16:08` **You**

Reaction: ❤️ from Meredith Lamb
🥰 feels good though


**007.** `18:14` **Meredith Lamb (+14169386001)**

Sigh just finished groceries and lcbo\. Holy crap\. $$ lol


**008.** `18:17` **You**

jesus that took a while


**009.** `18:17` **You**

I just got back to the safety of my basement


**010.** `18:39` **Meredith Lamb (+14169386001)**

I was asking Mac if I will be sick tonight\. She said nauseous lol at least I’m used to that


**011.** `18:39` **Meredith Lamb (+14169386001)**

:p


**012.** `18:39` **You**

from Plan B


**013.** `18:39` **You**

jesus


**014.** `18:39` **You**

you told Mac you took a Plan B??


**015.** `18:40` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**016.** `18:40` **You**

😵


**017.** `18:40` **Meredith Lamb (+14169386001)**

Yeah bc what if I’m sick tonight


**018.** `18:41` **Meredith Lamb (+14169386001)**

I took it before in my early 20s but forget the impact


**019.** `18:41` **You**

Reaction: 😂 from Meredith Lamb
\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.still processing\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


**020.** `18:41` **Meredith Lamb (+14169386001)**

I can’t have her asking me to do a bunch of shit tonight


**021.** `18:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**022.** `18:42` **You**

I got the note on the way home\.


**023.** `18:42` **You**

Also I am getting a doctors appointment this week\.


**024.** `18:42` **You**

Going to get it done\.


**025.** `18:45` **Meredith Lamb (+14169386001)**

I have a physical on thurs with my dr and will talk to her


**026.** `18:45` **You**

yeah but then you have to be "on" something\.\. when I can just do it and then it is just over\.


**027.** `18:46` **You**

I don't mind\.\. tbh\.\. I just don't think that is fair to have you do that when I could just do this\.


**028.** `18:48` **Meredith Lamb (+14169386001)**

It would probably be faster for me\. I will talk to her


**029.** `18:52` **You**

Faster for yku sure but still not fair in long run\. Talk to her and then maybe you and I could talk?


**030.** `19:38` **Meredith Lamb (+14169386001)**

Yeah k it’s fine honestly


**031.** `19:38` **You**

okie dokie\.\. look forward to chatting about it ☺️


**032.** `19:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**033.** `19:55` **You**

very cute


**034.** `19:55` **You**

I am sure they will love them and love you\!


**035.** `20:45` **You**

Oh and on the DL wish Mac a happy bday from me I look forward
To more officially meeting her\.


**036.** `20:52` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**037.** `20:52` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**038.** `20:53` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**039.** `20:58` **You**

Really impressive mer\.\.  Your girls are so lucky to have a mom like you\.


**040.** `21:02` **Meredith Lamb (+14169386001)**

Mac is complaining I forgot to get cocktail glasses


**041.** `21:02` **Meredith Lamb (+14169386001)**

Omg


**042.** `21:03` **You**

I am sure they can make do


**043.** `21:03` **You**

lol


**044.** `21:19` **Meredith Lamb (+14169386001)**

Right omg


**045.** `21:20` **You**

You just be exhausted despite your midday nap\.


**046.** `21:23` **Meredith Lamb (+14169386001)**

My country addition

*📎 1 attachment(s)*

**047.** `21:24` **You**

Lol\.  So much effort into this\.  Looks great\.


**048.** `21:34` **Meredith Lamb (+14169386001)**

I’m done for the night\. I am exhausted ring cameras, clear\. Lol


**049.** `21:35` **You**

Well done mer\.\.  pretty impressive\.\. will be memorable for sure


**050.** `21:35` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**051.** `21:36` **Meredith Lamb (+14169386001)**

I got a thank u\!


**052.** `21:36` **Meredith Lamb (+14169386001)**

🙄


**053.** `21:37` **You**

lol did they all pile down into there space and leave you be?


**054.** `21:42` **Meredith Lamb (+14169386001)**

They aren’t here yet\!


**055.** `21:42` **Meredith Lamb (+14169386001)**

ETA 10\.15 I guess


**056.** `21:43` **You**

Ouch well I won’t be awake to get an update will have to read in the morning\.\. hopefully they and Andrew are in good moods\.


**057.** `21:43` **Meredith Lamb (+14169386001)**

Gym in morning?


**058.** `21:44` **You**

Of course


**059.** `21:44` **You**

No one said anything tonight btw


**060.** `21:44` **Meredith Lamb (+14169386001)**

That seems odd


**061.** `21:44` **You**

So I will just go back to my routine\.


**062.** `21:44` **Meredith Lamb (+14169386001)**

Were you surprised?


**063.** `21:45` **You**

A little


**064.** `21:45` **You**

But certainly not disappointed


**065.** `21:45` **Meredith Lamb (+14169386001)**

Thats good… so your head is ok and you are going to bed ok?


**066.** `21:46` **You**

My head?


**067.** `21:49` **Meredith Lamb (+14169386001)**

Like mentally


**068.** `21:50` **Meredith Lamb (+14169386001)**

Your mindset


**069.** `21:50` **You**

Sure it’s great\.


**070.** `21:50` **Meredith Lamb (+14169386001)**

Sarcasm?


**071.** `21:52` **You**

I am fine Mer\.  I told you not to worry about me\.


**072.** `21:52` **Meredith Lamb (+14169386001)**

k, I hope so ❤️


**073.** `21:53` **You**

❤️


**074.** `21:54` **Meredith Lamb (+14169386001)**

I’ve been missing you since you left but super thankful you came up\. xo


**075.** `21:56` **You**

Reaction: ❤️ from Meredith Lamb
Yeah honestly the more I see you and spend time with you the more I love you doesn’t make sense but it is true\.  It is easier mentally but I do miss you and that will be hard until this is over\.  I am glad I came too\.  Wish I could wake up next to you every morning like this morning\.\. or just watch you nap on the couch\.  All good stuff for me\.


**076.** `21:59` **Meredith Lamb (+14169386001)**

I feel the same way\. It is really wild and perplexing to me also at times but sometimes not because what’s not to love about you\. 🫠😉


**077.** `22:03` **You**

I will be ok Mer\.   I will find ways to stay busy over the next week\.\. will continue to do my workouts and my morning coffee and meditation at my park with my birds\.\. maybe find some time to talk to jim\.\. grab him for a beer or something after work\. Time will def not go by fast these next 60\-90 days\.\. but we will get through\.


**078.** `22:04` **You**

>
There are lots of things not to love\.\. you will find them I promise

*💬 Reply*

**079.** `22:09` **Meredith Lamb (+14169386001)**

Sorry girls got here


**080.** `22:09` **You**

Send me all the pics and videos and shit that you want
To share as
Well\.\.
I am happy for you and hope
This turns out as you have envisioned it\.


**081.** `22:10` **You**

>
Figured

*💬 Reply*

**082.** `22:10` **Meredith Lamb (+14169386001)**

Their mothers all sent wine


**083.** `22:10` **You**

Nice\.


**084.** `22:10` **Meredith Lamb (+14169386001)**

And Cinnabon


**085.** `22:10` **Meredith Lamb (+14169386001)**

And Craig’s cookies


**086.** `22:10` **Meredith Lamb (+14169386001)**

And chocolate


**087.** `22:10` **Meredith Lamb (+14169386001)**

Sheesh


**088.** `22:11` **You**

lol


**089.** `22:11` **Meredith Lamb (+14169386001)**

>
I hope so but if you are not, it is allowed\.

*💬 Reply*

**090.** `22:12` **You**

If I am not well\.\. 🙂 I will figure it out\.


**091.** `22:13` **Meredith Lamb (+14169386001)**

\*We\* will\.


**092.** `22:17` **You**

We will later\.\. I will now\.   I want you to focus on Andrew taxes yourself and your situation\.\. it would suck for me to be all done and you still stuck there\.


**093.** `22:19` **You**

But for now I will figure me out\. I am going to try to keep as much away from you as I can\.\. I am not going to self destruct or anything and if anything serious happened and I was having a hard time or coming to grips, I would talk to you\.\. maybe lol\.


**094.** `22:22` **Meredith Lamb (+14169386001)**

🙄


**095.** `22:22` **Meredith Lamb (+14169386001)**

Everything is going to be okay so just have faith


**096.** `22:24` **You**

lol and in that I am going to go to bed\.\. I love you Meredith\.\. have a great time you deserve it\.\. and Remeber focus on you and your
Situation you can’t fix me\.\. and you can only be there with me if you are sorted\.


**097.** `22:25` **Meredith Lamb (+14169386001)**

Sweet dreams 😴 ❤️ I love you


**098.** `22:25` **You**

Nite I love you too\.\. xo ❤️❤️❤️❤️


**099.** `23:26` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**100.** `23:31` **You**

Cute


**101.** `23:31` **You**

Can’t sleep yet\.\. 🙁


**102.** `23:31` **You**

Watching my geeky gamer movie but I think you’d kinda like it maybe


**103.** `23:32` **Meredith Lamb (+14169386001)**

They are listening to country music :\)


**104.** `23:32` **You**

Well that’s something


**105.** `23:32` **Meredith Lamb (+14169386001)**

>
You aren’t done it yet?

*💬 Reply*

**106.** `23:32` **You**

Nope was working earlier on the stupid thing I have to do tomorrow


**107.** `23:33` **Meredith Lamb (+14169386001)**

Oh I forgot\! What time


**108.** `23:35` **You**

Reaction: 😂 from Meredith Lamb
10 am you will be asleep


**109.** `23:36` **You**

You don’t need to show up just enjoy your sleep in and day off


