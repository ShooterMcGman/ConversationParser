# Daily Conversation: 2025-06-11 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-11 |
| **Day** | Wednesday |
| **Week** | 9 |
| **Messages** | 502 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-11T06:01 - 2025-06-11T22:58 |

## 📝 Daily Summary

This day contains **502 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `06:01` **Meredith Lamb (+14169386001)**

Good morning ❤️
😢 my first morning in a while waking with no msg from Scott 😢


**002.** `06:50` **You**

Morning mer\.\. just in my own head\.  Didn’t sleep well had a lot on my mind I was thinking through\.   Little self loathing this morning\. Should know better by now right\.


**003.** `06:53` **You**

Love you\.\. ❤️ of course\.\. and always\.\. just coming to some realizations\.\. going to talk with therapist about them today\.


**004.** `06:57` **Meredith Lamb (+14169386001)**

Self loathing? What on earth? Scott……\.


**005.** `06:57` **Meredith Lamb (+14169386001)**

I’m so confused\.


**006.** `06:59` **Meredith Lamb (+14169386001)**

I literally laid in bed this morning for like 10 min before getting up thinking about how great you are and how lucky I am and you are self loathing? wtf


**007.** `07:06` **You**

I keep doing the same thing looking back seeing things, reading things\.\. I truly appreciate you making the blog private\.\. it was a place I would get lost\.  Before we got into it last night about the blog there is an older version lamberrymere with an “e” and it is merv\! … I am a 27 year old mba student… I never went back to it after I told you I wouldn’t\.  Covers the Jeremy er a bit\.  I shouldn’t see any of this\.\. like you cannot see mine\.  It is easier\.\. I think I envy those memories they are immortalized in a way ours will never be\. I feel young with you but am constantly reminded I am not\.
I mean this is my nature\.\. I search,
I want to understand, I look and I spend too much time on it\. And when it is there I read it\.  We won’t have that\.\. I don’t know why it bothers me because I do feel so lucky to have you\.  The more I dig into this the more I understand what is triggering me\.  It isn’t the individuals\.\. it is time and experiences and how you laid it all out there\.  I think I realized how bad I wanted something like that my whole life and never found it until now\.\. after it is too late to have all of these experiences\.
This is about me mer not you\.\. pls just be patient I have made progress I can see the source of my frustration/hurt but it is my own doing,  it yours\.  I guess someday I would like to read words about us like that or hear you talk about me that way\.  I am sorry but of a mess here\.


**008.** `07:09` **You**

https://open\.spotify\.com/track/2Bo0hh0yoQReC4reJav5DT?si=2CtvMViRRl6ZzBiMXxAlUg
Where my head is at today\.  So fucking dumb\.  This never happened to me in 25 years to fall apart over something so stupid\.


**009.** `07:10` **You**

This isn’t for you to fix not to overwhelm you but you deserve to know, I don’t like keeping feelings from you\.


**010.** `07:11` **Meredith Lamb (+14169386001)**

I mean the searching, researching, digging… I love that so much about you\. It is part of what makes you an amazing person\. But obviously not if it is going to completely tear you down\!  Where is this one with an ‘e’? Do you have a link or is it from that weird web site?


**011.** `07:11` **Meredith Lamb (+14169386001)**

If it was during my mba it was still pretty later on


**012.** `07:11` **You**

It isn’t worth your time


**013.** `07:11` **You**

And pls just leave it\.


**014.** `07:12` **Meredith Lamb (+14169386001)**

But is it like a public site?


**015.** `07:12` **Meredith Lamb (+14169386001)**

lol


**016.** `07:12` **You**

You cannot do anything about it


**017.** `07:12` **You**

Same with the one you just made private


**018.** `07:12` **Meredith Lamb (+14169386001)**

One sec


**019.** `07:12` **You**

It is still there some of it


**020.** `07:12` **You**

The way back machine


**021.** `07:12` **You**

Go there


**022.** `07:13` **You**

And search for lamberry


**023.** `07:14` **You**

I mean even after last night after this morning hearing your worry about the blog being private just makes me curious \.\. even knowing it will do nothing but tear me\.\. lol I am sorry fucking stupid\.


**024.** `07:17` **You**

I am going to the sauna and have a shower and go home…\. I will just have to figure this all out\. I tried to explain it all in that long message above not sure if you had a chance to read it all or not\.\. I think I just need to literally not look you up online at all ever again…\. Hard when you are literally always on my mind\.\. but yeah this is just ripping me up thinking about this\.\. chat gpt tells me I am grieving and you know what that is what it feels like\.  Smart AI\.


**025.** `07:20` **Meredith Lamb (+14169386001)**

>
No just because of people at work, your kids\. Etc etc

*💬 Reply*

**026.** `07:20` **Meredith Lamb (+14169386001)**

There is nothing weird on it


**027.** `07:20` **Meredith Lamb (+14169386001)**

Or like inappropriate


**028.** `07:20` **Meredith Lamb (+14169386001)**

My mom and bro had the link


**029.** `07:23` **Meredith Lamb (+14169386001)**

>
I did read and it and if you are grieving that is okay\. Nothing wrong with that as long as it doesn’t wreck you unnecessarily\. We have time to have our own completely unique relationship snd experiences\. Scott, despite having prior relationship I have never ached for anyone in this way nor felt so at home with them\.  That is unique to YOU\. Everything is better about you\. And you will eventually see that\. Just be patient\.

*💬 Reply*

**030.** `07:23` **Meredith Lamb (+14169386001)**

❤️❤️❤️


**031.** `07:51` **Meredith Lamb (+14169386001)**

Ps\. You realize I was really stupid and immature in my 20s right? So whatever is on that blog is just stupid shit\. Nothing deep\.


**032.** `07:53` **You**

>
I appreciate what you are saying mer\.\. I will try\.

*💬 Reply*

**033.** `07:55` **You**

>
Again it isn’t quite about that but
you LIVED\.  All caps intended\.\. very envious, like I said I feel like that is lost to me and that is what I never had\.\. my crazy wasn’t living it was just what it was\.  It didn’t fill me with memories and experiences I ever really look back and think on\.\. it was empty\.  It isn’t your fault yours was not\.\. like I said this is my problem I hope you can appreciate the distinction\.

*💬 Reply*

**034.** `07:58` **Meredith Lamb (+14169386001)**

I can but it sounded like you sure lived while in uni so I don’t fully get it\. I just extended my time a bit longer\. Lol


**035.** `08:00` **You**

No I didn’t\. Rinse and repeat\.  I had a few relationships that were long term, but post 17\-18 there wasn’t much joy\.  I just functioned, faked it, played along\.  Next step, next step\.\. that was life a series of what’s next, what is expected of me\.\. ok let’s go do that\.  I think you misunderstood yeah I had fun\.\. but it wasn’t substantive, shaping, memorable\.


**036.** `08:00` **Meredith Lamb (+14169386001)**

Well that’s why you met me\. 😇


**037.** `08:01` **Meredith Lamb (+14169386001)**

I did forget that my original blog was mere tho\.


**038.** `08:01` **Meredith Lamb (+14169386001)**

I had a really good friend at the time Lara and she always put an e on the end


**039.** `08:01` **Meredith Lamb (+14169386001)**

So I was more used to that in the beginning


**040.** `08:02` **Meredith Lamb (+14169386001)**

She was the first person who ever called me mer


**041.** `08:02` **Meredith Lamb (+14169386001)**

I was always merv prior


**042.** `08:06` **You**

Yeah I didn’t expect it to pop up but there it was\.\. again nothing other than same old stuff a couple of posts
About her\. Few convos with Chris about I don’t know what\.\. nothing crazy\.\. I didn’t even bother with the Reno blog but is pretty much all in there\.


**043.** `08:06` **You**

Anyways I am done looking I don’t want to anymore\.


**044.** `08:06` **Meredith Lamb (+14169386001)**

“A couple posts about her”? Who?


**045.** `08:07` **You**

Jer


**046.** `08:07` **Meredith Lamb (+14169386001)**

Reno blog is literally all Reno


**047.** `08:07` **Meredith Lamb (+14169386001)**

We gutted our old house and I documented the whole thing


**048.** `08:10` **Meredith Lamb (+14169386001)**

I can only find one screenshot


**049.** `08:10` **Meredith Lamb (+14169386001)**

Please tell me that is all you found lol


**050.** `08:10` **Meredith Lamb (+14169386001)**

Not loving that this is living on


**051.** `08:11` **Meredith Lamb (+14169386001)**

Gavin said I had maniah tendencies\. I forgot about that\. Maybe he wasn’t as nice as I thought lol


**052.** `08:11` **Meredith Lamb (+14169386001)**

I probably said shit right back to him tho to be fair


**053.** `08:18` **You**

I found a couple


**054.** `08:23` **You**

>
I have always wondered about your use of the frantic/nervous lol you still have to do it even when typing

*💬 Reply*

**055.** `08:24` **Meredith Lamb (+14169386001)**

>
Huh?

*💬 Reply*

**056.** `08:24` **Meredith Lamb (+14169386001)**

I mean, that particular blog is from 20 years ago\. Do you really want shit that you were doing 20 years ago just like out there for people?


**057.** `08:25` **Meredith Lamb (+14169386001)**

It is silly and kind of stupid


**058.** `08:25` **You**

>
Just sometimes you out lol T the end of a sentence where you are clearly anxious\.\. kind like how you laugh irl\.  Wow I haven’t used that acronym in a long time

*💬 Reply*

**059.** `08:26` **You**

>
Nope which is why I never had one\.\. dad and I had a conversation about my exploits and he suggested maybe not a good idea to document them\.

*💬 Reply*

**060.** `08:26` **Meredith Lamb (+14169386001)**

Well I was like 26/27 so yeah makes me a bit anxious


**061.** `08:27` **Meredith Lamb (+14169386001)**

I didn’t document exploits on the blogs


**062.** `08:27` **Meredith Lamb (+14169386001)**

I did in my diaries on paper tho


**063.** `08:27` **Meredith Lamb (+14169386001)**

But got rid of those bc … Andrew


**064.** `08:28` **You**

Yeah you mentioned he read your journals and kind of learned about your past just not sure how much he got of it\.


**065.** `08:28` **Meredith Lamb (+14169386001)**

Not much


**066.** `08:28` **Meredith Lamb (+14169386001)**

I destroyed the bad stuff before he got to them


**067.** `08:29` **Meredith Lamb (+14169386001)**

He got to a very late one written during my breakup with Andrew


**068.** `08:30` **You**

lol destroyed the bad stuff


**069.** `08:30` **You**

Omg


**070.** `08:30` **Meredith Lamb (+14169386001)**

So you will never find them by accident


**071.** `08:30` **Meredith Lamb (+14169386001)**

Well what he would consider bad stuff


**072.** `08:30` **Meredith Lamb (+14169386001)**

To me it wasn’t


**073.** `08:30` **Meredith Lamb (+14169386001)**

It was just life


**074.** `08:44` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 11 Jun 2025 08:44:49 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Wed, 11 Jun 2025 08:30:29 \-0400
| >
| > lol destroyed the bad stuff
|
| You need to get over these thoughts\. Not “bad”\. Just bad to others I guess\. But honestly yes I have a past, it exists and I hate pretending it doesn’t\.
|
| Version: 1
| Sent: Wed, 11 Jun 2025 08:44:22 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Wed, 11 Jun 2025 08:30:29 \-0400
| >
| > lol destroyed the bad stuff
|
| You need to get over these thoughts\. Not “bad”\. Just bad to others I guess\. But honestly yes I have a past, it exists and I hate pretending it does t\.


**075.** `08:46` **Meredith Lamb (+14169386001)**

I get the ocd thoughts because I get that also\. However, just talk to me about those thoughts instead of struggling alone and maybe that will help\.


**076.** `08:46` **You**

I told you you don't have to\.\. I am fairly certain I explained above\. The only reason I am looking right now is to provide you the links I find\.\. then I am never fucking looking again\.


**077.** `08:57` **Meredith Lamb (+14169386001)**

Yes, I read and understand\. It isn’t about “needing” to\. I want to be in everything with you together\.


**078.** `09:27` **Meredith Lamb (+14169386001)**

Reaction: ❓ from Meredith Lamb
Can you just call me on teams at some point and tell me you are fine\.


**079.** `09:53` **Meredith Lamb (+14169386001)**

Scott……


**080.** `09:53` **Meredith Lamb (+14169386001)**

Grrrrrr


**081.** `09:53` **You**

You have a meeting in a few minutes\.\. won't have time\.


**082.** `09:54` **Meredith Lamb (+14169386001)**

Right but you could have responded and just said that :p


**083.** `09:54` **You**

Said what\.\. srry I had to haul maddie's ass out of bed she wasn't ready to go went back to sleep


**084.** `09:55` **Meredith Lamb (+14169386001)**

I have to do midstream reporting … because …\.\.Pauline


**085.** `09:55` **You**

oh\.\. here\.\. this is what I found using little to no effort at all\.
LamberryMere
https://web\.archive\.org/web/20050313175636/http://www\.blogger\.com/profile/5241054
https://web\.archive\.org/web/20050321115844/http://lamberrymere\.blogspot\.com:80/2005/02/funny\-90s\.html
https://web\.archive\.org/web/20050322085134/http://lamberrymere\.blogspot\.com:80/2005/03/lambs\-of\-world\-unite\.html
https://web\.archive\.org/web/20041205092423/http://lamberrymere\.blogspot\.com:80/2004/11/land\-down\-under\.html
http://lamberrymere\.blogspot\.com/2004/11/more\-pink\.html
https://web\.archive\.org/web/20050217094254/http://lamberrymere\.blogspot\.com:80/2005\_02\_01\_lamberrymere\_archive\.html
http://lamberrymere\.blogspot\.com/2005/04/hot\-docs\-adventure\.html
https://web\.archive\.org/web/20050325101927/http://lamberrymere\.blogspot\.com:80/2005/02/thursday\-night\-challenge\.html
RadioFuture
https://web\.archive\.org/web/20050226220957/http://braincandy\.ca/radiofuture/index\.php?disp=arcdir
Tempermental
https://web\.archive\.org/web/20050411084759/http://www\.braincandy\.ca/tempermental/
http://www\.braincandy\.ca/tempermental/2002\_07\_28\_archive\.php
Diary\-X
http://almostconscious\.diary\-x\.com/journal\.cgi?action=archive


**086.** `09:55` **Meredith Lamb (+14169386001)**

>
You were so silent

*💬 Reply*

**087.** `09:55` **You**

again\.\. not doing it again\.\. or looking anymore\.\. done


**088.** `10:05` **Meredith Lamb (+14169386001)**

Omg Chris’ blogs\. That is a rabbit hole


**089.** `10:06` **Meredith Lamb (+14169386001)**

You are talented\.


**090.** `10:06` **You**

no I am creepy and weird


**091.** `10:06` **Meredith Lamb (+14169386001)**

I was like “what the hell is radiofuture?”


**092.** `10:06` **Meredith Lamb (+14169386001)**

I remember temperamental


**093.** `10:06` **Meredith Lamb (+14169386001)**

That was always his screen name when we first met in 2001


**094.** `10:07` **You**


*📎 1 attachment(s)*

**095.** `10:08` **You**

I just wanted you to be aware\.\. again\.\. I am not looking anymore\.\. but that is what you made private last night\.\. 680 pages still there\.\. many of the archive links work which would list all your posts in a given month\.


**096.** `10:08` **You**

kk\.\. now\.\. finished with this\.\.  if you want to know something I can try to help\.\. but other than that\.\. just going to leave the site alone\.


**097.** `12:49` **You**

therapist said you are awful\!\!\!


**098.** `12:50` **You**

and mean spirited


**099.** `12:50` **You**

I was like wow


**100.** `12:50` **You**

dude


**101.** `12:50` **Meredith Lamb (+14169386001)**

WHAT?\!


**102.** `12:50` **You**

calm down\!\!


**103.** `12:51` **You**

oh didn't realize you were on a call sorry\.


**104.** `12:51` **Meredith Lamb (+14169386001)**

I’m on a call with VitalityMD


**105.** `12:51` **You**

Ah ok\.\. yeah naw he didn't say shit like that


**106.** `13:34` **You**

You are literally the most amazing person I have ever met, I love you more than anyone ever, I have been more honest with you than anyone else, I have been vulnerable, and I have already clawed myself out of some pits that I have admittedly thrown myself into\.\. please stop worrying about if I am going to leave\.\. I never will\.\. I love you\.\. ❤️ I am so sorry I am having such a hard time processing all of this shit\.  I am glad that I am able to categorize this and go through it now, but I do think I would have been able to blow by some of this were we together\.  It just isn't in the cards\.\. so better this get's done now\.  KK stop worrying\.


**107.** `13:58` **You**

I think you are going to have to trust me the same as you are asking me to trust you\.


**108.** `14:00` **You**

No heartbreaks\.\.


**109.** `14:05` **Meredith Lamb (+14169386001)**

Yes I’m super trying to trust you the way I ask you to\. Every time I reassure you I think about that\. k therapy\.\. ❤️


**110.** `14:17` **You**

You are super trying to trust me\.\. how can I move this all the way to trust me\.


**111.** `14:22` **You**

Because it is one of those back and forth things right the more concerned I am about your trust the more I am going to be concerned that I am going to drive you away rather than the other way around\. Just something to think about\.  Enjoy therapy\.\. hope it goes well\.


**112.** `14:52` **Meredith Lamb (+14169386001)**

Are you on a call?


**113.** `14:52` **You**

on sec


**114.** `15:54` **You**

https://open\.spotify\.com/track/3HlWVKwU0JqJXqJK9DWHnZ?si=34337384203f4177


**115.** `15:57` **You**

https://open\.spotify\.com/track/6EIVLz5xM1xE29r0OmIkWt?si=89d54289ece14bb3


**116.** `15:58` **You**

SIGN \- Yes I’m super trying to trust you the way I ask you to\. Every time I reassure you I think about that\. k therapy\.\. ❤️
2:05 p\.m\.


**117.** `16:09` **You**

I keep doing the same thing looking back seeing things, reading things\.\. I truly appreciate you making the blog private\.\. it was a place I would get lost\.  Before we got into it last night about the blog there is an older version lamberrymere with an “e” and it is merv\! … I am a 27 year old mba student… I never went back to it after I told you I wouldn’t\.  Covers the Jeremy er a bit\.  I shouldn’t see any of this\.\. like you cannot see mine\.  It is easier\.\. I think I envy those memories they are immortalized in a way ours will never be\. I feel young with you but am constantly reminded I am not\.
I mean this is my nature\.\. I search,
I want to understand, I look and I spend too much time on it\. And when it is there I read it\.  We won’t have that\.\. I don’t know why it bothers me because I do feel so lucky to have you\.  The more I dig into this the more I understand what is triggering me\.  It isn’t the individuals\.\. it is time and experiences and how you laid it all out there\.  I think I realized how bad I wanted something like that my whole life and never found it until now\.\. after it is too late to have all of these experiences\.
This is about me mer not you\.\. pls just be patient I have made progress I can see the source of my frustration/hurt but it is my own doing,  it yours\.  I guess someday I would like to read words about us like that or hear you talk about me that way\.  I am sorry but of a mess here\.


**118.** `16:11` **You**

https://web\.archive\.org/web/20070702093337/http://lamberrymer\.blogspot\.com/2005\_09\_01\_archive\.html


**119.** `16:18` **You**

SEX


**120.** `16:18` **You**

LOL


**121.** `16:44` **You**

Ok you never get to mention me making abrupt decisions again\.


**122.** `17:18` **You**

you might not be able to make it tomorrow\.\. but I will be at the park at 7:45 per usual\.\. just saying as I don't think we will be seeing each other for a bit after that\.  ttyl


**123.** `17:31` **Meredith Lamb (+14169386001)**

I will be there 🙂 but I will be going to bed early tonight


**124.** `17:32` **You**

Same anything that makes days go by faster these days I am usually up for unless I have to stay up


**125.** `17:49` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**126.** `17:50` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**127.** `17:50` **Meredith Lamb (+14169386001)**

So I took 2 seconds to search “unconditional” in my email\.


**128.** `17:50` **Meredith Lamb (+14169386001)**

I knew something would appear immediately\. Constant complaint from Andrew over many years\.


**129.** `17:52` **You**

Absolutely, this is an important and often misunderstood distinction\. Here's a way to frame it clearly and compassionately:
\-\-\-
\*\*Unconditional love\*\* means that your love for someone isn't based on conditions or what they can do for you\. It's about loving them for who they are at their core, through good times and bad\. It’s deep, enduring, and doesn’t just disappear when they make a mistake\.
But \*\*unconditional love does \*not\* mean unconditional tolerance of harmful behavior\*\*\. Loving someone unconditionally doesn't require you to stay in a relationship if they betray your trust or hurt you deeply—like through cheating\. In fact, holding someone accountable is a \*form\* of love—both for yourself and for them\.
When someone cheats, it's a breach of trust and respect, which are fundamental to a healthy relationship\. You can still love them deeply, but choose to set boundaries, take space, or even walk away because your \*self\-respect and emotional well\-being matter too\*\.
Put simply:
\* \*\*Unconditional love\*\* says, \*"I love you even when you're flawed\."\*
\* \*\*Accountability\*\* says, \*"But I won’t allow your flaws to harm me without consequence\."\*
Both can exist at the same time\. Love is about the heart, but relationships also require respect, trust, and responsibility\.
\-\-\-
Would you like this turned into a message you could send her directly, maybe in your own voice and tone?


**130.** `17:53` **Meredith Lamb (+14169386001)**

This is to show you not that I run away from shit, but I have never really I thought I would be with him forever\. Just didn’t\.
I feel completely differently with you\. I can visualize our future together\. I have never done that before\. Just kind of got stuck in somethings…\. Jeremy … andrew\.
I’m not stuck with you\. Choosing you\. So incredibly different\.


**131.** `17:53` **You**

That is how I feel about you above


**132.** `17:53` **You**

that to me is unconditional


**133.** `17:53` **Meredith Lamb (+14169386001)**

That Feb 2021 email exchange as about sex btw\. Only thing we argued about consistently\.


**134.** `17:54` **Meredith Lamb (+14169386001)**

It’s funny bc I remember this incident\. Happened at cottage and I up and left with the girls and drove back to Toronto


**135.** `17:54` **Meredith Lamb (+14169386001)**

Seriously considered separating AGAIN


**136.** `17:54` **You**

I love who you are\.\. not what you can do\.  And I am choosing you as well\.\. I would give you more if I could\.\. I don't know what else there is to give you to assure you of that, but whatever I could do, or give you\.\. it would happen\.


**137.** `17:54` **Meredith Lamb (+14169386001)**

2021


**138.** `17:55` **You**

jesus


**139.** `17:55` **You**

Reaction: 😂 from Meredith Lamb
Its a wonder you even want to have sex with me\.


**140.** `17:55` **You**

after all of that


**141.** `17:55` **You**

I don't think Andrew understood unconditional and accountable


**142.** `17:56` **Meredith Lamb (+14169386001)**

No and he still doesn’t\.


**143.** `17:56` **Meredith Lamb (+14169386001)**

I bet I could find many other examples but need to take dogs to park


**144.** `17:57` **You**

btw the sex thing\.\. seriously I never really quite knew it was that bad\.\. always figured it was exagerrated because I couldn't contemplate it being real\.\.


**145.** `17:57` **You**

but again\.\. if that is a problem\.\. we don't have to\.\. cause honestly you have been through enougj


**146.** `17:59` **Meredith Lamb (+14169386001)**

What? I love sex with you\. \(If that wasn’t obvious\.\)
To me it is very dependent on the connection etc etc\. Unfortunately Andrew just ruined all of that very early on\. I tried to make the best of it but life was a challenge\. I always knew I would leave eventually\. So did he\.


**147.** `18:00` **You**

That is a tough way to live through a relationship for both knowing that


**148.** `18:01` **You**

Reaction: ❤️ from Meredith Lamb
Anyhow I am glad we click that way because I love it too\.  And I never thought that would happen\.


**149.** `18:12` **You**

Oh and the everyday thing put a pin in that\.\. that is going to happen\.  Love you talk to you later\.


**150.** `18:14` **Meredith Lamb (+14169386001)**

This is in response to a question “can I ask what you are thinking?” This was after I left and took the girls\.

*📎 1 attachment(s)*

**151.** `18:15` **Meredith Lamb (+14169386001)**

Constant temper tantrums 🙄


**152.** `18:16` **You**

Eesh I mean j and I fought but never about the stuff you mentioned not to that degree\.


**153.** `18:17` **Meredith Lamb (+14169386001)**

I will just be so happy beyond belief to be done\. However, I will still have to deal with this shit I’m sure\.


**154.** `18:18` **You**

Not from me\.


**155.** `18:19` **You**

And we can deal together I can support you\.\. you can lean on me\.\. and I know I can you\.\.


**156.** `18:21` **Meredith Lamb (+14169386001)**

Another one of the 10\+ times I wanted to separate :p\. He was coercing/pressuring me as usual\. I told him\. Then this was his response\.

*📎 1 attachment(s)*

**157.** `18:22` **Meredith Lamb (+14169386001)**

>
I definitely trust this\.

*💬 Reply*

**158.** `18:23` **Meredith Lamb (+14169386001)**

>
I’m not looking at anymore\. They are all so annoying to read\.

*💬 Reply*

**159.** `18:23` **Meredith Lamb (+14169386001)**

My phone archives old stuff\. But on my computer I could find really old stuff with the EXACT same conversations\.


**160.** `18:24` **Meredith Lamb (+14169386001)**

Just sitting at the park\.


**161.** `18:33` **You**

Yah don’t look back it isn’t going to help you\.  I believe that you are 1000% justified in doing this probably 30 times over\.  This will NEVER be us\. Even with my problems and insecurities\.\. NEVER gonna happen\.\. and I PROMISE these feelings that I have will all go away soon and hopefully forever\.


**162.** `18:34` **You**

I am really sorry you had such an abusive relationship, I cannot really describe it otherwise\. You didn’t deserve it and he didn’t deserve you\.


**163.** `18:36` **Meredith Lamb (+14169386001)**

We were just very mismatched\. k, midstream time lol


**164.** `18:38` **You**

Have fun


**165.** `18:46` **Meredith Lamb (+14169386001)**

>
I don’t think it was abusive\. I think he’s just an idiot\. I said to my therapist today that I just understand how he hasn’t suspected anything at all\. And she was like “Meredith, from everything you’ve described, he never noticed you in any significant way so why would he now?”
Made me pause\.

*💬 Reply*

**166.** `18:50` **You**

That is equally awful and completely not understandable


**167.** `18:50` **You**

Because I cannot get you out of my head\.\. and it has been that way every day for months\.


**168.** `18:50` **You**

And I don’t ever see it changing\.


**169.** `18:51` **You**

Just hopefully balancing lol


**170.** `18:52` **Meredith Lamb (+14169386001)**

>
lol same

*💬 Reply*

**171.** `20:14` **You**

if you aren't too tired I have a few things I want to share with you\.\. will take me a few mins\.\.


**172.** `20:19` **Meredith Lamb (+14169386001)**

I’m doing midstream still\. Writing out instructions for Mus because Yolanda’s training videos are soooooooo looooooong and annoying


**173.** `20:19` **You**

There will be a modelling pic


**174.** `20:19` **You**

just saying


**175.** `20:20` **Meredith Lamb (+14169386001)**

I deserve it for all the annoying work I’m doing lol


**176.** `20:21` **You**

Reaction: ❤️ from Meredith Lamb
This first\.\. this is who I was\.\. and who I am with you\.

*📎 1 attachment(s)*

**177.** `20:29` **Meredith Lamb (+14169386001)**

Omg wow…\. Why did she write that to you?


**178.** `20:29` **Meredith Lamb (+14169386001)**

That is such a special letter to have from her\.


**179.** `20:29` **You**

I was going into high school\.


**180.** `20:30` **Meredith Lamb (+14169386001)**

I don’t have anything like that from my parents\.


**181.** `20:30` **You**

I wanted you to see who I was before everything\.


**182.** `20:30` **Meredith Lamb (+14169386001)**

That is exactly how I see you so I’m pretty sure you are the same person\.


**183.** `20:30` **You**

Reaction: ❤️ from Meredith Lamb
This was the next person after mum that I loved the most\.

*📎 1 attachment(s)*

**184.** `20:30` **You**

that was nana her mum\.


**185.** `20:31` **You**

This is what I could find on very short notice\.\. but figured why not share\.

*📎 3 attachment(s)*

**186.** `20:32` **You**

The prom picture is Angela, Me, Jon \(who you will meet\) and Katie\.


**187.** `20:32` **You**

The picture with all the friends\.\. were my people through Junior High and High School\.


**188.** `20:33` **You**

Reaction: 😮 from Meredith Lamb
the guy whose back I am climbing on and who I am sitting next to in the other photo is Liam\.\. he was one of my best friends through highschool we were like brothers\.\. by that time he had already slept with Angela and I wouldn't find out for another 10 months\.


**189.** `20:33` **You**

I forgave him and her a long time ago\.\. I still speak to him when I go home\.


**190.** `20:34` **Meredith Lamb (+14169386001)**

That’s wild\. Everyone looks so 90s lol


**191.** `20:35` **You**

ok so scanning a pic no one else has ever seen\.\. and it is the pair to another I have shown you\.\. honestly forgot it existed\.


**192.** `20:35` **Meredith Lamb (+14169386001)**

The pair?


**193.** `20:38` **You**

Reaction: ❤️ from Meredith Lamb
not up to my current standards\.\. but interesting to read\.

*📎 1 attachment(s)*

**194.** `20:40` **Meredith Lamb (+14169386001)**

You didn’t date it


**195.** `20:40` **You**

It was after high school


**196.** `20:41` **You**

Reaction: ❤️ from Meredith Lamb
the pair

*📎 1 attachment(s)*

**197.** `20:44` **Meredith Lamb (+14169386001)**

>
That was so nice\. Why did you mention difficulties as a child socially twice? What was that about?

*💬 Reply*

**198.** `20:45` **Meredith Lamb (+14169386001)**

>
What do you MEAN by “the pair”?

*💬 Reply*

**199.** `20:46` **You**

that is the second picture to the other black and white one


**200.** `20:46` **You**

Sarah shot me twice till i told her to piss off


**201.** `20:46` **You**

She was 2 years younger than me in 1st year\.\. I was in third


**202.** `20:46` **Meredith Lamb (+14169386001)**

Ahhhh got it


**203.** `20:46` **You**

Photographers\.\.


**204.** `20:47` **You**

eesh


**205.** `20:47` **Meredith Lamb (+14169386001)**

You should feel lucky to have them 🙂


**206.** `20:47` **Meredith Lamb (+14169386001)**

Or maybe just me lol


**207.** `20:47` **You**

Reaction: ❤️ from Meredith Lamb
ok be gentle\.\. this is pretty lame\.

*📎 2 attachment(s)*

**208.** `20:48` **You**

Just because :\)

*📎 1 attachment(s)*

**209.** `20:48` **Meredith Lamb (+14169386001)**

Almost like glamour shots :\)


**210.** `20:49` **You**

that is what they were supposed to be\.\. for when she tried to book me


**211.** `20:49` **You**

Ruth was her name\.\. and she was creepy


**212.** `20:49` **You**

but if Mike could do it, so could I\!


**213.** `20:49` **Meredith Lamb (+14169386001)**

lol I did glamour shots 3x back in the day


**214.** `20:49` **Meredith Lamb (+14169386001)**

Very 90s thing to do


**215.** `20:49` **You**

rofl I mean I did it because Mike said I couldn't


**216.** `20:50` **You**

and by then I had a bit of confidence


**217.** `20:53` **You**

Reaction: ❤️ from Meredith Lamb
anyhow\.\. I kind of invaded your past so wanted to share some of mine with you\.\. those black and white photos though, were the last before my innocence kind of vanished\.\. ironically Sarah and I were a great match\.\.we had a lot of fun, travelled around, got into all sorts of trouble for a couple of years\.\. we broke up, and got back together after my car accident\.  She was the one who I heard the guy on the phone calling her back to bed at Dalhousie\.\. I kind of changed after that\.  But I figured the letter from Mum could explain a lot to you about a bunch of aspects of who I am\.\. from my 100% in approach to friendship\.\. hoping for people to reciprocate\.\. to my lack of confidence\.\. etc etc


**218.** `20:54` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
One of our glamour shots\. Lol my 2 best friends for many years but not really now … still really good friends but not best

*📎 1 attachment(s)*

**219.** `20:54` **You**

deleted \- need to comment first\.\. holy shit\.\. you look amazing\. how old?


**220.** `20:55` **Meredith Lamb (+14169386001)**

My mom literally made me do these ones in high school…\. LOL I don’t even keep them\. Mac took this while in Oshawa recently bc she thought it was so hilarious

*📎 1 attachment(s)*

**221.** `20:56` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**222.** `20:56` **You**

I was in the middle of saying you probably are tired\.\. and I don't want to keep you up\.\. but I did want to share\.\. and I wanted to give you a heads up\.\. I have something small to give you tomorrow\.\. but it means something to me and I want you to keep it\.\. no arguing\.


**223.** `20:56` **Meredith Lamb (+14169386001)**

I got actual semi good non lame ones taken in uni but have no copies


**224.** `20:56` **You**

why would she make you\.\. you are goregeous\.\.


**225.** `20:56` **Meredith Lamb (+14169386001)**

My mom keeps one framed tho


**226.** `20:56` **You**

no doubt


**227.** `20:56` **Meredith Lamb (+14169386001)**

>
You have to know my mother to understand lol

*💬 Reply*

**228.** `20:57` **You**

way out of my league lol\.\. I wouldn't have talked to you\.


**229.** `20:57` **You**

would have been way to shy\.


**230.** `21:01` **Meredith Lamb (+14169386001)**

You can see the only normal glamour shot I have in the background framed lol

*📎 1 attachment(s)*

**231.** `21:02` **Meredith Lamb (+14169386001)**

>
Yeah I mean zero surprises in either letter \(other than the “childhood difficulties”\) … I really don’t think you are different at all

*💬 Reply*

**232.** `21:03` **Meredith Lamb (+14169386001)**

>
Oh whatever\.

*💬 Reply*

**233.** `21:03` **You**

Well then that tells you at least one thing\.\.\. I have been 100% transparent\.\. you know me more than anyone else\.


**234.** `21:03` **You**

>
it is so trued

*💬 Reply*

**235.** `21:03` **You**

never in a million years would we have hooked up unless you expressed interest\.


**236.** `21:04` **You**

no confidence that way


**237.** `21:04` **You**

still


**238.** `21:04` **Meredith Lamb (+14169386001)**

Well maybe I would have :\)


**239.** `21:04` **You**

I dunno\.\. I wasn't very "big" back then\.\. :\) 170lbs\.


**240.** `21:04` **Meredith Lamb (+14169386001)**

LOL


**241.** `21:05` **You**

>
I think in your searching for pics you might have overlooked this\.\. just want to make sure you don't miss it so no surprises\.

*💬 Reply*

**242.** `21:06` **Meredith Lamb (+14169386001)**

I came downstairs to look for something\. Just found it


**243.** `21:06` **Meredith Lamb (+14169386001)**

Trent and I playing cricket and Brett videotaping lol

*📎 1 attachment(s)*

**244.** `21:07` **Meredith Lamb (+14169386001)**

You can see the taped area where the ball has to hit on the barn lol


**245.** `21:07` **You**

hehe


**246.** `21:07` **You**

it was so much better when we made our own fun/


**247.** `21:08` **Meredith Lamb (+14169386001)**

The barn was home shortly after that\. Safety risk lol

*📎 1 attachment(s)*

**248.** `21:09` **Meredith Lamb (+14169386001)**

I like having those photos tho\. Funny memories


**249.** `21:09` **Meredith Lamb (+14169386001)**

I have many albums\. I used to like to make Allen when I was little


**250.** `21:09` **Meredith Lamb (+14169386001)**

\*make them


**251.** `21:11` **You**

Reaction: 😢 from Meredith Lamb
I have thousands of photos but I letft them at Katies


**252.** `21:11` **You**

I always planned to go back and get them


**253.** `21:11` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Very country\. Corn field in the back

*📎 1 attachment(s)*

**254.** `21:16` **You**

sry aunt called


**255.** `21:20` **Meredith Lamb (+14169386001)**

Sok folding laundry before bed… tired now


**256.** `21:24` **You**

sec


**257.** `21:28` **You**

was just telling my Aunt \(2nd Cousin\) mum's best friend


**258.** `21:29` **You**

Reaction: 😮 from Meredith Lamb
she will actually live 5 mins from where Jaimie will be living


**259.** `21:29` **You**

anyways also needed to confirm something with her so I did that too while I was on the call\.


**260.** `21:33` **Meredith Lamb (+14169386001)**

Was she surprised or did she know already?


**261.** `21:33` **Meredith Lamb (+14169386001)**

I can guarantee you my whole family knows\. My mom and her 3 sisters are blabbermouths


**262.** `21:35` **You**

Katie


**263.** `21:35` **You**

Told her a bit


**264.** `21:35` **You**

I told her the rest


**265.** `21:35` **You**

She wasn’t surprised


**266.** `21:36` **You**

She knew I was unhappy a while ago


**267.** `21:36` **You**

Knew about the basement


**268.** `21:36` **You**

Said mum would understand d


**269.** `21:37` **Meredith Lamb (+14169386001)**

From the letter your mom wrote you it sounds like she would understand


**270.** `21:37` **You**

I asked Marlene


**271.** `21:37` **You**

She said she would


**272.** `21:37` **You**

And mum and j were close too


**273.** `21:38` **Meredith Lamb (+14169386001)**

Seems like she just wanted you to be happy really


**274.** `21:38` **You**

She did I had a hard childhood


**275.** `21:39` **You**

Led with my heart\.\. lol even in friendship\.\. I was off that way and got made fun of for being more like the guys\.\.


**276.** `21:39` **You**

Odd not off


**277.** `21:40` **Meredith Lamb (+14169386001)**

Guys or girls?


**278.** `21:40` **You**

I found some balance about grade 7 \-12


**279.** `21:40` **You**

Girls never made fun of me


**280.** `21:40` **Meredith Lamb (+14169386001)**

>
Is guys a typo here?

*💬 Reply*

**281.** `21:40` **You**

But I was like that with everyone


**282.** `21:40` **You**

No


**283.** `21:40` **You**

Guys kids were d\-bags


**284.** `21:41` **Meredith Lamb (+14169386001)**

You got made fun of for being like the guys?


**285.** `21:41` **You**

I wasn’t like that


**286.** `21:41` **You**

For not


**287.** `21:41` **You**

Being like them


**288.** `21:41` **Meredith Lamb (+14169386001)**

Oh\!\! lol


**289.** `21:41` **Meredith Lamb (+14169386001)**

So many typos


**290.** `21:41` **Meredith Lamb (+14169386001)**

You were no


**291.** `21:41` **Meredith Lamb (+14169386001)**

Emo


**292.** `21:41` **Meredith Lamb (+14169386001)**

Or sorry, you ARE


**293.** `21:42` **You**

I was sensitive, not emo in the common sense


**294.** `21:42` **You**

No I am not emo is something else


**295.** `21:43` **You**

Hmmm


**296.** `21:43` **You**

Maybe you are right


**297.** `21:43` **Meredith Lamb (+14169386001)**

I just ChatGPT’d it\. Yeah I didn’t fully get emo I guess


**298.** `21:43` **You**

It is on the line


**299.** `21:43` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**300.** `21:43` **You**

There is a culture which I am not


**301.** `21:44` **You**

Yeah not the culture but the meaning is emotionally hardcore or raw


**302.** `21:44` **You**

Oh sent this to Jon when i was scanning things to you


**303.** `21:45` **You**


*📎 1 attachment(s)*

**304.** `21:45` **You**

He gave me this right at the end of high school\.


**305.** `21:47` **You**

Talk about people liking me\.\. 🙂


**306.** `21:48` **You**

A little cringe a little dramatic but honest\.


**307.** `21:51` **Meredith Lamb (+14169386001)**

Sec just got out of shower getting ready for bed


**308.** `21:55` **Meredith Lamb (+14169386001)**

Wow this is so pure and genuine\.

*💬 Reply*

**309.** `21:55` **Meredith Lamb (+14169386001)**

I have no letters like this\!\!


**310.** `21:56` **You**

Hehe


**311.** `21:56` **You**

He was / is the best


**312.** `21:57` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
I have letters from a good friend of mine \(who killed herself\) but I she never professes her love for me lol


**313.** `21:57` **You**

No Jon and I were close


**314.** `21:58` **You**

He moved to Montreal in grade 11


**315.** `21:58` **You**

Graduated and the\. Came back for grade 12 anyways just to graduate with me


**316.** `22:01` **You**

Getting g ready for bed myself


**317.** `22:02` **You**

Didnt get done what I needed to get done tonight but I did get done what I wanted to get done\.


**318.** `22:02` **Meredith Lamb (+14169386001)**

He sounded so lonely in his letter


**319.** `22:03` **You**

He was he was by himself in Ontario older brother gone parents kind of absent


**320.** `22:07` **Meredith Lamb (+14169386001)**

Kari’s letters are fucked up bc she was in rehab\. She couldn’t have email and that’s why we wrote letters lol\. This is the loviest I got\. Just read a few


**321.** `22:07` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**322.** `22:08` **Meredith Lamb (+14169386001)**

She killed herself just under 6 months after this


**323.** `22:08` **Meredith Lamb (+14169386001)**

I got a letter right before


**324.** `22:08` **Meredith Lamb (+14169386001)**

And she was great in it


**325.** `22:09` **You**

Ah mer I am so sorry\.\. sounds like she really did care about you\.\. you had a connection\.\.


**326.** `22:09` **Meredith Lamb (+14169386001)**

We were very good friends all through high school\. Very competitive though\.


**327.** `22:10` **Meredith Lamb (+14169386001)**

I have her letters scanned because I gave them to her family years later


**328.** `22:10` **Meredith Lamb (+14169386001)**

They were estranged for 2 yrs before she died


**329.** `22:10` **Meredith Lamb (+14169386001)**

So I thought they might like them even though they are a little weird and not so great about me sometimes lol


**330.** `22:11` **Meredith Lamb (+14169386001)**

Mentions my drug use in one


**331.** `22:11` **Meredith Lamb (+14169386001)**

🤷‍♀️


**332.** `22:11` **You**

So you were older when you exhchsbged letters?


**333.** `22:11` **Meredith Lamb (+14169386001)**

Yeah 2001 she was in rehab


**334.** `22:11` **Meredith Lamb (+14169386001)**

Before that email


**335.** `22:11` **You**

Ah ok


**336.** `22:12` **Meredith Lamb (+14169386001)**

She lived in California


**337.** `22:12` **You**

Hard to lose a friend like that\.\.


**338.** `22:12` **Meredith Lamb (+14169386001)**

Went to us in track scholarship but fucked it up due to bulimia and mental health issues


**339.** `22:13` **Meredith Lamb (+14169386001)**

She actually got her email back like 2 weeks before she killed herself :p


**340.** `22:13` **Meredith Lamb (+14169386001)**

I think the whole letter thing was challenging


**341.** `22:13` **Meredith Lamb (+14169386001)**

They took so freaking long compared to email


**342.** `22:13` **Meredith Lamb (+14169386001)**

Was so stupid


**343.** `22:13` **You**

Yeah that seems counter intuitive


**344.** `22:13` **Meredith Lamb (+14169386001)**

I don’t know why they didn’t just monitor her email


**345.** `22:14` **Meredith Lamb (+14169386001)**

Or allow certain ppl only


**346.** `22:14` **Meredith Lamb (+14169386001)**

Dumb


**347.** `22:14` **Meredith Lamb (+14169386001)**

They read all my letters before she got them


**348.** `22:14` **Meredith Lamb (+14169386001)**

That place was fucked up


**349.** `22:14` **You**

Yeah \.\. oh speaking of mental heart Gracie got a call from Ontario shores


**350.** `22:14` **You**

She has an appointment with psychiatrist on Tuesday\.


**351.** `22:14` **You**

I am hoping she can get a referral to New Brunswick\.


**352.** `22:15` **Meredith Lamb (+14169386001)**

>
I had to ChatGPT that

*💬 Reply*

**353.** `22:15` **Meredith Lamb (+14169386001)**

>
Doesn’t she already have one?

*💬 Reply*

**354.** `22:15` **You**

No she has a therapist


**355.** `22:15` **Meredith Lamb (+14169386001)**

Ah


**356.** `22:16` **You**

Psychiatrist is diff can prescribe drugs etc


**357.** `22:16` **You**

Hey I should go see her to\.


**358.** `22:16` **You**

Get that K treatment apparently it is a fad\.


**359.** `22:17` **Meredith Lamb (+14169386001)**

🙄


**360.** `22:18` **You**

Hey I read up on it


**361.** `22:18` **You**

I don’t need any treatment


**362.** `22:18` **Meredith Lamb (+14169386001)**

No way it is a fad


**363.** `22:18` **You**

Just you\.  And I will be all good


**364.** `22:18` **Meredith Lamb (+14169386001)**

You don’t need treatment, agree


**365.** `22:18` **Meredith Lamb (+14169386001)**

Did you really think you did?


**366.** `22:18` **You**

For a bit


**367.** `22:18` **Meredith Lamb (+14169386001)**

Are you hiding something?


**368.** `22:19` **Meredith Lamb (+14169386001)**

Like why


**369.** `22:19` **You**

What?


**370.** `22:19` **You**

Hiding something


**371.** `22:19` **Meredith Lamb (+14169386001)**

Why would you need treatment


**372.** `22:19` **You**

We talked about trust earlier I walk around in front of you naked and you know everything about me\. lol


**373.** `22:19` **You**

Like WTF


**374.** `22:19` **Meredith Lamb (+14169386001)**

Isn’t apparent to me so are you hiding some extra anxieties


**375.** `22:19` **You**

No


**376.** `22:19` **You**

Jesus


**377.** `22:19` **You**

Look


**378.** `22:19` **Meredith Lamb (+14169386001)**

Then why did you think that


**379.** `22:19` **You**

Ok I am serious


**380.** `22:20` **Meredith Lamb (+14169386001)**

That you needed treatment


**381.** `22:20` **You**

When you came on the scene


**382.** `22:20` **Meredith Lamb (+14169386001)**

>
I do enjoy both of these things btw\.

*💬 Reply*

**383.** `22:20` **You**

It was like getting hit with a tidal wave of emotion I didn’t know what was what how to deal with it\.\. it was wonderful and terrifying and you were at the middle of all of it\.\.


**384.** `22:20` **You**

And the only thing I was certain about


**385.** `22:20` **You**

And then


**386.** `22:21` **You**

Little things\.\. I was unaware of\.\. Andrew sleeping situation\.\. history and sharing a bunch of things very quickly as well as a bunch of wonderful nights\.


**387.** `22:21` **You**

Again it was a LOT for me to handle \+ what is going on here


**388.** `22:22` **Meredith Lamb (+14169386001)**

So just like the speed and depth


**389.** `22:22` **You**

No


**390.** `22:22` **You**

Loving you fast and deep was the only thing that felt true and right


**391.** `22:22` **Meredith Lamb (+14169386001)**

Yeah it has been a lot for me also but I think in a different way\. I don’t think I feel things to the same depth that you do lol just generally


**392.** `22:23` **You**

I just couldn’t deal with all the blips then I would smack into them face first unprepared, and have to deal and process


**393.** `22:23` **Meredith Lamb (+14169386001)**

You kind of wear your heart on your sleeve


**394.** `22:23` **Meredith Lamb (+14169386001)**

And feel immediately


**395.** `22:23` **You**

I haven’t loved anyone this deeply ever\.


**396.** `22:23` **Meredith Lamb (+14169386001)**

All the time


**397.** `22:23` **Meredith Lamb (+14169386001)**

I process a bit


**398.** `22:24` **You**

I feel like if I process it would seem
Like I am trying to misrepresent or frame a response rather than be brutally honest


**399.** `22:24` **You**

I used to hold back a lot when I was more closed off


**400.** `22:24` **You**

Was introspective


**401.** `22:24` **You**

But I don’t feel like you deserve that from me


**402.** `22:24` **You**

Because it is just what I want you to see then


**403.** `22:25` **You**

And I want you to see everything even the stuff I am uncomfortable with


**404.** `22:25` **You**

So we are different, but I don’t need treatment\.\. I have gotten much better at control believe it or not\.  Still there are moments


**405.** `22:26` **You**

And I believe what I said I do t need treatment I just need you


**406.** `22:27` **Meredith Lamb (+14169386001)**

>
I am feeling this also but it doesn’t scare me\. Even though you are kind of crazy sometimes \(lol\) you just feel peaceful and like home to me\. It is really an odd thing\. Like even in your spiralling moments\. Don’t love those times but you still have this vibe I connect with … except when you give me the silent treatment that is\.

*💬 Reply*

**407.** `22:27` **You**

Look I am not walking away, I am not going to have a heart attack or stroke, I am not going to have a nervous breakdown\. I am not going to get disinterested\. I am never going to love anyone else\. I am never going to want anyone else\. I am only interested in being happy with you at the earliest possible convenience\.\. which could be months or years I would wait\.


**408.** `22:28` **You**

And I am not crazy


**409.** `22:28` **Meredith Lamb (+14169386001)**

>
But you can still work right?

*💬 Reply*

**410.** `22:28` **You**

I am emotionally challenged fed


**411.** `22:28` **You**

>
Hrm?

*💬 Reply*

**412.** `22:29` **Meredith Lamb (+14169386001)**

>
You are kind of crazy sometimes\. Case in point: blog mining\.

*💬 Reply*

**413.** `22:29` **You**

Reaction: 😂 from Meredith Lamb
That isn’t crazy at all


**414.** `22:29` **Meredith Lamb (+14169386001)**

>
Did you do any actual work today? Like Enbridge work

*💬 Reply*

**415.** `22:29` **You**

Crazy was me setting up a web crawling system to go dig through the internet for anything I want to find out\.


**416.** `22:29` **You**

I did


**417.** `22:30` **You**

Work


**418.** `22:30` **You**

>
I did not do this\.

*💬 Reply*

**419.** `22:30` **You**

Just an example


**420.** `22:30` **Meredith Lamb (+14169386001)**

>
I was like “is this a fancy term for mining?”

*💬 Reply*

**421.** `22:30` **You**

It is mining but at a much different level


**422.** `22:30` **You**

Huge scale


**423.** `22:31` **Meredith Lamb (+14169386001)**

I’m not convinced you didn’t do it


**424.** `22:31` **You**

I didn’t


**425.** `22:31` **You**

Period


**426.** `22:31` **Meredith Lamb (+14169386001)**

k


**427.** `22:31` **Meredith Lamb (+14169386001)**

lol


**428.** `22:32` **You**

I don’t know anything about any of the years you desperately  don’t want me to know about don’t worry mer\.\. lol


**429.** `22:32` **You**

I wouldn’t lie to you I told you that


**430.** `22:32` **You**

In fact


**431.** `22:32` **You**

I didn’t have to tell you anything about the blogs


**432.** `22:32` **You**

Nor that I found Chris blogs


**433.** `22:32` **Meredith Lamb (+14169386001)**

I know and there is nothing but silliness online


**434.** `22:32` **You**

Like I don’t lie


**435.** `22:33` **You**

>
Then you shouldn’t be so worried

*💬 Reply*

**436.** `22:33` **Meredith Lamb (+14169386001)**

I’m not worried


**437.** `22:33` **You**

Bs


**438.** `22:33` **Meredith Lamb (+14169386001)**

I just deleted them for a reason


**439.** `22:33` **You**

I call 1000% bs


**440.** `22:33` **Meredith Lamb (+14169386001)**

Silliness


**441.** `22:33` **You**

But you can say whatever you want


**442.** `22:33` **You**

Like I said don’t care not looking not interested


**443.** `22:33` **You**

You will have to trust me


**444.** `22:34` **You**

Or it will eat at
You


**445.** `22:34` **You**

And is


**446.** `22:34` **You**

Us


**447.** `22:34` **Meredith Lamb (+14169386001)**

I do trust you\. And trust me that I’m not worried


**448.** `22:34` **You**

K


**449.** `22:34` **You**

Notes


**450.** `22:34` **You**

Noted


**451.** `22:34` **Meredith Lamb (+14169386001)**

I’m just not a 20somethjng anymore


**452.** `22:34` **Meredith Lamb (+14169386001)**

So Yunno


**453.** `22:34` **You**

I don’t know why you feel like you need to keep saying that\.


**454.** `22:35` **Meredith Lamb (+14169386001)**

Because if I had a blog now it wouldn’t be like that


**455.** `22:35` **Meredith Lamb (+14169386001)**

I’m not that person anymore


**456.** `22:35` **You**

I know that\.\. See this is why people lie mer\.\.
lol


**457.** `22:36` **You**

Proving my point


**458.** `22:36` **You**

I could have said nothing g dealt with this privately and you would t have known so you wouldn’t have been bothered and the\. You wouldn’t think I am crazy and doubt me\.


**459.** `22:37` **You**

This bothers you a lot more than you are letting i
On I knew it from how you reacted last night\.


**460.** `22:39` **Meredith Lamb (+14169386001)**

It doesn’t bother me\. It surprised me that my blog was out there\. I had no idea\. That’s all\.


**461.** `22:39` **Meredith Lamb (+14169386001)**

Honestly doesn’t bother me


**462.** `22:39` **Meredith Lamb (+14169386001)**

I put it out publicly


**463.** `22:39` **Meredith Lamb (+14169386001)**

It’s just immature


**464.** `22:39` **Meredith Lamb (+14169386001)**

It’s not like a diary or anything\. THAT would bother me


**465.** `22:42` **You**

Ok mer I think it is time for bed\.\. For the record I went back and read and I def think it bothered you and I am sorry I did it\.  Like said won’t happen again as I am not interested I\. Looking back\.  But I do think it bothered you from reading between the lines\. Again sorry\.


**466.** `22:43` **You**

You should go to bed I kept you up again, and really didn’t want to get back on this topic


**467.** `22:43` **You**

>
This was the most honest thing you have said about this\.

*💬 Reply*

**468.** `22:45` **Meredith Lamb (+14169386001)**

>
It was a joke\.

*💬 Reply*

**469.** `22:45` **You**

No it wasn’t


**470.** `22:46` **You**

Kidding follows a joke


**471.** `22:46` **You**

It doesn’t bother me btw I deserve it\.\. but I am not going to do it\.\. again it only hurts me why the fuck woukd I want more of that rather than to move forward\.\.


**472.** `22:47` **You**

I just need something to fill the time  in Between now and when when can


**473.** `22:48` **Meredith Lamb (+14169386001)**

I went back up and took much to read through lol


**474.** `22:48` **You**

Reaction: ❓ from Meredith Lamb
Did you see what I saw??


**475.** `22:48` **Meredith Lamb (+14169386001)**

>
I actually found it pretty impressive tbh\.

*💬 Reply*

**476.** `22:49` **You**

>
What do you mean

*💬 Reply*

**477.** `22:49` **Meredith Lamb (+14169386001)**

I mean finding all of that… pretty impressive\.


**478.** `22:49` **You**

Omg stop nooooooooooooooo


**479.** `22:49` **You**

It want


**480.** `22:49` **You**

Wasn’t


**481.** `22:50` **Meredith Lamb (+14169386001)**

I HONESTLY am not bothered by it\. It wasn’t a diary\. Just stupid shit\. I had real diaries on paper\.


**482.** `22:51` **You**

Sigh ok I am fine to just drop it honestly I didn’t want to talk about it anyways


**483.** `22:51` **Meredith Lamb (+14169386001)**

Don’t sigh


**484.** `22:52` **You**

SIGH


**485.** `22:52` **You**

AND 🙄


**486.** `22:52` **You**

So that’s what you get


**487.** `22:53` **Meredith Lamb (+14169386001)**

Sighhhhhh


**488.** `22:53` **You**

Therm’s fighting texts right there\.


**489.** `22:53` **Meredith Lamb (+14169386001)**

k I really need to get to bed if I’m getting up EARLIER tomorrow


**490.** `22:53` **You**

I tried to get you to go to bed a\. Hour ago


**491.** `22:54` **Meredith Lamb (+14169386001)**

🤷‍♀️


**492.** `22:54` **You**

Yeah I know\.


**493.** `22:54` **Meredith Lamb (+14169386001)**

Night person


**494.** `22:54` **Meredith Lamb (+14169386001)**

But need to get up earlier if I am going to meet you


**495.** `22:55` **Meredith Lamb (+14169386001)**

Sooo


**496.** `22:55` **You**

I know same\.\.
Go to bed my Mer… I love you very much in my crazy kind of way\.


**497.** `22:55` **You**

❤️❤️❤️


**498.** `22:55` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I love you too \(have my crazy ways also… \)


**499.** `22:55` **Meredith Lamb (+14169386001)**

❤️


**500.** `22:57` **You**

Oh go read the thing before you go to bed that you saved I feel like it\. Would do you some good\.\. you were rattled today\.


**501.** `22:58` **You**

Still think you are honestly\., hope that goes away\.


**502.** `22:58` **You**

❤️


