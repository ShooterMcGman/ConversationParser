# Daily Conversation: 2025-07-04 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-04 |
| **Day** | Friday |
| **Week** | 12 |
| **Messages** | 607 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-04T04:20 - 2025-07-04T23:43 |

## 📝 Daily Summary

This day contains **607 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:20` **You**

Morning Mer hope you have a good sleep, don’t think you are back on the workout schedule yet so try to get some sleep in time\.  Will be in at the office today moving my shit, so let me know if you wanna chat maybe we can find a few minutes to break the day up\.  Anyhow going to go hit the gym… love you, chat later\.


**002.** `06:38` **You**

Not sure where to proceed with status shots btw\.\. let me know if you still want those\. 🙂


**003.** `06:46` **You**

Think I am going to head to park this morning for a bit, sit on my rock and think before heading into work\.


**004.** `07:33` **Meredith Lamb (+14169386001)**

Morning \- definitely not back working out :\( soon tho \- hope you had a good workout and of course photos, yes :\) k I’m going to snooze a bit more …\.


**005.** `07:34` **You**

Kk enjoy your snooze heading to park… pics later\.\. workout was ok\.


**006.** `07:48` **You**

https://open\.spotify\.com/episode/2yxZDFxnKdnMQzLPAeJVI1?si=tVcVPbq2QWG3L5y4HEQueg&context=spotify%3Ashow%3A7fY99FB3bNyn7nEdXCoBeB


**007.** `08:30` **You**

Reaction: ❤️ from Meredith Lamb
V is coming slowly\.

*📎 1 attachment(s)*

**008.** `08:30` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**009.** `08:34` **Meredith Lamb (+14169386001)**

I wouldn’t call your progress “slowly” lol


**010.** `08:35` **You**

Well it’s coming\.\. I might go for a run tonight not sure yet\.


**011.** `08:40` **You**

Are you feeling ok this morning did you not sleep well again last night?


**012.** `08:43` **Meredith Lamb (+14169386001)**

I slept better last night so feeling OK\.


**013.** `08:44` **You**

Glad to hear\.\. will leave you to your work\.\. maybe we can chat later\.


**014.** `08:45` **Meredith Lamb (+14169386001)**

Buying stuff for girls cottage weekend lol


**015.** `08:45` **You**

Edited: 2 versions
| Version: 2
| Sent: Fri, 4 Jul 2025 08:49:53 \-0400
|
| Sounds like your kind of fun\.\. enjoy\. 🙂
|
| Version: 1
| Sent: Fri, 4 Jul 2025 08:45:59 \-0400
|
| Sounds like you’re kind of fun\.\. enjoy\. 🙂


**016.** `08:54` **Meredith Lamb (+14169386001)**

Wait you told Mia that you are interviewing


**017.** `08:54` **Meredith Lamb (+14169386001)**

She really wants to prepare


**018.** `08:55` **You**

I told her nothing was going to happen for a few weeks


**019.** `08:55` **Meredith Lamb (+14169386001)**

Right she wants to prep for an interview end of July


**020.** `08:55` **You**

I am going to talk to Ian to see if there is anything else we can do\.\. but I am completely at a loss here


**021.** `08:55` **You**

I feel like shit


**022.** `08:55` **You**

But I cannot do anything


**023.** `08:55` **You**

Or say anything


**024.** `08:56` **Meredith Lamb (+14169386001)**

Yeah I know


**025.** `08:56` **Meredith Lamb (+14169386001)**

Everyone keeps asking me


**026.** `08:56` **Meredith Lamb (+14169386001)**

Didn’t say anything


**027.** `08:56` **Meredith Lamb (+14169386001)**

Not even to Jim \(who also asked\)


**028.** `08:56` **You**

Appreciate it\.\. I shouldn’t have slipped up that is my fault


**029.** `08:56` **Meredith Lamb (+14169386001)**

Leaving until end of July with no explanation is weird tho


**030.** `08:57` **You**

It won’t be end of July


**031.** `08:57` **You**

Next week I suspect


**032.** `08:57` **Meredith Lamb (+14169386001)**

Oh then that’s fine


**033.** `09:02` **You**

I mean it’s not optimal but it is all I can do\.\. no control over this situation\.\. sucks\.\. I liked Mia and enjoyed our conversations\.


**034.** `09:14` **Meredith Lamb (+14169386001)**

So Marlowe actually wants to see the house finally so going to pop her over this morning\.


**035.** `09:14` **You**

Great I hope that puts her mind at ease\.


**036.** `09:15` **You**

I will be interested to hear what she thinks


**037.** `09:42` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
She likes it


**038.** `09:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**039.** `09:42` **You**

Very happy for you, I know you were worried\.


**040.** `09:42` **You**

Happy for her too\.


**041.** `10:09` **You**

So I did some more thinking as I went to sleep last night yeah you full time with kids will definitely put the relationship in a kind of holding pattern\.\. we won’t really be able to move towards a life together\.\. and as you said that estimate is likely way understated so we could easily be looking at a year or more\.\. so that means that nights together or extended times spent in each others company will likely be non existent, but who knows maybe there is a way around this\.  Either way I still think that once your family knows,
At least we can have date nights perhaps,
Dinners together a few hours here or there\.\. it would be enough for me, I resolved that\.\. so just something for you to think about\.\. perhaps it isn’t completely impossible\.  Anyhow just wanted to share that there may be some light\.\. something to be a little optimistic about\.  Trying\.  Love you\.


**042.** `10:14` **Meredith Lamb (+14169386001)**

I mean I don’t want to ruin Marlowe’s life or anything but she hates not knowing shit and I just have this gut feeling that she would like to know\.
On the weekend when she was driving back from Newmarket, I was already home and she goes:

*📎 1 attachment(s)*

**043.** `10:14` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
The “but it’s fine” broke me a little


**044.** `10:14` **Meredith Lamb (+14169386001)**

She knows I’m hiding shit


**045.** `10:15` **Meredith Lamb (+14169386001)**

And she is trying to be good about it


**046.** `10:15` **Meredith Lamb (+14169386001)**

I shared my location back


**047.** `10:15` **You**

Is there any way she would keep it a secret


**048.** `10:15` **You**

Too much for her probably


**049.** `10:15` **You**

And not fair


**050.** `10:15` **Meredith Lamb (+14169386001)**

She might but Andrew and I are close so I think we are almost there


**051.** `10:15` **Meredith Lamb (+14169386001)**

But I need to tell her when this is signed


**052.** `10:16` **You**

Yep I know


**053.** `10:16` **Meredith Lamb (+14169386001)**

It’s making our relationship weird


**054.** `10:16` **Meredith Lamb (+14169386001)**

\(Her and I\)


**055.** `10:16` **You**

I am sorry I feel like if I just laid back and left you be no rendezvous no secret meetings your life would be better off\.\.


**056.** `10:17` **You**

Anyhow I will try to remain optimistic as I said above\.\. all I can do\.  Really sorry for the trouble with Marlowe


**057.** `10:17` **Meredith Lamb (+14169386001)**

No, not better off at all\.


**058.** `10:18` **Meredith Lamb (+14169386001)**

It’s just getting to the point where she needs to know


**059.** `10:19` **You**

Yep it definitely is\.\. it is tough to keep that away from her when she knows but also knows you don’t want her to ask outright\.\. really sucks\.


**060.** `10:22` **You**

>
I just think before all of the secrecy I already knew you were the one, that I was helplessly in love and that that wouldn’t change\.\. if I hadn’t forced the issue, I know you would have been more patient\.\. anyhow nothing I can do now but try to do better moving forward\.\. I promise I will\.

*💬 Reply*

**061.** `10:25` **Meredith Lamb (+14169386001)**

Reaction: 🙂 from Scott Hicks
Just talking to my mom


**062.** `11:48` **You**

Didn’t realize I kept this\.

*📎 1 attachment(s)*

**063.** `11:48` **Meredith Lamb (+14169386001)**

lol


**064.** `11:56` **Meredith Lamb (+14169386001)**

Just got off with my mom phew


**065.** `11:57` **You**

Wow that was long convo


**066.** `11:57` **Meredith Lamb (+14169386001)**

>
You haven’t done anything wrong so there is no “doing better”\. I have been with you in this every step of the way

*💬 Reply*

**067.** `11:58` **Meredith Lamb (+14169386001)**

>
Yeah she likes to talk a lot sometimes\. Had to update her on the mediation and she asked how weekend was also

*💬 Reply*

**068.** `11:58` **Meredith Lamb (+14169386001)**

She asked when I’m telling girls


**069.** `11:58` **Meredith Lamb (+14169386001)**

Said no idea


**070.** `11:58` **Meredith Lamb (+14169386001)**

She said to not tell Andrew as long as possible bc he is going to be livid


**071.** `11:59` **You**

If you told her what we talked about out last night I know what she would say\.


**072.** `11:59` **You**

>
I just do t see how that works\.  I agree after settlement\. But how long\.

*💬 Reply*

**073.** `12:00` **Meredith Lamb (+14169386001)**

>
I did not\.

*💬 Reply*

**074.** `12:00` **You**

Still I can imagine\. Heh


**075.** `12:00` **You**

Anyways you have a lot to think about for sure


**076.** `12:00` **Meredith Lamb (+14169386001)**

She knows I don’t like hiding it


**077.** `12:01` **Meredith Lamb (+14169386001)**

She thinks Andrew will think this has been going on for a long time \(similar to Jaimie\)


**078.** `12:01` **You**

It is possible\.


**079.** `12:01` **You**

But you actually have texts to show it has not


**080.** `12:02` **Meredith Lamb (+14169386001)**

True


**081.** `12:02` **Meredith Lamb (+14169386001)**

Do you want to chat or should I call him back


**082.** `12:02` **Meredith Lamb (+14169386001)**

He called to update me on the po4 meeting this morning


**083.** `12:02` **You**

Hmm?


**084.** `12:03` **Meredith Lamb (+14169386001)**

\*jim


**085.** `12:03` **You**

Oh I mean up to you I am free for lunch then in meetings this afternoon\.


**086.** `12:03` **Meredith Lamb (+14169386001)**

Up to YOU


**087.** `12:04` **Meredith Lamb (+14169386001)**

I feel like I’m doing no work all day so…\.\.


**088.** `12:04` **You**

I was the one who asked you if you wanted to chat this morning lol so if you would like to and are comfortable then give me a shout\.


**089.** `12:59` **You**

Reaction: 😂 from Meredith Lamb
I love you too\.\. you hang up so fast after you say it I didn’t know if you heard me\.\. lol


**090.** `13:02` **Meredith Lamb (+14169386001)**

I did


**091.** `13:03` **You**

Kk I was like stuttering trying to get it out because you are quick I\. The hang up\.  Conversations need to end before or if we start talking about the future\.\. I think\.\. it is just\. A downer and no solutioning\.  You are better equipped to deal with us not moving forward because you are busy\.\. once I find something to keep me busy it will be better for everyone I think\.


**092.** `13:08` **Meredith Lamb (+14169386001)**

Well I was glad to hear that the whole basement/maybe not 5050 for a while thing was a little deflating to you because it really hit me when he told me after work\. Day was already hard and then that and it just seemed like things were piling on


**093.** `13:09` **You**

You were glad I felt like you felt? Lol sorry I didn’t understand first sentence


**094.** `13:11` **Meredith Lamb (+14169386001)**

Yes exactly\.


**095.** `13:13` **You**

So we both felt bad together lol… or you felt bad because you knew how I would react


**096.** `13:14` **Meredith Lamb (+14169386001)**

No I felt bad because it gives less flexibility to us\.


**097.** `13:15` **You**

Well yeah then same page\.\. I mean the next 2 months is kind of grim too\.\.  it I could have gotten over that with some light


**098.** `13:19` **Meredith Lamb (+14169386001)**

Same…\. It was a big blow\.


**099.** `13:23` **You**

Well apparently we are not allowed to be apprehensive so we will just figure it out right\.


**100.** `13:28` **Meredith Lamb (+14169386001)**

Correct\.


**101.** `13:29` **You**

Okie dokie\.


**102.** `13:30` **Meredith Lamb (+14169386001)**

We just have to tell ppl


**103.** `13:30` **Meredith Lamb (+14169386001)**

\(My kids etc\)


**104.** `13:30` **You**

Every time I say that I remeber laying on the couch with you at the cottage and power watching that show


**105.** `13:31` **You**

>
Yeah that is a big step\.\. then we will need to reassess

*💬 Reply*

**106.** `13:32` **You**

But yeah that’s still quite a ways out i suspect\.\. I am not going away but I am also not super optimistic\.\. just the tiniest tiniest bit optimistic\.\. lol


**107.** `13:32` **You**

Ever so small\.


**108.** `14:00` **Meredith Lamb (+14169386001)**

So Jim definitely has not done anything intentional to you\. I didn’t ask but he’s been talking about you/us in a positive way so it is in your head\.


**109.** `14:00` **You**

Must be all in my head\.\. all those chats I forgot we had, the outreach to see how I\. Am doing\.


**110.** `14:00` **You**

Yep\.\. figment


**111.** `14:00` **You**

lol


**112.** `14:02` **You**

Just leave it be I am not reaching out to him again on us anyways he is probably still worried I am going to get hurt and I don’t need any of that in my head either


**113.** `14:30` **Meredith Lamb (+14169386001)**

Oh stop


**114.** `14:30` **Meredith Lamb (+14169386001)**

I think he’s just been busy honestly


**115.** `14:30` **You**

Nope nope


**116.** `14:30` **You**

Set


**117.** `14:30` **Meredith Lamb (+14169386001)**

Or maybe he thinks I need more support than you do


**118.** `14:30` **You**

Sry


**119.** `14:30` **Meredith Lamb (+14169386001)**

He talked about having us over for dinner once both of our things are signed


**120.** `14:31` **Meredith Lamb (+14169386001)**

Then he said if we were free tonight, we could go to his friends concert that he’s having but I was like next year


**121.** `14:31` **Meredith Lamb (+14169386001)**

A bit too last minute


**122.** `14:31` **Meredith Lamb (+14169386001)**

And I’m just so tired still


**123.** `14:31` **You**

Mmmm hmmmm


**124.** `14:31` **You**

lol


**125.** `14:31` **Meredith Lamb (+14169386001)**

I think you are over\-thinking


**126.** `14:32` **You**

Yeah I dun think so\.\. gonna stick to my plan\.


**127.** `14:32` **You**

I get it you have a dif perspective so do I\.


**128.** `14:33` **Meredith Lamb (+14169386001)**

Do you feel like I stole your friend?


**129.** `14:33` **You**

No I feel like he abandoned me\.


**130.** `14:34` **Meredith Lamb (+14169386001)**

Aw but he’s a guy\. He probably doesn’t realize it


**131.** `14:34` **You**

Kk well you asked


**132.** `14:34` **Meredith Lamb (+14169386001)**

OK, well I didn’t tell him that


**133.** `14:35` **You**

It’s fine I suggested not to it wouldn’t make a difference on my decision


**134.** `14:35` **Meredith Lamb (+14169386001)**

What decision?


**135.** `14:35` **You**

To just not reach out to him anymore


**136.** `14:36` **Meredith Lamb (+14169386001)**

k well I’m sure he will reach out or maybe not because he heard about you second hand


**137.** `14:36` **You**

???


**138.** `14:36` **You**

What’d you tell him


**139.** `14:37` **Meredith Lamb (+14169386001)**

He hears about you through me so maybe he thinks he’s all caught up and things are “ok”\.
He said I really shouldn’t tell Andrew


**140.** `14:37` **Meredith Lamb (+14169386001)**

He said I need to be more patient and let the ink dry


**141.** `14:37` **Meredith Lamb (+14169386001)**

😝


**142.** `14:37` **You**

2 years


**143.** `14:38` **Meredith Lamb (+14169386001)**

I think end of August


**144.** `14:38` **Meredith Lamb (+14169386001)**

One month


**145.** `14:39` **You**

2 years till this is real perhaps\.


**146.** `14:39` **You**

Or maybe when we are 50


**147.** `14:42` **Meredith Lamb (+14169386001)**

Not on my end …


**148.** `14:45` **You**

We will see… it’s all good I will go back to school, learn a trade, become a bouncer, meet new people make new friends\.\. all kinds of time to find myself again lol\.\. but I am certainly ready to throw all of that in the trash when you are ready\.


**149.** `14:46` **Meredith Lamb (+14169386001)**

When do you think you will tell maddie for real?


**150.** `14:46` **You**

I already did


**151.** `14:46` **Meredith Lamb (+14169386001)**

No like for real for real… like no hiding shit


**152.** `14:47` **You**

August\.\. maybe I guess\.\. when she is back home


**153.** `14:50` **Meredith Lamb (+14169386001)**

Depending on how accepting she is… she could come to cottage over the school year at some point\(s\) either with or without my kids\. See if our kids get socialized to the idea then maybe we can see each other more


**154.** `14:50` **Meredith Lamb (+14169386001)**

Just be different circumstances


**155.** `14:50` **Meredith Lamb (+14169386001)**

Sometimes


**156.** `14:50` **You**

Like I told her I really liked you and wanted to have a relationship with you and we were going to try


**157.** `14:50` **Meredith Lamb (+14169386001)**

>
And I’m not talking like immediately

*💬 Reply*

**158.** `14:50` **You**

Oh listen don’t get my hopes up\.\. rofl


**159.** `14:51` **You**

They aren’t\.\. btw


**160.** `14:51` **You**

lol


**161.** `14:51` **Meredith Lamb (+14169386001)**

Who aren’t?


**162.** `14:51` **You**

Play it by ear


**163.** `14:51` **You**

Isn’t that what you like


**164.** `14:51` **You**

My hopes aren’t up


**165.** `14:51` **You**

They


**166.** `14:52` **Meredith Lamb (+14169386001)**

I don’t think my kids would care too much honestly but I might be REALLY naive\.


**167.** `14:52` **Meredith Lamb (+14169386001)**

I know Mac wouldn’t


**168.** `14:52` **Meredith Lamb (+14169386001)**

Once my kids know my mom has met you etc that will influence things a lot also for them


**169.** `14:53` **You**

I don’t know how Maddie would be whether she would be comfortable or not or feel like she was betraying Jaimie


**170.** `14:53` **You**

I will find out later


**171.** `14:54` **Meredith Lamb (+14169386001)**

My younger two will feel like they are being disloyal to their dad for sure


**172.** `14:54` **Meredith Lamb (+14169386001)**

But I wouldn’t position it as a “family” weekend


**173.** `14:54` **Meredith Lamb (+14169386001)**

Positioning would be very carefully considered


**174.** `14:54` **Meredith Lamb (+14169386001)**

Like no big family dinners


**175.** `14:54` **Meredith Lamb (+14169386001)**

Etc


**176.** `14:55` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 4 Jul 2025 14:55:13 \-0400
|
| They wouldn’t like that guaranteed
|
| Version: 1
| Sent: Fri, 4 Jul 2025 14:55:05 \-0400
|
| They wouldn’t like that guarantees


**177.** `14:55` **Meredith Lamb (+14169386001)**

Would just be too soon


**178.** `14:55` **You**

Now you are over thinking


**179.** `14:56` **Meredith Lamb (+14169386001)**

No, I have to think about a freaking middle schooler …\. Groan


**180.** `14:56` **You**

But not now


**181.** `14:56` **Meredith Lamb (+14169386001)**

She requires overthinking lol


**182.** `14:58` **You**

I would rather think about the next potential opportunity to spend time with you and what magic I need to perform\.


**183.** `15:05` **Meredith Lamb (+14169386001)**

Magic to make it happen or magic when we are together? Or both? Lol


**184.** `15:07` **You**

Reaction: ❤️ from Meredith Lamb
I felt like the together stuff happened naturally


**185.** `15:07` **You**

I didn’t have to try that is why I am so dismayed this week


**186.** `15:09` **You**

I mean at least from my perspective it was perfect and easy and wonderful and maybe just slightly overly physical at times\.\. but we can work on that\.\. and then to realize that that kind of thing is never going to happen again for like a year or more\.\. kicked in the face


**187.** `15:09` **You**

So the magic would be in making the most of any opportunity


**188.** `15:10` **You**

If the 50/50 stays or is even partial where you get weekends off or a weekend off or anything that is what I would need to be ready for\.\. or like whatever comes in the next few months\.\. I think you said it earlier… or you joked you want me to be available which is partly why you don’t like the whole me getting a life thing\.


**189.** `15:15` **Meredith Lamb (+14169386001)**

It’s not that I don’t want you to get a life\. I do\. I just want to be part of it and get worried I won’t be\. 🙁


**190.** `15:17` **You**

I get it\.\. there is nothing I wouldn’t build that I couldn’t walk away from or incorporate you in it\.  You are the most important thing, the only thing central to me building a new life


**191.** `15:17` **Meredith Lamb (+14169386001)**

>
Me too… which is why I didn’t want to push the “open” convo too early and too much because I was just hoping it would be natural

*💬 Reply*

**192.** `15:17` **Meredith Lamb (+14169386001)**

>
This makes me happy

*💬 Reply*

**193.** `15:17` **You**

How much more open is there?


**194.** `15:17` **You**

lol


**195.** `15:17` **Meredith Lamb (+14169386001)**

lol\!


**196.** `15:18` **Meredith Lamb (+14169386001)**

No comment


**197.** `15:20` **You**

Good I like surprises\.


**198.** `15:20` **Meredith Lamb (+14169386001)**

Do you really?


**199.** `15:20` **You**

Yep


**200.** `15:20` **You**

From you


**201.** `15:20` **You**

I just don’t like details\.\. lol


**202.** `15:21` **Meredith Lamb (+14169386001)**

LOL


**203.** `15:21` **Meredith Lamb (+14169386001)**

Ok surprises but no details\. Noted\.


**204.** `15:21` **You**

Not a this one time at band camp let’s try this kind of story


**205.** `15:22` **You**

But the surprise whatever you want to try\.\. game\.


**206.** `15:22` **Meredith Lamb (+14169386001)**

My head is spinning


**207.** `15:23` **You**

Reaction: ❤️ from Meredith Lamb
Have never been as comfortable with anyone ever\.\. would never walk around naked any of that with anyone period so that should say something\.  I am completely comfortable and have complete trust in you\.


**208.** `15:24` **Meredith Lamb (+14169386001)**

Surprises me


**209.** `15:24` **Meredith Lamb (+14169386001)**

But not upset


**210.** `15:24` **Meredith Lamb (+14169386001)**

lol


**211.** `15:27` **You**

What surprises you?


**212.** `15:27` **You**

And why would you be upset lol


**213.** `15:27` **You**

Did I mistype something


**214.** `15:28` **Meredith Lamb (+14169386001)**

Just surprises me how uncomfortable you have been\. I don’t get why


**215.** `15:29` **You**

Uncomfortable I have been with what\.\. in the past before you


**216.** `15:29` **Meredith Lamb (+14169386001)**

Yes


**217.** `15:30` **You**

Self conscious\.\. was always worried about what people were thinking\.\. or comparing me to whatever all that shit\.\. I just never think about it when I am with you\.\. it doesn’t matter\.\. why would you be upset?


**218.** `15:31` **Meredith Lamb (+14169386001)**

I’m not upset at all in hearing that\. That’s all I meant\.


**219.** `15:31` **Meredith Lamb (+14169386001)**

I just didn’t know guys were insecure


**220.** `15:31` **Meredith Lamb (+14169386001)**

I haven’t really experienced that before


**221.** `15:32` **You**

Ah ok\.\. was a little confused\.\. meant as a compliment\.\. I mean maybe not the ones you have met\.\. I am, but again I am all about pleasing others which is kind of the origination of my insecurity\.\. am I good enough are they happy enough etc always going through my head\.\. part of my makeup\.


**222.** `15:33` **You**

Not selfish and be appalled if I came across that way\.


**223.** `15:33` **Meredith Lamb (+14169386001)**

You do not come across that way at all


**224.** `15:33` **Meredith Lamb (+14169386001)**

Not sure if I told you but after we told Jim, he and I were talking at some point and


**225.** `15:34` **Meredith Lamb (+14169386001)**

I can’t remember the context


**226.** `15:34` **Meredith Lamb (+14169386001)**

But he said something about you having “empathy in spades”


**227.** `15:34` **You**

Yeah that’s true


**228.** `15:34` **Meredith Lamb (+14169386001)**

I’d never heard him say it that before


**229.** `15:35` **Meredith Lamb (+14169386001)**

When I first started cait and David painted you like a bully


**230.** `15:35` **Meredith Lamb (+14169386001)**

It was weird


**231.** `15:35` **You**

Reaction: 😂 from Meredith Lamb
Because they didn’t do their jobs


**232.** `15:35` **You**

And I held back for so long


**233.** `15:35` **You**

Even Craig was like cmon Scott


**234.** `15:36` **You**

So I need to amend an earlier statement, insecurity\.  While I have always been insecure I am fairly certain I never came off that way\.  I also wouldn’t have came off as arrogant\.\. but no one would have thought I had any insecurities\.


**235.** `15:37` **You**

I have only been transparent with you


**236.** `15:37` **Meredith Lamb (+14169386001)**

Yes I would never have thought that when I first met you


**237.** `15:37` **You**

So you seeing what you saw is normal


**238.** `15:38` **Meredith Lamb (+14169386001)**

However were you feeling insecure about getting Tom’s job?


**239.** `15:38` **You**

I was feeling unprepared


**240.** `15:38` **Meredith Lamb (+14169386001)**

I think you were bc of the whole pri thing


**241.** `15:38` **You**

But I reminded myself


**242.** `15:38` **You**

No not that


**243.** `15:39` **You**

It was more about if I could do it\.\. but I reminded myself I already managed at this level
Before even coming to wnbridge and I am already better than at least three managers already


**244.** `15:39` **You**

So just a bit there


**245.** `15:40` **You**

But relationships are different


**246.** `15:40` **Meredith Lamb (+14169386001)**

>
Right but many ppl wouldn’t question if they could do it\. That was your insecurity\. You are better than you often think

*💬 Reply*

**247.** `15:40` **You**

Especially one like this with the feelings I have and the fear of losing it\.   Everything becomes very important to me\.\. I am always thinking\.\.


**248.** `15:41` **You**

>
Sometimes it isn’t that I think it but that I want others to

*💬 Reply*

**249.** `15:41` **You**

Lower expectations


**250.** `15:41` **You**

Either to over deliver or have them underestimate me


**251.** `15:42` **You**

Btw I did not do that with you\. Everything I told you was 1000% true\.\.


**252.** `15:42` **You**

No twisting or turning or bending straight facts


**253.** `15:42` **Meredith Lamb (+14169386001)**

I know


**254.** `15:42` **You**

But I won’t lie I was very worried\.\.


**255.** `15:43` **Meredith Lamb (+14169386001)**

Very worried about me?


**256.** `15:43` **Meredith Lamb (+14169386001)**

Judging?


**257.** `15:43` **You**

Worried about how it would go, judging yeahnsll that same shit


**258.** `15:44` **Meredith Lamb (+14169386001)**

You were worried because you didn’t know that I liked you for a long time already…\. lol had you known that it might have been different for you


**259.** `15:46` **You**

No that really isn’t it\.\. we each have a past and I am 47 and you were far more sexually active than me and I was scared I would just fail\.\. period\.


**260.** `15:47` **Meredith Lamb (+14169386001)**

“fail” … sucks that you felt that because it really isn’t about that\. It was just about us connecting\. But I get it as much as I can, not being a guy …\.


**261.** `15:49` **You**

Yep well that is where my head goes\.  Is what it is\.\.  I have girl friends or have had them I have heard them talk\.\. lol so I kinda know\.\. so this worried it’s fine I am ok with myself now\.


**262.** `15:49` **You**

It’s who I am and it is what I am capable of\.\. all I can do


**263.** `15:50` **Meredith Lamb (+14169386001)**

You are a perfectionist to a fault


**264.** `15:50` **Meredith Lamb (+14169386001)**

Virgo


**265.** `15:50` **You**

Hardly a perfectionist in this


**266.** `15:51` **You**

Shooting for adequate


**267.** `15:51` **You**

lol


**268.** `15:51` **You**

I am also a realist


**269.** `15:51` **Meredith Lamb (+14169386001)**

Um, I beg to differ\. I know zero guys our age doing what you are doing


**270.** `15:51` **Meredith Lamb (+14169386001)**

I mean even guys in their 20s are not


**271.** `15:52` **Meredith Lamb (+14169386001)**

It’s weird


**272.** `15:52` **Meredith Lamb (+14169386001)**

Just so you are aware


**273.** `15:54` **You**

I don’t have a basis\.\. and I try not to think because it messes me up\.\. so I just look at you\.  There was a moment I cannot remember what night I think it was first night in London\.\. I couldn’t stop looking at you it was insane you were so beautiful and I almost just stopped and laid there\.\.  was crazy… nothing like that like anything we do has ever been close to this\.\. it’s almost too much for me\.  Well this when the aftershock hits


**274.** `15:55` **Meredith Lamb (+14169386001)**

🫠


**275.** `15:55` **Meredith Lamb (+14169386001)**

Well I have a basis …


**276.** `15:55` **Meredith Lamb (+14169386001)**

Not just myself but I have friends who talk and talked a lot more in their 20s


**277.** `15:56` **Meredith Lamb (+14169386001)**

Plus I was with someone with a high sex drive relative to allllllll my friends \(wtf\) so…\.


**278.** `15:56` **Meredith Lamb (+14169386001)**

I have a pretty good basis


**279.** `15:56` **Meredith Lamb (+14169386001)**

For comparison or relativity or whatever


**280.** `15:58` **Meredith Lamb (+14169386001)**

Ps\. Women don’t talk about that shit in their late 40s


**281.** `15:59` **You**

Well that is good\.\. what you mean share the sex talk stuff yeah I figured


**282.** `15:59` **You**

Reaction: 😂 from Meredith Lamb
Guys neither although I wanted to tell Mike


**283.** `15:59` **You**

lol


**284.** `16:00` **You**

I just said we had an amazing weekend\.


**285.** `16:00` **Meredith Lamb (+14169386001)**

Yeah they are all discussing life more so\. 20s and early 30s conversations are much different


**286.** `16:01` **You**

Well I was never worried about you talking to people


**287.** `16:01` **Meredith Lamb (+14169386001)**

At the cottage, my best friend from high school and uni will be there\. She doesn’t know about you


**288.** `16:01` **Meredith Lamb (+14169386001)**

She will ask


**289.** `16:01` **Meredith Lamb (+14169386001)**

She’s different


**290.** `16:01` **Meredith Lamb (+14169386001)**

lol


**291.** `16:01` **You**

Yeah we all have those friends


**292.** `16:02` **Meredith Lamb (+14169386001)**

Yah it will be very interesting bc the two is us never got into anything good


**293.** `16:02` **Meredith Lamb (+14169386001)**

Mandy and Kim are better behaved lol


**294.** `16:03` **You**

Doesn’t surprise me


**295.** `16:04` **Meredith Lamb (+14169386001)**

https://flic\.kr/p/5FXzn


**296.** `16:04` **Meredith Lamb (+14169386001)**

She’s trouble\.


**297.** `16:05` **You**

It’s in the eyes


**298.** `16:05` **Meredith Lamb (+14169386001)**

She’s so excited about the cottage weekend


**299.** `16:05` **You**

It’s in your eyes too if you are wondering


**300.** `16:05` **You**

Still


**301.** `16:05` **Meredith Lamb (+14169386001)**

It’s all her\. Lol


**302.** `16:05` **Meredith Lamb (+14169386001)**

Kidding it was actually me but she just goes along with it


**303.** `16:06` **Meredith Lamb (+14169386001)**

That’s her trouble


**304.** `16:06` **Meredith Lamb (+14169386001)**

She would never reign me in


**305.** `16:06` **You**

I mean when I look into your eyes today


**306.** `16:06` **You**

Just a bit of mischief I have told you before


**307.** `16:07` **Meredith Lamb (+14169386001)**

I like to have fun … sometimes


**308.** `16:07` **You**

Uh huh


**309.** `16:08` **Meredith Lamb (+14169386001)**

Jim showed me photos of the “concert” they go to at his friends farm\. I have seen them before when I worked for him


**310.** `16:08` **Meredith Lamb (+14169386001)**

Looks very fun


**311.** `16:08` **Meredith Lamb (+14169386001)**

But not feeling it tonight


**312.** `16:08` **You**

Reaction: 😡 from Meredith Lamb
2 years


**313.** `16:09` **Meredith Lamb (+14169386001)**

Reaction: 😮 from Scott Hicks
Country singer from boots and hearts is going to be playing


**314.** `16:11` **You**

There will be other nights some day down the road


**315.** `16:12` **Meredith Lamb (+14169386001)**

Yeah I’m not worried\. Last weekend was amazing\. Need recovery time lol


**316.** `16:12` **You**

Was good after a day\.


**317.** `16:13` **You**

But yeah that pace is impossible


**318.** `16:13` **You**

Unless it isn’t


**319.** `16:13` **You**

We will have to see


**320.** `16:13` **Meredith Lamb (+14169386001)**

It is


**321.** `16:14` **Meredith Lamb (+14169386001)**

Absolutely is lol


**322.** `16:14` **You**

Maybe not though


**323.** `16:14` **Meredith Lamb (+14169386001)**

Yes


**324.** `16:14` **Meredith Lamb (+14169386001)**

It is


**325.** `16:14` **Meredith Lamb (+14169386001)**

I could hardly walk the day at the mall


**326.** `16:14` **Meredith Lamb (+14169386001)**

Not even kidding lol


**327.** `16:14` **You**

I mean over short periods of time bit indefinitely


**328.** `16:14` **Meredith Lamb (+14169386001)**

I powered on


**329.** `16:14` **You**

Not


**330.** `16:15` **Meredith Lamb (+14169386001)**

Huh?


**331.** `16:15` **Meredith Lamb (+14169386001)**

Let’s just say it is and call it a day


**332.** `16:15` **You**

No sorry I meant bit normally only in certain situations


**333.** `16:16` **You**

Anyhow it won’t be the norm


**334.** `16:16` **You**

When there is actually a norm


**335.** `16:16` **You**

Kk so I am
Pretty much home\.\.


**336.** `16:16` **Meredith Lamb (+14169386001)**

Fun


**337.** `16:17` **You**

Yeah\.\. just wanted to let you know\.\.


**338.** `16:17` **You**

I love you Mer\.\. will be around later if
You feel like chatting\.\. I think part of what we should do btw is watch a show together but apart we need some conversation fodder


**339.** `16:18` **You**

It cannot always be about us and it wouldn’t and wasn’t when we were together


**340.** `16:18` **You**

Anyways just an idea


**341.** `16:18` **Meredith Lamb (+14169386001)**

I thought you weren’t into tv


**342.** `16:18` **You**

I am not but we need something


**343.** `16:20` **Meredith Lamb (+14169386001)**

K well I might get drunk and take a gummy and watch this movie Jim said to try


**344.** `16:20` **You**

Ok well if you let me know I might watch I won’t be drunk or stoned though\.


**345.** `16:21` **Meredith Lamb (+14169386001)**

lol


**346.** `16:21` **You**

Weekend is over for me 🙁


**347.** `16:21` **Meredith Lamb (+14169386001)**

It’s called “heads of state” on prime


**348.** `16:21` **You**

Kk


**349.** `16:21` **You**

I will look it up


**350.** `16:22` **Meredith Lamb (+14169386001)**

I have to have a family meeting tho first whenever everyone gets home\.


**351.** `16:22` **Meredith Lamb (+14169386001)**

Business\. Then relaxing\.


**352.** `16:22` **You**

??


**353.** `16:22` **Meredith Lamb (+14169386001)**

Everyone is slacking and I’m leaving\. Andrew said he would do some stuff he didn’t\. Mac same\.


**354.** `16:23` **Meredith Lamb (+14169386001)**

We need to have a serious discussion\. It’s honestly ridiculous\.


**355.** `16:23` **You**

Ah ok\.\.  I get it


**356.** `16:23` **You**

Well good luck… hope you get through that and to the relaxing part of your evening


**357.** `16:23` **Meredith Lamb (+14169386001)**

Poor Marlowe gets left with these slobs and she is the only one who cleans up


**358.** `16:24` **Meredith Lamb (+14169386001)**

Miss you and ttyl\. Going to walk dogs with marmar


**359.** `16:24` **Meredith Lamb (+14169386001)**

❤️


**360.** `16:24` **You**

Love you\.


**361.** `16:24` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Love you too


**362.** `17:07` **Meredith Lamb (+14169386001)**

Mac just bought me a bottle of wine with her fake id\. Just saying\.


**363.** `17:28` **You**

Nice daughter


**364.** `17:29` **You**

Lucky mine don’t do that


**365.** `17:31` **You**

going to pick up supper for family will have company yay me\.\. :\) aces\!\!


**366.** `17:31` **You**

14 days


**367.** `18:43` **Meredith Lamb (+14169386001)**

I had another nap lol I have never napped so much in so long


**368.** `18:44` **You**

nice\.\. finished supper\.\. got yelled at on ride back\.\. lol


**369.** `18:44` **You**

par for the course


**370.** `18:44` **Meredith Lamb (+14169386001)**

By…?


**371.** `18:44` **You**

wife


**372.** `18:44` **Meredith Lamb (+14169386001)**

Oh


**373.** `18:45` **You**

you came up again\.\. but she wasn't yelling at me about that\.


**374.** `18:45` **You**

to use Craig's phrase


**375.** `18:45` **You**

I kind of keep dripping the idea that we aren't sure if we will be able to make a relationship work\.\. but that we are interested


**376.** `18:45` **Meredith Lamb (+14169386001)**

What was it?
Going to have my family meeting now


**377.** `18:45` **You**

msg me after


**378.** `18:45` **You**

good luck


**379.** `18:46` **Meredith Lamb (+14169386001)**

>
Why do you do this?

*💬 Reply*

**380.** `18:46` **You**

because if she raises it it gives me an opening\.\.


**381.** `18:46` **You**

it is like socializing


**382.** `18:46` **You**

I said so if Meredith and I make a go of it are you going to make my life hell


**383.** `18:47` **You**

she said as if we would be in that kind of contact for that to happen


**384.** `18:47` **You**

I thought you had your family meeting we can chat about this later if you want


**385.** `18:47` **Meredith Lamb (+14169386001)**

Or are you just giving us bad karma by saying that? Lol


**386.** `18:47` **You**

Reaction: 😢 from Meredith Lamb
I mean the unique part is I am not lying\.\. we are interested and we are going to try\.


**387.** `18:48` **You**

I just didn't say we are going to succeed


**388.** `18:48` **You**

omission


**389.** `18:48` **You**

>
The only way this won't work is if one of us gives up\.

*💬 Reply*

**390.** `18:48` **You**

and if we mean as much as we say we do to one another\.\. then that will never happen\.


**391.** `19:40` **You**

not sure if you are done yet or read this last\.\. but again I think we will be the only ones to end this\.\. turning on heads of state now\.


**392.** `20:05` **Meredith Lamb (+14169386001)**

>
Correct exactly\.

*💬 Reply*

**393.** `20:05` **Meredith Lamb (+14169386001)**

>
Still in family meeting\. Topics have progressed quickly\. Mostly scheduling\.

*💬 Reply*

**394.** `20:06` **You**

That is a long fucking meeting insane


**395.** `20:11` **You**

I should have waited to start but I will be in bed before long anyways\.


**396.** `20:16` **Meredith Lamb (+14169386001)**

I’m drinking so it’s fine lol


**397.** `20:16` **Meredith Lamb (+14169386001)**

We have so much scheduling to discuss\. Cottage Reno etc etc


**398.** `20:17` **You**

Kk well have a good night you will probably be going for a while\.


**399.** `20:36` **Meredith Lamb (+14169386001)**

Did you start that movie for real?


**400.** `20:36` **You**

Yeah half way through


**401.** `20:37` **You**

Reaction: 😂 from Meredith Lamb
I thought you would be done and watching\.\. I wanted to keep up


**402.** `20:37` **You**

Got fucking yelled at again for another 30 mins


**403.** `20:37` **Meredith Lamb (+14169386001)**

>
The answer to this is likely\. Lol

*💬 Reply*

**404.** `20:38` **You**

I don’t even know if I survive next 14 days\.\. Jesus this is hell


**405.** `20:38` **Meredith Lamb (+14169386001)**

Yelled at for what?


**406.** `20:38` **You**

>
No to that she said not likely

*💬 Reply*

**407.** `20:38` **You**

>
Just tried to go up and get them to do some stuff with me\.

*💬 Reply*

**408.** `20:38` **You**

I can’t stay here anymore I think I might have to leave I am not sure


**409.** `20:39` **You**

Reaction: 😮 from Meredith Lamb
Anyways go watch your show I am ironing for a few more mins then going to take whatever the fuck I have to to go to sleep…\.\.


**410.** `20:40` **You**

Hope the family thing went well sounds like it probably did\.


**411.** `20:41` **Meredith Lamb (+14169386001)**

>
She will be a pain because she will continue to depend on you and ask you to do shit constantly probably\.

*💬 Reply*

**412.** `20:42` **You**

No not the same and if she asked but was fine with maddie going to cottage price I would fucking pay


**413.** `20:42` **Meredith Lamb (+14169386001)**

What are you being yelled at for??


**414.** `20:42` **Meredith Lamb (+14169386001)**

>
What do you mean?

*💬 Reply*

**415.** `20:42` **You**

I told you I went upstairs and tried to get them going to get some work done


**416.** `20:43` **You**

I am trying to get Jaimie to a point where she won’t give e shit if maddie meets you


**417.** `20:43` **Meredith Lamb (+14169386001)**

I don’t think that is up to you though


**418.** `20:43` **Meredith Lamb (+14169386001)**

Maddie will be 18 soon


**419.** `20:43` **You**

It is I can make shit like this happen I know her I just have to play it right


**420.** `20:43` **You**

She will be 18 in a year


**421.** `20:43` **You**

1 year\! lol


**422.** `20:44` **Meredith Lamb (+14169386001)**

Oh right forgot


**423.** `20:44` **You**

Not soon


**424.** `20:44` **Meredith Lamb (+14169386001)**

lol


**425.** `20:44` **You**

ROFL


**426.** `20:44` **You**

How many melatonin can I take\.


**427.** `20:44` **Meredith Lamb (+14169386001)**

Why the f would she care if a SEVENTEEN year old met me?


**428.** `20:44` **You**

I never take them


**429.** `20:44` **Meredith Lamb (+14169386001)**

Like I don’t get that


**430.** `20:44` **You**

She is getting to the point where she won’t


**431.** `20:45` **Meredith Lamb (+14169386001)**

>
It isn’t how many pills\. It is mg

*💬 Reply*

**432.** `20:45` **Meredith Lamb (+14169386001)**

>
Well geez I should hope not

*💬 Reply*

**433.** `20:45` **You**

Like 20  5
Mg piills maybe I take 4


**434.** `20:45` **Meredith Lamb (+14169386001)**

I don’t give a shit if my girls meet Andrew’s new whoever


**435.** `20:45` **Meredith Lamb (+14169386001)**

Like why would I care about that?


**436.** `20:45` **Meredith Lamb (+14169386001)**

They aren’t little kids


**437.** `20:46` **You**

It isn’t you it is J


**438.** `20:46` **You**

Reaction: ❓ from Meredith Lamb
She is did


**439.** `20:46` **You**

Why do you think I am doing what I am doing


**440.** `20:46` **You**

We are not compatible


**441.** `20:46` **You**

In so many ways


**442.** `20:46` **You**

Turning movie off


**443.** `20:46` **You**

She is different


**444.** `20:46` **You**

Not did


**445.** `20:46` **Meredith Lamb (+14169386001)**

Oh


**446.** `20:46` **Meredith Lamb (+14169386001)**

I guess


**447.** `20:46` **Meredith Lamb (+14169386001)**

Because that is just weird


**448.** `20:47` **Meredith Lamb (+14169386001)**

Sorry


**449.** `20:47` **Meredith Lamb (+14169386001)**

I get it if they were kids


**450.** `20:47` **Meredith Lamb (+14169386001)**

But they are not


**451.** `20:47` **You**

Did you get everything sorted?


**452.** `20:47` **Meredith Lamb (+14169386001)**

Yep just did a ton of scheduling and figuring out beds\. What’s going to cottage what’s not etc etc


**453.** `20:47` **You**

My life is shit not worth talking about honestly


**454.** `20:47` **You**

Well at least you were productive


**455.** `20:48` **Meredith Lamb (+14169386001)**

So wait what was the argument tho


**456.** `20:48` **You**

Mer


**457.** `20:48` **You**

How many glasses


**458.** `20:48` **Meredith Lamb (+14169386001)**

Scott


**459.** `20:48` **Meredith Lamb (+14169386001)**

lol


**460.** `20:48` **You**

And gummies


**461.** `20:48` **Meredith Lamb (+14169386001)**

I’m using a really small glass so it isn’t accurate


**462.** `20:48` **Meredith Lamb (+14169386001)**

No gummies


**463.** `20:48` **You**

God I wish I was with you right now\.


**464.** `20:48` **You**

For the third time


**465.** `20:48` **Meredith Lamb (+14169386001)**

>
Same

*💬 Reply*

**466.** `20:48` **You**

Reaction: 😮 from Meredith Lamb
I went upstairs and woke her ass up off the couch


**467.** `20:49` **You**

And asked her if we were going to do anything


**468.** `20:49` **You**

And she got pissed again\.\. we were supposed to work earlier


**469.** `20:50` **Meredith Lamb (+14169386001)**

Pissed because you are pressuring?


**470.** `20:51` **Meredith Lamb (+14169386001)**

It’s so odd bc Andrew is still being nice to me


**471.** `20:52` **Meredith Lamb (+14169386001)**

I made some comment in front of the kids about if he is assholish to me then…… and he smirks and rolls his eyes and is all I’m not like that


**472.** `20:52` **Meredith Lamb (+14169386001)**

He is going to move some furniture for me to new place


**473.** `20:53` **Meredith Lamb (+14169386001)**

We are taking our king bed to cottage to replace Mac’s queen\. Then we essentially have two masters at the cottage


**474.** `20:53` **Meredith Lamb (+14169386001)**

Sorry the proverbial “we”


**475.** `20:53` **Meredith Lamb (+14169386001)**

I am not taking it\. He will\. I said I would help


**476.** `20:54` **Meredith Lamb (+14169386001)**

He raised his eye brows


**477.** `20:54` **Meredith Lamb (+14169386001)**

I said I’d drive separately


**478.** `20:54` **Meredith Lamb (+14169386001)**

Not in u haul


**479.** `20:54` **You**

Well you are getting along at least happy for you


**480.** `20:55` **Meredith Lamb (+14169386001)**

It’s not going to last though\. I don’t get it


**481.** `20:56` **You**

I think I am
Right


**482.** `20:56` **You**

So we’ll see


**483.** `20:56` **Meredith Lamb (+14169386001)**

So was she mad at you for waking her up or for pressuring?


**484.** `20:56` **You**

I dunno I didn’t ask\.


**485.** `20:57` **Meredith Lamb (+14169386001)**

You do know that when she is gone, she is like gone right


**486.** `20:57` **Meredith Lamb (+14169386001)**

Like that is crazy


**487.** `20:57` **Meredith Lamb (+14169386001)**

I don’t have that situation


**488.** `20:57` **You**

Like I said will I make it…\. That is the question\.


**489.** `20:57` **You**

lol


**490.** `20:57` **Meredith Lamb (+14169386001)**

So you are going through pain but then there will be this huge void


**491.** `20:57` **You**

Yeah that will feel better for sure


**492.** `20:58` **You**

Surrounded by nothing but my own failure lol


**493.** `20:58` **You**

SCORE\!\!


**494.** `20:58` **You**

lol


**495.** `20:58` **Meredith Lamb (+14169386001)**

No not failure, progress


**496.** `20:58` **You**

It doesn’t feel that way it feels like I have been obliterated\. And I am too tired to keep going on like this tbh


**497.** `20:59` **Meredith Lamb (+14169386001)**

I don’t get why they are being so awful to you still


**498.** `20:59` **You**

Because I am a bastard\.\. I broke the family\.\.


**499.** `20:59` **Meredith Lamb (+14169386001)**

Isn’t it time to just accept


**500.** `20:59` **You**

Never


**501.** `20:59` **You**

Grudge forever


**502.** `20:59` **Meredith Lamb (+14169386001)**

Did you? It takes 2 to tango


**503.** `21:00` **Meredith Lamb (+14169386001)**

I don’t blame Andrew fully


**504.** `21:00` **You**

She will fuck off for sure but she will always throw it at me


**505.** `21:00` **Meredith Lamb (+14169386001)**

I played a role


**506.** `21:00` **You**

Again different people


**507.** `21:00` **Meredith Lamb (+14169386001)**

Ughhh


**508.** `21:00` **You**

It’s fine not your problem\.\. I told you earlier my my life is shit not worth discussing I just have to get through this as intact as I can get through it\.\.


**509.** `21:01` **You**

Will see what kind of shape I am in then


**510.** `21:01` **Meredith Lamb (+14169386001)**

Well it is my indirect problem lol


**511.** `21:01` **Meredith Lamb (+14169386001)**

Your problems are my problems now


**512.** `21:01` **You**

We aren’t going to really see each other likely until after they are gone or well beyond that\.\. so you don’t really need to worry\.


**513.** `21:01` **You**

>
No mer they aren’t\.\.

*💬 Reply*

**514.** `21:02` **Meredith Lamb (+14169386001)**

If we are in a relationship and it is affecting you, it affects me


**515.** `21:02` **You**

…\.\.


**516.** `21:05` **Meredith Lamb (+14169386001)**

What is that?


**517.** `21:05` **You**

I don’t know i started to say different things deleted them and then didn’t know what to do


**518.** `21:06` **Meredith Lamb (+14169386001)**

So are all 3 of them really mad at you or mostly 2?


**519.** `21:06` **Meredith Lamb (+14169386001)**

Do you want to just go to bed?


**520.** `21:06` **Meredith Lamb (+14169386001)**

Take 10\-20 mg of melatonin and sleep\. But it will make you drowsy in morning\.  Only shitty part


**521.** `21:07` **You**

I don’t know what I am going to do\.\. you just go do your thing\.


**522.** `21:09` **Meredith Lamb (+14169386001)**

I’m just sitting drinking


**523.** `21:09` **Meredith Lamb (+14169386001)**

lol


**524.** `21:10` **Meredith Lamb (+14169386001)**

Haven’t had dinner so waiting for a piece of pizza


**525.** `21:10` **Meredith Lamb (+14169386001)**

Oh so Mac cried on Andrew today


**526.** `21:10` **Meredith Lamb (+14169386001)**

Was great


**527.** `21:11` **Meredith Lamb (+14169386001)**

She is stressed about Reno and he responds to crying\. She didn’t CRY but was almost\. Wiping her eyes


**528.** `21:11` **You**

Awkward


**529.** `21:12` **Meredith Lamb (+14169386001)**

He just thinks she is so strong all the time and she is only human too


**530.** `21:12` **Meredith Lamb (+14169386001)**

I also had to tell him to tell his bro to cool it with the teasing of her


**531.** `21:12` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
All he does is tease her about her style etc etc


**532.** `21:13` **Meredith Lamb (+14169386001)**

He never takes her seriously


**533.** `21:13` **Meredith Lamb (+14169386001)**

Andrew’s going to talk to him


**534.** `21:13` **You**

I like Mac’s style just feel uncomfortable
Sometimes lol


**535.** `21:13` **Meredith Lamb (+14169386001)**

Julian just does it to feel close to her but she feels like he is so judgy


**536.** `21:13` **You**

Dumb boys


**537.** `21:13` **Meredith Lamb (+14169386001)**

>
You likely will all the time

*💬 Reply*

**538.** `21:13` **Meredith Lamb (+14169386001)**

lol


**539.** `21:14` **You**

We’ll
See


**540.** `21:14` **Meredith Lamb (+14169386001)**

She just doesn’t like 100% teasing


**541.** `21:14` **Meredith Lamb (+14169386001)**

And that’s what Julian does


**542.** `21:14` **Meredith Lamb (+14169386001)**

Never takes her seriously


**543.** `21:14` **You**

Some people are
Like that because they don’t know how
To communicate


**544.** `21:15` **Meredith Lamb (+14169386001)**

I tease her a lot but I try to take her seriously also


**545.** `21:15` **Meredith Lamb (+14169386001)**

I think the meeting tonight was helpful to set some expectations for the Reno


**546.** `21:16` **Meredith Lamb (+14169386001)**

But too bad Maelle isn’t around


**547.** `21:16` **You**

Will see how Monday goes


**548.** `21:16` **Meredith Lamb (+14169386001)**

What is Monday?


**549.** `21:16` **Meredith Lamb (+14169386001)**

Ohhhh


**550.** `21:16` **Meredith Lamb (+14169386001)**

Mediation


**551.** `21:16` **You**

Mediation 50/50 all that shit


**552.** `21:17` **Meredith Lamb (+14169386001)**

Tonight he was talking as if they will be here 50%


**553.** `21:17` **Meredith Lamb (+14169386001)**

But then he’s like “no one can be here during water proofing or electrical etc etc”


**554.** `21:17` **You**

That will change


**555.** `21:17` **Meredith Lamb (+14169386001)**

lol


**556.** `21:17` **You**

So he will be with you


**557.** `21:17` **You**

lol


**558.** `21:17` **You**

Called it


**559.** `21:18` **Meredith Lamb (+14169386001)**

No he will be here but no kids


**560.** `21:18` **You**

Mm hm


**561.** `21:18` **Meredith Lamb (+14169386001)**

When we rebuilt the COTTAGE, there was a month or two where he basically lived there full\-time and I was at home with the kids full\-time


**562.** `21:19` **Meredith Lamb (+14169386001)**

It was tricky because there were some major contractor issues that he was struggling with, so I had to call the contractors and give them shit because he was getting frustrated at not being able to come back to Toronto, and then that kind of helped speed things along


**563.** `21:19` **Meredith Lamb (+14169386001)**

He is fine with giving me shit and people at work shit but not contractors for some reason


**564.** `21:19` **Meredith Lamb (+14169386001)**

It’s weird


**565.** `21:20` **You**

I would need to meet him to see
If
I could guage him\. Dunno


**566.** `21:20` **Meredith Lamb (+14169386001)**

It will be so weird like I can’t even tell you there is no other word for me to describe it


**567.** `21:20` **You**

Different


**568.** `21:20` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 4 Jul 2025 21:20:53 \-0400
|
| You guys will meet at volleyball guaranteed
|
| Version: 1
| Sent: Fri, 4 Jul 2025 21:20:43 \-0400
|
| You guys wanna meet at volleyball guaranteed


**569.** `21:21` **You**

Maybe


**570.** `21:21` **You**

Reaction: 😂 from Meredith Lamb
Maybe we never meet


**571.** `21:21` **Meredith Lamb (+14169386001)**

It will be very  a propos


**572.** `21:21` **You**

I mean who knows


**573.** `21:21` **Meredith Lamb (+14169386001)**

No, you will have to be around each other sorry


**574.** `21:22` **You**

I feel like you are getting a better break\.


**575.** `21:22` **Meredith Lamb (+14169386001)**

I totally am


**576.** `21:22` **Meredith Lamb (+14169386001)**

100%


**577.** `21:22` **You**

Like I am I\. Such a fucking hole and then on the other side\.\. all kinds of bad stuff


**578.** `21:23` **Meredith Lamb (+14169386001)**

?


**579.** `21:23` **Meredith Lamb (+14169386001)**

Edit that


**580.** `21:24` **You**

Like I will worry about kids about Andrew about us our relationship being able to see you etc etc \.
Lol\. Here then gone\.\. like it is going to be rough\.\.
You still have a family\.\. and no Jaimie and me available pretty well 24/7 lol\.


**581.** `21:25` **You**

Anyhow not getting into this again\.\. I am going to go to bed before we start
Digging\.


**582.** `21:25` **You**

I am sure you have pizza wine and other things to do more fun than this anyways


**583.** `21:29` **Meredith Lamb (+14169386001)**

I do have a family but you do too\. And my family will be very accepting of you\. They have been so far\. So I don’t see any issues on my end once I can freaking tell them\. It is going to be on your end\. With Jaimie being upset if I meet your kids\.
Ok you can go to bed ❤️ love you


**584.** `21:41` **Meredith Lamb (+14169386001)**

For the record, worried about you\. 🙁


**585.** `21:47` **Meredith Lamb (+14169386001)**

Scott…\.\.


**586.** `21:54` **Meredith Lamb (+14169386001)**

You are reading my messages and not responding


**587.** `22:02` **Meredith Lamb (+14169386001)**

Scott……\.


**588.** `22:11` **Meredith Lamb (+14169386001)**

k what is happening, I know you aren’t likely sleeping\.


**589.** `22:12` **Meredith Lamb (+14169386001)**

I had a gummy 45 min ago\. Put me out of my confused misery


**590.** `22:12` **Meredith Lamb (+14169386001)**

lol


**591.** `22:25` **You**

Mmm


**592.** `22:25` **You**

I don’t think I was reading hon


**593.** `22:25` **You**

Since I was sleeping sorry


**594.** `22:27` **You**

Reaction: ❤️ from Meredith Lamb
I think you might be a bit something sorry wasn’t ignoring\.\. pulled a you and had a nap\.\. who knows what you are up to now so might not get a response


**595.** `22:28` **You**

Reaction: 😢 from Meredith Lamb
Anyways I am worried about me to Mer honestly glad you took a gummy that always helps\.


**596.** `22:28` **You**

Well have a good night ❤️ firing on all cylinders tonight aren’t we…\.\.


**597.** `22:31` **Meredith Lamb (+14169386001)**

Ok I’m glad you were asleep\. All good\. Xoxo


**598.** `22:31` **Meredith Lamb (+14169386001)**

You only have 2 weeks


**599.** `22:31` **Meredith Lamb (+14169386001)**

You can do that


**600.** `22:32` **You**

Yep all is well lol night xo\.


**601.** `22:34` **Meredith Lamb (+14169386001)**

Nite 😢❤️❤️


**602.** `22:38` **You**

Same


**603.** `22:42` **Meredith Lamb (+14169386001)**

Just know that I wish I was with you right now too


**604.** `22:45` **Meredith Lamb (+14169386001)**

And I wish you were in a better mood before bed


**605.** `23:17` **Meredith Lamb (+14169386001)**

Heads of state = 👎


**606.** `23:17` **Meredith Lamb (+14169386001)**

Just finished


**607.** `23:43` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I’m going to bed now\. Gpt helped me write this for you:
Scott is sleeping on a Friday night,
While Mer drinks wine, avoiding a fight\.
The distance between them is plain in sight,
The longing swelling with quiet might\.
She lies on the couch in dim, soft light,
Craving his hands to make it right\.
The ache is more than just desire—
It’s needing him to stoke the fire\.
The night drips slow like candle wax,
Memories playing on heart\-worn tracks\.
She wonders if he dreams of her too—
Or if she’s fading in his view\.
But even through silence, space, and time,
Their hearts stay tethered, still in rhyme\.
No matter the distance, storm, or weather—
They’re bound by love, always, forever\.


