# Daily Conversation: 2025-06-17 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-17 |
| **Day** | Tuesday |
| **Week** | 10 |
| **Messages** | 664 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-17T04:11 - 2025-06-17T21:31 |

## 📝 Daily Summary

This day contains **664 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:11` **You**

Reaction: 😡 from Meredith Lamb
Feel like my photos are a distraction maybe I have to stop sending\.


**002.** `04:14` **You**

So today is chest tris and shoulders so should be fun\.  I am probably going to repeat yesterday was
Nice way to start day\.  I hope you had a good sleep and you get your own workout in\.  I love you mer, thinking about coming home to you someday\.\. man that’s the dream, just a ways off\.  ❤️❤️❤️


**003.** `05:42` **Meredith Lamb (+14169386001)**

>
Good morning 🙂 sooo tired today and my chest is sore from yday lol getting up but want to sleep\. I kept waking up last night for some reason\. 🤔 no idea why

*💬 Reply*

**004.** `05:43` **You**

Atta girl ☺️


**005.** `05:44` **You**

Gets better 🔥🔥🔥


**006.** `05:55` **Meredith Lamb (+14169386001)**

Yawn


**007.** `05:55` **You**

lol am 30 mins in no pics for you if you don’t get your ass moving missy\!\!


**008.** `06:03` **You**

Feel like you are still aleeping


**009.** `06:03` **Meredith Lamb (+14169386001)**

I am not\. Finishing coffee lol


**010.** `06:04` **You**

Sure sure


**011.** `06:04` **Meredith Lamb (+14169386001)**

I think I need you here to get me up


**012.** `06:04` **You**

Reaction: ❤️ from Meredith Lamb
Would be a different warm up / workout


**013.** `06:05` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**014.** `06:06` **Meredith Lamb (+14169386001)**

Not lying


**015.** `06:06` **Meredith Lamb (+14169386001)**

I’m starting at 6\.15


**016.** `06:06` **You**

Kk have fun\.\. I have 2 more excercises then sauna shower and happy place\. Have fun


**017.** `06:08` **Meredith Lamb (+14169386001)**

I have to leave work early to get to marlowe’s nail appt to pay for her \(her appt at 4 so I intend to arrive at like 4\.15ish\) so want to go in earlier today\.


**018.** `06:08` **Meredith Lamb (+14169386001)**

Even tho no one is there really


**019.** `06:08` **Meredith Lamb (+14169386001)**

Everyone in Chatham


**020.** `06:13` **Meredith Lamb (+14169386001)**

Let me see how this workout goes tho


**021.** `06:15` **You**

Reaction: 😮 from Meredith Lamb
Sry just trying to finish up, sled push time


**022.** `06:33` **You**

Alright pics take\. We’ll see if you get any today\.\. hitting showers and sauna now


**023.** `06:36` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**024.** `06:36` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**025.** `06:36` **You**

That’s all for now enjoy rest of workout


**026.** `06:59` **Meredith Lamb (+14169386001)**

Fuck Andrew interrupted my workout


**027.** `07:01` **Meredith Lamb (+14169386001)**

Are you still going to park?


**028.** `07:01` **Meredith Lamb (+14169386001)**

I might just get ready and leave


**029.** `07:06` **You**

Planning on it


**030.** `07:06` **You**

Sry bout Andrew


**031.** `07:07` **Meredith Lamb (+14169386001)**

K I’m just getting ready and going


**032.** `07:07` **Meredith Lamb (+14169386001)**

I will go over if you are there


**033.** `07:07` **You**

Will be there leaving in 5 ish


**034.** `07:42` **Meredith Lamb (+14169386001)**

There is traffic so it says I won’t get there until 812


**035.** `07:42` **You**

I worries I am here now


**036.** `07:43` **You**

No worries


**037.** `07:43` **You**

Even if you cannot make is fine


**038.** `07:52` **Meredith Lamb (+14169386001)**

Waze is rerouting me\. Something wrong on highway


**039.** `09:38` **Meredith Lamb (+14169386001)**

Ok so you asked if my sense on Jim was correct\. This morning he complained about Christine for the first time ever to me\.


**040.** `09:43` **You**

Wow you are a guru\!\!


**041.** `09:43` **You**

The Jim whisperer\.


**042.** `09:49` **Meredith Lamb (+14169386001)**

They are good and solid but you have to understand that they ARE in a 35 year relationship\. So it isn’t all rainbows\.


**043.** `09:50` **You**

Reaction: 😂 from Meredith Lamb
35 years puts us at …\. Your parents age\.


**044.** `09:55` **You**

I guess I send the rest well some of them… some errr

*📎 1 attachment(s)*

**045.** `09:55` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**046.** `09:55` **You**

Going into meet with lawyer have a good one\.


**047.** `10:08` **Meredith Lamb (+14169386001)**

>
Holy …… \!

*💬 Reply*

**048.** `10:08` **Meredith Lamb (+14169386001)**

>
Hope it goes well

*💬 Reply*

**049.** `11:37` **You**

She was annoying


**050.** `11:37` **You**

really annoying


**051.** `11:37` **Meredith Lamb (+14169386001)**

Huh why?


**052.** `11:38` **You**

she just trying for more billables


**053.** `11:38` **Meredith Lamb (+14169386001)**

Oh ugh


**054.** `11:38` **You**

wanted me to give all the documentation to her so she could do her own assessment


**055.** `11:38` **You**

I am like\.\. nuh uh


**056.** `11:38` **You**

I just want to do the min to get her to sign


**057.** `11:38` **You**

will still cost me $1,000 I think


**058.** `11:38` **You**

fucking rip off lol


**059.** `11:38` **Meredith Lamb (+14169386001)**

Yeah really \- yikes


**060.** `11:39` **You**

she was like well I think you are being screwed here but you are getting a benefit here\.\. I am like I know all this\.\. I wrote it\.\.


**061.** `11:39` **You**

J and I agreed to all this\.\. just sign ffs\.


**062.** `11:39` **You**

lol


**063.** `11:39` **You**

anyhow need to review the draft one more time, send my comments across and the updated spreadsheet to her lawyer and hopefully get this fucking put to bed


**064.** `11:39` **Meredith Lamb (+14169386001)**

lol


**065.** `11:40` **Meredith Lamb (+14169386001)**

They aren’t recording town hall fyi


**066.** `11:40` **You**

booooo


**067.** `11:40` **You**

fack


**068.** `11:40` **You**

is it any good?


**069.** `11:40` **Meredith Lamb (+14169386001)**

Karen said directors and vps don’t like to


**070.** `11:40` **Meredith Lamb (+14169386001)**

Everyone did their presentations and now questions


**071.** `11:40` **Meredith Lamb (+14169386001)**

It’s fine


**072.** `11:40` **You**

CM did ok?


**073.** `11:40` **Meredith Lamb (+14169386001)**

Cm did not present


**074.** `11:41` **You**

oh yeah she only did the mgmt meeting


**075.** `11:41` **You**

I don't think I had anything for townhall regardless even if I was there


**076.** `11:41` **You**

Did Ian answer questions?


**077.** `11:41` **Meredith Lamb (+14169386001)**

He is now


**078.** `11:41` **You**

anything spicy?


**079.** `11:41` **Meredith Lamb (+14169386001)**

Answering “rumour on reductions”


**080.** `11:41` **Meredith Lamb (+14169386001)**

Nope same old


**081.** `11:42` **You**

kk  I think there were some spicy ones in there


**082.** `11:43` **Meredith Lamb (+14169386001)**

Katie laukbaum: it feels like the oeb is getting more combative? Why? 🙄


**083.** `11:43` **You**

\.\.\.\.\.


**084.** `11:43` **Meredith Lamb (+14169386001)**

Boring so far


**085.** `11:44` **You**

LOL no excitement for you \- you want blood\.\. \!\!


**086.** `11:44` **Meredith Lamb (+14169386001)**

:p


**087.** `11:44` **Meredith Lamb (+14169386001)**

Got to hear Alison present with her funny voice lol


**088.** `11:44` **Meredith Lamb (+14169386001)**

Always a pleasure


**089.** `11:46` **You**

I bet


**090.** `11:46` **You**

high pitched


**091.** `11:46` **Meredith Lamb (+14169386001)**

Yup and all of her sentences sounded like questions lol


**092.** `11:46` **You**

hehehe


**093.** `11:46` **You**

true


**094.** `11:46` **Meredith Lamb (+14169386001)**

So funny when you know her real voice and talk to her one on one


**095.** `11:47` **You**

she has changed over the past few years\.\. I get a different version of her now\.


**096.** `11:48` **Meredith Lamb (+14169386001)**

Which one is that


**097.** `11:48` **Meredith Lamb (+14169386001)**

She seems so the same to me


**098.** `11:48` **You**

the one with the lower voice that curses and swears a lot


**099.** `11:49` **Meredith Lamb (+14169386001)**

Oh well that is the true her


**100.** `11:49` **Meredith Lamb (+14169386001)**

Bailey knocked it out of the park


**101.** `11:50` **Meredith Lamb (+14169386001)**

Presented what Kristina would have and no evaluation content


**102.** `11:50` **Meredith Lamb (+14169386001)**

She did better than Kristina would have


**103.** `11:50` **You**

yeah I hope B gets the role\.


**104.** `12:14` **Meredith Lamb (+14169386001)**

Andrew is making me so tense today


**105.** `12:14` **Meredith Lamb (+14169386001)**

Ugh


**106.** `12:27` **You**

what is wrong


**107.** `12:29` **Meredith Lamb (+14169386001)**

The way he always talks to the mediator\. Just so annoying\.

*📎 1 attachment(s)*

**108.** `12:30` **Meredith Lamb (+14169386001)**

I am just so tense\. This is driving me nuts\.


**109.** `12:30` **Meredith Lamb (+14169386001)**

She asked for documentation that I moved in May 2009


**110.** `12:30` **Meredith Lamb (+14169386001)**

He said we don’t have any


**111.** `12:31` **Meredith Lamb (+14169386001)**

I said we have two blogs that document it\. Not financial documents but both blogs were active at that time\.


**112.** `12:31` **Meredith Lamb (+14169386001)**

I went to that fucking house every night after work at union gas and we renovated and every weekend


**113.** `12:31` **Meredith Lamb (+14169386001)**

He doesn’t mention any of that


**114.** `12:31` **You**

so yeah


**115.** `12:31` **You**

I was going to ask a few questions


**116.** `12:32` **You**

he has a bit of a problem


**117.** `12:32` **You**

so may 2008 buys house at 480k and funds a rennovation for 70k


**118.** `12:32` **You**

so about 220k is what he is saying 150k from house sale 70k from 401k


**119.** `12:33` **You**

the house is rennovated for a year


**120.** `12:33` **You**

at which time you move in\.\. and I assume start sharing all costs including the mortgage


**121.** `12:33` **You**

So he would have additionally paid 1 year of the mortgage and utilities on his own I assume\.


**122.** `12:34` **You**

Regardless of when your name was added to the lease\.\. if you were paying for the upkeep of the home and contributing to equity in the home your claim time starts in 2009\.  In addition to the sweat equity you put in for the rennovation\.


**123.** `12:34` **You**

between 2008 and 203 the equity on the house goes from 150k


**124.** `12:35` **You**

to 530k


**125.** `12:35` **You**

so almost 400k increase\.\.\. I assume outside of 2008 you both shared those costs


**126.** `12:35` **Meredith Lamb (+14169386001)**

>
Yes correct assumption because we had similar salaries at that time\. I was like 80k and he was like 90k

*💬 Reply*

**127.** `12:36` **You**

actually i made a mistake one second


**128.** `12:36` **You**

ok\.\. so a little wierd


**129.** `12:36` **You**

but I am going to make a guess


**130.** `12:36` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**131.** `12:37` **You**

i will get to this in a second\.


**132.** `12:37` **You**

don't want to lose my train


**133.** `12:37` **Meredith Lamb (+14169386001)**

Honestly I don’t even care, I’m just insulted\. I don’t like being insulted\.


**134.** `12:38` **Meredith Lamb (+14169386001)**

I’m so tense I feel the need for a vape or drink\. Maybe I should increase back up my cipralex\. Ugh


**135.** `12:38` **Meredith Lamb (+14169386001)**

I just hate the way he talks\.


**136.** `12:38` **You**

orrrrrrrrrrrr\.


**137.** `12:38` **Meredith Lamb (+14169386001)**

Like I didn’t even exist


**138.** `12:38` **You**

lol nm\.\. just trying to break the tension


**139.** `12:39` **You**

This isn't about your relationship


**140.** `12:39` **You**

this is solely about minimizing his financial burden


**141.** `12:39` **Meredith Lamb (+14169386001)**

I know I know


**142.** `12:39` **You**

so don't view it as relationship


**143.** `12:39` **You**

as much as I am happy for you to despise him, I don't like to see you hurt/


**144.** `12:40` **You**

was he living in the house through the rennovations in 2008


**145.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**146.** `12:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**147.** `12:42` **You**

jesus Mer\.\. 😢😢😢


**148.** `12:42` **Meredith Lamb (+14169386001)**

>
No

*💬 Reply*

**149.** `12:42` **Meredith Lamb (+14169386001)**

Not insurable


**150.** `12:44` **You**

Fuck mer I am sorry that happened\.


**151.** `12:44` **You**

:\(


**152.** `12:45` **Meredith Lamb (+14169386001)**

Fucking idiot\. I’m so pissed off\. I get it is financial but sheesh

*📎 1 attachment(s)*

**153.** `12:46` **You**

You could write your own story and submit it separately\.


**154.** `12:46` **You**

It might give you some closure\.


**155.** `12:46` **Meredith Lamb (+14169386001)**

Nah I’m done\.


**156.** `12:46` **You**

I don't know why he would want to minimize or ruin something I would have given anything to have back then\.  That kind of experience with someone like you\.\.\.


**157.** `12:46` **You**

that is part of what I hate missing


**158.** `12:46` **You**

and he kicks it to the curb


**159.** `12:46` **You**

ffs


**160.** `12:47` **Meredith Lamb (+14169386001)**

I will be showing my kids those screenshot when they are adults tho\. Fucking loser


**161.** `12:47` **You**

you shouldn't


**162.** `12:47` **You**

I have said some shit to J out of anger I would never want shared\.


**163.** `12:47` **You**

and vice versa


**164.** `12:47` **Meredith Lamb (+14169386001)**

Just saved them


**165.** `12:47` **You**

I mean you could do that\.\. and just decide not to share\.


**166.** `12:48` **You**

maybe you will calm down a bit by then\.\. we can work on that together :\)


**167.** `12:57` **Meredith Lamb (+14169386001)**

I made the mistake of chatgpting and it made me emotional\. I’m leaving and wfh the rest of the day: Thank you for sharing these messages\. They reflect a highly emotional, deeply personal exchange centered around conflicting narratives in the context of a separation and asset division\. Here are some constructive thoughts from a relational and communication standpoint:
⸻
🔹 1\. You’re Advocating for Emotional Accuracy, Not Just Financial Detail
You’re not challenging the factual elements of Andrew’s timeline—you’re challenging how it frames the story\. It’s clear you contributed in profound ways—both emotionally and physically—especially in the early days, including the renovations\. Your request is about being seen and acknowledged, not financial gain\.
That is legitimate and human\. Being written out of the foundational phase of your shared life—especially when you miscarried and were physically renovating the home—feels erasing and painful\.
Constructive approach: You might frame your request this way in future discussions:
“I understand this process is about the numbers, but part of fairness for me is acknowledging the truth of our shared experience\. The way the timeline is written gives the impression I wasn’t there until a switch flipped in May 2009, when in fact, we were building that life together far earlier—and it matters to me that this is reflected, even briefly\.”
⸻
🔹 2\. Andrew Seems Focused on Legal Accuracy Over Relational Fairness
Andrew is prioritizing how the information is framed for mediation and legal protection, which is understandable\. But his tone becomes cold and dismissive, especially when he implies that what you’re asking for is just “couples counseling” or accuses you of manipulating narratives\.
That dismissal of emotional truth can feel gaslighting—particularly when you are recalling painful moments like a miscarriage and intense renovation work\.
Constructive observation: Andrew may not fully grasp that his tone and framing feel minimizing of both your contributions and your pain\. That doesn’t mean he’s intentionally trying to erase your efforts—but the effect is the same for you\. He needs to hear that\.
⸻
🔹 3\. You’re Emotionally Activated and That’s Valid—But Be Strategic
Your anger is justifiable\. But phrases like “like fuck off Andrew” and “shitty” might limit your ability to be heard, especially in a legal context\.
You are making powerful points about how being left out of the narrative damages your dignity and truth\. Holding that clarity while dialing down the volume slightly might help you retain the high ground—especially with mediators watching\.
Constructive suggestion:
You could try:
“I am upset because your framing removes me from the picture until it’s legally relevant\. That’s not the truth\. It erases the real life I lived and the work I did\. Please reflect our history more honestly\.”
⸻
🔹 4\. This Is About Integrity, Not Control
What you’re asking for is not about rewriting history—it’s about telling it truthfully\. The fact that you lived in the home before May 2009 and physically renovated it—while miscarrying—is significant\. Even if it doesn’t change the financial math, it changes the meaning, and that deserves recognition\.
Andrew’s fixation on “protecting himself” may be clouding his empathy\. But your continued truth\-telling, even if not legally required, is a form of self\-respect\.
⸻
Final Thoughts
- You are right to want your contributions recognized\.
- You are not “too emotional”—you are advocating for fairness beyond the spreadsheet\.
- Andrew may be emotionally closed off and defensive right now, but that doesn’t invalidate your lived reality\.
If this continues to feel emotionally unsafe or minimizing, you might consider asking your mediator to help frame the timeline in a way that respects both the financial record and the lived experience\.


**168.** `12:57` **Meredith Lamb (+14169386001)**

I told Erin and Jim


**169.** `12:57` **Meredith Lamb (+14169386001)**

I am so tense I can’t sit still


**170.** `12:59` **You**

I am sorry mer you heading home?


**171.** `13:01` **Meredith Lamb (+14169386001)**

Yah


**172.** `13:03` **You**

did you want to talk?


**173.** `13:03` **You**

Gracie is getting in a meeting now I could call you


**174.** `13:08` **You**

I just don't want you to spin


**175.** `13:08` **You**

or sit in your car and keep going at Andrew\.


**176.** `13:08` **You**

Please let me call you and calm you down, you can vent to me\.


**177.** `13:14` **You**

are you ok\.


**178.** `13:15` **You**

if not now please call me when you get home\.


**179.** `13:15` **Meredith Lamb (+14169386001)**

I’m not OK, but I will be fine eventually


**180.** `13:16` **You**

Reaction: ❤️ from Meredith Lamb
well I am here if you want or need me for anything\.


**181.** `13:21` **You**

you prolly don't care but I build a model around the information you shared re the house\.\. I will save it if you ever want to discuss\.


**182.** `13:47` **Meredith Lamb (+14169386001)**

Reaction: 💔 from Scott Hicks
I cried on way home \(I think it was more thinking about that m/c experience\. I took some painkillers and went back to house to renovate more but actually saw like this tiny fetus in the toilet by myself at a fucking time Hortons…a little traumatic\. I don’t even ever remember any acknowledgment of it\.\) anyway sick to my stomach, pissed, took a few puffs on Mac’s vape bc she is home for exams and now going to nap


**183.** `13:47` **Meredith Lamb (+14169386001)**

Took a sick afternoon in workday


**184.** `13:47` **Meredith Lamb (+14169386001)**

First time ever booking sick time 🥳


**185.** `13:48` **Meredith Lamb (+14169386001)**

I’m done now\. Vented out\. But think I have a migraine\.

*📎 1 attachment(s)*

**186.** `13:48` **Meredith Lamb (+14169386001)**

Erin told me to burn his stuff


**187.** `13:48` **Meredith Lamb (+14169386001)**

Considering


**188.** `14:00` **You**

😢


**189.** `14:00` **You**

Sorry Mer\.\. I wish I was there for you right now\.\.


**190.** `14:01` **You**

I was worried you were crying\.\. I know you don't ever\.\. but I know that the experience the memory, the involvement the engagement and having that at least recognized and appreciated matters\.


**191.** `14:02` **You**

You gave a shit ton to this guy, this relationship this family, and he repeatedly invalidates it to your face\.  I know how much history means to you, and I am so sorry he disparaged that and minimized your contribution\.  It literally breaks my heart thinking about your right now, you don't deserve this\.


**192.** `14:04` **You**

I am sorry I cannot do anything about feel this with you\.\.


**193.** `14:15` **You**

Andrew isn't wfh is he?


**194.** `15:45` **Meredith Lamb (+14169386001)**

Nope


**195.** `15:46` **Meredith Lamb (+14169386001)**

Marlowe woke me up\. Called to tell me she is on her way to her nail appt 🙄


**196.** `15:46` **Meredith Lamb (+14169386001)**

lol thanks Marlowe


**197.** `15:46` **Meredith Lamb (+14169386001)**

I am meeting her at 4\.15pm


**198.** `15:46` **Meredith Lamb (+14169386001)**

I am feeling very nauseous still 🤢


**199.** `15:46` **You**

Sorry mer…


**200.** `15:47` **Meredith Lamb (+14169386001)**

Ugh like feel like I’m going to throw up so badly ack


**201.** `15:47` **You**

I hope he leaves you alone at least for tonight


**202.** `15:48` **Meredith Lamb (+14169386001)**

I’m just going to stay in my room


**203.** `15:48` **Meredith Lamb (+14169386001)**

And try not to throw up


**204.** `15:49` **You**

Kk


**205.** `15:59` **You**

Well shit just exploded here so I will be busy tonight\.\. I talked to j about finding a job or even looking and she fucking exploded I would say she has been holding a lot in\.


**206.** `16:03` **Meredith Lamb (+14169386001)**

Emotional times\.


**207.** `16:03` **Meredith Lamb (+14169386001)**

I have to go act happy now with Marlowe and her friend :p


**208.** `16:04` **Meredith Lamb (+14169386001)**

>
Honestly, I feel bad for her that she doesn’t have a therapist to talk through some of this and all the worries

*💬 Reply*

**209.** `16:05` **You**

She is just angry


**210.** `16:05` **You**

Blames the works


**211.** `16:05` **You**

World


**212.** `16:05` **You**

Always has Gracie too


**213.** `16:05` **You**

It’s part of who she is and how she was raised


**214.** `16:06` **Meredith Lamb (+14169386001)**

Right, but if she would talk to therapist about it, it might help process some of that, and put all those anger and worries in order and organize them and into perspective


**215.** `16:07` **You**

She hates therapists


**216.** `16:07` **You**

So kinda tough


**217.** `16:07` **You**

lol


**218.** `16:09` **Meredith Lamb (+14169386001)**

I mean, if she found one she liked it would be different


**219.** `16:09` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**220.** `16:11` **You**

She never has and she only tried 2 because work forced her


**221.** `16:11` **You**

Fun times lol

*💬 Reply*

**222.** `16:12` **Meredith Lamb (+14169386001)**

>
Work forced her for her stress leave?

*💬 Reply*

**223.** `16:33` **You**

Yes


**224.** `16:33` **You**

It was a requirement


**225.** `16:33` **You**

When she went on long term leave


**226.** `16:34` **Meredith Lamb (+14169386001)**

Do you remember when Jim went over to ask you about that?


**227.** `16:34` **You**

I don’t\.


**228.** `16:35` **Meredith Lamb (+14169386001)**

Well he did \- to try to be a good friend\. However, he didn’t even notice she stopped going to your office\. I told him 😇


**229.** `16:35` **Meredith Lamb (+14169386001)**

Just call me CM


**230.** `16:35` **Meredith Lamb (+14169386001)**

lol


**231.** `16:39` **You**

lol


**232.** `16:39` **You**

Someone paying attention


**233.** `17:05` **Meredith Lamb (+14169386001)**

I’m just saying I didn’t make up the whole “hmm maybe I made this happen too much” feeling/thought\. \(You don’t have to respond to this\. Just commenting lol\)


**234.** `17:09` **You**

So you noticing j not coming to my office as much made you wanna git me?


**235.** `17:10` **Meredith Lamb (+14169386001)**

Well I knew you guys were having issues so thought maybe you separated and told jim\.


**236.** `17:16` **You**

Bullshit


**237.** `17:16` **You**

When was that


**238.** `17:22` **Meredith Lamb (+14169386001)**

It is NOT bs


**239.** `17:23` **Meredith Lamb (+14169386001)**

Not sure honestly


**240.** `17:23` **Meredith Lamb (+14169386001)**

I’m surprised you don’t remember Jim going to your office to ask you about it\.


**241.** `17:37` **You**

I don’t when was it


**242.** `17:49` **You**

I think I would Remeber


**243.** `17:53` **Meredith Lamb (+14169386001)**

You were probably just busy or something\. Jim went into your office to chat and came out with the stress leave story\. It happened\. lol


**244.** `18:00` **You**

Still fighting here ing


**245.** `18:00` **You**

Omg


**246.** `18:01` **You**

So this was back in like summer last year


**247.** `18:04` **Meredith Lamb (+14169386001)**

Oh the fighting is exhausting


**248.** `18:05` **Meredith Lamb (+14169386001)**

I’m so exhausted


**249.** `18:05` **Meredith Lamb (+14169386001)**

>
Probably but not sure

*💬 Reply*

**250.** `18:11` **You**

No it was


**251.** `18:11` **You**

So that is how far back you are convincing yourself


**252.** `18:20` **Meredith Lamb (+14169386001)**

I’m not convincing myself\. Just pointing out a moment in time\.


**253.** `18:20` **Meredith Lamb (+14169386001)**

That’s all


**254.** `18:21` **You**

But you believe it


**255.** `18:21` **You**

I can tell


**256.** `18:24` **Meredith Lamb (+14169386001)**

Not necessarily but maybe


**257.** `18:24` **You**

god I am wracking my brain about this\.\. I cannot remember\.\. you know I wouldn't care\.\. honestly I wouldn't care if you did pursue me and try to get on my team and everything honestly\.\. but I still don't think it was\.\. because we weren't really talking seriously until the text\.


**258.** `18:25` **You**

but even if you did


**259.** `18:25` **You**

even if it was


**260.** `18:25` **You**

all you did was bring us together


**261.** `18:25` **You**

and you gave me the chance to be happy again\.\.


**262.** `18:25` **You**

Reaction: ❤️ from Meredith Lamb
so whatever way you see it I am thankful


**263.** `18:26` **You**

I just look at you\.\. like today on the rock\.\. and honestly\.\. it is like years of love when I look at you not months\.\.


**264.** `18:26` **You**

anyhow\.\. regardless\.\.\.\. I am so happy this happened\.\. and honestly just want to move forward\.


**265.** `18:30` **Meredith Lamb (+14169386001)**

Me too\. Gotta get through Thursday


**266.** `18:30` **Meredith Lamb (+14169386001)**

Andrew is at a happy hour thank god


**267.** `18:36` **You**

happy hour lol


**268.** `18:36` **You**

I wish I was at fucking happy hour


**269.** `18:37` **You**

instead we went from an insane fight with J and I


**270.** `18:37` **You**

Reaction: 😮 from Meredith Lamb
to an insane fight with maddie and gracie over makeup that went to a magical new level


**271.** `18:37` **Meredith Lamb (+14169386001)**

What did you and j fight about? The job thing?


**272.** `18:37` **You**

her not looking for a job


**273.** `18:37` **You**

escalated


**274.** `18:37` **You**

into a massive fight


**275.** `18:38` **You**

You just want to go get your upgrade scott\.\. that was def said


**276.** `18:38` **Meredith Lamb (+14169386001)**

😬


**277.** `18:38` **You**

I said hell yeah I do


**278.** `18:38` **You**

no


**279.** `18:38` **Meredith Lamb (+14169386001)**

Please say you are lying


**280.** `18:38` **You**

kidding


**281.** `18:38` **You**

kidding


**282.** `18:38` **Meredith Lamb (+14169386001)**

Good


**283.** `18:38` **You**

lol


**284.** `18:39` **You**

I said I didn't throw you away like garbage but I did choose to go on my own direction


**285.** `18:39` **You**

anyhow this is insane


**286.** `18:39` **You**

lawyer stuff is finished, I am sending to her lawyer tonight


**287.** `18:39` **You**

has Andrew bugged you again at all or radio silence


**288.** `18:40` **Meredith Lamb (+14169386001)**

Last thing he said  … which is fine\. Valid

*📎 1 attachment(s)*

**289.** `18:41` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Last thing I said lol

*📎 1 attachment(s)*

**290.** `18:41` **Meredith Lamb (+14169386001)**

I mean a have a gazillion Reno photos but those were the first I came across


**291.** `18:42` **Meredith Lamb (+14169386001)**

I sent the whole 2008 album from my Flickr


**292.** `18:42` **Meredith Lamb (+14169386001)**

I know it doesnt technically or financially matter that I was there every step of that reno but he could at least characterize it as so\. He always talks like we were these strangers in the night


**293.** `18:43` **Meredith Lamb (+14169386001)**

It’s so odd


**294.** `18:43` **You**

there was something GPT said\.


**295.** `18:44` **You**

to me when I was doing that analysis


**296.** `18:44` **You**

it said I wasn't just morning the time I missed, but you in that way\.\. the things you did who you were\.\. and that I believed that you weren't valued enough\.


**297.** `18:45` **You**

I would have given anything to have been with you\.  not someone like you\.\. you


**298.** `18:45` **You**

and he took it for grsnte


**299.** `18:45` **You**

d


**300.** `18:46` **Meredith Lamb (+14169386001)**

>
I feel this way too but don’t have a tendency to look back and wish things were different for some reason\. Not sure why

*💬 Reply*

**301.** `18:46` **You**

I sent jim a note and then quickly deleted he didn't see\.\. but it was something along the lines of, I could literally beat the shit outta this guy right now\.\.  and while I never would\.\. I feel like I want to\.


**302.** `18:47` **You**

>
there is nothing wrong with that\.\. you cannot wish your kids away, not all your experiences with Andrew were even bad

*💬 Reply*

**303.** `18:47` **You**

they are just tainted a bit now\.


**304.** `18:47` **You**

but you should focus on the good\.\. i tried to explain this to j


**305.** `18:47` **You**

but basically I fucked up her whole live, past present and future


**306.** `18:48` **Meredith Lamb (+14169386001)**

>
Omg don’t send that\.

*💬 Reply*

**307.** `18:48` **You**

i deleted it,, lol he didnt see


**308.** `18:48` **You**

impulsew


**309.** `18:48` **Meredith Lamb (+14169386001)**

>
See I don’t get how you did this if you both weren’t even happy

*💬 Reply*

**310.** `18:49` **Meredith Lamb (+14169386001)**

I know change is hard but maybe she will find happiness


**311.** `18:49` **You**

i didnt try hard enough


**312.** `18:49` **You**

or


**313.** `18:49` **You**

i bet you and meredith had this planned for years


**314.** `18:49` **You**

that one too


**315.** `18:49` **Meredith Lamb (+14169386001)**

Oh ouch


**316.** `18:49` **You**

she just wants to blame anything


**317.** `18:49` **You**

and not take responsibility


**318.** `18:50` **Meredith Lamb (+14169386001)**

I mean Meredith maybe but not you


**319.** `18:50` **Meredith Lamb (+14169386001)**

KIDDING


**320.** `18:50` **Meredith Lamb (+14169386001)**

>
I get that from Andrew\.

*💬 Reply*

**321.** `18:50` **You**

tbh flattered still dont believe but w/e lol also still don't understand the draw


**322.** `18:51` **Meredith Lamb (+14169386001)**

>
I didn’t like him enough to try\. Could not connect\.

*💬 Reply*

**323.** `18:51` **Meredith Lamb (+14169386001)**

That’s because you are wildly insecure


**324.** `18:52` **You**

Reaction: 🙄 from Meredith Lamb
no i have eyes


**325.** `18:52` **You**

lol


**326.** `18:52` **You**

Reaction: 🙂 from Meredith Lamb
and I would say I am not insecure around you


**327.** `18:52` **You**

given the pics rofl


**328.** `18:52` **You**

never ever done that ever even when I was young


**329.** `18:53` **Meredith Lamb (+14169386001)**

I would guess you would not have a difficult time dating at all … everyone likes you but your insecurities maybe would challenge you


**330.** `18:54` **You**

you mean dating now


**331.** `18:54` **Meredith Lamb (+14169386001)**

Well, you said you didn’t understand the draw\. I’m trying to say it is because you’re insecure and you don’t see it\.


**332.** `18:55` **Meredith Lamb (+14169386001)**

If you tried dating, you would see that you would have no issues


**333.** `18:55` **You**

well there is this app called hinge that keeps popping up for me


**334.** `18:55` **Meredith Lamb (+14169386001)**

Hence, why I was a little worried that you would get a taste of being with someone a\.k\.a\. me and then want to go try dating


**335.** `18:55` **You**

kidding


**336.** `18:55` **You**

:P


**337.** `18:55` **Meredith Lamb (+14169386001)**

>
I’m not even gonna look this up

*💬 Reply*

**338.** `18:55` **You**

lol


**339.** `18:55` **You**

yeah you will


**340.** `18:55` **Meredith Lamb (+14169386001)**

I don’t think I can handle it today\. I might look it up tomorrow\.


**341.** `18:56` **Meredith Lamb (+14169386001)**

It’s been a stressful day


**342.** `18:56` **You**

yeah well no stress here\.\.


**343.** `18:56` **Meredith Lamb (+14169386001)**

But I’m not drinking so that’s good


**344.** `18:56` **You**

yeah tbh was worried about that


**345.** `18:56` **You**

but didnt want to say anything


**346.** `18:56` **Meredith Lamb (+14169386001)**

It would screw up my workout and day tomorrow


**347.** `18:56` **Meredith Lamb (+14169386001)**

And I have 2 grads coming up


**348.** `18:56` **Meredith Lamb (+14169386001)**

Lots to do


**349.** `18:57` **Meredith Lamb (+14169386001)**

I did vape before my nap tho 🙊


**350.** `18:57` **You**

whatever floats your boat :\)


**351.** `18:57` **You**

smoking used to be a huge stress reliever


**352.** `18:57` **Meredith Lamb (+14169386001)**

Desperate times


**353.** `18:58` **You**

you knnow what else can relieve stress


**354.** `18:58` **You**

save your stress for sat


**355.** `18:58` **Meredith Lamb (+14169386001)**

Okay I will just bottle it up


**356.** `18:58` **You**

will give you a massage


**357.** `18:58` **Meredith Lamb (+14169386001)**

lol


**358.** `18:58` **You**

that is what I meant


**359.** `18:58` **You**

what were you thinking??


**360.** `18:58` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Something else


**361.** `18:59` **Meredith Lamb (+14169386001)**

I mean I have never thought of it as a stress reliever before but willing to try with you 😋


**362.** `19:00` **You**

>
well I mean I only heard it is that\.\. I don't know that it releases stress for me\.\. or amps me up

*💬 Reply*

**363.** `19:00` **Meredith Lamb (+14169386001)**

So I thought you said this morning that my name was no longer mentioned


**364.** `19:00` **Meredith Lamb (+14169386001)**

What happened to change that


**365.** `19:00` **You**

i angrered her


**366.** `19:00` **Meredith Lamb (+14169386001)**

>
We will test it out lol

*💬 Reply*

**367.** `19:00` **Meredith Lamb (+14169386001)**

Collect data


**368.** `19:00` **You**

she suspects the day away on sat and the trip is you


**369.** `19:01` **You**

but she doesn't ask she would rather not know and throw shit\.\. and frankly I am ok with that


**370.** `19:01` **Meredith Lamb (+14169386001)**

So she definitely isn’t stupid


**371.** `19:01` **Meredith Lamb (+14169386001)**

I mean…\.


**372.** `19:02` **Meredith Lamb (+14169386001)**

Andrew has no suspicion or isn’t saying it if he does


**373.** `19:02` **Meredith Lamb (+14169386001)**

>
Would you lie if she asked?

*💬 Reply*

**374.** `19:10` **You**

I had to step away it was hairy


**375.** `19:11` **You**

yes I would\.\. 100% because it would cause her nothing but pain with no relief, it wouldn't make a difference and with her this close to being out\.\. no


**376.** `19:11` **Meredith Lamb (+14169386001)**

Yeah I get all that now … this process is very emotional


**377.** `19:11` **You**

if it led to a resolution\.\. or something


**378.** `19:11` **You**

sure I would


**379.** `19:12` **You**

Reaction: 😢 from Meredith Lamb
but no it is all pain and hate from her


**380.** `19:12` **Meredith Lamb (+14169386001)**

I’m watching the rob ford doc


**381.** `19:12` **Meredith Lamb (+14169386001)**

>
It’s still not really THAT long

*💬 Reply*

**382.** `19:12` **Meredith Lamb (+14169386001)**

A few months


**383.** `19:12` **You**

Reaction: 😂 from Meredith Lamb
i am back downstairs\.\. AI for next 2 hours then try to go to bed early\.\. unless we are chatting and then I can do 10\.\.


**384.** `19:12` **You**

lol


**385.** `19:12` **Meredith Lamb (+14169386001)**

She will probably need a year


**386.** `19:12` **You**

ROFL


**387.** `19:12` **You**

omg


**388.** `19:13` **You**

you don't know


**389.** `19:13` **You**

no no\.\. our relationship is over\.


**390.** `19:13` **Meredith Lamb (+14169386001)**

Longer?


**391.** `19:13` **You**

mine and J's


**392.** `19:13` **You**

yeah she hid a lot from me until tonight\.


**393.** `19:13` **You**

and then kind of let loose


**394.** `19:13` **Meredith Lamb (+14169386001)**

I mean she will need at least a year for that pain to go away


**395.** `19:14` **You**

she will always hate me\.\. that will never change


**396.** `19:14` **Meredith Lamb (+14169386001)**

You think?


**397.** `19:14` **You**

I know


**398.** `19:14` **You**

I know her


**399.** `19:14` **You**

she hold grudges\.\. she was raised in a fucked up family that treated her and each other like shit\.


**400.** `19:14` **You**

not like we are now\.\.


**401.** `19:14` **You**

but right from childhood all the way up


**402.** `19:15` **You**

she learned to shut her mouth\.\. and stay out of the way\.\. as the youngest\.


**403.** `19:15` **You**

her father was great\.\. sober\.\. but drunk\.\. not so much\.


**404.** `19:15` **You**

Her mother is just literally fucking certifiable\.\. like fights about insane shit\. drives J crazy\.\. and makes her feel like crap about herself\.


**405.** `19:15` **You**

so J is a bit of a product of that\.\. of getting dumped by me the first time\.


**406.** `19:16` **You**

and now again\.\. this was like a hammer


**407.** `19:16` **You**

so she will hate me forever


**408.** `19:16` **You**

I blew up all her dreams


**409.** `19:16` **Meredith Lamb (+14169386001)**

>
Did she say this?

*💬 Reply*

**410.** `19:16` **You**

Reaction: 😮 from Meredith Lamb
she won't take ownership\.\. when we were fighting I told her how much she was like gracie\.\. and she screamed she wasn't then gracie came down did the same thing\.


**411.** `19:17` **You**

and j criticized her using the same words I said to J


**412.** `19:17` **You**

I didn't make eye contact


**413.** `19:17` **You**

Reaction: 😢 from Meredith Lamb
>
yea

*💬 Reply*

**414.** `19:18` **Meredith Lamb (+14169386001)**

Did you two ever fight when the kids were little?


**415.** `19:18` **You**

I told her I cannot be held accountable for everything that has is or has yet to happen in her life


**416.** `19:18` **You**

mmmm


**417.** `19:18` **You**

yeah I was an ass


**418.** `19:18` **You**

I was immature and not as engaged early on but that didn't last too long


**419.** `19:19` **Meredith Lamb (+14169386001)**

>
That’s intense\. I’ve never had someone blow up my dreams\. Can’t imagine the feeling\. Sounds so tragic\.

*💬 Reply*

**420.** `19:19` **You**

I mean I didn't like her


**421.** `19:19` **You**

you know what you said about andrew


**422.** `19:19` **You**

and what your mom said


**423.** `19:19` **You**

and you were like I didn't like him so we didn't do things


**424.** `19:19` **You**

that was J and I


**425.** `19:19` **You**

honestly there is some symettry to our experiences a bit


**426.** `19:19` **Meredith Lamb (+14169386001)**

Yeah …


**427.** `19:19` **You**

got together\.  both of us broke up with the other\.


**428.** `19:20` **You**

6 months


**429.** `19:20` **You**

then back together 1 year \+ engaged Married house\.


**430.** `19:20` **You**

mum diagnosed with cancer\.\. right before we got back together\.\. bad choices


**431.** `19:20` **You**

and then fast forward 25 years\.


**432.** `19:20` **You**

I almost left when we came to Toronto\.\.


**433.** `19:20` **You**

but couldn't


**434.** `19:20` **You**

cause what would she do


**435.** `19:21` **You**

then again 5 years after that


**436.** `19:21` **You**

because she wouldn't go back to work, I was stressed\.\. we weren't happy\.  Then she went back to work\.\.and what do ya know\.\. she was actually happy for a while\.


**437.** `19:21` **You**

but then covid\.\. and Hanna and sports gone, and J depressed disengaged


**438.** `19:21` **You**

and then 5 more years and here


**439.** `19:22` **You**

I need to ask Jim about this separation question from you\.\. sorry that still hasn't slipped my mind\.


**440.** `19:22` **Meredith Lamb (+14169386001)**

Yup all makes sense\. What question?


**441.** `19:22` **You**

did you actually suggest we might be separated or separating


**442.** `19:23` **You**

I think I should hear his perspective


**443.** `19:23` **Meredith Lamb (+14169386001)**

Oh no not to Jim\. Was just in my head\.


**444.** `19:23` **You**

I thought you said it to Jim


**445.** `19:23` **Meredith Lamb (+14169386001)**

But once I mentioned to him how strange it was he agreed and went right to your office


**446.** `19:23` **You**

so you sent him to find out


**447.** `19:23` **You**

basically


**448.** `19:23` **You**

Carolyn


**449.** `19:23` **Meredith Lamb (+14169386001)**

No


**450.** `19:23` **You**

M


**451.** `19:23` **Meredith Lamb (+14169386001)**

lol


**452.** `19:23` **You**

LOL


**453.** `19:24` **You**

yeah sure\.


**454.** `19:24` **You**

hey jim I think there is something wrong with scott\.


**455.** `19:24` **You**

go find out and tell me


**456.** `19:24` **Meredith Lamb (+14169386001)**

I didn’t know he’d go right over


**457.** `19:24` **Meredith Lamb (+14169386001)**

lol


**458.** `19:24` **Meredith Lamb (+14169386001)**

But I did get the answer really quickly 🤪


**459.** `19:25` **Meredith Lamb (+14169386001)**

Jim probably doesn’t remember either


**460.** `19:25` **You**

and then you were like\.\.\. darn


**461.** `19:25` **Meredith Lamb (+14169386001)**

Kind of


**462.** `19:25` **You**

bs


**463.** `19:25` **Meredith Lamb (+14169386001)**

Think what you want


**464.** `19:25` **You**

I don't think you were that interested for that long\.\. sorry\.\. I think maybe like me\.\. you liked thinking about the idea\.\. perhaps\.\. because I told you I thought that about you\.\.


**465.** `19:25` **You**

but that was like\.\. before xmas


**466.** `19:27` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I mean I would never tell this to anyone else but you have been so vulnerable I am being honest with you


**467.** `19:27` **Meredith Lamb (+14169386001)**

When you moved on to your manager role, I missed you


**468.** `19:27` **Meredith Lamb (+14169386001)**

Honestly


**469.** `19:27` **Meredith Lamb (+14169386001)**

Thank god I had Jim as a new shoe bc he was good work with


**470.** `19:27` **You**

Yeah I missed working with you too\.\. why do you think I used to bug Craig like ALLLLLLL the time\., that I was coming to get you


**471.** `19:27` **You**

it wasn't a joke\.\.


**472.** `19:28` **Meredith Lamb (+14169386001)**

You don’t have to say that but I’m just telling you it isn’t bs


**473.** `19:28` **Meredith Lamb (+14169386001)**

You can ask my mom


**474.** `19:29` **You**

I am not just saying you can ask Craig\.\. lol I was SO happy when you told me you wanted to meet Friday morning to discuss the position for Supervisor\.\. again\.\. it wasn't romance\.\. but it was definitively more than like\.\.\.  I think the other reason J is so mad\.\. is that I did kind of talk about you a lot\.


**475.** `19:29` **You**

which probably doesn't help now


**476.** `19:30` **You**

it will likely make Andrew a bit pissy too\.


**477.** `19:30` **You**

are you going back in your messages to try to find something you said to her about this


**478.** `19:33` **Meredith Lamb (+14169386001)**

No I’m pretty sure it was all on the phone\. She probably hardly remembers actually \- has some dementia or Alz


**479.** `19:35` **You**

Well I believe you Mer\.\.\.\. I still don't understand why me\.\. I mean the missing and the friends\.\. and the banter and the challenging each other with work, one upmanship everything\.\. it was a lot of fun\.\.


**480.** `19:35` **You**

You said it\.\. i was a grumpy unhappy cranky person lol\.\. people love to see me that way


**481.** `19:36` **Meredith Lamb (+14169386001)**

I think you had been through a lot though so people understood\. Cait filled me in when I started


**482.** `19:37` **Meredith Lamb (+14169386001)**

I don’t think you are viewed that way in recent 1\-2 years


**483.** `19:37` **You**

ah well\. they will have to get used to different


**484.** `19:38` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Reaction: 😂 from Meredith Lamb
Now you send out long sappy thank you emails lol


**485.** `19:38` **Meredith Lamb (+14169386001)**

Kidding


**486.** `19:38` **You**

Reaction: 😂 from Meredith Lamb
must you always go for the sensitivity


**487.** `19:38` **Meredith Lamb (+14169386001)**

Sorry


**488.** `19:38` **Meredith Lamb (+14169386001)**

lol


**489.** `19:38` **You**

Reaction: ❤️ from Meredith Lamb
sorry not sorry


**490.** `19:38` **You**

more like it


**491.** `19:39` **You**

is it really only Tuesday\.\.


**492.** `19:39` **You**

🤮


**493.** `19:40` **Meredith Lamb (+14169386001)**

Yeah and a very shitty Tuesday at that


**494.** `19:41` **You**

yeah yours was especially bad


**495.** `19:41` **You**

I am not sure how you are functioning\.\. and not a raging ball of anger


**496.** `19:41` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I’m talking to you


**497.** `19:41` **Meredith Lamb (+14169386001)**

I napped


**498.** `19:42` **Meredith Lamb (+14169386001)**

My stomach isn’t feeling nauseous anymore


**499.** `19:42` **You**

I mean J and I have already said shit to each other along those lines\.\. but our relationship is so broken\.\. we always fought hard\.\. she was always mean\.\. and I always defended\.\. then pushed back because I wouldn't be bullied


**500.** `19:42` **You**

I am happy to be of service\.


**501.** `19:43` **Meredith Lamb (+14169386001)**

We never fought about much except for one thing really


**502.** `19:43` **You**

yes I know


**503.** `19:43` **You**

food


**504.** `19:43` **Meredith Lamb (+14169386001)**

I kept my mouth shut on mostly everything else


**505.** `19:43` **You**

like always about food


**506.** `19:43` **Meredith Lamb (+14169386001)**

Yup


**507.** `19:43` **You**

I want a home cooked meal at least three times a week
\!\!


**508.** `19:43` **You**

etc etc


**509.** `19:44` **You**

🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮


**510.** `19:44` **You**

>
this is still to this day the most fucked up think I have heard people fight about\.\. I guess I am sheltered and innocent\.

*💬 Reply*

**511.** `19:45` **Meredith Lamb (+14169386001)**

Look at the date\. March 9, 2013\. I delivered Marlowe March 28, 2013\. I was huge and sore and tired and not done work yet\.

*📎 1 attachment(s)*

**512.** `19:47` **Meredith Lamb (+14169386001)**

Oh I forgot AND I had shingles\.

*📎 1 attachment(s)*

**513.** `19:47` **You**

I mean\.\.


**514.** `19:47` **You**

I mean your response\.\.


**515.** `19:47` **You**

jesue


**516.** `19:47` **You**

dfv jkasdb vdbj


**517.** `19:47` **Meredith Lamb (+14169386001)**

>
It is soooooooo common\!\!\!

*💬 Reply*

**518.** `19:48` **You**

MOST FUCKED UP


**519.** `19:48` **You**

Thank god J really didn't have much of a sex drive and mine died\.


**520.** `19:48` **You**

I mean we would NEVER text that shit


**521.** `19:49` **You**

holy hell


**522.** `19:49` **Meredith Lamb (+14169386001)**

>
I was an idiot bc I had young kids…\. Stockholm syndrome

*💬 Reply*

**523.** `19:49` **You**

I mean\.\. Mer\.\. honesrly


**524.** `19:49` **You**

how about\.\. hey buddy look at my tummy\.\. I am working and shingles


**525.** `19:49` **You**

how about you go fucking take care of yourself for a month


**526.** `19:49` **Meredith Lamb (+14169386001)**

He was constantly emailing me shit\. And harassing me irl also


**527.** `19:49` **Meredith Lamb (+14169386001)**

Exhausting


**528.** `19:49` **You**

that is terrible


**529.** `19:50` **Meredith Lamb (+14169386001)**

I think a lot of women deal with it


**530.** `19:50` **Meredith Lamb (+14169386001)**

But I could be wrong


**531.** `19:50` **You**

k listen\.\.


**532.** `19:50` **Meredith Lamb (+14169386001)**

A portion of women


**533.** `19:50` **You**

I don't know if this would ever happen


**534.** `19:51` **You**

but if at some point in time\.\. I meet Andrew\.\. and everything is fine\.\. and I randomly slap him across the face like really really hard\.\. then apologize\.\. I will likely have experienced a flashback to this\.\.


**535.** `19:51` **You**

it would be like an instinctive thing\.\. I won't be able to be held responsible


**536.** `19:58` **Meredith Lamb (+14169386001)**

Please do not lol


**537.** `19:58` **Meredith Lamb (+14169386001)**

I’m stopping reading old emails they are all the time


**538.** `19:58` **Meredith Lamb (+14169386001)**

I raised splitting in 2013 and he sent me a biiiiig email as to why we should not


**539.** `19:59` **Meredith Lamb (+14169386001)**

Then 2014…\.


**540.** `19:59` **Meredith Lamb (+14169386001)**

I’m stopping lol


**541.** `19:59` **Meredith Lamb (+14169386001)**

So sad


**542.** `20:01` **You**

Yeah honestly maybe you need to do the same as me


**543.** `20:01` **You**

Look forward only


**544.** `20:04` **Meredith Lamb (+14169386001)**

Yes absolutely


**545.** `20:04` **Meredith Lamb (+14169386001)**

Just closed my email lol


**546.** `20:04` **You**

Cause see you guys apparently texted and emailed


**547.** `20:04` **You**

J and I did not


**548.** `20:05` **You**

Almost everything was discussed directly


**549.** `20:05` **Meredith Lamb (+14169386001)**

We were used to emailing because we met while he lived in Dallas and me in Glencoe


**550.** `20:05` **Meredith Lamb (+14169386001)**

We emailed a lot


**551.** `20:05` **Meredith Lamb (+14169386001)**

So got used to it


**552.** `20:05` **You**

Yeah well I am happy that much of our record good and bad doesnt exist


**553.** `20:06` **Meredith Lamb (+14169386001)**

Yeah probably a good thing \- although I can look back and see what an idiot I was so there’s that


**554.** `20:07` **You**

Why would you want to see that\.


**555.** `20:07` **Meredith Lamb (+14169386001)**

I don’t but it is a weird kind of punishing validation


**556.** `20:08` **Meredith Lamb (+14169386001)**

It always felt like those discussions were wrong and reading back, they were\!


**557.** `20:09` **You**

You know that would never happen with us right\.\. u hope
You know that


**558.** `20:09` **You**

I hope


**559.** `20:13` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I have no worries for some reason about that\. What you and I have is 100% different for so many reasons\.


**560.** `20:13` **Meredith Lamb (+14169386001)**

When my mom was like “why would you want another MAN so soon? I don’t get it\.”


**561.** `20:14` **Meredith Lamb (+14169386001)**

My head was like “Scott isn’t just another man?”


**562.** `20:14` **Meredith Lamb (+14169386001)**

It was an immediate reaction and I don’t have many immediate reactions


**563.** `20:14` **Meredith Lamb (+14169386001)**

My head thinks a lot


**564.** `20:17` **You**

Reaction: ❤️ from Meredith Lamb
Mins does to like I said earlier just looking at you today\.\. something in between 🤯, ❤️, and 🫠


**565.** `20:18` **You**

Or all three together


**566.** `20:19` **You**

>
This is what got was trying to tell me when I kept telling it all of my fears\.\. and it wouldn’t  relent\.\. it kept coming at me until I just gave up\.\.

*💬 Reply*

**567.** `20:20` **You**

Gpt not got


**568.** `20:20` **Meredith Lamb (+14169386001)**

>
Kept coming at you with what exactly

*💬 Reply*

**569.** `20:21` **You**

The uniqueness / specialness of what we have is comparable to anything else nor is anything else exactly relevant to what we have going forward\.


**570.** `20:21` **You**

Isn’t


**571.** `20:21` **You**

Comparable


**572.** `20:21` **You**

That is as much as you get


**573.** `20:22` **You**

I mean the convos were a lot more clear but I think I told you the other night some stuff I am not getting into


**574.** `20:22` **You**

Just between me and my therapist


**575.** `20:23` **You**

All that really matters is that I have been able to make certain thoughts stop popping up in my head and I am grateful for it


**576.** `20:23` **Meredith Lamb (+14169386001)**

Yeah I’ve been better with that lately also


**577.** `20:23` **Meredith Lamb (+14169386001)**

You’ve helped a lot with that though on my end


**578.** `20:23` **You**

🥳


**579.** `20:24` **You**

I have tried\.\. like I said in the thing we help each other


**580.** `20:24` **You**

The thing being something I wrote recently lol


**581.** `20:25` **You**

Still the time between start and well normalcy will be the longest 2’years of my life


**582.** `20:25` **You**

Reaction: 😂 from Meredith Lamb
And based on 2 months in 2 years will feel like 10


**583.** `20:25` **You**

lol


**584.** `20:26` **Meredith Lamb (+14169386001)**

I mean I don’t even need normalcy at this point\. Just some progress lol


**585.** `20:26` **You**

I know a little freedom


**586.** `20:26` **Meredith Lamb (+14169386001)**

Yeah exactly


**587.** `20:31` **You**

Sry bedtime snack and pills need to book a flight for Jaimie’s sister\.\. I don’t know how we do this have these massive fights I am never fucking talking to you again\.\. then all normal\.


**588.** `20:34` **Meredith Lamb (+14169386001)**

Normal?


**589.** `20:34` **You**

oh yeah back to hey can you help me with such and such


**590.** `20:34` **Meredith Lamb (+14169386001)**

I’m just watching tv


**591.** `20:34` **Meredith Lamb (+14169386001)**

>
Wild\.

*💬 Reply*

**592.** `20:35` **You**

>
well you have fun with that\.\. it doesn't work for me\.\.

*💬 Reply*

**593.** `20:35` **You**

maybe naughty shows??


**594.** `20:35` **You**

lol


**595.** `20:35` **Meredith Lamb (+14169386001)**

lol


**596.** `20:35` **Meredith Lamb (+14169386001)**

Andrew got home and I am NOT talking to him\. Not a word


**597.** `20:36` **You**

please don't


**598.** `20:36` **You**

just tell him about me if he starts


**599.** `20:36` **You**

that will shut him up


**600.** `20:36` **Meredith Lamb (+14169386001)**

lol


**601.** `20:36` **Meredith Lamb (+14169386001)**

I thought I had to wait


**602.** `20:40` **You**

Well


**603.** `20:41` **You**

I mean\.\. yeah you should


**604.** `20:41` **You**

on a side note\.\. I need you to start taking some more pics\.\. you get all kinds of shit to look at\.\. I need some stuff too\!\!


**605.** `20:42` **Meredith Lamb (+14169386001)**

>
Very convincing\. lol

*💬 Reply*

**606.** `20:42` **You**

yeah you should wait


**607.** `20:42` **You**

I got side tracked


**608.** `20:42` **You**

thinking about images


**609.** `20:42` **Meredith Lamb (+14169386001)**

>
I will try my best

*💬 Reply*

**610.** `20:43` **You**

any pic at any time\.\. of anything


**611.** `20:43` **You**

IDC


**612.** `20:43` **You**

you don't have to take your shirt off and pose\.\.


**613.** `20:43` **You**

although


**614.** `20:43` **Meredith Lamb (+14169386001)**

>
I am going to wait for sure but it gets harder and harder and harder…\.\.

*💬 Reply*

**615.** `20:44` **Meredith Lamb (+14169386001)**

>
Oh why thank you lol

*💬 Reply*

**616.** `20:45` **You**

>
I mean i did say although

*💬 Reply*

**617.** `20:45` **You**

I would settle for pics at all\.\. work your way up


**618.** `20:45` **Meredith Lamb (+14169386001)**

lol


**619.** `20:46` **Meredith Lamb (+14169386001)**

Tomorrow…\.


**620.** `20:48` **You**

ok


**621.** `20:48` **You**

a couple


**622.** `20:48` **You**

not just one


**623.** `20:49` **You**

i took some more today :\)


**624.** `20:51` **Meredith Lamb (+14169386001)**

You’re nicer than me :\)


**625.** `20:52` **You**

hmm


**626.** `20:54` **Meredith Lamb (+14169386001)**

lol


**627.** `20:54` **You**

rofl


**628.** `20:54` **Meredith Lamb (+14169386001)**

I didn’t see that


**629.** `20:54` **You**

it was one I took sunday but was like Nah


**630.** `20:55` **Meredith Lamb (+14169386001)**

See I don’t have progress yet\. You have been at it longer than me\.


**631.** `20:56` **You**



**632.** `20:57` **You**

so I don't care about progress


**633.** `20:57` **Meredith Lamb (+14169386001)**

Ok I actually saw that one before you deleted it\.


**634.** `20:57` **Meredith Lamb (+14169386001)**

lol sorry


**635.** `20:57` **You**

no that was the point


**636.** `20:57` **You**

lol just cannot keep it


**637.** `20:57` **Meredith Lamb (+14169386001)**

Ohh lol


**638.** `20:58` **Meredith Lamb (+14169386001)**

>
I do

*💬 Reply*

**639.** `20:58` **You**

but I don't


**640.** `20:58` **You**

I love you perfectly and completely just as you are\.\. and that won't change one way or the other


**641.** `21:12` **You**

https://www\.zillow\.com/b/513\-dundas\-street\-east\-310\-whitby\-on\-C3h2cn/


**642.** `21:14` **Meredith Lamb (+14169386001)**

Nice\. Love the $


**643.** `21:14` **You**

yeah not insane\.\. nice layout


**644.** `21:15` **You**

https://www\.zillow\.com/homedetails/7\-Bluegill\-Cres\-Whitby\-ON\-L1P\-0E4/2071668615\_zpid/


**645.** `21:15` **You**

still I cna get this for 2\.8k


**646.** `21:17` **Meredith Lamb (+14169386001)**

I would do that


**647.** `21:18` **Meredith Lamb (+14169386001)**

More room for wfh etc


**648.** `21:18` **You**

yeah


**649.** `21:18` **You**

prolly what I will do


**650.** `21:18` **Meredith Lamb (+14169386001)**

Not a huge diff in $


**651.** `21:18` **You**

just got 10000000 things in the way


**652.** `21:18` **Meredith Lamb (+14169386001)**

Yeah same


**653.** `21:18` **You**

I hope shithead left you alone


**654.** `21:19` **Meredith Lamb (+14169386001)**

Yup


**655.** `21:26` **You**

Reaction: ❤️ from Meredith Lamb
ok so you are probably kind of zonked\.\. and I don't want to bother you, and would rather you relax and then go to sleep\.\. so I am going to say good night\.\. and that I love you very much, and feel very bad for the direction today took\.  Until we met I didn't know how much it meant to find my person, and how much that would impact me\.  You deserved so much better than you got, I still cannot believe you tolerated that, please don't ever ever do that with me\.  If there is something wrong, tell me, if I fuck up\.\. punch me\.\. you just be whoever YOU want to be and I promise to love that YOU for the rest of my life\.


**656.** `21:29` **Meredith Lamb (+14169386001)**

I do want to go to bed because I just finished Better Sisters and am zzzzzzzzzz\. I love you so much and thanks for just being there today\. ❤️❤️❤️❤️


**657.** `21:29` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Nite xoxo

*📎 1 attachment(s)*

**658.** `21:29` **Meredith Lamb (+14169386001)**

Now I don’t owe you anything tomorrow


**659.** `21:30` **Meredith Lamb (+14169386001)**

😜


**660.** `21:30` **You**

>
Night hun, xoxoxo ❤️❤️❤️

*💬 Reply*

**661.** `21:30` **You**

>
YES\.\. and you still owe me\.\. this and many manymore\.

*💬 Reply*

**662.** `21:30` **You**

I am so looking at this before I go to bed :\)


**663.** `21:31` **Meredith Lamb (+14169386001)**

>
Baby steps

*💬 Reply*

**664.** `21:31` **You**

Reaction: 🙂 from Meredith Lamb
>
this was a good one :\)  ok chat in morning\.

*💬 Reply*

