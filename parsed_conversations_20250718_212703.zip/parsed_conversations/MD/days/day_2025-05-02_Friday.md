# Daily Conversation: 2025-05-02 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-02 |
| **Day** | Friday |
| **Week** | 3 |
| **Messages** | 813 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-02T00:14 - 2025-05-02T23:59 |

## 📝 Daily Summary

This day contains **813 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:14` **You**

Check out this listing
https://realtor\.ca/real\-estate/28055316/18\-annable\-lane\-ajax\-south\-east\-south\-east?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**002.** `00:18` **You**

Alright honey hoping you are in a good sleep\.\. I had a fantastic workout and I am wiped and I will be going to bed dreaming of you\.  Love you, chat in morning\.  ❤️❤️❤️❤️


**003.** `06:46` **You**

Reaction: ❤️ from Meredith Lamb
It worked 🥰


**004.** `07:07` **Meredith Lamb (+14169386001)**

>
Nice place\. $$

*💬 Reply*

**005.** `07:09` **Meredith Lamb (+14169386001)**

Not a fan of waking up to this reality\. \(In all aspects\.\) 😵‍💫 But being patient\.


**006.** `08:11` **You**

I’m sry I would give anything to wake up role over and see you\.


**007.** `08:12` **You**

And I am really trying on my side maybe I skip gym for a few days and do worry around here won’t get done otherwise


**008.** `08:12` **You**

But the gym right now is my escape


**009.** `08:12` **You**

Still just want to be with you


**010.** `08:13` **You**

>
Did you have a bad sleep or did he bug you again?

*💬 Reply*

**011.** `08:16` **Meredith Lamb (+14169386001)**

No more bugging\. He had work to do for a meeting today thank god\. Sleep was meh\. This place just feels really heavy\.  I just don’t fit here anymore which makes it heavier\. Then having to stay fully normal or composed for my kids is just draining\. It is all draining and heavy\. Nothing like last weekend…\.\.


**012.** `08:18` **You**

Yeah i know this does suck but i promise those weekends will become nights and days eventually


**013.** `08:21` **Meredith Lamb (+14169386001)**

Holding you to that\.


**014.** `08:22` **You**

Same mer\. Same\.


**015.** `08:29` **You**

Did you guys resolve anything last night after your final chat I know you went to bed shortly thereafter


**016.** `08:29` **You**

>
It’s a good price for what you get and I will be able
To afford it

*💬 Reply*

**017.** `08:38` **Meredith Lamb (+14169386001)**

So I think we resolved a spreadsheet to take to a lawyer\. Just picked one now


**018.** `08:38` **Meredith Lamb (+14169386001)**

He can’t do a $300k up front lump sum without selling


**019.** `08:39` **You**

All you do is simply determine the value of what he owes the net present value of the owe subtract
The lump sum and then stretch the balance back out over
The term


**020.** `08:39` **You**

Hopefully he can do that without losing 100k along the way


**021.** `08:39` **Meredith Lamb (+14169386001)**

So I can get $150k up front and the rest monthly over 8 hrs


**022.** `08:40` **Meredith Lamb (+14169386001)**

8 yrs


**023.** `08:40` **You**

Again just determines what value the rest equals to determine if it is fair


**024.** `08:40` **You**

And it matters how he split the assets


**025.** `08:40` **Meredith Lamb (+14169386001)**

BUT he wants to put a clause in that if I marry or cohabitate, that changes


**026.** `08:40` **You**

Refuse it


**027.** `08:40` **You**

I am refusing too


**028.** `08:41` **You**

He will relent on that he has no standing


**029.** `08:41` **Meredith Lamb (+14169386001)**

Asset split was equalized


**030.** `08:41` **Meredith Lamb (+14169386001)**

Except for his $200k


**031.** `08:41` **Meredith Lamb (+14169386001)**

So I got most of our savings to equalize it


**032.** `08:41` **You**

So then he is not using any assets to offset the lump sum


**033.** `08:41` **Meredith Lamb (+14169386001)**

Right


**034.** `08:41` **You**

Not like I am doing


**035.** `08:42` **Meredith Lamb (+14169386001)**

He was before last night


**036.** `08:42` **You**

Yeah so then the calc really matters to
You


**037.** `08:42` **You**

Btw you do hold
All
The power
Here he would never ever want to go to court


**038.** `08:42` **Meredith Lamb (+14169386001)**

Our assets are almost equal before equalization


**039.** `08:42` **You**

They would deal with you being home and your education in a harsh way


**040.** `08:42` **Meredith Lamb (+14169386001)**

We just have this $100k sitting in cash


**041.** `08:42` **You**

And then add the text and he would be decimated


**042.** `08:42` **You**

Anyhow


**043.** `08:42` **You**

I am mean like that


**044.** `08:43` **Meredith Lamb (+14169386001)**

He split the $100 50/50


**045.** `08:43` **Meredith Lamb (+14169386001)**

Now I have $93 of it in the actual proper equalization


**046.** `08:43` **You**

But he stands to inherit a fair amount too I bet\.


**047.** `08:45` **Meredith Lamb (+14169386001)**

Doubt it


**048.** `08:45` **Meredith Lamb (+14169386001)**

His step dad is insane


**049.** `08:45` **Meredith Lamb (+14169386001)**

His step dad will take everything


**050.** `08:45` **You**

Eesh


**051.** `08:45` **Meredith Lamb (+14169386001)**

His mom will let him


**052.** `08:45` **Meredith Lamb (+14169386001)**

She has already said everything goes to Jeff


**053.** `08:45` **Meredith Lamb (+14169386001)**

His mom is weird


**054.** `08:45` **Meredith Lamb (+14169386001)**

Step dad hates Andrew


**055.** `08:45` **You**

Well yeah that sounds off… still
I feel like you hold more cards here mer


**056.** `08:45` **Meredith Lamb (+14169386001)**

I bet Andrew gets nothing


**057.** `08:46` **Meredith Lamb (+14169386001)**

His brother is Jeff’s son


**058.** `08:46` **Meredith Lamb (+14169386001)**

His bro will get everything


**059.** `08:46` **You**

Hmm well that is a bit twisted


**060.** `08:46` **You**

I have seen it in my fam too though


**061.** `08:46` **Meredith Lamb (+14169386001)**

Yeah it is pretty common


**062.** `08:46` **You**

Just not with me or Katie cousins etc


**063.** `08:47` **Meredith Lamb (+14169386001)**

But will happen to Andrew and his sister for sure


**064.** `08:47` **Meredith Lamb (+14169386001)**

His mom has basically told him


**065.** `08:47` **Meredith Lamb (+14169386001)**

Just weird


**066.** `08:47` **Meredith Lamb (+14169386001)**

It is the reason why the cottage is so important to Andrew


**067.** `08:47` **Meredith Lamb (+14169386001)**

He doesn’t depend on his mom and Jeff and their cottage


**068.** `08:48` **Meredith Lamb (+14169386001)**

We bought the cottage after they last minute cancelled one of our cottage trips and didn’t let us go


**069.** `08:48` **Meredith Lamb (+14169386001)**

Andrew had a temper tantrum and was like “fine I will buy my own”


**070.** `08:48` **You**

Man


**071.** `08:48` **You**

We are very different people


**072.** `08:49` **Meredith Lamb (+14169386001)**

lol


**073.** `08:49` **You**

I mean only you could truly know that


**074.** `08:49` **You**

But seems like to me


**075.** `08:49` **Meredith Lamb (+14169386001)**

So I’m trying to respect some of the insaneness in his family


**076.** `08:50` **Meredith Lamb (+14169386001)**

>
I mean we haven’t lived together :\)

*💬 Reply*

**077.** `08:50` **You**

Well I guess from what you do know or are aware of then lol


**078.** `08:50` **Meredith Lamb (+14169386001)**

If j marries or cohabitates do you stop paying or are you doing all lump sum?


**079.** `08:51` **You**

I am going to all lump sum if I can and I won’t change anything on marriage or cohabitation


**080.** `08:51` **You**

It will be much much harder
For me


**081.** `08:51` **You**

But it
Is safer for her and the kids still we will have a lawyer
Look and make a recommendation


**082.** `08:52` **Meredith Lamb (+14169386001)**

And you had no more flip flopping last night or this morning


**083.** `08:53` **Meredith Lamb (+14169386001)**

Last night we ALMOST got into a conversation about how I contributed nothing to his courses and actually made his life harder


**084.** `08:53` **Meredith Lamb (+14169386001)**

I was honestly speachless


**085.** `08:53` **Meredith Lamb (+14169386001)**

Then I was just like “I don’t think we should talk about this”


**086.** `08:54` **Meredith Lamb (+14169386001)**

I literally did everything for years


**087.** `08:54` **Meredith Lamb (+14169386001)**

Everything


**088.** `08:54` **Meredith Lamb (+14169386001)**

I couldn’t even respond


**089.** `08:54` **You**

I had no more let’s try again for days now


**090.** `08:54` **You**

I solution on housing


**091.** `08:55` **You**

>
Like where is he coming from… I think he will attack anything for the sake of it

*💬 Reply*

**092.** `08:55` **You**

No solution sorry in housing


**093.** `08:55` **Meredith Lamb (+14169386001)**

Yeah he also remakes the past


**094.** `08:55` **You**

She is just miserable


**095.** `08:55` **You**

She yelled at me when I got home


**096.** `08:55` **You**

And tried to show her the listing


**097.** `08:55` **Meredith Lamb (+14169386001)**

Do they want to stay in house and you just have an apt in basement? Lol


**098.** `08:55` **You**

Originally it was for her


**099.** `08:55` **You**

They would yea


**100.** `08:55` **You**

Def


**101.** `08:56` **You**

Cause then they could keep the house


**102.** `08:56` **You**

And who cares about me because I caused this


**103.** `08:56` **You**

Essentially


**104.** `08:56` **Meredith Lamb (+14169386001)**

I mean could you make a basement apt for the short term or is that ridiculous


**105.** `08:56` **You**

She is trapped because I wouldn’t go back to Moncton with no job or prospects on a whim


**106.** `08:56` **You**

It is a ridiculous investment


**107.** `08:57` **Meredith Lamb (+14169386001)**

Yeah likely


**108.** `08:57` **You**

And would be impossible regardless maddie wants out as welll


**109.** `08:57` **Meredith Lamb (+14169386001)**

She right


**110.** `08:57` **Meredith Lamb (+14169386001)**

\*ah right


**111.** `08:57` **You**

But Gracie still won’t go to Moncton which is the lynch pin


**112.** `08:58` **You**

So 133/83 this morning and I am
Down 19\.5 lbs


**113.** `08:58` **You**

Did a 30 min interval training on the treadmill last night


**114.** `08:58` **Meredith Lamb (+14169386001)**

Holy crap


**115.** `08:58` **You**

Eesh


**116.** `08:58` **You**

Hard


**117.** `08:58` **You**

After the 1 hr on back


**118.** `08:58` **You**

Fun\!\!


**119.** `08:59` **You**

Honestly you are
Great
Motivation


**120.** `09:00` **Meredith Lamb (+14169386001)**

lol


**121.** `09:01` **You**

Reaction: 😂 from Meredith Lamb
Seriously not joking thought about stopping in treadmill like 3/4 through\.


**122.** `09:01` **Meredith Lamb (+14169386001)**

So musarrat starts on Monday and I’m having a team meeting and lunch and didn’t invite you bc I don’t want to be distracted


**123.** `09:01` **You**

But I have trained before I know how to focus on a mental image


**124.** `09:01` **Meredith Lamb (+14169386001)**

I will intro her to you separately


**125.** `09:01` **Meredith Lamb (+14169386001)**

LOL


**126.** `09:01` **You**

No worries


**127.** `09:01` **You**

I don’t eat lunches wel not much at least


**128.** `09:02` **Meredith Lamb (+14169386001)**

Well we are doing intros and lunch  but we will intro you separate


**129.** `09:02` **You**

Sok


**130.** `09:02` **Meredith Lamb (+14169386001)**

And I did all the on boarding right\. She has everything


**131.** `09:02` **Meredith Lamb (+14169386001)**

\*pats back


**132.** `09:03` **You**

Hav e to drive maddie to school but I am free till 11 and then all
Through lunch and on until 2:30


**133.** `09:03` **Meredith Lamb (+14169386001)**

Kk


**134.** `09:03` **You**

Would love
To sit and chat if you have time tell me when and I will book an official
Meeting


**135.** `09:03` **You**

Will ping you when I am back


**136.** `09:31` **Meredith Lamb (+14169386001)**

I forgot to tell you that Michelle is so different now that she knows my situation\. She was SO suspicious before… I knew it


**137.** `09:31` **Meredith Lamb (+14169386001)**

Just got off a call with her


**138.** `10:17` **Meredith Lamb (+14169386001)**

So Andrew is WFH today bc he doesn’t care anymore and is going to cottage this afternoon\. Not sure what time he is leaving\. Doesn’t mean I can’t talk but I would be more careful\. He’s on calls most of the day by anyway


**139.** `10:20` **You**

Ok I mean we can talk this aft if that works better for you\.


**140.** `10:23` **You**

I can do whatever you want basically


**141.** `10:25` **Meredith Lamb (+14169386001)**

I’m free until 11\.30


**142.** `10:25` **Meredith Lamb (+14169386001)**

You need to respond to Jacky’s email tho


**143.** `10:26` **Meredith Lamb (+14169386001)**

And don’t be an ass about the service line


**144.** `10:26` **Meredith Lamb (+14169386001)**

lol


**145.** `10:26` **You**

lol


**146.** `12:23` **Meredith Lamb (+14169386001)**

Our first lawyer call just scheduled\. Tues 1pm


**147.** `12:24` **Meredith Lamb (+14169386001)**

Like a breath of fresh air… seriously


**148.** `12:38` **Meredith Lamb (+14169386001)**

K scrap that\. The lawyer won’t see us both


**149.** `12:39` **Meredith Lamb (+14169386001)**

We each have to have our own


**150.** `12:39` **Meredith Lamb (+14169386001)**

Omg can this just end already


**151.** `12:39` **You**

Mine will see us both


**152.** `12:39` **You**

Do you want me to give you the name


**153.** `12:39` **Meredith Lamb (+14169386001)**

This guy won’t


**154.** `12:40` **You**

Well some are
Like that


**155.** `12:40` **You**

I guess


**156.** `12:40` **Meredith Lamb (+14169386001)**

Yah


**157.** `12:40` **You**

Russell Alexander Collaborative Family Lawyers


**158.** `12:40` **You**

That is who I am filling out a form for now


**159.** `12:44` **Meredith Lamb (+14169386001)**

We wanted one nearby right at yeg \(building oeb is in\)


**160.** `12:44` **Meredith Lamb (+14169386001)**

Just easy


**161.** `12:57` **You**

Sure but I believe you will want one you can both see together or this will get very
Contentious although I still expect you would come out further ahead


**162.** `12:57` **You**

Just puts at further risk cottage and house


**163.** `12:58` **Meredith Lamb (+14169386001)**

Yeah I’m done\. Not negotiating anymore


**164.** `12:58` **Meredith Lamb (+14169386001)**

I just want it on paper and done


**165.** `12:58` **Meredith Lamb (+14169386001)**

I want the girls to get their home and cottage so it is what it is\. And it is fine


**166.** `12:59` **You**

As long as you feel you have enough to get to where you need to be\.
Beyond 8 years have you planned out how you will proceed


**167.** `12:59` **Meredith Lamb (+14169386001)**

I won’t be in this area beyond 8 yrs


**168.** `12:59` **You**

I mean pls tel me to shut it lol I am just thinking about how I thought this through for Jaimie


**169.** `13:00` **Meredith Lamb (+14169386001)**

Marlowe done high school in 6 yrs


**170.** `13:00` **You**

And I set it up so she will be fine beyond the term


**171.** `13:00` **You**

But if you rent you will have no equity to put down on a new home right


**172.** `13:00` **Meredith Lamb (+14169386001)**

If he buys me out of cottage I get half of $1\.5m


**173.** `13:00` **You**

Unless
You borrow against the cottage or whatever


**174.** `13:00` **You**

Yeah


**175.** `13:00` **Meredith Lamb (+14169386001)**

I don’t want in the cottage long term


**176.** `13:01` **You**

Make sure that is in agreement


**177.** `13:01` **You**

The buyout clause


**178.** `13:01` **Meredith Lamb (+14169386001)**

Yeah


**179.** `13:01` **You**

So I assume you will be continuing to pay a portion of the cottage mortgage etc


**180.** `13:01` **Meredith Lamb (+14169386001)**

Yup


**181.** `13:01` **You**

Kk then that could work for you\.


**182.** `13:01` **Meredith Lamb (+14169386001)**

$1,500 per month


**183.** `13:02` **You**

Fack lol


**184.** `13:03` **You**

Just mer I know you are smart smarter
Than me in a ton of ways but you also have a huge heart\.\. again much bigger
Than mine I am way meaner\.\. or would be in this situation\.
I just want you to be
Taken care of to be able
To retire when you want and have the life you want\.


**185.** `13:04` **You**

I was going to say if but when we can be together I have no doubt we would support each other through whatever comes anyways


**186.** `13:05` **Meredith Lamb (+14169386001)**

Wdym “Fack lol”


**187.** `13:05` **You**

Just a lot of money lol


**188.** `13:05` **You**

For me that is


**189.** `13:06` **Meredith Lamb (+14169386001)**

With insurances and property tax and gas it is 2,002 \+ 250 per month total lol


**190.** `13:06` **You**

You focus on the Fack and not the nice things… psssh… 😛


**191.** `13:07` **Meredith Lamb (+14169386001)**

Feel better?


**192.** `13:07` **Meredith Lamb (+14169386001)**

Reaction: 😝 from Scott Hicks
I was just curious what you were reacting to


**193.** `13:25` **You**

So my feelings on your comment\.\. never been happier or felt
More at ease\.\.  it still want to learn more about what makes you “happy” and suggest much practice should be forthcoming\.


**194.** `13:25` **You**

But we will leave that out of teams


**195.** `13:28` **You**

And we will see how brave you are lol


**196.** `13:28` **Meredith Lamb (+14169386001)**

Yeah not teams content for sure


**197.** `13:28` **You**

As you would say So…………\.


**198.** `13:28` **Meredith Lamb (+14169386001)**

How BRAVE I am?


**199.** `13:28` **Meredith Lamb (+14169386001)**

lol


**200.** `13:29` **Meredith Lamb (+14169386001)**

Depends on the context in terms of my bravery haha


**201.** `13:29` **Meredith Lamb (+14169386001)**

It is quite a spectrum


**202.** `13:30` **You**

Just in response\.\. nothing else
Right now\.


**203.** `13:32` **Meredith Lamb (+14169386001)**

My bravery is different everyday lol


**204.** `13:33` **You**

Ok fine don’t engage\.\. I can be patient\.


**205.** `13:33` **Meredith Lamb (+14169386001)**

I mean you have no choice so…


**206.** `13:34` **You**

Agreed, just trying to be the best I can be as the saying goes 😊


**207.** `13:39` **You**

We could continue this conversation tonight but I think you would need a few drinks\.  anyways you know where I stand on this lol\.


**208.** `13:55` **Meredith Lamb (+14169386001)**

lol sorry, had to find my freaking cc


**209.** `13:55` **Meredith Lamb (+14169386001)**

Mac took my credit card in Detroit and still hasn’t given it back


**210.** `13:55` **Meredith Lamb (+14169386001)**

Needed it


**211.** `13:55` **Meredith Lamb (+14169386001)**

Man


**212.** `13:55` **You**

lol


**213.** `13:55` **Meredith Lamb (+14169386001)**

Found weight loss pills in her room


**214.** `13:55` **Meredith Lamb (+14169386001)**

Argh


**215.** `13:56` **You**

Eesh that isn’t good


**216.** `13:56` **Meredith Lamb (+14169386001)**

I think she is anorexic


**217.** `13:56` **Meredith Lamb (+14169386001)**

New thing to deal with


**218.** `13:56` **You**

☹️ sucks\.


**219.** `13:56` **Meredith Lamb (+14169386001)**

>
Probably need more than a few drinks

*💬 Reply*

**220.** `13:57` **You**

Hey I am just so out of practice I think I need some help\.  I mean it is only in our best interests\.


**221.** `13:58` **Meredith Lamb (+14169386001)**

Oh stop lol I just need to know you better


**222.** `13:58` **Meredith Lamb (+14169386001)**

As weird as that sounds


**223.** `13:59` **You**

Well we can figure that out whenever you want\.


**224.** `13:59` **Meredith Lamb (+14169386001)**

I mean we have had all of one weekend together and it was amazing so slow your roll


**225.** `14:00` **Meredith Lamb (+14169386001)**

Or maybe, just don’t worry


**226.** `14:00` **Meredith Lamb (+14169386001)**

Or whatever


**227.** `14:04` **You**

I am not worried\. Initially I was just playing with the weekend alignment  comment but was then like whatever why not… 🙁


**228.** `14:06` **You**

😇


**229.** `14:06` **You**

Sad face was supposed to be this guy


**230.** `14:06` **You**

But maybe both work LOL


**231.** `14:06` **Meredith Lamb (+14169386001)**

k and yes both work


**232.** `14:06` **Meredith Lamb (+14169386001)**

lol


**233.** `14:06` **You**

heh


**234.** `16:41` **You**

Insane fight all over cheap little crappy rings


**235.** `16:41` **Meredith Lamb (+14169386001)**

Ok that is a little crazy\. For real\.


**236.** `16:42` **You**

Seriously I swear this is what my life has been like for years but this is my fault


**237.** `16:42` **Meredith Lamb (+14169386001)**

I mean it takes two


**238.** `16:43` **You**

Well yeah but to be honest Gracie will literally never ever quit and if you hold out long enough she starts breaking stuff and then she moves on to hitting herself in the head\.  And j wouldn’t let me take her in for a psyche eval\.


**239.** `16:46` **Meredith Lamb (+14169386001)**

Maybe she will let you now? Have you tried re\-suggesting it?


**240.** `16:46` **Meredith Lamb (+14169386001)**

She could get suicidal if she is left too long


**241.** `16:47` **You**

We don’t have a choice now


**242.** `16:47` **You**

She is 18


**243.** `16:47` **You**

We cannot do anything


**244.** `16:47` **You**

The cops even told us


**245.** `16:47` **Meredith Lamb (+14169386001)**

Ohhhhhh right


**246.** `16:47` **You**

It really is bad we have very little control


**247.** `16:48` **Meredith Lamb (+14169386001)**

Was she checked for bi\-polar?


**248.** `16:48` **You**

All we can really do is kick her out


**249.** `16:48` **You**

I think she has it\.  But we didn’t hear that from the psychiatrist she sees and the bi polar mess made her worse


**250.** `16:48` **Meredith Lamb (+14169386001)**

My sis is bi\-polar and really unstable at times


**251.** `16:48` **You**

I feel like Gracie has a bunch of shit wrong but we cannot figure out how to get it addressed


**252.** `16:49` **Meredith Lamb (+14169386001)**

It’s weird bc my sis is adopted but we have bipolar in my family on both sides


**253.** `16:49` **You**

It is a tough problem\.\. I have friends with it


**254.** `16:49` **You**

The meds can be rough


**255.** `16:50` **Meredith Lamb (+14169386001)**

Well if she is freaking out over rings she needs more important things in her life \(school, work, etc etc\)…


**256.** `16:50` **Meredith Lamb (+14169386001)**

It would put the rings into a different perspective lol


**257.** `16:50` **You**

Logic doesn’t work I have tried this lol


**258.** `16:51` **You**

It was
Like this when she had school


**259.** `16:51` **You**

And work


**260.** `16:51` **Meredith Lamb (+14169386001)**

Does her therapist not help?


**261.** `16:51` **You**

She needs everything the way her mind requires it


**262.** `16:51` **You**

Not so far and we are t allowed to interact


**263.** `16:51` **You**

Again 18 and we have no rights


**264.** `16:53` **You**

Like right now she is losing her goddamn mind because she absolutely has to have an iPad in the bathroom
With her while
She showers
Some she can watch or listen to something g


**265.** `17:13` **Meredith Lamb (+14169386001)**

Intense


**266.** `17:17` **You**

Now j says she has to live with me which I said is fine but there will be rules and she will have to follow them\.\. and then she said but you cannot kick her out\.\. and I said this is your problem there are no real consequences\.\. and at her age these are them


**267.** `17:20` **You**

Hey don’t worry about responding you are busy we can chat later


**268.** `17:21` **You**

❤️ u


**269.** `17:24` **Meredith Lamb (+14169386001)**

Going to go over finances one last time just to get him the hell out of here


**270.** `17:31` **You**

No worries best of luck I know you are tired but he doesn’t deserve any relief\.


**271.** `18:13` **Meredith Lamb (+14169386001)**

K we are good\. All fine\. Lawyer next week


**272.** `18:16` **You**

Good


**273.** `18:16` **You**

Was thinking about you but trying not worry


**274.** `18:17` **You**

Cause you get mad at me when I show caring feelings lol


**275.** `18:20` **You**

Cause when you love
Someone this much you always care but it isn’t about you not being capable it is just about me caring about your well\-being\.  I just want you to understand when I worry that is why\.\. well that or because my brain kicks me in the face but that is happening less and less frequently to be honest\.


**276.** `18:23` **You**

So ❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️ I hope it went well and you feel good about the outcome and that he leaves you be to have a nice weekend\.


**277.** `18:23` **Meredith Lamb (+14169386001)**

He hasn’t left yet omg


**278.** `18:23` **You**

Errr


**279.** `18:24` **Meredith Lamb (+14169386001)**

Mac and all her friends are here and playing country music omg


**280.** `18:24` **You**

Well that went in a diff direction


**281.** `18:24` **You**

lol


**282.** `18:24` **Meredith Lamb (+14169386001)**

Zack Bryan


**283.** `18:24` **Meredith Lamb (+14169386001)**

I have them edibles so they love me


**284.** `18:24` **You**

So he is not going to go now


**285.** `18:24` **You**

I mean you are the mum with candy so they all love you lol


**286.** `18:26` **Meredith Lamb (+14169386001)**

He is but omg taking forever


**287.** `18:27` **You**

🙁


**288.** `18:27` **Meredith Lamb (+14169386001)**

One of them told me I look like a teenager bc of my sweatpants\. She has the same ones\. She is a duck up


**289.** `18:27` **Meredith Lamb (+14169386001)**

\*suck up


**290.** `18:27` **Meredith Lamb (+14169386001)**

lol


**291.** `18:27` **You**

Take it whatever the reason


**292.** `18:27` **Meredith Lamb (+14169386001)**

lol


**293.** `18:28` **You**

You certainly can still act
Like one


**294.** `18:28` **Meredith Lamb (+14169386001)**

They are having fan\. Just left with a speaker blaring walking down the street


**295.** `18:28` **Meredith Lamb (+14169386001)**

>
No shame

*💬 Reply*

**296.** `18:28` **You**

We made out like teenagers for sure


**297.** `18:28` **You**

And that was super fun


**298.** `18:29` **Meredith Lamb (+14169386001)**

I mean it was more than fun for sure


**299.** `18:29` **You**

Yeah no it was fun, remained fun but yeah was def more\.


**300.** `18:30` **You**

And like I told you will never get tired of it


**301.** `18:30` **You**

It is something about how great it is anyways and how great you are period


**302.** `18:30` **Meredith Lamb (+14169386001)**

Don’t say never please


**303.** `18:31` **You**

I cannot foresee a possible situation in which I might feel differently one might exist but I cannot see it


**304.** `18:31` **You**

Reaction: ❤️ from Meredith Lamb
How is that for getting around never in an awesome way


**305.** `18:32` **Meredith Lamb (+14169386001)**

Much better


**306.** `18:32` **You**

When I use absolutes consider the intent not the literal\.\.
Will make it easier but the second thing I said is way more
Literally accurate


**307.** `18:33` **You**

And my memory brings me back to the moments whenever I want and still thinking about it over
And
Over I feel
The same


**308.** `18:34` **Meredith Lamb (+14169386001)**

I couldn’t get the tv working for some reason and he goes “what are you going to do without me?” 🙄


**309.** `18:34` **You**

I could not find a flaw or bad moment or bad feeling


**310.** `18:34` **You**

Rofl


**311.** `18:34` **You**

Wow


**312.** `18:34` **You**

Ask ChatGPT douchebag


**313.** `18:34` **You**

That should have been your answer


**314.** `18:34` **You**

lol


**315.** `18:34` **Meredith Lamb (+14169386001)**

He hates ChatGPT


**316.** `18:35` **You**

See I knew I would never like him\.


**317.** `18:35` **Meredith Lamb (+14169386001)**

Hahaha


**318.** `18:36` **You**

Anyways I know you have a hard time with affection\.\.
So just take it for what it is and feel good about it\.\.
Give
Yourself a break relax
He will be gone soon and you can chill with your teeny friends


**319.** `18:36` **You**

That is why I picked the song I did


**320.** `18:36` **You**

The lyrics
Pretty much describe you lol


**321.** `18:36` **Meredith Lamb (+14169386001)**

The only exception song?


**322.** `18:37` **You**

No that describes how I feel about you


**323.** `18:37` **Meredith Lamb (+14169386001)**

What song


**324.** `18:37` **You**

Our song I considered to be the one we danced to


**325.** `18:37` **You**

But it could also be only exception


**326.** `18:37` **Meredith Lamb (+14169386001)**

Ohhhhhhhhh\!


**327.** `18:37` **You**

I listen to it every day at least a couple times lol sap\.


**328.** `18:38` **Meredith Lamb (+14169386001)**

:\)


**329.** `18:38` **You**

I don’t think you were listening to the song though when we were dancing


**330.** `18:38` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I was not


**331.** `18:38` **Meredith Lamb (+14169386001)**

lol


**332.** `18:39` **Meredith Lamb (+14169386001)**

I was distracted


**333.** `18:39` **Meredith Lamb (+14169386001)**

You distract me a lot


**334.** `18:40` **You**

I try to\. But in a good way\. I do not expect that I will ever likely stop trying to distract you in that way\.


**335.** `18:40` **You**

Reaction: 😂 from Meredith Lamb
God it is so wordy to get around absolutes


**336.** `18:40` **You**

Words though\.\. I got lots of those\.


**337.** `18:41` **Meredith Lamb (+14169386001)**

Reaction: 😀 from Scott Hicks
Literally


**338.** `18:41` **Meredith Lamb (+14169386001)**

Friday night last week was so much better :p


**339.** `18:42` **You**

Yeah it was\.\. man I was out of my mind\.\.


**340.** `18:42` **You**

Can still remember


**341.** `18:42` **You**

The whole weekend was
Like that for me though


**342.** `18:42` **You**

Just surreal in so many ways


**343.** `18:42` **Meredith Lamb (+14169386001)**

And now we are back here\.


**344.** `18:43` **Meredith Lamb (+14169386001)**

😵‍💫


**345.** `18:43` **You**

Well I do t think back


**346.** `18:43` **You**

I think we took a step forward


**347.** `18:43` **You**

And just have to pause before taking the next


**348.** `18:43` **You**

So I don’t see it as back


**349.** `18:44` **Meredith Lamb (+14169386001)**

I guess\. But we are literally back in the same places\.


**350.** `18:44` **You**

We are in our houses respectively and I loved you certainly before last
Weekend more than I have ever loved
Anyone \.\. and
Like I said it only grew
And continues
To\.\. we are making progress
In our respective situations\.


**351.** `18:45` **You**

And that rock you gave me was one of the nicest most thoughtful things anyone has ever done for me


**352.** `18:46` **You**

So while I worry and fret I am feeling more and more confident about the future more specifically that we might not be too far off from having a bit more opportunity to connect\.


**353.** `18:46` **You**

I can deal with 40 days and 40 nights for those kinds of weekends\.


**354.** `18:47` **You**

Are you worried this will
Ever stop?


**355.** `18:47` **You**

The wooing and texting because I don’t think it is likely to either


**356.** `18:47` **You**

Just in case you are worried


**357.** `18:48` **Meredith Lamb (+14169386001)**

I have a little anxiety…


**358.** `18:48` **Meredith Lamb (+14169386001)**

But my life is such a shitty mess I don’t focus on it too much


**359.** `18:48` **Meredith Lamb (+14169386001)**

Tbh


**360.** `18:48` **Meredith Lamb (+14169386001)**

But it is there


**361.** `18:49` **You**

Why are you anxious\.\. I can relieve it for you I am sure


**362.** `18:49` **You**

Or you can tell me later if you want


**363.** `18:49` **Meredith Lamb (+14169386001)**

I don’t think you can


**364.** `18:49` **You**

Why not


**365.** `18:50` **Meredith Lamb (+14169386001)**

It is just related to the fact that if we never get real opportunities to actually spent time together in real life, what happens… just haven’t been in this situation so it is the unknown I guess


**366.** `18:51` **You**

This and talking \- communicating reassuring each other that is how we stay healthy


**367.** `18:51` **You**

That we know that despite the lack of opportunities or having to prioritize other things this is important enough to hold
Onto


**368.** `18:52` **You**

I never wanted to let you leave Monday night because I knew when you walked out that was it for a while


**369.** `18:52` **You**

And it hurt literally but I did it anyways


**370.** `18:53` **Meredith Lamb (+14169386001)**

Here is another smaller anxiety


**371.** `18:53` **You**

Reaction: 😂 from Meredith Lamb
But I think what I have said above is key and I think we are ok at it\.\. yes I might communicate more than you but as long as you can tolerate it lol


**372.** `18:53` **You**

Ok


**373.** `18:53` **You**

What is the other


**374.** `18:54` **Meredith Lamb (+14169386001)**

So I feel like you have been very neglected \(not sure of the right word but that is the closest\) for years…\. So you think ppl don’t like you or are not attracted to you or whatever when it just isn’t the case\. You were just blind in your weird situation


**375.** `18:54` **Meredith Lamb (+14169386001)**

Sooo


**376.** `18:55` **You**

So why are you anxious


**377.** `18:55` **Meredith Lamb (+14169386001)**

Now that I have shown interest and an actual longing/connection/desire for you that you might feel like testing the waters lol


**378.** `18:56` **You**

So let me lay a few things out\. This will take a few sentences


**379.** `18:56` **Meredith Lamb (+14169386001)**

But does that make sense?


**380.** `18:57` **You**

I can see how you might feel that way\.\. just responding before I share my thoughts


**381.** `18:57` **You**

So first I haven’t connected with anyone like this on any level ever and I can say ever in this instance\.


**382.** `18:58` **Meredith Lamb (+14169386001)**

But it doesn’t mean you couldn’t with someone else


**383.** `18:58` **Meredith Lamb (+14169386001)**

Right?


**384.** `18:59` **You**

Second, I have had ED for about 5 years probably psychological ,
My performance
anxiety was
Literally off the charts… as
I said to you my changing my “personal” habits for the first
Time since I was what 15 to something g that has never happened, my ability at all to do what we did\.\. like you don’t understand that is what
YOU do to
Me\.


**385.** `18:59` **You**

Not other people


**386.** `18:59` **You**

I haven’t looked at a girl in any way
For years before you and haven’t after


**387.** `19:00` **You**

I am not joking


**388.** `19:00` **You**

Ok on to the next point


**389.** `19:01` **You**

I do have like zero confidence in my abilities it is true it has been so friggen long like pre Jaimie likely that anything like that happened,
But still
All
I can think about is your happiness
Were you weren’t you what can I do better differently etc


**390.** `19:01` **You**

Again not a single thought of anything but you


**391.** `19:02` **You**

I am so worried tontell you because I thought it would scare you off


**392.** `19:02` **You**

See I will tell you anything


**393.** `19:02` **Meredith Lamb (+14169386001)**

I am not scared even an inch


**394.** `19:02` **Meredith Lamb (+14169386001)**

This does not scare me


**395.** `19:03` **Meredith Lamb (+14169386001)**

But it is surprising to hear bc from what I know about ED that wasn’t it


**396.** `19:03` **Meredith Lamb (+14169386001)**

lol


**397.** `19:03` **You**

You have nothing to worry about out from me\.\. all I do is try to figure out how to give you whatever I can however I can\.\.


**398.** `19:03` **Meredith Lamb (+14169386001)**

So you don’t want to go sow your oats


**399.** `19:03` **You**

I have been taking tadafil for years even that doesn’t really help\.\.
Got thinks it is emotional and psychological


**400.** `19:03` **You**

Just with you repeatedly


**401.** `19:04` **You**

And I know you told me your drive was kind of\. It there


**402.** `19:04` **You**

I didn’t think mine was either


**403.** `19:04` **You**

But apparently
It so


**404.** `19:04` **You**

Not so


**405.** `19:04` **Meredith Lamb (+14169386001)**

Yeah thoughts if andrew…\. 👎


**406.** `19:04` **Meredith Lamb (+14169386001)**

\*of


**407.** `19:05` **Meredith Lamb (+14169386001)**

But my body could always perform


**408.** `19:05` **Meredith Lamb (+14169386001)**

Just had to not think about him lol


**409.** `19:05` **You**

I could not… do that


**410.** `19:05` **Meredith Lamb (+14169386001)**

Very interesting


**411.** `19:05` **Meredith Lamb (+14169386001)**

Did you ChatGPT that


**412.** `19:06` **You**

There is some kind of emotional requirement


**413.** `19:06` **Meredith Lamb (+14169386001)**

Is it psychological


**414.** `19:06` **You**

I think it is both emotional and psychological


**415.** `19:06` **You**

But yeah I mean there are other things insecurities everyone has and I try not to think about them


**416.** `19:07` **Meredith Lamb (+14169386001)**

The emotional part is massive for me for sure


**417.** `19:08` **Meredith Lamb (+14169386001)**

I would want to be with you even if we couldn’t have sex\. I honestly wouldn’t care


**418.** `19:09` **Meredith Lamb (+14169386001)**

The other stuff is just as important


**419.** `19:09` **Meredith Lamb (+14169386001)**

If not more


**420.** `19:11` **You**

I appreciate that and I agree\.\. but sex is important and I don’t say that because I think it\.\. because it just is everything f I have ever read talks about sexual compatibility being important to maintaining a strong healthy relationship\.  I cannot help but worry not about you… so like that is where my main concern is\.\. I haven’t always felt that way\.\. but I am older and love you more than anything so I cannot help but feel that way now\.\.
Another mental thing I will have to overcome\.\.  it I have been ok so far I guess at doing that\.


**421.** `19:12` **You**

I just try not to think about certain things\.\. and focus on others\.\. sometimes more successfully than others\.


**422.** `19:13` **Meredith Lamb (+14169386001)**

I mean I think all those articles are written biased lol


**423.** `19:13` **You**

Mmmm I don’t think so I believe it is true\. To a large degree\.
I didn’t a long time ago but seeing what I went through I think there might be some truth to it


**424.** `19:13` **Meredith Lamb (+14169386001)**

My dad had prostate surgery at like 53 or some young age and couldn’t have sex after\. My parents are great 30 yrs later…errrr wait sorry


**425.** `19:13` **Meredith Lamb (+14169386001)**

lol


**426.** `19:15` **You**

I mean the ability or have sex isn’t overly a concern I feel like I have a better handle on that now it is the rest\.


**427.** `19:16` **You**

Anyhow it is a topic that is tough to talk about out let alone think about\.\. or lead to questioning a whole bunch of things that don’t make me feel good\.


**428.** `19:16` **Meredith Lamb (+14169386001)**

Why are you so hard on yourself?


**429.** `19:16` **You**

I don’t know I always have been


**430.** `19:16` **Meredith Lamb (+14169386001)**

Low key yeah


**431.** `19:16` **You**

It is part of who I am


**432.** `19:16` **Meredith Lamb (+14169386001)**

\(Ad Mac would say\)


**433.** `19:17` **Meredith Lamb (+14169386001)**

\*As


**434.** `19:17` **You**

It drives me to do things to get better
To be better\.  To want to be worthy etc\.\. and it doesn’t matter what I hear it always is there


**435.** `19:18` **You**

I don’t know if I can fix this it will just likely become less prominent over time perhaps\.\. I am not sure you are a unique case


**436.** `19:19` **Meredith Lamb (+14169386001)**

So curious \.\. what you are seeking? An instruction manual to me?


**437.** `19:19` **You**

777777777777


**438.** `19:19` **You**

lol


**439.** `19:19` **Meredith Lamb (+14169386001)**

Hahahaha


**440.** `19:20` **Meredith Lamb (+14169386001)**

That was a good one


**441.** `19:20` **You**

I mean usually that comes with time but seeing as we don’t have a ton of it\.\. I just want to get to a place where you are comfortable and I know what to do to make you happy\.  I think there are a lot of selfish people when it comes to this kind of thing\.\. I am not that\.


**442.** `19:22` **Meredith Lamb (+14169386001)**

Definitely time… I need time for sure\. I’m not as intense as you I don’t think\. Trust me, I am comfortable with you but there are degrees that come with time and really getting to know someone\. So we are not degrees deep yet but I find that fun personally


**443.** `19:23` **You**

I can be patient if you are happy\.  It is just how I am made\.\. it think it has to do with how I was raised \- always be courteous and polite always think about the other person first, always give more than you receive\.


**444.** `19:24` **Meredith Lamb (+14169386001)**

I mean you can call it being patient but maybe just enjoy the ride\.\.


**445.** `19:25` **You**

Like you said the ride has a lot of long pauses\.\. it won’t change how I feel or how long I will wait but you know anticipation \- only so much of a good thing\.


**446.** `19:25` **You**

But you shouldn’t worry about where my head is at\.


**447.** `19:25` **Meredith Lamb (+14169386001)**

Did your past girlfriends and wife tell you exactly what to do after your first weekend together?


**448.** `19:25` **Meredith Lamb (+14169386001)**

lol


**449.** `19:26` **You**

Mmmmm


**450.** `19:26` **Meredith Lamb (+14169386001)**

lol


**451.** `19:26` **You**

It was a different time and I was different


**452.** `19:26` **Meredith Lamb (+14169386001)**

Meaning you didn’t care about them?


**453.** `19:26` **Meredith Lamb (+14169386001)**

Haha


**454.** `19:26` **You**

No


**455.** `19:27` **You**

I just never really had a problem with that kind of thing\. The giving and all\.\. lol\.


**456.** `19:27` **You**

Like you said your body was capable mine probably was a lot more before the last 20 years of kind of meh\.


**457.** `19:28` **Meredith Lamb (+14169386001)**

Was that like a gradual thing or all of a sudden?


**458.** `19:28` **You**

Anyhow it was a long time ago and I cannot even remember most of it now\.


**459.** `19:29` **You**

It was after kids well before we moved here


**460.** `19:29` **You**

That is kind of when I realized I made a mistake and I was stuck


**461.** `19:29` **You**

Still no desire to look anywhere else


**462.** `19:29` **You**

Was not acceptable to me


**463.** `19:30` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Just reading all of that like I’m so glad we met\.


**464.** `19:30` **You**

I mean listen even thinking about competitive math makes me cry inside lol


**465.** `19:30` **You**

Comparative


**466.** `19:31` **You**

So like you said will take some time I will get my head around this


**467.** `19:31` **Meredith Lamb (+14169386001)**

Me too :\)


**468.** `19:35` **Meredith Lamb (+14169386001)**

👻


**469.** `19:36` **You**

>
lol why

*💬 Reply*

**470.** `19:37` **Meredith Lamb (+14169386001)**

Just because\.


**471.** `19:40` **Meredith Lamb (+14169386001)**

I just got asked “Do you not have any sadness about this?”


**472.** `19:40` **Meredith Lamb (+14169386001)**

Hasn’t left yet


**473.** `19:40` **You**

Look you have insecurities about the future I have then about the past\.\. I guess we will just have to see how we can deal with those\.  We are human


**474.** `19:40` **You**

Ouch


**475.** `19:40` **You**

Ok


**476.** `19:41` **You**

Maybe ignore my comment for a min


**477.** `19:41` **Meredith Lamb (+14169386001)**

>
This is very true\. Didn’t think about that\.

*💬 Reply*

**478.** `19:41` **Meredith Lamb (+14169386001)**

I said I had my sadness 3 years ago


**479.** `19:42` **You**

Yeah remeber how I said never try to compete with the past\.\. it is really really hard to keep that out of your head\.\.
lol\.


**480.** `19:42` **You**

>
What did he say

*💬 Reply*

**481.** `19:42` **You**

Eye roll\.\.


**482.** `19:42` **You**

My bet is on that


**483.** `19:42` **Meredith Lamb (+14169386001)**

No he nodded


**484.** `19:42` **Meredith Lamb (+14169386001)**

He knows how I felt then


**485.** `19:43` **Meredith Lamb (+14169386001)**

My mom and him convinced me to stay


**486.** `19:43` **You**

We’re you with the company yet


**487.** `19:43` **Meredith Lamb (+14169386001)**

Yup


**488.** `19:44` **Meredith Lamb (+14169386001)**

Had recently started


**489.** `19:44` **You**

That might have caused something to happen sooner


**490.** `19:44` **Meredith Lamb (+14169386001)**

I was going home to these conversations when I first started working for you


**491.** `19:44` **Meredith Lamb (+14169386001)**

Can’t remember exactly when


**492.** `19:44` **Meredith Lamb (+14169386001)**

I went back to work basically bc I hated him


**493.** `19:45` **Meredith Lamb (+14169386001)**

When you asked me during the interview…


**494.** `19:45` **You**

I never really knew about that at the time\.\.


**495.** `19:45` **Meredith Lamb (+14169386001)**

“Why now? Why go back to work now?” I laughed a little in my head


**496.** `19:45` **Meredith Lamb (+14169386001)**

Like not fully but like 1/5 of me knew this was coming


**497.** `19:46` **Meredith Lamb (+14169386001)**

Wasn’t a big focus


**498.** `19:46` **Meredith Lamb (+14169386001)**

>
No one did except Andrew and my parents

*💬 Reply*

**499.** `19:46` **You**

Had I known had we gotten to know each other like we have I think I would have likely called it\.


**500.** `19:48` **You**

Still woukd have been in same awkward situation with you reporting to me though lol


**501.** `19:48` **You**

But I guess not for long


**502.** `19:48` **Meredith Lamb (+14169386001)**

lol


**503.** `19:49` **Meredith Lamb (+14169386001)**

>
I didn’t even tell my best friends 3 yrs ago\.

*💬 Reply*

**504.** `19:49` **Meredith Lamb (+14169386001)**

Unheard of for me\.


**505.** `19:49` **You**

I mean I don’t blame you


**506.** `19:49` **You**

It is tough


**507.** `19:50` **Meredith Lamb (+14169386001)**

Yeah they helped me through the 2016 stuff everyday


**508.** `19:50` **You**

I have told very few people about my situation


**509.** `19:50` **Meredith Lamb (+14169386001)**

But the most important knows


**510.** `19:50` **Meredith Lamb (+14169386001)**

:\)


**511.** `19:50` **You**

Only one knows about you and how I feel


**512.** `19:50` **You**

Well 2you


**513.** `19:50` **You**

Well 3


**514.** `19:50` **You**

If you and I cojnt


**515.** `19:51` **You**

Cause Mike knows and believes me


**516.** `19:51` **Meredith Lamb (+14169386001)**

Are you going to tell anyone else?


**517.** `19:51` **You**

Not right now I came close to telling Katie


**518.** `19:51` **You**

She is just always busy


**519.** `19:51` **You**

It is a sit down talk


**520.** `19:51` **Meredith Lamb (+14169386001)**

I’ve told a bunch of ppl sorry


**521.** `19:51` **You**

Sok


**522.** `19:51` **Meredith Lamb (+14169386001)**

lol


**523.** `19:51` **You**

I don’t care


**524.** `19:52` **Meredith Lamb (+14169386001)**

Mac can be trusted tho\. You didn’t need to get anxiety today


**525.** `19:52` **You**

Oh I think she wants you to be happy


**526.** `19:52` **Meredith Lamb (+14169386001)**

Desperately she does\.


**527.** `19:53` **Meredith Lamb (+14169386001)**

She’s a good person deep down\. Lol


**528.** `19:53` **You**

She is you she has to be


**529.** `19:53` **Meredith Lamb (+14169386001)**

Just a little superficial but whatever


**530.** `19:53` **You**

That is all teens


**531.** `19:53` **Meredith Lamb (+14169386001)**

>
Lord help her if so

*💬 Reply*

**532.** `19:54` **You**

I think you did ok\.


**533.** `19:54` **You**

😊


**534.** `19:55` **You**

I mean same can be said for me


**535.** `19:55` **You**

Wasn’t a straight line


**536.** `19:56` **Meredith Lamb (+14169386001)**

Same\.


**537.** `19:56` **Meredith Lamb (+14169386001)**

lol


**538.** `19:56` **Meredith Lamb (+14169386001)**

Even tho it was a little


**539.** `19:56` **Meredith Lamb (+14169386001)**

The background wasn’t\. Lol


**540.** `19:56` **You**

But I did go through a really really long period of disappointment so that sucked


**541.** `19:57` **You**

But still here I am and different choices put me somewhere else


**542.** `19:57` **You**

And I believe I will look back and say I wouldn’t change a thing


**543.** `19:59` **Meredith Lamb (+14169386001)**

Except this and this and this lol you are so hard on yourself there will be 15 things you’d change 🙃


**544.** `19:59` **You**

No mer because if I changed anything I wouldn’t have met you\.


**545.** `20:00` **Meredith Lamb (+14169386001)**

🫠


**546.** `20:00` **Meredith Lamb (+14169386001)**

;\)


**547.** `20:01` **You**

No words… just gah\.


**548.** `20:02` **Meredith Lamb (+14169386001)**

Little quiet…\. Listening to music while chaos is around me lol


**549.** `20:03` **You**

Half naked at gym getting changed


**550.** `20:03` **You**

😇


**551.** `20:03` **Meredith Lamb (+14169386001)**

lol wow


**552.** `20:03` **Meredith Lamb (+14169386001)**

Escalated


**553.** `20:03` **Meredith Lamb (+14169386001)**

Quickly


**554.** `20:04` **You**

lol no


**555.** `20:04` **Meredith Lamb (+14169386001)**

\(Not mad\)


**556.** `20:04` **You**

That is later


**557.** `20:04` **You**

Reaction: 😂 from Meredith Lamb
This is just what I am doing


**558.** `20:05` **You**

June 21 is a bust j is going back to pei for 5 days and not taking either of the girls\.


**559.** `20:06` **Meredith Lamb (+14169386001)**

June 21\. Omg so far away\.


**560.** `20:06` **Meredith Lamb (+14169386001)**

lol


**561.** `20:06` **Meredith Lamb (+14169386001)**

And you are planning


**562.** `20:06` **Meredith Lamb (+14169386001)**

It’s sad though


**563.** `20:07` **You**

No i was I mentioned it the other night but yeah it wa far
Out\.


**564.** `20:07` **Meredith Lamb (+14169386001)**

Just leave your kids alone all night


**565.** `20:07` **Meredith Lamb (+14169386001)**

No biggie


**566.** `20:07` **Meredith Lamb (+14169386001)**

Lol


**567.** `20:07` **You**

I won’t be able to do that it would be too obvious and we have never done that


**568.** `20:08` **Meredith Lamb (+14169386001)**

I was being sarcastic


**569.** `20:08` **Meredith Lamb (+14169386001)**

I wouldn’t be able to either


**570.** `20:08` **You**

https://open\.spotify\.com/track/47Xj8eIAp7hYOOqArmkqZE?si=D51s2dDaTA\-HEgkS7wtawQ&context=spotify%3Aplaylist%3A37i9dQZF1DZ06evO2zJOi2
Listening now


**571.** `20:09` **Meredith Lamb (+14169386001)**

I listened to Morgan a lot today\.


**572.** `20:09` **Meredith Lamb (+14169386001)**

I go on and off…\.


**573.** `20:09` **You**

Just a lot


**574.** `20:10` **Meredith Lamb (+14169386001)**

?


**575.** `20:10` **You**

Heavy


**576.** `20:10` **You**

Like you said feel it


**577.** `20:10` **Meredith Lamb (+14169386001)**

Oh yeah


**578.** `20:10` **Meredith Lamb (+14169386001)**

Like jelly roll


**579.** `20:11` **You**

I don’t mean the song although it is


**580.** `20:11` **You**

Just feel heavy all of a sudden


**581.** `20:11` **Meredith Lamb (+14169386001)**

I thought you meant Morgan is heavy\. He is lol


**582.** `20:11` **You**

Yep agreed


**583.** `20:12` **Meredith Lamb (+14169386001)**

I’m kinda high now so the night is now forever clumsy :p


**584.** `20:13` **You**

Lucky


**585.** `20:13` **You**

This is why I shouldn’t


**586.** `20:14` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**587.** `20:15` **You**

It’s fine you enjoy your high and your music just gonna work out I don’t want to bring you down\.


**588.** `20:15` **You**

Wow

*💬 Reply*

**589.** `20:15` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**590.** `20:15` **Meredith Lamb (+14169386001)**

I think I need to go to the basement


**591.** `20:15` **Meredith Lamb (+14169386001)**

Brb lol


**592.** `20:15` **You**

Kk


**593.** `20:17` **Meredith Lamb (+14169386001)**

Mac’s friend bea is Haris to you


**594.** `20:17` **Meredith Lamb (+14169386001)**

I go down there and go to the fridge and she’s like “omg can I give you a hug?”


**595.** `20:18` **You**

Ah lol


**596.** `20:18` **Meredith Lamb (+14169386001)**

They are all my edibles


**597.** `20:18` **You**

Girlmance


**598.** `20:18` **Meredith Lamb (+14169386001)**

But I had 4 drinks


**599.** `20:18` **Meredith Lamb (+14169386001)**

lol


**600.** `20:18` **You**

Jesus


**601.** `20:18` **Meredith Lamb (+14169386001)**

They don’t do the drinks


**602.** `20:18` **You**

4


**603.** `20:18` **Meredith Lamb (+14169386001)**

9


**604.** `20:18` **You**

4 drinks of 9


**605.** `20:18` **Meredith Lamb (+14169386001)**

9 edibles, 4 drinks


**606.** `20:18` **Meredith Lamb (+14169386001)**

They ate all the gummies


**607.** `20:19` **Meredith Lamb (+14169386001)**

No drinks


**608.** `20:19` **You**

Rofl you will be preferring more tonight or tomorrow


**609.** `20:19` **You**

Ordering


**610.** `20:19` **Meredith Lamb (+14169386001)**

They are a bunch of very high girls\. Honestly preferable to drunk


**611.** `20:19` **You**

I agree


**612.** `20:19` **You**

Gracie drinking tonight


**613.** `20:19` **Meredith Lamb (+14169386001)**

Sharon’s here :\)


**614.** `20:20` **You**

Fireball


**615.** `20:20` **Meredith Lamb (+14169386001)**

Oh no


**616.** `20:20` **You**

J wanted me to pick her up


**617.** `20:20` **You**

I said fuck\. O


**618.** `20:20` **You**

No


**619.** `20:20` **You**

She is drinking and I am getting high


**620.** `20:20` **You**

Gracie can walk home


**621.** `20:20` **You**

I will stay awake


**622.** `20:21` **Meredith Lamb (+14169386001)**

I am going through our old laptop’s photos … Andrew is on his laptop across the house\. He is not leaving yet


**623.** `20:21` **Meredith Lamb (+14169386001)**

wtf


**624.** `20:21` **You**

He won’t leave I bet at this point


**625.** `20:22` **Meredith Lamb (+14169386001)**

Omg he better\. I think he will but he prefers to drive at night


**626.** `20:22` **Meredith Lamb (+14169386001)**

So I’m still optimistic lol


**627.** `20:22` **Meredith Lamb (+14169386001)**

Not even dark yet


**628.** `20:23` **You**

Sry was on a run interval hard to
Text


**629.** `20:23` **You**

Well I hope he does otherwise
Will be a quiet night


**630.** `20:24` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/5IOUNrN8E37eLGdLNRr9aC?si=l9sstqhwQ2ifaB5RIHwjEQ


**631.** `20:26` **Meredith Lamb (+14169386001)**

If he was gone I’d play a game with mar and Maelle right now but if I start he will stay longer ermagerrrrrd


**632.** `20:26` **You**

🙁 no win


**633.** `20:28` **Meredith Lamb (+14169386001)**

Just soooooo ugh\. 🤷‍♀️


**634.** `20:28` **You**

Yep I feel you


**635.** `20:29` **Meredith Lamb (+14169386001)**

One thing I look forward to…


**636.** `20:29` **Meredith Lamb (+14169386001)**

The first time we play ticket to ride together\.


**637.** `20:29` **Meredith Lamb (+14169386001)**

lol


**638.** `20:30` **You**

Should be fun I have never played


**639.** `20:30` **Meredith Lamb (+14169386001)**

Next time we get together


**640.** `20:30` **Meredith Lamb (+14169386001)**

Actually no I only have them at the cottage


**641.** `20:31` **You**

As I said the clear result the Friday after next after next after…\. lol sad lol but still lol


**642.** `20:31` **Meredith Lamb (+14169386001)**

Ant believe you have never played with your daughters\. :\(


**643.** `20:31` **You**

We never did that


**644.** `20:31` **Meredith Lamb (+14169386001)**

\*cant


**645.** `20:31` **You**

Reaction: 👎 from Meredith Lamb
Just monopoly


**646.** `20:31` **You**

All j wanted to play


**647.** `20:31` **Meredith Lamb (+14169386001)**

Not Pandemic??


**648.** `20:31` **You**

Nope


**649.** `20:31` **Meredith Lamb (+14169386001)**

Wow


**650.** `20:31` **You**

No family here mer


**651.** `20:31` **You**

Not really


**652.** `20:32` **You**

Used to be diff pre pandemic


**653.** `20:32` **Meredith Lamb (+14169386001)**

Yeah


**654.** `20:32` **Meredith Lamb (+14169386001)**

Altho


**655.** `20:32` **Meredith Lamb (+14169386001)**

During Covid I made my kids play ticket to ride too much and they have resentment


**656.** `20:32` **Meredith Lamb (+14169386001)**

lol


**657.** `20:33` **You**

It’s a strategy game right


**658.** `20:36` **You**

So do me a favour chatgpt Europa universalis 4 and ask it to do a comparison to ticket to ride\.\. I think it could
Make it interesting for you\.


**659.** `20:38` **You**

That was the game I played for 10
Years to get through my marriage


**660.** `20:40` **Meredith Lamb (+14169386001)**

😮

*📎 1 attachment(s)*

**661.** `20:40` **You**

😇


**662.** `20:40` **Meredith Lamb (+14169386001)**

That is so true wow


**663.** `20:40` **Meredith Lamb (+14169386001)**

lol


**664.** `20:41` **You**

I have played strategy games
Like that online since I was
12


**665.** `20:41` **Meredith Lamb (+14169386001)**

Such a nice short game


**666.** `20:41` **You**

:\)


**667.** `20:41` **Meredith Lamb (+14169386001)**

\(Ticket to ride\)


**668.** `20:41` **You**

First strategy
Game
I played was a Baird
Game
Called
Bazaar
Though


**669.** `20:41` **Meredith Lamb (+14169386001)**

And you stopped playing them?


**670.** `20:41` **You**

Got me hooked


**671.** `20:41` **You**

Yeah I don’t play anymore


**672.** `20:41` **You**

Been a few years


**673.** `20:41` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Omg he left


**674.** `20:42` **Meredith Lamb (+14169386001)**

>
Why’d you stop?

*💬 Reply*

**675.** `20:42` **You**

Lost its fun life
Just sucked too much


**676.** `20:43` **Meredith Lamb (+14169386001)**

Board games\. Start end\. Fini\.


**677.** `20:43` **You**

Didn’t have anyone


**678.** `20:44` **Meredith Lamb (+14169386001)**

What about cards


**679.** `20:44` **Meredith Lamb (+14169386001)**

Second best


**680.** `20:44` **You**

Used to play when I was
Younger up till I was married


**681.** `20:44` **You**

Cribbage


**682.** `20:44` **You**

200’s


**683.** `20:45` **You**

Which is like euchre


**684.** `20:45` **Meredith Lamb (+14169386001)**

My dad was obsessed with crib


**685.** `20:45` **Meredith Lamb (+14169386001)**

I used to play with him


**686.** `20:45` **Meredith Lamb (+14169386001)**

My kids basically know gin rummy, crazy 8s and go fish


**687.** `20:46` **Meredith Lamb (+14169386001)**

They have learned euchre maybe once


**688.** `20:46` **Meredith Lamb (+14169386001)**

I make them play gin rummy a lot\. I like it\. Lifeguarding game


**689.** `20:46` **Meredith Lamb (+14169386001)**

They had to learn\. No choice


**690.** `20:46` **You**

Played gin rummy drinking game


**691.** `20:46` **You**

lol


**692.** `20:46` **You**

I learned a lot of card games


**693.** `20:46` **You**

When I wa
You get


**694.** `20:46` **Meredith Lamb (+14169386001)**

My grandparents and mom used to make us play bridge


**695.** `20:46` **You**

Younger


**696.** `20:47` **Meredith Lamb (+14169386001)**

>
We played hours and hours and betted lifeguarding lol

*💬 Reply*

**697.** `20:47` **Meredith Lamb (+14169386001)**

Hearts?


**698.** `20:47` **Meredith Lamb (+14169386001)**

My grandpa loved hearts


**699.** `20:49` **You**

Hearts on comp


**700.** `20:49` **You**

Mostly in university


**701.** `21:04` **Meredith Lamb (+14169386001)**

“How many rounds are we playing?”

*📎 1 attachment(s)*

**702.** `21:06` **You**

That is an awwww mum moment


**703.** `21:32` **You**

Aww I had an idea of a risky thing to do for you tonight to make you smile but not sure I am up
For it lol some other time maybe


**704.** `21:33` **Meredith Lamb (+14169386001)**

🤔


**705.** `21:34` **You**

Well I am heading to the hot tub then the shower


**706.** `21:34` **You**

But nah


**707.** `21:34` **Meredith Lamb (+14169386001)**

lol


**708.** `21:34` **Meredith Lamb (+14169386001)**

You could write a sitcom


**709.** `21:35` **You**

I mean if it was about locking a try hard 47 year old man\.\. yep


**710.** `21:35` **You**

Mocking


**711.** `21:35` **Meredith Lamb (+14169386001)**

lol ok


**712.** `21:36` **You**

Some other time I figured out how to make it work\.\. lol too much time on my hands and slightly insane for you\.


**713.** `21:37` **Meredith Lamb (+14169386001)**

Sorry, am I supposed to understand that?


**714.** `21:38` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/1aZfq7TK3tNl9XJLkOpwKw?si=yzdIJJweT\_6rlIu2Vxnn3g


**715.** `21:39` **You**

Nope fail


**716.** `21:39` **You**

Won’t work


**717.** `21:39` **You**

There is a clear plastic bag for wet clothes


**718.** `21:39` **You**

But cannot video through


**719.** `21:39` **You**

Still safe to bring in hot tub


**720.** `21:40` **Meredith Lamb (+14169386001)**

I hope you read this later\.


**721.** `21:40` **You**

Read what


**722.** `21:41` **Meredith Lamb (+14169386001)**

I’m just so confused


**723.** `21:41` **Meredith Lamb (+14169386001)**

lol


**724.** `21:41` **You**

Oh you want me to revisit


**725.** `21:41` **You**

Ah ok


**726.** `21:41` **You**

Sure maybe


**727.** `21:42` **You**

You must be completely messed right now


**728.** `21:42` **Meredith Lamb (+14169386001)**

😇👼😇👼😇👼😇👼😇👼😇


**729.** `21:42` **You**

Jealous


**730.** `21:44` **You**

I am not sure we are going to be able to have a conversation later not sure you will be coherent by then lol


**731.** `21:44` **Meredith Lamb (+14169386001)**

Definitely possible


**732.** `21:44` **You**

Ah well will just go to bed early


**733.** `21:44` **Meredith Lamb (+14169386001)**

I am not sleepy


**734.** `21:45` **You**

O I know you aren’t but you are going to be in your own little world by the time I get home showering now


**735.** `21:46` **Meredith Lamb (+14169386001)**

LOL


**736.** `21:53` **You**

Less than satisfactory


**737.** `21:54` **Meredith Lamb (+14169386001)**

\[lol no words\]


**738.** `21:55` **You**

Another first I look forward to


**739.** `21:55` **You**

Mistake


**740.** `21:55` **You**

Phew


**741.** `21:55` **You**

lol


**742.** `21:55` **You**

That would have been slightly awkward


**743.** `21:55` **Meredith Lamb (+14169386001)**

Phew?


**744.** `21:56` **You**

I called you by mistake


**745.** `21:56` **You**

Hung up fast


**746.** `21:56` **You**

lol


**747.** `21:56` **You**

Wasn’t decent


**748.** `21:57` **Meredith Lamb (+14169386001)**

lol man you are loving that gym until the end eh


**749.** `21:57` **You**

Like I said
Might keep it my only refuge atm


**750.** `21:58` **You**

At least
Till I move out


**751.** `21:58` **You**

Still have to decide rent or buy


**752.** `21:58` **You**

Working k\. That tonight


**753.** `21:58` **Meredith Lamb (+14169386001)**

For real? Working \*on that tonight?


**754.** `21:59` **Meredith Lamb (+14169386001)**

Ew no


**755.** `21:59` **You**

Cannot do anything else


**756.** `22:00` **Meredith Lamb (+14169386001)**

Talk to me


**757.** `22:00` **You**

Well I can do both but I doubt I can get high


**758.** `22:01` **You**

Cause Jaimie drinking and I think someone will have to get Gracie


**759.** `22:01` **You**

Even though we told her to either stay or
Get a drive she will call or someone will call to come get her


**760.** `22:02` **Meredith Lamb (+14169386001)**

Uber


**761.** `22:02` **You**

She will be too drunk no doubt


**762.** `22:02` **Meredith Lamb (+14169386001)**

I had to put $100/ month in my expenses for rando ubers


**763.** `22:03` **Meredith Lamb (+14169386001)**

\(And those aren’t me\)


**764.** `22:03` **You**

Rofl


**765.** `22:04` **You**

I mean the fucking detail


**766.** `22:04` **You**

Omfg


**767.** `22:04` **Meredith Lamb (+14169386001)**

lol


**768.** `22:04` **Meredith Lamb (+14169386001)**

What more detail do you require


**769.** `22:04` **Meredith Lamb (+14169386001)**

Perfectionist much?


**770.** `22:05` **You**

No I am not criticizing


**771.** `22:05` **You**

That is like 5x
The detail


**772.** `22:05` **You**

I went to


**773.** `22:05` **You**

Too much


**774.** `22:05` **Meredith Lamb (+14169386001)**

Ohhh


**775.** `22:05` **Meredith Lamb (+14169386001)**

My budget is very specific


**776.** `22:05` **You**

Yeah I can tell


**777.** `22:05` **Meredith Lamb (+14169386001)**

Wanted to make sure he knows what I spend on his daughters


**778.** `22:05` **You**

Like I said we didn’t go bottom up we went too down


**779.** `22:06` **You**

Here is how much you get…\.
It is a lot more than k get…\. Figure it out


**780.** `22:06` **Meredith Lamb (+14169386001)**

Do one and calibrate with the other


**781.** `22:06` **You**

I like my approach


**782.** `22:07` **Meredith Lamb (+14169386001)**

I generally like your approaches\.


**783.** `22:07` **You**

Dev


**784.** `22:09` **You**

Sec


**785.** `22:36` **You**

Friday you tried something I was like nope\.\. then relented\.\. then funny shit happened\.\.
Which you won’t remember anyways and then I explained\.


**786.** `22:36` **You**

Because you were persistent lol\.\. I am fairly certain I allowed
You to be much more persistent than me\.


**787.** `22:38` **Meredith Lamb (+14169386001)**

Were you upset?


**788.** `22:50` **You**

lol about what


**789.** `22:51` **Meredith Lamb (+14169386001)**

That I was so persistent


**790.** `22:52` **You**

Hardly it was amazing but I am still self conscious\.\.


**791.** `22:52` **You**

But  I wanted the same opportunity I guess


**792.** `22:52` **Meredith Lamb (+14169386001)**

I just don’t think I enjoy it like a guy does


**793.** `22:53` **Meredith Lamb (+14169386001)**

Something different about the whole thing with guys and girls


**794.** `22:54` **Meredith Lamb (+14169386001)**

\(I now know what a burnt vape tastes like…\. Doesn’t deserve the word “burnt”\. So much less than that…\. 🙄\)


**795.** `23:07` **You**

Rofl


**796.** `23:07` **You**

>
I think we should try at least
Once and if no then find something else\. Imho\. Maybe it will be different…

*💬 Reply*

**797.** `23:08` **You**

Sorry fighting with Jaimie again\.


**798.** `23:08` **You**

Now done


**799.** `23:12` **Meredith Lamb (+14169386001)**

lol


**800.** `23:12` **Meredith Lamb (+14169386001)**

Neverending story


**801.** `23:13` **Meredith Lamb (+14169386001)**

On both sides


**802.** `23:17` **You**

Reaction: ❤️ from Meredith Lamb
>
Mmmmmmhmmmmmm

*💬 Reply*

**803.** `23:21` **You**

Sooo……\.


**804.** `23:22` **You**

Cmon you know how this works


**805.** `23:22` **Meredith Lamb (+14169386001)**

I’m not sure I do\.


**806.** `23:23` **You**

Well I am unsure what the heart means in this context lol


**807.** `23:31` **Meredith Lamb (+14169386001)**

Ong im too stoned for this… lol


**808.** `23:39` **You**

Oh sure you are


**809.** `23:39` **You**

It’s ok you don’t have to engage


**810.** `23:39` **You**

I know this is hard for you\.s


**811.** `23:49` **You**

Reaction: 😢 from Meredith Lamb
You went to sleep\.\. kk I am going to go to bed tired
Of
Fighting with j another shit night  here I need to fucking leave\.


**812.** `23:51` **You**

Man almost went full lawyers tonight


**813.** `23:59` **You**

😢


