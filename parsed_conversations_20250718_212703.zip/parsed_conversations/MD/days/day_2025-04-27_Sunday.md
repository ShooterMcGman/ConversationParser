# Daily Conversation: 2025-04-27 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-27 |
| **Day** | Sunday |
| **Week** | 3 |
| **Messages** | 366 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-27T03:24 - 2025-04-27T22:42 |

## 📝 Daily Summary

This day contains **366 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `03:24` **You**

Reaction: ❤️ from Meredith Lamb
It doesn’t know what it is talking about\.  That was simply the best night I have had in an immensely long time\.  And the only reason I can think of is that is because it was with you\.  I love you very much
Thank you for being with me tonight\.  Have a great
Sleep\.

*💬 Reply*

**002.** `08:12` **You**

Ok sightly hung over


**003.** `08:12` **You**

😩


**004.** `09:41` **You**

Still worth although I am sore I am really sorry if you are too\.


**005.** `10:42` **Meredith Lamb (+14169386001)**

>
I feel like that is my fault\. Sorry lol\. I am also\.

*💬 Reply*

**006.** `10:43` **Meredith Lamb (+14169386001)**

Mac uber eats eh king donuts for coffee\. Lol waiting


**007.** `10:43` **Meredith Lamb (+14169386001)**

\*dunkin


**008.** `10:43` **You**

Ok out of shower\.\.  feeling good\.\. hydrated electrolytes in me\.\. so much better now\.


**009.** `10:44` **You**

No way not
Your fault I wanted to drink with you I promised\.\. man of my word


**010.** `10:44` **You**

Fireball was yummy


**011.** `10:44` **You**

I will be having that again


**012.** `10:44` **Meredith Lamb (+14169386001)**

lol


**013.** `10:44` **Meredith Lamb (+14169386001)**

>
ChatGPT knows everything\. Will wait to see how this new reality unfolds…\.

*💬 Reply*

**014.** `10:45` **You**

Eesh lol


**015.** `10:45` **You**

Reaction: 😵‍💫 from Meredith Lamb
I think we are going to have to take reality by the face and make it unfold the way we want it to a little bit\.


**016.** `10:46` **You**

I had no coffee yesterday\.\. was very unsettling


**017.** `10:46` **You**

I will get some o\. Way to Chatham


**018.** `10:51` **You**

So you are here until what about 5 ish


**019.** `10:57` **Meredith Lamb (+14169386001)**

Yeah\. They play at 3 and again at 4\. So we will likely leave 5\.30\-6 unless the games are delayed


**020.** `10:57` **Meredith Lamb (+14169386001)**

She’s going to make me stop for stuff tho


**021.** `10:58` **You**

Yeah I don’t think you make the dinner


**022.** `10:58` **Meredith Lamb (+14169386001)**

\(Vape\)


**023.** `10:58` **You**

It’s fine if you don’t


**024.** `10:58` **You**

This is more important


**025.** `10:58` **Meredith Lamb (+14169386001)**

>
I’m ok with this\. Less awkward\.

*💬 Reply*

**026.** `10:58` **You**

lol I knew you would be


**027.** `10:58` **Meredith Lamb (+14169386001)**

😇


**028.** `10:59` **You**

Can you pop up before noon?  Just to relax for a few before I check out at noon?


**029.** `10:59` **You**

Or shit nm you have to pack


**030.** `10:59` **Meredith Lamb (+14169386001)**

I haven’t gotten out of bed yet\. Waiting for my coffee\. One min away


**031.** `11:00` **You**

ROFL all good either way I am just packing anyways


**032.** `11:01` **Meredith Lamb (+14169386001)**

Mac is mad I haven’t packed


**033.** `11:01` **Meredith Lamb (+14169386001)**

🙄


**034.** `11:01` **Meredith Lamb (+14169386001)**

Can’t without coffee\. She just went to front desk to get it if you want to meet her lol


**035.** `11:02` **You**

No that is ok


**036.** `11:02` **You**

lol


**037.** `11:11` **Meredith Lamb (+14169386001)**

If I can make the dinner I will go but I will keep you updated\.


**038.** `11:11` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I feel like my head has a lot to process today so maybe no dinner would be better lol\. We will see


**039.** `11:11` **You**

Seriously don’t worry about it\.\. people know you are here for volleyball I will tell them you messaged me that you wouldn’t be able to make it


**040.** `11:12` **You**

It’s no biggy\.


**041.** `11:12` **Meredith Lamb (+14169386001)**

Kk


**042.** `11:14` **You**

>
I get it I am kind of processing too\.\. all in a good way mind you\.

*💬 Reply*

**043.** `11:14` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**044.** `11:16` **You**

ROFL the dress


**045.** `11:16` **Meredith Lamb (+14169386001)**

Mackenzie goes “why would she wear that to meet the parents??”


**046.** `11:16` **You**

Heheh


**047.** `11:17` **You**

Good question


**048.** `11:17` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**049.** `11:18` **You**

I mean that could be a fair conclusion some moms might be like that


**050.** `11:18` **Meredith Lamb (+14169386001)**

Yeah it is but the dress didn’t help for sure lol


**051.** `11:19` **You**

No omg it screams “your son is hitting this, and can you imagine all of the shit I am teaching him”\. Feel free
To share that lol


**052.** `11:19` **Meredith Lamb (+14169386001)**

Haha


**053.** `11:19` **Meredith Lamb (+14169386001)**

No


**054.** `11:20` **Meredith Lamb (+14169386001)**

I told her she could be besties with the mom\. Prob same age


**055.** `11:20` **You**

ROFL


**056.** `11:21` **Meredith Lamb (+14169386001)**

k, some coffee consumed\. Time to get up and ready


**057.** `11:21` **You**

Cool have fun I am almost done


**058.** `11:53` **You**

Just got a slight extension beyond 12 I said I was almost done if I could get a bit more time\.\. I think they are busy now so they will pretty much say yes to anything


**059.** `11:54` **Meredith Lamb (+14169386001)**

We are waiting for a cart and then all set


**060.** `11:54` **Meredith Lamb (+14169386001)**

I’m feeling unwell lol


**061.** `11:54` **Meredith Lamb (+14169386001)**

Not sure about the day drinking and night drinking yday while sick on mounjaro


**062.** `11:54` **Meredith Lamb (+14169386001)**

Sighhhh lol


**063.** `11:55` **You**

Sry I feel like I contributed to the night drinking for sure


**064.** `11:55` **You**

And had you up too late


**065.** `11:55` **Meredith Lamb (+14169386001)**

We got an extension until the cart comes


**066.** `11:56` **Meredith Lamb (+14169386001)**

Omg the 3am nights at 47


**067.** `11:56` **You**

Yeah I know


**068.** `11:56` **Meredith Lamb (+14169386001)**

It’s fine\. I kind of got to sleep in


**069.** `11:56` **Meredith Lamb (+14169386001)**

Until Mac disrupted


**070.** `11:57` **You**

Reaction: ❤️ from Meredith Lamb
And still being able to do stuff at 3 am at 47\.\. happy\.


**071.** `11:57` **Meredith Lamb (+14169386001)**

Shit keeps getting realERRRR


**072.** `11:59` **You**

I very much enjoyed it\.  I was worried though I hope you were ok with what happened I thought you might ya know regret
In the morning\.


**073.** `12:01` **Meredith Lamb (+14169386001)**

No regrets but my prior concern remains lol


**074.** `12:01` **You**

Stating the for the record are you lol


**075.** `12:03` **You**

Keeping this also for the memory


**076.** `12:03` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**077.** `12:08` **Meredith Lamb (+14169386001)**

So Detroit is our place now


**078.** `12:08` **Meredith Lamb (+14169386001)**

lol


**079.** `12:09` **You**

I feel like it is yeah


**080.** `12:09` **You**

Good news for Lori\.


**081.** `12:19` **You**

Ok I am pretty
Much done about to head out assuming you still waiting on cart lol


**082.** `12:29` **You**

Ok here is the deal you might have left so this will be moot\.  But if Mac wants to see who I am I am taking my stuff down to the lobby I think there are places to sit down there\.\. I am going to find a spot and read my iPad for a few mins\.
Then leave\.


**083.** `12:42` **You**

You guys must be go a already


**084.** `12:48` **Meredith Lamb (+14169386001)**

Sorry yeah we left\! Lol Mac took me to the hood to a vape store


**085.** `12:50` **You**

ROFL ok well I wasn’t in a hurry anyways relaxing here reading emails


**086.** `12:50` **You**

Reaction: 😂 from Meredith Lamb
Might I make a suggestion


**087.** `12:52` **You**

For the vaping when I quite
It was using a fake vape or e cigarette no nicotine just the smoke and a nic patch it
Might work for her\.\. side effect she gains back a bit of healthy weight\.  I think like smoking vaping curbs your appetite S another side effect


**088.** `12:52` **You**

I know I gained 20 lbs when I wuit


**089.** `12:54` **You**

See now it feels weird


**090.** `12:55` **You**

Before I would have no problem making a suggestion re Mac\. lol now I am anxious\.\. what if I suggest the wrong thing etc\.\. heheh


**091.** `12:56` **You**

Ok heading to car getting I\. Road\.\. will check in on how your day is going\.


**092.** `13:24` **Meredith Lamb (+14169386001)**

At the venue and I get to sit around and wait until 3\. Forgot to bring my laptop in and we valeted parking god…\.


**093.** `13:24` **You**

That sucks… it’s ok I will work on it when I get to hotel I suspect I will be at hotel
Working before the game starts


**094.** `13:24` **You**

Super fun for you


**095.** `13:25` **Meredith Lamb (+14169386001)**

I’m going to have a nap lol


**096.** `13:25` **You**

Did you want anything at duty free shop getting gas and it is right here


**097.** `13:25` **Meredith Lamb (+14169386001)**

Nope all good\. No more drinking\.


**098.** `13:25` **Meredith Lamb (+14169386001)**

lol


**099.** `13:25` **Meredith Lamb (+14169386001)**

Gotta be good around Michelle


**100.** `13:29` **You**

Rofl


**101.** `13:29` **You**

Apparently I shouldn’t have invited her


**102.** `13:34` **Meredith Lamb (+14169386001)**

lol


**103.** `13:34` **Meredith Lamb (+14169386001)**

She’s scary


**104.** `13:53` **You**

Well that was a little expensive stopped in called j and the kids to see what they wanted spent 300 like how… I was just like going to get something small lol


**105.** `13:54` **You**

Next
Time not calling


**106.** `13:54` **Meredith Lamb (+14169386001)**

lol still under our target bill so you are fine lol


**107.** `13:54` **You**

Yeah that was
Silly rofl


**108.** `13:57` **You**

Thought you were napping


**109.** `13:58` **Meredith Lamb (+14169386001)**

Impossible here I think


**110.** `13:58` **Meredith Lamb (+14169386001)**

Also hungry but too lazy to go get something\. Going to soon


**111.** `14:00` **You**

Ur going to be in a good mood later


**112.** `14:00` **You**

lol


**113.** `14:01` **Meredith Lamb (+14169386001)**

There is never any time to nap\. That is the problem\. Just like a 20 min Power Nap


**114.** `14:02` **You**

That sucks… I don’t nap much since I had my apnea fixed


**115.** `14:02` **You**

But I used to like it


**116.** `14:04` **You**

I could take a nap right now though bit of a line to get into Canada


**117.** `14:09` **You**

Back in Canada\!\! The border guard had a Morgan wallen mustache \#jealous


**118.** `14:20` **Meredith Lamb (+14169386001)**

lol


**119.** `14:27` **You**

So they playing 3 games no matter what or do they need to win to advance


**120.** `14:27` **Meredith Lamb (+14169386001)**

2 games


**121.** `14:27` **Meredith Lamb (+14169386001)**

For sure


**122.** `14:32` **You**

How is your stomach


**123.** `14:32` **You**

Feeling ok or still really bad


**124.** `14:35` **Meredith Lamb (+14169386001)**

I ate some real nonkid grilled cheese food and having a smoothie so feeling better


**125.** `14:39` **Meredith Lamb (+14169386001)**

Stomach is ok \(not Perf\) but my head is messing with me 🤔


**126.** `14:43` **You**

What is wrong with your head


**127.** `14:47` **Meredith Lamb (+14169386001)**

It’s asking me so many things while also telling me so many things…\.


**128.** `14:47` **Meredith Lamb (+14169386001)**

It’s annoying me


**129.** `14:48` **You**

Like what…\.\.


**130.** `14:49` **You**

As a good friend of mine would say\.


**131.** `14:49` **Meredith Lamb (+14169386001)**

lol


**132.** `14:49` **You**

You are that you know\.


**133.** `14:49` **You**

I do see you that way


**134.** `14:49` **Meredith Lamb (+14169386001)**

You see me as a good friend


**135.** `14:49` **You**

In addition


**136.** `14:50` **Meredith Lamb (+14169386001)**

Or annoying


**137.** `14:50` **Meredith Lamb (+14169386001)**

lol


**138.** `14:50` **You**

No kk


**139.** `14:50` **You**

Not annoying


**140.** `14:50` **You**

I like seeing you as a friend as well as everything else


**141.** `14:51` **You**

So what is your head asking and telling


**142.** `14:53` **Meredith Lamb (+14169386001)**

Basic stuff: “What the f are you doing Meredith? Why are you so ocd about this? You aren’t focusing on your separation stuff\. You aren’t focusing on WORK\. Now you have gone and made things even MORE complicated\. Etc etc etc” \(it goes on and on and won’t stop\)


**143.** `14:54` **You**

I’m sorry mer\.\. I can back off if you want\.\. for a bit\. Let you focus
I would def do that for you\.


**144.** `14:55` **You**

I want to be part of making your life better not worse


**145.** `14:56` **Meredith Lamb (+14169386001)**

>
No, this is impossible at this point\.  But you realize after this weekend we probably won’t spend time together for so long\.

*💬 Reply*

**146.** `14:57` **Meredith Lamb (+14169386001)**

And you won’t be off at war\. You will literally be right in front of my face everyday\. Lol


**147.** `14:57` **You**



**148.** `14:58` **You**

Sec


**149.** `15:00` **You**

I mean I know that was why I wanted to try to spend as much time as I could with you these few days\.  And honestly it
Felt amazing\.\. it felt easy I was so much less self
Conscious around you everything for me was perfect\.\. I can focus on that as my motivation to get
Moving faster


**150.** `15:01` **You**

Like moving my separation along\.  Just
Got
To hotel\.


**151.** `15:02` **You**

Anyhow for me this weekend was amazing and I very
Much appreciated
The opportunity had we not
Taken it it
Would be that much longer


**152.** `15:03` **Meredith Lamb (+14169386001)**

Well I’m glad to read that\. That helps a bit\.


**153.** `15:03` **You**

Which part exactly lol


**154.** `15:03` **Meredith Lamb (+14169386001)**

All of it


**155.** `15:04` **You**

Anyhow think about what you need to get through this mer I will do whatever you want


**156.** `15:04` **Meredith Lamb (+14169386001)**

Will try to get out of my head a bit…


**157.** `15:05` **You**

Reaction: ❤️ from Meredith Lamb
We can talk later
Tonight if
You would
Like whatever I can do\.
Just
Going to check in and get
To my room


**158.** `15:05` **You**

Love you\.


**159.** `15:06` **Meredith Lamb (+14169386001)**

Love u too and want to see you again\. Gah\. Delayed here again\. Not started yet


**160.** `15:17` **You**

Ummmmmmm soooooooo


**161.** `15:17` **You**

I checked in


**162.** `15:17` **You**

Thankfully by myself


**163.** `15:17` **You**

Reaction: 😮 from Meredith Lamb
The girl read the notation in my file\.


**164.** `15:17` **You**

I was like Jesus


**165.** `15:17` **Meredith Lamb (+14169386001)**

So jealous you can nap


**166.** `15:17` **You**

lol


**167.** `15:17` **You**

You are literally next door


**168.** `15:18` **You**

At the end of a small hallway


**169.** `15:19` **You**

I think there are 2 rooms it could be but they suggested
You were next door lol so don’t check in when anyone else is around\. I just said in the vacinity of because we work
Together


**170.** `15:19` **You**

Not next door lol


**171.** `15:20` **Meredith Lamb (+14169386001)**

>
So this will be interesting with Mac

*💬 Reply*

**172.** `15:20` **You**

Ya think


**173.** `15:20` **You**

I am hiding in here for the full 2 days


**174.** `15:21` **Meredith Lamb (+14169386001)**

I mean all day meeting


**175.** `15:21` **Meredith Lamb (+14169386001)**

lol


**176.** `15:21` **You**

Eeesh


**177.** `15:21` **You**

Too sick
To come don’t want people
To catch\.\.


**178.** `15:21` **You**

Yeah going with that


**179.** `15:21` **Meredith Lamb (+14169386001)**

I think that should be me not you


**180.** `15:22` **Meredith Lamb (+14169386001)**

Omg warming up finally


**181.** `15:22` **You**

What should be on you


**182.** `15:23` **Meredith Lamb (+14169386001)**

I should be the sick one


**183.** `15:23` **You**

Well you still might be


**184.** `15:23` **You**

Who knows


**185.** `15:25` **Meredith Lamb (+14169386001)**

This meeting was such a great idea


**186.** `15:25` **You**

Sarcasm?


**187.** `15:26` **Meredith Lamb (+14169386001)**

lol yep


**188.** `15:26` **You**

I mean originally it
Gave me
The excuse
To go
To Detroit\.


**189.** `15:26` **You**

Me going to Detroit was your idea


**190.** `15:26` **You**

So technically so was the meeting\.


**191.** `15:26` **You**

😝


**192.** `15:27` **Meredith Lamb (+14169386001)**

I’m not sure all those dots connect\.


**193.** `15:27` **You**

I feel like they should


**194.** `15:27` **Meredith Lamb (+14169386001)**

You talked about the meeting before you knew about Detroit


**195.** `15:27` **You**

Not the date


**196.** `15:27` **Meredith Lamb (+14169386001)**

>
lol k, but they don’t

*💬 Reply*

**197.** `15:28` **You**

Maybe I was a little
Ambitious\.


**198.** `15:29` **Meredith Lamb (+14169386001)**

Can’t stay up until 3 tonight


**199.** `15:29` **Meredith Lamb (+14169386001)**

I will die tomorrow


**200.** `15:31` **You**

Reaction: 😂 from Meredith Lamb
How about 2:30


**201.** `15:31` **You**

Reaction: 👍 from Meredith Lamb
Maybe 1 would be better


**202.** `15:31` **You**

lol


**203.** `15:32` **Meredith Lamb (+14169386001)**

>
No

*💬 Reply*

**204.** `15:32` **You**

1 is good we can watch a few episodes of wrexham\.


**205.** `15:33` **Meredith Lamb (+14169386001)**

We have been watching movies and tv so well together


**206.** `15:33` **You**

I know but there is a couch here


**207.** `15:33` **You**

Easier to behave perhaps?


**208.** `15:34` **You**

Or……


**209.** `15:34` **You**

lol


**210.** `15:35` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
We’ll see … if this game ever freaking starts and I get out of here


**211.** `16:06` **You**

How is game


**212.** `16:11` **You**

Also random question would you ever consider moving back to Chatham someday?


**213.** `16:14` **Meredith Lamb (+14169386001)**

Lost first one\. Warming up now for second


**214.** `16:14` **Meredith Lamb (+14169386001)**

>
I never lived in Chatham

*💬 Reply*

**215.** `16:14` **Meredith Lamb (+14169386001)**

I just worked there


**216.** `16:16` **You**

I like it here


**217.** `16:17` **Meredith Lamb (+14169386001)**

Are you not just in the hotel? Lol


**218.** `16:17` **You**

Nope


**219.** `16:17` **You**

I went to Best Buy


**220.** `16:17` **You**

And then I need a snack before supper


**221.** `16:18` **You**

Because damn I am hungry


**222.** `16:20` **Meredith Lamb (+14169386001)**

Ahhh Chatham is OK


**223.** `16:20` **Meredith Lamb (+14169386001)**

Not sure I’d ever live in Chatham\. A bunch of better places


**224.** `16:20` **You**

I guess anything but Toronto\.\.  I just thought I could work out of Chatham


**225.** `16:21` **Meredith Lamb (+14169386001)**

Better places within driving distance


**226.** `16:21` **You**

I mean if j went back to Moncton\. I would think of transferring to Chatham


**227.** `16:21` **You**

Would be much easier for me to afford


**228.** `16:22` **You**

Eventually


**229.** `16:22` **Meredith Lamb (+14169386001)**

Or you could just move in with me


**230.** `16:22` **You**

Yeah I could do that\.


**231.** `16:22` **Meredith Lamb (+14169386001)**

🙂


**232.** `16:22` **You**

Still I don’t think your kids or Andrew would be happy


**233.** `16:22` **You**

lol


**234.** `16:23` **Meredith Lamb (+14169386001)**

Andrew doesn’t have a say\. My kids would be fine


**235.** `16:24` **Meredith Lamb (+14169386001)**

Besides I wouldn’t tell Andrew lol


**236.** `16:24` **You**

Well I would want everything absolutely rock solid and finalized with J so it would be a little ways out and would need another job at
Enbridge\.


**237.** `16:24` **You**

But yeah like I said


**238.** `16:24` **You**

It felt so easy with you\.\. I don’t think that changes


**239.** `16:25` **You**

We aren’t putting in airs for each other we are mid 40s we take each other as we are


**240.** `16:25` **Meredith Lamb (+14169386001)**

Why did you think it would feel different?


**241.** `16:25` **You**

I didn’t know what to expect\.\. I hadn’t spent time like that with anyone else in 25 years\.


**242.** `16:26` **You**

I figured it would be good if for no other reason than I know what you are like at work


**243.** `16:27` **Meredith Lamb (+14169386001)**

But you didn’t think it would feel “easy”?


**244.** `16:28` **You**

I didn’t know I don’t want to disappoint you\.\. I have my idiosyncratic ways\. So lol I just
Didnt assume


**245.** `16:28` **You**

I figured I would be the one to annoy you not the other way around


**246.** `16:29` **Meredith Lamb (+14169386001)**

If I thought you were annoying in any way we would not be talking right now lol trust me


**247.** `16:31` **You**

See that is scary lol you don’t see it though\.  The way I read that is \- if I were to find something about you annoying……
Fill in blank\. lol\. Your mind does it’s wacky things mine does my own foolishness


**248.** `16:32` **Meredith Lamb (+14169386001)**

Fill in the blank?


**249.** `16:32` **Meredith Lamb (+14169386001)**

Huh? Like you think I would hide it if I was annoyed by you?


**250.** `16:32` **Meredith Lamb (+14169386001)**

I’m not at that stage in my life


**251.** `16:33` **You**

O but you could


**252.** `16:33` **You**

In the future


**253.** `16:33` **You**

Find something annoying


**254.** `16:33` **Meredith Lamb (+14169386001)**

Oh I’m sure I will at some point


**255.** `16:33` **Meredith Lamb (+14169386001)**

But it will be minor


**256.** `16:33` **Meredith Lamb (+14169386001)**

Relative to who you are generally and who I am in love with


**257.** `16:34` **You**

I haven’t tired to be someone I am not with you so there is that


**258.** `16:36` **Meredith Lamb (+14169386001)**

I’ve known you for a while now\. Pretty confident in my feelings


**259.** `16:36` **You**

Kk well it did feel good
And easy and i would love to live with you when we sort our shit out\.


**260.** `16:37` **Meredith Lamb (+14169386001)**

2 years


**261.** `16:37` **Meredith Lamb (+14169386001)**

😜


**262.** `16:38` **You**

Reaction: ❤️ from Meredith Lamb
Mmmm maybe a little sooner but 1 for sure


**263.** `16:41` **Meredith Lamb (+14169386001)**

Would never guessed 2 months ago that you would be saying that lol


**264.** `16:41` **Meredith Lamb (+14169386001)**

How things change


**265.** `16:42` **You**

Nope


**266.** `16:42` **You**

But this isn’t normal


**267.** `16:42` **You**

This is the exception


**268.** `16:42` **You**

Like way out there


**269.** `16:46` **You**

I mean that is why it is special I have never
Heard of
This happening to anyone else\. Everything had to happen just as it did for this to work out the way it did\.  As I have said before I feel incredibly lucky\.


**270.** `16:46` **You**

How are
Girls doing winning or losing?


**271.** `16:46` **Meredith Lamb (+14169386001)**

Just won first set of second game


**272.** `16:47` **Meredith Lamb (+14169386001)**

Marlowe’s team in Ottawa won their first game today


**273.** `16:47` **Meredith Lamb (+14169386001)**

Ugh I’m so ready to leave\.


**274.** `16:47` **You**

Nice


**275.** `16:47` **You**

lol I bet you are


**276.** `16:48` **Meredith Lamb (+14169386001)**

Got my hair clipped by a random lol

*📎 1 attachment(s)*

**277.** `16:56` **You**

Rofl


**278.** `16:56` **You**

That is awesome


**279.** `16:57` **Meredith Lamb (+14169386001)**

Marlowe loves them\. The younger kids do it a lot


**280.** `16:57` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**281.** `16:57` **Meredith Lamb (+14169386001)**

Marlowe just sent me hers so far lol


**282.** `16:59` **Meredith Lamb (+14169386001)**

https://youtube\.com/watch?v=tCM44SrLC5A&feature=shared


**283.** `17:00` **Meredith Lamb (+14169386001)**

https://youtube\.com/watch?v=stNHqsxzqzo&feature=shared


**284.** `17:03` **Meredith Lamb (+14169386001)**

I just thought of something\. This is probably the last volleyball game I will watch Mac play ever\.


**285.** `17:08` **Meredith Lamb (+14169386001)**

Omg going to third set\.


**286.** `17:14` **You**

I was going to say something g to you earlier about enjoying what is right in front of you\.  I felt same way\.\. it
Drove me crazy running all over the fucking place for basketball but I missed it when it was gone


**287.** `17:14` **You**

It’s a connection you and Mac have\.\.


**288.** `17:14` **You**

Watching the video
You sent


**289.** `17:15` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I got a good photo of her on her last game I will see

*📎 1 attachment(s)*

**290.** `17:16` **You**

>
It might not be you never know

*💬 Reply*

**291.** `17:17` **You**

You should write a blog about it


**292.** `17:17` **You**

Maybe getting back into that would help deal with some shit


**293.** `17:22` **Meredith Lamb (+14169386001)**

Errrr no\.


**294.** `17:22` **Meredith Lamb (+14169386001)**

lol


**295.** `17:22` **Meredith Lamb (+14169386001)**

I don’t need another distraction


**296.** `17:23` **You**

Well store up your shit and let it out later\.\. you need some kind of release mer you are carrying a lot\.


**297.** `17:26` **Meredith Lamb (+14169386001)**

Ok they finally won a game lol


**298.** `17:26` **Meredith Lamb (+14169386001)**

Ridiculous tournament


**299.** `17:26` **Meredith Lamb (+14169386001)**

I get to leave now 🎉🎉🎉🎉🎉


**300.** `17:36` **You**

Yay I mean remember do not check in with anyone from the team around\. Lol


**301.** `17:36` **You**

If you don’t see anyone should I tell them you couldn’t come?


**302.** `17:46` **Meredith Lamb (+14169386001)**

Omg tire pressure was low\. Like can this day end already lol

*📎 1 attachment(s)*

**303.** `17:46` **Meredith Lamb (+14169386001)**

>
Huh?

*💬 Reply*

**304.** `17:47` **You**

I am asking if you are coming to dinner\.


**305.** `17:47` **You**

Man that sucks about tires


**306.** `17:49` **Meredith Lamb (+14169386001)**

>
I will let you know in an hour

*💬 Reply*

**307.** `17:49` **Meredith Lamb (+14169386001)**

Dinner is 8 right


**308.** `17:50` **Meredith Lamb (+14169386001)**

Shouldn’t I get ready for tomorrow lol


**309.** `17:51` **You**

I would be supportive of that\.


**310.** `17:51` **You**

lol


**311.** `17:51` **You**

Your call though


**312.** `17:52` **You**

>
Pinging this again last time\.\. lol\.\. careful right

*💬 Reply*

**313.** `18:02` **Meredith Lamb (+14169386001)**

>
Thanks\. Like wtf\. What do I do if someone is there\. Geeeez

*💬 Reply*

**314.** `18:05` **You**

Um I feel like you will be creative\.


**315.** `18:17` **Meredith Lamb (+14169386001)**

Border is so slow\. Dinner looking unlikely


**316.** `18:26` **You**

Yeah I totally feel you


**317.** `18:45` **You**

How goes the progress


**318.** `18:45` **You**

I think everyone is going to arrive at the same time I bet


**319.** `18:52` **Meredith Lamb (+14169386001)**

Will arrive at 7\.20


**320.** `18:53` **You**

Ah ok well I will still be in my room working away


**321.** `18:53` **You**

I left the bolt on my door over if you wanted to say hello\.


**322.** `19:06` **Meredith Lamb (+14169386001)**

Stopping for gas and caffeine


**323.** `19:08` **You**

Cote going to be late 8:20 going straight to restaurant


**324.** `19:08` **You**

Carolyn and Louise
Already here


**325.** `19:08` **Meredith Lamb (+14169386001)**

I will go to dinner if I can have one glass of wine


**326.** `19:08` **You**

Not sure about rest I tried calling Deanna and Sarah they might be caught I\. Traffic as well


**327.** `19:08` **Meredith Lamb (+14169386001)**

lol


**328.** `19:09` **You**

Rofl you can have many glasses
Of wine


**329.** `19:09` **Meredith Lamb (+14169386001)**

No


**330.** `19:09` **You**

And I will sit far away from you


**331.** `19:09` **Meredith Lamb (+14169386001)**

Absolutely not


**332.** `19:09` **You**

And ignore you


**333.** `19:09` **You**

There is a corkscrew in my kitchen ete


**334.** `19:09` **You**

lol


**335.** `19:10` **You**

I think I have a taste for Pinot now\.


**336.** `19:10` **You**

Uh oh


**337.** `19:11` **Meredith Lamb (+14169386001)**

No drinking tonight


**338.** `19:11` **Meredith Lamb (+14169386001)**

What restaurant again?


**339.** `19:12` **You**

Mamma marias


**340.** `19:13` **You**

Shots?


**341.** `19:13` **You**

Fireball\!\!


**342.** `19:13` **Meredith Lamb (+14169386001)**

>
Are you sure?

*💬 Reply*

**343.** `19:13` **You**

I am sure


**344.** `19:13` **Meredith Lamb (+14169386001)**

I thought it closed early


**345.** `19:13` **You**

Nope cote booked it


**346.** `19:13` **You**

But as I said she called me and is going to be quite late


**347.** `19:24` **You**

You getting close… was just going to run down to desk to get some more coffee\.\. just making sure lol


**348.** `19:24` **You**

Like to avoid lol


**349.** `19:26` **You**

I have a balcony\!\! Awesome


**350.** `19:33` **You**

Made the dash I am all stocked up


**351.** `19:39` **You**

I see you


**352.** `22:06` **You**

Not sure if and or you planned on coming over but I just need 15
Minutes if so have to call Gracie\.


**353.** `22:09` **Meredith Lamb (+14169386001)**

I’m having a shower and getting my laptop on\. :p Just let me know\.


**354.** `22:10` **Meredith Lamb (+14169386001)**

I will come\. I know where Carolyn’s room is so should be fine


**355.** `22:11` **You**

Ok listen I am going to grab a quick shower too I will leave the bolt Orr so you can just come in whenever


**356.** `22:12` **Meredith Lamb (+14169386001)**

Marlowe’s team went 3\-0 today\. Just learned


**357.** `22:13` **You**

Nice good for her\!\!


**358.** `22:38` **You**

I am out


**359.** `22:39` **Meredith Lamb (+14169386001)**

What is the room number again


**360.** `22:39` **Meredith Lamb (+14169386001)**

Be weird if I went to the wrong room


**361.** `22:39` **You**

206


**362.** `22:40` **You**

Thought you were 205


**363.** `22:41` **Meredith Lamb (+14169386001)**

No 203


**364.** `22:41` **You**

Is Carolyn 205


**365.** `22:41` **You**

lol


**366.** `22:42` **Meredith Lamb (+14169386001)**

Um yes


