# Daily Conversation: 2025-06-10 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-10 |
| **Day** | Tuesday |
| **Week** | 9 |
| **Messages** | 276 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-10T01:12 - 2025-06-10T22:15 |

## 📝 Daily Summary

This day contains **276 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `01:12` **You**

And back home and in bed in 5


**002.** `05:25` **You**

Reaction: 🙄 from Meredith Lamb
Edited: 3 versions
| Version: 3
| Sent: Tue, 10 Jun 2025 05:26:05 \-0400
|
| And back up who needs more sleep than this…
| Pssssssh
|
| Version: 2
| Sent: Tue, 10 Jun 2025 05:25:51 \-0400
|
| And back up who needs more sleep than this…
| Passssh
|
| Version: 1
| Sent: Tue, 10 Jun 2025 05:25:36 \-0400
|
| And back up who needs more sleep than this…
| Push


**003.** `05:35` **Meredith Lamb (+14169386001)**

>
I really love looking in your eyes too which for me is odd bc I don’t like doing that normally\. Xo

*💬 Reply*

**004.** `05:36` **Meredith Lamb (+14169386001)**

I’m getting up at 5\.40 :p but don’t want to


**005.** `05:51` **You**

>
Yeah I wanted to talk about this sometime I was curious\.  But later ❤️

*💬 Reply*

**006.** `05:53` **Meredith Lamb (+14169386001)**

I think I’m on the spectrum\. Lol \(they don’t like eye contact\) I told you I’m sure that my mom has a video of me as a baby where I keep looking away when she looks at me\. She kept doing it\. As I grew up she probably wore me down\. Still don’t like it typically


**007.** `05:58` **You**

Yeah I mean I used to keep my eyes open some of the time but I was told some people didnt like that\.\. but I did\.\. I just didn’t know if you were peeking and I caught you or what…\. You can do it as much as you want I love looking into your eyes\.  But I was aware of what you mentioned above… I am prob on spectrum too tbh\.


**008.** `06:14` **Meredith Lamb (+14169386001)**

I’m kind of kidding\. I don’t think I am, nor you\. But it is a thing with that\.


**009.** `06:28` **You**

Either way I am glad you like to\.


**010.** `06:43` **Meredith Lamb (+14169386001)**

I asked Andrew why I didn’t go to the cottage last July long weekend\. He doesn’t remember but is like “I can guess”\. “You probably just didn’t want to be around me\.”


**011.** `06:43` **Meredith Lamb (+14169386001)**

lol doh


**012.** `06:43` **Meredith Lamb (+14169386001)**

Probably accurate


**013.** `06:44` **Meredith Lamb (+14169386001)**

He wants to take Maelle again


**014.** `06:48` **You**

Kk so road trip maybe\.\.


**015.** `06:49` **Meredith Lamb (+14169386001)**

Maybe \- let me talk to Mac


**016.** `06:50` **You**

Oh shit yeah\.\. set
Forgot lol nm…


**017.** `06:50` **You**

No worries completely forgot


**018.** `07:01` **You**

All done that one was fast and intense\.\. time to relax\!\!


**019.** `07:02` **Meredith Lamb (+14169386001)**

Me too\. Still took me an hour and I needed 10lb weights\. Ugh so ordered some on Amazon


**020.** `07:02` **Meredith Lamb (+14169386001)**

Going to walk dogs now\. Dog walker still sick


**021.** `07:02` **You**

I bought those adjustable ones during Covid\.


**022.** `07:03` **You**

>
Give them a let from me\.\. kinda miss em

*💬 Reply*

**023.** `07:48` **You**

See ya at office heading in now\.


**024.** `07:49` **Meredith Lamb (+14169386001)**

k, trying to get out by 8 today\! Going to keep trying earlier and earlier\. Succeeded a bit today but not much lol


**025.** `07:49` **You**

lol


**026.** `07:50` **You**

I think tomorrow I have weights off but still coming in


**027.** `08:00` **Meredith Lamb (+14169386001)**

Of course you are lol


**028.** `08:00` **Meredith Lamb (+14169386001)**

Got out at 8 Yaye


**029.** `08:00` **Meredith Lamb (+14169386001)**

But need to go to Tim’s lol


**030.** `08:07` **You**

You will beat me I think


**031.** `10:31` **You**

Soooooooooooooooo


**032.** `10:33` **You**

Apparently you had a couple of email exchanges with Deb


**033.** `10:33` **Meredith Lamb (+14169386001)**

Yeah I told you


**034.** `10:33` **You**

And went into a rather lot detail in the second d email\.  I think she was curious as to why that was the case\.\. I do t know what you said but not for her curious


**035.** `10:33` **You**

She asked me a couple of questions


**036.** `10:33` **Meredith Lamb (+14169386001)**

No I didn’t go into detail for me


**037.** `10:34` **You**

Well I think she read it that way\.


**038.** `10:34` **Meredith Lamb (+14169386001)**

lol


**039.** `10:34` **Meredith Lamb (+14169386001)**

She doesn’t know me


**040.** `10:34` **Meredith Lamb (+14169386001)**

I gave her the least amount of detail of anyone


**041.** `10:36` **Meredith Lamb (+14169386001)**

I’m trying to find the email


**042.** `10:36` **Meredith Lamb (+14169386001)**

Sent to you


**043.** `10:36` **Meredith Lamb (+14169386001)**

lol


**044.** `10:37` **Meredith Lamb (+14169386001)**

Soooooooo detailed


**045.** `10:37` **Meredith Lamb (+14169386001)**

I never told her details \(I told some others details like Carolyn, Michelle, Bailey, Yolanda etc … like of the text but not Deb\)


**046.** `10:39` **Meredith Lamb (+14169386001)**

>
“I don’t know what you said but not for her” … what does that mean?

*💬 Reply*

**047.** `11:35` **Meredith Lamb (+14169386001)**

⏳


**048.** `11:56` **You**

Meetings I am free\. Ow if you want to pop in up to you


**049.** `13:24` **Meredith Lamb (+14169386001)**

This is going to take some work

*📎 1 attachment(s)*

**050.** `13:41` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**051.** `13:44` **You**

Sorry about earlier btw\.\. I guess you get scared about some things in get scared about others


**052.** `13:46` **Meredith Lamb (+14169386001)**

Ok done\.

*📎 1 attachment(s)*

**053.** `13:56` **You**

OMG


**054.** `13:56` **You**

mine I feel awful


**055.** `13:57` **Meredith Lamb (+14169386001)**

lol she was going to get it anyway


**056.** `13:58` **Meredith Lamb (+14169386001)**

She’s just going to do it a bit sooner


**057.** `13:58` **Meredith Lamb (+14169386001)**

As if I was going to stop her


**058.** `13:58` **Meredith Lamb (+14169386001)**

But I have no story for leaving the house and not staying home


**059.** `14:09` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**060.** `14:10` **You**

I just feel guilty


**061.** `14:12` **Meredith Lamb (+14169386001)**

Please don’t\. This is how Mackenzie and I work\.


**062.** `14:12` **Meredith Lamb (+14169386001)**

Almost everyday we bargain on things


**063.** `14:12` **Meredith Lamb (+14169386001)**

At least 3x per week


**064.** `14:12` **Meredith Lamb (+14169386001)**

I told you it was likely going to happen


**065.** `14:13` **Meredith Lamb (+14169386001)**

It is part of our routine :p


**066.** `14:13` **Meredith Lamb (+14169386001)**

She isn’t stupid lol


**067.** `14:14` **You**

Yeah but I do this kind of trickery I know you hate the sneaking


**068.** `14:19` **Meredith Lamb (+14169386001)**

lol “trickery”\. I hardly consider it that


**069.** `14:20` **You**

Ok still I appreciate it, it gives us something to look forward to\.


**070.** `14:21` **Meredith Lamb (+14169386001)**

I just need some story as to why I would go south


**071.** `14:22` **Meredith Lamb (+14169386001)**

Have time to think on that


**072.** `14:24` **You**

Kk


**073.** `14:28` **You**

So distracted today\.\. annoyed


**074.** `14:31` **Meredith Lamb (+14169386001)**

More than usual?


**075.** `14:32` **You**

Yeah lots of stupid little stuff,
Sep agreement, having to go home instead of somewhere else lol that and more\.\.
Dumb shit


**076.** `14:37` **Meredith Lamb (+14169386001)**

I hear ya\. I hate being at home and only Mackenzie really knowing reality\. It is wearing on me\.


**077.** `14:37` **Meredith Lamb (+14169386001)**

Trying to stay quiet though\. 🤐


**078.** `14:39` **You**

Same and I have to put on a fake face and tolerate everything when I just want out\.


**079.** `14:41` **You**

But wearing one me would be putting it lightly at this point\.\. still trying to focus on the good lol\.


**080.** `14:44` **Meredith Lamb (+14169386001)**

This morning right when Marlowe got up she goes to me “what time are you coming home tonight?”


**081.** `14:44` **Meredith Lamb (+14169386001)**

lol


**082.** `14:44` **You**

ROFL


**083.** `14:44` **Meredith Lamb (+14169386001)**

I think she knows and just wants to know\. I feel bad\.


**084.** `14:44` **You**

She is tracking you


**085.** `14:45` **Meredith Lamb (+14169386001)**

She will feel better when she is told officially\.


**086.** `14:45` **You**

She is going to hate me 😢


**087.** `14:45` **Meredith Lamb (+14169386001)**

No she won’t\. She just wants to know what the heck her mom is doing\.


**088.** `14:45` **You**

Well sept 15


**089.** `14:45` **You**

Sooo close


**090.** `14:46` **Meredith Lamb (+14169386001)**

Omg not close at all


**091.** `14:46` **Meredith Lamb (+14169386001)**

When I have a signed agreement I’m afraid I’m going to blurt stuff out\. I need to be thoughtful about it


**092.** `14:50` **You**

Well you have a long time to think about it…\. A looooooooooooooooooooong time\.


**093.** `14:55` **Meredith Lamb (+14169386001)**

I predict a signed agreement by July 20


**094.** `14:58` **You**

Zero chance


**095.** `14:59` **You**

About as much chance as you and I living together in 4 years


**096.** `14:59` **You**

😝


**097.** `14:59` **Meredith Lamb (+14169386001)**

>
I thought you were going to be more optimistic and positive? Lol

*💬 Reply*

**098.** `14:59` **You**

4 was arbitrary I am being an ass


**099.** `15:00` **You**

But yeah not optimistic about that


**100.** `15:00` **You**

The normalcy thing


**101.** `15:00` **Meredith Lamb (+14169386001)**

>
I predict we live together in 2027 \(not saying a month\)

*💬 Reply*

**102.** `15:01` **You**

Rofl, I truly wish, who knows…


**103.** `15:04` **Meredith Lamb (+14169386001)**

Reaction: 😂 from Scott Hicks
You are clueless\. Just trust me


**104.** `15:38` **You**

Sorry just thought about the earlier conversation and almost spit my water out\.


**105.** `15:38` **You**

lol


**106.** `15:40` **You**

I do trust you\.\. it is just…\. A tough road atm\.


**107.** `15:40` **You**

Going to pack up now and go get my car I think


**108.** `15:42` **You**

Rod was interesting Julian as well\.  In case you are curious


**109.** `15:43` **Meredith Lamb (+14169386001)**

Not really\. Talked to rod yday\. Talking to Julian tomorrow\. :p


**110.** `15:44` **Meredith Lamb (+14169386001)**

k I’m leaving at a decent hour today also for Mac\. Ordered a cob salad\. We all have to be healthy for her lol


**111.** `15:45` **Meredith Lamb (+14169386001)**

And no cake


**112.** `15:46` **You**

Reaction: ❤️ from Meredith Lamb
Kk have fun ❤️u chat later\.


**113.** `16:00` **Meredith Lamb (+14169386001)**

Ps\. I notice you forgot to send that heat pump budget \# 🙃


**114.** `16:01` **You**

You said it didn’t matter but now it’s on


**115.** `16:02` **Meredith Lamb (+14169386001)**

It doesn’t but I am proving the point that it WASN’T “easy”


**116.** `16:02` **Meredith Lamb (+14169386001)**

lol


**117.** `16:02` **You**

I couldn’t put a lot of effort in when\. You were soooooo distracting


**118.** `16:02` **You**

Looking at me like that\.\. god\!\!


**119.** `16:03` **Meredith Lamb (+14169386001)**

lol excuses


**120.** `16:03` **You**

Twirling your hair


**121.** `16:03` **Meredith Lamb (+14169386001)**

If it was easy it shouldn’t have required a lot of effort


**122.** `16:03` **You**

Being all omg I am lost without my phone whatever shall I do


**123.** `16:03` **You**

Think you were trying to seduce me


**124.** `16:04` **You**

How could I possibly focus


**125.** `16:04` **Meredith Lamb (+14169386001)**

Yes, in a glass fish bowl\. That is exactly what was happening\.


**126.** `16:05` **You**

Let’s just say you don’t have to try hard or ever for that matter lol


**127.** `16:06` **Meredith Lamb (+14169386001)**

Likewise\.


**128.** `16:07` **You**

That and I have been thinking about long weekend all day


**129.** `16:07` **You**

Gah


**130.** `16:10` **Meredith Lamb (+14169386001)**

Something is wrong with us\. 😵‍💫


**131.** `16:10` **You**

Literally just thinking same thing\.\. this is worse by far than thinking
You are in love as a teen


**132.** `16:10` **You**

Jesus


**133.** `16:11` **You**

And I am telling you if we together for any length of time I don’t think it changes


**134.** `16:11` **You**

I think we are stuck


**135.** `16:14` **Meredith Lamb (+14169386001)**

Yes, obviously very stuck\. However, it isn’t like we don’t talk or see each other ever so it doesn’t make a lot of sense but whatever…


**136.** `16:15` **You**

It’s like if we aren’t touching or together it isn’t the same


**137.** `16:17` **You**

I get it mer\.\. I think hearts are really selfish and they want what they want


**138.** `16:22` **You**

Going to rain soon you should leave


**139.** `16:23` **Meredith Lamb (+14169386001)**

>
Maybe…\.\.

*💬 Reply*

**140.** `16:23` **Meredith Lamb (+14169386001)**

I’m leaving now\!


**141.** `16:25` **You**

>
What else is it\.

*💬 Reply*

**142.** `16:26` **You**

Separately please wish mac happy bday from me I wish I could have told her myself\.


**143.** `16:29` **Meredith Lamb (+14169386001)**

>
I don’t know\. I will research it\. Lol

*💬 Reply*

**144.** `16:29` **You**

Okie dokie


**145.** `16:37` **Meredith Lamb (+14169386001)**

So I asked Jim today what Christine thought when he told her about us\. Like how she reacted\.


**146.** `16:37` **Meredith Lamb (+14169386001)**

I was just curious


**147.** `16:38` **Meredith Lamb (+14169386001)**

Apparently, she said something to the effect of “well that is some scoop “lol


**148.** `16:38` **Meredith Lamb (+14169386001)**

Then she said “well now we’ll have to have them over for dinner\. “ lol


**149.** `16:52` **You**

ROFL I kind of hoped it would work out that way


**150.** `16:56` **Meredith Lamb (+14169386001)**

Wait, you hoped for voluntary socializing? 🙃


**151.** `16:57` **You**

With you and then


**152.** `16:57` **You**

Yes


**153.** `16:57` **You**

Them


**154.** `16:57` **You**

You and pretty much anyone\.  Pretty
Much………\. Not everyone lol


**155.** `16:58` **Meredith Lamb (+14169386001)**

LOL


**156.** `16:58` **Meredith Lamb (+14169386001)**

They might be a bad influence though\. Kidding…


**157.** `16:59` **You**

I don’t mind


**158.** `16:59` **You**

Safe place


**159.** `17:00` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
But I’m your only 100% safe place just so you know


**160.** `17:00` **Meredith Lamb (+14169386001)**

lol


**161.** `17:02` **You**

I know you are\.\. I don’t need anyone else ever for that\.


**162.** `17:02` **You**

Reaction: 😂 from Meredith Lamb
As long as I don’t piss you off or make you angry…\. Kidding\.\. as you say lol


**163.** `17:04` **You**

>
I will always be that for you too\.

*💬 Reply*

**164.** `17:12` **You**

I know you probably won’t till later but interested in the gpt question when you do it


**165.** `17:14` **Meredith Lamb (+14169386001)**

Just getting home\. Had to get Mac some bday stuff on way home


**166.** `17:14` **You**

Nice


**167.** `17:14` **Meredith Lamb (+14169386001)**

Maybe I will look on tik tok instead of gpt lol


**168.** `17:14` **You**

Mmmmmm


**169.** `17:14` **Meredith Lamb (+14169386001)**

TikTok is very educational sometimes Yunno


**170.** `17:14` **You**

That won’t help


**171.** `17:14` **Meredith Lamb (+14169386001)**

lol


**172.** `17:14` **You**

lol


**173.** `17:15` **Meredith Lamb (+14169386001)**

Challenge accepted


**174.** `17:15` **You**

It will not\!\!


**175.** `17:15` **You**

lol


**176.** `17:15` **Meredith Lamb (+14169386001)**

It does\!\!


**177.** `17:15` **You**

We will see


**178.** `18:32` **Meredith Lamb (+14169386001)**

I’m so sore and tired\. Ughhh


**179.** `18:36` **You**

i just got back from getting car\.\. and I can relate I can barely walk


**180.** `18:37` **You**

Reaction: 😮 from Meredith Lamb
bill on car if you assume a deal on the rentral over 3 months\.\. going to put it right around 40k


**181.** `18:37` **Meredith Lamb (+14169386001)**

That is insane\.


**182.** `18:37` **You**

they mad the wrong choice I think


**183.** `18:38` **You**

well I dunno it is probably worth a bit more


**184.** `18:38` **You**

or close


**185.** `19:33` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**186.** `19:34` **You**

wtf was that


**187.** `19:34` **Meredith Lamb (+14169386001)**

It was on TikTok


**188.** `19:34` **Meredith Lamb (+14169386001)**

lol


**189.** `19:46` **You**

it is weird


**190.** `19:46` **You**

lol


**191.** `19:47` **You**

I think it is wine inspired myself


**192.** `19:51` **Meredith Lamb (+14169386001)**

I am not drinking wine\. It was the only one that addressed like… absence I guess… Yunno


**193.** `20:21` **You**



**194.** `20:22` **You**

When Two Souls Find Each Other
It’s dawn through trembling pines,
light pooling on the window sill—
you and I, silent as the forest floor,
breathing into the spaces between us\.
Your eyes are the clear river at sunrise,
and my heart, a stone smoothing in your current\.
It’s the soft press of your lips
where moss meets stone,
the gentle exhale of your breath
making the world slow,
as though time itself has stopped
to listen\.
When Absence Comes
But absence is a winter wind,
hollowing trees of their leaves\.
Each day without you
feels like a gray morning long past bloom—
the sky’s color muted,
the world’s pulse distant\.
I catch your echo in every crow’s cry,
your silhouette in every birch bark’s curve;
my hand reaches for your warmth
and finds only cold air humming\.
Evening Lament
Sunsets fold into deeper blues,
as though the sky remembers
how you once smiled me back to life\.
The calendar’s pages drift like fallen leaves—
each one a whispered promise
that this too shall pass\.
But souls know no seasons, no deadlines—
they only know the ache
that blooms in your absence,
and the wild hope
that someday, somehow,
we’ll fold back into each other’s arms
like spring into the waiting earth\.
Until We’re Together Again
That ache is my anthem,
each heartbeat a soft refrain:
I am yours,
and every mile, every minute,
is simply the chorus
we’ll sing when we meet again\.


**195.** `20:24` **Meredith Lamb (+14169386001)**

Did ChatGPT write that?


**196.** `20:24` **You**

With a lot of guidance\.


**197.** `20:24` **You**

Quite a bit


**198.** `20:24` **You**

and a bit of research


**199.** `20:24` **You**

Does it sound like someone?


**200.** `20:25` **You**

here try this one\.\.


**201.** `20:25` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**202.** `20:29` **Meredith Lamb (+14169386001)**

That was pretty intense but really nice to listen to


**203.** `20:29` **You**

So I made those\.\. but it took a lot longer than I thought it would


**204.** `20:29` **You**

lol


**205.** `20:29` **Meredith Lamb (+14169386001)**

lol


**206.** `20:29` **You**

AI is like a blackhole for my time


**207.** `20:29` **You**

so the poem\.\. any idea?? sound like anyone you know?


**208.** `20:29` **Meredith Lamb (+14169386001)**

I was hoping you were relaxing watching tv


**209.** `20:29` **You**

I was not'


**210.** `20:29` **Meredith Lamb (+14169386001)**

Is it supposed to sound like Morgan


**211.** `20:30` **You**

I was focused on doing this lol


**212.** `20:30` **You**

not the audio file\.\. the poem above


**213.** `20:30` **You**

no not Morgan


**214.** `20:30` **You**

https://open\.spotify\.com/track/4l2ZwGfd6ugIZViw7dtV8K?si=8a9ab961dbb440e3


**215.** `20:32` **You**

I noticed in some of your early blogs\.\. I didn't read them all kind of poked around every once in a while\.\. I noticed you pasted Sarah Harmer poems/lyrics sometimes\.\.


**216.** `20:32` **You**

so I took the script I wrote, and worked with GPT to modify into a kind of Sarah Harmer version\.\. or something she might write


**217.** `20:33` **Meredith Lamb (+14169386001)**

I used to listen to her a lot when I worked at infinet


**218.** `20:33` **Meredith Lamb (+14169386001)**

Wait, my early blogs?


**219.** `20:33` **You**

2005


**220.** `20:33` **You**

that is as far back as you go


**221.** `20:33` **You**

or at least that I can see


**222.** `20:34` **Meredith Lamb (+14169386001)**

Wait my old blog is online? Lol


**223.** `20:34` **Meredith Lamb (+14169386001)**

No


**224.** `20:34` **You**

https://lamberrymer\.blogspot\.com/search?updated\-max=2005\-11\-13T17:15:00\-05:00&max\-results=20&start=29&by\-date=false


**225.** `20:34` **You**

all of it


**226.** `20:34` **You**

how did you think I knew about Dallas Boy


**227.** `20:34` **Meredith Lamb (+14169386001)**

So weird


**228.** `20:34` **You**

lol


**229.** `20:34` **Meredith Lamb (+14169386001)**

So the earlier ones I deleted


**230.** `20:34` **Meredith Lamb (+14169386001)**

I had a couple before


**231.** `20:36` **You**

there is more if one knows how to look\.


**232.** `20:36` **Meredith Lamb (+14169386001)**

More\. Blogs?


**233.** `20:36` **Meredith Lamb (+14169386001)**

Honestly?


**234.** `20:36` **You**

yeah but I am going to stop\.\.


**235.** `20:36` **You**

not healthy


**236.** `20:36` **Meredith Lamb (+14169386001)**

I didn’t even know this was one e


**237.** `20:37` **Meredith Lamb (+14169386001)**

Wait the ones I deleted?


**238.** `20:37` **You**


*📎 1 attachment(s)*

**239.** `20:37` **You**

nothing is ever gone lol it is the internet


**240.** `20:37` **Meredith Lamb (+14169386001)**

Oh Reno blog


**241.** `20:37` **Meredith Lamb (+14169386001)**

That’s different


**242.** `20:38` **Meredith Lamb (+14169386001)**

The ones I deleted are actually gone


**243.** `20:38` **Meredith Lamb (+14169386001)**

I think


**244.** `20:38` **Meredith Lamb (+14169386001)**

They were my first lamberrymer ones


**245.** `20:38` **Meredith Lamb (+14169386001)**

I kept deleting and restarting over the years


**246.** `20:40` **Meredith Lamb (+14169386001)**

Can you see the our castle rental blog though?


**247.** `20:40` **Meredith Lamb (+14169386001)**

I thought it was made private because Andrew was interviewing this guy once and he brought printouts of the blog to the interview


**248.** `20:40` **Meredith Lamb (+14169386001)**

So I thought you made a private after that, but I could be wrong\. I don’t know\.


**249.** `20:40` **Meredith Lamb (+14169386001)**

\*he


**250.** `20:46` **You**

there is something called the wayback machine


**251.** `20:46` **You**

ever heard of it


**252.** `20:46` **Meredith Lamb (+14169386001)**

No do I need to ChatGPT it lol


**253.** `20:46` **You**

it is an archive of old websites


**254.** `20:47` **You**

it takes images of pages and sites from previous times when they existed


**255.** `20:47` **You**

you can find a lot of lost stuff


**256.** `20:47` **You**

if you have addresses


**257.** `20:49` **Meredith Lamb (+14169386001)**

I don’t think it has mine prior to 2005


**258.** `20:49` **You**

not unless it was hosted on a different platform


**259.** `20:49` **Meredith Lamb (+14169386001)**

No it was the same blog url I think


**260.** `20:49` **Meredith Lamb (+14169386001)**

I think I just deleted content


**261.** `20:49` **Meredith Lamb (+14169386001)**

Started over


**262.** `20:52` **Meredith Lamb (+14169386001)**

You kind of had me scared


**263.** `20:52` **You**

yeah\.\. anyhow, I think I am going to take a break\.\. go back to separation agreement\.\. like I said\.\. none of this is good\.\. it is just more of me being stupid me\.


**264.** `20:52` **You**

>
yeah I am sure blog from 2000\-2005 needed to be deleted

*💬 Reply*

**265.** `20:52` **You**

no doubt


**266.** `20:52` **Meredith Lamb (+14169386001)**

I can’t remember what was on those blogs\.


**267.** `20:53` **Meredith Lamb (+14169386001)**

Was during my Toronto years


**268.** `20:53` **You**

they are still around I am sure\.\. just not going to go looking for them


**269.** `20:53` **Meredith Lamb (+14169386001)**

Thank you


**270.** `20:53` **Meredith Lamb (+14169386001)**

I made me blog private lol


**271.** `20:54` **Meredith Lamb (+14169386001)**

I thought it was … I feel like blogger switched it maybe


**272.** `20:54` **Meredith Lamb (+14169386001)**

Joe meriano loved my Reno blog lol


**273.** `20:54` **Meredith Lamb (+14169386001)**

We worked together at the time of that one


**274.** `20:56` **Meredith Lamb (+14169386001)**

k, go finish your agreement\. I’m going to watch a wee bit more tv and fall asleep xoxox


**275.** `21:05` **You**

Night xo


**276.** `22:15` **You**



