# Daily Conversation: 2025-07-02 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-02 |
| **Day** | Wednesday |
| **Week** | 12 |
| **Messages** | 197 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-02T04:28 - 2025-07-02T22:20 |

## 📝 Daily Summary

This day contains **197 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:28` **You**

Good morning love\.  I have to tell you this does in fact suck\.  On my bucket list is going to bed and waking up with only you for the rest of my life\.  This weekend I caught myself watching you sleep thinking of how lucky I was and how much I loved you and how much that continued be more than I thought was previously possible\.  I watched dream and rubbed your forehead\.\. wanting to wake you up just to talk to you but also wanting to let you sleep as long as I could because I know you needed it\.  I would try to tell you how much I loved you loud enough so that you heard it but not loud enough to wake you up\.  So overall take the positive from this message\.\. there is no one else, and there never will be because I have never felt like this… and as such, this situation does in fact suck a lot lol\.  I love you Mer\.\. I hope you and the kids had a nice reunion, that Andrew wasn’t a dick, and they you had a good sleep\.  ❤️❤️❤️❤️


**002.** `07:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Just lying here in awe of that message and kind of have no words\. ❤️ I love you so much and reading stuff like this confirms a lot\. Agree, this sucks, it feels like so much time is being wasted and I don’t like that feeling\. I want to go to sleep and wake up with you too\. xoxo


**003.** `11:39` **Meredith Lamb (+14169386001)**

Reaction: 🎉 from Scott Hicks
Ok \- keys obtained, place is officially mine\. 😬


**004.** `11:40` **You**

Awesome\.\. you should be excited


**005.** `11:40` **You**

I would be


**006.** `11:40` **You**

lol


**007.** `11:40` **You**

get me the fuck outta here


**008.** `11:43` **Meredith Lamb (+14169386001)**

I am but I feel bad leaving my kids with Andrew 50% of the time\. I was asking ChatGPT how to ease my head about that\. I got home to a very messy place, laundry all over\. He just doesn’t know how or do anything\. I feel bad for the girls


**009.** `11:44` **Meredith Lamb (+14169386001)**

I won’t be here to fix it


**010.** `11:44` **Meredith Lamb (+14169386001)**

Having major anxiety about that


**011.** `11:44` **You**

>
as I said you will be picking them up with garbage bags filled with dirty clothes\.

*💬 Reply*

**012.** `11:45` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
😢


**013.** `11:46` **You**

I am sorry Mer\.\. you cannot fix everything for everyone\.


**014.** `11:48` **You**

And it isn't your responsibility tbh\.\. you didn't cause this, Andrew did\.\. and not with one act\.


**015.** `11:50` **Meredith Lamb (+14169386001)**

Yeah it will just take some time to adjust I think\.


**016.** `11:50` **You**

It will\.\. but you need to take care of you as well\.


**017.** `11:50` **You**

I know you are\.\. just don't let that go by the wayside because Andrew cannot get his act together\.


**018.** `11:51` **Meredith Lamb (+14169386001)**

That’s an incredibly hard emotional place to be in, and it makes sense you’re feeling unsettled\. You’re trying to protect your kids and adjust to your own new life — it’s a lot to carry at once\. Here are a few ways to help your head \(and heart\) work through this:
⸻
1\. Accept that “Good Enough” Might Look Different
It’s painful to know your kids may not have the same standards of cleanliness or care at their dad’s\. But try to remind yourself that kids are surprisingly resilient\. A less\-than\-ideal environment doesn’t automatically mean harm — it just means different\. Your home can still anchor them in warmth, structure, and stability\.
⸻
2\. Focus on What You Can Control
You can’t micromanage his household, but you can:
- Send the kids with clean clothes and maybe a backup bag\.
- Teach them simple things — like how to notice when clothes need washing or how to speak up for their needs\.
- Create open space for them to talk about how things feel, without putting them in the middle\.
⸻
3\. Trust in the Long Game
Your consistency, care, and emotional availability will shine over time\. Even if things feel imbalanced now, kids come to understand who shows up for them — not always in tasks, but in presence, listening, and safety\.
⸻
4\. Allow the Grief
This is grief\. You’re not only grieving the end of the shared family unit, but also your illusion of shared standards — the ability to protect your kids from less\-than\-ideal conditions\. Give yourself space to feel that\. It’s okay to hurt and move forward at the same time\.
⸻
5\. Build Your Support Muscles
Being on your own can feel scary at first, but it also offers clarity and peace\. Make your space reflect you\. Slowly lean into your routines, your solitude, and your self\-worth\. You don’t have to love it right away — you just have to begin\.


**019.** `11:52` **Meredith Lamb (+14169386001)**

I like the last sentence\.


**020.** `11:54` **You**

yeah\.\. it is definitely scary\.\. I am feeling it too tbh\.\. a lot of uncertainty\.\. but more simplicity if Gracie actually acclimates to NB\.\. Even with this last sentence, with you, I think your routines and solitude is going to get overrun, because Andrew won't be able to do this, and will still want the kids to stay there, and I can see you getting drug in to rescue them either by cleaning the house, doing their laundry at the house, or any other number of things\.


**021.** `11:54` **You**

I am not sure you will be able to create that separate but connected life\.


**022.** `11:56` **You**

I think you are an amazing Mom\.\. and you will do what you have to for your kids\.\. you will sacrifice your time, your happiness and your sanity for them lol\.\. which while amazing is equally scary\.


**023.** `11:56` **You**

There has to be repercussions in the parenting agreement if Andrew cannot hold up


**024.** `11:56` **Meredith Lamb (+14169386001)**

He just never does what he says he will so it is concerning for the kids\.


**025.** `11:57` **Meredith Lamb (+14169386001)**

Example\.

*📎 1 attachment(s)*

**026.** `11:57` **You**

again\.\. in the parenting agreement \- there needs to be something for self determination if he cannot keep a household that is functional\.


**027.** `11:57` **Meredith Lamb (+14169386001)**

He promised to groom the dogs\. I reminded him 3x over the weekend


**028.** `11:57` **Meredith Lamb (+14169386001)**

Mac said he waited until the last minute so had no time to find the clippers


**029.** `11:57` **You**

yeah\.\. I kind of thought it might be like that


**030.** `11:58` **Meredith Lamb (+14169386001)**

I don’t really care if he doesn’t do it but fucking tell me so I can make appts


**031.** `11:58` **Meredith Lamb (+14169386001)**

Just never does what he says unless it is volleyball related lol


**032.** `11:59` **You**

Well it cannot remain that way\.\. what did you say to me at dinner again??


**033.** `11:59` **You**

I enable Jaimie\.


**034.** `12:00` **You**

That is a word you should think about over the next little while\.\. you might find you are more like me\.\. enabling as an alternative to a fucking shit show\.  I am not saying you should do that long term\.\. I sure as hell am not\.\. and where i am providing support, it requires minimal time and effort\.


**035.** `12:05` **Meredith Lamb (+14169386001)**

I know I enable BS all the time with all 4 of them\.


**036.** `12:09` **You**

Yeah something about that will need to change a bit


**037.** `12:11` **Meredith Lamb (+14169386001)**

Supposed to be why he changed jobs so we will see once he’s been in it a bit more\.


**038.** `12:15` **You**

I mean the working from home should technically allow for that flexibility


**039.** `12:15` **You**

But I mean his job is a lot more higher up than mine so hard for me to understand his accountabilities etc


**040.** `12:17` **Meredith Lamb (+14169386001)**

🤷‍♀️ what he wanted\. But yeah regardless of the job he has, it will be a struggle\. He wants to do what HE wants to do and nothing beyond that\.


**041.** `12:19` **You**

Well that isn’t how it works with kids\.\. I know what I am capable of because I have done it all at various points in time\.\. again he is just going to have to reassess his priorities\.


**042.** `12:19` **You**

I will be doing same


**043.** `12:20` **Meredith Lamb (+14169386001)**

Yeah


**044.** `12:21` **Meredith Lamb (+14169386001)**

Evvvvvvverything\.

*📎 1 attachment(s)*

**045.** `12:22` **You**

lol I am sorry you sound like you are having a rough day a lot to think about maybe try not to think on it all at
Once pick a small thing think only about it then move on to next understanding you can only really set your boundaries and expectations with Andrew\.\. and then beyond that you need to decide what you are willing to sacrifice\.


**046.** `12:23` **You**

Yeah j is same for me I push on everything\.  Today was pharmacy and eyeglasses for Gracie…\.


**047.** `12:25` **Meredith Lamb (+14169386001)**

Everytime I book something he makes me reschedule\. Sometimes I have shad to reschedule 3x\! So frustrating\. I’m like book it yourself\. Geez


**048.** `12:29` **You**

He seems pretty passive\.\. a lot of apologies\.


**049.** `12:30` **You**

passive and disconnected perhaps/


**050.** `12:38` **Meredith Lamb (+14169386001)**

He doesn’t normally apologize\. Not sure what is going on\.


**051.** `12:38` **You**

Maybe he is not trying to antagonize you anymore\.\.


**052.** `12:39` **Meredith Lamb (+14169386001)**

Why tho


**053.** `12:40` **You**

He doesn't want a fight at the parental thing with the mediator?


**054.** `12:41` **Meredith Lamb (+14169386001)**

No way that is the reason\. There is something else going on


**055.** `12:41` **Meredith Lamb (+14169386001)**

I’m just not sure yet


**056.** `12:41` **You**

he wants you back?


**057.** `12:41` **You**

so he is going to be super nice?


**058.** `12:41` **Meredith Lamb (+14169386001)**

lol no


**059.** `12:42` **You**

unsure\.\. afraid I cannot help with this particular mystery\.


**060.** `12:43` **Meredith Lamb (+14169386001)**

I will talk to him in person eventually and probably find out


**061.** `12:43` **Meredith Lamb (+14169386001)**

Didn’t even see him last night and he was gone early this morning to work


**062.** `12:44` **You**

I will be interested in how that conversation goes\.  He might know he is going to need your continued help around the house\.\. etc\.\.


**063.** `12:44` **Meredith Lamb (+14169386001)**

Not sure\. Doubt that is it either


**064.** `12:44` **You**

what does your gut tell you?


**065.** `12:45` **Meredith Lamb (+14169386001)**

I think it is something more obvious


**066.** `12:45` **Meredith Lamb (+14169386001)**

Or like explicit


**067.** `12:45` **Meredith Lamb (+14169386001)**

Like maybe an ask or something


**068.** `12:45` **Meredith Lamb (+14169386001)**

I dunno


**069.** `12:45` **You**

mmm\.\. well my money is on more help around the house despite the fact that you won't be there and don't actually have an ownership stake in it\.


**070.** `12:48` **Meredith Lamb (+14169386001)**

Well I just got an ask but it is small


**071.** `12:48` **Meredith Lamb (+14169386001)**

He can’t take Marlowe to her beach tourn on Sunday


**072.** `12:49` **You**

well perhaps that is all\.


**073.** `12:59` **Meredith Lamb (+14169386001)**

He’s starting back at hockey tonight


**074.** `12:59` **Meredith Lamb (+14169386001)**

On his regular team


**075.** `13:00` **Meredith Lamb (+14169386001)**

He rejoined the “text” team \(mon/tues\)


**076.** `13:00` **You**

ahhh


**077.** `13:00` **You**

good timing\.


**078.** `13:00` **You**

for sure


**079.** `13:00` **Meredith Lamb (+14169386001)**

He left it because of the text and said he just rejoined it


**080.** `13:01` **You**

well I am sure you have feelings about this\.\. I am guessing they are roiling\.\. and I am sorry if they are\.


**081.** `13:01` **Meredith Lamb (+14169386001)**

Nah I’m fine\. Don’t care honestly


**082.** `13:01` **You**

I was thinking more practically\.\. haven't gotten this living thing sorted\.\. do you think rejoining now is the best time when you cannot find the time to do the things that absolutely matter\.


**083.** `13:02` **You**

I guess he needs a release\.\. if that is all he has\.\.


**084.** `13:04` **Meredith Lamb (+14169386001)**

Oh\! He will never be practical


**085.** `13:04` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
lol I have no hope for that


**086.** `13:04` **You**

that will just weigh on you and add to your stress


**087.** `13:05` **You**

kind of like how the Gracie situation will never seemingly get resolved for me\.


**088.** `13:06` **Meredith Lamb (+14169386001)**

If he is out at hockey every Mon, tues and Wed night until 2am on his week with kids I will be pissed


**089.** `13:06` **Meredith Lamb (+14169386001)**

I will have to talk about that at mediation


**090.** `13:06` **Meredith Lamb (+14169386001)**

Mon 12\-2 :p


**091.** `13:06` **You**

fun times


**092.** `13:07` **You**

Reaction: 😮 from Meredith Lamb
Last day for benefits for Jaimie\.\. and Gracie won't leave the house to go get glasses\.\. huge fight ensued\.\. basically pissing away $300 if she doesn't go\.\. so stupid\.  That is my day\.\. and J wants to spend a few hours with me working on the basement\.\. so I am super excited\.


**093.** `13:08` **You**

oh shit you are in a meeting sorry\.  will leave you alone\.


**094.** `13:08` **You**

mentioned the data strategy thing to Daniel\.\. that and i want to see the AI scope of work\.


**095.** `13:43` **You**

had an interesting meeting with Daniel\.\. :\)


**096.** `13:46` **Meredith Lamb (+14169386001)**

Interesting how?


**097.** `13:48` **You**

Just interesting


**098.** `13:48` **You**

Different you might say\.\.


**099.** `13:48` **Meredith Lamb (+14169386001)**

Huh?? So confused


**100.** `13:48` **You**

I mean you know\.\. different\.  It's kind of obvious\.


**101.** `13:49` **You**

This is unfair to you\.\. your mind is all reeling with everything going on so the joke is not landing :\(


**102.** `14:06` **Meredith Lamb (+14169386001)**

I am so confused\. Honestly


**103.** `14:06` **Meredith Lamb (+14169386001)**

Daniel j?


**104.** `14:06` **Meredith Lamb (+14169386001)**

Different?


**105.** `14:06` **Meredith Lamb (+14169386001)**

Huh?


**106.** `14:06` **Meredith Lamb (+14169386001)**

Why are you confusing me?


**107.** `14:07` **You**

LOL\.\. remember the weekend


**108.** `14:07` **Meredith Lamb (+14169386001)**

Omg that went over my head


**109.** `14:07` **Meredith Lamb (+14169386001)**

lol


**110.** `14:07` **You**

I told you I was going to be more vague with you because you used the word different with me and then would never explain what that meant


**111.** `14:07` **Meredith Lamb (+14169386001)**

Got it


**112.** `14:08` **Meredith Lamb (+14169386001)**

🙄


**113.** `14:08` **You**

kk


**114.** `14:08` **You**

all is good now\.


**115.** `14:08` **Meredith Lamb (+14169386001)**

Wow I was so confused


**116.** `14:08` **Meredith Lamb (+14169386001)**

Good joke


**117.** `14:08` **You**

:P


**118.** `14:08` **Meredith Lamb (+14169386001)**

😐


**119.** `14:08` **You**

😊


**120.** `14:08` **You**

that is how I feel\.


**121.** `14:08` **Meredith Lamb (+14169386001)**

lol


**122.** `14:09` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I’m glad


**123.** `14:09` **You**

>
fyi I love all of your faces \- the eyeroll, the disinterested, the flat\-line, the dismissive \- all of em\.\. love em all\!\!

*💬 Reply*

**124.** `14:11` **Meredith Lamb (+14169386001)**

>
I mean, for now you say that\. It will get added to your annoying list\. \#3

*💬 Reply*

**125.** `14:12` **You**

your face is not annoying Mer\!\!


**126.** `14:42` **Meredith Lamb (+14169386001)**

Mm hmm


**127.** `14:46` **You**

Stop being dumb\. I would never ever think that\. fack


**128.** `15:21` **Meredith Lamb (+14169386001)**

😇


**129.** `15:38` **You**

\.\.\.\.\. pls don't say that\.\. I love the way you look\.\.\. :/


**130.** `15:46` **You**

>
thus the laying there staring at you comment from this morning\.\. the annoying list is dumb\.\. I am not doing that\.\. was meant as a joke anyways\.

*💬 Reply*

**131.** `15:57` **Meredith Lamb (+14169386001)**

I’m having Scott withdrawal knowing we are not hanging out tonight\. Feels weird\.


**132.** `15:58` **You**

tonight, tomorrow night, etc for a while\.\. yeah I am feeling a bit lost too\.  It is not pleasant\.


**133.** `16:01` **Meredith Lamb (+14169386001)**

Hmmm


**134.** `16:04` **You**

>
what are you "hmm"ing about\.

*💬 Reply*

**135.** `16:06` **You**

oh want to chat at all\.\. I have focus time blocked for a workshop I am developing for tomorrow\.


**136.** `16:09` **Meredith Lamb (+14169386001)**

Workshop?


**137.** `16:09` **Meredith Lamb (+14169386001)**

Sure I’m just hanging out


**138.** `16:09` **You**

training for PD\.


**139.** `16:46` **You**

sorry I am not my usual chipper self\.\. I still love speaking to you and seeing you\.\. just kinda sorta not the same right\.\. hope your meeting goes well and that you have fun shopping tonight\.


**140.** `16:52` **Meredith Lamb (+14169386001)**

Yeah same\. Weird day


**141.** `16:53` **Meredith Lamb (+14169386001)**

Very different 😝


**142.** `16:53` **You**

>
not good different\. to be clear

*💬 Reply*

**143.** `16:54` **Meredith Lamb (+14169386001)**

Correct


**144.** `16:54` **Meredith Lamb (+14169386001)**

lol


**145.** `16:57` **Meredith Lamb (+14169386001)**

Mentally taxing …\. Better?


**146.** `16:58` **You**

>
you never responded to my question\.\.

*💬 Reply*

**147.** `16:58` **You**

Emotionally Taxing\.\.is more accurate for me\.


**148.** `17:11` **Meredith Lamb (+14169386001)**

>
I was hmm’ing because it is just difficult to think about…\. No real solutions\. It’s getting tiring but I think I’m just tired still from the weekend\.

*💬 Reply*

**149.** `17:12` **You**

>
ah ok\.\. I will have to remember that hmmm\.\.\. noted\.

*💬 Reply*

**150.** `17:40` **Meredith Lamb (+14169386001)**

I think I might need to make you a dictionary for me\.


**151.** `17:42` **You**

I don’t think that’s possible\.


**152.** `17:45` **Meredith Lamb (+14169386001)**

You’re probably right\.


**153.** `17:45` **You**

I am destined to forever muddle through life guessing at meanings behind grunts and vague statements\.\.\. rofl\.


**154.** `17:58` **Meredith Lamb (+14169386001)**

Reaction: 🤮 from Scott Hicks
I just saw Ravi and a friend walking across the street\. She lives in my hood\. Totally forgot\.


**155.** `17:58` **Meredith Lamb (+14169386001)**

Maybe good thing you weren’t with me lol


**156.** `17:59` **You**

for multiple reasons\.


**157.** `17:59` **Meredith Lamb (+14169386001)**

lol


**158.** `18:32` **Meredith Lamb (+14169386001)**

So he came home and is going shopping tomorrow instead\. Anyway, I think he was being nice because he was worried I was going to push hard and move out fully this weekend\. I was like no, I told Marlowe it will be gradual because I don’t want to stress her out\. He seemed very happy with that\. So I think that is why I was getting apologies\.


**159.** `18:56` **You**

I mean whatever decreases stress in the house must be a good thing\.


**160.** `19:00` **Meredith Lamb (+14169386001)**

I’m just worried about my kids, not him\. But I understand the niceness now\. I think he’s just concerned about kids ultimately also bc when I’m gone he has to step it up\.


**161.** `19:02` **You**

I am just glad it was something as simple and straightforward as that\.  You don't need any more stress or shit to argue about\.


**162.** `19:03` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 2 Jul 2025 19:03:50 \-0400
|
| Agree\. Bit of a relief\.
|
| Version: 1
| Sent: Wed, 2 Jul 2025 19:03:43 \-0400
|
| Agree\. But of a relief\.


**163.** `19:04` **You**

well now you can go shopping\.\. and drink wine\.\. there is that at least


**164.** `19:04` **Meredith Lamb (+14169386001)**

I don’t feel like shopping :\( ugh… watching a doc lol and having a glass 🙃


**165.** `19:05` **You**

kk have fun with that\.\. still finishing ppt then packing\.


**166.** `19:05` **You**

FML


**167.** `19:05` **Meredith Lamb (+14169386001)**

🫩


**168.** `19:06` **You**

you know that emoticon looks like a piece of paper\.\. no clue what it is


**169.** `19:06` **Meredith Lamb (+14169386001)**

A piece of paper?


**170.** `19:06` **You**

the image doesn't come out right forme


**171.** `19:06` **Meredith Lamb (+14169386001)**

It is an unamused, worn down face


**172.** `19:07` **You**

well that is me\.\.


**173.** `19:07` **You**

accurate


**174.** `19:07` **Meredith Lamb (+14169386001)**

That’s why I sent it :\)


**175.** `19:07` **You**

still true


**176.** `19:26` **Meredith Lamb (+14169386001)**

😢


**177.** `19:30` **You**

Don't give me the sad crying face\.\. Just go have 🍷 and watch your 📺, you don't need to be sad for me\.\. my situation is what is, so is ours\.\. filled with absolutely amazing and awesome ups\.\. that give me hope for the future\.\. and the fucking holes in between\.\. that's life for now\.\. I am not being dark\.\. that is reality right?  But yeah you were wondering if it would be better lol\.\. I just want you worse\.\.\. there is your answer\.\. lol better and worse at the same time\!\!\! who'd a thunk\.


**178.** `19:40` **Meredith Lamb (+14169386001)**

Yeah, same\. I believe the long weekend together made things harder for me\. I guess it is worth it but …\. definitely more difficult\. It is also just driving my brain nuts that my family doesn’t know\. Honestly, if it weren’t for Mac I probably would have exploded by now and said something at some impulsive time\.


**179.** `19:42` **You**

I don't understand the desire to tell people\.\. I have no interest in that until the timing is much more favorable for everyone\.  Otherwise it just create chaos\.\. makes the situation worse all around\.


**180.** `19:43` **You**

I mean yeah it is definitely worth it\.\. because if I thought we were just not going to see each other again, based on the fact that it makes things more challenging\.\.\. I would literally curl up in a ball right now\.\. and say wake me the fuck up in September\.


**181.** `19:45` **Meredith Lamb (+14169386001)**

>
I’m not sure\. I guess I don’t like the feeling of living a double life\.

*💬 Reply*

**182.** `19:47` **Meredith Lamb (+14169386001)**

>
I know\. I just am feeling withdrawal\. lol it will be “fine” in a day or two\.

*💬 Reply*

**183.** `19:50` **You**

>
I am not sure how it will be for me\.\. it has never been "fine" it has just been easier to suppress\.\. but the feeling is still really shitty to live with\.

*💬 Reply*

**184.** `19:51` **You**

>
I know\.\. that is something that bothers you\.\. I wish we didn't have to do things this way\.

*💬 Reply*

**185.** `19:52` **You**

Let's park this conversation maybe? \- I can put my shit in a box\.\. won't mention it\.\. you can go enjoy your show and the rest of your night\.


**186.** `19:59` **Meredith Lamb (+14169386001)**

k… going to go to bed early also


**187.** `20:03` **You**

>
sorry not trying to be abrupt or bossy\.\. but we have been here before\.\. this discussion doesn't lead anywhere except making both of us feel like shit for various reasons\.\. just didn't want you to have a bad night\.

*💬 Reply*

**188.** `20:09` **Meredith Lamb (+14169386001)**

Yeah right, you’re just trying to get rid of me\. That’s fine, go off and have your special packing time\. :p


**189.** `20:09` **You**

there is no packing tonight


**190.** `20:09` **Meredith Lamb (+14169386001)**

\(That was not serious\.\)


**191.** `20:09` **You**

she didn't want to


**192.** `20:09` **You**

I am just working\.


**193.** `20:09` **Meredith Lamb (+14169386001)**

Ew


**194.** `22:08` **You**

Alright mer not sure whether you are still awake or not but I am going to bed\.


**195.** `22:16` **You**

Edited: 3 versions
| Version: 3
| Sent: Wed, 2 Jul 2025 22:17:33 \-0400
|
| Well as expected was a rough day\.\. but you must be out already\.\.
| So hope you had a good night yourself at least\. Cya tomorrow xo\.
|
| Version: 2
| Sent: Wed, 2 Jul 2025 22:17:17 \-0400
|
| Well as expected was a rough day\.\. but you just be out already\.\.
| So hope you had a good night yourself at least\. Cya tomorrow xo\.
|
| Version: 1
| Sent: Wed, 2 Jul 2025 22:16:13 \-0400
|
| Alright well you must be out already\.\. night\. Xo


**196.** `22:18` **Meredith Lamb (+14169386001)**

Gnite ❤️❤️ love you


**197.** `22:20` **You**

Love you too…\. ❤️


