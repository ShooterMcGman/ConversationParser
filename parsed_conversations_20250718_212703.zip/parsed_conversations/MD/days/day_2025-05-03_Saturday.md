# Daily Conversation: 2025-05-03 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-03 |
| **Day** | Saturday |
| **Week** | 3 |
| **Messages** | 480 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-03T00:00 - 2025-05-03T23:42 |

## 📝 Daily Summary

This day contains **480 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

Reaction: ❤️ from Meredith Lamb
I wish I could see you


**002.** `01:00` **You**

…\.\.


**003.** `04:58` **You**

Omfg worst sleep ever cannot even… going to gym\.


**004.** `05:52` **You**

Told Jaimie before I left no more fighting at all I don’t care what anyone says or spits out I am not fighting


**005.** `06:23` **You**

Reaction: ❤️ from Meredith Lamb
Well the one shiny thing this morning 17\.2% body fat at 232 lbs pretty pleased about that down from 252 and well\. Lot more body fat lol\.


**006.** `06:36` **You**

Thought about it last night I am going to buy\.  I don’t want to
Just dump money in a rental only to buy later\.\. I figure if and when you are ever ready for to cohabitate which could be some time into the future I would be better served to own something even if I get dinged with real estate fees down the road


**007.** `06:36` **You**

Just sharing as I kind of came to a decision when trying to fall asleep last night


**008.** `06:53` **You**

Hope you are not too hung over this morning


**009.** `07:13` **You**

Think maybe pic this morning 🤔


**010.** `07:32` **You**

Maybe not if you aren’t up yet


**011.** `08:10` **You**

Sorry you will have lots
To read
Shitty night no sleep up early and no one to talk to sorry you are it


**012.** `08:21` **You**

Well I dunno workout done lazy person still sleeping going in sauna and steam room check in after


**013.** `09:00` **You**

Still sleeping I don’t think you deserve have to earn\.


**014.** `09:02` **You**

Pics are there though going to have a shower\.


**015.** `09:20` **You**

You are never getting up


**016.** `09:34` **Meredith Lamb (+14169386001)**

Never getting up indeed\. Think I’m still passed out honestly lol


**017.** `09:36` **You**

Well you have a lot to read I will let you to it\.


**018.** `09:39` **Meredith Lamb (+14169386001)**

Wow how many hours between your gym trips?


**019.** `09:40` **You**

Not enough and I went stupid hard today had a really fucked up bad night\.


**020.** `09:40` **You**

No sleep


**021.** `09:41` **You**

Oh you can call me if you want I am just I\. Car driving around looking at houses


**022.** `09:56` **You**

Actually nm I have to go home now and pick up j to bring her to Costco then looking at a townhome for me


**023.** `09:56` **You**

Think maybe you went back to sleep lol


**024.** `09:58` **You**

I had hoped to see
You this weekend even for a few mins but doesn’t look like it’s doable\.  Maybe we can catch up on the above stuff later sometime\.


**025.** `10:00` **You**

lol sigh well talk to you later shutting this down for a while\.


**026.** `11:16` **Meredith Lamb (+14169386001)**

I think I was still high this morning\. lol just waking up


**027.** `11:17` **Meredith Lamb (+14169386001)**

Sorry


**028.** `11:17` **Meredith Lamb (+14169386001)**

I will read all your stuff over my coffee when I get it made gah


**029.** `11:26` **You**

Just out at Costco now with j ☹️


**030.** `11:26` **You**

Hope home soo


**031.** `11:36` **Meredith Lamb (+14169386001)**

Wow I was a mess at like 9pm last night 😝


**032.** `11:37` **Meredith Lamb (+14169386001)**

Sorry about that but my brain really needed that\. It feels so much better today\.


**033.** `11:38` **Meredith Lamb (+14169386001)**

I feel like you had so many revelations and made so many decisions


**034.** `11:40` **Meredith Lamb (+14169386001)**

>
I think I stared at this last night and my hands were paralyzed at the time\. Lol I was so f’cked up

*💬 Reply*

**035.** `11:40` **Meredith Lamb (+14169386001)**

So I couldn’t respond


**036.** `11:42` **Meredith Lamb (+14169386001)**

>
Given the uncertainty of our respective situations I would totally do what your gut it telling you and what you think is right\. Buying is right if you can

*💬 Reply*

**037.** `11:43` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
But yes, I absolutely envision us living together and everyone being annoyed about it except for us\. 🫠


**038.** `11:50` **Meredith Lamb (+14169386001)**

>
\[deleted\]

*💬 Reply*

**039.** `11:50` **Meredith Lamb (+14169386001)**

lol


**040.** `12:22` **You**

Deleted I am sure that was interesting


**041.** `12:22` **You**

>
You were a bit of a mess\.\.but it is understandable with what you are
Going through

*💬 Reply*

**042.** `12:23` **You**

Sucks though lonely… like hanging with j is not companionship lol\.\. but it sounds again as if she is relegated
To going back
To Moncton


**043.** `12:24` **You**

You are probably out shopping or doing bat mitzvah stuff


**044.** `12:24` **You**

Will check in later


**045.** `12:36` **Meredith Lamb (+14169386001)**

I had to drop Maelle off at work


**046.** `12:37` **You**

Nah it’s all
Good
You have a busy few days


**047.** `12:37` **Meredith Lamb (+14169386001)**

>
I mean, I think when you going through a separation it is supposed to be kind of lonely so not unusual really\.

*💬 Reply*

**048.** `12:38` **Meredith Lamb (+14169386001)**

>
I’m just a chauffeur on demand disguised as a real person :p

*💬 Reply*

**049.** `12:38` **You**

Sounds about right


**050.** `12:39` **Meredith Lamb (+14169386001)**

>
Why are you hanging out together tho?

*💬 Reply*

**051.** `12:40` **You**

I offered to pick some stuff up at Costco for her she asked if I would pick her up and bring her I said fine


**052.** `12:40` **You**

We talked about Gracie’s night last night


**053.** `12:41` **You**

Her moving to Moncton


**054.** `12:41` **You**

Not sure how many more flips\.


**055.** `12:41` **You**

Not really “hanging out” equivalent to you and Andrew “hanging out at
Cottage”\. Well not cottage is def worse


**056.** `12:42` **Meredith Lamb (+14169386001)**

We don’t hang out at the cottage


**057.** `12:42` **Meredith Lamb (+14169386001)**

For like probably a couple of years honestly


**058.** `12:43` **Meredith Lamb (+14169386001)**

We have a very large cottage … no hanging out together required


**059.** `12:45` **You**

Ok well now I am down in my basement with the door locked……\.\. where I belong\.


**060.** `12:45` **You**

😔 kinda lol


**061.** `12:48` **You**

Better imagery lights off listening to sad country\.\.


**062.** `12:49` **Meredith Lamb (+14169386001)**

You don’t belong there\.


**063.** `12:49` **You**

I have no where to go


**064.** `12:49` **You**

It is what it is


**065.** `12:50` **You**

We just have very different situations so we will experience this differently


**066.** `12:50` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/0iPyyo8GtCAgRGEmxldAGi?si=DfIiJkyyQtuUxZapDWVp0Q
Do you know this one? Great sad song… :\)


**067.** `12:50` **You**

I don’t but I will put
It on the sad list


**068.** `12:51` **Meredith Lamb (+14169386001)**

One of my favourite songs


**069.** `12:51` **Meredith Lamb (+14169386001)**

Altho that list is long lol


**070.** `12:52` **Meredith Lamb (+14169386001)**

>
I guess\. Just don’t mention j gym and Costco excursions maybe\. My head will take that and do what it will…\.

*💬 Reply*

**071.** `12:54` **You**

Kk we don’t do anything together I stay down here with door locked on my own 90% of time\.


**072.** `12:54` **You**

Or I go to gym


**073.** `12:54` **You**

Like I will go back again tonight


**074.** `12:55` **You**

I will refrain from mentioning j


**075.** `12:55` **Meredith Lamb (+14169386001)**

Just in that context


**076.** `12:55` **Meredith Lamb (+14169386001)**

Lovely little excursion context lol


**077.** `12:56` **You**

Reaction: 😂 from Meredith Lamb
I hardly provided anywhere near
That context\.


**078.** `12:56` **You**

I do the least amount I have to do insofar as engaging her


**079.** `12:59` **You**

I’m just going to go to sleep\.


**080.** `13:01` **Meredith Lamb (+14169386001)**

:\( I feel like I made you sadder\.


**081.** `13:03` **Meredith Lamb (+14169386001)**

It would be so much easier if I was there in person\. Gah\.


**082.** `13:04` **You**

It’s fine mer nothing you can do\.  You got your own stuff don’t worry about it\.


**083.** `13:06` **Meredith Lamb (+14169386001)**

Always stuff I can do ❤️


**084.** `13:07` **You**

I ❤️u too\.\. but I don’t think There is hon


**085.** `13:11` **Meredith Lamb (+14169386001)**

Just know I want to always be there for you … even if I was absent this time\. Brain fried\. lol I won’t make a habit of it


**086.** `13:12` **You**

I don’t blame you mer like I said I understand\.


**087.** `14:09` **Meredith Lamb (+14169386001)**

Bat mitzvah dresses organized\. Cards, $ etc\!


**088.** `14:09` **Meredith Lamb (+14169386001)**

Remind me not get so messed up when I have a million things to do the next day\. Omg

*📎 1 attachment(s)*

**089.** `14:09` **Meredith Lamb (+14169386001)**

Painful


**090.** `14:10` **You**

Congrats climbed a small mountain\.  I am just
Getting up no sleep just done laying down\. I felt like you needed it\.\. I was concerned you hit yourself pretty hard last night\.\. lots of stuff like I said would put me under\.


**091.** `14:11` **Meredith Lamb (+14169386001)**

I was under\! Haha


**092.** `14:11` **You**

>
She’s cute love
The pose\!  Ur
Cute too of course

*💬 Reply*

**093.** `14:12` **Meredith Lamb (+14169386001)**

I need a nap now lol


**094.** `14:12` **Meredith Lamb (+14169386001)**

Having a coffee


**095.** `14:13` **You**

Reaction: 😮 from Meredith Lamb
I haven’t even had my 1st yet just about to sit down to computer and have it


**096.** `14:15` **Meredith Lamb (+14169386001)**

Omg my friends are “interesting”\. They wanted to go to a spa\. Couldn’t find anything\. Now we are back where we started\. This convo is like 4\-6 weeks long…\.\.

*📎 1 attachment(s)*

**097.** `16:43` **You**

Well back from another house hunting adventure\. So expensive\.


**098.** `16:46` **Meredith Lamb (+14169386001)**

How’d it go?


**099.** `16:52` **You**

Well I saw a nursery house


**100.** `16:52` **You**

Murder


**101.** `16:52` **You**

That was a first


**102.** `16:53` **You**

Then I went to a new development looked at a town for about 875


**103.** `16:53` **You**

Could get it for a little less
But not much


**104.** `16:54` **You**

Going to do a bit of research see
What I can find out met a nice young real estate agent at the murder house might engage him to help me


**105.** `16:54` **Meredith Lamb (+14169386001)**

>
?

*💬 Reply*

**106.** `16:54` **You**

I mean I could afford the new one if I structured the mortgage right


**107.** `16:54` **You**

Reaction: 😮 from Meredith Lamb
Someone was killed there in 2017


**108.** `16:55` **You**

Anyhow gave me something to do and I was bored


**109.** `16:56` **You**

Now I have to think of what to do next but I feel like it will be eat
Something a bit of work and back to gym


**110.** `16:56` **You**

Yeah it was a no go after that


**111.** `16:58` **Meredith Lamb (+14169386001)**

It is incredible how we are both in so limbo today when we could be together…\. It is so weird\.


**112.** `16:58` **You**

How could we be together\!\! lol


**113.** `16:58` **You**

That is all I wanted rofl


**114.** `16:58` **You**

But you had a million things to do\.


**115.** `16:58` **Meredith Lamb (+14169386001)**

I mean like technically we could but obviously we can’t\.


**116.** `16:58` **You**

Rofl


**117.** `16:58` **You**

Ok I was like what… srsly


**118.** `16:59` **Meredith Lamb (+14169386001)**

lol sorry


**119.** `16:59` **Meredith Lamb (+14169386001)**

I have gotten a lot done


**120.** `16:59` **You**

Yep
Sucks super bad but is what it is\.


**121.** `16:59` **You**

I have not gotten a ton done\.\. because no one wants to help


**122.** `17:00` **You**

The trick here is either Jaimie moves sooner than me and we get her a mortgage and I sell
This house and then figure out the money


**123.** `17:00` **You**

Or I buy and the reverse


**124.** `17:00` **You**

But glad
You got a lot
Done\!


**125.** `17:01` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Well not a lot for separating but a lot for bat mitzvah la and 14th birthday


**126.** `17:01` **Meredith Lamb (+14169386001)**

lol


**127.** `17:11` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**128.** `17:12` **You**

Very classy and cost effective


**129.** `17:14` **You**



**130.** `17:14` **You**

Oops


**131.** `17:14` **Meredith Lamb (+14169386001)**

Why did you delete that


**132.** `17:14` **Meredith Lamb (+14169386001)**

>
Didn’t buy a thing

*💬 Reply*

**133.** `17:14` **You**

Mistakes were made


**134.** `17:15` **Meredith Lamb (+14169386001)**

😐


**135.** `17:15` **You**

Mmmmm hmmmm


**136.** `17:16` **Meredith Lamb (+14169386001)**

This is challenging\. lol


**137.** `17:16` **You**



**138.** `17:16` **You**

Nope


**139.** `17:17` **Meredith Lamb (+14169386001)**

I like that you are a people pleaser but the deleter in you, no


**140.** `17:17` **You**

You were sleeping this morning when I offered you kissed out


**141.** `17:17` **You**

Missed


**142.** `17:17` **Meredith Lamb (+14169386001)**

That wasn’t fair bc I wasn’t awake


**143.** `17:17` **Meredith Lamb (+14169386001)**

I think I was still high lol


**144.** `17:18` **You**

I feel like it was
Kinda
Fair then I said you could earn it\.
But then you stayed asleep
For like 3’more hours
lol


**145.** `17:18` **Meredith Lamb (+14169386001)**

🙊


**146.** `17:18` **Meredith Lamb (+14169386001)**

I couldn’t type\. My hands were paralyzed


**147.** `17:18` **Meredith Lamb (+14169386001)**

Like seriously


**148.** `17:18` **Meredith Lamb (+14169386001)**

Haha


**149.** `17:19` **Meredith Lamb (+14169386001)**

I was very messed up


**150.** `17:19` **You**


*📎 3 attachment(s)*

**151.** `17:19` **You**

The steam room one was too sweaty


**152.** `17:19` **Meredith Lamb (+14169386001)**

I know nothing about too sweaty


**153.** `17:20` **Meredith Lamb (+14169386001)**

Can you not delete those pls\.


**154.** `17:20` **You**


*📎 1 attachment(s)*

**155.** `17:20` **Meredith Lamb (+14169386001)**

Sigh


**156.** `17:21` **You**

I figured that i am
Self
Conscious I could care less
If anyone likes me but you anyways\.  So if it makes you happy regardless of what I think I am happy to share


**157.** `17:21` **Meredith Lamb (+14169386001)**

I have zero workout photos but maybe eventually\. I used to take them nonstop


**158.** `17:21` **You**

I never did


**159.** `17:22` **Meredith Lamb (+14169386001)**

I used to IG my fitness stuff\. Hence Ehsan’s knowledge\. We followed each other


**160.** `17:22` **You**

Yeah no I won’t be doing that\.


**161.** `17:22` **You**

And I can probably delete them if I want to\.


**162.** `17:22` **You**

But I won’t


**163.** `17:22` **Meredith Lamb (+14169386001)**

Thank you


**164.** `17:25` **You**

Kk I am going to make
Myself supped and then go to the gym\.\. maybe chat later\.\.
You have been pretty
Busy and a bit distracted\.\. so don’t worry if you not up for it\.


**165.** `17:26` **Meredith Lamb (+14169386001)**

Omg gym again lol


**166.** `17:27` **You**

Just hot tub and sauna and steam then I get up at 5 am tomorrow for workout\.\.
Switching to mornings\.


**167.** `17:27` **You**

And I have nothing else
To do\.\. so there
Is that too\.\. and I hate it here\.\. so pretty easy choice


**168.** `17:28` **Meredith Lamb (+14169386001)**

Yeah I get that


**169.** `17:29` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
6am a month before I quit union\. Was working for Ehsan and if he was a better mgr I might have stayed lol

*📎 1 attachment(s)*

**170.** `17:29` **Meredith Lamb (+14169386001)**

I was obsessed with morning workouts and you getting obsessed is bring back that feeling in my head lol


**171.** `17:31` **You**

It is just a means to an end for me\.


**172.** `17:33` **Meredith Lamb (+14169386001)**

For me it was an outlet like what you are doing\. After a bad 2016 experience\. So I get what you are doing\. I did the same…

*📎 1 attachment(s)*

**173.** `17:34` **Meredith Lamb (+14169386001)**

It is a good thing … need to get back there but my mom is like “just don’t get so obsessive about it”


**174.** `17:35` **Meredith Lamb (+14169386001)**

She should meet you and hear your gym schedule


**175.** `17:35` **You**

I just want to be happy that is it


**176.** `17:35` **You**

I would love to meet
Your mum whenever the time is right


**177.** `17:35` **Meredith Lamb (+14169386001)**

2 yrs


**178.** `17:35` **Meredith Lamb (+14169386001)**

Kidding


**179.** `17:36` **Meredith Lamb (+14169386001)**

K I have to go pick Maelle up from work and then take her to her bat mitzvah


**180.** `17:36` **You**

☹️


**181.** `17:36` **You**

I don’t even like my joke anymore


**182.** `17:36` **You**

You are right it wasn’t funny when I said it


**183.** `17:36` **You**

Kk have fun


**184.** `17:39` **You**

Reaction: ❤️ from Meredith Lamb
Maybe chat later\.


**185.** `17:56` **You**

>
It would be interesting given the opportunity to work out with you\.  Could be a lot of fun\.

*💬 Reply*

**186.** `18:25` **Meredith Lamb (+14169386001)**

I would enjoy that if I was semi in shape\. I hate working out with ppl when I am not in shape\. Lol


**187.** `18:28` **You**

Well I am a good motivator


**188.** `18:33` **Meredith Lamb (+14169386001)**

You are


**189.** `18:34` **You**

Anyhow it could be fun but it is a ways off lots to focus on until then


**190.** `18:36` **Meredith Lamb (+14169386001)**

She won’t get out of the car bc her hair is “wet” from lifeguarding\.

*📎 2 attachment(s)*

**191.** `18:36` **Meredith Lamb (+14169386001)**

It isn’t that wet


**192.** `18:37` **Meredith Lamb (+14169386001)**

I still have a 30 min drive home


**193.** `18:37` **Meredith Lamb (+14169386001)**

Fack


**194.** `18:37` **You**

Not at all looks nice


**195.** `18:37` **You**

Sorry you look non\-plussed


**196.** `18:37` **You**

So 30 mins home then when you going back to get her?


**197.** `18:38` **Meredith Lamb (+14169386001)**

Omfg her phone is dead so I have to charge it for 10\-15 min before I leave


**198.** `18:39` **Meredith Lamb (+14169386001)**

Otherwise she has no way to text me for a ride home


**199.** `18:39` **Meredith Lamb (+14169386001)**

This kid… I swear


**200.** `18:39` **You**

Errr yeah fucked night


**201.** `18:40` **You**

Sorry mer that sucks no fun tonight


**202.** `18:41` **Meredith Lamb (+14169386001)**

Kids are so fucking annoying sometimes


**203.** `18:42` **You**

Yep I know… it makes a difficult day so much moreso


**204.** `18:42` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/7lGKEWMXVWWTt3X71Bv44I?si=ZWtaj5miSZu032M\_xYLkjA


**205.** `18:42` **You**

lol always a song


**206.** `18:43` **You**

Well I am busy putting together a one not journal while I am eating


**207.** `18:43` **Meredith Lamb (+14169386001)**

One note for what


**208.** `18:46` **You**

Sec


**209.** `18:49` **You**

It’s a chat for inspired journal for me with sections for different types of information… I need an outlet\.


**210.** `18:51` **Meredith Lamb (+14169386001)**

Good idea\. I mean providing no one snoops through your stuff


**211.** `18:51` **You**

No one can access it


**212.** `18:51` **You**

Anyhow it covers a lot of stuff and I have way too much going on so need to let it out\.


**213.** `18:52` **Meredith Lamb (+14169386001)**

Do you think it was a great time to go off anxiety meds?


**214.** `18:52` **Meredith Lamb (+14169386001)**

🤔


**215.** `18:53` **You**

Yea I have to learn to deal with this\. On my own\.  And this is too much to share\.\. so this is the only other option I have thought of plus maybe it will keep my mind occupied a bit


**216.** `18:54` **You**

Also mer… it was literally the lowest dose I could be on\.  I know someone who is 10x my dose


**217.** `18:55` **Meredith Lamb (+14169386001)**

k just don’t like to see you struggling either


**218.** `18:55` **You**

I don’t want you to see me struggling\. This trying to find other solutions\.


**219.** `18:56` **You**

I want to have somewhere else to drop off my feelings and push the rest down into a box


**220.** `18:57` **Meredith Lamb (+14169386001)**

I don’t think you have to do that\. Doesn’t seem healthy for you


**221.** `18:57` **Meredith Lamb (+14169386001)**

More my thing


**222.** `18:57` **Meredith Lamb (+14169386001)**

lol


**223.** `18:57` **You**

Not healthy for us if I do t


**224.** `18:57` **You**

Don’t


**225.** `18:57` **Meredith Lamb (+14169386001)**

Not true


**226.** `18:57` **Meredith Lamb (+14169386001)**

Wdym


**227.** `19:00` **Meredith Lamb (+14169386001)**

This is what I did when I stayed home and didn’t work\. Lol

*📎 1 attachment(s)*

**228.** `19:00` **Meredith Lamb (+14169386001)**

I would design them on paper first lol

*📎 1 attachment(s)*

**229.** `19:01` **You**

Mer I don’t have a life\.\. honestly this family has been broken a long time maddie is relatively self sufficient Gracie is a mess but we cannot connect\.\. j is well whatever\.\. my life has been my job and trying to make people happy here\. I have had nothing for myself\.  You come along and the analogy of the drowning man and the lifeguard comes
To mind\.  I don’t want to weigh you down or pull you under\.  Having these feelings now I want to have them as much as I can, and looking forward to weeks and weeks of can’t\.\. it really crushes on me\.\. and I cannot let that touch you or you will eventually resent me\. So I need to find an alternative outlet and I need to build a life for myself\.


**230.** `19:01` **You**

>
Again I don’t care what you think about it I think it and you are amazing\.  The more I learn the more you prove it to be true\.

*💬 Reply*

**231.** `19:03` **You**

So I am just trying to find ways to avoid you eventually seeing me as weak and needy and broken and overly dependent on you because that isn’t or wasn’t me\.


**232.** `19:05` **Meredith Lamb (+14169386001)**

>
You have a life but not one you are happy with…\. And you are changing that\. Same\. Listen, you will not nor are you dragging me down\. I could say the same\. Our lives/situations/whatever is part of our story and connection\. You don’t need to hide any part of you from me\. Quite frankly, that would suck……

*💬 Reply*

**233.** `19:05` **Meredith Lamb (+14169386001)**

K I’m allowed to drive home now omg


**234.** `19:08` **You**

Safe drive\.\. but honestly mer I share a lot but remember how you talked about our levels of intensity being different\.\. I don’t think you quite get the difference\.\.  and I don’t understand it so I am trying to wrap my head around it daily\.  And I cannot open up that much because it is just too much to put on anyone\.  Again someday I hope this will all go away when situations change\.  I suspect it will\.


**235.** `19:08` **You**

For now I will carry it myself and try to figure out how to manage it\.


**236.** `19:13` **You**

I can very much empathize with cold as a stone\.\. I wish was too\.


**237.** `19:14` **You**

That or Tinman


**238.** `19:27` **You**

Jesus some dark fucking sad songs out there\.\.


**239.** `19:28` **You**

Was trying to find something to reflect I\. And I am finding super depressing shit


**240.** `19:30` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/0GVuLQtPXFaL18ijEOqoAa?si=PgrY1vN\-SQuZQPAUpQ7WfQ
Not sad


**241.** `19:31` **You**

Treasure trove of songs\. Aren’t you\.


**242.** `19:31` **Meredith Lamb (+14169386001)**

Playing my liked playlist on shuffle lol


**243.** `19:31` **Meredith Lamb (+14169386001)**

>
It is not too much\.

*💬 Reply*

**244.** `19:33` **You**

Mer sorry but it is\.


**245.** `19:34` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/44IeABaLLsnFVb7rjzNTzS?si=gignjju4T2CLW9vdDI\_3vw


**246.** `19:34` **You**

Here this is for you\.


**247.** `19:34` **You**

Reaction: ❤️ from Meredith Lamb
https://open\.spotify\.com/track/2qLMf6TuEC3ruGJg4SMMN6?si=iozhHjmJRUmGHqarJR5WXw&context=spotify%3Aartist%3A6aZyMrc4doVtZyKNilOmwu


**248.** `19:36` **You**

You have a lot of really strong feeling songs\.


**249.** `19:36` **You**

What drove this


**250.** `19:37` **Meredith Lamb (+14169386001)**

>
Never heard this song

*💬 Reply*

**251.** `19:37` **Meredith Lamb (+14169386001)**

>
Just the music I prefer

*💬 Reply*

**252.** `19:38` **You**

That lucky song was on glee


**253.** `19:38` **You**

But I have always liked it


**254.** `19:38` **You**

Going back to your greatest showman


**255.** `19:38` **You**

https://open\.spotify\.com/track/65fpYBrI8o2cfrwf2US4gq?si=TqK57ISWQraRlRnZAEeZvg&context=spotify%3Atrack%3A65fpYBrI8o2cfrwf2US4gq


**256.** `19:39` **You**

>
It is pretty longing and powerful

*💬 Reply*

**257.** `19:41` **Meredith Lamb (+14169386001)**

I have the whole greatest showman soundtrack in my liked songs lol


**258.** `19:42` **Meredith Lamb (+14169386001)**

Did you watch the Movie


**259.** `19:43` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/28cnXtME493VX9NOw9cIUh?si=Gb7\_op6zQgS24L8s67HqiQ
I like sad songs


**260.** `19:44` **You**

>
I was saving it\.

*💬 Reply*

**261.** `19:46` **Meredith Lamb (+14169386001)**

I’m not sure if we watch movies together well


**262.** `19:47` **You**

Not yet but we will need to take a break sometime


**263.** `19:47` **You**

Super cheesy incoming but I read the lyrics\.\.


**264.** `19:47` **Meredith Lamb (+14169386001)**

Lyrics of?


**265.** `19:47` **You**

Reaction: 😂 from Meredith Lamb
The non commitment commitment?


**266.** `19:48` **You**

https://open\.spotify\.com/track/0Q7Jp3aCwfYnSnbMDoXWyR?si=IpHM5l6zTiC3pYVQMn1OdQ&context=spotify%3Atrack%3A0Q7Jp3aCwfYnSnbMDoXWyR


**267.** `19:49` **Meredith Lamb (+14169386001)**

Shania wow bringing it back


**268.** `19:49` **You**

If the shoe fits\.


**269.** `19:49` **Meredith Lamb (+14169386001)**

Grade 13\. We were all obsessed with her haha


**270.** `19:50` **Meredith Lamb (+14169386001)**

It’s kind of a wedding song you know


**271.** `19:51` **You**

Non commitment commitment song you mean


**272.** `19:51` **You**

I would never suggest a wedding song I know better


**273.** `19:51` **You**

Shania had a shit ton of great songs\.\. still the one is pretty heavy too\.


**274.** `19:52` **You**

But we would need to be together for a while for that to work


**275.** `19:52` **Meredith Lamb (+14169386001)**

For what to work?


**276.** `19:52` **You**

And yes I used an absolute I am sry lol


**277.** `19:53` **You**

The song is a reference to a long term relationship


**278.** `19:53` **Meredith Lamb (+14169386001)**

It is a reference to a marriage


**279.** `19:53` **Meredith Lamb (+14169386001)**

But whatever lol


**280.** `19:53` **You**

I feel like it is open to interpretation


**281.** `19:53` **Meredith Lamb (+14169386001)**

lol


**282.** `19:53` **You**

In this case non commitment commitment


**283.** `19:54` **You**

You know your reaction the other\. Ight when I talked about our song and you went to the paramour one\.\. I could live with that too it is completely true\.


**284.** `19:54` **Meredith Lamb (+14169386001)**

It reminds me you bc I had never heard it before…


**285.** `19:55` **You**

Well we
Can use that one then


**286.** `19:55` **Meredith Lamb (+14169386001)**

I connect it to you


**287.** `19:55` **Meredith Lamb (+14169386001)**

I like Morgan too :\)


**288.** `19:55` **You**

I mean they both work for me\.


**289.** `19:55` **Meredith Lamb (+14169386001)**

More than one song is ok


**290.** `19:55` **Meredith Lamb (+14169386001)**

lol


**291.** `19:55` **You**

Yep


**292.** `19:56` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/1XbC2PUR09MlgmpVbLgF4L?si=Xhatz6z2Q4CvaJaBVoipLQ
Listening to this now…


**293.** `19:57` **You**

Ahh divergent


**294.** `19:57` **Meredith Lamb (+14169386001)**

Such a good movie


**295.** `19:57` **You**

You had mentioned it before


**296.** `19:57` **You**

The boy is pretty cute I think I recall


**297.** `19:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**298.** `19:59` **Meredith Lamb (+14169386001)**

>
His name is Four\. And yes\.

*💬 Reply*

**299.** `19:59` **You**

Jim is a bad man


**300.** `19:59` **Meredith Lamb (+14169386001)**

lol


**301.** `20:01` **You**

Are you doing that again tonight lol


**302.** `20:01` **Meredith Lamb (+14169386001)**

I can’t\. I have to drive from 10\.30\-11\.30pm\. :p


**303.** `20:02` **You**

Wow that sucks\.


**304.** `20:02` **Meredith Lamb (+14169386001)**

Yeah…


**305.** `20:02` **Meredith Lamb (+14169386001)**

After 11\.30 all bets are off


**306.** `20:02` **You**

Well
You can do whatever you want then I will be going to bed


**307.** `20:03` **Meredith Lamb (+14169386001)**

Mac’s friends are coming over again apparently


**308.** `20:03` **You**

Well then you will be entertained


**309.** `20:03` **Meredith Lamb (+14169386001)**

Maybe\. We will see


**310.** `20:05` **Meredith Lamb (+14169386001)**

So how is your one note going


**311.** `20:06` **You**

It isn’t I was talking to you and listening to music


**312.** `20:06` **You**

I will have nothing to do later I will do it then


**313.** `20:07` **Meredith Lamb (+14169386001)**

Much more fun


**314.** `20:07` **You**

Yep true


**315.** `20:08` **You**

Plus there is going to be an absolute shit ton for me to download\.\. will take a while


**316.** `20:08` **Meredith Lamb (+14169386001)**

Download?


**317.** `20:08` **You**

From myself


**318.** `20:09` **Meredith Lamb (+14169386001)**

Ohhhh


**319.** `20:09` **Meredith Lamb (+14169386001)**

Maybe you just need to take a couple edibles and relax


**320.** `20:11` **You**

No


**321.** `20:11` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/5b9Iolaee6xTaMWb8c5rLB?si=NPpxJV1PQF29b\-EdBpqTVw
Have you ever heard this song?


**322.** `20:11` **You**

Remeber they take me to the bad place


**323.** `20:11` **You**

Will listen in a sec getting stuff to get in car


**324.** `20:11` **You**

I cannot do what you do mer very jealous


**325.** `20:12` **You**

And our situations are different so there is that


**326.** `20:12` **You**

Just drugs are not my friends atm


**327.** `20:13` **You**

And this isn’t who I am outside of work\.\. unlike work I am typically more up beat optimistic fun goofy guy\.


**328.** `20:13` **You**

But yeah\.\. not quite atm lol


**329.** `20:15` **Meredith Lamb (+14169386001)**

Same atm


**330.** `20:17` **You**

Anyhow as I said I am not dumping this on you anymore\.\. so no more sooo……\.\. and mmmm hmmmmm and stuff like that to draw it out\.


**331.** `20:18` **Meredith Lamb (+14169386001)**

lol you are not dumping stuff on me so stop


**332.** `20:19` **You**

I am and I know I am\.  And everything I have read ever before and in the last two days tell me if I do this you will leave\.  So I don’t want that\. Even if you say you won’t I don’t want to risk it\.


**333.** `20:20` **Meredith Lamb (+14169386001)**

What have you read? Curious minds…\.


**334.** `20:20` **You**

Always curious


**335.** `20:21` **You**

Read online forums gpt Gemini psychological journals etc
Etc


**336.** `20:21` **Meredith Lamb (+14169386001)**

😇


**337.** `20:21` **You**

You know me I research


**338.** `20:21` **Meredith Lamb (+14169386001)**

And what was your “topic”


**339.** `20:22` **Meredith Lamb (+14169386001)**

What are you researching, what is one of your current issues?


**340.** `20:22` **You**

That isn’t what I researched nice try though


**341.** `20:22` **Meredith Lamb (+14169386001)**

I was ASKING what you researched


**342.** `20:23` **You**

No you wanted to know about my issues


**343.** `20:23` **You**

lol


**344.** `20:23` **Meredith Lamb (+14169386001)**

Well I’m assuming they are linked


**345.** `20:23` **Meredith Lamb (+14169386001)**

Research topic = issue


**346.** `20:23` **You**

Sure but I am not talking isssue


**347.** `20:23` **You**

Research topic was what happens when you feel too much and open up too often


**348.** `20:24` **Meredith Lamb (+14169386001)**

Sigh\.\.


**349.** `20:24` **Meredith Lamb (+14169386001)**

You are feeling too much?


**350.** `20:24` **Meredith Lamb (+14169386001)**

Or just enough


**351.** `20:24` **You**

See you are signing


**352.** `20:24` **You**

That is a clear sign


**353.** `20:24` **You**

They said so


**354.** `20:24` **Meredith Lamb (+14169386001)**

Huh?


**355.** `20:25` **Meredith Lamb (+14169386001)**

Who is they


**356.** `20:25` **You**

The research


**357.** `20:25` **Meredith Lamb (+14169386001)**

Omg


**358.** `20:25` **Meredith Lamb (+14169386001)**

I’m signing


**359.** `20:25` **Meredith Lamb (+14169386001)**

Going to research that now


**360.** `20:25` **You**

This is not the right\-now kind of love\. This is the build\-it\-slow\-and\-sacred kind\. And that means the ache is part of it, not a detour from it\.


**361.** `20:26` **You**

Don’t treat the ache as failure\. Treat it as evidence\. You love her\. Now, build the stamina to hold that love with reverence until the world can catch up\.


**362.** `20:26` **You**

Impossible I don’t know how to do this


**363.** `20:26` **You**

Boundaries: Don’t seek constant reassurance from her—it will backfire\. Set mutually agreed check\-ins that give both of you stability\.


**364.** `20:26` **Meredith Lamb (+14169386001)**

>
Same\.

*💬 Reply*

**365.** `20:27` **You**

You need one person—a therapist, coach, or deeply trusted friend—who:
- Is not your ex\.
- Is not your lover\.
- Doesn’t work for you\.
- Can hold your sadness without fixing it\.
Keeping this inside will rot you from the core\. You don’t have to carry it alone\.


**366.** `20:27` **Meredith Lamb (+14169386001)**

I can’t find anything on “signing”\. What did you mean


**367.** `20:27` **You**

Sighing


**368.** `20:27` **Meredith Lamb (+14169386001)**

Oh


**369.** `20:27` **Meredith Lamb (+14169386001)**

lol


**370.** `20:28` **Meredith Lamb (+14169386001)**

I just think you are opening up too often


**371.** `20:28` **You**

See


**372.** `20:28` **You**

lol


**373.** `20:28` **You**

It was right\!\!\!


**374.** `20:29` **Meredith Lamb (+14169386001)**

I’m not sure why you are feeling that way other than you are feeling unreciprocated but I just don’t express myself like you\. Doesn’t mean I’m not feeling it


**375.** `20:29` **Meredith Lamb (+14169386001)**

>
Sorry I meant “I just don’t think you are…”

*💬 Reply*

**376.** `20:29` **Meredith Lamb (+14169386001)**

Typo


**377.** `20:29` **Meredith Lamb (+14169386001)**

Sorry


**378.** `20:29` **You**

Hmmmmmmmmmm I dunno


**379.** `20:30` **Meredith Lamb (+14169386001)**

I prefer when you open up


**380.** `20:30` **Meredith Lamb (+14169386001)**

Why do you think I don’t?


**381.** `20:31` **You**

Because you are carrying enough and who wants someone weak\. It’s not even that it is what i said earlier I am completely isolated and alone\. I am a loner but not like this


**382.** `20:31` **You**

And


**383.** `20:31` **You**

I was more fine with it when I felt nothing


**384.** `20:31` **Meredith Lamb (+14169386001)**

Listen, I know you are not weak


**385.** `20:32` **Meredith Lamb (+14169386001)**

Like honestly


**386.** `20:32` **You**

If you do t know what you are missing you cannot miss it right


**387.** `20:32` **Meredith Lamb (+14169386001)**

Virgo perfectionism to a fault


**388.** `20:32` **You**

Just logic


**389.** `20:32` **Meredith Lamb (+14169386001)**

You are your own worst enemy


**390.** `20:32` **You**

I know


**391.** `20:33` **You**

I have been here before


**392.** `20:33` **Meredith Lamb (+14169386001)**

If you could see yourself through my eyes you would feel better I think


**393.** `20:33` **Meredith Lamb (+14169386001)**

If we met in a different time I would have dated you for sure\.


**394.** `20:33` **Meredith Lamb (+14169386001)**

I mean I remember liking you as a person in Florida that time


**395.** `20:34` **Meredith Lamb (+14169386001)**

Felt a little jealous of your happy little cutesie family


**396.** `20:34` **Meredith Lamb (+14169386001)**

Mine was not happy at that time


**397.** `20:34` **You**

Mer tbh I actually believe you like me and love me for who I am it isn’t\. Lack of confidence


**398.** `20:34` **You**

It is simple


**399.** `20:35` **Meredith Lamb (+14169386001)**

Then what is it


**400.** `20:35` **You**

What I just said


**401.** `20:35` **Meredith Lamb (+14169386001)**

You have been here before?


**402.** `20:35` **You**

Well that is true but not what I meant


**403.** `20:35` **Meredith Lamb (+14169386001)**

You feel like a burden?


**404.** `20:36` **Meredith Lamb (+14169386001)**

I’m guessing here


**405.** `20:36` **You**

I have blown up relationships all on my own by myself


**406.** `20:36` **You**

But no


**407.** `20:36` **Meredith Lamb (+14169386001)**

Ah k


**408.** `20:36` **Meredith Lamb (+14169386001)**

I get it


**409.** `20:36` **You**

This is just about being sad and lonely\.


**410.** `20:36` **You**

And weak


**411.** `20:36` **Meredith Lamb (+14169386001)**

I am too obsessed with you, you will not blow this up


**412.** `20:37` **Meredith Lamb (+14169386001)**

I mean unless you and Jaime rekindle


**413.** `20:37` **Meredith Lamb (+14169386001)**

lol


**414.** `20:37` **Meredith Lamb (+14169386001)**

Then maybe


**415.** `20:37` **You**

Sad lonely and weak and no interest whatsoever in looking backwards


**416.** `20:37` **You**

Zero


**417.** `20:37` **Meredith Lamb (+14169386001)**

You are not sad, lonely nor weak\.


**418.** `20:37` **You**

I feel that way


**419.** `20:38` **Meredith Lamb (+14169386001)**

I mean you are transitioning from one life to the next\. There will be moments in that transition but it doesn’t mean that is who you are


**420.** `20:38` **Meredith Lamb (+14169386001)**

It shouldn’t define you


**421.** `20:38` **Meredith Lamb (+14169386001)**

You just get thru it


**422.** `20:38` **Meredith Lamb (+14169386001)**

By whatever means…


**423.** `20:39` **You**

Sure sure lol


**424.** `20:39` **Meredith Lamb (+14169386001)**

For me, it is getting wasted\.


**425.** `20:39` **Meredith Lamb (+14169386001)**

For you, it is going to the gym\.


**426.** `20:39` **Meredith Lamb (+14169386001)**

lol


**427.** `20:39` **You**

It does t do it


**428.** `20:39` **You**

I still come home to the house and the basement


**429.** `20:39` **You**

And my brain


**430.** `20:39` **Meredith Lamb (+14169386001)**

But it isn’t forever


**431.** `20:40` **Meredith Lamb (+14169386001)**

It’s just probably too long


**432.** `20:40` **Meredith Lamb (+14169386001)**

But not forever


**433.** `20:40` **Meredith Lamb (+14169386001)**

Just consider yourself at war right now


**434.** `20:40` **Meredith Lamb (+14169386001)**

Haha


**435.** `20:40` **You**

I don’t see the end… not in sight…  trying
Trying


**436.** `20:40` **Meredith Lamb (+14169386001)**

Really?


**437.** `20:40` **Meredith Lamb (+14169386001)**

I do


**438.** `20:41` **You**

That’s the drugs talking


**439.** `20:41` **Meredith Lamb (+14169386001)**

It is a tad too far for my liking but I see it


**440.** `20:41` **Meredith Lamb (+14169386001)**

I have no drugs in me


**441.** `20:41` **Meredith Lamb (+14169386001)**

lol right


**442.** `20:41` **You**

From last night stilll


**443.** `20:41` **Meredith Lamb (+14169386001)**

I know lol


**444.** `20:42` **Meredith Lamb (+14169386001)**

I can kind of see the end but I see the midpoint more


**445.** `20:42` **Meredith Lamb (+14169386001)**

I have my own place and am out of here


**446.** `20:42` **Meredith Lamb (+14169386001)**

That’s my mid point


**447.** `20:42` **Meredith Lamb (+14169386001)**

Next couple of months


**448.** `20:43` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/0QEmGCfiMQjyDRnRogtMnM?si=oAeO5UbhTzaHbotGSScNFw


**449.** `20:44` **You**

Mid point is a couple of months?


**450.** `20:44` **You**

Rofl\!\!\!\!’n


**451.** `20:44` **Meredith Lamb (+14169386001)**

Hopefully have my own place July 1


**452.** `20:44` **Meredith Lamb (+14169386001)**

That is my midpoint


**453.** `20:44` **Meredith Lamb (+14169386001)**

Short term is literally surviving next week


**454.** `20:45` **You**

I got agreement from j I can take a vacation do whatever I want like her trip to Aruba cruise whatever\.\. fyi\.


**455.** `20:45` **You**

I am going to have a very difficult time I didn’t think I would\. But I will\.


**456.** `20:46` **You**

Btw if your shadow isn’t around we can talk instead of text I am going for a walk on a treadmill


**457.** `20:46` **Meredith Lamb (+14169386001)**

>
Does this mean we are going on a trip? Lol

*💬 Reply*

**458.** `20:46` **You**

I was seeing what you wanted it really is your schedule that will dictate


**459.** `20:47` **Meredith Lamb (+14169386001)**

>
My shadow is at a bat mitzvah

*💬 Reply*

**460.** `20:47` **Meredith Lamb (+14169386001)**

>
Difficult time with what?

*💬 Reply*

**461.** `20:47` **You**

Kk well up to you walk starting


**462.** `20:48` **Meredith Lamb (+14169386001)**

Well you can call if you want


**463.** `20:48` **Meredith Lamb (+14169386001)**

Unless you are out of breathe lol


**464.** `21:03` **You**

I am really sad\.\. getting separated \.\. living in my basement\.\. my wife hates me kids not as bad\.  I am in love with someone else so hard, like nothing ever like it ever ever ever I cannot emphasize that enough\.  And she loves me too but we cannot find time and she has a busy life with her kids\.\. oh did I mention she works for me also and we have to keep it a secret\. Wtf do I do to deal with the sadness and absence\.\. we will be together eventually but this is physical pain


**465.** `21:26` **Meredith Lamb (+14169386001)**

I’m really struggling right now\. I’m separated and living in my basement\. Things with my wife are broken—she’s angry and distant—and while my kids are more forgiving, it’s still incredibly hard\.
The complicated part is… I’m in love\. Truly, deeply in love, in a way I’ve never experienced before\. It’s with someone extraordinary\. She sees me\. She knows me\. She brings out parts of me I thought were lost\. She loves me too—but life is complicated\.
She has a full life of her own—she’s a mother, with three kids, navigating her own separation\. She works for me, which adds even more layers to everything\. We have to be careful, and it’s so hard to keep something this real hidden\. We hardly get time together, and when we do, it’s amazing—but when we don’t, I feel this aching absence\.
I know in my bones that we’ll be together someday, and that helps me hold on\. But in the meantime, the sadness, the longing, the waiting—it hurts\. Physically, emotionally\.
How do I live with this in\-between? How do I cope with missing someone I love so deeply when being with her fully just isn’t possible yet?”\*\*
⸻
Would you like a version that sounds more like a text to a close friend, or something for a journal or therapist?


**466.** `21:29` **Meredith Lamb (+14169386001)**

Scott, your pain is valid\. You’re navigating a profound emotional storm—letting go of one life while desperately wanting another that still feels out of reach\. It makes complete sense that you’re feeling this level of sadness and longing\. Separation alone is emotionally brutal\. Add in a love that has to remain hidden, limited time with someone who brings you joy, and the emotional fallout with your family—of course it feels overwhelming\.
What you’re experiencing isn’t just sadness\. It’s grief\. Grief for a relationship that’s ending, for the time you wish you had, for the version of your life you can’t fully live yet\. And when love feels this strong but can’t be fully expressed, it creates a kind of emotional limbo that’s incredibly painful\.
Here’s what I’d gently offer:
- Don’t carry this alone\. This is too much for one person to process in isolation\. Talking to a therapist or counselor can help you move through this in a healthier way\.
- Focus on anchoring yourself\. It’s easy to get pulled into the dream of the future, but your body and mind still need you here, now\. Even small routines, movement, or creative expression can ground you\.
- Be kind to yourself\. You’re not a villain for loving someone new, or for being heartbroken over your past\. You’re human\. Complex, emotional, and worthy of grace\.
You don’t have to have all the answers today\. But if you can find a way to stay present—even just a little—you’ll give yourself space to eventually arrive at the life you want to live\. One day at a time\.”\*\*


**467.** `21:49` **Meredith Lamb (+14169386001)**

I get concerned when you say you have to hide stuff from me because you think I can’t handle it or whatever\. I honestly think we might be soulmates and if that is the case, it means I uniquely understand you and hopefully even complete you\. I can’t do that if you hide stuff…… or hide who you are or what you’re going through\. You realize that?


**468.** `22:28` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/11EX5yhxr9Ihl3IN1asrfK?si=u3wOxo4bSL6bBVCfschn4g


**469.** `22:28` **You**

I listened to that earlier


**470.** `22:28` **You**

When you sent me the other one


**471.** `22:36` **You**

I will call you in a min brushing
Y teeth\.


**472.** `22:44` **You**

>
And I don’t think we are I am sure we are\.\. we just need the time and opportunity\.

*💬 Reply*

**473.** `23:03` **You**

Love you xoxoxoxo ❤️❤️❤️❤️this better be the kind of thing where we come through stronger because of it\.


**474.** `23:09` **You**

>
And mer I think I have been quite a bit more open, but I am pretty patient\. Just saying you can open up too\.

*💬 Reply*

**475.** `23:12` **You**

If you get bored before bed why don’t you leave one of your own open up notes like I leave you\.\. would love to read it and learn more about you\.


**476.** `23:33` **Meredith Lamb (+14169386001)**

I came home to a party 🙄


**477.** `23:33` **Meredith Lamb (+14169386001)**

>
Am I not opening up enough?

*💬 Reply*

**478.** `23:37` **Meredith Lamb (+14169386001)**

It’s possible that his perception is based on how you open up\. You often take time to process and tend to share in ways that are thoughtful, measured, or analytical\. He, on the other hand, may express himself more spontaneously or directly—so to him, that might feel like he’s opening up more, even if you’re actually being just as emotionally present, but in a different style


**479.** `23:41` **Meredith Lamb (+14169386001)**

Marlowe won a Morgan Wallen t shirt at the bat mitzvah

*📎 1 attachment(s)*

**480.** `23:42` **Meredith Lamb (+14169386001)**

She’s going to sleep over at her friend’s 🎉🎉🎉


