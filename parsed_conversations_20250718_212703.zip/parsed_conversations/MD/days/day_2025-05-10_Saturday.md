# Daily Conversation: 2025-05-10 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-10 |
| **Day** | Saturday |
| **Week** | 4 |
| **Messages** | 69 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-10T03:43 - 2025-05-10T23:33 |

## 📝 Daily Summary

This day contains **69 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `03:43` **Meredith Lamb (+14169386001)**

2 min away


**002.** `03:44` **Meredith Lamb (+14169386001)**

I think you should go? Even at least for maddie?? I can go to my parents?


**003.** `14:19` **You**

Hope the drive back is/was ok


**004.** `14:22` **Meredith Lamb (+14169386001)**

Soooooo much traffic


**005.** `14:23` **You**

That sucks\.\. does it look like drive back will be equally bad


**006.** `14:35` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/21IYMdzTrzSe191Cy5eMap?si=OE9sZcE0QPq6222KBljzPQ
A new favourite song I found a few days ago\.


**007.** `15:19` **You**

That is a pretty awesome song\.\. listened to it a few times,
Some stuff to relate
To


**008.** `17:14` **You**

You left little white hillfiger sockies here


**009.** `17:15` **Meredith Lamb (+14169386001)**

Whoops you can just toss them


**010.** `17:15` **Meredith Lamb (+14169386001)**

We have a million of them


**011.** `17:16` **Meredith Lamb (+14169386001)**

So I slept for 2 hrs


**012.** `17:16` **Meredith Lamb (+14169386001)**

lol


**013.** `17:16` **You**

Kk


**014.** `17:16` **You**

Me too


**015.** `17:16` **Meredith Lamb (+14169386001)**

Now I have to get up :\(


**016.** `17:16` **You**

I slept since my 3 pm


**017.** `17:16` **Meredith Lamb (+14169386001)**

Same


**018.** `17:17` **Meredith Lamb (+14169386001)**

I could sleep more but will have to get Maelle at work shortly and then drive back to the shwa\! Yaye\. Lol


**019.** `17:18` **You**

I had a bite then watched tv got a really bad stitch from moving a wierd way came in to listen to the song you sent kept mynfavs playing and passed out


**020.** `17:20` **You**

Maybe go to sleep early tonight and bounce out of here early to do hun tomorrow morning and work everything out a bit\.\. might he kind of nice


**021.** `18:24` **Meredith Lamb (+14169386001)**

Told the girls I’m going back to old jobs so I have more time for them\. Mac smirked and raised her eyebrows\.


**022.** `18:25` **You**

I think
Mac an I will get along well


**023.** `18:45` **Meredith Lamb (+14169386001)**

lol


**024.** `18:45` **You**

I hope tonight goes well for you hon\.


**025.** `18:48` **Meredith Lamb (+14169386001)**

Just arrived at park to meet others


**026.** `18:49` **You**

❤️


**027.** `18:49` **You**

You are pretty awesome for doing this your mother and family are so lucky


**028.** `19:04` **You**

Reaction: 😂 from Meredith Lamb
So I have had a very naughty weekend for food I am going to have to make up for it next week


**029.** `19:08` **You**

Reaction: ❤️ from Meredith Lamb
Also bumble kind of
Boring I think I need to find something else


**030.** `19:16` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**031.** `19:16` **You**

I deleted the app just so you know\.\. and my account\.\. very sad attempt to fill in something that really only you can fill in\.


**032.** `19:17` **Meredith Lamb (+14169386001)**

I have to make my video into a tik tok now


**033.** `19:17` **Meredith Lamb (+14169386001)**

>
D’aw ❤️

*💬 Reply*

**034.** `19:17` **You**

Love you mer\.\. have fun


**035.** `19:19` **You**

Tell your mum Scottie wishes her a happy bday too\.\. tell her not to judge me too harshly lol… you a hard person not to want to be around\.


**036.** `19:22` **Meredith Lamb (+14169386001)**

lol I will tell her later\.


**037.** `20:07` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Opening all my drunken amazing shopping gifts lol

*📎 1 attachment(s)*

**038.** `20:07` **You**

She looks really happy


**039.** `20:08` **Meredith Lamb (+14169386001)**

She is… very\. But only because I gave her a heads up lol


**040.** `20:08` **Meredith Lamb (+14169386001)**

No one figured it out and I didn’t tell anyone


**041.** `20:09` **You**

She genuinely acted
Surprised
In video\.\.
Good actress lol


**042.** `20:10` **You**

80 is a big year and she looks great\.\.  I am glad you were able
To do this\.\. these kinds
Of memories matter
Most\.


**043.** `20:28` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**044.** `20:28` **Meredith Lamb (+14169386001)**

I got her this book to work her brain lol


**045.** `20:28` **You**

I see where you get your smile from 😃


**046.** `20:29` **You**

Was your dad happy too


**047.** `20:32` **Meredith Lamb (+14169386001)**

Yes he’s having a great time


**048.** `20:33` **Meredith Lamb (+14169386001)**

Strong silent type\.

*📎 1 attachment(s)*

**049.** `20:33` **You**

Awesome sounds like you nailed it ❤️


**050.** `20:34` **You**

He still looks happy


**051.** `20:34` **Meredith Lamb (+14169386001)**

She just read the\. She of the book out loud lol

*📎 1 attachment(s)*

**052.** `20:35` **You**

Did you come up with all this yourself?


**053.** `20:38` **Meredith Lamb (+14169386001)**

Yes wed night when I was drinking and talking to you


**054.** `20:44` **You**

They are pretty brilliant\.\. and thoughtful and funny\.


**055.** `20:45` **You**

Sounds like you\.\. you are so notch more extra than me\.


**056.** `20:45` **You**

Much


**057.** `20:46` **You**

Reaction: ❤️ from Meredith Lamb
Next year maybe I can attend\.


**058.** `20:55` **Meredith Lamb (+14169386001)**

She liked the soft stuff I got her the best probably bc she is sick\. Got her soft lounge wear, pjs, blankets\. All in a smaller size bc she is small now and didn’t buy new clothes


**059.** `20:57` **You**

Quality of life and comfort\.\. but don’t kid yourself she just just like it because it is soft and functional\.\. she loves it because it is from yku most of all I think\.  And she likely appreciates that the most\.


**060.** `21:10` **Meredith Lamb (+14169386001)**

How are you doing? Not bored?


**061.** `21:11` **You**

Just laying in bed pretty content enjoying your updates\. Thinking about you etc\.


**062.** `21:12` **You**

Nothing is wrong I am fine\.😌


**063.** `21:12` **Meredith Lamb (+14169386001)**

Good\. I am sorry we can’t hang out


**064.** `21:13` **Meredith Lamb (+14169386001)**

But the home videos are coming out


**065.** `21:13` **You**

Don’t apologize enjoy your night


**066.** `21:13` **You**

I didn’t think you were going to be able to anyways too difficult


**067.** `21:17` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**068.** `21:18` **You**

lol oldie cute


**069.** `23:33` **Meredith Lamb (+14169386001)**

Omg so tired I passed out\. I’m going to bed \(no one else is lol\) I love you \- hope your night has gone ok xo


