# Daily Conversation: 2025-05-05 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-05 |
| **Day** | Monday |
| **Week** | 4 |
| **Messages** | 402 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-05T00:26 - 2025-05-05T22:28 |

## 📝 Daily Summary

This day contains **402 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:26` **You**

Reaction: ❤️ from Meredith Lamb
I hope
You are sleeping ok\.\. love you more than anything\.\. see you later xoxo❤️\. The feelings will pass I promise\.  Anything I can do let
Me know\.


**002.** `04:53` **You**

Oooh it is nice and shiny this morning\.


**003.** `06:48` **You**

Feels good\.\. steam sauna shower and off
To work\.\.
See you there \.\. love you\.


**004.** `07:01` **Meredith Lamb (+14169386001)**

So much energy lol


**005.** `07:02` **Meredith Lamb (+14169386001)**

These are nice messages to wake up to ❤️❤️❤️


**006.** `07:02` **Meredith Lamb (+14169386001)**

Love you


**007.** `07:09` **You**

No pics this morning though too many dudes watching


**008.** `07:10` **You**

Just imagine with this energy if I was coming home to you instead
Of going to work\. Eesh… I mean… I don’t feel 46 😈


**009.** `07:11` **You**

It would be a nice wake up 😇


**010.** `08:02` **Meredith Lamb (+14169386001)**

>
I can imagine but then it’s all arghhhh lol

*💬 Reply*

**011.** `08:10` **You**

Well
You will have to imagine for a while\.


**012.** `08:10` **You**

So will I


**013.** `08:14` **You**

You just be running late thought you were in early this morning


**014.** `08:18` **Meredith Lamb (+14169386001)**

Kids…\.


**015.** `08:18` **Meredith Lamb (+14169386001)**

Just got here


**016.** `08:18` **You**

Ahh fun


**017.** `08:18` **Meredith Lamb (+14169386001)**

Maelle’s\. Bday


**018.** `08:19` **You**

Yeah I know I thought you were celebrating tomorrow… must be a 2 day affair lol\.


**019.** `13:38` **Meredith Lamb (+14169386001)**

Just had a 30 min mediator consultation with Andrew\. Very interesting


**020.** `13:40` **You**

Bet it was\.\. I had to make some difficult legal decisions today as well\.\.  giving a lot of trust to Jaimie\.


**021.** `13:49` **Meredith Lamb (+14169386001)**

When the mediator heard he made $600 last year and I made $150k she was like “you need legal advice on spousal”\. He wasn’t thrilled with that\.


**022.** `13:50` **You**

Rofl called it


**023.** `13:50` **You**

I am sure he is just texting Mike crazy


**024.** `13:51` **You**

Like


**025.** `13:52` **Meredith Lamb (+14169386001)**

He actually hasn’t texted so must be on a call


**026.** `13:52` **Meredith Lamb (+14169386001)**

Not sure


**027.** `16:04` **Meredith Lamb (+14169386001)**

I’m leaving early for bday dinner\. She’s allowed to do it tonight :p


**028.** `16:04` **You**

Cya


**029.** `16:16` **Meredith Lamb (+14169386001)**

Omg what is wrong


**030.** `16:32` **Meredith Lamb (+14169386001)**

Um Scott …


**031.** `16:33` **You**

I had a panic attack…\.\.


**032.** `16:33` **You**

I couldn’t stay


**033.** `16:34` **You**

It was building for about 3 hours


**034.** `16:34` **You**

I was already trying to leave before you told me anything


**035.** `16:35` **You**

And I didn’t want cote there


**036.** `16:35` **Meredith Lamb (+14169386001)**

Why didn’t you say anything?


**037.** `16:35` **Meredith Lamb (+14169386001)**

Are you ok now?


**038.** `16:35` **You**

What am I gonna say\.\.


**039.** `16:35` **You**

Hey team


**040.** `16:35` **Meredith Lamb (+14169386001)**

I meant to me


**041.** `16:35` **You**

About to lose my shit lol


**042.** `16:35` **You**

I don’t like doing that


**043.** `16:36` **Meredith Lamb (+14169386001)**

Do you think it is recent developments with Jaime or just everything?


**044.** `16:36` **You**

Not you


**045.** `16:36` **You**

Or bud


**046.** `16:36` **You**

Us


**047.** `16:37` **Meredith Lamb (+14169386001)**

Maybe go back on half an anxiety pill per day


**048.** `16:37` **You**

It won’t help and I don’t like how it makes me feel


**049.** `16:38` **You**

Or not feel


**050.** `16:38` **Meredith Lamb (+14169386001)**

But maybe for a month or two you need that


**051.** `16:38` **You**

I will go numb


**052.** `16:39` **Meredith Lamb (+14169386001)**

I get it but survival


**053.** `16:39` **You**

You won’t like me…


**054.** `16:40` **Meredith Lamb (+14169386001)**

I will hardly get to see you anyway\. I will like you, love you just the same


**055.** `16:42` **You**

Before I do that I am going to try something else tomorrow\.


**056.** `16:42` **Meredith Lamb (+14169386001)**

I’m not conditional right now\.


**057.** `16:43` **You**

I know


**058.** `16:43` **You**

Don’t worry about me I will be fine I just needed to leave


**059.** `16:44` **You**

Just go have a good time with your fam tonight\.\. I will find something to keep me
Occupied


**060.** `16:44` **Meredith Lamb (+14169386001)**

I will of course worry about especially when you practically run away suddenly


**061.** `16:45` **You**

I don’t want people to see me like that


**062.** `16:45` **You**

It’s fine I will manage it\.\. just please focus on your night\.


**063.** `16:47` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/7vRriwrloYVaoAe3a9wJHe?si=mLaVXTHYQYeCHF4qFlDSWg
Don’t listen if you don’t want deep\. Listening right now


**064.** `16:47` **Meredith Lamb (+14169386001)**

Just a good song


**065.** `16:47` **Meredith Lamb (+14169386001)**

>
I plan to get caught up in work tonight actually after dinner

*💬 Reply*

**066.** `16:48` **Meredith Lamb (+14169386001)**

You should go for a walk somewhere calm\. Not the gym


**067.** `16:48` **You**

Not sure yet will figure it out later


**068.** `16:48` **You**

Got things I have to do though


**069.** `16:53` **Meredith Lamb (+14169386001)**

Is there anything i can do?


**070.** `16:54` **You**

Nope


**071.** `16:56` **You**

Focus on you and yours mer you have more than enough on your own plate\.


**072.** `16:56` **You**

I don’t think there is anything you could do anyways\.


**073.** `16:58` **Meredith Lamb (+14169386001)**

Maybe in person… 😕


**074.** `16:59` **You**

U can’t do that either


**075.** `17:00` **You**

I me\. I just have to get used to the fact that we aren’t going to see each other again for months\. But that is separate from today\.


**076.** `17:01` **Meredith Lamb (+14169386001)**

I don’t think we can do “months”\. We will figure it out\.


**077.** `17:04` **Meredith Lamb (+14169386001)**

Our mediator that we just secured told us 3 weeks to a separation agreement\.


**078.** `17:04` **Meredith Lamb (+14169386001)**

Then I move out\.


**079.** `17:04` **You**

Congrats… light at the end of the tunnel for you\.


**080.** `18:06` **Meredith Lamb (+14169386001)**

How are you doing? \(For real\)


**081.** `18:07` **You**

Mer pls\.\. hun I feel really guilty for distracting you please be with your family tonight\.


**082.** `18:07` **Meredith Lamb (+14169386001)**

Mac and Maelle going to volleyball\.


**083.** `18:08` **You**

What happened to not doing that and having the party


**084.** `18:08` **Meredith Lamb (+14169386001)**

We had dinner, cake, she opened gifts\. Pretty much done so they are both going to volleyball


**085.** `18:08` **You**

ah ok\.\. well I hope she had fun and she enjoyed her gifts etc\.


**086.** `18:09` **Meredith Lamb (+14169386001)**

Yes she did of course\. Gifts = always good\. Lol


**087.** `18:10` **Meredith Lamb (+14169386001)**

So answer my original question


**088.** `18:10` **You**

fack


**089.** `18:10` **You**

why can't I skip over questions I don't want to answer


**090.** `18:10` **You**

you get to


**091.** `18:10` **You**

lol


**092.** `18:10` **Meredith Lamb (+14169386001)**

You don’t have my skill level in that area


**093.** `18:10` **You**

pshh


**094.** `18:10` **Meredith Lamb (+14169386001)**

Thems the breaks


**095.** `18:11` **You**

Ok\.\. so here is the thing\.\. I ate last night \- went to the gym, went hard\.\. came home\.\. had my shake\.\. woke up 5 hours later\.\. another hard workout another shake and then nothing\.


**096.** `18:11` **You**

So


**097.** `18:11` **You**

I probably crashed


**098.** `18:11` **You**

I should have eaten\.\.


**099.** `18:12` **Meredith Lamb (+14169386001)**

Uh, yeah


**100.** `18:12` **You**

So there you go no harm no foul


**101.** `18:12` **You**

case closed


**102.** `18:12` **Meredith Lamb (+14169386001)**

Errrrrr


**103.** `18:12` **Meredith Lamb (+14169386001)**

That sounds like a teen explanation


**104.** `18:12` **You**

I feel like it holds its own


**105.** `18:13` **You**

outside of that


**106.** `18:13` **Meredith Lamb (+14169386001)**

So did you eat tonight?


**107.** `18:13` **You**

there is an ache that won't go away no matter what I do\.


**108.** `18:13` **You**

I cannot help it\.\.  it isn't me trying to feel that way\.\. I cannot think it away


**109.** `18:13` **You**

I cannot ignore it


**110.** `18:13` **You**

But that wasn't the crash


**111.** `18:13` **You**

or the reason for it


**112.** `18:14` **Meredith Lamb (+14169386001)**

Yeah I have that also\.


**113.** `18:14` **You**

but you were going to push and bug me until I admitted it


**114.** `18:14` **Meredith Lamb (+14169386001)**

A crash and panic attack are different


**115.** `18:14` **You**

Felt the same


**116.** `18:14` **You**

scarily


**117.** `18:15` **You**

You guys were occupied\.\. I just wanted to bolt with no one noticing


**118.** `18:15` **You**

just sec grabbing food 2 mins\.


**119.** `18:15` **Meredith Lamb (+14169386001)**

Carolyn and Michelle didn’t notice actually\. Strange


**120.** `18:15` **Meredith Lamb (+14169386001)**

kk


**121.** `18:19` **You**

good


**122.** `18:19` **You**

glad


**123.** `18:20` **You**

anyhow\.\. the ache thing is torture\.\. I try to ignore but it doesn't want to go away\.\. so I am not sure what to do tbh\.


**124.** `18:21` **You**

like i said this is my problem


**125.** `18:21` **You**

not yours


**126.** `18:21` **Meredith Lamb (+14169386001)**

Whatever it is my problem too


**127.** `18:22` **You**

not the fact that I cannot deal


**128.** `18:22` **Meredith Lamb (+14169386001)**

I have been very much struggling since our weekend together\.


**129.** `18:22` **You**

i wasn't suggesting you weren't hon


**130.** `18:22` **You**

at all


**131.** `18:22` **Meredith Lamb (+14169386001)**

Just saying it is both of our problems


**132.** `18:22` **Meredith Lamb (+14169386001)**

Unfortunately


**133.** `18:23` **You**

well I cannot get a handle on it\.\. so just going to have to find some way to deal\.\. somehow\.\. I will just keep on trying to figure something out\.\. eventually


**134.** `18:25` **Meredith Lamb (+14169386001)**

We will plan the next time we see each other\. Maybe that will help


**135.** `18:26` **You**

you know we cannot do that\.\. too far out\.


**136.** `18:26` **Meredith Lamb (+14169386001)**

Doesn’t matter\. Is what it is


**137.** `18:27` **Meredith Lamb (+14169386001)**

We might be able to get creative


**138.** `18:27` **You**

there are too many risks\.\. and I don't want anything happening that could hurt you in any way


**139.** `18:27` **Meredith Lamb (+14169386001)**

Honestly, I feel the ache too entirely\. Everything in my body wants more from that weekend…


**140.** `18:28` **Meredith Lamb (+14169386001)**

I’m sure we can figure something out


**141.** `18:28` **Meredith Lamb (+14169386001)**

I will ask ChatGPT lol


**142.** `18:28` **You**

Have at it\.\. it didn't help me very much\.


**143.** `18:30` **You**

Look I know you are trying to be optimistic and cheer me up and yes mer\.\. no matter how shitty I feel right now, I am still 100% in this for the long haul\.\. but I don't have much hope for the near to medium term\.


**144.** `18:31` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
😭


**145.** `18:31` **You**

>
Sorry but you know it too you said it earlier

*💬 Reply*

**146.** `18:32` **Meredith Lamb (+14169386001)**

I mean I’ve been more focusing on bdays and separation crap so didn’t fully think about something short term\. I’m sure if I thought hard enough I could come up with something\. Might not be great but could be sufficient lol


**147.** `18:33` **You**

Again you have too much on the go\.\. separation, finding a place, kids all the time, little shadows tracking you, etc\.


**148.** `18:34` **Meredith Lamb (+14169386001)**

Stop


**149.** `18:34` **You**

I am not doing anything


**150.** `18:34` **Meredith Lamb (+14169386001)**

I don’t like reading it


**151.** `18:34` **You**

this isn't moping


**152.** `18:34` **You**

this is stating facts


**153.** `18:34` **You**

and the problem is


**154.** `18:34` **Meredith Lamb (+14169386001)**

I know…


**155.** `18:34` **You**

it builds expectation


**156.** `18:34` **You**

which leads to hope


**157.** `18:34` **You**

which leads tooooooooooo\.\.\.\.


**158.** `18:34` **You**

what?


**159.** `18:35` **Meredith Lamb (+14169386001)**

The funny thing is that I feel like I knew this would happen\.


**160.** `18:35` **Meredith Lamb (+14169386001)**

🤔


**161.** `18:35` **You**

You did


**162.** `18:35` **You**

you told me so


**163.** `18:35` **Meredith Lamb (+14169386001)**

I know…


**164.** `18:35` **You**

You don't even have to say it I will


**165.** `18:35` **You**

It doesn't matter\.\. like you said it is what it is\.\. changes nothing\.


**166.** `18:35` **You**

not for me


**167.** `18:36` **Meredith Lamb (+14169386001)**

But everything has changed\. Everything is harder now\. More heavy\.


**168.** `18:36` **You**

For now\.\. yeah\.


**169.** `18:37` **You**

I know you aren't giving up\.\. neither am I\.\. we don't have a lot of choices


**170.** `18:37` **You**

I would never give up on this no matter how heavy or shitty it got


**171.** `18:37` **You**

so please if you brain takes you there shut it down


**172.** `18:38` **You**

Again\.\. if it sucked, or was awkward, or was meh\.\. that weekend would be easy\.\. like\.\.\. well first time\.\. let's give it some time\.\. we will get there\.\.


**173.** `18:38` **You**

but it wasn't


**174.** `18:38` **You**

at all


**175.** `18:39` **You**

anyway I am done typing\. because now you are just listening again


**176.** `18:39` **Meredith Lamb (+14169386001)**

I am letting you finish your thoughts lol


**177.** `18:39` **Meredith Lamb (+14169386001)**

It’s called respect


**178.** `18:39` **Meredith Lamb (+14169386001)**

😋


**179.** `18:39` **You**

>
oh\.\.\. that is what it is\.\. mmmm hhhmmmmm

*💬 Reply*

**180.** `18:40` **Meredith Lamb (+14169386001)**

For the record my brain has not taken me to giving up ever\. Not even one time\. But today was concerning\.


**181.** `18:41` **You**

no I meant don't let your brain let you think I would


**182.** `18:41` **Meredith Lamb (+14169386001)**

Oh well, if you start having panic attacks everyday :p


**183.** `18:41` **Meredith Lamb (+14169386001)**

Your brain might tell you to


**184.** `18:42` **You**

mer\.\.\.


**185.** `18:42` **You**

like\.\. how many times in how many ways do I need to say this\.


**186.** `18:42` **Meredith Lamb (+14169386001)**

>
I think the fact that it was a little too perfect is causing this to be way more overload…\.

*💬 Reply*

**187.** `18:42` **You**

there is no one on earth that I want to spend the rest of my life with but you, and I know that in the years we have known each other, and the months we have fallen in love\.


**188.** `18:43` **Meredith Lamb (+14169386001)**

>
I’m just saying you haven’t had panic attacks everyday for a week yet

*💬 Reply*

**189.** `18:43` **You**

Reaction: ❤️ from Meredith Lamb
I cannot say it more plainly than that\.\. and I believe it\.\. and it is what it is\.


**190.** `18:43` **You**

If it got bad I would go back on medication\.


**191.** `18:43` **You**

there is nothing for the ache though\.


**192.** `18:43` **You**

sorry


**193.** `18:44` **Meredith Lamb (+14169386001)**

Were you upset that I didn’t do the park thing this morning?


**194.** `18:44` **You**

like that is what this is to me\.\. it is everything\.\. it is also just very painful atm


**195.** `18:44` **You**

nope\.\. you had shit to do\.\. I figured we would try that sometime whenever you figure out what you want to do\.


**196.** `18:45` **You**

I didn't bank on it anytime soon\.


**197.** `18:45` **You**

But\.\.


**198.** `18:45` **You**

and I will be honest


**199.** `18:45` **Meredith Lamb (+14169386001)**

k, I thought maybe you were


**200.** `18:45` **You**

I don't want to suggest anything else\.\. because it is difficult to constantly be putting that out there\.\. like it just is\.\. nothing other than that\.


**201.** `18:46` **Meredith Lamb (+14169386001)**

You deleted and rewrote


**202.** `18:46` **You**

no


**203.** `18:46` **You**

I wanted to make sure it was written in such a way that it didn't make you mad\.\. or anyting


**204.** `18:46` **You**

but that is what I was writing\.


**205.** `18:47` **Meredith Lamb (+14169386001)**

You don’t want to suggest anything else? Wdym


**206.** `18:47` **You**

Like throwing ideas out to connect\.\. they never seem to happen\.\. so I just gonna stop for a bit\.\. draining\.


**207.** `18:47` **Meredith Lamb (+14169386001)**

Ah gotcha


**208.** `18:48` **Meredith Lamb (+14169386001)**

I’m sorry


**209.** `18:48` **You**

again\.\. it isn't your fault I don't blame you\.


**210.** `18:48` **You**

but still it takes energy\.\. and like I said earlier it leads to expectations and hope and\.\.\.\.\.


**211.** `18:48` **You**

so like I am just going to chill for a while I think\.


**212.** `18:49` **Meredith Lamb (+14169386001)**

Yes please do\. I feel so overloaded right now so really would like for you to chill\. I’m not going anywhere


**213.** `18:49` **You**

now you deleted


**214.** `18:49` **Meredith Lamb (+14169386001)**

I didn’t delete


**215.** `18:49` **You**

>
kk

*💬 Reply*

**216.** `18:50` **Meredith Lamb (+14169386001)**

I will try to suggest something soon so just wait for me


**217.** `18:50` **You**

Not going anywhere Mer\.\. will be in that office again tomorrow morning\.


**218.** `18:51` **Meredith Lamb (+14169386001)**

I know but things felt incredibly off today


**219.** `18:52` **You**

Mer, it is difficult\.\. if I start joking with you I see how awesome you are\.\. and I feel good for a minute\.\.


**220.** `18:52` **You**

it was easier to walk away today\.\. and to be more curt\.


**221.** `18:52` **You**

I hated it


**222.** `18:52` **You**

it hurt but I think maybe it hurt less


**223.** `18:53` **You**

I still don't like it I don't think I can keep doing it anyways


**224.** `18:53` **You**

so I don't even know what to od


**225.** `18:53` **Meredith Lamb (+14169386001)**

😵‍💫


**226.** `18:54` **You**

this isn't easy\.\. and I am not trying to make this hard\.\. I don't know what it is you do\.\. but I cannot do that\.


**227.** `18:54` **You**

I am not saying you don't feel but you handle it


**228.** `18:54` **Meredith Lamb (+14169386001)**

I mean we can’t go home together, can’t be together so we have no choice really


**229.** `18:55` **Meredith Lamb (+14169386001)**

I was looking forward to seeing you but felt concerned all day


**230.** `18:55` **Meredith Lamb (+14169386001)**

Basically


**231.** `18:55` **You**

Ok\.\. Mer I won't do that anymore\.


**232.** `18:55` **Meredith Lamb (+14169386001)**

Go back on anxiety meds for a WHILE


**233.** `18:55` **You**

I was just don't know what to do\. the ache just never stops


**234.** `18:56` **You**

I mean it sounds like you want me to just turn my emotions back off\.\. lol\.  I am not sure meds can do that\.


**235.** `18:56` **You**

I know the old me would have been much easier though


**236.** `18:56` **Meredith Lamb (+14169386001)**

I mean you were fine before


**237.** `18:57` **Meredith Lamb (+14169386001)**

Then you go off them and start to get all antsy


**238.** `18:57` **You**

I will go to the doctor tomorrow\.


**239.** `18:57` **Meredith Lamb (+14169386001)**

I get the ache too entirely … I have that too\. But you need to survive


**240.** `18:57` **You**

Get back on fluoxotine


**241.** `18:59` **Meredith Lamb (+14169386001)**

I take a really tiny bit of cipralex a day


**242.** `18:59` **Meredith Lamb (+14169386001)**

Google it vs yours


**243.** `18:59` **You**

I know what that is


**244.** `18:59` **You**

I have about 500 pills here


**245.** `18:59` **Meredith Lamb (+14169386001)**

I used to take more when the crap happened


**246.** `18:59` **You**

between gracie and jaimie


**247.** `18:59` **You**

and maddie


**248.** `18:59` **Meredith Lamb (+14169386001)**

Now I am just paranoid to go off completely


**249.** `19:00` **Meredith Lamb (+14169386001)**

And now you are making me more paranoid\.


**250.** `19:00` **Meredith Lamb (+14169386001)**

I will go off entirely when I’m more settled


**251.** `19:00` **You**

mer if we were together right now\.\. I wouldn't need anything\.\. I know that\.


**252.** `19:00` **Meredith Lamb (+14169386001)**

Same


**253.** `19:02` **Meredith Lamb (+14169386001)**

My ChatGPT letter made you laugh tho didn’t it


**254.** `19:02` **You**

a little\.\.


**255.** `19:02` **You**

it was funny


**256.** `19:02` **Meredith Lamb (+14169386001)**

lol


**257.** `19:02` **You**

I just wasn't laughy


**258.** `19:02` **Meredith Lamb (+14169386001)**

Oh come on


**259.** `19:02` **Meredith Lamb (+14169386001)**

It so was


**260.** `19:02` **Meredith Lamb (+14169386001)**

It was hilarious


**261.** `19:02` **You**

took me a lot to get through that meeting


**262.** `19:02` **You**

I was really irritated


**263.** `19:02` **Meredith Lamb (+14169386001)**

I could tell


**264.** `19:03` **You**

look if I hadn't gone to that meeting \- they wouldn't have come off their targets at all


**265.** `19:03` **You**

that was stupid


**266.** `19:03` **You**

I don't know how Haris didn't see what would happen


**267.** `19:03` **Meredith Lamb (+14169386001)**

Well it was an early meeting to get them thinking bc we figured they wouldn’t know


**268.** `19:03` **You**

I know jacky was trying


**269.** `19:03` **You**

I appreciated that


**270.** `19:03` **Meredith Lamb (+14169386001)**

Still 2 weeks until oc


**271.** `19:04` **You**

but they needed to be smacked


**272.** `19:04` **Meredith Lamb (+14169386001)**

Talked to Michael y after and he is going to relook


**273.** `19:05` **You**

God I have literally nothing tomorrow\.\.\. maybe stay home\.\.\. not sure that'd be better\.


**274.** `19:05` **Meredith Lamb (+14169386001)**

What’s worse… what you are feeling or feeling nothing


**275.** `19:05` **You**

If the good feelings went I would hate myself\.


**276.** `19:05` **You**

I haven't had them in so long\.


**277.** `19:06` **You**

jesus\.\. no I wouldn't be happy at all I suspect


**278.** `19:06` **You**

still going to do it\.


**279.** `19:06` **Meredith Lamb (+14169386001)**

Do what


**280.** `19:06` **You**

take the drug


**281.** `19:07` **Meredith Lamb (+14169386001)**

I think you should for a while at the very least


**282.** `19:07` **Meredith Lamb (+14169386001)**

This is a lot


**283.** `19:07` **You**

It just makes me sad to think about it but w/e


**284.** `19:07` **You**

not much of a choice


**285.** `19:07` **Meredith Lamb (+14169386001)**

We both have these crumbling lives \+ this secretive thing\. It’s a lot


**286.** `19:08` **You**

I don't think this will help\.\. I was having these feelings even when I was on it\.


**287.** `19:08` **You**

part of why I quit


**288.** `19:09` **Meredith Lamb (+14169386001)**

Then maybe don’t overdo it at the gym? Like 2x per day etc


**289.** `19:09` **Meredith Lamb (+14169386001)**

I mean there are probably contributing factors


**290.** `19:09` **Meredith Lamb (+14169386001)**

Not one thing


**291.** `19:09` **You**

maybe\.\. I dunno\.\. I just know i have shit to do because no one else will\.\. and i feel how i feel and no drug is touching that\.


**292.** `19:11` **You**

look if it gets bad next time\.\. I will just leave before it gets to that point\./


**293.** `19:12` **You**

but I agree shit is not going to change\.\. it will hurt and ache and suck for a long time\.\. I just have to get through\.


**294.** `19:12` **Meredith Lamb (+14169386001)**

Ugh, I wish we could lie together …\.


**295.** `19:12` **You**

ditto\.\. and as much as I love thinking about it\.\. and can remember insane details\.\. I try not to\.


**296.** `19:14` **Meredith Lamb (+14169386001)**

I’m kinda the same


**297.** `19:15` **Meredith Lamb (+14169386001)**

It is an odd feeling to miss something so much that we only really had for 4 days … and not even full time lol


**298.** `19:16` **You**

but see that isn't just it\.\. even absent that time\.\. I would still be frustrated and lonely, and achy\.\. even if all we had was the back of the car that first time\.


**299.** `19:16` **You**

that was enough\.\.


**300.** `19:17` **You**

I was in love before the car\.\. after I was convinced something different was going on\.


**301.** `19:17` **You**

so while it makes it harder probably because there was something very tangible and now we cannot have any of it\.\. I sitll would have felt incomplete\.


**302.** `19:20` **Meredith Lamb (+14169386001)**

It likely wouldn’t be as intense\.


**303.** `19:20` **You**

maybe not\.\. maybe it would be\.\. it was getting awful intense before the weekend


**304.** `19:22` **Meredith Lamb (+14169386001)**

True enough but the weekend solidified something for me\. Just the time together…\.\.  \(Not talking sex necessarily…\)


**305.** `19:22` **You**

Agreed and it was a lot more than just sex\.\. agreed\.


**306.** `19:22` **You**

like even the sex wasn't that to me\.\.


**307.** `19:22` **Meredith Lamb (+14169386001)**

Definitely fell in love with you before the weekend also tho


**308.** `19:23` **Meredith Lamb (+14169386001)**

>
Same, I know what you mean

*💬 Reply*

**309.** `19:24` **You**

anyhow let's not talk about the weekend anymore\.\. magical and rainbows and unicorns\.\. lol and real as hell and as perfect as I could expect it to be\.\. and it reflects what can be\.\. but honestly the more I think about it the more everything sucks\.


**310.** `19:25` **Meredith Lamb (+14169386001)**

Sure but we were lucky really


**311.** `19:25` **You**

this whole think has been luck


**312.** `19:25` **You**

or fate


**313.** `19:25` **You**

pick whatever you believe in


**314.** `19:25` **Meredith Lamb (+14169386001)**

Fate


**315.** `19:25` **You**

that is what I think\.\. but I never would have before


**316.** `19:26` **You**

but fate does suck a bit\.


**317.** `19:26` **You**

it could have fucking waited like 4 more months


**318.** `19:26` **You**

lol


**319.** `19:26` **Meredith Lamb (+14169386001)**

LOL


**320.** `19:26` **You**

but then


**321.** `19:27` **You**

all the emotion and stuff and urgency and connection etc\.\. wouldn't be the same


**322.** `19:27` **You**

oh I still think we would have gotten to the same place


**323.** `19:27` **You**

but this is memorable and unique to me


**324.** `19:27` **Meredith Lamb (+14169386001)**

I honestly think this was my fault\. If I never told you about the text that day on our one on one I don’t see this happening


**325.** `19:27` **You**

not ever or not now\.


**326.** `19:27` **You**

you might be right


**327.** `19:27` **Meredith Lamb (+14169386001)**

Not now


**328.** `19:28` **You**

like I said I was going this way anyways


**329.** `19:28` **You**

we would have connected the dots eventually


**330.** `19:28` **You**

and then\.\. same thing happens\.


**331.** `19:28` **You**

I bet\.\.


**332.** `19:28` **Meredith Lamb (+14169386001)**

Probably\. Just different timing


**333.** `19:29` **You**

it still would have been too early\.


**334.** `19:29` **You**

my bet


**335.** `19:29` **Meredith Lamb (+14169386001)**

Not sure tho\. We kind of connected over my messed up life


**336.** `19:29` **Meredith Lamb (+14169386001)**

lol


**337.** `19:29` **You**

well I am ok if you take the blame for the kickoff \- but I am fairly certain I jumped off the cliff after you\.


**338.** `19:30` **Meredith Lamb (+14169386001)**

Yep you definitely did


**339.** `19:30` **Meredith Lamb (+14169386001)**

\(Thanks\)


**340.** `19:30` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
💕


**341.** `19:30` **You**

oh yeah cause I made everything super easy for everyone LOL


**342.** `19:31` **Meredith Lamb (+14169386001)**

Super easy or super interesting?


**343.** `19:31` **You**

Reaction: 😂 from Meredith Lamb
let's fall madly insanely in love, have an absolute soul crushing weekend, then go into limbo for 4 months while our lives explode all over everything, and oh yeah you work on my team\.


**344.** `19:31` **You**

i mean\.\. wtf


**345.** `19:32` **Meredith Lamb (+14169386001)**

Well when you put it like that


**346.** `19:32` **Meredith Lamb (+14169386001)**

lol


**347.** `19:33` **Meredith Lamb (+14169386001)**

I think if there are 2 ppl that are well suited to this situation and can handle it, it is us\.


**348.** `19:33` **Meredith Lamb (+14169386001)**

LOL


**349.** `19:33` **Meredith Lamb (+14169386001)**

NOT\. that was sarcasm


**350.** `19:34` **You**

yeah I don't feel suited


**351.** `19:34` **You**

old me yes


**352.** `19:34` **You**

Reaction: 💋 from Meredith Lamb
new me\.\. he sucks and is a big fucking baby\.


**353.** `19:36` **You**

no he is not cool\.\. he wants to kill me\.


**354.** `19:36` **You**

lke 20 years worth of pent up emotion/


**355.** `19:36` **You**

seriously mer you are going to have to try to be patient with me\.\. I know I am going to have a really really hard time these next few months\.


**356.** `19:37` **Meredith Lamb (+14169386001)**

I know… :\(


**357.** `19:38` **You**

In my head I thought we would be past this whole thing in like 2 months\.\. and we could find a bit of time every week to try to take the edge off\.\. but lol it feels more like we are about to enter a 3\-4 week dry spell\.\.\.


**358.** `19:39` **You**

I will literally have to do something \- like figure out a way to shut down or something\.


**359.** `19:39` **Meredith Lamb (+14169386001)**

There must be another way


**360.** `19:40` **You**

no I don't know how to handle it\.\. and it is getting too bad\.\. like go back to the cold version of me somehow??


**361.** `19:40` **You**

at least he didn't feel it\.


**362.** `19:40` **You**

But that would basically be today


**363.** `19:40` **You**

but worse and all the time


**364.** `19:41` **Meredith Lamb (+14169386001)**

No don’t do that\. I didn’t like today


**365.** `19:41` **You**

:\(


**366.** `19:44` **Meredith Lamb (+14169386001)**

>
You are kind of scaring me a little\. I’m not going anywhere but genuinely concerned\.

*💬 Reply*

**367.** `19:44` **Meredith Lamb (+14169386001)**

I know this is messy but we are in it together\. You aren’t alone\.


**368.** `19:44` **You**

I know\.\. but it is like you said\.\. Survival mode right\.\.


**369.** `19:45` **Meredith Lamb (+14169386001)**

Right but when you say “it is getting too bad”…… 😥😢😥😢


**370.** `19:45` **You**

It is getting too bad to not see you, or not do something myself to deal with it\.


**371.** `19:46` **You**

not too bad to give up I already said there isn't bad enough that = that choice


**372.** `19:46` **You**

Listen I know what you want\.


**373.** `19:46` **Meredith Lamb (+14169386001)**

k well let’s try seeing each other this week …


**374.** `19:47` **Meredith Lamb (+14169386001)**

Even if in morning


**375.** `19:47` **You**

You want me to be this chill dude\.\. who can basically float along be happy all day \- chat here and there\.\. and hold my emotions in check until the time is right\.


**376.** `19:47` **You**

ROFL


**377.** `19:47` **You**

problem is I was an unemotional GIT for like 2 decades


**378.** `19:47` **You**

then you broke the hoover damn


**379.** `19:47` **Meredith Lamb (+14169386001)**

I honestly just want you to be honest and real


**380.** `19:48` **Meredith Lamb (+14169386001)**

If that is not chill, so be it


**381.** `19:48` **You**

I am but that is pain, and ache and longing


**382.** `19:48` **You**

so


**383.** `19:48` **You**

not cool


**384.** `19:48` **Meredith Lamb (+14169386001)**

That’s ok\. I have that too


**385.** `19:48` **You**

But I have let it define me\.\. and I don't know how to make it go the fuck away\.


**386.** `19:49` **Meredith Lamb (+14169386001)**

We just need time together\. Real time


**387.** `19:50` **You**

Yeah I know Mer but that isn't coming for months\.\. so I am just trying to solve this\.\. maybe there is something I haven't thought of yet\.\. I am not giving up\.


**388.** `19:51` **You**

But I mean I know we need time together\.\. we just aren't going to get it\.  So I don't even think about it because I know it won't happen\.


**389.** `19:52` **You**

and by solve this I mean me


**390.** `19:52` **You**

not time\.\.


**391.** `19:52` **You**

I cannot solve that


**392.** `19:52` **Meredith Lamb (+14169386001)**

It will happen\.


**393.** `19:52` **Meredith Lamb (+14169386001)**

Just not sure when exactly


**394.** `19:53` **You**

I love you Mer\.\. I will do whatever I have to, to get through this\.\. it just won't be pretty\.\. and I will likely be a lot messy by the end of it\.


**395.** `19:54` **Meredith Lamb (+14169386001)**

Yeah we both will\. :p


**396.** `21:02` **You**

not sure how long I am going to stay up tonight J and I have been fighting again \- not really bad but again it is the stress of it all\.


**397.** `21:03` **You**

I had to go upstairs to do some shit and I figured you had gone off to take care of some stuff when I got back anyways\.\. may be here or not\.\. not sure\.\. still doing some work \- if I can respond I will\.


**398.** `21:35` **Meredith Lamb (+14169386001)**

Fell asleep watching tv\. Tired\. Going to go to bed early xoxox miss you so much


**399.** `21:36` **You**

night xo ❤️


**400.** `21:41` **You**

Still not sure what my plan is tomorrow\.\. I will let you know in morning\.


**401.** `21:45` **Meredith Lamb (+14169386001)**

kk ❤️


**402.** `22:28` **You**

Bed now night love you\.  Going to gym first thing tomorrow not sure what else to do anyways I will be up and going early\.


