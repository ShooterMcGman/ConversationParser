# Daily Conversation: 2025-04-15 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-15 |
| **Day** | Tuesday |
| **Week** | 1 |
| **Messages** | 366 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-15T00:01 - 2025-04-15T23:56 |

## 📝 Daily Summary

This day contains **366 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:01` **You**

Gracie
Came
Down and yelled and
Cried a bit more…\. Ugggh as you would say


**002.** `00:02` **Meredith Lamb (+14169386001)**

That sounds worrisome


**003.** `00:03` **You**

Kk I am going to bed  I M coming in early again tomorrow\.\. again\. lol nite
Luv xoxoxoxoxo etc
Etc


**004.** `00:03` **You**

Nothing
For you to worry about


**005.** `00:03` **Meredith Lamb (+14169386001)**

Nite xo


**006.** `00:04` **You**

It’s good have good dreams
Tonight no bad o es


**007.** `00:05` **Meredith Lamb (+14169386001)**

I will go to sleep missing u which is weird bc I saw you all day\. Whatever\. Sweet dreams


**008.** `00:05` **You**

Same\.\. at
Least
I get
To
See
You in morning g\.  Night


**009.** `06:46` **You**

Morning sunshine see you at work\.


**010.** `06:49` **Meredith Lamb (+14169386001)**

❤️


**011.** `07:31` **Meredith Lamb (+14169386001)**

Just double checked with Mackenzie if it was ok if you were in Detroit\. She could care less\. Also doesn’t care if she happens to meet you\. Probably good if the parents don’t though\. lol


**012.** `07:31` **You**

I am glad because room was non refundable lol


**013.** `07:33` **Meredith Lamb (+14169386001)**

Really\. Weird\!


**014.** `07:33` **Meredith Lamb (+14169386001)**

I knew she’d be fine but seemed like the respectful thing to do lol


**015.** `07:36` **You**

Totally appropriate but I will be really nervous to meet her


**016.** `07:47` **Meredith Lamb (+14169386001)**

I would be too\. Kidding\!


**017.** `07:47` **Meredith Lamb (+14169386001)**

You will love her


**018.** `08:01` **Meredith Lamb (+14169386001)**

https://youtube\.com/watch?v=o92LrjPI\-HM&feature=shared


**019.** `08:01` **Meredith Lamb (+14169386001)**

Her in a nutshell


**020.** `08:02` **You**

Listen I have no doubt t I will she sounds like a big ball of fun\.


**021.** `08:02` **You**

A little like one of Maddies friends that I drove downtown last night\.


**022.** `08:02` **You**

Alright On my way\! In


**023.** `11:20` **You**

Rip Chatham…\.\. 🥲


**024.** `11:20` **Meredith Lamb (+14169386001)**

?


**025.** `11:22` **You**

Just trickier is it not\!? I was hoping to also spend the day with you on Sunday just chilling maybe walk around Detroit 😩


**026.** `11:22` **Meredith Lamb (+14169386001)**

We can… why can’t we?


**027.** `11:25` **Meredith Lamb (+14169386001)**

I do not need to go to volleyball\.


**028.** `11:25` **Meredith Lamb (+14169386001)**

I have watched sooooo much volleyball this year\. Mac doesn’t care\.


**029.** `12:02` **You**

I meant on Sunday night too right


**030.** `12:02` **You**

Greedy


**031.** `12:02` **You**

So
You would
Head back
Monday night I think\.


**032.** `12:03` **Meredith Lamb (+14169386001)**

Do you think Mac is going to want to hang out with me? Because she will not\.


**033.** `12:03` **Meredith Lamb (+14169386001)**

>
Not sure\.

*💬 Reply*

**034.** `12:05` **You**

Well we will roll with it,
All good 👍


**035.** `12:05` **Meredith Lamb (+14169386001)**

I will hang out whenever you want to


**036.** `12:09` **Meredith Lamb (+14169386001)**

Mac will have to do dinner with her team\. I don’t have to :\)


**037.** `13:53` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28075616/1002\-25\-broadway\-avenue\-toronto\-mount\-pleasant\-west\-mount\-pleasant\-west?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**038.** `13:54` **Meredith Lamb (+14169386001)**

Andrew said he’d put his name on my mortgage as a co\-owner to buy this place\.


**039.** `13:54` **You**

So you have a min to pop I


**040.** `13:54` **You**

Without being suspicious


**041.** `14:23` **Meredith Lamb (+14169386001)**

Ok, that was very surprising, sweet, emotional, hot… all the adjectives 🥵❤️‍🔥


**042.** `15:34` **You**

I won’t always have the energy to do these things life etc\.  I had thought of this the day you told me about your letters and had the idea to write one back gpt and I chatted for about an hour me directing and shaping the note\.\. they I rewrote most of it\.\.  it it helped 🙂\.  Honestly would pretty
Much do anything just to make you happy/smile\.  Ok all my emotional energy spent for the day\.\. lol\.


**043.** `18:00` **Meredith Lamb (+14169386001)**

I read it again more carefully in the car before going inside\. You’re killing me with this stuff\.


**044.** `18:01` **You**

I am sorry


**045.** `18:02` **You**

Coming on too strong I feel maybe


**046.** `18:02` **You**

Gah I will chill lol hard
To but I will
😊


**047.** `18:08` **Meredith Lamb (+14169386001)**

No you are not \-it is just really hard not to see you tonight after that\.


**048.** `18:10` **You**

Yeah I know sorry that isn’t my intention\.  I mean I would love to see you but I don’t want to cause any problems either\.  I think just thought about the idea and you and I just wanted to do it\.  But maybe I need to time things better


**049.** `18:13` **Meredith Lamb (+14169386001)**

lol no I love it, seriously\. I can be patient\.


**050.** `18:25` **You**

Hope so wish this could go faster


**051.** `19:09` **Meredith Lamb (+14169386001)**

Not to worry you or anything …\. :P

*📎 1 attachment(s)*

**052.** `19:22` **Meredith Lamb (+14169386001)**

Ps\. Andrew doesn’t think he will cancel\.


**053.** `20:19` **You**

Errrrrrrrrrrrr


**054.** `20:20` **Meredith Lamb (+14169386001)**

Don’t worry I will go regardless


**055.** `20:20` **Meredith Lamb (+14169386001)**

But Andrew is confident jay won’t cancel


**056.** `20:20` **You**

Well this is shitty nuclear bomb here tonight


**057.** `20:20` **Meredith Lamb (+14169386001)**

One of my good high school friends lives in Detroit so I will say I’m visiting lol she will cover for me


**058.** `20:21` **You**

I mean I do t want you to get in trouble at all for me\.\. ever…


**059.** `20:21` **You**

Sec
I need to go back in will catch you up later… nothing has changed further down the road\.


**060.** `20:21` **Meredith Lamb (+14169386001)**

>
Was wondering\. :\(

*💬 Reply*

**061.** `21:24` **Meredith Lamb (+14169386001)**

So we have had some intense convos tonight and I’m waiting to hear from you\. Getting super awkward here\. Waiting…\.


**062.** `21:49` **You**

Just read my letter repeatedly lol


**063.** `21:56` **You**

I am sort of back and available


**064.** `21:56` **You**

How was
Your night


**065.** `21:56` **You**

What intense conversations did you have


**066.** `21:57` **You**

I didn’t mean to make you wait btw but
We were going for four hours


**067.** `21:57` **Meredith Lamb (+14169386001)**

Ugh still ongoing and trying to end


**068.** `21:57` **Meredith Lamb (+14169386001)**

Literally now


**069.** `21:57` **You**

You or me


**070.** `21:57` **Meredith Lamb (+14169386001)**

Me


**071.** `21:57` **You**

Fack you too


**072.** `21:57` **You**

Shit


**073.** `21:57` **You**

Not good


**074.** `21:58` **You**

Should
I be worried too now


**075.** `21:58` **You**

Ackkkkkkkkkkkkkkk


**076.** `22:01` **Meredith Lamb (+14169386001)**

Omg no don’t be worried but like back to day 1 wtf


**077.** `22:02` **Meredith Lamb (+14169386001)**

This is insane


**078.** `22:02` **Meredith Lamb (+14169386001)**

What happened you?


**079.** `22:03` **Meredith Lamb (+14169386001)**

I just want to lie with you :\(


**080.** `22:04` **You**

Reaction: 😢 from Meredith Lamb
Jaimie and I fought Gracie found out for real went crazy maddie sat there\.
J got a bit mean and I finally responded\.  There was a lot I held
Back so it was a lot
For her to
Take I\. We basically shit on each other


**081.** `22:04` **You**

Back
To day 1 with Andrew


**082.** `22:04` **You**

Trying to convince you to stay again


**083.** `22:05` **Meredith Lamb (+14169386001)**

Yeah \.\.


**084.** `22:05` **You**

>
Just to cuddle fuck yeah some comfort for both would be nice

*💬 Reply*

**085.** `22:05` **Meredith Lamb (+14169386001)**

So nice


**086.** `22:06` **You**

So nothing g has changed on my side as I said \- further down the road


**087.** `22:06` **Meredith Lamb (+14169386001)**

I honestly dream of just kissing you head to toe\. If only…


**088.** `22:06` **You**

Meaning further ahead toward what I want with you\.  But sounds like you might
Have had a setback?


**089.** `22:06` **You**

Yeah I know this is fucking tough


**090.** `22:07` **You**

I have to hold everything in


**091.** `22:07` **You**

I even tried to be snarky with you today and felt like shit


**092.** `22:07` **Meredith Lamb (+14169386001)**

>
No setback\. He proposed keeping the house together with 2 units\. I said that would be weird\.

*💬 Reply*

**093.** `22:07` **You**

Oh living in same house but an official
Divide


**094.** `22:07` **Meredith Lamb (+14169386001)**

>
Really? When? I didn’t notice

*💬 Reply*

**095.** `22:08` **You**

Reaction: 😂 from Meredith Lamb
I always think am
I paying enough attention to Carolyn lol am I equally sarcastic
With not
lol


**096.** `22:08` **You**

Etc
Etc


**097.** `22:08` **Meredith Lamb (+14169386001)**

He talked about staying together\. I didn’t try hard enough blahblahblahblahvlahblah


**098.** `22:08` **You**

It
Isn’t hard it
Isn’t
A chore


**099.** `22:09` **You**

If
I could just see
You ffs lol,
Again I can do this you are worth it
Just
Venting


**100.** `22:09` **You**

J said same thing tonight


**101.** `22:09` **Meredith Lamb (+14169386001)**

I’m so tired of that…\.


**102.** `22:09` **You**

Yeah I know


**103.** `22:09` **Meredith Lamb (+14169386001)**

Exhausting


**104.** `22:10` **You**

I told her I tried
I explained what I did and why I did it


**105.** `22:10` **Meredith Lamb (+14169386001)**

When I explained it would be weird if we shared the same house, I said because he would be dating someone and I might…


**106.** `22:10` **Meredith Lamb (+14169386001)**

He goes “you said you would not?”


**107.** `22:11` **Meredith Lamb (+14169386001)**

😬


**108.** `22:11` **Meredith Lamb (+14169386001)**

lol


**109.** `22:13` **Meredith Lamb (+14169386001)**

Gahhhhhhhhhhhhh

*📎 1 attachment(s)*

**110.** `22:18` **You**

Well that is rough


**111.** `22:21` **You**

I thought he was relegated
To this what changed his mind


**112.** `22:21` **You**

Did his mum offer on the cottage?


**113.** `22:23` **Meredith Lamb (+14169386001)**

I think it is just too much time in the same space\. He is talking to his mom on Saturday\. If she says no I am reaching out to former owners of cottage and he is reaching out to a lake what’s app group\.


**114.** `22:24` **Meredith Lamb (+14169386001)**

I just really feel the need for a night with you\.\.


**115.** `22:24` **Meredith Lamb (+14169386001)**

:\(


**116.** `22:24` **Meredith Lamb (+14169386001)**

Why did you have a “nuclear bomb”?


**117.** `22:25` **You**

Because shit got real for real\.


**118.** `22:26` **You**

I stopped
Taking shit tonight


**119.** `22:26` **You**

And gave it back


**120.** `22:26` **Meredith Lamb (+14169386001)**

\(Ps\. I don’t care if you have a sleep apnea machine\. Lol\)


**121.** `22:26` **Meredith Lamb (+14169386001)**

>
Oh\.

*💬 Reply*

**122.** `22:26` **Meredith Lamb (+14169386001)**

Sounds intense\.


**123.** `22:26` **You**

>
Apnea machines are sexy\!

*💬 Reply*

**124.** `22:26` **You**

lol


**125.** `22:26` **Meredith Lamb (+14169386001)**

>
Indeed 💋

*💬 Reply*

**126.** `22:27` **Meredith Lamb (+14169386001)**

I also don’t care that you are bald and technically have a wife


**127.** `22:27` **Meredith Lamb (+14169386001)**

:P


**128.** `22:28` **You**

I mean also literally separates as in Ontario verbal separation is valid and leg


**129.** `22:28` **You**

Legal


**130.** `22:28` **You**

I checked


**131.** `22:28` **You**

Of course


**132.** `22:28` **Meredith Lamb (+14169386001)**

\(Even tho I’ve met her and she seems like a nice person\. Lol\)


**133.** `22:29` **You**

She is not a horrible person but we are not good together\.


**134.** `22:29` **Meredith Lamb (+14169386001)**

I know\. Andrew and I had this big conversation tonight\. Ugh I’m so done with it


**135.** `22:30` **Meredith Lamb (+14169386001)**

I just miss you\.


**136.** `22:30` **Meredith Lamb (+14169386001)**

It all makes me miss you


**137.** `22:31` **You**

same this sucks bad but there is a reason I gave you the letter right you can only read it so many times but it as tangible as
I can be atm\.


**138.** `22:31` **You**

I still wish we could
Find even 15 minutes for us before the long weekend but it
Might be too difficult\.
😞


**139.** `22:35` **Meredith Lamb (+14169386001)**

I know…


**140.** `22:37` **You**

You could always read my letter
To Andrew\.\.
Or your mother\!\! Better


**141.** `22:38` **Meredith Lamb (+14169386001)**

Andrew would be in disbelief\.


**142.** `22:38` **Meredith Lamb (+14169386001)**

He’s always thought I didn’t like hi\. As much as my ex\.


**143.** `22:38` **Meredith Lamb (+14169386001)**

\*him


**144.** `22:39` **You**

Well listen history is a tough competitor to ignore


**145.** `22:39` **Meredith Lamb (+14169386001)**

He just doesn’t understand how much he sucks\.


**146.** `22:39` **Meredith Lamb (+14169386001)**

It’s hard\.


**147.** `22:39` **You**

Especially since you were engaged and it was hard


**148.** `22:39` **Meredith Lamb (+14169386001)**

I told him AGAIN tonight to go to therapy


**149.** `22:40` **You**

Can I ask you a question


**150.** `22:40` **Meredith Lamb (+14169386001)**

Of course


**151.** `22:40` **You**

I cannot remember but I thought you told me you and your ex broke up because you didn’t want to have children at the time\.


**152.** `22:41` **Meredith Lamb (+14169386001)**

No… actually Andrew and I broke up for 6 months bc I wasn’t sure on the kid thing\.


**153.** `22:41` **Meredith Lamb (+14169386001)**

My ex and I never were in discussion on kids\.


**154.** `22:41` **Meredith Lamb (+14169386001)**

We broke up bc he was crazy lol


**155.** `22:41` **Meredith Lamb (+14169386001)**

Hahaha


**156.** `22:41` **Meredith Lamb (+14169386001)**

Like literally


**157.** `22:41` **You**

I mean i can see why you don’t like insecurities


**158.** `22:41` **You**

lol


**159.** `22:42` **Meredith Lamb (+14169386001)**

I dealt with 4 yrs of crazy\. But I was crazy too so……\.


**160.** `22:42` **Meredith Lamb (+14169386001)**

It worked for a time


**161.** `22:42` **Meredith Lamb (+14169386001)**

Then ran its course


**162.** `22:42` **You**

What is crazy btw just curious


**163.** `22:43` **Meredith Lamb (+14169386001)**

>
I don’t like YOUR insecurities because if you could see what I see, it would just be so different\.

*💬 Reply*

**164.** `22:44` **Meredith Lamb (+14169386001)**

>
Hmmh how to explain… just like all the craziness\. Substances, partying, just crazy adventurer \(too much for me\)

*💬 Reply*

**165.** `22:44` **You**

>
Yeah bald dude with a dad bod\.  lol I mean you are beautiful… I am
Plain\.\.
lol at least
I didn’t say ugly

*💬 Reply*

**166.** `22:44` **Meredith Lamb (+14169386001)**

Like motorcycle across Canada with a tent crazy


**167.** `22:44` **You**

Substances


**168.** `22:44` **You**

ROFL


**169.** `22:44` **You**

So you did have an adventure


**170.** `22:45` **Meredith Lamb (+14169386001)**

>
AGAIN, you don’t see what I see obviously\.

*💬 Reply*

**171.** `22:45` **Meredith Lamb (+14169386001)**

>
My 20s were a ride…\.

*💬 Reply*

**172.** `22:46` **You**

I am
Relatively comfortable with who I M but I am not
Anyone amazing\.  I am the one with the nice
Personality and the witty sense of humour\.
lol\.


**173.** `22:46` **You**

Reaction: 😴 from Meredith Lamb
>
My 20s were about settling\.

*💬 Reply*

**174.** `22:46` **You**

Well
22
On


**175.** `22:47` **Meredith Lamb (+14169386001)**

This came up in my time hop today\.

*📎 1 attachment(s)*

**176.** `22:48` **Meredith Lamb (+14169386001)**

That is my lawyer friend and 2 daughters and BALD husband\. Lol


**177.** `22:48` **You**

Well at
Least
She has good
Taste


**178.** `22:48` **You**

Mer I am
Giving you a hard time


**179.** `22:48` **Meredith Lamb (+14169386001)**

>
That’s okay\.

*💬 Reply*

**180.** `22:49` **You**

Not really I fucking missed out on sooo much


**181.** `22:49` **Meredith Lamb (+14169386001)**

Meh… not sure honestly


**182.** `22:49` **Meredith Lamb (+14169386001)**

You can make up for it now :\)


**183.** `22:50` **You**

I mean you had fun\.\. you don’t think I had a crazy friend like that\.\. lol I chose the safe route that I thought I was expected to take\.  I love my children and wouldn’t trade them
But j was the wrong choice for a bunch of different reasons


**184.** `22:51` **Meredith Lamb (+14169386001)**

What’d you guys argue about tonight?


**185.** `22:51` **You**

Reaction: ❤️ from Meredith Lamb
>
I am game if you are\.

*💬 Reply*

**186.** `22:51` **You**

>
Just blame

*💬 Reply*

**187.** `22:52` **You**

Again I decided to stop
Taking it


**188.** `22:52` **Meredith Lamb (+14169386001)**

>
Yeah…\.

*💬 Reply*

**189.** `22:52` **Meredith Lamb (+14169386001)**

Were the girls a part of this?


**190.** `22:52` **You**

Yes


**191.** `22:52` **Meredith Lamb (+14169386001)**

Or in their rooms


**192.** `22:52` **You**

No


**193.** `22:53` **Meredith Lamb (+14169386001)**

Oh yikes


**194.** `22:53` **You**

Gracie came down and had a caniotion fit


**195.** `22:53` **You**

Conniption fit


**196.** `22:53` **Meredith Lamb (+14169386001)**

My sister always used to say “conniption” lol


**197.** `22:54` **Meredith Lamb (+14169386001)**

So what is the main blame of you ?


**198.** `22:55` **You**

Cold and unfeeling, I always lied and told her it wasn’t
Her when it was\.  Etc etc


**199.** `22:55` **Meredith Lamb (+14169386001)**

Yeah I get that also\.


**200.** `22:55` **Meredith Lamb (+14169386001)**

Andrew thinks it will be “ironic” if I ever date anyone again


**201.** `22:56` **Meredith Lamb (+14169386001)**

I just ugh, it is hard being in the same house still


**202.** `22:56` **Meredith Lamb (+14169386001)**

Then he proposes staying here\. 2 units\. wtf


**203.** `22:56` **Meredith Lamb (+14169386001)**

How long have you been cold and unfeeling ?


**204.** `22:58` **You**

Since I was 18


**205.** `22:58` **Meredith Lamb (+14169386001)**

lol omg


**206.** `22:58` **You**

I mean let me clarify


**207.** `22:58` **You**

Reaction: 😢 from Meredith Lamb
How long have I been able to effectively repress
My emotions


**208.** `22:58` **You**

I clearly have emotions


**209.** `22:59` **You**

As you can read


**210.** `22:59` **You**

Or
Feel


**211.** `22:59` **You**

lol


**212.** `22:59` **Meredith Lamb (+14169386001)**

Yes very clearly\. Very very very\.
So change of topic\. What would we be doing if we were together alone right now?


**213.** `23:01` **You**

I mean I suspect a series of things\.  But I would be happy just
Knowing I could be there with you without having to worry that I have to leave or go anywhere etc


**214.** `23:02` **Meredith Lamb (+14169386001)**

That would be sooooo nice


**215.** `23:02` **You**

Yep\.\. it is so unfortunate we are x days away\.


**216.** `23:03` **You**

You should let
Me book your hotel for Chatham


**217.** `23:04` **You**

Tricky part


**218.** `23:04` **Meredith Lamb (+14169386001)**

Why?


**219.** `23:04` **Meredith Lamb (+14169386001)**

lol


**220.** `23:04` **You**

There are going to be people like Octavian there Sunday\. Ight


**221.** `23:04` **You**

And cote


**222.** `23:04` **You**

lol


**223.** `23:04` **Meredith Lamb (+14169386001)**

Yeah and my daughter


**224.** `23:04` **Meredith Lamb (+14169386001)**

lol


**225.** `23:04` **You**

Yep


**226.** `23:04` **You**

That is why i said rip
Chatham


**227.** `23:04` **Meredith Lamb (+14169386001)**

Nah she’s cool 😎


**228.** `23:05` **Meredith Lamb (+14169386001)**

lol


**229.** `23:05` **You**

But I figured if I could arrange our rooms
To be
Side by side


**230.** `23:05` **You**

Wellllllllllllllll


**231.** `23:05` **Meredith Lamb (+14169386001)**

I mean you could try


**232.** `23:05` **You**

Maybe I will reach out tomorrow morning\. Just to see


**233.** `23:06` **Meredith Lamb (+14169386001)**

Just don’t get anywhere near Michelle lol\!


**234.** `23:06` **Meredith Lamb (+14169386001)**

Retro is small tho


**235.** `23:07` **Meredith Lamb (+14169386001)**

Small and maze\-like


**236.** `23:07` **You**

Yeah I know\.\. I cannot guarantee we won’t be near anyone else\.\. we will still need to be sneaky


**237.** `23:08` **You**

lol this is the exciting adrenaline part for me\.\. but I don’t think you like it as
Much


**238.** `23:08` **You**

It might be better if retro is booked up then have an excuse to book elsewhere


**239.** `23:09` **Meredith Lamb (+14169386001)**

If be fine with that


**240.** `23:09` **Meredith Lamb (+14169386001)**

Retro isn’t that amazing


**241.** `23:09` **Meredith Lamb (+14169386001)**

I’d


**242.** `23:09` **You**

If I do book
You it
Is o my for o e night right with mac there I suspect you need
To get back Monday night


**243.** `23:09` **Meredith Lamb (+14169386001)**

Depends


**244.** `23:09` **You**

On?


**245.** `23:10` **Meredith Lamb (+14169386001)**

You basically\. That’s all\.


**246.** `23:11` **You**

What like I wouldn’t want
You there for two nights Jesus of course I would\.


**247.** `23:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I have completely fallen for you and would stay for more time with you… even though I know that might make things more challenging\. Worth it I suspect\.


**248.** `23:13` **You**

Yeah worth for me for sure\.


**249.** `23:13` **You**

I don’t things will be too challenging for too long


**250.** `23:14` **You**

Eventually we will find some flex


**251.** `23:14` **Meredith Lamb (+14169386001)**

My situation seems so stifling…\. I guess we will see how things evolve\.


**252.** `23:15` **You**

I have an idea


**253.** `23:16` **Meredith Lamb (+14169386001)**

So wait, you never said how your whole thing ended tonight?


**254.** `23:18` **You**

It just did I said there is nothing to be accomplished we have just pretty much hurt each other and the children we are not ready to have a discussion about moving forward clearly\.  I told her how the process works how typically there is legal involved but it can get complicated and expensive depending on how much we can agree on up front


**255.** `23:19` **You**

The\. She dropped another passive aggressive snarky comment and I said ok I am done for the night clearly\.  She is hurt and lashing out\.\. but she has been doing that for a week\.  She also says she had no idea


**256.** `23:20` **You**

I told my sister today we had separated she was supportive\.  I am being fairly quiet about us though\.  I did mention you to Mike\.


**257.** `23:21` **Meredith Lamb (+14169386001)**

>
NO idea?

*💬 Reply*

**258.** `23:22` **You**

Oops weird


**259.** `23:22` **You**

Sec


**260.** `23:22` **Meredith Lamb (+14169386001)**

>
We are living each others’ lives…\.\.

*💬 Reply*

**261.** `23:22` **You**

That this was coming


**262.** `23:22` **Meredith Lamb (+14169386001)**

Oh I see


**263.** `23:22` **You**

Yeah it sucks gracie is worries about me getting another family


**264.** `23:22` **Meredith Lamb (+14169386001)**

Aw


**265.** `23:23` **You**

That was an interesting part of the conversation


**266.** `23:23` **You**

How do I navigate that lol


**267.** `23:23` **Meredith Lamb (+14169386001)**

You say you are too old for that lol


**268.** `23:23` **Meredith Lamb (+14169386001)**

Haha


**269.** `23:23` **You**

I’m Gracie daddy is actually kind of insane about someone else


**270.** `23:23` **You**

I did say that I said I am so closed off how could anyone even want to be with me


**271.** `23:24` **Meredith Lamb (+14169386001)**

>
Some crazy chick that sees through all that I guess

*💬 Reply*

**272.** `23:24` **You**

And to be honest mer that is what I really thought\.\. I mean it is laying it in thick but until you honestly\.\. that was what I expected


**273.** `23:24` **You**

Yeah exactly


**274.** `23:25` **Meredith Lamb (+14169386001)**

Yeah same, I get it


**275.** `23:25` **Meredith Lamb (+14169386001)**

>
Hate to say it but if it wasn’t me it would have been someone else, you are a catch despite what your family has you believe

*💬 Reply*

**276.** `23:27` **You**

I mean listen I am not going to argue with you suffice to say “I” am the lucky one here\.


**277.** `23:28` **Meredith Lamb (+14169386001)**

Thank you for not arguing lol


**278.** `23:28` **Meredith Lamb (+14169386001)**

Finally


**279.** `23:28` **You**

>
Went back to something a ways back\.\. read
To your mother?  lol

*💬 Reply*

**280.** `23:29` **You**

I just wonder how she would react to be honest I feel like I would like her and haven’t even met her\.


**281.** `23:30` **Meredith Lamb (+14169386001)**

I mean she isn’t her true self anymore…\. But 60\-65% her\.


**282.** `23:30` **Meredith Lamb (+14169386001)**

She would like you


**283.** `23:30` **Meredith Lamb (+14169386001)**

But she is more confused and sick and stuff now


**284.** `23:30` **Meredith Lamb (+14169386001)**

She used to be super annoying


**285.** `23:30` **Meredith Lamb (+14169386001)**

lol


**286.** `23:31` **Meredith Lamb (+14169386001)**

She would LOVE your letter


**287.** `23:31` **You**

🙁 wish I could have known her before


**288.** `23:31` **Meredith Lamb (+14169386001)**

I don’t even need to shower to know that


**289.** `23:31` **Meredith Lamb (+14169386001)**

\*show


**290.** `23:32` **You**

Show her


**291.** `23:32` **You**

I know


**292.** `23:32` **You**

lol


**293.** `23:33` **Meredith Lamb (+14169386001)**

When I worked at a dot com, we had this client from Amsterdam who was old and in love with me and it was super hr sus\.  He wrote me this love letter and I forwarded to my mom and she said I should keep it bc when I’m old I’d appreciate it\. I deleted it immediately lol


**294.** `23:33` **Meredith Lamb (+14169386001)**

My mom is weird\.


**295.** `23:33` **Meredith Lamb (+14169386001)**

\*WAS


**296.** `23:33` **You**

ROFL I think you told me about him lol


**297.** `23:33` **Meredith Lamb (+14169386001)**

Probably


**298.** `23:34` **Meredith Lamb (+14169386001)**

It was kind of traumatizing lol


**299.** `23:34` **You**

>
Yeah I mean older people Eesh\.

*💬 Reply*

**300.** `23:34` **You**

I think I went a bit older than you though


**301.** `23:35` **Meredith Lamb (+14169386001)**

?


**302.** `23:35` **You**

Your fling


**303.** `23:35` **You**

I mean 10 years older is something for sure


**304.** `23:35` **Meredith Lamb (+14169386001)**

But…\.


**305.** `23:36` **You**

15 years older at 22 is a bit insane too\.\. but it really was just a short fling\.\.


**306.** `23:36` **Meredith Lamb (+14169386001)**

Lol


**307.** `23:36` **You**

I was way out of my comfort zone


**308.** `23:36` **You**

Like way the fuck out there


**309.** `23:37` **Meredith Lamb (+14169386001)**

Haha funny, I wasn’t :\)


**310.** `23:37` **You**

I wasn’t “crazy”\. But did like to experiment now and then\.


**311.** `23:37` **You**

I think crazy people
Appealed
To
Me
Because I was so straight laced


**312.** `23:37` **Meredith Lamb (+14169386001)**

Hmmmh experiment is an interesting word


**313.** `23:38` **Meredith Lamb (+14169386001)**

Explain


**314.** `23:38` **Meredith Lamb (+14169386001)**

>
You were strait laced?

*💬 Reply*

**315.** `23:38` **You**

I mean when you stay within your age range and then do that it was out of character\.  I did other things like that over the years but that was extreme


**316.** `23:38` **You**

I was a paradox


**317.** `23:39` **You**

I had a code and ethics and morals\.  I never lied to anyone about any of that shit was always transparent\.  But was willing to go along for any amount of fun


**318.** `23:39` **You**

It made my friends crazy


**319.** `23:40` **Meredith Lamb (+14169386001)**

Ok you are kind of cryptic sometimes\. Just saying\. lol


**320.** `23:40` **You**

I mean it isn’t cryptic it is just polite


**321.** `23:40` **Meredith Lamb (+14169386001)**

Haha


**322.** `23:41` **Meredith Lamb (+14169386001)**

Kk


**323.** `23:41` **Meredith Lamb (+14169386001)**

lol


**324.** `23:41` **Meredith Lamb (+14169386001)**

Aka\. Cryptic\.


**325.** `23:41` **You**

I mean look we all have our pasts


**326.** `23:41` **You**

Do you really want to know all of
My torrid secrets lol


**327.** `23:42` **You**

No is the correct answer lol


**328.** `23:42` **Meredith Lamb (+14169386001)**

Maybe someday\. Tonight I will just be thinking of us


**329.** `23:43` **You**

Prefer it that way besides I am not that person anymore I am who I am now same as you and I am perfectly happy with that\.


**330.** `23:44` **Meredith Lamb (+14169386001)**

I am too\.


**331.** `23:44` **Meredith Lamb (+14169386001)**

I just like to know who you are, were, will be


**332.** `23:44` **Meredith Lamb (+14169386001)**

Delete lol


**333.** `23:45` **You**

I mean no deletes allowed


**334.** `23:45` **Meredith Lamb (+14169386001)**

Is your fam miserable? Are tou feeling wiped


**335.** `23:46` **You**

Reaction: 😂 from Meredith Lamb
I feel like I want to channel the “Bossy Mogul” speaking of the future rofl


**336.** `23:46` **You**

>
Back to this first then I answer

*💬 Reply*

**337.** `23:46` **You**

You have gotten all of my deleted out of me


**338.** `23:46` **You**

With sad emojis and such


**339.** `23:47` **You**

lol you deleted again


**340.** `23:48` **Meredith Lamb (+14169386001)**

I was just going to say that I have been in a 15\+ yr relationship full of “we have no past and don’t speak of it” which always bugged me\. I found it hard to connect in that situation\. I DIDNT DELETE AGAIN LOL


**341.** `23:48` **Meredith Lamb (+14169386001)**

The past doesn’t threaten me


**342.** `23:48` **Meredith Lamb (+14169386001)**

Just helps me understand


**343.** `23:50` **You**

ROFL I mean look if you knew my past I wasn’t much different than many other guys perhaps
Just the way in which I went about my life\.  lol I had lots of fun made lots of friends\.  I loved to dance to anything hustled people at pool,
Loved
To smoke\.  And got caught in embarrassing situations many many times\.


**344.** `23:50` **You**

Reaction: ❤️ from Meredith Lamb
But like i said I had the honest approach probably instilled
By mum\.
Respect,
Morals etc


**345.** `23:50` **Meredith Lamb (+14169386001)**

Can we just make out again? Sigh so much talking


**346.** `23:50` **You**

Well morals kind of took a bit of a backseat


**347.** `23:51` **You**

Yeah I know shit that was super fun


**348.** `23:51` **You**

Reaction: ❤️ from Meredith Lamb
If anyone had have told
Me I would ever make out again I would have lol’d in their face\.


**349.** `23:51` **Meredith Lamb (+14169386001)**

Haha


**350.** `23:52` **You**

But everything feels different, better I don’t know I think it is because we are older and apparently emotional
Attachment and engagement means a shit ton more than when we were young\.


**351.** `23:52` **Meredith Lamb (+14169386001)**

They probably would have told you to do it at marriage counselling :P


**352.** `23:52` **You**

At least that is what our friend says when I asked


**353.** `23:53` **You**

Errr yeah no


**354.** `23:53` **You**

That wouldn’t have been an option


**355.** `23:53` **Meredith Lamb (+14169386001)**

I want to know the question


**356.** `23:53` **You**

As you said


**357.** `23:53` **You**

O connection


**358.** `23:53` **You**

No


**359.** `23:53` **Meredith Lamb (+14169386001)**

>
It would have been “homework”

*💬 Reply*

**360.** `23:53` **You**

What the prompt?


**361.** `23:54` **Meredith Lamb (+14169386001)**

Marriage is hard\. That type of thing


**362.** `23:54` **Meredith Lamb (+14169386001)**

>
Yeah

*💬 Reply*

**363.** `23:54` **You**

How is it possible to feel like this at 46 in the back of a shitty car\.  I explained a little further how I felt about you and it explained how intimacy changes over
Time


**364.** `23:55` **You**

There is a reason I didn’t go to counselling\.  That never would have worked anyways\.


**365.** `23:55` **Meredith Lamb (+14169386001)**

>
You get desperate as you get middle aged? lol

*💬 Reply*

**366.** `23:56` **Meredith Lamb (+14169386001)**

>
Yeah same\. I was asked last fall\-ish\.

*💬 Reply*

