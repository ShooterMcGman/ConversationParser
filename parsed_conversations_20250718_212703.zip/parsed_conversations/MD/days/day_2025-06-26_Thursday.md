# Daily Conversation: 2025-06-26 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-26 |
| **Day** | Thursday |
| **Week** | 11 |
| **Messages** | 357 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-26T03:29 - 2025-06-26T19:39 |

## 📝 Daily Summary

This day contains **357 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `03:29` **You**

Morning love I didn’t have the best sleep not sure why… too many thoughts swirling last night I guess\.  Going to stop off at lifetime because I got up early enough for a sauna to relax because I am pretty stressed out tbh\.\. then on the road\.  Hope you have a good morning and that all your prep for Maelle runs smoothly\.  Xo


**002.** `06:34` **Meredith Lamb (+14169386001)**

G’morn \- I haven’t been sleeping the greatest the last few nights either\. So many things\. Hope the drive is ok\. ❤️ Just getting up to workout\. Coffee first\.


**003.** `06:37` **You**

I have been talking to ChatGPT while I have been driving\. Nice to
Have a friend to keep me company


**004.** `06:37` **You**

At London now


**005.** `06:38` **Meredith Lamb (+14169386001)**

What have you been talking about? Lol


**006.** `06:38` **You**

This and that


**007.** `06:38` **Meredith Lamb (+14169386001)**

Haha k


**008.** `06:38` **Meredith Lamb (+14169386001)**

I like to listen to music when I drive


**009.** `06:38` **You**

So do I but I felt like chatting


**010.** `06:39` **You**

It gave me some advice we discussed in depth for like 25 mins


**011.** `06:40` **Meredith Lamb (+14169386001)**

Advice for Gracie?


**012.** `06:40` **You**

No


**013.** `06:41` **Meredith Lamb (+14169386001)**

I feel like you don’t need advice on anything else


**014.** `06:41` **You**

Just you\. And some on myself


**015.** `06:42` **Meredith Lamb (+14169386001)**

You need advice on me? Nooooo


**016.** `06:42` **You**

Always


**017.** `06:42` **Meredith Lamb (+14169386001)**

I think you have things covered right now\. You think too much


**018.** `06:42` **You**

Yeah that may be true\.\. but still\.


**019.** `06:43` **You**

Anyway go enjoy your coffee and workout


**020.** `06:43` **Meredith Lamb (+14169386001)**

You are going to be so tired tonight omg 3am wake


**021.** `06:43` **You**

I had 6 hours almost


**022.** `06:43` **You**

More than fine I woke up on my own


**023.** `06:44` **You**

Couldn’t get back


**024.** `06:44` **Meredith Lamb (+14169386001)**

Crazy


**025.** `06:44` **You**

Meh you will be more tired than me guaranteed


**026.** `06:45` **Meredith Lamb (+14169386001)**

lol true


**027.** `07:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**028.** `07:11` **You**

🙄


**029.** `07:11` **You**

That is weird and creepy


**030.** `07:12` **Meredith Lamb (+14169386001)**

It is just the way he rolls\. Always says I’m wrong and then I talk to him this morning and oh it is super helpful that I get out


**031.** `07:12` **Meredith Lamb (+14169386001)**

Like wtf


**032.** `07:12` **Meredith Lamb (+14169386001)**

So stupid


**033.** `07:13` **You**

Yep\.\. quite stuoid


**034.** `07:13` **Meredith Lamb (+14169386001)**

Also, Maelle got to see the house before she goes away for a month


**035.** `07:13` **Meredith Lamb (+14169386001)**

She feels good about it\. Can rest easy for a month with some certainty


**036.** `07:13` **Meredith Lamb (+14169386001)**

He’s like “I guess”


**037.** `07:13` **Meredith Lamb (+14169386001)**

😵‍💫


**038.** `07:13` **Meredith Lamb (+14169386001)**

I need out of here\.


**039.** `07:13` **Meredith Lamb (+14169386001)**

Omg


**040.** `07:13` **You**

Yeah I know


**041.** `07:14` **You**

Peace


**042.** `07:14` **Meredith Lamb (+14169386001)**

I think he’s just scared of having me gone


**043.** `07:14` **Meredith Lamb (+14169386001)**

But I’m going to be close by so I don’t get it fully


**044.** `07:14` **You**

Well it is managing the house


**045.** `07:14` **You**

And the kids


**046.** `07:14` **You**

He is not prepared


**047.** `07:15` **Meredith Lamb (+14169386001)**

Yeah and he just started a new job and doing the Reno\. It is a lot


**048.** `07:15` **Meredith Lamb (+14169386001)**

All while depressed


**049.** `07:15` **Meredith Lamb (+14169386001)**

And in denial about his depression


**050.** `07:15` **You**

Is this something you have seen before


**051.** `07:16` **Meredith Lamb (+14169386001)**

No


**052.** `07:16` **You**

I mean you are dealing with\. But of depression too right?


**053.** `07:16` **Meredith Lamb (+14169386001)**

No he has had it easy so no depression like this before that I’ve seen


**054.** `07:16` **Meredith Lamb (+14169386001)**

First time


**055.** `07:16` **Meredith Lamb (+14169386001)**

But he won’t admit it


**056.** `07:16` **Meredith Lamb (+14169386001)**

He’s not good at being self aware


**057.** `07:16` **You**

Hnmm


**058.** `07:16` **Meredith Lamb (+14169386001)**

He will be better when I leave


**059.** `07:17` **You**

I don’t have a lot of experience muse


**060.** `07:17` **You**

Myself


**061.** `07:17` **Meredith Lamb (+14169386001)**

I think it is partly anxiety about being alone


**062.** `07:17` **Meredith Lamb (+14169386001)**

He hates being alone


**063.** `07:17` **You**

Mmmm I like\. Being alone but I like you way more apparently lol


**064.** `07:18` **Meredith Lamb (+14169386001)**

I like being alone too\. Always was a problem with he and I


**065.** `07:18` **You**

Same with j\.


**066.** `07:18` **Meredith Lamb (+14169386001)**

Anyway I have seen the delaying from him before\. He always needs to be pushed down that is no different


**067.** `07:18` **Meredith Lamb (+14169386001)**

I can’t have Julian and cassy backing out or we are fucked


**068.** `07:19` **Meredith Lamb (+14169386001)**

So he needs to get moving


**069.** `07:19` **Meredith Lamb (+14169386001)**

This will help


**070.** `07:19` **Meredith Lamb (+14169386001)**

They will be SUPER happy by this July 1 news


**071.** `07:19` **Meredith Lamb (+14169386001)**

So will his mom


**072.** `07:19` **Meredith Lamb (+14169386001)**

He’s the only ass about it I’m sure


**073.** `07:19` **You**

Well I mean good news for all then


**074.** `07:20` **Meredith Lamb (+14169386001)**

Oh this morning he said “so I suppose you are going to want child support payment right away”


**075.** `07:21` **Meredith Lamb (+14169386001)**

🙄


**076.** `07:21` **Meredith Lamb (+14169386001)**

I was like no it is fine fuck off


**077.** `07:21` **You**

Jesus


**078.** `07:21` **You**

I mean I am thinking about how I can afford to carry Jaimie and myself through this\.\. his approach slightly different


**079.** `07:22` **You**

Dumbass


**080.** `07:25` **Meredith Lamb (+14169386001)**

>
Are you super stressed about it?

*💬 Reply*

**081.** `07:26` **You**

Reaction: 😮 from Meredith Lamb
It is a lot to carry I am paying for a lot outside of the agreement half for the lawyer fees and land transfer for new home half for down payment half for furniture paying for all the phones and the plans


**082.** `07:26` **You**

Not forever


**083.** `07:27` **You**

But it will be tight for a bit I am\. Not worrried


**084.** `07:27` **You**

More important to get a good sale price for the home


**085.** `07:32` **Meredith Lamb (+14169386001)**

That is a lot outside of the agreement


**086.** `07:32` **Meredith Lamb (+14169386001)**

Andrew would never


**087.** `07:32` **You**

It’s fine


**088.** `07:32` **Meredith Lamb (+14169386001)**

He isn’t even going to help me set up insurance even tho he works at intact


**089.** `07:32` **You**

I am low sssg


**090.** `07:32` **Meredith Lamb (+14169386001)**

My mom was like huh?


**091.** `07:33` **Meredith Lamb (+14169386001)**

sssg?


**092.** `07:33` **Meredith Lamb (+14169386001)**

lol


**093.** `07:33` **You**

Reaction: 👍 from Meredith Lamb
Ssag


**094.** `07:33` **You**

For lump


**095.** `07:33` **You**

Well thatbisnwhat it says but I don’t agree


**096.** `07:34` **Meredith Lamb (+14169386001)**

Ah I see, k


**097.** `07:35` **You**

What help do you need with insurance like help get you a good rate


**098.** `07:35` **Meredith Lamb (+14169386001)**

Yeah employee discount lol


**099.** `07:35` **Meredith Lamb (+14169386001)**

But whatever don’t care


**100.** `07:35` **Meredith Lamb (+14169386001)**

Not a big deal


**101.** `07:35` **Meredith Lamb (+14169386001)**

But I would help him if tables were reversed


**102.** `07:35` **You**

Yeah shitty love


**103.** `07:36` **You**

Move


**104.** `07:36` **You**

We have discount


**105.** `07:36` **You**

With cooperators


**106.** `07:36` **You**

Prolly not as good


**107.** `07:36` **You**

I use my mba discount with Ted


**108.** `07:36` **You**

Td


**109.** `07:37` **Meredith Lamb (+14169386001)**

I will figure it all out\. Just funny what an ass he is


**110.** `07:37` **You**

Yep


**111.** `07:37` **Meredith Lamb (+14169386001)**

He’s just mad and sad and all that


**112.** `07:37` **You**

Ego


**113.** `07:39` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**114.** `07:42` **You**

That was nice of her 🙂


**115.** `07:42` **You**

Nice for him to get something


**116.** `07:43` **You**

Reaction: 👍 from Meredith Lamb
Just got to the office


**117.** `07:43` **You**

Made good time


**118.** `08:21` **You**

Ahhh chatham so homey


**119.** `08:22` **You**

Where did you sit btw


**120.** `08:22` **Meredith Lamb (+14169386001)**

2nd floor\!


**121.** `08:22` **You**

In the new or old


**122.** `08:22` **Meredith Lamb (+14169386001)**

Old


**123.** `08:22` **You**

Hmm I might walk down


**124.** `08:22` **You**

Curious


**125.** `08:22` **Meredith Lamb (+14169386001)**

I looked out the window to the Wendy’s at the time


**126.** `08:22` **Meredith Lamb (+14169386001)**

Not sure what is on that corner now


**127.** `08:22` **You**

Good old days


**128.** `08:22` **Meredith Lamb (+14169386001)**

Not Wendy’s anymore


**129.** `08:23` **Meredith Lamb (+14169386001)**

Are we moving to Chatham? lol


**130.** `08:23` **You**

I would


**131.** `08:23` **You**

In a second


**132.** `08:23` **Meredith Lamb (+14169386001)**

I would also but not while my kids are this young … they would hate it


**133.** `08:23` **You**

Can’t really walk around would look weird just got down here


**134.** `08:24` **You**

Perhaps later


**135.** `08:24` **You**

Perhaps later
We
Could consider it


**136.** `08:25` **Meredith Lamb (+14169386001)**

My friends would be ecstatic


**137.** `08:26` **You**

I would def be happier


**138.** `08:26` **You**

And it would be much more affordable


**139.** `08:26` **You**

Spend our money on adventures instead of housing


**140.** `08:26` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**141.** `08:26` **You**

Mmmmmhmm


**142.** `08:26` **Meredith Lamb (+14169386001)**

Showed them the new place


**143.** `08:28` **You**

Cool it is a really nice place tbh… but I bet no boys over is a rule too 😩


**144.** `08:28` **You**

lol


**145.** `08:28` **You**

Not for a good while


**146.** `08:29` **Meredith Lamb (+14169386001)**

Kim lives on a farm in Appin\. So small no population listed really\. Lol


**147.** `08:29` **Meredith Lamb (+14169386001)**

>
What why?

*💬 Reply*

**148.** `08:29` **You**

How far is glencoe from chatham?


**149.** `08:29` **Meredith Lamb (+14169386001)**

I will have children half the time


**150.** `08:30` **You**

>
Jk really but not until after singing agreement and only after
Andrew knows I think

*💬 Reply*

**151.** `08:30` **You**

Would hate to have him show up


**152.** `08:30` **You**

Well that too


**153.** `08:30` **You**

Cannot be there with kids


**154.** `08:30` **Meredith Lamb (+14169386001)**

>
45 minutes unless you get behind a bus or tractor then it could be closer to an hour\. You drive on highway 2 and it mostly has a solid line, no passing because it is a windy highway through fields\.

*💬 Reply*

**155.** `08:30` **You**

Hmm not bad at all


**156.** `08:31` **Meredith Lamb (+14169386001)**

\(School bus\)


**157.** `08:31` **Meredith Lamb (+14169386001)**

No it is an easy 45 min\. Not like city 45 min


**158.** `08:31` **Meredith Lamb (+14169386001)**

Beautiful drive


**159.** `08:31` **You**

I know it would be like home


**160.** `08:31` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Morning has beautiful views\. Misty over the fields in the fall


**161.** `08:31` **Meredith Lamb (+14169386001)**

It’s gorgeous


**162.** `08:31` **Meredith Lamb (+14169386001)**

Night is meh


**163.** `08:32` **You**

Other views at night


**164.** `08:32` **You**

Nicer


**165.** `08:32` **Meredith Lamb (+14169386001)**

If it is dark, it is just black\. No lights anywhere\. In the middle of nowhere lol


**166.** `08:32` **You**

Perfect


**167.** `08:32` **Meredith Lamb (+14169386001)**

I used to go to GoodLife after work so always went home in the dark a lot


**168.** `08:33` **You**

Something to consider down the road\.


**169.** `08:33` **You**

Reaction: 👍 from Meredith Lamb
Kk logging on to oc call\.


**170.** `08:35` **Meredith Lamb (+14169386001)**

https://flic\.kr/p/nGyJH
This was before going to work in Chatham one morning …\.


**171.** `08:36` **You**

Beautiful


**172.** `10:16` **Meredith Lamb (+14169386001)**

My lease is all official now\.


**173.** `10:16` **Meredith Lamb (+14169386001)**

Fully executed\.


**174.** `10:29` **You**

Nice grata\!\!


**175.** `10:29` **You**

I am heading to Mayes to see baby\.


**176.** `10:30` **Meredith Lamb (+14169386001)**

Oh cool \- have fun


**177.** `10:33` **You**

Oh yeah super fun


**178.** `10:34` **Meredith Lamb (+14169386001)**

lol


**179.** `10:34` **You**

ROFL


**180.** `10:38` **Meredith Lamb (+14169386001)**

I just set up all my banking and credit card fun fun one more thing done


**181.** `11:21` **You**

Wow just finished at Mayes heading to Windsor


**182.** `11:23` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 26 Jun 2025 11:23:19 \-0400
|
| I’m off to do bank drafts, then lcbo for Mac and Liana, then I’m basically done all my errands for today\. Have to set up insurance utilities but can do tomorrow from hotel\.
|
| Version: 1
| Sent: Thu, 26 Jun 2025 11:23:06 \-0400
|
| I’m off to do bank drafts, then lcbo for Mac and Liana, then I’m basically done all my errands for today\. Have to def up insurance utilities but can do tomorrow from hotel\.


**183.** `11:23` **Meredith Lamb (+14169386001)**

I haven’t packed yet\. Been focusing on Maelle’s packing


**184.** `11:26` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**185.** `11:26` **You**

Kk we’ll just let me know when to expect you lol


**186.** `11:27` **You**

Then I will add an hour or two


**187.** `11:27` **You**

Interesting how long in Detroit


**188.** `11:27` **Meredith Lamb (+14169386001)**

Just until sat


**189.** `11:28` **You**

Ah shitty


**190.** `11:34` **Meredith Lamb (+14169386001)**

It might be too early to meet them anyway lol


**191.** `11:34` **Meredith Lamb (+14169386001)**

They would be with their kids


**192.** `11:34` **Meredith Lamb (+14169386001)**

Kids don’t know likely


**193.** `11:34` **Meredith Lamb (+14169386001)**

Seeing as how mine don’t lol


**194.** `11:37` **You**

True


**195.** `11:37` **You**

I am meeting enough new people this weekend too many according to Jim


**196.** `11:37` **Meredith Lamb (+14169386001)**

Yeah we are good\. We are going to be too social


**197.** `11:37` **Meredith Lamb (+14169386001)**

lol


**198.** `11:40` **You**

ROFL


**199.** `11:40` **You**

Idc I am just happy to be with you\.\. dun care doing what


**200.** `11:46` **Meredith Lamb (+14169386001)**

Oh no CIBC system down wtf


**201.** `11:46` **You**

Like everywhere?


**202.** `11:47` **Meredith Lamb (+14169386001)**

Not sure\. 3 ppl working on it right now


**203.** `11:47` **Meredith Lamb (+14169386001)**

Sigh


**204.** `11:47` **Meredith Lamb (+14169386001)**

I need to get this done today


**205.** `11:47` **You**

I got into my CIBC app


**206.** `11:48` **Meredith Lamb (+14169386001)**

I think it is something about bank drafts specifically


**207.** `11:48` **Meredith Lamb (+14169386001)**

It took my money but no draft


**208.** `11:48` **Meredith Lamb (+14169386001)**

lol


**209.** `11:48` **Meredith Lamb (+14169386001)**

Gahhhh


**210.** `11:48` **You**

There should be a fix


**211.** `11:48` **You**

Are you at bank


**212.** `11:49` **Meredith Lamb (+14169386001)**

Yup\-  they are working on it


**213.** `11:49` **You**

Well should be fine


**214.** `11:49` **Meredith Lamb (+14169386001)**

Yeah just eating my time


**215.** `11:50` **You**

Is maelle ready


**216.** `11:53` **You**

You don’t need to rush


**217.** `11:57` **Meredith Lamb (+14169386001)**

Omg I have to go to another branch


**218.** `11:57` **Meredith Lamb (+14169386001)**

So annoyed\. Everything is annoying right now\. lol


**219.** `11:58` **You**

Just be calm\.\. don’t rush


**220.** `12:21` **Meredith Lamb (+14169386001)**

This branch having issues too omg


**221.** `12:21` **Meredith Lamb (+14169386001)**

Hilarious


**222.** `12:22` **You**

Holy shit


**223.** `12:22` **You**

How the fuck this going to work


**224.** `12:23` **Meredith Lamb (+14169386001)**

🤷‍♀️


**225.** `12:23` **You**

Shit see you tomorrow lol


**226.** `12:23` **Meredith Lamb (+14169386001)**

If I ever get this draft I have to then go to TD


**227.** `12:23` **Meredith Lamb (+14169386001)**

honestly


**228.** `12:24` **You**

lol


**229.** `12:24` **You**

Tomorrow rollers


**230.** `12:36` **You**

😢


**231.** `12:37` **Meredith Lamb (+14169386001)**

I’m just stuck here waiting\. They made a mistake and aren’t sure how to fix it so are on hold calling someone\. Not my day 🤷‍♀️


**232.** `12:51` **You**

That sucks met


**233.** `12:51` **You**

Mer


**234.** `12:54` **Meredith Lamb (+14169386001)**

We are trying a wire now


**235.** `12:54` **Meredith Lamb (+14169386001)**

lol omg


**236.** `12:54` **You**

Jesus


**237.** `12:54` **You**

They should comp you something g for all this hassle


**238.** `12:54` **You**

What the fuck


**239.** `12:54` **Meredith Lamb (+14169386001)**

God like 2 hrs out of my day


**240.** `12:54` **You**

Yep\.\.


**241.** `12:55` **Meredith Lamb (+14169386001)**

They were going to get me to go to a 3rd branch lol


**242.** `12:55` **You**

Sorry I know it doesn’t help your nerves


**243.** `12:55` **Meredith Lamb (+14169386001)**

I’m like try a wire


**244.** `12:55` **Meredith Lamb (+14169386001)**

It costs extra but not much and worth my time


**245.** `12:59` **You**

Well they should cover those costs for shit


**246.** `13:04` **Meredith Lamb (+14169386001)**

Ok I’m done


**247.** `13:04` **Meredith Lamb (+14169386001)**

LCBO for Mac


**248.** `13:04` **Meredith Lamb (+14169386001)**

Then home omg


**249.** `13:08` **You**

Td bank?


**250.** `13:08` **Meredith Lamb (+14169386001)**

I don’t have to do that with a wire only if I did the bank draft


**251.** `13:15` **You**

Ah ok


**252.** `13:36` **Meredith Lamb (+14169386001)**

Omg I’m home\. F’ing day\. Thank god I took a vacation day\. Holy


**253.** `13:36` **You**

Yeah honestly shit day


**254.** `14:07` **Meredith Lamb (+14169386001)**

I just realized I don’t know where I’m going


**255.** `15:24` **You**

Hyatt


**256.** `15:39` **You**

You on road?


**257.** `15:40` **Meredith Lamb (+14169386001)**

Yes, but I haven’t decided yet whether to stop in London or not


**258.** `15:40` **Meredith Lamb (+14169386001)**

Does it matter what time I get there?


**259.** `15:40` **You**

Nope\.\.


**260.** `15:40` **You**

Well I mean


**261.** `15:40` **You**

I look forward to seeing you but you do you


**262.** `15:41` **Meredith Lamb (+14169386001)**

But when will you be there?


**263.** `15:41` **You**

I already told you tell me a time and I will add two hours


**264.** `15:41` **You**

I am going to Hyatt now


**265.** `15:41` **Meredith Lamb (+14169386001)**

I could be there as early as seven


**266.** `15:41` **You**

I am done for the day


**267.** `15:41` **You**

But if you want to stop you should


**268.** `15:41` **Meredith Lamb (+14169386001)**

No, I’m kind of tired\. I’ll just go there\.


**269.** `15:42` **You**

If you want to see your friends you should stop lol


**270.** `15:42` **You**

I will be here


**271.** `15:42` **Meredith Lamb (+14169386001)**

No, it would be for my niece Alayna her graduation is today


**272.** `15:42` **You**

Oh shit yeah I forgot isn’t your Kim there


**273.** `15:42` **You**

Mum


**274.** `15:43` **Meredith Lamb (+14169386001)**

Yeah, my parents are there and my mom has that card and money for Alayna from me so I don’t need to stop


**275.** `15:43` **You**

Kk


**276.** `15:46` **Meredith Lamb (+14169386001)**

Are you going out with Harris for dinner tonight?


**277.** `15:54` **You**

Nope


**278.** `15:54` **You**

Lunch was huge


**279.** `15:55` **Meredith Lamb (+14169386001)**

Oh, for some reason, I thought you would have dinner obligations tonight


**280.** `15:55` **You**

I was going to but I was like nope still full and he had Bball


**281.** `15:55` **You**

So we having lunch again tomorrow with a business partner


**282.** `15:57` **You**

I can find something to do if you need some alone time 🙂


**283.** `15:58` **Meredith Lamb (+14169386001)**

No no lol


**284.** `16:02` **You**

Need anything I am just out for a few mins


**285.** `16:03` **Meredith Lamb (+14169386001)**

Nope thanks


**286.** `16:05` **You**

Nothing no fruit or water or anything


**287.** `16:12` **You**

Getting wine


**288.** `16:12` **You**

Any pref Pinot or cab\.


**289.** `16:12` **Meredith Lamb (+14169386001)**

I actually got two bottles when I was getting McKenzie’s vodka


**290.** `16:12` **You**

lol so only need one bottle the\. Got it


**291.** `16:12` **Meredith Lamb (+14169386001)**

lol


**292.** `16:24` **Meredith Lamb (+14169386001)**

OK, I feel guilty so I’m just going to drop in to say congratulations to Alayna\. I will not be staying because she will need to leave for her actual graduation and they live right off the highway in London


**293.** `16:27` **You**

Kk


**294.** `16:27` **You**

All good


**295.** `16:27` **You**

Tell ur mom I miss her


**296.** `16:27` **Meredith Lamb (+14169386001)**

Yeah, OK


**297.** `16:28` **You**

lol


**298.** `16:43` **Meredith Lamb (+14169386001)**

Get to Woodstock and my body just relaxes… in the childhood area and it always feels so different than Toronto


**299.** `16:44` **You**

lol you can tour me around on Monday\.


**300.** `16:45` **Meredith Lamb (+14169386001)**

Tour all the fields?


**301.** `16:46` **You**

Wherever you want to go we go


**302.** `17:01` **You**

Ironic just ran into mark p in the liquor store


**303.** `17:01` **You**

Of all places


**304.** `17:07` **You**

He helped me pick a pinot


**305.** `17:07` **Meredith Lamb (+14169386001)**

lol


**306.** `17:07` **You**

He was coming back from Utah


**307.** `17:08` **Meredith Lamb (+14169386001)**

Prociw?


**308.** `17:08` **You**

Yep


**309.** `17:09` **Meredith Lamb (+14169386001)**

Did you tell him you’re drinking alone in your hotel room?


**310.** `17:11` **You**

Yep said I am trying to get into wine\.\. someone suggested Pinot but I don’t have a clue where to start


**311.** `17:11` **You**

Trust me I was convincing


**312.** `17:27` **You**

In hotel now room is nice\.


**313.** `17:33` **You**

Room is 514
You are on reservation key at desk for whenever you get in\.\. I may or may not be in room\.


**314.** `17:39` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
My mom made us pose like this 🙄

*📎 1 attachment(s)*

**315.** `17:48` **Meredith Lamb (+14169386001)**

I’m back on the road


**316.** `17:48` **Meredith Lamb (+14169386001)**

Sorry


**317.** `17:49` **Meredith Lamb (+14169386001)**

2080 Huron church road??


**318.** `17:50` **You**

Yep


**319.** `17:55` **Meredith Lamb (+14169386001)**

Added onto my time, but I feel better than I went\. Alayna appreciated it\.


**320.** `18:01` **You**

Reaction: 👍 from Meredith Lamb
Hope you remembered to get passport


**321.** `18:01` **You**

And I am glad
You stopped


**322.** `18:01` **Meredith Lamb (+14169386001)**

You should have a nap because I will be there until at least 730


**323.** `18:02` **Meredith Lamb (+14169386001)**

lol


**324.** `18:02` **You**

I am just getting into gym


**325.** `18:02` **You**

No napping


**326.** `18:02` **Meredith Lamb (+14169386001)**

lol eesh k


**327.** `18:07` **You**

They have a nice pool


**328.** `18:22` **Meredith Lamb (+14169386001)**

Johnny with his dad today awww lol

*📎 1 attachment(s)*

**329.** `18:41` **You**

Oooooooopooh Johnny\!\!\!\!


**330.** `18:42` **You**

How is the drive


**331.** `18:51` **You**

Like 9 pm arrival?  If you give me a heads up I can order food


**332.** `18:56` **You**

Or if you aren’t hungry I might order myself something


**333.** `19:12` **Meredith Lamb (+14169386001)**

7\.30


**334.** `19:12` **Meredith Lamb (+14169386001)**

Ish


**335.** `19:13` **Meredith Lamb (+14169386001)**

lol


**336.** `19:13` **Meredith Lamb (+14169386001)**

Call at 7:45 just to be safe


**337.** `19:13` **You**

ROFL


**338.** `19:13` **You**

So 8:15


**339.** `19:13` **You**

Do you want food for when you get here


**340.** `19:14` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 26 Jun 2025 19:14:21 \-0400
|
| Not really I was just gonna get like something snacky to have with some wine so like just go to shoppers or something on my way in
|
| Version: 1
| Sent: Thu, 26 Jun 2025 19:14:08 \-0400
|
| Not really I was just gonna get like something snack to have with some wine so like just go to shoppers or something on my way in


**341.** `19:14` **You**

Reaction: 😂 from Meredith Lamb
I got you bananas and smart pop


**342.** `19:15` **You**

But there is a restaurant downstairs prolly something small there let me go down and check menu


**343.** `19:21` **You**

Yeah they have a decent menu\. What food goes well with wine?  Chicken? Fingers??  lol I have no class


**344.** `19:22` **Meredith Lamb (+14169386001)**

Come on now I drink wine with anything


**345.** `19:22` **You**

Cheese pizza


**346.** `19:22` **Meredith Lamb (+14169386001)**

lol


**347.** `19:23` **You**

Or peperoni\.\. anyhow I will bring a menu up we can call down and order and pick
Up


**348.** `19:23` **Meredith Lamb (+14169386001)**

Just get what you want you’re probably way more hungry than I am


**349.** `19:23` **You**

Yeah I am a bit but I want to see what you want first maybe we can share


**350.** `19:23` **Meredith Lamb (+14169386001)**

Anything seriously


**351.** `19:24` **You**

Ok well I am not going to order until you are close or it will be cold


**352.** `19:25` **You**

I am going to start drinking my fireball


**353.** `19:30` **Meredith Lamb (+14169386001)**

Im at shoppers up the street


**354.** `19:31` **Meredith Lamb (+14169386001)**

Getting aleve


**355.** `19:31` **You**

Kk see you soon


**356.** `19:39` **Meredith Lamb (+14169386001)**

Done so where do I go when I get there


**357.** `19:39` **You**

Park out front walk in to the front desk say you are Meredith in room 514 and need a key


