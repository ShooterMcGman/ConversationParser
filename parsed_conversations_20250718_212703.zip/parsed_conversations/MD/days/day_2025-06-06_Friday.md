# Daily Conversation: 2025-06-06 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-06 |
| **Day** | Friday |
| **Week** | 8 |
| **Messages** | 301 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-06T00:00 - 2025-06-06T22:14 |

## 📝 Daily Summary

This day contains **301 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **Meredith Lamb (+14169386001)**

If you can’t call me you get stuck with annoying texts\. If you call me you get stuck with equal annoyingness\.  No winning\.  Sorry


**002.** `00:00` **You**

Reaction: ❓ from Meredith Lamb
i am scared anxious and sweaty atm


**003.** `00:01` **Meredith Lamb (+14169386001)**

Another step for my mom\. Baby steps


**004.** `00:02` **Meredith Lamb (+14169386001)**

My dad would have been your best friend 2 months ago


**005.** `00:04` **Meredith Lamb (+14169386001)**

>
Huh? Why?

*💬 Reply*

**006.** `00:04` **You**

You told me to call\.


**007.** `07:12` **You**

I am up\.\. gawd Mer\.\. I hope
You have been up
For an hour hitting that workout hard babe\. ❤️❤️❤️❤️❤️


**008.** `07:13` **You**

Reaction: ❤️ from Meredith Lamb
Love you hun, that was a really awkward yet endearing and fulfilling conversation \(in a kind of weird\) way\.  I hope you remember everything we talked about because we made some pretty intimate promises to each other 😇❤️❤️


**009.** `08:31` **Meredith Lamb (+14169386001)**

Ermagod…\.\. so tired\. I have no meetings today so will be working out at noonish\. Yawwwwwwwn


**010.** `08:32` **You**

Yah sure


**011.** `08:32` **You**

lol


**012.** `08:32` **Meredith Lamb (+14169386001)**

>
I mean no guarantees but hopefully\. Lol

*💬 Reply*

**013.** `08:32` **You**

So how much do you remember


**014.** `08:33` **Meredith Lamb (+14169386001)**

Not sure literally just woke up\. :p I remember when we decided to go to bed and going to bed and that is a good sign lol


**015.** `08:34` **Meredith Lamb (+14169386001)**

But we talked forevvver


**016.** `08:34` **You**

Ok let’s test do you Remeber talking about snow?


**017.** `08:34` **Meredith Lamb (+14169386001)**

lol yes


**018.** `08:34` **You**

Ok then that should be good enough


**019.** `08:35` **Meredith Lamb (+14169386001)**

I remember the basics but maybe not every detail


**020.** `08:35` **You**

No it was fun\.\. and awkward\.\. but we \(powered\) through it


**021.** `08:35` **Meredith Lamb (+14169386001)**

LOL


**022.** `08:35` **You**

Reaction: ❤️ from Meredith Lamb
I Remeber telling you at the end I would rather be uncomfortable and know you that comfortable and not\.


**023.** `08:36` **You**

Anyhow you get up do your thing\.\. I might workout at noon as well unsure


**024.** `08:36` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**025.** `08:36` **You**

Poor Rosie scarred by the conversation


**026.** `08:36` **Meredith Lamb (+14169386001)**

>
I remember this too

*💬 Reply*

**027.** `08:36` **You**

She heard so many bad things from Scott kissed a boy to sisters to all kinds


**028.** `08:37` **Meredith Lamb (+14169386001)**

It was pretty wild \- I enjoyed it all


**029.** `08:37` **You**

I’m Victoria Olivia and Emma for the record


**030.** `08:37` **You**

Memory still there\.\. sometimes fun to have


**031.** `08:38` **Meredith Lamb (+14169386001)**

I hope I remember everything\. Time will tell lol


**032.** `08:38` **You**

Yeah you won’t


**033.** `08:38` **Meredith Lamb (+14169386001)**

Probably not


**034.** `08:38` **Meredith Lamb (+14169386001)**

But you can refresh it


**035.** `08:38` **You**

Reaction: 😂 from Meredith Lamb
You didn’t Remeber last night what you said to me earlier in the night lol


**036.** `08:38` **You**

That is what had us going around about Chris


**037.** `08:39` **You**

Then you agreed if you hang we al hang


**038.** `08:39` **You**

Then I told
You I kissed a boy and you were like shit


**039.** `08:39` **Meredith Lamb (+14169386001)**

Omg I remember way too much about Chris\. :p


**040.** `08:39` **You**

Chris was
Prime time all night


**041.** `08:39` **You**

Then you admitted


**042.** `08:39` **You**

That if the situation was reversed you would not be comfortable in me reconnecting


**043.** `08:39` **Meredith Lamb (+14169386001)**

>
So weird\.

*💬 Reply*

**044.** `08:40` **You**

It did resolve a lot


**045.** `08:40` **You**

If that is any consolation


**046.** `08:40` **You**

I mean you are fucking blind lol but it resolved\. A lot for me


**047.** `08:40` **Meredith Lamb (+14169386001)**

It is actually


**048.** `08:40` **Meredith Lamb (+14169386001)**

I am blind?\!


**049.** `08:40` **You**

What trend?\!\!\!\!\!\!\!


**050.** `08:40` **You**

lol


**051.** `08:40` **You**

Omfg


**052.** `08:41` **You**

Do you remember that


**053.** `08:41` **Meredith Lamb (+14169386001)**

Maybe if you refresh my memory, but not really


**054.** `08:41` **Meredith Lamb (+14169386001)**

Oh my God, I haven’t had coffee yet


**055.** `08:41` **You**

Jeremy gavin Andrew Scott


**056.** `08:41` **Meredith Lamb (+14169386001)**

This is a lot of trying to remember when I just got up


**057.** `08:42` **You**

Does that do it


**058.** `08:42` **Meredith Lamb (+14169386001)**

That isn’t a trend


**059.** `08:42` **You**

Yes it is


**060.** `08:42` **Meredith Lamb (+14169386001)**

There is no trend there


**061.** `08:42` **You**

4
Data points


**062.** `08:42` **You**

Is a trend


**063.** `08:42` **Meredith Lamb (+14169386001)**

No, everyone is so different\. There is no trend\.


**064.** `08:42` **You**

Every one of them was threatened by your relationship with Chris


**065.** `08:42` **You**

Reaction: 😂 from Meredith Lamb
And 2 didn’t even know it was sexual


**066.** `08:42` **You**

And they were still threatened


**067.** `08:42` **Meredith Lamb (+14169386001)**

Oh, right OK fine whatever


**068.** `08:42` **You**

lol


**069.** `08:43` **Meredith Lamb (+14169386001)**

I remember now


**070.** `08:43` **You**

So that should give you pause to reconsider


**071.** `08:43` **Meredith Lamb (+14169386001)**

See just need some refreshing lol


**072.** `08:43` **You**

Reaction: ❤️ from Meredith Lamb
Ok go get coffee eorking in saving my finances


**073.** `08:43` **You**

I will refresh your memory tomorrow


**074.** `08:43` **Meredith Lamb (+14169386001)**

Just let me have my coffee and think


**075.** `08:43` **Meredith Lamb (+14169386001)**

lol


**076.** `08:44` **Meredith Lamb (+14169386001)**

I have no meetings so am just going to wear my workout clothes until I finish my workout


**077.** `08:44` **You**

Interesting\.\. I wonder how many more stories you have… I have so many\.\.


**078.** `08:44` **Meredith Lamb (+14169386001)**

I have none


**079.** `08:44` **You**

What stfu


**080.** `08:44` **Meredith Lamb (+14169386001)**

You heard them all


**081.** `08:44` **You**

Bullshit


**082.** `08:44` **Meredith Lamb (+14169386001)**

Stick a fork in me


**083.** `08:44` **Meredith Lamb (+14169386001)**

That’s all I got


**084.** `08:44` **You**

The adventures you and Jeremy had cross Canada


**085.** `08:44` **You**

Why was Andrew so threatened by Jeremy


**086.** `08:45` **You**

You made Jeremy out to sound pretty weak\.\.


**087.** `08:45` **You**

I was the fucking boss


**088.** `08:45` **You**

lol


**089.** `08:45` **Meredith Lamb (+14169386001)**

>
Because he fucking snooped in my room and read my journal at the time

*💬 Reply*

**090.** `08:45` **Meredith Lamb (+14169386001)**

Jeremy is weak


**091.** `08:45` **You**

Present day or old


**092.** `08:45` **You**

Well I am weak too\.\. ish atm that is


**093.** `08:46` **You**

But that is situational\.


**094.** `08:46` **Meredith Lamb (+14169386001)**

No you are not


**095.** `08:46` **Meredith Lamb (+14169386001)**

How did I make him sound weak?


**096.** `08:48` **You**

well


**097.** `08:49` **You**

we were debating as to whether or not Jeremy knew about Chris and all the sex\.\. and I said def not\.\. because no way he is cool with you sleeping at Chris' place knowing that


**098.** `08:49` **Meredith Lamb (+14169386001)**

>
This is funny because it is true I guess\.

*💬 Reply*

**099.** `08:49` **You**

and you said he wouldn't have a say in it


**100.** `08:49` **You**

>
not funny\.\. disturbing\.\. and even more supports my position

*💬 Reply*

**101.** `08:50` **Meredith Lamb (+14169386001)**

>
Chris and I were not having sex at that point\! Just hanging out… a lot\.

*💬 Reply*

**102.** `08:50` **You**

and then you tried to defend but I slept on the couch blah blah\.\. and that is when I said\.\. well maybe me and Cheyenne should reconnect and I could sleep at her house and "not" have sex\.


**103.** `08:50` **You**

and you said\.\. mmmm


**104.** `08:50` **You**

no


**105.** `08:50` **Meredith Lamb (+14169386001)**

>
But it is true\! I did\.

*💬 Reply*

**106.** `08:50` **You**

I didn'


**107.** `08:50` **You**

say you lied


**108.** `08:50` **You**

I said Jeremy would have lost his sht


**109.** `08:51` **You**

and you said fuck him


**110.** `08:51` **You**

so I knew he was weak


**111.** `08:51` **You**

I can promise you my reaction would be quite different\.  Just like yours would be as well\.\. even though we trust each other\.


**112.** `08:51` **You**

it is human nature\.


**113.** `08:51` **You**

Anyhow\.


**114.** `08:51` **You**

that is how I knew he was weak\.


**115.** `08:53` **You**

Doesn't matter\.\. when I finally meet Chris \- I will give him a huge hug\.\. and say omg I feel like I know you already Meredith has told me so much about you two\.\.\. like OMG\!\!


**116.** `08:53` **You**

😇


**117.** `08:53` **You**

we can have a chat on teams later if you are bored and want to play some more\.


**118.** `08:56` **Meredith Lamb (+14169386001)**

>
You will never meet him\. I will be worried about you kissing him\. 🤪

*💬 Reply*

**119.** `08:56` **You**

No that can't work\.\.


**120.** `08:57` **You**

because you said the next time you see him we would be together\.\. and I don't want you walking away from your friendship\.


**121.** `08:57` **You**

catch 22


**122.** `08:57` **You**

Reaction: 😂 from Meredith Lamb
I would have to be very drunk Meredith\.\. don't worry\.\.


**123.** `08:57` **You**

lol


**124.** `08:57` **Meredith Lamb (+14169386001)**

>
We were in our 20s so it was a bit different maybe

*💬 Reply*

**125.** `08:58` **You**

Um\.\. yeah no


**126.** `08:58` **You**

You have already admitted to your jealousy level\.\. and I think mine is up there with yours\.\. my reaction would be the same today as it would have been then\.


**127.** `09:18` **Meredith Lamb (+14169386001)**

So Andrew and I just talked


**128.** `09:18` **Meredith Lamb (+14169386001)**

It was very calm and amicable


**129.** `09:18` **Meredith Lamb (+14169386001)**

No more arguing\. No more craziness


**130.** `09:19` **Meredith Lamb (+14169386001)**

Getting drunk last night helped me\. Not sure why I need to do that when I’m overstressed but it is a definite “trend”


**131.** `09:29` **You**

Just dropped maddie off can I teams you when I get back


**132.** `09:30` **Meredith Lamb (+14169386001)**

Sure \- I need 10 min to get ready\. Just had my coffee and Andrew just left


**133.** `09:31` **You**

There are other ways we can deal with stress


**134.** `09:47` **Meredith Lamb (+14169386001)**

I think this is my way of dealing with “beyond typical stress”


**135.** `09:47` **Meredith Lamb (+14169386001)**

Not many times in my life have I felt this equivalent disruption


**136.** `09:48` **Meredith Lamb (+14169386001)**

Obviously not my way of dealing with regular stress


**137.** `09:52` **You**

Yeah I get it but there are other ways too\.\.


**138.** `09:57` **Meredith Lamb (+14169386001)**

I know\. I’m trying … therapy… etc i will get there\. I always do


**139.** `09:57` **Meredith Lamb (+14169386001)**

I’m just not very resilient lol


**140.** `10:11` **You**

I wasn’t being critical I was being playful and suggestive\.\. not where your head is at\.


**141.** `10:27` **Meredith Lamb (+14169386001)**

Oh\. Lol yeah I’m working\.


**142.** `10:27` **Meredith Lamb (+14169386001)**

And hungover


**143.** `10:30` **You**

it's fine\.


**144.** `10:33` **Meredith Lamb (+14169386001)**

Are you at your computer


**145.** `10:34` **You**

yeah


**146.** `10:34` **Meredith Lamb (+14169386001)**

I have a work question\. Can you call me


**147.** `12:22` **Meredith Lamb (+14169386001)**

You sure you don’t like Rhys?


**148.** `12:22` **Meredith Lamb (+14169386001)**

I liked him


**149.** `12:23` **You**

I cannot do it I don't think ian will support posting in chatham


**150.** `12:24` **Meredith Lamb (+14169386001)**

Ohhhhh


**151.** `13:29` **You**

Tried calling you just have missed you or you are working out


**152.** `15:48` **You**

Hey I think I am gonna head out to the gym now\.\. maybe chat later?


**153.** `16:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Yeah sure ❤️


**154.** `16:21` **You**

Hey


**155.** `16:22` **Meredith Lamb (+14169386001)**

Hey


**156.** `16:22` **You**

Cote just reached out told
Her was at the gym she gave me an update on this meeting next week then asked me to look out for any single hot guys\.


**157.** `16:22` **Meredith Lamb (+14169386001)**

lol


**158.** `16:22` **You**

How should I answer?


**159.** `16:22` **You**

😇


**160.** `16:23` **You**

Wait not single I don’t count\.


**161.** `16:23` **You**

Reaction: 🙄 from Meredith Lamb
Also the hot part


**162.** `16:23` **You**

Boooooo


**163.** `16:23` **Meredith Lamb (+14169386001)**

>
Exactly

*💬 Reply*

**164.** `16:23` **You**



**165.** `16:23` **You**

Noted


**166.** `16:24` **Meredith Lamb (+14169386001)**

Not as effective with the typo


**167.** `16:24` **You**

What typo


**168.** `16:24` **Meredith Lamb (+14169386001)**

“Notes”


**169.** `16:24` **You**

I don’t see that


**170.** `16:25` **Meredith Lamb (+14169386001)**

Well now it looks weird with “this message was deleted”


**171.** `16:25` **You**

Heheh


**172.** `16:25` **You**

Hmmm leg and shoulders no fun and never good for status


**173.** `16:27` **Meredith Lamb (+14169386001)**

For status?


**174.** `16:31` **You**


*📎 1 attachment(s)*

**175.** `16:31` **You**


*📎 1 attachment(s)*

**176.** `16:31` **You**


*📎 1 attachment(s)*

**177.** `16:31` **You**

Photos


**178.** `16:31` **You**

No good


**179.** `16:36` **Meredith Lamb (+14169386001)**

That’s quite a drop

*💬 Reply*

**180.** `16:38` **You**

It was over 20% in march


**181.** `16:38` **You**

Like 23 I think


**182.** `16:40` **Meredith Lamb (+14169386001)**

That’s intense


**183.** `16:41` **You**

I wonder why\.


**184.** `16:42` **You**

Reaction: ❤️ from Meredith Lamb
Maybe there is someone out there I want to impress who knows


**185.** `16:44` **Meredith Lamb (+14169386001)**

It is pretty impressive but please don’t waste away\. :p


**186.** `16:44` **You**

Oh yeah the size thing


**187.** `16:45` **Meredith Lamb (+14169386001)**

I just mean for your health lol


**188.** `16:45` **You**

I don’t know how to turn that around have to eat a lot more now


**189.** `16:45` **You**

Naw that’s not what you meant but that’s ok\.


**190.** `16:47` **Meredith Lamb (+14169386001)**

I am happy for you, honestly but don’t do it for meeeee


**191.** `16:47` **You**

Already committed can’t turn back now


**192.** `16:48` **You**

Besides healthiest I have been in 30 years easy


**193.** `16:50` **Meredith Lamb (+14169386001)**

Well you do look amazing so…\.


**194.** `16:50` **You**

No I don’t but it is kind of you to say so\.\. excited to see what you look like tomorrow 🙂


**195.** `17:02` **Meredith Lamb (+14169386001)**

You do\. I am not being “kind”\. Lol


**196.** `17:08` **You**

Well i mean I wanted to fermi\. Shape but you gave me soo much more motivation\.


**197.** `17:08` **You**

Get in shape\.


**198.** `18:39` **You**

All done


**199.** `18:39` **You**

All shiny 😀


**200.** `18:41` **You**

You must be shopping


**201.** `18:43` **Meredith Lamb (+14169386001)**

No I had a nap


**202.** `18:43` **Meredith Lamb (+14169386001)**

lol


**203.** `18:44` **You**

Hangover nap


**204.** `18:46` **Meredith Lamb (+14169386001)**

Absolutely\!


**205.** `18:46` **Meredith Lamb (+14169386001)**

Frozen pizza now lol


**206.** `18:47` **You**

After I drive Maddies friend home m&m pizza roles for me


**207.** `18:47` **Meredith Lamb (+14169386001)**

I don’t know what that is


**208.** `18:48` **You**

M&m meat shops


**209.** `18:48` **Meredith Lamb (+14169386001)**

Oh I googled it


**210.** `18:48` **Meredith Lamb (+14169386001)**

Interesting


**211.** `18:48` **You**

Maybe rich people don’t shop there


**212.** `18:48` **Meredith Lamb (+14169386001)**

Oh whatever


**213.** `18:48` **You**

😛


**214.** `18:48` **Meredith Lamb (+14169386001)**

I have never heard of pizza rolls


**215.** `18:48` **Meredith Lamb (+14169386001)**

I have heard of m&m


**216.** `18:48` **You**

Heheh


**217.** `18:49` **You**

Never shopped there I bet


**218.** `18:54` **Meredith Lamb (+14169386001)**

Sure I have


**219.** `18:54` **Meredith Lamb (+14169386001)**

It just isn’t a big Toronto thing so don’t often


**220.** `19:01` **You**

A big Toronto thing?


**221.** `19:01` **You**

lol


**222.** `19:02` **Meredith Lamb (+14169386001)**

Like you can’t find stores


**223.** `19:03` **Meredith Lamb (+14169386001)**

It’s more a suburb small town thing


**224.** `19:03` **Meredith Lamb (+14169386001)**

Not as easy in Toronto to find


**225.** `19:03` **You**

Ok so the fancy muckity mucks have their own special places


**226.** `19:04` **Meredith Lamb (+14169386001)**

Oh shit yeah they do\.
I have nowhere to watch tv 😢everyone is everywhere


**227.** `19:04` **Meredith Lamb (+14169386001)**

Gah


**228.** `19:04` **You**

Office


**229.** `19:04` **Meredith Lamb (+14169386001)**

Maelle


**230.** `19:05` **You**

Go sit with Andrew he would like the company


**231.** `19:08` **Meredith Lamb (+14169386001)**

Haha


**232.** `19:08` **You**

You could make plans


**233.** `19:09` **Meredith Lamb (+14169386001)**

What kind of plans


**234.** `19:09` **You**

Oh fuck\.\.


**235.** `19:09` **You**

Nm


**236.** `19:09` **You**

Deleted


**237.** `19:09` **Meredith Lamb (+14169386001)**

lol wha


**238.** `19:09` **You**

Nothing back in the vault\.


**239.** `19:09` **You**

Kk plans


**240.** `19:09` **You**

I dunno


**241.** `19:09` **Meredith Lamb (+14169386001)**

Like tomorrow plans


**242.** `19:10` **You**

You meant
To make tomorrow plans with Andrew


**243.** `19:10` **You**

That could be weird\.


**244.** `19:10` **Meredith Lamb (+14169386001)**

🙄 did not mean that


**245.** `19:10` **You**

lol


**246.** `19:10` **Meredith Lamb (+14169386001)**

I’m having a protein shake in my room


**247.** `19:10` **You**

Well I already figured bring some breakfast / snacks


**248.** `19:10` **You**

You tell me \.


**249.** `19:11` **You**

We
Can watch our movie or movies have lunch


**250.** `19:11` **You**

Do whatever go for a walk I dun care I just want to be with you and I will be happy


**251.** `19:14` **Meredith Lamb (+14169386001)**

>
Same\. :\)

*💬 Reply*

**252.** `19:14` **You**

If you have any other ideas to contribute I am “open” per se\.


**253.** `19:15` **Meredith Lamb (+14169386001)**

Open \+ per se\. Wow\. ✅✅


**254.** `19:15` **You**

I should get some kind of reward


**255.** `19:15` **You**

I know\!\!\!


**256.** `19:15` **You**

You think about it and answer LOL


**257.** `19:16` **Meredith Lamb (+14169386001)**

We’ll talk tomorrow\. 🥳


**258.** `19:17` **You**

No…\. That is a cop out you are going to forget\!\!


**259.** `19:17` **You**

I know your tricks


**260.** `19:17` **Meredith Lamb (+14169386001)**

I would never forget anything\!


**261.** `19:18` **Meredith Lamb (+14169386001)**

My memory is golden


**262.** `19:18` **Meredith Lamb (+14169386001)**

lol


**263.** `19:19` **You**

Compromise


**264.** `19:19` **You**

Tell me later tonight


**265.** `19:54` **Meredith Lamb (+14169386001)**

Watcha doing? Pizza rolls?


**266.** `19:55` **You**

Bad food


**267.** `19:55` **You**

Ate pizza rolls and onion rings I needed the calories


**268.** `19:55` **You**

And I am having a protein drink in a sec


**269.** `19:55` **You**

And doing laundry and cleaning kitchen


**270.** `19:56` **Meredith Lamb (+14169386001)**

Busy bee


**271.** `19:57` **You**

I am that\.


**272.** `19:58` **You**

Any ideas yet\.\.  I am also persistent


**273.** `19:58` **Meredith Lamb (+14169386001)**

Reward ideas? Or just ideas of things to do


**274.** `20:00` **You**

Both could be the same thing


**275.** `20:01` **Meredith Lamb (+14169386001)**

I mean, I always have ideas in my head when it comes to you\. Pretty easy


**276.** `20:05` **You**

Kk you not sharing though right\.\. because that would be opening yourself up too much?


**277.** `20:05` **You**

Driving her friend home


**278.** `20:06` **You**

Edited: 2 versions
| Version: 2
| Sent: Fri, 6 Jun 2025 20:06:35 \-0400
|
| So you have some time to come up with a good answer lol
|
| Version: 1
| Sent: Fri, 6 Jun 2025 20:06:23 \-0400
|
| So you have some time to come up with a good abase lol


**279.** `20:07` **Meredith Lamb (+14169386001)**

:p I’m watching Better Sister


**280.** `20:07` **Meredith Lamb (+14169386001)**

>
I feel like if I share then it will be boring tomorrow

*💬 Reply*

**281.** `20:12` **Meredith Lamb (+14169386001)**

I got the office back\!


**282.** `20:12` **Meredith Lamb (+14169386001)**

And tv is working now


**283.** `20:39` **You**

>
You are full of crap no ideas incoming\.\. lol

*💬 Reply*

**284.** `20:39` **You**



**285.** `20:42` **Meredith Lamb (+14169386001)**

Someone is persistent tonight


**286.** `20:43` **Meredith Lamb (+14169386001)**

And the deletions\. Geez


**287.** `20:43` **Meredith Lamb (+14169386001)**

That’s like 2 or 3 today


**288.** `20:43` **You**

One was a typo\.\. errr
No
It wasn’t


**289.** `20:44` **Meredith Lamb (+14169386001)**

🤔


**290.** `20:44` **You**

Anyhow my comment stands\!


**291.** `20:51` **Meredith Lamb (+14169386001)**

Your deleted comment? :p


**292.** `20:51` **You**

It was a poop emoji


**293.** `20:51` **You**

😀


**294.** `20:51` **Meredith Lamb (+14169386001)**

Omg


**295.** `20:51` **Meredith Lamb (+14169386001)**

lol


**296.** `20:51` **You**

\#child


**297.** `22:08` **You**

Taking dogs for quick walk not sure you wanna talk or if you can if not I will come back and
Likely say goodnight I am tired


**298.** `22:12` **Meredith Lamb (+14169386001)**

Sorry I was getting ready for bed\. So tired too……\.zzzzz


**299.** `22:12` **Meredith Lamb (+14169386001)**

I can’t wait to see you tomorrow 🙂❤️


**300.** `22:16` **Meredith Lamb (+14169386001)**

Love you \- nite xoxoxo


**301.** `22:14` **You**

Kk night same love you mer ❤️


