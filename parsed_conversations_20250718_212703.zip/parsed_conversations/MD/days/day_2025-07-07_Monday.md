# Daily Conversation: 2025-07-07 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-07 |
| **Day** | Monday |
| **Week** | 13 |
| **Messages** | 1065 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-07T04:24 - 2025-07-07T23:59 |

## 📝 Daily Summary

This day contains **1065 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:24` **You**

Morning love


**002.** `04:25` **You**

Up and headed to gym\.\. I hope you were able to just go to sleep and not reengage with Andrew over anything last night I know that was frustrating for you and you already have a distracting meeting today in the books\.


**003.** `04:39` **You**

I am sorry for the weekend and part of the last week it is so hard to be apart when I love you this much\.\. and I hope in addition to weakness and insecurity my concern yesterday can also reflect how much I actually value you and how much this relationship means to me\.  Love you Mer will see
You later\.


**004.** `04:40` **You**

❤️❤️❤️


**005.** `05:51` **Meredith Lamb (+14169386001)**

Morning :\)


**006.** `05:52` **Meredith Lamb (+14169386001)**

Yes we talked a bit more but it was all fine


**007.** `05:52` **You**

Kk glad no fighting


**008.** `05:52` **You**

Almost done workout


**009.** `05:52` **Meredith Lamb (+14169386001)**

No but I found out the new person is “early 40s” so Mackenzie will be pleased lol


**010.** `05:53` **You**

How did you find that out


**011.** `05:53` **Meredith Lamb (+14169386001)**

I asked if we should put an age limit to dating on the parenting thing today as a joke but then seriously asked bc he knows Mac’s concern


**012.** `05:53` **Meredith Lamb (+14169386001)**

He said no age limit\! lol


**013.** `05:54` **You**

ROFL


**014.** `05:54` **Meredith Lamb (+14169386001)**

This thing is “new” so I think he wants to keep things flex


**015.** `05:54` **You**

Could never have had that convo with j


**016.** `05:54` **Meredith Lamb (+14169386001)**

He said he started it bc I got my own place and he thought I’d be out


**017.** `05:55` **Meredith Lamb (+14169386001)**

He’s been waiting


**018.** `05:55` **You**

Ah ok\.\.


**019.** `05:55` **You**

Interesting


**020.** `05:55` **You**

Interesting assume you kept us quiet for now


**021.** `05:55` **Meredith Lamb (+14169386001)**

I did because I would like to resolve mediation first


**022.** `05:55` **You**

Yep smart


**023.** `05:56` **Meredith Lamb (+14169386001)**

I don’t think he feels bad at all but …\.


**024.** `05:56` **Meredith Lamb (+14169386001)**

He seems more willing on the waiving topic than before


**025.** `05:56` **Meredith Lamb (+14169386001)**

And it is only dating/sex that is making him that way


**026.** `05:57` **You**

Man


**027.** `05:57` **Meredith Lamb (+14169386001)**

Defending himself he was like “you know I need that stuff” 🙄


**028.** `05:57` **You**

So not me


**029.** `05:57` **You**

Weird


**030.** `05:57` **You**

wtf


**031.** `05:57` **You**

OMFG


**032.** `05:57` **Meredith Lamb (+14169386001)**

No not you at all


**033.** `05:57` **Meredith Lamb (+14169386001)**

This woman does not have kids apparently


**034.** `05:58` **Meredith Lamb (+14169386001)**

But he wouldn’t tell me how they met


**035.** `05:58` **Meredith Lamb (+14169386001)**

I kind of want to know because I wonder if it is the text person


**036.** `05:58` **You**

Hockey


**037.** `05:59` **Meredith Lamb (+14169386001)**

Probably because it is not a work or industry person


**038.** `05:59` **Meredith Lamb (+14169386001)**

Which for him is weird


**039.** `05:59` **You**

Hmm


**040.** `06:00` **Meredith Lamb (+14169386001)**

We have almost no ac but I’m going to try to work out


**041.** `06:02` **You**

Reaction: 😮 from Meredith Lamb
Today

*📎 1 attachment(s)*

**042.** `06:02` **You**


*📎 1 attachment(s)*

**043.** `06:02` **You**

Done for the day


**044.** `06:03` **You**

Good luck with workout I wouldn’t go
Longer than 30


**045.** `06:03` **You**

You have been off a bit


**046.** `06:03` **You**

Going to sauna shower and shave then head out


**047.** `06:07` **Meredith Lamb (+14169386001)**

Oh I forgot to mention that for the first time he wonders if I’m seeing someone but has a hard time believing it and says it would be ironic


**048.** `06:07` **Meredith Lamb (+14169386001)**

He noticed the u\.s\. trip and said he thought I might be seeing someone in Detroit but he didn’t say anything


**049.** `06:07` **You**

lol seriously


**050.** `06:07` **Meredith Lamb (+14169386001)**

lol


**051.** `06:07` **You**

Well


**052.** `06:07` **Meredith Lamb (+14169386001)**

He got some notification on his phone that my phone crossed the border\. Not sure why


**053.** `06:07` **Meredith Lamb (+14169386001)**

I’m confused on that one


**054.** `06:08` **You**

lol ah well I wonder how long he has been with this one


**055.** `06:08` **Meredith Lamb (+14169386001)**

Yeah who knows


**056.** `06:09` **Meredith Lamb (+14169386001)**

I told him as long as he keeps being nice to me I don’t care and he scoffs and says he was never not nice


**057.** `06:09` **You**

Man I still think he is going to react when he finds out it is me


**058.** `06:09` **You**

Like big


**059.** `06:13` **Meredith Lamb (+14169386001)**

Only reason I didn’t say anything last night\. If it was a rando I don’t think he’d care


**060.** `06:13` **You**

Rando\.\. Eesh\.\.


**061.** `06:13` **You**

Haven’t heard that in a while


**062.** `06:13` **You**

Haha


**063.** `06:14` **Meredith Lamb (+14169386001)**

lol


**064.** `06:14` **You**

I don’t think I ever referred to one as a rando


**065.** `06:14` **You**

lol


**066.** `06:14` **Meredith Lamb (+14169386001)**

But they were


**067.** `06:14` **Meredith Lamb (+14169386001)**

You know it


**068.** `06:14` **You**

I mean not all were randos


**069.** `06:14` **You**

Some were friends


**070.** `06:14` **Meredith Lamb (+14169386001)**

k


**071.** `06:14` **Meredith Lamb (+14169386001)**

“Some”


**072.** `06:15` **You**

Hmm at least 1/3


**073.** `06:15` **Meredith Lamb (+14169386001)**

🙄


**074.** `06:15` **You**

Truth


**075.** `06:15` **You**

Not one nighters I met


**076.** `06:15` **Meredith Lamb (+14169386001)**

So 2/3 were randos


**077.** `06:15` **You**

I am not like that Eesh


**078.** `06:15` **You**

No


**079.** `06:15` **You**

1/3 were maybe


**080.** `06:15` **You**

1/3 were relationships


**081.** `06:16` **You**

Mmm maybe that number is skewed a bit


**082.** `06:16` **You**

Anyways I never called em Randi’s


**083.** `06:16` **You**

Randos


**084.** `06:16` **Meredith Lamb (+14169386001)**

lol


**085.** `06:16` **You**

I was a gentleman


**086.** `06:17` **Meredith Lamb (+14169386001)**

That’s so nice for you


**087.** `06:17` **You**

Wow I feel the sarcasm of that text\.\.
All the way through to my phone


**088.** `06:17` **You**

It got hot all of\. Sudden


**089.** `06:17` **You**

Ok we can move off the rando topic 😇


**090.** `06:18` **Meredith Lamb (+14169386001)**

lol just saying you might be rewriting history in your mind somewhat


**091.** `06:18` **Meredith Lamb (+14169386001)**

But maybe not


**092.** `06:18` **You**

Well the gentleman part is true


**093.** `06:18` **You**

The me initiating is not


**094.** `06:19` **Meredith Lamb (+14169386001)**

You were always a gentleman, I was always a lady\. There\.


**095.** `06:19` **Meredith Lamb (+14169386001)**

lol


**096.** `06:19` **You**

Exactly


**097.** `06:19` **You**

How I pictured you


**098.** `06:19` **You**

❤️


**099.** `06:19` **Meredith Lamb (+14169386001)**

Always\.


**100.** `06:19` **You**

No doubt


**101.** `06:20` **Meredith Lamb (+14169386001)**

Except for that one time at band camp…


**102.** `06:20` **You**

I think I might have been a lady on more than a few nights


**103.** `06:20` **Meredith Lamb (+14169386001)**

Ok this is taking a turn lol


**104.** `06:21` **You**

I mean I was pursued had drinks bought for me\.\. etc


**105.** `06:21` **You**

I didn’t love the drinks part


**106.** `06:21` **You**

But being pursued was kinda fun


**107.** `06:22` **Meredith Lamb (+14169386001)**

I’m sensing a theme


**108.** `06:22` **You**

Well…


**109.** `06:23` **Meredith Lamb (+14169386001)**

So my feeling of hunting you down is likely true lol I’m sensing this


**110.** `06:23` **You**

When I realize how
Much In love with you I was I definitely turned into the pursuer hard\.


**111.** `06:23` **You**

You might have started but I think I finished\.


**112.** `06:24` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 06:24:28 \-0400
|
| Kk hopping in sauna and shower and out of here\.\. love you, we can pick this up after\.
|
| Version: 1
| Sent: Mon, 7 Jul 2025 06:24:17 \-0400
|
| Kk hopping in sauna and shower and out of here\.\. love you sleep can pick this up after\.


**113.** `06:24` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
Good team 🙂

*💬 Reply*

**114.** `06:25` **Meredith Lamb (+14169386001)**

K enjoy


**115.** `06:25` **Meredith Lamb (+14169386001)**

C u soon ish


**116.** `06:25` **You**

Okie dokie


**117.** `06:38` **Meredith Lamb (+14169386001)**

Ok not a hockey person and now I know why Mac noticed multiple people\. He opened a Hinge dating account a week ago when I rented my place\. This Melanie is the one who has stuck so far … literally a week in and he wants me out\. lol he seems more flex this morning on fucking chilling out with the schedule


**118.** `07:14` **You**

Hmm


**119.** `07:15` **You**

All done going to car now to cool off


**120.** `07:19` **Meredith Lamb (+14169386001)**

Just got out of shower


**121.** `07:19` **Meredith Lamb (+14169386001)**

I am going to rush but shit it is hot here


**122.** `07:20` **You**

All good


**123.** `07:25` **You**

I will get there early but happy to sit in ac and rest


**124.** `07:26` **Meredith Lamb (+14169386001)**

Reaction: 😀 from Scott Hicks
I am attempting to be out by 7\.35


**125.** `08:57` **Meredith Lamb (+14169386001)**

Omg Mediator cannot meet today family emergency\. They just called\. Ughhhh


**126.** `08:57` **You**

That sucks sorry Mer\.


**127.** `08:59` **You**

Keep the room and give
Your
Mum a call
lol


**128.** `08:59` **You**

Catch her up


**129.** `08:59` **Meredith Lamb (+14169386001)**

lol no thanks


**130.** `09:34` **You**

I thought it would be fun lol\.\. anyhow sorry that happened maybe some other time this week might work who knows\.


**131.** `12:02` **Meredith Lamb (+14169386001)**

Thursday 12pm first available appt\. Ughhhhh


**132.** `12:02` **You**

Still will get done this week maybe final next week and signed next week


**133.** `12:02` **You**

Perhaps who knows


**134.** `12:09` **Meredith Lamb (+14169386001)**

Yeah hopefully


**135.** `12:10` **You**

I mean you could put a hit of pressure on mediator if you feel it might need to proceed faster\.\. moving out and all\.\. want things firmed up


**136.** `12:17` **Meredith Lamb (+14169386001)**

Like on Thursday you mean?


**137.** `12:17` **Meredith Lamb (+14169386001)**

Andrew actually accused me this morning of delaying things


**138.** `12:17` **Meredith Lamb (+14169386001)**

I was like “your schedule is the issue not mine”


**139.** `12:17` **Meredith Lamb (+14169386001)**

I was willing to meet last week


**140.** `12:18` **Meredith Lamb (+14169386001)**

He’s saying weird shit


**141.** `12:18` **You**

I mean you could message the mediator in advance of Thursday and expresss a need to expedite this process\.  While understanding she had this emergency anything that can be done to expedite blah blah


**142.** `12:24` **Meredith Lamb (+14169386001)**

Could\. But I think I will focus on other stuff instead\. Need to get wifi set up and close off the current\. Andrew will have to reset it up at current house\. Also will try to move some stuff and focus on that\.


**143.** `12:24` **You**

Well it isn’t like you don’t have lots to do anyways\.


**144.** `12:25` **You**

So yeah maybe focus on some easier stuff\.


**145.** `12:25` **Meredith Lamb (+14169386001)**

So much to do … makes me tired thinking about it\.


**146.** `12:26` **You**

Same\.\. boxes come on Wednesday ffs


**147.** `12:26` **You**

Like holy shit my house will be literally empty almost by weekend


**148.** `12:26` **Meredith Lamb (+14169386001)**

That will be crazy


**149.** `12:26` **You**

M boxes Thursday but still yeah empty house on weekend nuts


**150.** `12:27` **You**

No couch main floor lol nothing


**151.** `12:27` **You**

Lawn chairs


**152.** `12:27` **Meredith Lamb (+14169386001)**

We used our outdoor furniture for 2 months before we moved lol was awful


**153.** `12:31` **You**

Gonna be sweet


**154.** `15:33` **You**

Having a good afternoon?? Bored lol reading reports\.\. poorly written ones\.


**155.** `15:57` **Meredith Lamb (+14169386001)**

Yeah not bad but tired\. You?


**156.** `15:58` **Meredith Lamb (+14169386001)**

Maelle’s camp

*📎 1 attachment(s)*

**157.** `15:58` **You**

Just a bit bored mondays always suck for me\.\.


**158.** `15:58` **Meredith Lamb (+14169386001)**

Same


**159.** `15:58` **You**

Crazy camp lol\.


**160.** `15:59` **You**

It’s odd I don’t want to be here but I don’t want to go home lol\.\. but I have to go pack some more\.\. gah boo\.\.


**161.** `16:00` **You**

I am not sure how much got done today didn’t sound promising


**162.** `16:24` **Meredith Lamb (+14169386001)**

I don’t want to go home either gahhh


**163.** `16:42` **You**

Yeah I know no fun\.\. but I love you and I hope you had a good day\.\. we chst later if
You are available\.


**164.** `16:45` **Meredith Lamb (+14169386001)**

I will definitely be around\. Think I’m going to order beds tonight finally\.


**165.** `16:51` **You**

Nice the excitement continues\. lol I hate shopping


**166.** `16:55` **You**

Maybe it will be an easy night there is a lot out in the open less stress for Andrew now\.\.
Might be easier\.\. fingers crossed


**167.** `17:00` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 17:00:24 \-0400
|
| He won’t be home tonight, so yes, definitely easier…\. “work dinner”
|
| Version: 1
| Sent: Mon, 7 Jul 2025 17:00:11 \-0400
|
| I’ll be home tonight, so yes, definitely easier…\. “work dinner”


**168.** `17:01` **You**

Rofl


**169.** `17:01` **You**

Reaction: 😬 from Meredith Lamb
Gracie putting up a fight so I am going home to that


**170.** `17:01` **You**

It’ll be fine


**171.** `17:01` **You**

I am just holding the line


**172.** `17:03` **Meredith Lamb (+14169386001)**

The funny thing is he gave me a hard time about not moving out and then he’s like you’re gonna be home tonight tomorrow and Wednesday night correct? Because he has work dinner hockey and hockey so he wants me to stay with Marlowe\.


**173.** `17:03` **Meredith Lamb (+14169386001)**

Fucking idiot, my God


**174.** `17:22` **You**

Wow


**175.** `17:22` **You**

He isn’t ready


**176.** `17:27` **Meredith Lamb (+14169386001)**

It would be nice if he had some common sense sometimes\. Don’t give me a hard time and then literally ask me to be home\. Omg\.


**177.** `17:27` **You**

When is he moving stuff


**178.** `17:31` **Meredith Lamb (+14169386001)**

Probably not this week lol


**179.** `17:31` **Meredith Lamb (+14169386001)**

I think he plans to go to cottage Thurs night so


**180.** `17:31` **Meredith Lamb (+14169386001)**

Every night busy


**181.** `17:31` **Meredith Lamb (+14169386001)**

🙄


**182.** `17:31` **You**

Hmmm wish I could help would if there was a way\.


**183.** `17:34` **You**

Home sweet home\.\. 🫤


**184.** `17:34` **You**

lol


**185.** `17:37` **Meredith Lamb (+14169386001)**

Trust me, I know you would help if you could\. Lol


**186.** `17:38` **Meredith Lamb (+14169386001)**

Yeah home too\. No ac\. Colder outside than inside


**187.** `17:40` **You**

>
ChatGPT says so it is how I show value

*💬 Reply*

**188.** `17:41` **You**

>
Eww that’s intolerable how do you not have a inside ac yet that goes to the window

*💬 Reply*

**189.** `17:43` **Meredith Lamb (+14169386001)**

>
No doubt\.

*💬 Reply*

**190.** `17:44` **Meredith Lamb (+14169386001)**

>
Because …\. “The Reno”

*💬 Reply*

**191.** `17:46` **Meredith Lamb (+14169386001)**

It’s not bad outside

*📎 1 attachment(s)*

**192.** `17:46` **Meredith Lamb (+14169386001)**

lol


**193.** `17:46` **You**

Wine lol


**194.** `17:47` **Meredith Lamb (+14169386001)**

Helps with the heat


**195.** `17:47` **You**

Mmm hmm


**196.** `17:47` **You**

🫢


**197.** `17:47` **Meredith Lamb (+14169386001)**

Don’t worry I have water too

*📎 1 attachment(s)*

**198.** `17:48` **Meredith Lamb (+14169386001)**

It cancels the wine out


**199.** `17:49` **You**

It does not in fact do that at all


**200.** `17:49` **You**

Do not teach your daughters chem\.


**201.** `17:49` **Meredith Lamb (+14169386001)**

I beg to differ\. It does\.


**202.** `17:50` **You**

Ok well look you believe what you want\.\. if you wish and hope hard enough it just be true\.\. lol we will see how you are 5 glasses later


**203.** `17:51` **You**

And if your 5 glasses of water keep you sober


**204.** `18:07` **Meredith Lamb (+14169386001)**

2 not 5


**205.** `18:11` **You**

So far you mean 2 of 5


**206.** `18:12` **You**

Apparently Gracie is going to fight so we will have to see how this goes\.


**207.** `18:12` **Meredith Lamb (+14169386001)**

Oh man, you need a welcome to fight club door mat at your house\. Gah\.


**208.** `18:16` **You**

>
it is every night\.\. Gracie started yelling shit at me so I went downstairs, and just texted J that I am not going to do this\.\. I am holding the line\. and I am not changing on this one\.\. then she yelled at me LOL\.\. I am fine\.\. it is all good\.\. nothing to worry about\.

*💬 Reply*

**209.** `18:16` **You**

think i am just going to work for the next 3 hours maybe and go to bed\.\. might be best option\.\.


**210.** `18:17` **You**

if I had wine I might get drunk to


**211.** `18:17` **You**

but alas


**212.** `18:17` **Meredith Lamb (+14169386001)**

You should have a glass of wine lol


**213.** `18:17` **Meredith Lamb (+14169386001)**

Haha


**214.** `18:17` **You**

jinx


**215.** `18:17` **You**

yeah no you should do your thing I will do mine\.


**216.** `18:17` **You**

works better that way


**217.** `18:18` **Meredith Lamb (+14169386001)**

I’ve only had a half glass\. Buying furniture\. Ugh\.
Would rather be making you feel better in person though\. Sort of selfishly but whatever\.


**218.** `18:18` **You**

yeah but remember you cannot, so don't take that on yourself\.\. I have to deal with my shit, I am fine\.\. seeing you this morning was wonderful\.\. didn't want to leave the car\.


**219.** `18:19` **Meredith Lamb (+14169386001)**

If we were in person I’m confident I could 😋


**220.** `18:20` **You**

yeah that is true\.\. just sitting with you watching a show and talking it out with a glass of wine would be wonderful\.


**221.** `18:20` **Meredith Lamb (+14169386001)**

That’s not what I was thinking but we could do that too\. :\)


**222.** `18:20` **You**

lol\. I already knew what you were insinuating\.\. was baiting you :P


**223.** `18:21` **You**

yeah the other thing would make me forget everything


**224.** `18:21` **You**

but you\.\.


**225.** `18:21` **You**

so yeah that works


**226.** `18:23` **Meredith Lamb (+14169386001)**

So wait why did Jaimie yell at you?


**227.** `18:23` **You**

because apparently when I text her from down here while there is fighting up there it stresses her out\.\. I went up read the text to everyone\.\. and said there was nothing there to do that\.\. and then she screamed at me like 5 times lol


**228.** `18:23` **You**

so I went back downstairs


**229.** `18:24` **You**

I am fine


**230.** `18:24` **Meredith Lamb (+14169386001)**

I am looking forward to you getting away from such a drama environment


**231.** `18:24` **Meredith Lamb (+14169386001)**

It is very toxic


**232.** `18:24` **You**

yeah me too\.\. partly why Gracie is not allowed to stay\.\. she is a walking toxic bomb atm


**233.** `18:25` **Meredith Lamb (+14169386001)**

I do feel bad for her though but holy shit\.


**234.** `18:26` **Meredith Lamb (+14169386001)**

And then the divorce adds onto her issues … I’m sure it is a lot


**235.** `18:26` **You**

My sister is like kick her out\.


**236.** `18:26` **You**

she has seen all this


**237.** `18:26` **You**

and is like this is fucking bs


**238.** `18:27` **You**

she doesn't like J much and is really disappointed in G


**239.** `18:27` **Meredith Lamb (+14169386001)**

My sister ran away from home so my parents didn’t have to kick her out\. They were close tho


**240.** `18:27` **Meredith Lamb (+14169386001)**

My sister says she feels bad now but I don’t believe her


**241.** `18:27` **Meredith Lamb (+14169386001)**

I was like maddie


**242.** `18:27` **Meredith Lamb (+14169386001)**

Had to deal with her fucking bullshit constantly


**243.** `18:28` **Meredith Lamb (+14169386001)**

Then she left and it was this huge vacuum


**244.** `18:28` **You**

yeah maddie is still up there sitting through it listening\.


**245.** `18:28` **Meredith Lamb (+14169386001)**

Yeah shitty


**246.** `18:28` **You**

hey so what did you share with Jim today?


**247.** `18:28` **Meredith Lamb (+14169386001)**

It is fucking with her nervous system and she doesn’t know it


**248.** `18:29` **You**

>
oh she is a straight mess\.\. and won't make any of the right decisions to fix it\.

*💬 Reply*

**249.** `18:29` **Meredith Lamb (+14169386001)**

>
Omg we talked so much today\. He wouldn’t stop talking

*💬 Reply*

**250.** `18:29` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 18:29:57 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Mon, 7 Jul 2025 18:29:15 \-0400
| >
| > oh she is a straight mess\.\. and won't make any of the right decisions to fix it\.
|
| No, I mean it’s fucking with Maddie’s nervous system and Maddie doesn’t know it\. She’ll realize it later\.
|
| Version: 1
| Sent: Mon, 7 Jul 2025 18:29:44 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Mon, 7 Jul 2025 18:29:15 \-0400
| >
| > oh she is a straight mess\.\. and won't make any of the right decisions to fix it\.
|
| No, I mean it’s fucking with Maddie’s nervous system then Maddie doesn’t know it\. She’ll realize it later\.


**251.** `18:29` **You**

lol


**252.** `18:29` **You**

>
oh yeah but she is resilient she will be fine when it is us

*💬 Reply*

**253.** `18:30` **You**

>
what'd he have to say

*💬 Reply*

**254.** `18:30` **You**

i messaged him on signal\.\. he hasn't even looked at it :\(


**255.** `18:30` **Meredith Lamb (+14169386001)**

Don’t message on signal\. I don’t think he uses signal\. Just text him regularly\.


**256.** `18:30` **You**

maybe


**257.** `18:31` **Meredith Lamb (+14169386001)**

I don’t use signal with him


**258.** `18:31` **Meredith Lamb (+14169386001)**

He’s not very techy


**259.** `18:31` **Meredith Lamb (+14169386001)**

He’s old


**260.** `18:31` **Meredith Lamb (+14169386001)**

lol


**261.** `18:31` **You**

it's fine\.\. no biggy


**262.** `18:31` **Meredith Lamb (+14169386001)**

He talked a lot about Christine’s drinking today


**263.** `18:31` **Meredith Lamb (+14169386001)**

lol


**264.** `18:31` **You**

hmm


**265.** `18:31` **Meredith Lamb (+14169386001)**

And he asked a lot about my situation and stuff like that and I told him about the Andrew Melanie thing, etc\.


**266.** `18:32` **Meredith Lamb (+14169386001)**

And yeah, I probably talked about you of course but like nothing crazy


**267.** `18:32` **Meredith Lamb (+14169386001)**

lol


**268.** `18:32` **Meredith Lamb (+14169386001)**

I told him you and Jamie went to Costco together on the weekend


**269.** `18:32` **Meredith Lamb (+14169386001)**

He rolled his eyes


**270.** `18:32` **Meredith Lamb (+14169386001)**

We both equally feel that that is weird


**271.** `18:32` **You**

whatever\.\. you watched a movie with Andrew


**272.** `18:32` **You**

point scott


**273.** `18:33` **Meredith Lamb (+14169386001)**

No


**274.** `18:33` **Meredith Lamb (+14169386001)**

I was incapacitated on the couch


**275.** `18:33` **You**

mmmmmm\.\.\.\. no disagree\. regardless\.


**276.** `18:33` **You**

like it is chores


**277.** `18:34` **You**

it would be like you going to the cottage with him to help him pack shit to bring back


**278.** `18:34` **Meredith Lamb (+14169386001)**

I will not be doing that


**279.** `18:34` **Meredith Lamb (+14169386001)**

He’s going to the COTTAGE this weekend with his family and him and McKenzie will be packing it


**280.** `18:34` **You**

I do what I have to to get through this\.\. there are no mixed messages being sent\.


**281.** `18:34` **Meredith Lamb (+14169386001)**

It isn’t about mixed messages


**282.** `18:35` **You**

this is just how we work\.\. it is how it has always worked\.\.\. she can have it this way till she leaves


**283.** `18:35` **Meredith Lamb (+14169386001)**

It’s just about you doing too much and maybe too much isn’t even the right phrase to use\. I don’t know\.


**284.** `18:35` **You**

I am not going home btw


**285.** `18:35` **You**

to move her


**286.** `18:35` **You**

I will be going home sometime in August to pick up Maddie\.


**287.** `18:35` **You**

will see Katie and Mike\. and come back


**288.** `18:36` **Meredith Lamb (+14169386001)**

I could come with lol kidding


**289.** `18:36` **You**

will be staying in Mike's basement


**290.** `18:36` **Meredith Lamb (+14169386001)**

Fun\!


**291.** `18:36` **You**

I would love to have you\.\. stop in quebec along the way\.\. you could actually stay at Mikes


**292.** `18:36` **You**

but it would be weird coming back no?


**293.** `18:36` **You**

lol


**294.** `18:36` **Meredith Lamb (+14169386001)**

Yes totally\. You’d get in trouble


**295.** `18:36` **You**

hey maddie sit with my GF for the next 14 hours


**296.** `18:36` **You**

LOL


**297.** `18:37` **Meredith Lamb (+14169386001)**

Haha


**298.** `18:37` **Meredith Lamb (+14169386001)**

I could fly back


**299.** `18:37` **Meredith Lamb (+14169386001)**

lol


**300.** `18:37` **You**

i mean you could\.\. that'd be sneaky


**301.** `18:37` **Meredith Lamb (+14169386001)**

I feel like we are pros at that now


**302.** `18:37` **You**

the planning


**303.** `18:37` **You**

yeah getting there


**304.** `18:38` **Meredith Lamb (+14169386001)**

Is he looking forward to having you in his basement?


**305.** `18:38` **You**

Mike loves when I come over


**306.** `18:38` **Meredith Lamb (+14169386001)**

When’s the last time you saw him?


**307.** `18:38` **You**

last year for a few days


**308.** `18:38` **You**

J's dad died


**309.** `18:38` **You**

his basement was rented when he first bought the house


**310.** `18:39` **You**

it is a beautiful house\.\. it has a full kitchen down there\.\. it was an in law suite eventually for his mum


**311.** `18:39` **You**

it was mine during COVID when I went to sequester for 14 days before seeing dad


**312.** `18:40` **Meredith Lamb (+14169386001)**

Nice that you had that


**313.** `18:40` **You**

it was great\.\. I worked from his basement\.\. had space\.\. was perfect


**314.** `18:42` **Meredith Lamb (+14169386001)**

That’s what friends are for 🤪


**315.** `18:43` **You**

yeah he has been there through at all\.\. talked to me yesterday when I was feeling bummed\.\. we talk about his challenges with his oldest son\.\. he is coming up here on 23\-25th of july with his youngest son\.\. to my place\.\. he will have been here a week prior at a basketball camp to the nw of toronto\.


**316.** `18:44` **Meredith Lamb (+14169386001)**

What is the camp?


**317.** `18:44` **You**

it is a nike camp\.\. not sure what it is called\.\.


**318.** `18:45` **You**

but it is a basketball camp\.\.


**319.** `18:45` **You**

:\)


**320.** `18:46` **Meredith Lamb (+14169386001)**

Long way to travel for that


**321.** `18:46` **You**

well they wanted to\.\. and Sam is a pretty good baller\.\. is a good opportunity for him to play with more elite players


**322.** `18:48` **Meredith Lamb (+14169386001)**

They live in Moncton?


**323.** `18:49` **You**

Dieppe\.\.\. technically but Greater Moncton


**324.** `18:49` **Meredith Lamb (+14169386001)**

No good basketball players? Lol


**325.** `18:50` **You**

it is east coast\.\. moncton has 120k people


**326.** `18:50` **You**

math


**327.** `18:50` **You**

lol


**328.** `18:50` **Meredith Lamb (+14169386001)**

lol
K I have ordered a desk, velvet bedframe for Mac and 2 mattresses\. Might call it but we’ll see


**329.** `18:51` **You**

shopping is SOOOO much fun lol\.


**330.** `18:51` **Meredith Lamb (+14169386001)**

I know but I feel pressured now lol


**331.** `18:51` **Meredith Lamb (+14169386001)**

Using the joint credit card lol


**332.** `18:53` **Meredith Lamb (+14169386001)**

Tyler got in another car accident today


**333.** `18:53` **Meredith Lamb (+14169386001)**

I think Jim is going to drink tonight


**334.** `18:53` **Meredith Lamb (+14169386001)**

Did you go to the Indy mktg call?


**335.** `18:54` **Meredith Lamb (+14169386001)**

Was damir on it?


**336.** `18:55` **Meredith Lamb (+14169386001)**

So the girls and I like this sectional at structube but Mac and I don’t like that it is called “Andrew”


**337.** `18:55` **Meredith Lamb (+14169386001)**

Bad karma right?


**338.** `18:56` **You**

sry was getting supped


**339.** `18:56` **You**

>
oh ffs

*💬 Reply*

**340.** `18:56` **You**

his fault?


**341.** `18:57` **You**

>
I did waste of time

*💬 Reply*

**342.** `18:57` **You**

>
he was we talked after

*💬 Reply*

**343.** `18:57` **You**

>
ROFL

*💬 Reply*

**344.** `18:57` **You**

yeah I wouldn't buy anything called Andrew


**345.** `18:57` **You**

bad joke\.\.\. blech


**346.** `19:04` **Meredith Lamb (+14169386001)**

lol


**347.** `19:04` **Meredith Lamb (+14169386001)**

>
I didn’t ask any questions\. Lol

*💬 Reply*

**348.** `19:04` **You**

i double deleted the joke


**349.** `19:04` **Meredith Lamb (+14169386001)**

What why


**350.** `19:04` **You**

cause it was dumb


**351.** `19:04` **You**

LOL


**352.** `19:04` **You**

childish


**353.** `19:05` **You**

>
unless it was a swedish toilet

*💬 Reply*

**354.** `19:05` **You**

BOOOOOOOOOOOOOO Scott\.\.\.


**355.** `19:05` **Meredith Lamb (+14169386001)**

lol


**356.** `19:05` **Meredith Lamb (+14169386001)**

It is a nice sectional though


**357.** `19:05` **You**

hehe


**358.** `19:05` **You**

So you and I could have sex on the Andrew?  how does that work for you


**359.** `19:06` **You**

still want to buy it


**360.** `19:06` **Meredith Lamb (+14169386001)**

I mean, I don’t see why not


**361.** `19:06` **You**

sick


**362.** `19:06` **You**

rofl


**363.** `19:06` **Meredith Lamb (+14169386001)**

lol


**364.** `19:07` **Meredith Lamb (+14169386001)**

So I was talking to ChatGPT earlier


**365.** `19:07` **You**

yeah


**366.** `19:08` **Meredith Lamb (+14169386001)**

You weren’t actually thinking that we would get together this morning and I would do something terrible?


**367.** `19:08` **You**

I was


**368.** `19:08` **You**

if you want all honesty


**369.** `19:08` **Meredith Lamb (+14169386001)**

After all that we have been through?


**370.** `19:08` **You**

sorry


**371.** `19:08` **You**

I know how much you have going on\.


**372.** `19:09` **You**

I cannot be at the top of your list of things to prioritize\.\. and I felt you were getting to a point where something had to give


**373.** `19:09` **You**

why did it say something bad about me because I was worried


**374.** `19:09` **Meredith Lamb (+14169386001)**

You are at the top\. I have 6 of things equally at the top lol


**375.** `19:09` **You**

>
that is impossible

*💬 Reply*

**376.** `19:10` **Meredith Lamb (+14169386001)**

To equally prioritize 6 things?


**377.** `19:10` **Meredith Lamb (+14169386001)**

No


**378.** `19:10` **Meredith Lamb (+14169386001)**

Some ppl have like 18 kids


**379.** `19:10` **You**

to even have 6 things be equal is impossible\.\. but anyways what did GPT say\.\. and I am over it now\.\. I don't think it will come again\.\.  I don't think\.\.


**380.** `19:11` **You**

It isn't that I don't feel I have worth


**381.** `19:11` **You**

And it isn't that I don't trust you


**382.** `19:11` **Meredith Lamb (+14169386001)**

You, Mac, Maelle, Mar, my parents, my dogs … 6


**383.** `19:11` **Meredith Lamb (+14169386001)**

I can prioritize those things


**384.** `19:12` **You**

it is that I just felt you were cracking\.\. and some of the things you said shook


**385.** `19:12` **Meredith Lamb (+14169386001)**

Gpt said that you were deeply afraid


**386.** `19:12` **You**

it was accurate


**387.** `19:13` **You**

>
me

*💬 Reply*

**388.** `19:13` **You**

what did you ask it?


**389.** `19:13` **You**

if you don't mind me asking


**390.** `19:13` **Meredith Lamb (+14169386001)**

k so trust in the future that I am not that flippant


**391.** `19:14` **You**

I am trying Mer\.\. somedays are harder than others\.\. but I promise not to lie\.\. even little ones\.


**392.** `19:14` **You**

not on this stuff


**393.** `19:15` **You**

no placating


**394.** `19:15` **Meredith Lamb (+14169386001)**

I uploaded screenshots


**395.** `19:15` **You**

ah


**396.** `19:15` **You**

yep\.\. that would be enough\.


**397.** `19:15` **Meredith Lamb (+14169386001)**

Then I asked it to interpret the mental state of both people\.
This exchange reveals a highly emotionally charged but loving dynamic between the two people, marked by deep affection, vulnerability, and some recent relational turbulence\. Here’s an interpretation of the mental and emotional states of both individuals:
⸻
You \(in blue\):
Emotional State: Reassuring, Loving, Grounded, Vulnerable but Committed
- Affection and Love: You openly and unequivocally express love—“I am completely in love with you and honestly believe in you as my soul mate\.” That’s a significant emotional declaration, showing you’re all in\.
- Reassurance: You’re calming him, gently correcting his fears \(“I am not calling it a day, omg… no other reason”\), and emphasizing connection over any perceived plan or agenda\.
- Playfulness Mixed with Tenderness: The “might roll my eyes or kiss you… we’ll see lol” adds warmth and levity—suggesting affection remains, even when things get tense\.
- Stability in Conflict: “I’m not going anywhere just because we have a rough day” reinforces your commitment and shows emotional maturity—you’re not reactionary\.
- Empathy: “And I’m glad your day was better and less fight club” uses humor to acknowledge his stress while softening it with care\.
You’re emotionally solid here—anchored, expressive, and offering a calm, loving presence in what seems like a fragile moment for him\.
⸻
Scott \(in grey\):
Emotional State: Anxious, Relieved, Emotionally Impacted, Self\-Aware but Fragile
- Anxiety and Insecurity: His intense emotional reaction \(“thank you… you don’t know what that just did for me”\) implies that he was deeply afraid—possibly of losing you, or that things were falling apart\.
- Overwhelmed: The phrase “you don’t know what that just did for me” signals that your reassurance hit him hard—in a good way, but also suggesting he was on edge or feeling desperate for reassurance\.
- Physiological Stress: Mentioning that his heart rate hit 178 at the gym \(possibly induced by stress\) and that he’s “a bit of a mess” reveals how much emotional and physical toll this has taken on him\.
- Relieved and Touched: Your message clearly brought him back to emotional safety\. His quick and heartfelt “thank you” indicates he feels emotionally soothed but fragile\.
⸻
Overall Dynamic:
This is a couple working through tension or a misunderstanding, likely following a difficult day or exchange\. One partner \(you\) is holding space and offering emotional safety; the other \(Scott\) is highly emotionally affected, possibly internalizing more than he communicates day to day\. There is clearly deep love on both sides—what’s happening is not a rupture but a reconnection after disconnection\.
Subtext:
Scott needed to hear those words\. You intuited that and offered them, without judgment or drama—just truth and love\. That exchange saved him emotionally in that moment\.


**398.** `19:17` **You**

so weak


**399.** `19:17` **You**

:\(


**400.** `19:17` **You**

lol


**401.** `19:17` **You**

but honest\.\.


**402.** `19:17` **Meredith Lamb (+14169386001)**

I was more wondering about you but then I got all complimented and stuff


**403.** `19:17` **Meredith Lamb (+14169386001)**

It is not weak\. You were having a moment


**404.** `19:17` **Meredith Lamb (+14169386001)**

I just don’t understand it tho


**405.** `19:18` **Meredith Lamb (+14169386001)**

You think I’m going to call it because of a small frustration


**406.** `19:19` **You**

I told you I have been down this road before\.\. I put everything out there\.\. and I have gotten burned\.\.\. you sounded really frustrated\.\. you weren't answering my questions\.\. you weren't being direct\.\. it felt like a lead up\.


**407.** `19:20` **You**

but again\.\. it was a reaction


**408.** `19:20` **Meredith Lamb (+14169386001)**

I think you just really need out of your current environment\.


**409.** `19:20` **You**

and


**410.** `19:20` **You**

that to


**411.** `19:20` **You**

but and


**412.** `19:20` **You**

I really really did want to talk to you the night before but I didn't know you were going through something


**413.** `19:20` **You**

and I really wanted to talk to you Sunday\.\. but again\.\. didn't expect that in the morning\.


**414.** `19:20` **You**

I thought we were all good\.\. if I left you alone the night before\.


**415.** `19:20` **You**

so I was a little off\.


**416.** `19:21` **Meredith Lamb (+14169386001)**

I wanted to talk to you also sat night but not really with the way you were communicating that day\. It was tiring


**417.** `19:21` **You**

I know\.\. but I tried to explain\.\.


**418.** `19:21` **You**

when I am like that I don't want to talk about me


**419.** `19:21` **Meredith Lamb (+14169386001)**

Yeah


**420.** `19:21` **You**

I want to talk about you


**421.** `19:21` **You**

or anything else\.


**422.** `19:22` **You**

but I do want to talk about it with you\.\. you are my person\.\.


**423.** `19:22` **You**

I know I was short\.\. but I tried to kind of say\.\. look nothing you say is going to make this better\.


**424.** `19:22` **You**

I know you are wired to fix\.


**425.** `19:22` **You**

so I will deal with it differently next time\.


**426.** `19:22` **Meredith Lamb (+14169386001)**

I don’t think so


**427.** `19:23` **Meredith Lamb (+14169386001)**

If we were in person it would have been different and I knew that


**428.** `19:23` **You**

yep\.\.


**429.** `19:23` **Meredith Lamb (+14169386001)**

But still was tired and frustrated


**430.** `19:23` **You**

I know\.\. I don't blame you


**431.** `19:24` **Meredith Lamb (+14169386001)**

But you are my person too so I’m not just going to up and leave


**432.** `19:24` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 19:24:18 \-0400
|
| So you have to get that out of your head
|
| Version: 1
| Sent: Mon, 7 Jul 2025 19:24:12 \-0400
|
| So you have to get that out of you head


**433.** `19:24` **You**

Like I said Text is the worst\.\. being alone with myself in this house\.\.


**434.** `19:24` **You**

yeah doesn't help


**435.** `19:24` **You**

it will be better\.


**436.** `19:24` **You**

I know it will be\.\. even if we cannot see each other regularly


**437.** `19:25` **Meredith Lamb (+14169386001)**

Griffin is eating my soup

*📎 1 attachment(s)*

**438.** `19:25` **You**

reward for haircut


**439.** `19:26` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Today is his birthday


**440.** `19:26` **Meredith Lamb (+14169386001)**

He’s 3


**441.** `19:26` **Meredith Lamb (+14169386001)**

I got him uber eats


**442.** `19:26` **Meredith Lamb (+14169386001)**

lol


**443.** `19:26` **You**

nice\!\! I love gryph\.\. he is a big cuddle bug\.


**444.** `19:28` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**445.** `19:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**446.** `19:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**447.** `19:29` **You**

lol that will be tasty


**448.** `19:29` **You**

hehe those eyes


**449.** `20:45` **Meredith Lamb (+14169386001)**

Been talking to my mom, not ignoring you


**450.** `20:46` **You**

Likely story my insecurity came up with 15 other more likely reasons\.


**451.** `20:47` **Meredith Lamb (+14169386001)**

lol


**452.** `20:48` **You**

Just getting my shit ready for tomorrow


**453.** `20:50` **You**

What glass number btw


**454.** `20:50` **Meredith Lamb (+14169386001)**

I have had 3


**455.** `20:52` **You**

And am working on a fourth?? If you have had 3


**456.** `20:53` **Meredith Lamb (+14169386001)**

Maybe working on a 4th


**457.** `20:53` **You**

Yeah


**458.** `20:53` **You**

Too easy


**459.** `20:53` **Meredith Lamb (+14169386001)**

My mom was not surprised about Melanie lol


**460.** `20:54` **You**

Well not if you told her about Andrew’s proclivities


**461.** `20:55` **Meredith Lamb (+14169386001)**

Telling her that Mac told cassy about the text\!


**462.** `20:55` **Meredith Lamb (+14169386001)**

Mac just told me on the weekend


**463.** `20:55` **You**

Hmmm


**464.** `20:55` **Meredith Lamb (+14169386001)**

Cassy is Julian’s wife


**465.** `20:55` **Meredith Lamb (+14169386001)**

Andrew’s bro


**466.** `20:55` **You**

I know


**467.** `20:55` **You**

That might be bad


**468.** `20:55` **Meredith Lamb (+14169386001)**

Apparently when Mac told her she screamed in shock


**469.** `20:55` **Meredith Lamb (+14169386001)**

LOL


**470.** `20:56` **You**

Well I mean maybe Andrew hides his deviance well


**471.** `20:57` **Meredith Lamb (+14169386001)**

I mean OF COURSE he does


**472.** `20:57` **Meredith Lamb (+14169386001)**

That has been well established


**473.** `20:57` **You**

I mean everyone hides something but that is quite a bit


**474.** `20:58` **You**

It’s human nature no one wants someone else to know 100% everything it just cannot work\.\. but that’s a lot to conceal


**475.** `21:00` **Meredith Lamb (+14169386001)**

Mackenzie will make sure nothing gets concealed


**476.** `21:00` **Meredith Lamb (+14169386001)**

lol


**477.** `21:00` **You**

Well I don’t know that that will go well for avoiding him getting pissed


**478.** `21:00` **You**

He will blame you for her finding out


**479.** `21:00` **You**

And then off we go


**480.** `21:00` **Meredith Lamb (+14169386001)**

Meh don’t care


**481.** `21:01` **You**

You are drunk or at least half way there


**482.** `21:01` **You**

You would care sober


**483.** `21:01` **You**

Reaction: ❓ from Meredith Lamb
You have been trying to avoid the anger


**484.** `21:01` **Meredith Lamb (+14169386001)**

Yes, yes I am\.  And no I wouldn’t care sober


**485.** `21:01` **You**

Mmmm hmmm


**486.** `21:02` **You**

I love you btw just want to get that in here\.\. just squeeze it in\.


**487.** `21:02` **Meredith Lamb (+14169386001)**

lol I love you too


**488.** `21:02` **You**

>
You have been trying to not piss Andrew off

*💬 Reply*

**489.** `21:03` **Meredith Lamb (+14169386001)**

Yes but once things are signed I honestly don’t care AS much


**490.** `21:03` **Meredith Lamb (+14169386001)**

I mean I care for kids


**491.** `21:03` **Meredith Lamb (+14169386001)**

But that is all


**492.** `21:03` **You**

Yeah I know what you mean


**493.** `21:03` **Meredith Lamb (+14169386001)**

Want things amicable for my kids only really


**494.** `21:04` **You**

I am sure it will work out\.\. I just need to meet him\.\. yah know shake his hand let him size me up… all will be well\.


**495.** `21:04` **You**

We will be besties


**496.** `21:04` **Meredith Lamb (+14169386001)**

Are you looking forward to that?


**497.** `21:04` **You**

\#hingebroz4life


**498.** `21:04` **You**

Kidding


**499.** `21:04` **You**

Kidding\!\!\!\!


**500.** `21:05` **Meredith Lamb (+14169386001)**

You won’t be bros


**501.** `21:05` **Meredith Lamb (+14169386001)**

Trust me


**502.** `21:05` **Meredith Lamb (+14169386001)**

And he won’t like you


**503.** `21:05` **You**

Cmon did the joke pass you by


**504.** `21:05` **Meredith Lamb (+14169386001)**

lol


**505.** `21:05` **Meredith Lamb (+14169386001)**

It did not pass me


**506.** `21:05` **You**

I know we aren’t going to be bros hence the joke


**507.** `21:05` **You**

lol


**508.** `21:05` **You**

But if we were……\.


**509.** `21:05` **You**

lol


**510.** `21:06` **Meredith Lamb (+14169386001)**

It would be funny if you were


**511.** `21:06` **Meredith Lamb (+14169386001)**

But you won’t


**512.** `21:06` **Meredith Lamb (+14169386001)**

You are too different


**513.** `21:06` **You**

It wouldn’t be funny


**514.** `21:06` **Meredith Lamb (+14169386001)**

lol


**515.** `21:06` **You**

I wouldn’t be able to


**516.** `21:06` **You**

Like I said he would say the wrong thing\.\. and yeah\.\.


**517.** `21:06` **Meredith Lamb (+14169386001)**

He won’t say anything\. That’s the thing


**518.** `21:06` **Meredith Lamb (+14169386001)**

It would be super awkward


**519.** `21:07` **Meredith Lamb (+14169386001)**

He would literally say nothing


**520.** `21:07` **You**

So ah Andrew how is the swiping going eh?


**521.** `21:07` **Meredith Lamb (+14169386001)**

lol


**522.** `21:07` **You**

Great icebreaker


**523.** `21:08` **Meredith Lamb (+14169386001)**

You are taller than him so he will be intimidated lol


**524.** `21:08` **You**

Can be much taller


**525.** `21:08` **You**

Can’t


**526.** `21:08` **Meredith Lamb (+14169386001)**

He will be like “of course Meredith is with someone taller”


**527.** `21:08` **You**

He looked close to 6


**528.** `21:08` **Meredith Lamb (+14169386001)**

He’s 5’10


**529.** `21:08` **You**

So close enough


**530.** `21:08` **Meredith Lamb (+14169386001)**

No


**531.** `21:08` **Meredith Lamb (+14169386001)**

He’s like my height


**532.** `21:08` **You**

lol of course not my mistake


**533.** `21:09` **You**

He looked taller than you in oics


**534.** `21:09` **You**

Reaction: 😂 from Meredith Lamb
Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 21:09:59 \-0400
|
| Anyway he is what he is we will
| Meet I will smile stand on my tip toes with my docs on to add 2 inches
|
| Version: 1
| Sent: Mon, 7 Jul 2025 21:09:37 \-0400
|
| Anyway he is what he is we will
| Meet I will smile stand on my tip toes with my socks on to add 2 inches


**535.** `21:10` **You**

Slowly crush his hand in a handshake until
He pulls away\.


**536.** `21:10` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 21:11:00 \-0400
|
| That is how it works in my mind
|
| Version: 1
| Sent: Mon, 7 Jul 2025 21:10:49 \-0400
|
| That is how it works in my kind


**537.** `21:11` **Meredith Lamb (+14169386001)**



**538.** `21:11` **You**

Close


**539.** `21:16` **Meredith Lamb (+14169386001)**

Yeah


**540.** `21:16` **Meredith Lamb (+14169386001)**

I’m 5’7”


**541.** `21:16` **You**

So yeah 59 510


**542.** `21:17` **Meredith Lamb (+14169386001)**

I sent Mandy and Kim this photo and when I got together with them they were like “Andrew looks horrible\!”


**543.** `21:18` **You**

I mean dad bod\.


**544.** `21:18` **Meredith Lamb (+14169386001)**

They are good friends lol


**545.** `21:19` **You**

Oh you mean\.\. ah ok


**546.** `21:19` **You**

Sry slow


**547.** `21:19` **You**

I don’t know anything hehe


**548.** `21:21` **Meredith Lamb (+14169386001)**

I deleted that photo\. We don’t need it\.


**549.** `21:22` **You**

Okie dokie


**550.** `21:22` **You**

I should delete all my photos too


**551.** `21:22` **You**

You don’t need those


**552.** `21:22` **Meredith Lamb (+14169386001)**

Nope\. I like to peruse them


**553.** `21:22` **You**

Rofl peruse\.\. like something in your collection


**554.** `21:24` **Meredith Lamb (+14169386001)**

My mom thinks Melanie is in her 30s and Andrew is lying because he has no problems lying


**555.** `21:24` **Meredith Lamb (+14169386001)**

>
It is my collection\.

*💬 Reply*

**556.** `21:25` **Meredith Lamb (+14169386001)**

I treat it like that


**557.** `21:25` **Meredith Lamb (+14169386001)**

Altho


**558.** `21:25` **Meredith Lamb (+14169386001)**

I know that you can delete at anytime so I’ve downloaded a couple


**559.** `21:25` **You**

Rofl


**560.** `21:25` **You**

I wouldn’t delete I shared them with you because I wanted to good bad whatever


**561.** `21:26` **Meredith Lamb (+14169386001)**

Honestly the kissing this morning had a more lasting impact … at least for the day today


**562.** `21:27` **You**

Yeah I didn’t want
You to go lol


**563.** `21:28` **Meredith Lamb (+14169386001)**

Same…\. That was hard


**564.** `21:29` **You**

I mean I like
Kissing you\.\. you are a good kisser \.\.
And well sparks… ⚡️


**565.** `21:30` **Meredith Lamb (+14169386001)**

You are the good kisser\. I feel very connected …\.


**566.** `21:31` **You**

We are connected it makes everything “good” 🫠


**567.** `21:33` **Meredith Lamb (+14169386001)**

Makes everything “weird” ;\)


**568.** `21:33` **You**

What does?


**569.** `21:33` **You**

Kissing?


**570.** `21:34` **Meredith Lamb (+14169386001)**

Just everything … just very connected


**571.** `21:34` **You**

Good weird


**572.** `21:34` **You**

Like good different


**573.** `21:34` **You**

lol


**574.** `21:34` **Meredith Lamb (+14169386001)**

Yes


**575.** `21:34` **Meredith Lamb (+14169386001)**

lol


**576.** `21:35` **Meredith Lamb (+14169386001)**

Very good


**577.** `21:35` **You**

Well I am happy to connect with you whenever you want wherever you want


**578.** `21:35` **Meredith Lamb (+14169386001)**

Really…\.\.


**579.** `21:36` **Meredith Lamb (+14169386001)**

If only that were true


**580.** `21:36` **You**

Is true


**581.** `21:36` **Meredith Lamb (+14169386001)**

Mmm hmm


**582.** `21:36` **You**

You pick I will be there


**583.** `21:37` **Meredith Lamb (+14169386001)**

🧐


**584.** `21:38` **You**

lol you thinking


**585.** `21:39` **Meredith Lamb (+14169386001)**

I mean I’m not saying anything or else you might do it


**586.** `21:39` **Meredith Lamb (+14169386001)**

lol


**587.** `21:39` **Meredith Lamb (+14169386001)**

I know you now


**588.** `21:40` **You**

😑


**589.** `21:40` **Meredith Lamb (+14169386001)**

>
??

*💬 Reply*

**590.** `21:40` **You**

Unfortunate you know me\.  I would have liked to know my options lol


**591.** `21:41` **Meredith Lamb (+14169386001)**

Definitely know you now\. So…… 🤐


**592.** `21:41` **Meredith Lamb (+14169386001)**

🤐


**593.** `21:42` **Meredith Lamb (+14169386001)**

🤐


**594.** `21:42` **You**

Slightly sad\.


**595.** `21:43` **Meredith Lamb (+14169386001)**

Sad or glad that I’m so sensible


**596.** `21:43` **You**

Sad


**597.** `21:45` **Meredith Lamb (+14169386001)**

Hmmh


**598.** `21:46` **You**

Don’t worry sad it a not “sad” way


**599.** `21:46` **You**

lol


**600.** `21:47` **Meredith Lamb (+14169386001)**

I know


**601.** `21:48` **Meredith Lamb (+14169386001)**

If we lived closer


**602.** `21:48` **You**

Heh yeah sry not for a year


**603.** `21:48` **You**

And even then who knows


**604.** `21:49` **Meredith Lamb (+14169386001)**

Huh?


**605.** `21:50` **You**

Stuck here for a year


**606.** `21:50` **You**

Then need to figure out where I go after


**607.** `21:50` **You**

Who knows close far… it’s a mystery


**608.** `21:50` **Meredith Lamb (+14169386001)**

>
There is no figuring out

*💬 Reply*

**609.** `21:50` **You**

Reaction: 😡 from Meredith Lamb
You are right… Aurora…
Definitely


**610.** `21:51` **You**

We will see lol it will likely be closer


**611.** `21:52` **Meredith Lamb (+14169386001)**

Closer to what?


**612.** `21:53` **You**

Closer to you


**613.** `21:53` **Meredith Lamb (+14169386001)**

Or with me ?


**614.** `21:53` **You**

You are
Sweet
And drunk and I would today\.\. let alone then\.\. but I don’t think
That would be doable\.


**615.** `21:54` **Meredith Lamb (+14169386001)**

We can do the pre nup, no worries


**616.** `21:54` **You**

I am not worried


**617.** `21:54` **Meredith Lamb (+14169386001)**

lol


**618.** `21:54` **You**

It’s called a cohabitation agreement


**619.** `21:54` **You**

Prenup is for marriage


**620.** `21:54` **You**

We can do that too though


**621.** `21:54` **You**

lol


**622.** `21:55` **Meredith Lamb (+14169386001)**

lol I can’t even believe you would want to


**623.** `21:55` **You**

I would


**624.** `21:55` **You**

Timing etc but it doesn’t matter I know you wouldn’t and that is cool


**625.** `21:56` **You**

I asked for last night lol


**626.** `21:56` **You**

I asked gore


**627.** `21:56` **You**

Uggh


**628.** `21:56` **You**

Gpt


**629.** `21:56` **You**

After I pasted you stuff in


**630.** `21:56` **You**

I have it context


**631.** `21:56` **You**

Gave


**632.** `21:56` **Meredith Lamb (+14169386001)**

You asked gpt what


**633.** `21:57` **You**

Asked if there was a chance
You would ever change your mind and what would that look like\.\. to be clear I do not care how we are together just that we are… just to be clear\.\. lol


**634.** `21:58` **Meredith Lamb (+14169386001)**

“Just to be clear”


**635.** `21:58` **You**

Anyhow it had a response that was interesting but I deleted it


**636.** `21:58` **Meredith Lamb (+14169386001)**

Ugh


**637.** `21:58` **Meredith Lamb (+14169386001)**

Do you kind of remember a synopsis


**638.** `21:58` **You**

Yeah


**639.** `22:01` **You**

It had to do with you being comfortable enough to allow yourself to be fully seen, For who you are to know that you were loved for that alone and nothing else\.\. and that you could trust that the other person was fully committed\.\. something about not worrying about being left\.\. which was weird


**640.** `22:01` **You**

Because you never have been left


**641.** `22:01` **Meredith Lamb (+14169386001)**

I have so been left


**642.** `22:02` **You**

If you are talking about Andrew I get that\.\.


**643.** `22:02` **Meredith Lamb (+14169386001)**

No not talking about him


**644.** `22:02` **You**

I thought you told me you never were


**645.** `22:03` **You**

You don’t have to talk about it if you don’t want to


**646.** `22:05` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 22:05:13 \-0400
|
| I mean Jeremy and I … even though it was kind of mutual …
|
| Version: 1
| Sent: Mon, 7 Jul 2025 22:05:04 \-0400
|
| I mean Jeremy and I … even thought it was kind of mutual …


**647.** `22:05` **Meredith Lamb (+14169386001)**

He still kind of left lol


**648.** `22:05` **Meredith Lamb (+14169386001)**

I don’t F’ing care about Andrew


**649.** `22:05` **You**

I mean I know what it feels like…


**650.** `22:05` **You**

Can tell you that much


**651.** `22:06` **You**

It I wasn’t engaged


**652.** `22:06` **You**

But


**653.** `22:06` **You**

I wasn’t


**654.** `22:06` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
But as to whether I would change my mind on marriage, I would never consider it for anyone but you


**655.** `22:08` **You**

Well like I said I will be with you however you will have me 🫠


**656.** `22:08` **You**

Sorry about Jeremy though sounds like it hurt a lot more than you let on initially


**657.** `22:09` **You**

I mean you did say you went kind of rage


**658.** `22:09` **You**

Ragey


**659.** `22:09` **You**

That night


**660.** `22:09` **You**

At cottage


**661.** `22:09` **You**

I just didn’t think anything of it


**662.** `22:09` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 22:09:34 \-0400
|
| Ragey?
|
| Version: 1
| Sent: Mon, 7 Jul 2025 22:09:25 \-0400
|
| Target?


**663.** `22:09` **You**

You wrote about it in your blog


**664.** `22:09` **Meredith Lamb (+14169386001)**

Huh?


**665.** `22:09` **You**

I never read it you told me


**666.** `22:09` **You**

About your breakup


**667.** `22:09` **Meredith Lamb (+14169386001)**

Refresh my memory


**668.** `22:10` **You**

That is how Andrew knew to reach out


**669.** `22:10` **You**

I think you said you deleted all your pics or something


**670.** `22:10` **You**

I dunno lol you were hammered


**671.** `22:11` **You**

Or maybe it was al the blogs


**672.** `22:11` **Meredith Lamb (+14169386001)**

I’m so confused right now


**673.** `22:11` **You**

I cannot recall


**674.** `22:11` **You**


*📎 1 attachment(s)*

**675.** `22:12` **Meredith Lamb (+14169386001)**

>
You l didn’t read my break up post?

*💬 Reply*

**676.** `22:12` **You**

Nope


**677.** `22:12` **Meredith Lamb (+14169386001)**

I can’t listen to this bc still talking to my mom

*💬 Reply*

**678.** `22:12` **You**

Holy shit still


**679.** `22:12` **You**

How do you do it


**680.** `22:12` **Meredith Lamb (+14169386001)**

>
Didn’t I send it to you tho?

*💬 Reply*

**681.** `22:13` **You**

I don’t think so


**682.** `22:13` **You**

If you did I deleted it


**683.** `22:13` **Meredith Lamb (+14169386001)**

>
My mom and I are friends kind of sometimes

*💬 Reply*

**684.** `22:13` **You**

It would have been


**685.** `22:13` **You**

In messenger


**686.** `22:13` **Meredith Lamb (+14169386001)**

It’s a boring post


**687.** `22:13` **You**

Anyhow the way you characterized it when we first talked


**688.** `22:13` **You**

First


**689.** `22:13` **You**

Was that he was crazy


**690.** `22:13` **You**

And it got really crazy


**691.** `22:14` **You**

And you both decided to end it or something but that you were really pissed


**692.** `22:14` **You**

I figured some unresolved stuff


**693.** `22:14` **You**

We all have that


**694.** `22:15` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**695.** `22:15` **You**

I am sorry you got hurt though\.


**696.** `22:15` **Meredith Lamb (+14169386001)**

He wasn’t “crazy”


**697.** `22:15` **Meredith Lamb (+14169386001)**

Per se


**698.** `22:15` **Meredith Lamb (+14169386001)**

He was fun


**699.** `22:16` **You**

Yeah I saw this


**700.** `22:16` **Meredith Lamb (+14169386001)**

But we were bad together


**701.** `22:16` **You**

That is unfortunate


**702.** `22:16` **Meredith Lamb (+14169386001)**

We fuelled each other’s bad sides


**703.** `22:16` **You**

Yeah it can happen\.\.


**704.** `22:16` **Meredith Lamb (+14169386001)**

>
Well that was the post that Andrew responded to

*💬 Reply*

**705.** `22:17` **You**

Yep that’s why you shared it last time I think you were explaining what happened with andrew


**706.** `22:17` **You**

The story really wasn’t about Jeremy then


**707.** `22:17` **You**

Well anyhow gpt felt that you had trust issues


**708.** `22:17` **You**

Commitment fears


**709.** `22:18` **You**

And fear of people knowing you truly and seeing you for who you were and still loving you


**710.** `22:18` **You**

Or something Mike that


**711.** `22:18` **You**

Like


**712.** `22:18` **Meredith Lamb (+14169386001)**

My mom just asked if you had a vasectomy


**713.** `22:18` **Meredith Lamb (+14169386001)**

Omg


**714.** `22:18` **You**

wtf mum


**715.** `22:18` **Meredith Lamb (+14169386001)**

lol


**716.** `22:18` **You**

Why


**717.** `22:18` **You**

Because you told her we had a romping good time last weekend


**718.** `22:18` **You**

Cmon Mer


**719.** `22:19` **Meredith Lamb (+14169386001)**

No


**720.** `22:20` **Meredith Lamb (+14169386001)**

She just asked


**721.** `22:20` **Meredith Lamb (+14169386001)**

Not sure why


**722.** `22:20` **You**

I am I\. The process


**723.** `22:20` **Meredith Lamb (+14169386001)**

>
I am not sure if I do

*💬 Reply*

**724.** `22:20` **You**

Well what I said earlier that was the synopsis


**725.** `22:21` **You**

Reaction: 😂 from Meredith Lamb
I never figured I would ask because I never thought it was an option\.\. last time I brought it up  I got    Ugghhhhhhjjhjjjhhh


**726.** `22:21` **You**

lol


**727.** `22:22` **You**

But mer soulmate my person my home of course I would think about it\.\. just not dwell on it\.\. it was never part of the deal and I was absolutely fine with that


**728.** `22:23` **You**

anyhow I would live with you and sign a prenup Mer\.\. given the chance lol


**729.** `22:27` **Meredith Lamb (+14169386001)**

My mom is very concerned that I’m going to get pregnant


**730.** `22:28` **Meredith Lamb (+14169386001)**

She doesn’t believe in abortion


**731.** `22:28` **Meredith Lamb (+14169386001)**

I was like


**732.** `22:28` **Meredith Lamb (+14169386001)**

I would get an abortion in an instant


**733.** `22:28` **You**

Ok so yeah sharing right lol


**734.** `22:29` **You**

>
I would support that 100%\.  In another lifetime I would have loved the opportunity but too risky and you are done\.\. you have finished that part of your oide

*💬 Reply*

**735.** `22:29` **You**

Life


**736.** `22:29` **Meredith Lamb (+14169386001)**

Reaction: ❓ from Scott Hicks
Yeeeeeeeeah


**737.** `22:30` **Meredith Lamb (+14169386001)**

>
Never part of the deal lol

*💬 Reply*

**738.** `22:30` **You**

Kk trying to follow


**739.** `22:30` **You**

lol you are bouncing


**740.** `22:31` **Meredith Lamb (+14169386001)**

>
I meant yeah I’m not having a baby

*💬 Reply*

**741.** `22:31` **You**

Ok yeah I know I was just like it is so drawn out…\.\. didn’t quite get it\.


**742.** `22:31` **You**

>
It wasn’t you told me

*💬 Reply*

**743.** `22:31` **You**

I believed you


**744.** `22:31` **You**

But still you know I am gonna think


**745.** `22:32` **You**

>
How much details have you given her

*💬 Reply*

**746.** `22:33` **Meredith Lamb (+14169386001)**

I mean she isn’t stupid


**747.** `22:33` **Meredith Lamb (+14169386001)**

I don’t have to give her details


**748.** `22:33` **Meredith Lamb (+14169386001)**

In her younger years she would try to talk sex to me and I would plug my ears


**749.** `22:34` **Meredith Lamb (+14169386001)**

Like she would try to tell me about her sex life


**750.** `22:34` **You**

Yeah but there is a diff to we had unprotected sex to we had unprotected sex 10 or 11 times or more in 5
Days


**751.** `22:34` **Meredith Lamb (+14169386001)**

lol


**752.** `22:35` **You**

I think it was more


**753.** `22:35` **You**

If I had to guess


**754.** `22:35` **Meredith Lamb (+14169386001)**

>
Whatever I had already ovulated a few days prior so I’m 75% worried

*💬 Reply*

**755.** `22:35` **Meredith Lamb (+14169386001)**

Not 100%


**756.** `22:35` **You**

I am still sorry was selfish of me


**757.** `22:35` **Meredith Lamb (+14169386001)**

Or selfish of me?


**758.** `22:36` **Meredith Lamb (+14169386001)**

Ok off the phone with her finally lol


**759.** `22:36` **You**

I don’t know\.\. lol no clue I just no how amazing it felt being with you\.\. and then you your face eyes\.\. and\. Nothing else\.\. eeesh


**760.** `22:37` **Meredith Lamb (+14169386001)**

Trust me, I know……


**761.** `22:37` **Meredith Lamb (+14169386001)**

You don’t need to explain anything


**762.** `22:38` **You**

>
We should talk about this sometime down the road especially when you are sober\.

*💬 Reply*

**763.** `22:39` **Meredith Lamb (+14169386001)**

Last thing my mom said to me before hanging up, “make a doctors appointment” lol


**764.** `22:39` **Meredith Lamb (+14169386001)**

I am sober\. Water\.


**765.** `22:39` **You**

Maybe you should


**766.** `22:40` **You**

>
Well then we will just talk about it further down the road\.\. I know how I feel but it think there is a lot you need to sort through for\. While yet\.  Life emotions everything

*💬 Reply*

**767.** `22:40` **Meredith Lamb (+14169386001)**

She thinks I should get my tubes tied


**768.** `22:40` **You**

J did\.


**769.** `22:40` **You**

After maddie


**770.** `22:40` **Meredith Lamb (+14169386001)**

I never did bc we weren’t sure\. My mom and sis did tho


**771.** `22:41` **Meredith Lamb (+14169386001)**

Then my dr thought it was unfair


**772.** `22:41` **Meredith Lamb (+14169386001)**

Vasectomy easier than tubes tied procedure


**773.** `22:41` **You**

I know\.\. waiting for the doctor to call me


**774.** `22:41` **You**

Will be a few months unfortunately


**775.** `22:41` **Meredith Lamb (+14169386001)**

So I convinced Andrew to do it just bc of my dr really …


**776.** `22:42` **Meredith Lamb (+14169386001)**

I honestly didn’t care but Angela was like “he should do it”


**777.** `22:42` **Meredith Lamb (+14169386001)**

lol


**778.** `22:42` **Meredith Lamb (+14169386001)**

He waited years


**779.** `22:42` **Meredith Lamb (+14169386001)**

But he eventually did


**780.** `22:43` **You**

Yeaaaaaaaaaah


**781.** `22:43` **Meredith Lamb (+14169386001)**

Now his young gf will be upset lol


**782.** `22:43` **You**

Sweet


**783.** `22:43` **You**

I can delete your messages


**784.** `22:43` **Meredith Lamb (+14169386001)**

lol


**785.** `22:43` **You**

And I did 🙂


**786.** `22:44` **Meredith Lamb (+14169386001)**

Why


**787.** `22:44` **You**

Just didn’t need that sentence


**788.** `22:44` **Meredith Lamb (+14169386001)**

Which one


**789.** `22:44` **You**



**790.** `22:44` **Meredith Lamb (+14169386001)**

Oh lol


**791.** `22:44` **Meredith Lamb (+14169386001)**

Sorry


**792.** `22:44` **You**

Nope all good


**793.** `22:45` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 22:45:24 \-0400
|
| We were never really stupid like you and I
|
| Version: 1
| Sent: Mon, 7 Jul 2025 22:45:06 \-0400
|
| We weren’t never really stupid like you and I


**794.** `22:45` **Meredith Lamb (+14169386001)**

Just to be clear


**795.** `22:45` **You**

I am sure you had your stupid moments


**796.** `22:45` **You**

You were together for 20 years


**797.** `22:45` **You**

Of course you were at one point lol


**798.** `22:46` **Meredith Lamb (+14169386001)**

Andrew and I were just diff than you and I


**799.** `22:47` **Meredith Lamb (+14169386001)**

And I am not just saying that bc I’ve been drinking


**800.** `22:47` **Meredith Lamb (+14169386001)**

It is the truth


**801.** `22:47` **Meredith Lamb (+14169386001)**

lol


**802.** `22:47` **You**

Reaction: 😂 from Meredith Lamb
Yes different I know that is the truth\!\!


**803.** `22:47` **Meredith Lamb (+14169386001)**

I feel like i increased your anxiety


**804.** `22:47` **You**

lol


**805.** `22:47` **You**

No stop your text empathy is failing you


**806.** `22:47` **You**

I deleted what I didn’t want to keep


**807.** `22:48` **Meredith Lamb (+14169386001)**

Was it a lot


**808.** `22:48` **You**

Not a lot


**809.** `22:48` **You**

I will remember it anyways lol


**810.** `22:48` **You**

Brain


**811.** `22:48` **You**

Rofl


**812.** `22:48` **Meredith Lamb (+14169386001)**

Oh no


**813.** `22:48` **Meredith Lamb (+14169386001)**

Bad?


**814.** `22:48` **You**

No mer it isn’t bad


**815.** `22:48` **Meredith Lamb (+14169386001)**

I don’t think I’ve said anything bad


**816.** `22:49` **You**

No just imagery I don’t need


**817.** `22:49` **You**

It’s fine


**818.** `22:49` **Meredith Lamb (+14169386001)**

LOL fair enough


**819.** `22:49` **You**

Roulette and pull out


**820.** `22:49` **You**

If you are curious


**821.** `22:49` **You**

Those I deleted


**822.** `22:49` **Meredith Lamb (+14169386001)**

lol


**823.** `22:49` **Meredith Lamb (+14169386001)**

Sorry


**824.** `22:49` **You**

It’s fine


**825.** `22:50` **You**

I told you I am better with this stuff


**826.** `22:50` **Meredith Lamb (+14169386001)**

I told my mom about your stark honesty thing tonight and she was like “yup”


**827.** `22:50` **Meredith Lamb (+14169386001)**

lol


**828.** `22:50` **You**

Your inability to articulate different is still annoying


**829.** `22:50` **You**

>
Well apple tree

*💬 Reply*

**830.** `22:50` **Meredith Lamb (+14169386001)**

But yup because she has the stark honesty issue also


**831.** `22:51` **You**

Yah


**832.** `22:51` **Meredith Lamb (+14169386001)**

>
I’m happy to be more explicit if I can

*💬 Reply*

**833.** `22:51` **Meredith Lamb (+14169386001)**

>
Phew

*💬 Reply*

**834.** `22:52` **You**

You know whenever you say explicit I feel like I am playing a tricky game\.\.


**835.** `22:52` **Meredith Lamb (+14169386001)**

What why?


**836.** `22:53` **You**

Well I don’t know where you are going to go


**837.** `22:53` **You**

Rofl


**838.** `22:53` **Meredith Lamb (+14169386001)**

Okkkkkk


**839.** `22:54` **You**

Well I am listening in for a penny


**840.** `22:54` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/43h4FonpCeaaURpFpiQsf9?si=gOiBy5M9QIOQz6dM0GmCKg
Throwback for you


**841.** `22:54` **Meredith Lamb (+14169386001)**

>
I don’t know what this means

*💬 Reply*

**842.** `22:55` **You**

In for a penny in for a pound


**843.** `22:55` **You**

Be explicit


**844.** `22:55` **You**

It’s like activating the nsfw ChatGPT mode


**845.** `22:55` **You**

>
>
Great song

*💬 Reply*

**846.** `22:56` **Meredith Lamb (+14169386001)**

>
I chat gptd this… applies very well

*💬 Reply*

**847.** `22:56` **You**

Yeah I know lol


**848.** `22:56` **You**

Reaction: ❤️ from Meredith Lamb
I am in for a pound with you Mer


**849.** `22:56` **You**

Bigtime


**850.** `22:57` **You**

Ok have you lost
Track of where we are now


**851.** `22:58` **Meredith Lamb (+14169386001)**

No, just processing


**852.** `22:58` **Meredith Lamb (+14169386001)**

My brain is slower than yours lol


**853.** `22:58` **Meredith Lamb (+14169386001)**

I don’t have adhd


**854.** `22:58` **Meredith Lamb (+14169386001)**

Mine is slower


**855.** `22:58` **You**

What part are you processing


**856.** `22:58` **Meredith Lamb (+14169386001)**

lol


**857.** `22:58` **You**

Still in the different


**858.** `22:58` **You**

On


**859.** `22:58` **You**

Or something else


**860.** `22:59` **Meredith Lamb (+14169386001)**

I just had a moment …


**861.** `22:59` **Meredith Lamb (+14169386001)**

Listening to music


**862.** `22:59` **Meredith Lamb (+14169386001)**

Then you said that


**863.** `22:59` **Meredith Lamb (+14169386001)**

Just had a moment


**864.** `22:59` **You**

What was the moment


**865.** `23:00` **Meredith Lamb (+14169386001)**

Moment: I miss you\. I wish I was with you\. Thinking about being with you this morning\.
Was a moment…\.


**866.** `23:02` **You**

Nice moment


**867.** `23:02` **You**

Reaction: ❤️ from Meredith Lamb
https://open\.spotify\.com/track/5hnyJvgoWiQUYZttV4wXy6?si=YPFQD6\_\_RYyvCfp2taBNdQ&context=spotify%3Asearch%3Achasing%2Bcars


**868.** `23:02` **You**

Try this for moments


**869.** `23:02` **You**

I am


**870.** `23:04` **Meredith Lamb (+14169386001)**

🤍🤍🤍🤍🤍🤍


**871.** `23:05` **You**

I think honestly between this and only exception this has to be my love song to you\.\. the words make complete sense\.\.


**872.** `23:06` **You**

I love both songs but this one literally describes all of my feelings everything I want


**873.** `23:07` **You**

Maybe this is the song we dance to\.


**874.** `23:08` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I love that because I can literally close my eyes and think of you


**875.** `23:13` **You**

Well I think you might be all done tonight lol\.\. we didn’t get to explicitly different\.\. but we did cover some interesting topics ❤️❤️❤️😇😇😇


**876.** `23:13` **You**

https://open\.spotify\.com/track/7JIuqL4ZqkpfGKQhYlrirs?si=F2zIbzGgR7qor71NS\_Q8WA&context=spotify%3Aplaylist%3A4o0w2C4v7JfY6AwQTKoWoD


**877.** `23:14` **You**

Maybe go to sleep listening to this tonight


**878.** `23:14` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 23:17:57 \-0400
|
| You can tell me more about different some other time\.  And maybe we can talk about that prenup when you actually are sober… you are the only person I want to spend the rest of my life with\.\. however you want to do that I am game\.\. I would be happy to be with you in any capacity\.\.
|
| Version: 1
| Sent: Mon, 7 Jul 2025 23:14:21 \-0400
|
| You can tell me more about different some other time\.


**879.** `23:15` **You**

I think maybe you already crashed lol\.\.


**880.** `23:18` **Meredith Lamb (+14169386001)**

I was talking to Andrew about English


**881.** `23:18` **Meredith Lamb (+14169386001)**

Mac has some assignment due to midnight


**882.** `23:18` **You**

The language or her asssignmnmebt


**883.** `23:18` **You**

Yeah


**884.** `23:18` **Meredith Lamb (+14169386001)**

I thought I edited it last night


**885.** `23:18` **Meredith Lamb (+14169386001)**

Learning she might not have answered it right\. Shit show


**886.** `23:18` **Meredith Lamb (+14169386001)**

I’m like I’m out


**887.** `23:18` **Meredith Lamb (+14169386001)**

Can’t do that shit drinking


**888.** `23:18` **You**

Shit that sucks


**889.** `23:19` **Meredith Lamb (+14169386001)**

He can do it


**890.** `23:19` **You**

Well if you need to go help you can bounce off


**891.** `23:19` **You**

I was talking to myself for\. Bit


**892.** `23:19` **Meredith Lamb (+14169386001)**

What do you have against different


**893.** `23:19` **Meredith Lamb (+14169386001)**

It is just a word


**894.** `23:19` **You**

It doesn’t mean anything


**895.** `23:19` **Meredith Lamb (+14169386001)**

🙄


**896.** `23:19` **You**

Hey honey how do I look tonight… mmm different


**897.** `23:20` **You**

Hey how was that \(insert sexual thing\)\. That I just did … mmmmm different


**898.** `23:20` **You**

lol


**899.** `23:20` **Meredith Lamb (+14169386001)**

LOL


**900.** `23:20` **You**

I am going to use that all the time I swear\!\! lol


**901.** `23:20` **Meredith Lamb (+14169386001)**

Ok touché


**902.** `23:20` **You**

So you have said it twice and you said you would be explicit


**903.** `23:21` **Meredith Lamb (+14169386001)**

Happy to be explicit


**904.** `23:21` **Meredith Lamb (+14169386001)**

Specific


**905.** `23:22` **You**

\*\*waits patiently \*\*


**906.** `23:23` **Meredith Lamb (+14169386001)**

I can’t remember the situations


**907.** `23:23` **Meredith Lamb (+14169386001)**

I think I remember the first


**908.** `23:23` **You**

The second was tonight


**909.** `23:23` **You**

You wrote it


**910.** `23:23` **You**

The other was on our trip


**911.** `23:23` **Meredith Lamb (+14169386001)**

Tonight?\!


**912.** `23:23` **You**

Actually


**913.** `23:23` **You**

No


**914.** `23:23` **You**

It was at the hotel


**915.** `23:24` **You**

The last day hotel


**916.** `23:24` **You**

and yes tonight


**917.** `23:24` **You**

>
Sure

*💬 Reply*

**918.** `23:25` **You**

But you know what maybe ignore


**919.** `23:25` **Meredith Lamb (+14169386001)**

Sorry


**920.** `23:25` **You**

lol


**921.** `23:25` **Meredith Lamb (+14169386001)**

So the first time I think I remember


**922.** `23:28` **Meredith Lamb (+14169386001)**

And I just meant like when we first were in Detroit and Chatham together, you were a bit more insecure and stuff… then when I said you were different, I meant like you were the complete opposite… more confident, intense and it just was a different you\. You seemed different\. It was a good progression though but it was different for sure\. No? Am I wrong?


**923.** `23:29` **You**

Nope not wrong


**924.** `23:29` **You**

You were too


**925.** `23:29` **You**

Btw


**926.** `23:29` **You**

Reserved


**927.** `23:29` **You**

Held back


**928.** `23:30` **Meredith Lamb (+14169386001)**

Angelic?


**929.** `23:30` **Meredith Lamb (+14169386001)**

lol


**930.** `23:30` **You**

Mmmmm


**931.** `23:30` **Meredith Lamb (+14169386001)**

Hahah


**932.** `23:30` **You**

But you were


**933.** `23:30` **You**

I could tell


**934.** `23:31` **Meredith Lamb (+14169386001)**

Well we were learning each other’s language


**935.** `23:31` **You**

Yep


**936.** `23:31` **Meredith Lamb (+14169386001)**

I didn’t want to scare you off


**937.** `23:31` **Meredith Lamb (+14169386001)**

Still don’t


**938.** `23:31` **You**

lol hardly


**939.** `23:31` **You**

You still holding back I guess


**940.** `23:31` **Meredith Lamb (+14169386001)**

Never


**941.** `23:32` **You**

Then why do you think you will scare me off


**942.** `23:32` **Meredith Lamb (+14169386001)**

I don’t think I would


**943.** `23:32` **Meredith Lamb (+14169386001)**

I don’t really scare anyone


**944.** `23:32` **You**

Sorry you said still don’t\.\.


**945.** `23:32` **You**

Just sounded like you were worried


**946.** `23:33` **Meredith Lamb (+14169386001)**

I’m not worried unless you are


**947.** `23:33` **You**

You are talking in circles now


**948.** `23:33` **You**

Rofl


**949.** `23:33` **Meredith Lamb (+14169386001)**

LOL


**950.** `23:33` **You**

Let me ask you this


**951.** `23:33` **You**

Direct question


**952.** `23:34` **You**

Why were you concerned about scaring me off in Detroit and Chatham\.  And then why did you say you still are


**953.** `23:35` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 23:36:13 \-0400
|
| I’m not actually scared of scaring you off\. But it is a little scary to think about your recent years sometimes … not all the time, sometimes
|
| Version: 1
| Sent: Mon, 7 Jul 2025 23:35:56 \-0400
|
| I’m not actually scared of acting you off\. But it is a little scary to think about your recent years sometimes … not all the time, sometimes


**954.** `23:36` **You**

You mean my abstinence years


**955.** `23:36` **You**

lol


**956.** `23:37` **You**

Yeah those were good times


**957.** `23:37` **Meredith Lamb (+14169386001)**

Not exactly that per se\. I’m all for that if there is a reason


**958.** `23:37` **Meredith Lamb (+14169386001)**

It just seems like you ignored yourself


**959.** `23:37` **Meredith Lamb (+14169386001)**

But I probably did too


**960.** `23:37` **You**

Mmmmm no


**961.** `23:37` **Meredith Lamb (+14169386001)**

So being hypocritical


**962.** `23:37` **You**

?? Ignored
Myself?


**963.** `23:38` **Meredith Lamb (+14169386001)**

Your relationship


**964.** `23:38` **You**

Ohhhhhh yeah I tried to make it work\.\.
Just couldn’t\. Sex was never that central to our relationship\.\. connection was not there


**965.** `23:38` **You**

Told you that


**966.** `23:39` **Meredith Lamb (+14169386001)**

I know, you did …


**967.** `23:40` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 7 Jul 2025 23:43:04 \-0400
|
| I’m not sure how we got on that topic but I think it had to do with a word that you don’t like which I will never use again 🫢
|
| Version: 1
| Sent: Mon, 7 Jul 2025 23:40:41 \-0400
|
| I’m not sure how we got on that topic but I think it had to do with a word Elton don’t like which I will never use again 🫢


**968.** `23:41` **You**

I am so confused


**969.** `23:41` **You**

lol


**970.** `23:41` **Meredith Lamb (+14169386001)**

LOL


**971.** `23:41` **You**

Like what are you talking about


**972.** `23:41` **Meredith Lamb (+14169386001)**

So much for direct questions


**973.** `23:41` **Meredith Lamb (+14169386001)**

Haha


**974.** `23:42` **Meredith Lamb (+14169386001)**

Good job


**975.** `23:42` **You**

Reaction: 🌈 from Meredith Lamb
Yeah you just fucking bounced on down the rainbow road


**976.** `23:42` **You**

I don’t even know what you are talking about lol you win


**977.** `23:42` **You**

>
wtf

*💬 Reply*

**978.** `23:42` **You**

>
wtf

*💬 Reply*

**979.** `23:43` **You**

All for abstinence???


**980.** `23:43` **You**

Rofl


**981.** `23:43` **You**

I am not


**982.** `23:43` **You**

For the record


**983.** `23:43` **Meredith Lamb (+14169386001)**

If there is a reason I’m all for it


**984.** `23:43` **You**

I don’t know of a reason


**985.** `23:43` **You**

Other than what happened with j


**986.** `23:43` **Meredith Lamb (+14169386001)**

Well there are some


**987.** `23:44` **You**

What word didn’t Elton like


**988.** `23:44` **You**

How many gummies have you had


**989.** `23:44` **Meredith Lamb (+14169386001)**

I edited


**990.** `23:44` **Meredith Lamb (+14169386001)**

It was a typo


**991.** `23:44` **Meredith Lamb (+14169386001)**

lol


**992.** `23:44` **Meredith Lamb (+14169386001)**

Omg


**993.** `23:44` **Meredith Lamb (+14169386001)**

No gummies


**994.** `23:44` **You**

A word I don’t like


**995.** `23:44` **Meredith Lamb (+14169386001)**

“Different”


**996.** `23:45` **You**

Sigh


**997.** `23:45` **Meredith Lamb (+14169386001)**

lol


**998.** `23:45` **You**

Do you want to know what I think mer


**999.** `23:45` **Meredith Lamb (+14169386001)**

I will attempt to be more descriptive in the future


**1000.** `23:45` **Meredith Lamb (+14169386001)**

>
Always

*💬 Reply*

**1001.** `23:46` **You**

I think you asked about being open a while ago for a reason


**1002.** `23:46` **You**

After Detroit


**1003.** `23:46` **You**

And Chatham


**1004.** `23:46` **You**

Because there is a part of you\.\. not sure how much or how little


**1005.** `23:46` **Meredith Lamb (+14169386001)**

>
I will never live this down

*💬 Reply*

**1006.** `23:46` **You**

That probably is a little wild\.\. perhaps


**1007.** `23:46` **You**

And I suspect you are still holding back


**1008.** `23:47` **You**

Because you are worried about how I might react


**1009.** `23:47` **You**

You shouldn’t


**1010.** `23:47` **You**

If I am right


**1011.** `23:48` **Meredith Lamb (+14169386001)**

I think you took what I said and really ran with it …\.\. but perhaps there is some truth to that but I think you are overthinking it


**1012.** `23:48` **You**

Maybe\.\.
But I don’t think so


**1013.** `23:49` **Meredith Lamb (+14169386001)**

You have no basis for that thought other than your overthinking


**1014.** `23:49` **Meredith Lamb (+14169386001)**

And ocd


**1015.** `23:49` **You**

It true


**1016.** `23:49` **You**

Not


**1017.** `23:49` **You**

True


**1018.** `23:49` **You**

Remember


**1019.** `23:49` **You**

Two things


**1020.** `23:50` **You**

1\. You told stories and I am sorry you cannot remember 🙁


**1021.** `23:50` **You**

Reaction: 🤔 from Meredith Lamb
2\. We played I never


**1022.** `23:50` **You**

So I think between those two things


**1023.** `23:51` **You**

I feel my assumptions are relatively supported


**1024.** `23:51` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
I don’t think I actually told stories

*💬 Reply*

**1025.** `23:51` **You**

Kk


**1026.** `23:51` **Meredith Lamb (+14169386001)**

>
I don’t fully remember this so it doesn’t count

*💬 Reply*

**1027.** `23:51` **You**

Getting close to bedtime I think


**1028.** `23:51` **You**

Mer


**1029.** `23:51` **Meredith Lamb (+14169386001)**

Yeah


**1030.** `23:51` **You**

We wrote it down


**1031.** `23:52` **You**

lol


**1032.** `23:52` **Meredith Lamb (+14169386001)**

Oh yikes


**1033.** `23:52` **You**

It is in these chats


**1034.** `23:52` **Meredith Lamb (+14169386001)**

lol really


**1035.** `23:52` **You**

There were like 69 questions


**1036.** `23:52` **Meredith Lamb (+14169386001)**

Ohhhhh


**1037.** `23:52` **You**

Remeber we had the convo about you and I in the theatre


**1038.** `23:52` **Meredith Lamb (+14169386001)**

I remember now


**1039.** `23:52` **You**

Well that was one of the questions


**1040.** `23:52` **You**

So again stories plus that is enough for me to go by


**1041.** `23:53` **You**

That and my experience with you already


**1042.** `23:53` **Meredith Lamb (+14169386001)**

And you would kick me to the curb


**1043.** `23:53` **Meredith Lamb (+14169386001)**

Kidding


**1044.** `23:53` **You**

What??


**1045.** `23:54` **Meredith Lamb (+14169386001)**

I’m kidding


**1046.** `23:54` **You**

Where did that come from


**1047.** `23:54` **Meredith Lamb (+14169386001)**

lol


**1048.** `23:54` **Meredith Lamb (+14169386001)**

You said: Because you are worried about how I might react


**1049.** `23:55` **You**

I feel like you are
Worried I am trying to say you don’t have to be


**1050.** `23:55` **Meredith Lamb (+14169386001)**

I’m not worried


**1051.** `23:55` **You**

But it’s fine\.\. if you already are all in it’s all good I love what we have


**1052.** `23:55` **You**

Just saying I am up for whatever you can throw at me Mer\.\. 🙂


**1053.** `23:56` **You**

Shouldn’t talk too much like this though we not gonna have the opportunity for a bit so best not to get all frustrated lol


**1054.** `23:57` **Meredith Lamb (+14169386001)**

I love what we have too… I’ve just been teasing tonight


**1055.** `23:57` **You**

Testing or teasing?


**1056.** `23:57` **You**

Heh


**1057.** `23:57` **Meredith Lamb (+14169386001)**

😇


**1058.** `23:58` **You**

I never know


**1059.** `23:58` **You**

You are so smart something I think that could be a slip might\. E intentional


**1060.** `23:58` **Meredith Lamb (+14169386001)**

😇


**1061.** `23:58` **Meredith Lamb (+14169386001)**

No comment


**1062.** `23:58` **Meredith Lamb (+14169386001)**

Bed time?


**1063.** `23:58` **You**

Mmm hmm


**1064.** `23:59` **You**

I hope you got the answer you wanted


**1065.** `23:59` **Meredith Lamb (+14169386001)**

I’m just waiting for the next time we are together…\. That’s all…\.


