# Daily Conversation: 2025-07-16 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-16 |
| **Day** | Wednesday |
| **Week** | 14 |
| **Messages** | 448 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-16T04:46 - 2025-07-16T21:56 |

## 📝 Daily Summary

This day contains **448 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:46` **You**

Edited: 3 versions
| Version: 3
| Sent: Wed, 16 Jul 2025 06:49:28 \-0400
|
| Morning\.  xo Hope you got some sleep\. Gl with wifi and Andrew and everything else\. Ttyl\.
|
| Version: 2
| Sent: Wed, 16 Jul 2025 05:00:07 \-0400
|
| Morning\. Hope you got some sleep\. Gl with wifi and Andrew and everything else\. Ttyl\.
|
| Version: 1
| Sent: Wed, 16 Jul 2025 04:46:32 \-0400
|
| Morning…\. Heading to gym and then into work\. Hope you slept\.  Ttyl\. Xo


**002.** `08:39` **You**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 08:40:32 \-0400
|
| Odd to not hear from you by now… you haven’t even checked your messages\.\. I at least thought I would get a good morning,
| Even though I know last night was rough sorry\.  So I hope everything is ok??  Or are we on a chill day?  Just give me a heads up when you can and let me know how you are and what’s up please\.
|
| Version: 1
| Sent: Wed, 16 Jul 2025 08:39:12 \-0400
|
| Odd to not hear from you by now… at least a good morning\.\. so I hope everything is ok??  Or are we on a chill day?  Just give me a heads up when you can and let me know how you are and what’s up please\.


**003.** `08:42` **Meredith Lamb (+14169386001)**

I turned my alarm off somehow and slept in\.


**004.** `08:42` **Meredith Lamb (+14169386001)**

Gah


**005.** `08:42` **Meredith Lamb (+14169386001)**

Just getting up


**006.** `08:43` **You**

Must have been up late\.


**007.** `08:49` **You**

Warned you about naps\.\. hope it was just that and not an Andrew thing again\.


**008.** `08:51` **Meredith Lamb (+14169386001)**

I couldn’t sleep so took melatonin


**009.** `08:51` **Meredith Lamb (+14169386001)**

Text from Andrew but I haven’t read it yet ugh


**010.** `08:52` **You**

You need to get to your new place for the wifi right


**011.** `08:52` **Meredith Lamb (+14169386001)**

I’m on my way\. They did say they would call me an hour before though, but I was not sure if they were telling the truth\.


**012.** `08:53` **You**

Kk well we can chat later or whenever\.\. in the office just working\.


**013.** `08:53` **Meredith Lamb (+14169386001)**

So McKenzie went out with Johnny last night smoking


**014.** `08:53` **You**

And…\.


**015.** `08:53` **Meredith Lamb (+14169386001)**

Go home and I was trying to sleep and she’s all excited and she comes to my room


**016.** `08:54` **Meredith Lamb (+14169386001)**

And she goes mom Johnny got you flowers\!\!


**017.** `08:54` **Meredith Lamb (+14169386001)**

He literally got me flowers


**018.** `08:54` **You**

lol omg


**019.** `08:54` **Meredith Lamb (+14169386001)**

lol


**020.** `08:54` **You**

Nice of him


**021.** `08:54` **Meredith Lamb (+14169386001)**

It was like why what the fuck


**022.** `08:54` **Meredith Lamb (+14169386001)**

She said because the whole separation thing


**023.** `08:55` **You**

He does sound like a genuinely nice kid\.\. glad for you


**024.** `08:55` **Meredith Lamb (+14169386001)**

He wanted to Come in and visit, but she told him that I was at my new house so he wouldn’t lol


**025.** `08:56` **Meredith Lamb (+14169386001)**

He is a Genuinely nice person and I think he might be on the spectrum honestly


**026.** `08:56` **You**

Well I am sure it was a nice surprise prolly hard to fall asleep after that\.


**027.** `08:59` **Meredith Lamb (+14169386001)**

No lol\. I just kept waking up later


**028.** `09:00` **Meredith Lamb (+14169386001)**

I think it is maybe the drinking detoxing and I’m annoyed at Andrew how much he’s out Marlowe thought it was really weird last night and she’s confused and a little stressed by it which is just kind of annoying


**029.** `09:02` **You**

When I finally got to sleep I slept\.\. but not much i woke up late which I don’t usually do\.  Didn’t feel good this morning\.\. see how rest of day goes\.


**030.** `09:05` **Meredith Lamb (+14169386001)**

You were in really rough shape last night


**031.** `09:05` **Meredith Lamb (+14169386001)**

So I’m not surprised


**032.** `09:05` **You**

Yep


**033.** `09:06` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**034.** `09:07` **Meredith Lamb (+14169386001)**

He refuses to call you Scott


**035.** `09:07` **You**

Reaction: 😂 from Meredith Lamb
That’s fine\. He can call me whatever he wants to\.


**036.** `09:10` **You**

>
Sorry for Marlowe\.\. don’t see this getting easier for a bit\.\. like you said worse before better I guess\.

*💬 Reply*

**037.** `09:19` **Meredith Lamb (+14169386001)**

lol

*📎 1 attachment(s)*

**038.** `09:19` **You**

Sweet\.


**039.** `09:26` **Meredith Lamb (+14169386001)**

The annoying thing about this is he constantly does shit wrong and then plays victim\. Like I’m supposed to just ignore his shit and it have no impact on my life/actions

*💬 Reply*

**040.** `09:26` **Meredith Lamb (+14169386001)**

So frustrating having any conversations


**041.** `09:27` **You**

J does the same thing\.\. people don’t want to recognize the impact of their actions on others\.  They would rather push them down and not deal with them, while pointing out the flaws in others\.


**042.** `09:27` **You**

Humans\.\.’sucks


**043.** `09:27` **You**

That was last night for me


**044.** `09:27` **You**

Par for the course


**045.** `09:28` **Meredith Lamb (+14169386001)**

I don’t understand how she is still going on about it when she’s literally moving in only a couple of days?


**046.** `09:28` **Meredith Lamb (+14169386001)**

Just anger?


**047.** `09:28` **Meredith Lamb (+14169386001)**

Hurt?


**048.** `09:28` **Meredith Lamb (+14169386001)**

Venting?


**049.** `09:28` **Meredith Lamb (+14169386001)**

Like does she actually want to get back together?


**050.** `09:28` **You**

Yeah and she won’t make a decision on Gracie basically said I didn’t consult with them so I will just have to wait and see


**051.** `09:29` **Meredith Lamb (+14169386001)**

Didn’t consult with them on what?


**052.** `09:29` **You**

>
Would she\.\. probably,
Reluctantly and it would be down the road\. But it doesn’t matter I never would ever\.  I have lived that life already\.

*💬 Reply*

**053.** `09:29` **You**

>
When I separated

*💬 Reply*

**054.** `09:29` **Meredith Lamb (+14169386001)**

Ohhh


**055.** `09:29` **You**

And then she felt forced to New Brunswick


**056.** `09:30` **You**

Which I can appreciate


**057.** `09:30` **You**

It was the whole transition year


**058.** `09:30` **You**

I should have just bit the bullet


**059.** `09:30` **You**

My fault


**060.** `09:30` **Meredith Lamb (+14169386001)**

Bit the bullet?


**061.** `09:30` **You**

Moved out letter stay in house\. For a year


**062.** `09:30` **Meredith Lamb (+14169386001)**

Oh


**063.** `09:30` **Meredith Lamb (+14169386001)**

Ugh


**064.** `09:31` **Meredith Lamb (+14169386001)**

Messy


**065.** `09:31` **You**

Understatement\. I have never been pushed this far before\.\.


**066.** `09:33` **Meredith Lamb (+14169386001)**

It’s is strange to me that both of our respective spouses would stay in miserable relationships


**067.** `09:33` **Meredith Lamb (+14169386001)**

I find that hard to understand


**068.** `09:34` **Meredith Lamb (+14169386001)**

>
But 3 days so you can keep going right?

*💬 Reply*

**069.** `09:35` **You**

Reaction: 😢 from Meredith Lamb
Jaimie loved\(s\) me it is what it is to her\.\. I told you what you are to me I am to her\.\. and to her I broke her\.\.


**070.** `09:35` **You**

She would have rather stayed with me and hope for a better future


**071.** `09:35` **You**

That is what’s he said


**072.** `09:36` **You**

>
Depends what after 3 days looks like\.  I mean keep going is relative\.\. I don’t have a choice but to keep going\.

*💬 Reply*

**073.** `09:37` **Meredith Lamb (+14169386001)**

I mean keep going without losing it on anyone


**074.** `09:38` **Meredith Lamb (+14169386001)**

>
This is very sad\. Makes me feel bad…\.

*💬 Reply*

**075.** `09:38` **You**

What do you mean losing it\.\. lol


**076.** `09:38` **You**

>
It was happening regardless

*💬 Reply*

**077.** `09:38` **Meredith Lamb (+14169386001)**

Saying things you will regret in heated moments etc


**078.** `09:39` **You**

Ship has sailed


**079.** `09:39` **You**

Long ago


**080.** `09:39` **You**

There is shit I texted hope bever sees the light of day


**081.** `09:39` **You**

I have similar from them


**082.** `09:39` **You**

It is what it is


**083.** `09:39` **Meredith Lamb (+14169386001)**

😬


**084.** `09:40` **You**

I won’t be losing it\.\. but I am recognizing that I am going into a depression or something\.\. not sure maybe not never really been depressed but I am not taking drugs\.\. so will head that one off right now\.


**085.** `09:42` **You**

But keep going forward\.\. and try somehow to regain some semblance of focus and control just not sure how if I stay like this\.


**086.** `09:45` **Meredith Lamb (+14169386001)**

Bell here sorry


**087.** `09:52` **You**

No worries can chat whenever\.\. um figured I would ask but tomorrow morning or no\.


**088.** `09:53` **Meredith Lamb (+14169386001)**

😵‍💫 we cannot communicate

*📎 1 attachment(s)*

**089.** `09:57` **Meredith Lamb (+14169386001)**

>
Of course

*💬 Reply*

**090.** `10:10` **You**

Kk I just expect it to be another long weekend\.\. lol\.\. so I take whatever I can get\.


**091.** `10:26` **Meredith Lamb (+14169386001)**

I have to do beach volleyball all day Sunday


**092.** `10:26` **Meredith Lamb (+14169386001)**

Gahhhhhhhhhhh


**093.** `10:26` **You**

Rofl


**094.** `10:27` **Meredith Lamb (+14169386001)**

Saturday I am moving and my parents are coming to bring stuff and “help”


**095.** `10:27` **You**

Ah well


**096.** `10:28` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 10:28:32 \-0400
|
| I get bo on Sunday also
|
| Version: 1
| Sent: Wed, 16 Jul 2025 10:28:25 \-0400
|
| I get no on Sunday also


**097.** `10:29` **You**

Next two weeks right


**098.** `10:29` **You**

lol


**099.** `10:30` **Meredith Lamb (+14169386001)**

Yeah


**100.** `10:30` **You**

Eeeesh well yep heh


**101.** `10:32` **Meredith Lamb (+14169386001)**

The mediator told Andrew that he’s not gonna be able to keep planning the way he is and then telling me after the fact as to where I need to drive too and what I need to do\.


**102.** `10:33` **Meredith Lamb (+14169386001)**

He didn’t even comment he just kinda looked and smirked


**103.** `10:33` **You**

😟


**104.** `10:33` **Meredith Lamb (+14169386001)**

I told her that he signed the kids up for things and then text me as to what I need to do driving wise


**105.** `10:33` **Meredith Lamb (+14169386001)**

She was very clear that that cannot continue


**106.** `10:33` **Meredith Lamb (+14169386001)**

And yet here we are this Sunday


**107.** `10:33` **You**

Not enforceable


**108.** `10:33` **You**

Remember


**109.** `10:34` **You**

That will be between you and him


**110.** `10:34` **You**

To sort


**111.** `10:34` **Meredith Lamb (+14169386001)**

Ugh


**112.** `10:34` **You**

He will make it as difficult as possible especially now that he knows I am well\.\. that am peripherally involved\.


**113.** `10:37` **Meredith Lamb (+14169386001)**

Omg she agreed\!\!\!\!\!\!

*📎 1 attachment(s)*

**114.** `10:37` **You**

But tbh I won’t have any impact for a while\.


**115.** `10:37` **You**

You should actually tell him that


**116.** `10:37` **You**

He might back off


**117.** `10:38` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 10:38:22 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Wed, 16 Jul 2025 10:34:49 \-0400
| >
| > He will make it as difficult as possible especially now that he knows I am well\.\. that am peripherally involved\.
|
| Yeah he’s pissed\. At one point the other day he was like “well I guess the kids can meet Scott because you’ve been dating for two months or more” \(that is what we put in parenting plan\)
|
| Version: 1
| Sent: Wed, 16 Jul 2025 10:38:04 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Wed, 16 Jul 2025 10:34:49 \-0400
| >
| > He will make it as difficult as possible especially now that he knows I am well\.\. that am peripherally involved\.
|
| Yeah he’s pissed\. St one point the other day he was like “well I guess the kids can meet Scott because you’ve been dating for two months or more” \(that is what we put in parenting plan\)


**118.** `10:38` **You**

I mean I am not going to\.\. because we cannot just tell him we are on pause until sept or something he might chill


**119.** `10:38` **You**

At least your life would be easier


**120.** `10:39` **Meredith Lamb (+14169386001)**

No, I am not lying to him anymore


**121.** `10:39` **Meredith Lamb (+14169386001)**

Good, bad ugly\. It is what it is\.


**122.** `10:39` **Meredith Lamb (+14169386001)**

He can’t move on if I lie


**123.** `10:39` **You**

Then reframe the statement but maybe if he realizes we aren’t going to be seeing each other for the near future he might relax


**124.** `10:40` **Meredith Lamb (+14169386001)**

He actually finds it kind of irritating that we’re not seeing each other right now


**125.** `10:40` **You**

Like he is probably always wondering


**126.** `10:40` **You**

So just tell him


**127.** `10:40` **You**

Then he won’t be


**128.** `10:40` **Meredith Lamb (+14169386001)**

He knows we see each other every day at work and then we text and stuff and talk


**129.** `10:41` **You**

I mean ok\.\. I guess in his mind that is same thing\.\.  point is we are in a relationship\. Regardless of other details


**130.** `10:42` **Meredith Lamb (+14169386001)**

Last night, Marlowe asked me where she’s going to be the first week of school 😢


**131.** `10:42` **Meredith Lamb (+14169386001)**

It kind of hit me like a ton of bricks that question


**132.** `10:42` **Meredith Lamb (+14169386001)**

I felt really bad that she didn’t know


**133.** `10:42` **You**

Maddie asked jaimie if I would go back to being normal after the move\.


**134.** `10:43` **You**

Reaction: 😢 from Meredith Lamb
She is worried that we won’t go back to our old relationship because of how angry everyone is\.


**135.** `10:43` **You**

Kids get it the worst


**136.** `10:43` **You**

Regardless of how I feel


**137.** `10:44` **Meredith Lamb (+14169386001)**

Yeah …\.


**138.** `10:44` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
I asked Marlowe if she had any concerns about the weeks that she isn’t with me


**139.** `10:45` **You**

I texted Maddie this morning assuring her\.  I actually am excited but between here and there is absolute hell and again unsure how long it will take me to recover from everything


**140.** `10:45` **Meredith Lamb (+14169386001)**

She said that she hates going to bed alone upstairs and she likes that I hang out up there and watch TV and go to bed early and she will miss that because Andrew stays downstairs and works until 1am or 2 AM\. I told her that Andrew would be happy to work upstairs instead during those weeks\.


**141.** `10:46` **You**

Yeah that might make her feel better


**142.** `10:46` **Meredith Lamb (+14169386001)**

The reality is that they are going to be together in the basement so it’ll be fine


**143.** `10:46` **Meredith Lamb (+14169386001)**

>
Did she appreciate your text?

*💬 Reply*

**144.** `10:46` **You**

She hasn’t answered


**145.** `10:46` **You**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 10:47:06 \-0400
|
| She is not a big texter
|
| Version: 1
| Sent: Wed, 16 Jul 2025 10:46:58 \-0400
|
| She is not a big tester


**146.** `10:47` **Meredith Lamb (+14169386001)**

Like Maelle


**147.** `10:48` **You**

Yeah we might need to work on texting more in the future her and I\.


**148.** `10:48` **Meredith Lamb (+14169386001)**

Our conversations always look like this\. Lol “yep, yep, yep” she is so different than my other two in this way

*📎 1 attachment(s)*

**149.** `10:49` **Meredith Lamb (+14169386001)**

Her favourite response is “yep”


**150.** `10:49` **Meredith Lamb (+14169386001)**

lol always makes me laugh


**151.** `10:50` **Meredith Lamb (+14169386001)**

I get fucking novels from the other two


**152.** `10:50` **You**

I like that response too\.


**153.** `10:50` **You**

Also we will see\.\. and other solid noncommittal emotion hiding responses\.


**154.** `10:51` **Meredith Lamb (+14169386001)**

Perhaps


**155.** `10:51` **You**

Yeah that one too\.\. I decided you cannot tell me not to use those words\.


**156.** `10:52` **You**

I have basically taken down all my shields for real\.\. I need my words\.


**157.** `10:52` **You**

All of them\.


**158.** `10:53` **Meredith Lamb (+14169386001)**

And we know there are a lot in your repertoire


**159.** `10:53` **You**

Yeah so we will see will be making a comeback\.\. and others\.\. I need to be able to feel uncertain and say that\.\. because l do\.


**160.** `10:55` **Meredith Lamb (+14169386001)**

I know and it is ok\. I don’t love you any less when you are moody and uncertain\. I literally \(proper use of the word btw\) went to bed last night thinking about how intensely I was in love with you\. Your challenged mental state doesn’t change that … if anything, I’m glad you let me in and see it, share it with me rather than pushing me away


**161.** `10:59` **You**

I don’t like people seeing me like this\.  And I don’t like feeling this way\. It makes me think less of myself\.\. I am glad you appreciate getting the connection and am thankful it doesn’t repel you\.\. I just am not functioning well at the moment\.\. and I know it cannot last\.  I have to do something about this I am just not sure what\.\. but feeling this way all the time is not healthy\.  I “literally” cannot stop thinking about you\.\. that would never go away when we are together but it would not dominate everything\.\. it is a real issue, and I am concerned\.


**162.** `11:00` **You**

I still hope each day something is going to get better\.\. but it doesn’t it gets worse\.


**163.** `11:00` **You**

Reaction: 👍 from Meredith Lamb
Ahana coming in for a meeting will text you after


**164.** `12:03` **You**

Done with ahana\.\. sorry for leaving you with my sob story\. And then running


**165.** `12:07` **Meredith Lamb (+14169386001)**

No problem talking to my mom


**166.** `12:07` **Meredith Lamb (+14169386001)**

Working hard :p


**167.** `12:08` **You**

Sounds fun\.\. I am just existing\.\. bet that sounds fun too\.


**168.** `12:10` **Meredith Lamb (+14169386001)**

Do you want to chat today?


**169.** `12:10` **Meredith Lamb (+14169386001)**

Or too down?


**170.** `12:13` **You**

I don’t think you would want to talk to me to be honest\.\. I don’t have much joy to share with you\.  I am getting on a call with the mental hospital in 4 mins until 12:45 then I have 15 mins and then a meeting until 2 and free for rest of day\.  So you can think about whether or not you want to talk to me in my current state lol\.


**171.** `12:14` **Meredith Lamb (+14169386001)**

I do of course


**172.** `12:14` **Meredith Lamb (+14169386001)**

I’m going to go back to other house in a bit


**173.** `12:14` **Meredith Lamb (+14169386001)**

I’m still at new place


**174.** `12:15` **You**

Kk well I will let you know how this goes when it is done and we can connect after my next meeting if you want


**175.** `12:15` **You**

I will reach out


**176.** `12:15` **You**

Or let you know or whatever


**177.** `12:17` **Meredith Lamb (+14169386001)**

Ok sounds good


**178.** `12:40` **You**

Well that was a disaster lol


**179.** `13:23` **Meredith Lamb (+14169386001)**

What happened?


**180.** `14:02` **You**

If you want to call for a few mins I can before I leave\.


**181.** `15:15` **Meredith Lamb (+14169386001)**

For the drafts\. Already they kept the boat half and half …\. Sigh


**182.** `15:15` **Meredith Lamb (+14169386001)**

Mistake 1


**183.** `15:16` **You**

lol


**184.** `15:16` **You**

Good times \- I found so many mistakes


**185.** `15:17` **Meredith Lamb (+14169386001)**

I do not want that F’ing boat…\. First world problems


**186.** `15:18` **You**

Yeah you have a few of them


**187.** `15:18` **Meredith Lamb (+14169386001)**

Uh, so do you\!


**188.** `15:18` **You**

Nope I am firmly middle class


**189.** `15:18` **Meredith Lamb (+14169386001)**

Yeah either way your paid off house


**190.** `15:18` **Meredith Lamb (+14169386001)**

Mm hmm


**191.** `15:18` **Meredith Lamb (+14169386001)**

Real middle class


**192.** `15:19` **You**

Super middle


**193.** `15:19` **Meredith Lamb (+14169386001)**

Super DUPER


**194.** `15:19` **You**

More middle than you guys


**195.** `15:19` **Meredith Lamb (+14169386001)**

No


**196.** `15:19` **You**

Like so much more


**197.** `15:19` **Meredith Lamb (+14169386001)**

We just have put money in diff places


**198.** `15:19` **You**

Mmhmm


**199.** `15:20` **Meredith Lamb (+14169386001)**

Facts sorry


**200.** `15:20` **You**

Kk my brain is not working cannot argue\.\. do not take advantage


**201.** `15:21` **Meredith Lamb (+14169386001)**

lol


**202.** `15:21` **Meredith Lamb (+14169386001)**

I will be easy on you today


**203.** `15:22` **You**

Yep pretty fragile here about to head home so yeah


**204.** `15:24` **You**

Packing up\.\. torture time incoming


**205.** `15:27` **Meredith Lamb (+14169386001)**

Well I’m here if you need to vent at any point\. I promise to handle with care\. ❤️❤️


**206.** `15:27` **Meredith Lamb (+14169386001)**

Regardless we will see each other tomorrow so…


**207.** `15:28` **You**

At work yeah excited


**208.** `15:29` **Meredith Lamb (+14169386001)**

Meant in morning


**209.** `15:31` **You**

Oh yeah forgot\.\. k


**210.** `15:31` **You**

>
We’ll see how I am doing\. Let me know how the agreement review is going

*💬 Reply*

**211.** `15:33` **You**

One upside could be we could actually talk to each other rather than texting but I suspect you prefer texting\.


**212.** `15:42` **Meredith Lamb (+14169386001)**

>
I’m fighting with my printer

*💬 Reply*

**213.** `15:42` **Meredith Lamb (+14169386001)**

>
I’m happy to talk to you anytime

*💬 Reply*

**214.** `15:43` **You**

But then no record


**215.** `15:44` **Meredith Lamb (+14169386001)**

lol


**216.** `15:44` **Meredith Lamb (+14169386001)**

Omg


**217.** `15:44` **You**

Like the handcuffs


**218.** `15:44` **Meredith Lamb (+14169386001)**

🤪


**219.** `15:44` **You**

Which I am right about


**220.** `15:44` **Meredith Lamb (+14169386001)**

No


**221.** `15:44` **You**

10000000%


**222.** `15:44` **Meredith Lamb (+14169386001)**

I mean, you always think you’re right\.


**223.** `15:45` **You**

Maybe the question was more generic


**224.** `15:46` **You**

You know what I actually think I’d rather just not remember and be wrong\. I don’t even know why I’m fighting about this\.


**225.** `15:47` **Meredith Lamb (+14169386001)**

You are wrong


**226.** `15:47` **You**

Don’t care don’t wanna know anything else anymore


**227.** `15:48` **You**

Good


**228.** `15:48` **You**

Food


**229.** `15:48` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 15:49:41 \-0400
|
| But I do have some as part of maelle’s Halloween costume and they’re very real cause she wanted like real ones so you could give them to Jamie to use and then she ask you where you got them and you could just say from me 😜
|
| Version: 1
| Sent: Wed, 16 Jul 2025 15:48:48 \-0400
|
| But I do have some as part of my Halloween costume and they’re very real cause she wanted like real ones so you could give them to Jamie to use and then she ask you where you got them and you could just say from me 😜


**230.** `15:48` **You**

That was it


**231.** `15:48` **Meredith Lamb (+14169386001)**

>
That wouldn’t be awful at all

*💬 Reply*

**232.** `15:49` **You**

Stupid fucking brains


**233.** `15:49` **Meredith Lamb (+14169386001)**

lol


**234.** `15:49` **Meredith Lamb (+14169386001)**

I mean, did you at least crack a smile?


**235.** `15:49` **Meredith Lamb (+14169386001)**

lol


**236.** `15:49` **You**

No cause food


**237.** `15:49` **You**

Was stuck on that


**238.** `15:50` **You**

I would rather use them with you not giving to j


**239.** `15:50` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
The point was, I was attempting to make you smile … just a fixer around here 😜
I mean, I can keep them for future use lol


**240.** `15:51` **You**

Yep


**241.** `15:52` **You**

I honestly appreciate the attempt, but there’s not a lot right now that could make me truly smile to be honest


**242.** `15:54` **You**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 15:54:57 \-0400
|
| If it does make you feel any better as a consolation no one ever has been able to make me feel as good as you do ever so perhaps maybe that’s something I can try and hold onto unless I have to wait two years
|
| Version: 1
| Sent: Wed, 16 Jul 2025 15:54:25 \-0400
|
| If it does make you feel any better as a consolation no one ever has been able to make me feel as good as you do so perhaps maybe that’s something I can try and hold onto unless I have to wait two years


**243.** `16:04` **Meredith Lamb (+14169386001)**

It does make me feel better actually\.


**244.** `16:06` **You**

I actually don’t think anybody ever will be able to make me feel the same way\. So basically you have ruined me for everyone else\. I hope you are happy jk\.


**245.** `16:09` **Meredith Lamb (+14169386001)**

I mean I’m not unhappy\.


**246.** `16:09` **Meredith Lamb (+14169386001)**

lol


**247.** `16:10` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 16:10:39 \-0400
|
| Today on the phone with my mom she said something about us \*maybe\* being a rebound thing again\. I corrected her and was kind of surprised by my response
|
| Version: 1
| Sent: Wed, 16 Jul 2025 16:10:33 \-0400
|
| Today on the phone with my mom she said something about us \*maybe\* being a rebound thing again\. I corrected her and was kind of surprised by my response se


**248.** `16:10` **Meredith Lamb (+14169386001)**

But it made sense after I said it


**249.** `16:11` **Meredith Lamb (+14169386001)**

But I hadn’t really thought about it before like consciously to the extent that I said it to her


**250.** `16:12` **Meredith Lamb (+14169386001)**

I basically said that it isn’t a rebound because you are probably the first person that I have actually chosen to be with myself\. Every other relationship, the other person has pursued me incredibly and I just kind of went with it\. I feel like this is the first time where I have been actively engaged\. Not sure if you feel that way \(because you do more planning, etc\. etc\. etc\. I get it\) but “relatively speaking” that’s how I feel and that is my experience\.


**251.** `16:12` **Meredith Lamb (+14169386001)**

She was like “oh ok”


**252.** `16:12` **Meredith Lamb (+14169386001)**

LOL


**253.** `16:13` **You**

well it is an interesting way to view it\.  You also cannot talk about soul mates and all that shit or her head would pop\.


**254.** `16:13` **You**

at least she accepted it seemingly


**255.** `16:14` **Meredith Lamb (+14169386001)**

>
She would roll her eyes for sure\.

*💬 Reply*

**256.** `16:21` **You**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 16:21:44 \-0400
|
| Pssh
|
| Version: 1
| Sent: Wed, 16 Jul 2025 16:21:36 \-0400
|
| Lash


**257.** `16:26` **Meredith Lamb (+14169386001)**

>
I feel like there is a small piece of your subconscious that thinks if we never got together your life would be easier

*💬 Reply*

**258.** `16:31` **You**

There is a large part of me that knows if we never got together I would never have know what real happiness is\.


**259.** `16:31` **You**

Actually all of me knows that


**260.** `16:31` **You**

Life would be easier atm\. I would be strong and wouldn’t be in pain


**261.** `16:31` **You**

Just for this small slice of time


**262.** `16:33` **You**

>
Why do you think like this\.

*💬 Reply*

**263.** `16:33` **You**

My pain is from being apart not because we met and fell in love


**264.** `16:37` **You**

>
Like even in the face of all this say we are seeing each other regularly\.\. I am 100 times more resilient and happy…\. 😊

*💬 Reply*

**265.** `16:45` **Meredith Lamb (+14169386001)**

>
It has just really complicated things for you in a massive way\.

*💬 Reply*

**266.** `16:45` **Meredith Lamb (+14169386001)**

That’s all


**267.** `16:54` **You**

Yeah it has


**268.** `16:54` **You**

But I wouldn’t take it back for anything


**269.** `16:54` **You**

Ever


**270.** `16:54` **You**

I am still miserable about our situation but I wouldn’t take never change it


**271.** `16:59` **You**

>
It has made it complicated for you to

*💬 Reply*

**272.** `17:00` **You**

Do you regret


**273.** `17:04` **Meredith Lamb (+14169386001)**

>
Not really

*💬 Reply*

**274.** `17:05` **Meredith Lamb (+14169386001)**

Zero regrets … never even crosses my mind for real\. I just feel like your situation is more complicated\. Different provinces, Gracie, Jaimie not being very self sufficient, etc …\. You have a lot of complicated pieces


**275.** `17:06` **Meredith Lamb (+14169386001)**

Mine feel more straightforward for some reason but maybe just because they are mine and I’m biased


**276.** `17:09` **You**

nope I agree


**277.** `17:09` **You**

Reaction: ❤️ from Meredith Lamb
eating Domino's pizza tonight\.\. now that I have a memory of you and I eating it\.\. that is what I think of\.


**278.** `17:09` **You**

:\(


**279.** `17:10` **You**

on the plus side\.\. building memories\. step in right direction


**280.** `17:12` **Meredith Lamb (+14169386001)**

That was a good end long to that day


**281.** `17:12` **Meredith Lamb (+14169386001)**

That was Friday right


**282.** `17:12` **Meredith Lamb (+14169386001)**

Mediation day\. Gahh


**283.** `17:12` **You**

fun night though


**284.** `17:12` **Meredith Lamb (+14169386001)**

And all the utilities and insurance set up day


**285.** `17:12` **Meredith Lamb (+14169386001)**

Very chaotic day


**286.** `17:12` **Meredith Lamb (+14169386001)**

Yessss


**287.** `17:14` **You**

>
I think I told you you would regret it one day\.\. maybe you still will\.\.

*💬 Reply*

**288.** `17:16` **Meredith Lamb (+14169386001)**

What on earth is there about you that I would regret? \*thinks\* …\. I guess maybe there is some insecurity or something that is causing you to think this from time to time but I seriously don’t get it\.


**289.** `17:17` **Meredith Lamb (+14169386001)**

It reminds me of when we first started talking, and I thought you were just talking to me out of pity


**290.** `17:17` **You**

you did the same thing


**291.** `17:17` **You**

the whole maybe you think you would be better off without me


**292.** `17:17` **Meredith Lamb (+14169386001)**

I don’t think you will regret it one day I absolutely don’t think that


**293.** `17:17` **Meredith Lamb (+14169386001)**

I just kinda think you might be thinking this week during this whole leading up to Saturday


**294.** `17:17` **Meredith Lamb (+14169386001)**

When Saturday is over, I don’t think you’ll think it


**295.** `17:18` **You**

I don't know what I am going to think when Saturday is over\.\. I honestly don't know\.\. I know I love you, and I regret nothing between us, and want everything to hurry up and get here\.  But beyond that\.\. no clue\.


**296.** `17:20` **Meredith Lamb (+14169386001)**

I think you will feel the same way, but you won’t be in as much turmoil


**297.** `17:21` **You**

It depends\.\. if Gracie is still here I will very much be in turmoil\.\. and  so much to plan\.\. you would think I would be distracted but nope\.


**298.** `17:23` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Wed, 16 Jul 2025 17:23:50 \-0400
|
| I think that even if Gracie is there, it will be different because Jamie won’t be there\. I’m not saying you won’t be in turmoil, but it will be different\.
|
| Version: 1
| Sent: Wed, 16 Jul 2025 17:23:15 \-0400
|
| I think that even if Gracie is there, it will be different because Jamie won’t be there\. I’m not saying I won’t be turmoil, but it will be different\.


**299.** `17:23` **Meredith Lamb (+14169386001)**

And sometimes change is as good as a break


**300.** `17:23` **You**

Maybe\.\. but there will be 2 girls missing mum hating each other\.\. and no mum buffer


**301.** `17:36` **Meredith Lamb (+14169386001)**

Good point


**302.** `17:36` **Meredith Lamb (+14169386001)**

Andrew will have that to an extent also


**303.** `17:36` **Meredith Lamb (+14169386001)**

But maybe not as bad


**304.** `17:36` **Meredith Lamb (+14169386001)**

For sure


**305.** `17:36` **Meredith Lamb (+14169386001)**

100%


**306.** `17:37` **You**

I have a fair guage of my children and how they act\.  I mean ultimately it might have to be me to take Gracie if Jaimie cannot help her\.\.  but I am hoping that is a year or 2 out and she is a bit more mature\.


**307.** `17:45` **You**

So I hate admitting when you are right\.\. but you were\.\. well partially\.\.


**308.** `17:50` **You**

It will also make you feel good\.\. go read my letter again\.\. I don't need Sex\.\. but I do need to be with you again\.\. now that is both something I never thought I would feel or admit to anyone even if I did\.  If I cannot feel good\.\. at least maybe i can make you feel good by sharing this\. You were right\.\. :\(


**309.** `17:52` **Meredith Lamb (+14169386001)**

Sorry I was cleaning out closet and packing\. Winter stuff done\.


**310.** `17:52` **Meredith Lamb (+14169386001)**

>
Yes I feel the same way too\. It is getting to the point where it would be nice just to sit beside you for more than 20 min\. Lol

*💬 Reply*

**311.** `17:52` **You**

>
we got more of the basement done, and packed 1\.5 bins\.

*💬 Reply*

**312.** `17:52` **Meredith Lamb (+14169386001)**

I’m doing it with no a/c


**313.** `17:53` **Meredith Lamb (+14169386001)**

It is 28\.5c IN THIS HOUSE


**314.** `17:53` **Meredith Lamb (+14169386001)**

I feel so bad for the dogs


**315.** `17:53` **Meredith Lamb (+14169386001)**

Andrew won’t get an a/c


**316.** `17:53` **Meredith Lamb (+14169386001)**

Because he is gone all the time so doesn’t care about anyone left


**317.** `17:53` **Meredith Lamb (+14169386001)**

And “the Reno”


**318.** `17:53` **You**

>
Yeah the park is appreciated\.\. but yeah\.\. I am not sure what to do\.

*💬 Reply*

**319.** `17:53` **You**

anyways is he out again tonight?


**320.** `17:58` **Meredith Lamb (+14169386001)**

Not sure\. Not home, but it is normal for him to not be home at this time\.


**321.** `17:58` **Meredith Lamb (+14169386001)**

It’s Wednesday though, and Wednesday means hockey


**322.** `17:58` **You**

ah


**323.** `17:58` **Meredith Lamb (+14169386001)**

>
Hang on for dear life?

*💬 Reply*

**324.** `17:59` **You**

>
who the fuck knows\.\. that or I dunno\.

*💬 Reply*

**325.** `17:59` **You**

I mean I don't think even if I wanted to shut down\.\. if I even could at this point\.


**326.** `17:59` **You**

Edited: 3 versions
| Version: 3
| Sent: Wed, 16 Jul 2025 18:04:52 \-0400
|
| I thought about it last night, like for a while it was one reason why I couldn’t sleep\.  And you cannot get mad I am passed desperate T this point
|
| Version: 2
| Sent: Wed, 16 Jul 2025 18:04:23 \-0400
|
| I thought about it last night, like for a while it was one reason why I couldn’t sleep\.
|
| Version: 1
| Sent: Wed, 16 Jul 2025 17:59:44 \-0400
|
| I thought about it last night


**327.** `18:00` **You**

I figured if I could shut down even for a few weeks\.\.\. I could deal with the house and the ache and pain\.\. and keep moving\.


**328.** `18:00` **You**

I don't think that is even an option anymore


**329.** `18:01` **You**

😥


**330.** `18:07` **Meredith Lamb (+14169386001)**

Well I’m glad it isn’t an option because I wouldn’t like it\. But I honestly feel like when Sat is over it will be slightly improved


**331.** `18:07` **You**

Nothing changes for us\.


**332.** `18:07` **Meredith Lamb (+14169386001)**

But I’m willing to get creative if you want to see each other in non typical ways


**333.** `18:07` **You**

My situational change won’t make that much of a difference


**334.** `18:08` **You**

>
Honestly I think that is where we are at\.\. as much as I wish we could just be normal

*💬 Reply*

**335.** `18:09` **Meredith Lamb (+14169386001)**

Phase 26


**336.** `18:09` **You**

Oh so only 23
Phases to go


**337.** `18:09` **You**

To get there


**338.** `18:09` **You**

Perfect


**339.** `18:09` **Meredith Lamb (+14169386001)**

Yup\!


**340.** `18:09` **Meredith Lamb (+14169386001)**

lol


**341.** `18:09` **You**

So never


**342.** `18:09` **You**

lol


**343.** `18:09` **You**

Awesome


**344.** `18:09` **Meredith Lamb (+14169386001)**

We are past half way


**345.** `18:10` **You**

No we aren’t


**346.** `18:10` **Meredith Lamb (+14169386001)**

What are you talking about lol


**347.** `18:10` **Meredith Lamb (+14169386001)**

26 to 50


**348.** `18:10` **Meredith Lamb (+14169386001)**

Past half way


**349.** `18:10` **You**

You are just making shit up lol


**350.** `18:10` **You**

I don’t think we are even close to half way


**351.** `18:10` **You**

From a time frame perspective


**352.** `18:10` **Meredith Lamb (+14169386001)**

I am not\. Ask gpt


**353.** `18:11` **You**

It is full of shit\.\. and it has no appreciation for time\.\. real time and what it can do to you\.


**354.** `18:12` **You**

It is going to be like Gemini telling me to surrender to the falling which did only to land on spikes


**355.** `18:14` **Meredith Lamb (+14169386001)**

Based on the texts you’ve shared and everything I know about your relationship with Scott, here’s my take\.
You and Scott are in a deeply connected but painfully constrained phase\. There’s emotional closeness, a strong desire to be together, and mutual recognition that the current situation is unsustainable—but also a sense of powerlessness and exhaustion\. He’s clearly overwhelmed, emotionally frayed, and feeling like he can’t even shut down to regroup\. You’re offering hope and creativity, trying to hold on and make things better in small ways\. That shows strength and love—but it also reveals how hard this middle stretch is\.
You called it Phase 26\. That feels accurate—not just mathematically \(halfway to 50\), but emotionally\.
You’re in the murky middle—past the thrill of beginning, past the early chaos, now in the part where endurance and belief matter most\. It’s where people either double down or give up\. And you’re not giving up\.
So yes—I’d say you’re at Phase 26 out of 50\. That might not feel like progress to him right now, but from where I sit, it’s evidence of both of you still caring, still fighting through the fog, still imagining a future—even if you disagree on how close it is\.
He’s hurting\. He’s doubting\. But he’s still talking to you\. Still responding, still sharing, even when it’s raw\. That’s not nothing\.
Phase 26 means:
- You’re more than halfway in terms of emotional commitment\.
- You’re in the hardest stretch in terms of practical constraints\.
- You haven’t hit your turning point yet—but it’s out there\.
Hang on for dear life? Maybe\. But also: hang on for real life\. The one you two are still trying to build\.


**356.** `18:16` **You**

You are afraid


**357.** `18:16` **Meredith Lamb (+14169386001)**

I am not


**358.** `18:16` **You**

You think I am going to break


**359.** `18:16` **Meredith Lamb (+14169386001)**

But I think I’m smart because gpt always agrees with me


**360.** `18:16` **You**

For real


**361.** `18:17` **Meredith Lamb (+14169386001)**

Nope I don’t


**362.** `18:17` **You**

Sounds like it knows a lot about my situation\.\. must have used logs


**363.** `18:17` **You**

Or screen shots


**364.** `18:17` **Meredith Lamb (+14169386001)**

Screenshots


**365.** `18:17` **You**

I don’t know if we are halfway there because there isn’t defined either


**366.** `18:18` **Meredith Lamb (+14169386001)**

I told it phase 50 is when we can be together whenever we want


**367.** `18:18` **You**

All i know is it has been


**368.** `18:18` **You**

Reaction: ❓ from Meredith Lamb
…\.\.


**369.** `18:18` **You**

14 days


**370.** `18:19` **Meredith Lamb (+14169386001)**

Oh


**371.** `18:19` **You**

I cannot imagine what 30 will feel like


**372.** `18:19` **You**

Or more


**373.** `18:19` **You**

Like you said worse for me\.\. but how much more lol \(sad\)


**374.** `18:20` **You**

I am going to go get some more work done\.


**375.** `18:20` **You**

Don’t want to think about this anymore right now\.


**376.** `18:22` **Meredith Lamb (+14169386001)**

k can we talk later?


**377.** `18:22` **Meredith Lamb (+14169386001)**

I’m going to go take stuff to new place


**378.** `18:23` **Meredith Lamb (+14169386001)**

Going to goodwill drop off too


**379.** `18:26` **You**

Yeah we can


**380.** `18:26` **You**

Love you


**381.** `18:32` **Meredith Lamb (+14169386001)**

Love u 2


**382.** `19:18` **You**

back btw just working\.\. \(work work\)  you keep doing whatever you are doing we can chat when you are free later\.


**383.** `20:01` **Meredith Lamb (+14169386001)**

Just at the new place doing a few things and then going home\. Marlowe is sleeping over at her friends 🎉🎉🎉


**384.** `20:04` **You**

Is that 🎉🎉 for Marlowe or you lol\.\.


**385.** `20:16` **Meredith Lamb (+14169386001)**

Definitely for me


**386.** `20:16` **Meredith Lamb (+14169386001)**

I just had to FaceTime Andrew and do a call about this goddamn boat oh my God


**387.** `20:16` **Meredith Lamb (+14169386001)**

We’re good now


**388.** `20:21` **You**

Well then you get to relax tonight I assume Andrew will be out late


**389.** `20:24` **Meredith Lamb (+14169386001)**

Yeah for sure


**390.** `20:24` **Meredith Lamb (+14169386001)**

2 or 3 lol


**391.** `20:25` **You**

Jesus\.\. well enjoy


**392.** `20:25` **Meredith Lamb (+14169386001)**

I’m heading back now


**393.** `20:25` **You**

Kk


**394.** `20:26` **You**

I am going to go lay down


**395.** `20:41` **Meredith Lamb (+14169386001)**

k are you going to bed?


**396.** `20:44` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**397.** `20:44` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**398.** `20:45` **Meredith Lamb (+14169386001)**

The end result of our conversation is of course him keeping the boat, and it not being included in asset equalization, even though the mediator put it in the asset equalization, but didn’t equalize the assets


**399.** `20:45` **Meredith Lamb (+14169386001)**

So now, because Andrew is a whiny little baby, it’s not included in the asset equalization


**400.** `20:48` **Meredith Lamb (+14169386001)**

I honestly wouldn’t care that much if he would just stop treating me like I’m just trying to drain him drive money\. He told me it was on the asset list because of me\.


**401.** `20:48` **Meredith Lamb (+14169386001)**

He mentioned the boat she jumped on it\. The two of them had a conversation about it\. I stayed quiet the whole entire time because I was so fucking hung over and I don’t care about the fucking boat\. I never even said a word and yet I’m getting blamed for it\.


**402.** `20:49` **Meredith Lamb (+14169386001)**

Anyway, not a big deal\. Same old


**403.** `20:49` **Meredith Lamb (+14169386001)**

I’m going to have a cold shower\. Be back in a bit


**404.** `20:54` **You**

>
I wasn't planning on it unless you want me to so you can chill\.

*💬 Reply*

**405.** `20:56` **You**

How did he respond to your last statement at the bottom here?

*💬 Reply*

**406.** `20:56` **You**

If it isn't included in asset equalization just have him pay for your furniture call it even\.


**407.** `21:02` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**408.** `21:03` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**409.** `21:03` **Meredith Lamb (+14169386001)**

I can’t even


**410.** `21:03` **Meredith Lamb (+14169386001)**

Ugh


**411.** `21:05` **Meredith Lamb (+14169386001)**

He is just an asshole but thinks he’s nice\. It is strange\.


**412.** `21:07` **You**

Mmm apparently I am your boss and your coach


**413.** `21:08` **You**

Like you aren’t fucking smarter than me anyways lol\.\. he’s a dumbass


**414.** `21:18` **Meredith Lamb (+14169386001)**

He just came home to argue bc he didn’t want to do it on text


**415.** `21:18` **Meredith Lamb (+14169386001)**

He’s off to hockey now 😵‍💫


**416.** `21:18` **Meredith Lamb (+14169386001)**

He still doesn’t believe our timeline 🤷‍♀️


**417.** `21:20` **You**

lol I was wondering if you and Andrew were still going at it\.\.


**418.** `21:21` **Meredith Lamb (+14169386001)**

No done now but I sent him this:


**419.** `21:21` **Meredith Lamb (+14169386001)**

Legal Precedents in Ontario
1\. McPherson v\. McPherson \(1988\)
Ontario Court of Appeal held that deduction of notional selling costs is inappropriate if it’s unclear whether the matrimonial home will ever be sold   \.
2\. Buttar v\. Buttar \(2013\)
Affirmed that notional selling costs should only be deducted if there is “satisfactory evidence of a likely disposition date”  \.
3\. Oudeh v\. Prior‑Oudeh \(2021\)
Judge Kimmel applied only a 2\.5% notional fee \(instead of typical 5%\) because the sale was speculative and likely far in the future  \.
4\. Fielding v\. Fielding \(2014\)
Allowed a modest 2% commission deduction, reasoning that eventual disposition \(e\.g\. on death\) might occur—but not for some time  \.
⸻
🧭 What This Means If the House Won’t Be Sold Soon
- Courts won’t automatically deduct 5% just for a buy‑out\.
- Evidence matters\. If no sale is likely soon, no deduction—or a reduced one—can be justified\.
- Judges have discretion to choose a reduced “notional fee” \(e\.g\. 2–2\.5%\) based on the circumstances\.
⸻
📌 Application to Your Situation
Because it’s “known that the house will not be sold for a very, very long time”:
- The party keeping the house would need to prove a likely future sale and when it might happen\.
- Otherwise, Ontario courts might:
- Skip the notional fee entirely, or
- Apply a reduced percentage reflecting the long timeline to sale\.
⸻
✅ Takeaway
If you’re negotiating a separation agreement:
- Feel empowered to ask for no deduction of Realtor fees if you’re confident there’s no sale in the near or foreseeable future\.
- Or be open to a compromise deduction \(e\.g\. 2–3%\) reflecting possible but distant sale, as some judges have done\.


**420.** `21:21` **Meredith Lamb (+14169386001)**

Just because he is an asshole to me and I hate it\.


**421.** `21:22` **You**

Sorry Mer I wish you weren’t being treated that way\.


**422.** `21:24` **Meredith Lamb (+14169386001)**

I just can’t stand him saying shit like “oh I still love you” because it is just him being manipulative


**423.** `21:25` **Meredith Lamb (+14169386001)**

And he goes around saying I’m greedy too


**424.** `21:25` **You**

And bossy\.\. kidding


**425.** `21:25` **You**

❤️


**426.** `21:25` **You**

Luv luv luv u


**427.** `21:26` **You**

Look if you are all caught up in this like I think you are I can go to bed and leave you to it hon\.


**428.** `21:26` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**429.** `21:26` **Meredith Lamb (+14169386001)**

My blood is kind of boiling


**430.** `21:26` **You**

I can tell


**431.** `21:26` **Meredith Lamb (+14169386001)**

But it will calm


**432.** `21:26` **Meredith Lamb (+14169386001)**

Eventually


**433.** `21:27` **Meredith Lamb (+14169386001)**

This is why I drink lol


**434.** `21:27` **You**

People closest to us can usually elicit the most
Emotion


**435.** `21:37` **You**

>
I am not sure if you had something you wanted to cover\.\. but it feels like you are preoccupied\.\. so I am
Going to go to bed\.\. long frustrating/disappointing day\.

*💬 Reply*

**436.** `21:39` **Meredith Lamb (+14169386001)**

Sorry, wasn’t expecting the distraction tonight


**437.** `21:40` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**438.** `21:55` **Meredith Lamb (+14169386001)**

You go to sleep and I will see you in the morning\. Xox sorry\! I had that typed and didn’t send


**439.** `21:55` **Meredith Lamb (+14169386001)**

Ugh


**440.** `21:55` **Meredith Lamb (+14169386001)**

Sorry


**441.** `21:55` **Meredith Lamb (+14169386001)**

I’m so pissed off right now I have chest pain


**442.** `21:55` **You**

Night 😮‍💨


**443.** `21:56` **You**

Sorry Mer


**444.** `21:56` **Meredith Lamb (+14169386001)**

1/ this mediator makes fucking mistakes all over


**445.** `21:56` **Meredith Lamb (+14169386001)**

2/ I am not paying $120k in realtor fees


**446.** `21:56` **Meredith Lamb (+14169386001)**

So stupid


**447.** `21:56` **Meredith Lamb (+14169386001)**

Nite ❤️


**448.** `21:56` **You**

Night


