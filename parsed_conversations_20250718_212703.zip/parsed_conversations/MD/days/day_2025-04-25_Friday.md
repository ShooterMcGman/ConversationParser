# Daily Conversation: 2025-04-25 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-25 |
| **Day** | Friday |
| **Week** | 2 |
| **Messages** | 203 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-25T01:07 - 2025-04-25T19:28 |

## 📝 Daily Summary

This day contains **203 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `01:07` **You**

Ok now I am going to bed crazy kid keeping me up and packing love you all the way xoxoxoxoxoxox


**002.** `07:07` **Meredith Lamb (+14169386001)**

Woke up thinking of u…\. Also can’t believe we made it through this weeeeeeeeek\. Xoxox


**003.** `07:09` **You**

Um I have unfortunate news


**004.** `07:09` **Meredith Lamb (+14169386001)**

What


**005.** `07:09` **Meredith Lamb (+14169386001)**

No


**006.** `07:10` **Meredith Lamb (+14169386001)**

Unfortunate news not allowed


**007.** `07:10` **You**

I do have just a small touch of a sore throat very small tbh\. And Jon and I talked and we think with the little ones best to come another time\.


**008.** `07:11` **You**

So I will spend tonight in Detroit\.


**009.** `07:11` **Meredith Lamb (+14169386001)**

Sorry that is unfortunate news?


**010.** `07:11` **You**

Well it was meant to be a bit tricky\.\.


**011.** `07:11` **Meredith Lamb (+14169386001)**

Trying to understand how it is unfortunate lol


**012.** `07:11` **Meredith Lamb (+14169386001)**

lol


**013.** `07:12` **Meredith Lamb (+14169386001)**

Wait what about your fam


**014.** `07:12` **You**

Anyways I am updating my booking now


**015.** `07:12` **You**

Nothing there\.\.


**016.** `07:13` **You**

Nothing to worry about I guess


**017.** `07:13` **Meredith Lamb (+14169386001)**

Wait what?


**018.** `07:13` **You**

My fam


**019.** `07:13` **You**

What do you mean


**020.** `07:14` **You**

They don’t know Jon


**021.** `07:14` **You**

Never met him


**022.** `07:14` **Meredith Lamb (+14169386001)**

Like how are you explaining


**023.** `07:14` **Meredith Lamb (+14169386001)**

Oh


**024.** `07:14` **Meredith Lamb (+14169386001)**

So they still think you are going


**025.** `07:14` **You**

Explaining we met in Detroit cause I was sick


**026.** `07:14` **You**

Yeah


**027.** `07:14` **Meredith Lamb (+14169386001)**

Ahhh I see


**028.** `07:15` **Meredith Lamb (+14169386001)**

You are so getting me sick aren’t you


**029.** `07:15` **You**

Possibly


**030.** `07:15` **Meredith Lamb (+14169386001)**

lol


**031.** `07:15` **You**

Did you have an ok night


**032.** `07:16` **Meredith Lamb (+14169386001)**

I mean I was drinking so it was completely fine


**033.** `07:16` **You**

In fact I might not tell the team I went at all


**034.** `07:16` **Meredith Lamb (+14169386001)**

But I need to get up\. I can hear Mac blending her smoothie downstairs


**035.** `07:16` **You**

That would be easier


**036.** `07:16` **Meredith Lamb (+14169386001)**

>
Work a bit this morning?

*💬 Reply*

**037.** `07:16` **You**

And less suspicious


**038.** `07:17` **You**

Yeah that makes sense


**039.** `07:17` **You**

You learning


**040.** `07:17` **Meredith Lamb (+14169386001)**

Can you lie that well


**041.** `07:17` **Meredith Lamb (+14169386001)**

?


**042.** `07:17` **Meredith Lamb (+14169386001)**

I’m kinda bad at it


**043.** `07:17` **Meredith Lamb (+14169386001)**

lol


**044.** `07:17` **You**

No??


**045.** `07:17` **You**

lol


**046.** `07:17` **You**

Yah


**047.** `07:17` **Meredith Lamb (+14169386001)**

Haha


**048.** `07:17` **You**

Mum


**049.** `07:17` **You**

Had to learn


**050.** `07:18` **You**

So yeah maybe I works until 10 or 11 and get in a bit later


**051.** `07:18` **Meredith Lamb (+14169386001)**

Just make sure Carolyn and Michelle see you lol


**052.** `07:18` **You**

I will FaceTime them


**053.** `07:18` **You**

Teams


**054.** `07:19` **Meredith Lamb (+14169386001)**

Then we can hang out when you arrive 🙂


**055.** `07:19` **Meredith Lamb (+14169386001)**

Mac has a team dinner but I don’t have to go\. I hate them


**056.** `07:19` **You**

I want to if you do I know you have a busy weekend too


**057.** `07:20` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**058.** `07:21` **Meredith Lamb (+14169386001)**

Mac can go by herself if you are there\. If you arrive late late I will go with her\. So just keep me updated\.


**059.** `07:22` **Meredith Lamb (+14169386001)**

I’m still recovering from your “unfortunate news”


**060.** `07:22` **Meredith Lamb (+14169386001)**

Geez


**061.** `07:37` **You**

Reaction: 👍 from Meredith Lamb
Yeah it is tough sorry just told Jaimie she was good with it\.\. still seeing if Jon and I can meet for lunch tomorrow\.


**062.** `08:22` **You**

Yeah sooooo unfortunately the booking\.\.


**063.** `08:24` **Meredith Lamb (+14169386001)**

They are full?


**064.** `08:24` **Meredith Lamb (+14169386001)**

Omg spit it out


**065.** `08:24` **Meredith Lamb (+14169386001)**

lol


**066.** `08:25` **You**

Reaction: ❤️ from Meredith Lamb
Was confirmed see you tonight 😊


**067.** `08:25` **You**

Love you


**068.** `08:25` **Meredith Lamb (+14169386001)**

Mean Scott\.


**069.** `08:26` **You**

God I am so looking forward to seeing you\.\. I am going to eat a handful of vitamin c pills it will burn out any cold\.\.my throat actually feels a bit better today\.


**070.** `08:26` **You**

I think Jon and I are going to meet in lansing tomorrow for lunch


**071.** `08:29` **Meredith Lamb (+14169386001)**

That’s good


**072.** `08:29` **Meredith Lamb (+14169386001)**

I haven’t made a plan with my friend Lori yet


**073.** `08:29` **Meredith Lamb (+14169386001)**

I was thinking brunch maybe


**074.** `08:29` **You**

Kk well maybe we can make it all work


**075.** `08:29` **Meredith Lamb (+14169386001)**

Of course we can


**076.** `08:29` **You**

ROFL


**077.** `08:29` **You**

Now you say that


**078.** `08:29` **Meredith Lamb (+14169386001)**

lol


**079.** `08:31` **You**

Reaction: ❤️ from Meredith Lamb
I am kind of excited like a kid\.\. weird I don’t feel giddy often\.


**080.** `08:33` **Meredith Lamb (+14169386001)**

Reading that makes me very happy\. 🙂 feel the same after so much distance between us, this will be interesting


**081.** `08:36` **You**

Yeah I agree interesting works here


**082.** `08:41` **Meredith Lamb (+14169386001)**

Definitely does


**083.** `08:42` **You**

Kk I am going to grab a hot shower get
Online for a bit and then leave shortly
Thereafter


**084.** `08:42` **Meredith Lamb (+14169386001)**

Same\. We are leaving at 9\.30


**085.** `08:42` **You**

Reaction: 👍 from Meredith Lamb
Kk will text
You when I am on the road


**086.** `09:02` **Meredith Lamb (+14169386001)**

The whole couple friend thing is awkward\. Trying to make it less so\. Lol gahhhhhh

*📎 1 attachment(s)*

**087.** `09:23` **You**

ROFL


**088.** `09:24` **You**

Yeah I haven’t even started beyond mike and Katie


**089.** `11:22` **You**

Leaving shortly laid the foundation\.  lol


**090.** `11:31` **Meredith Lamb (+14169386001)**

Haha good\. We are just stopping in London


**091.** `11:36` **You**

Kk should be on road soon just attending to a few final things


**092.** `13:37` **Meredith Lamb (+14169386001)**

We are in Detroit early\. Mac had nail appts for 2\. No issue at border


**093.** `13:48` **You**

Fml


**094.** `13:49` **You**

See you at like 6 lol


**095.** `14:20` **Meredith Lamb (+14169386001)**

Perf I want to have a nap and Mac is making me go grocery shopping after this …


**096.** `14:20` **Meredith Lamb (+14169386001)**

Drive is long\. Ready yourself


**097.** `14:21` **Meredith Lamb (+14169386001)**

Mac wants me to get a coffee so I’m not “wimpy”


**098.** `14:21` **Meredith Lamb (+14169386001)**

Omg


**099.** `14:34` **You**

lol


**100.** `14:37` **You**

Took me a while to get out call if and when you have a minute I can bring you up to speed


**101.** `14:39` **Meredith Lamb (+14169386001)**

She is making me go to Target now


**102.** `14:48` **You**

Nice


**103.** `14:48` **You**

Good fun


**104.** `14:49` **You**

Just stopped for rest stop and more chicken soup


**105.** `14:55` **You**

Trying two new things today


**106.** `14:56` **You**

Caramel macchiato Nd white chocolate mocca should be interesting


**107.** `15:06` **Meredith Lamb (+14169386001)**

I’m having a regular coffee so I’m not wimpy lol


**108.** `15:15` **You**

Drive sucks


**109.** `15:28` **Meredith Lamb (+14169386001)**

Super sucks


**110.** `15:28` **You**

Max suckage


**111.** `15:37` **Meredith Lamb (+14169386001)**

Omg Mac is filling this cart\. “I feel like I’m in a dream\.”  She literally just said that


**112.** `15:38` **You**

Hahahaha


**113.** `15:38` **You**

And this is why


**114.** `15:38` **You**

lol


**115.** `15:38` **Meredith Lamb (+14169386001)**

She said “tell Scott he has to come to target to get health food”\. She can’t believe all the health food here\. 🙄🙄🙄🙄🙄🙄🙄


**116.** `15:38` **Meredith Lamb (+14169386001)**

I just want a nap\.


**117.** `15:39` **You**

I will fight not to have one


**118.** `15:39` **You**

I skipped shower at home having it when I get there


**119.** `15:39` **You**

As hot as I can tolerate


**120.** `15:43` **You**

Only one more stop at shoppers I think


**121.** `15:43` **You**

Then I can just boot it Ther


**122.** `15:48` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**123.** `15:48` **Meredith Lamb (+14169386001)**

She won’t stop buying stuff\. Me: wine\. Lol


**124.** `16:01` **You**

Yay wine


**125.** `16:08` **Meredith Lamb (+14169386001)**

So the cart is full now and we are taking bets on $ amount


**126.** `16:21` **You**

How much was it


**127.** `16:25` **Meredith Lamb (+14169386001)**

Sooo


**128.** `16:25` **You**

Yeah


**129.** `16:25` **You**

How much


**130.** `16:25` **You**

You nutter


**131.** `16:27` **Meredith Lamb (+14169386001)**

Mac guessed $500


**132.** `16:27` **Meredith Lamb (+14169386001)**

I guessed $550


**133.** `16:27` **Meredith Lamb (+14169386001)**

Total was $557 so I won


**134.** `16:27` **Meredith Lamb (+14169386001)**

\(Not happy about it lol\)


**135.** `16:28` **You**

Jesus


**136.** `16:28` **You**

USD


**137.** `16:28` **You**

wtf


**138.** `16:28` **You**

lol


**139.** `16:28` **Meredith Lamb (+14169386001)**

I mean I’m not technically separated yet and it was all Mac not me


**140.** `16:29` **You**

Rofl


**141.** `16:29` **You**

Oh wait uh oh


**142.** `16:29` **You**

If you aren’t techniclally we have to behave


**143.** `16:30` **Meredith Lamb (+14169386001)**

I meant financially


**144.** `16:31` **You**

Ah ok that’s different


**145.** `16:36` **You**

Was just reading about the amenities at the cambria


**146.** `16:58` **Meredith Lamb (+14169386001)**

Annoying\. Valet only


**147.** `16:59` **Meredith Lamb (+14169386001)**

Or park somewhere else


**148.** `17:01` **You**

Ewww I don’t want valet


**149.** `17:01` **You**

Other options?


**150.** `17:02` **You**

Sigh yer missing all the jokes booooooooooooooooko


**151.** `17:02` **You**

Not saying then\. Now


**152.** `17:04` **Meredith Lamb (+14169386001)**

Yeah there are some outdoor lots around


**153.** `17:05` **Meredith Lamb (+14169386001)**

I have a 16 yr old bossing me around right now


**154.** `17:05` **You**

Ok good feeling is gone anyways 😝


**155.** `17:27` **Meredith Lamb (+14169386001)**

K changed into pj’s and going to 💤💤💤 may not be successful with this barky teen in here omg


**156.** `17:31` **You**

Will let you know when I am there


**157.** `17:31` **You**

And my room


**158.** `17:35` **Meredith Lamb (+14169386001)**

We are 3rd floor 359


**159.** `17:36` **You**

Well I am not going there


**160.** `17:36` **You**

lol


**161.** `17:59` **You**

Where did you park valet or accross street


**162.** `18:08` **You**

I am here


**163.** `18:08` **You**

Checking in now


**164.** `18:18` **You**

Alright give me a shout when you wake up


**165.** `18:30` **Meredith Lamb (+14169386001)**

We just did valet\. Mac just woke me up barking\. Ugh\.


**166.** `18:31` **Meredith Lamb (+14169386001)**

She needs my cc for dinner


**167.** `18:34` **You**

Srry not a nice way to wake up


**168.** `18:34` **You**

I am in 4555


**169.** `18:34` **Meredith Lamb (+14169386001)**

Should shower and come see u


**170.** `18:34` **You**

455


**171.** `18:34` **You**

I am showering now


**172.** `18:35` **Meredith Lamb (+14169386001)**

Did u eat


**173.** `18:35` **You**

I ate on way here


**174.** `18:35` **You**

Soup


**175.** `18:35` **Meredith Lamb (+14169386001)**

lol


**176.** `18:35` **You**

Twice


**177.** `18:35` **You**

lol


**178.** `18:35` **Meredith Lamb (+14169386001)**

Am I going to be sick in Chatham in 2 days lol


**179.** `18:35` **You**

Turning temp down in here btw I find it too hot


**180.** `18:35` **You**

I mean who knows


**181.** `18:36` **Meredith Lamb (+14169386001)**

Our room is freezing and I prefer that


**182.** `18:36` **You**

Setting to 77


**183.** `18:36` **You**

66


**184.** `18:36` **You**

Anyways gonna shower
Get
My shorts
On and relax was a long drive


**185.** `18:37` **Meredith Lamb (+14169386001)**

Yah k so we are not going outside right?


**186.** `18:38` **You**

Not planning on it


**187.** `18:39` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
K good


**188.** `18:42` **You**

Will msg you when I am finished


**189.** `18:42` **Meredith Lamb (+14169386001)**

k…


**190.** `19:01` **You**

I do t know if you are done yet\.\. but if you are and want to come up I am just showering 5 mins I had to shave first


**191.** `19:02` **Meredith Lamb (+14169386001)**

I am not done yet and Mac just came back\. Will come in a bit


**192.** `19:02` **You**

I was just going to say if you weren’t goi g to be long I would leave door open


**193.** `19:02` **You**

Kk then I will shower first


**194.** `19:02` **Meredith Lamb (+14169386001)**

Yeah I will be a bit


**195.** `19:19` **You**

Kk I am done whenever you are free\.\.


**196.** `19:21` **Meredith Lamb (+14169386001)**

K Mac doesn’t care if I leave before her\. Do you care if I drink? Lol


**197.** `19:22` **Meredith Lamb (+14169386001)**

They are staying in the hotel now for dinner bc of the rain


**198.** `19:22` **Meredith Lamb (+14169386001)**

So many parents and coach here lol


**199.** `19:22` **You**

No


**200.** `19:23` **You**

Drink away


**201.** `19:27` **Meredith Lamb (+14169386001)**

K coming


**202.** `19:27` **You**

Kk door is open


**203.** `19:28` **Meredith Lamb (+14169386001)**

Ugh just pass led team mom on way to elevator gah


