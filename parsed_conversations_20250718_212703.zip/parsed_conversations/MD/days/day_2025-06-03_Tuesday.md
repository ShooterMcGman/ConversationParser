# Daily Conversation: 2025-06-03 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-03 |
| **Day** | Tuesday |
| **Week** | 8 |
| **Messages** | 195 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-03T04:30 - 2025-06-03T22:24 |

## 📝 Daily Summary

This day contains **195 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:30` **You**

Good morning love\.\. I know you are likely still exhausted from yesterday\.\. and if it is a choice between the workout or me\.\. please pick the workout\.\. I know you want to get back in it and I don’t want to be a barrier\.


**002.** `04:32` **You**

Reaction: ❤️ from Meredith Lamb
I am just getting ready to head out\.  But I will likely be at the park between 7:45 and 8\.  Again if you cannot make it do not worry\.  I love seeing you but not at
The expense of you sacrificing something else\.  I love you and hope you have a good morning\.


**003.** `05:36` **Meredith Lamb (+14169386001)**

I will make it but ahana booked a meeting for 9\.35am with Carolyn and I\. :p


**004.** `06:25` **You**

Don’t worry about it\.


**005.** `06:25` **You**

Too rushed


**006.** `06:27` **You**

Can do some other time\.


**007.** `06:31` **Meredith Lamb (+14169386001)**

Working out until 6\.45\. Get ready 6\.45\-7\.15\. Leave 7\.15\. Arrive 7\.45\. It will be fine


**008.** `06:31` **Meredith Lamb (+14169386001)**

My workouts aren’t long yet\. Trying to just get muscle memory back first


**009.** `06:31` **Meredith Lamb (+14169386001)**

This week


**010.** `06:35` **You**

Kk well if you make it I very much look forward to seeing you\. Got a couple of things I want to give you ❤️


**011.** `07:15` **Meredith Lamb (+14169386001)**

I’m actually on time\. Weird\. Leaving now\.


**012.** `07:17` **Meredith Lamb (+14169386001)**

Should be there at 7\.45 unless traffic


**013.** `07:21` **You**

Might be 5 mins late traffic


**014.** `07:21` **You**

Will see


**015.** `07:35` **Meredith Lamb (+14169386001)**

Terraview?


**016.** `07:37` **You**

Yeah


**017.** `07:37` **You**

By pharmacy


**018.** `07:44` **You**

I am parked on or worth road


**019.** `07:44` **You**

On penworth


**020.** `09:08` **You**

Reaction: ❤️ from Meredith Lamb
Thank you for that this morning… I don’t need reassurance any more that we have a future or that you love me I just like being with you\.  So thanks for hanging out\.


**021.** `09:10` **You**

And re C yeah he is your friend and as I understand a good one\.\. if you ever want me to meet him I would be happy to\.


**022.** `09:10` **You**

You were right I was wrong I need to trust you and I do\.\. it has always been hard though after my history\.


**023.** `09:20` **Meredith Lamb (+14169386001)**

I had a nice time 😍


**024.** `09:21` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
In the car I was thinking “why on earth would my kids not like him?” I couldn’t think of any reason why :\)


**025.** `13:15` **You**

That was “interesting”\. Will tell you about it later


**026.** `13:17` **Meredith Lamb (+14169386001)**

Network down\. Can’t work


**027.** `13:17` **Meredith Lamb (+14169386001)**

No teams, outlook\. Nadia


**028.** `13:17` **Meredith Lamb (+14169386001)**

Nadda


**029.** `13:17` **You**

Wow\.\.


**030.** `13:17` **You**

That sucks


**031.** `13:18` **Meredith Lamb (+14169386001)**

Whitney is waiting to be told to go home


**032.** `13:19` **You**

Send her


**033.** `13:28` **Meredith Lamb (+14169386001)**

It came back


**034.** `13:29` **You**

lol it always does


**035.** `13:33` **Meredith Lamb (+14169386001)**

>
What was interesting?

*💬 Reply*

**036.** `13:33` **Meredith Lamb (+14169386001)**

That came out of nowhere


**037.** `13:34` **You**

My session


**038.** `13:34` **You**

With therapist


**039.** `13:34` **Meredith Lamb (+14169386001)**

Omg I forgot\!\!


**040.** `13:35` **You**

Yeah I know yah did\.\. psssh


**041.** `13:35` **Meredith Lamb (+14169386001)**

🙈


**042.** `13:35` **You**

Reaction: 😢 from Meredith Lamb
It’s ok I just won’t tell you all the good parts


**043.** `13:35` **You**

Kk just dropped a load at value village
Going back home to keep going\.


**044.** `13:36` **Meredith Lamb (+14169386001)**

kk


**045.** `15:11` **Meredith Lamb (+14169386001)**

So am I ever going to hear anything that was “interesting” or do you have to tell me on video


**046.** `15:12` **You**

I don't know I doubt video will happen\.\. you always fall asleep\.\. so yeah\.\. video\.


**047.** `15:12` **You**

:\)


**048.** `15:12` **Meredith Lamb (+14169386001)**

I probably will again lol


**049.** `15:13` **You**

yeah sucks\.\. I guess


**050.** `15:15` **You**

Maybe once you have caught up on your sleep\.


**051.** `15:17` **You**

We did spend most of the time talking about you\.\. just as an fyi\.


**052.** `15:17` **You**

I have to go get ready to go, heading back out again\.  Maybe chat later\.\. we'll see\.


**053.** `15:17` **You**

Love you\.


**054.** `15:21` **Meredith Lamb (+14169386001)**

I actually might not fall asleep tonight\. Not feeling as tired\. FYI xoxo


**055.** `15:21` **You**

lol we will see\.\.


**056.** `15:22` **You**

I have heard that before and I know how that story typically ends


**057.** `15:22` **Meredith Lamb (+14169386001)**

I blame the role in YOUR group\. :p


**058.** `15:22` **You**

Mmmm ok if you want to\.\.


**059.** `15:23` **You**

I mean how am I functioning then


**060.** `15:25` **Meredith Lamb (+14169386001)**

You are crazy, that’s how\. 🤪


**061.** `15:27` **You**

I mean I deal with work\.\. I deal with home\.\.
Then there is you… lol❤️


**062.** `15:29` **Meredith Lamb (+14169386001)**

lol accurate


**063.** `15:32` **You**

Off the record here


**064.** `15:32` **You**

There has been an increase over the last year of downward career movements that were not occurring frequently before\. What is causing this and is it viewed as a concerning trend?


**065.** `15:33` **You**

This question was posted for the tow hall next week\.\. you aren’t supposed
To know\.


**066.** `15:34` **Meredith Lamb (+14169386001)**

Why am I not supposed to know?


**067.** `15:35` **You**

Because  I one except managers know the questions


**068.** `15:35` **You**

No


**069.** `15:35` **Meredith Lamb (+14169386001)**

Are they not going to address the question?


**070.** `15:36` **You**

Someone will it is relatively easy to answer


**071.** `15:36` **You**

There is no trend


**072.** `15:36` **You**

Each situation is unique and it is their choice


**073.** `15:36` **Meredith Lamb (+14169386001)**

I was going to say that


**074.** `15:36` **You**

Done


**075.** `15:36` **Meredith Lamb (+14169386001)**

Yeah


**076.** `15:36` **You**

Still I wanted you to not be surprised


**077.** `15:37` **Meredith Lamb (+14169386001)**

Given my day yesterday I wouldn’t have been surprised\. Everyone was pretty shocked\.


**078.** `15:39` **You**

ROFL


**079.** `15:39` **You**

Too cheesy not saying that


**080.** `15:40` **Meredith Lamb (+14169386001)**

:p no clue what you are talking about sometimes


**081.** `15:40` **You**

Cause my brain is bent


**082.** `15:40` **Meredith Lamb (+14169386001)**

Did Hugh tell you that?


**083.** `15:41` **You**

No he said… ohhhh hahahah… no you didn’t even come close to getting me


**084.** `15:41` **You**

😝


**085.** `15:45` **You**

Ok I am heading out again I am sure we might talk later if you aren’t sleeping


**086.** `15:46` **You**

Maybe…\. Not overly confident \.\. cya


**087.** `15:46` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**088.** `15:46` **Meredith Lamb (+14169386001)**

Be more optimistic


**089.** `15:47` **Meredith Lamb (+14169386001)**

\(The griffin emoji was an accident\) lol


**090.** `15:47` **Meredith Lamb (+14169386001)**

It is cute tho


**091.** `15:47` **You**



**092.** `15:47` **You**


*📎 1 attachment(s)*

**093.** `15:48` **You**

Be more awake


**094.** `15:48` **You**

Again\. Love you laters\.


**095.** `15:49` **Meredith Lamb (+14169386001)**

Love u


**096.** `16:25` **You**

Hey what was the site


**097.** `16:25` **You**

For selling earrings


**098.** `16:30` **Meredith Lamb (+14169386001)**

Poshmark


**099.** `16:34` **You**

Thx


**100.** `17:10` **You**

Cooking super for everyone then goi g to gym eventually


**101.** `17:13` **Meredith Lamb (+14169386001)**

Gym rat\.


**102.** `17:14` **You**

Escape


**103.** `17:15` **Meredith Lamb (+14169386001)**

Did you know that if we didn’t need to worry about being outed at work we could go to a Dave Matthews band concert in July\. But work ppl will be there for sure


**104.** `17:21` **You**

lol


**105.** `17:21` **You**

Would be fun


**106.** `17:21` **You**

But yeah not till she is gone


**107.** `17:29` **Meredith Lamb (+14169386001)**

Even after that at work, seriously not dealing with the goss lol


**108.** `17:58` **You**

I know I will never look at you as we pass each other in the halls\.\.


**109.** `17:58` **You**

Two hearts forever destined to pass in the night\.\. and never connect\.\.


**110.** `17:58` **You**

🧀


**111.** `18:00` **Meredith Lamb (+14169386001)**

lol


**112.** `18:34` **You**

sitting down to eat\.\. then not sure what I am doing\.\. J and I had another fight\.\. same shit different day\.\. nothing overly serious though\.


**113.** `18:49` **You**

ah you must be sleeping again\.\. I forgot it is 645 ish\. that is the new nap time / bed time lol


**114.** `18:55` **Meredith Lamb (+14169386001)**

I’m making soup\!


**115.** `18:55` **Meredith Lamb (+14169386001)**

Stop


**116.** `18:55` **Meredith Lamb (+14169386001)**

lol


**117.** `18:55` **You**

sleep cooking


**118.** `18:55` **You**

it happens\.\. it is common\.


**119.** `18:55` **You**

especially cooking soup, there have been studies


**120.** `18:55` **Meredith Lamb (+14169386001)**

🙄


**121.** `18:56` **You**

🙄


**122.** `18:56` **You**

I can do that too


**123.** `18:57` **Meredith Lamb (+14169386001)**

Not as well


**124.** `18:57` **You**

I feel like it looks the same


**125.** `18:58` **Meredith Lamb (+14169386001)**

Mine has more feeling


**126.** `18:58` **You**

LOL


**127.** `18:58` **You**

between the two of us


**128.** `18:58` **You**

we know that isn't true


**129.** `18:58` **You**

😝


**130.** `18:58` **You**

I have so many more feelings\.


**131.** `18:59` **You**

Hugh said so


**132.** `18:59` **Meredith Lamb (+14169386001)**

That isn’t true\. You have more chaos in your head\. Doesn’t equal more feeling per se


**133.** `18:59` **You**

nope


**134.** `18:59` **Meredith Lamb (+14169386001)**

Aren’t you supposed to be eating?


**135.** `18:59` **You**

Hugh said it was pretty clear that I am literally on fire after 30 years of being snuffed out\.


**136.** `18:59` **You**

I ate


**137.** `19:00` **Meredith Lamb (+14169386001)**

>
Really? Didn’t Jim say that?

*💬 Reply*

**138.** `19:00` **You**

I think he feels bad for you


**139.** `19:00` **You**

not sure what jim said


**140.** `19:00` **You**

I booked Hugh every week until end of july


**141.** `19:00` **Meredith Lamb (+14169386001)**

Well I’m glad it went well


**142.** `19:00` **Meredith Lamb (+14169386001)**

He feels bad for me because you are on fire?


**143.** `19:01` **You**

Yep it was great\.\. we went way over time\.\. he didn't seem to care\.\. I was just telling stories\.\. pretty sure I hooked him in\.


**144.** `19:01` **Meredith Lamb (+14169386001)**

lol


**145.** `19:01` **Meredith Lamb (+14169386001)**

I never go over


**146.** `19:02` **You**

He started a bit late\.\. and then we went a little over\.\. and he just kept going


**147.** `19:02` **You**

there is just SO much to fix


**148.** `19:02` **You**

therapists dream


**149.** `19:02` **Meredith Lamb (+14169386001)**

Really wow


**150.** `19:03` **Meredith Lamb (+14169386001)**

I don’t think you need FIXING\.


**151.** `19:03` **You**

yes I do\.\. I will be far better after


**152.** `19:03` **Meredith Lamb (+14169386001)**

It is more just talking and getting some feedback


**153.** `19:03` **Meredith Lamb (+14169386001)**

Perspective from someone else


**154.** `19:03` **You**

Less dependent\.\. more flexible\.\. less plan focused\.\.


**155.** `19:04` **Meredith Lamb (+14169386001)**

Is being plan focused a bad thing?


**156.** `19:04` **Meredith Lamb (+14169386001)**

Some ppl like to plan


**157.** `19:05` **You**

https://open\.spotify\.com/track/0GVuLQtPXFaL18ijEOqoAa?si=b939a16ad02c45a2


**158.** `19:05` **You**

words\.\.


**159.** `19:05` **You**

I have added this to my list of things to accomplish \- right next to the picture of Henry Caville coming out of the ocean\.


**160.** `19:05` **You**

this is what you want


**161.** `19:05` **You**

this is Open\.\.


**162.** `19:06` **You**

and I want to do this 😊


**163.** `19:08` **Meredith Lamb (+14169386001)**

Read the words


**164.** `19:08` **You**

I think future discussions are going to help me out here\.


**165.** `19:08` **Meredith Lamb (+14169386001)**

Never really read them before


**166.** `19:08` **You**

I mean I liked it when I first listened to it\.\. but then the words meant something\.\. more recently\.


**167.** `19:08` **You**

I felt it was apt\.\.


**168.** `19:09` **You**

anyhow even if that doesn't align up with your vision of Open\.\. there has to be enough crossover that we can make it work\.\. I just need something to shoot for\.


**169.** `19:09` **Meredith Lamb (+14169386001)**

>
Did you talk about this today? How hyper focused you are on this? LOO

*💬 Reply*

**170.** `19:09` **Meredith Lamb (+14169386001)**

LOL


**171.** `19:10` **Meredith Lamb (+14169386001)**

did he diagnose you with ocd


**172.** `19:10` **You**

We talked about it\.\. but remember\.\. no specifics\.\. verbal only\.\. sorry\.


**173.** `19:10` **You**

no\.\.


**174.** `19:10` **You**

he validated me


**175.** `19:10` **You**

we framed it up


**176.** `19:10` **Meredith Lamb (+14169386001)**

Ok good


**177.** `19:10` **You**

bounced the situation back and forth


**178.** `19:11` **You**

but recognize that the problem isn't C\.\. the problem is my history\.


**179.** `19:11` **You**

J had no past\.\. there was one guy then me\.


**180.** `19:11` **You**

So all of the trust issues I had previously


**181.** `19:11` **You**

didn't matter\.


**182.** `19:11` **You**

He said I have never dealt with those


**183.** `19:12` **You**

He believed everything I said about us\.\. had a chuckle about how I presented the story\.\. I think we connected well\.


**184.** `19:12` **You**

ok\.\. no more


**185.** `19:12` **You**

not a word\.


**186.** `19:12` **Meredith Lamb (+14169386001)**

What? Why?


**187.** `19:12` **You**

because I told you\.\. it is a chat conversation\.


**188.** `19:12` **You**

I am going to the gym soon and I don't want to type all night again\.


**189.** `19:12` **Meredith Lamb (+14169386001)**

Then call


**190.** `19:13` **You**

let me pack my shit up\.


**191.** `19:13` **You**

5 mins


**192.** `19:13` **Meredith Lamb (+14169386001)**

k


**193.** `19:27` **Meredith Lamb (+14169386001)**

Just watching handmaids tale finale\. You can call whenever


**194.** `22:21` **You**

Forgot to tell you most importantly Hugh said I was damn luck to find someone the way I described you and how I described my feelings\.  Most people don’t… and some do but don’t recognize it\. While he did suggest stopping it was only from the perspective of trying to make it easier\.  Thought that might make you feel a bit better… Love you xoxo🥰\. Have a good sleep\. ❤️\. All of these stupid what if conversations will be meaningless in the not to distant future\.\. I am hopeful\.  Nite\.


**195.** `22:24` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I feel lucky too\. ❤️ since I started working for you I’ve always admired you and would never in a million years have imagined we are where we are… nite xo


