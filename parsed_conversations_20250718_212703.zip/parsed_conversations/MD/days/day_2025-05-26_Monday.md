# Daily Conversation: 2025-05-26 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-26 |
| **Day** | Monday |
| **Week** | 7 |
| **Messages** | 170 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-26T04:36 - 2025-05-26T21:41 |

## 📝 Daily Summary

This day contains **170 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:36` **You**

Well off to the gym\.  Cya later\.


**002.** `06:17` **Meredith Lamb (+14169386001)**

I’m getting up on time today\. 🎉


**003.** `06:29` **You**

ROFL I hope you are feeling ok\.


**004.** `06:42` **Meredith Lamb (+14169386001)**

I’m good\. I hope 2 recovery days was all I needed from Friday night\. :p


**005.** `06:42` **Meredith Lamb (+14169386001)**

Good lord\.


**006.** `06:51` **Meredith Lamb (+14169386001)**

I feel like I need to wear jeans if I’m going to be sitting in a park lol


**007.** `06:51` **Meredith Lamb (+14169386001)**

🤔


**008.** `07:07` **Meredith Lamb (+14169386001)**

In rare fashion I’m basically almost ready to go\. Am going to pack my stuff, stop for coffee but pretty much ready few minutes early


**009.** `07:30` **You**

Heading out now should\. R there at 8


**010.** `07:36` **Meredith Lamb (+14169386001)**

Should be similar


**011.** `07:55` **Meredith Lamb (+14169386001)**

No idea where to park


**012.** `07:56` **Meredith Lamb (+14169386001)**

I’m at penworth and caehville cres


**013.** `07:56` **You**

I am just walking in


**014.** `09:55` **You**

See not sus at all\.


**015.** `10:23` **Meredith Lamb (+14169386001)**

You are going to have to tell Carolyn what is going on with you


**016.** `10:23` **Meredith Lamb (+14169386001)**

She is going crazy


**017.** `10:23` **Meredith Lamb (+14169386001)**

She knows something is wrong but doesn’t know what


**018.** `10:23` **Meredith Lamb (+14169386001)**

She is wondering if she is driving you crazy


**019.** `10:23` **Meredith Lamb (+14169386001)**

Not even kidding


**020.** `10:24` **Meredith Lamb (+14169386001)**

Just tell her already pleassssse


**021.** `10:28` **Meredith Lamb (+14169386001)**

Finally told all my friends today\. Not sure why I procrastinated on that…


**022.** `10:36` **You**

Kk


**023.** `10:38` **You**

Going to address
It now\.\. is Jim in today?


**024.** `10:39` **Meredith Lamb (+14169386001)**

No he took vacay today to recover from jet lag\. Forgot\. He mentioned that


**025.** `10:40` **Meredith Lamb (+14169386001)**

You didn’t have to address it ASAP\. Geez\. She goes “you didn’t tell him?”


**026.** `11:06` **You**

All done


**027.** `11:06` **You**

And by the way do you want to know how it ended?


**028.** `11:06` **You**

She said she had some single friends in their 40’s that are also separated\.\. so yeah…… now there is that


**029.** `11:07` **Meredith Lamb (+14169386001)**

LOL


**030.** `11:07` **You**

I said yeah that is a ways off\.\.


**031.** `11:07` **You**

Should be interesting right?


**032.** `11:08` **Meredith Lamb (+14169386001)**

Super interesting:p


**033.** `11:09` **You**

Maybe you wish I hadn’t told her now?? 😝


**034.** `11:09` **Meredith Lamb (+14169386001)**

I was just like “put her out of her misery” lol


**035.** `11:09` **Meredith Lamb (+14169386001)**

But man you did it quick


**036.** `11:09` **Meredith Lamb (+14169386001)**

Now she knows I told you to tell her


**037.** `11:12` **Meredith Lamb (+14169386001)**

Did she seem relieved?


**038.** `11:26` **You**

She was


**039.** `11:26` **You**

Very much so relieved


**040.** `11:27` **You**

I think she will be able to focus more now on work, and in who she wants to set me up with


**041.** `11:27` **Meredith Lamb (+14169386001)**

That’s good\. I could tell she was going nuts not knowing


**042.** `11:27` **You**

Yeah I could tell too I was going to wait for a bit though\.\. but thank you for the push\.


**043.** `11:28` **You**

You doing ok today\.


**044.** `11:29` **Meredith Lamb (+14169386001)**

Yeah I’m okay\. You?


**045.** `11:29` **You**

I am fine\.\. but be honest I was worried this morning would make your day worse


**046.** `11:30` **Meredith Lamb (+14169386001)**

No it has not\. It was nice 😊


**047.** `11:30` **You**

Ok good I am glad it worked out then and did not mess your day up\.\. and I agree I really enjoyed it\.\. a bit of reality before we go back to faking\.


**048.** `11:30` **You**

Thank you\.


**049.** `11:36` **Meredith Lamb (+14169386001)**

I am sorry I was dismissing your suggestions so many times\. I didn’t realize\. Life felt fast so I didn’t fully notice tbh\.


**050.** `11:40` **You**

Mer it is fine\.\. I don’t expect some massive change because of this I am just glad we got to do it once\.


**051.** `11:46` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
It’s not fine for me to ignore you like that\. \(I do think the ai 12x is overstated but no matter the number…\. not great\.\) I will do better ❤️❤️


**052.** `11:47` **You**

Pls don’t put any more pressure on yourself\.\.  not my intent I just wanted you to understand where I was coming from and not misinterpret it as losing interest or pulling away in some other form\.


**053.** `11:53` **Meredith Lamb (+14169386001)**

Totally understand now\. Really wasn’t seeing it before\.


**054.** `11:55` **Meredith Lamb (+14169386001)**

And all my friends know now… at least officially\. They were probably all gossiping behind my back because 3 knew\.


**055.** `11:55` **Meredith Lamb (+14169386001)**

lol


**056.** `11:55` **Meredith Lamb (+14169386001)**

I’m ok with that


**057.** `11:55` **Meredith Lamb (+14169386001)**

Didn’t say anything about you to the extended group but 3 know


**058.** `11:55` **You**

I have still haven’t told many in my family out of respect for Jaimie\.


**059.** `11:55` **You**

Because they are back in Moncton


**060.** `11:55` **You**

And they will torment her and bug her


**061.** `11:56` **You**

We will be letting people know in coming weeks


**062.** `11:56` **You**

I don’t have any other close friends to tell


**063.** `11:56` **You**

I have only told Mike Katie and John about you\.


**064.** `11:56` **You**

Oh and my family of course


**065.** `11:56` **You**

lol


**066.** `11:56` **Meredith Lamb (+14169386001)**

I have to tell this mom group I get together with… ugh


**067.** `11:56` **Meredith Lamb (+14169386001)**

Haven’t yet


**068.** `11:57` **You**

Should be easy enough\.\.


**069.** `11:57` **You**

So glad I have no social life sometimes


**070.** `12:04` **Meredith Lamb (+14169386001)**

I hate the pity messages tho\.

*📎 1 attachment(s)*

**071.** `12:29` **You**

lol looked like you were cranky when you walked by maybe this was why lol


**072.** `12:29` **You**

Just helping Michelle with some gpt stuff\.


**073.** `12:30` **Meredith Lamb (+14169386001)**

I think I’m getting a sore throat\. Carolyn gave me an emergen\-C for my water lol


**074.** `12:30` **You**

I have this losanges yku
Liked in here


**075.** `12:30` **You**

If you want to come in I can sneak some to you


**076.** `12:31` **You**

I do not have a sore throat at all for the record\.\.


**077.** `12:35` **Meredith Lamb (+14169386001)**

>
Give it a couple days

*💬 Reply*

**078.** `12:37` **You**

I guess I need to hit the vitamin c too\.\.


**079.** `12:42` **Meredith Lamb (+14169386001)**

I’m not even 100% sure and Carolyn was like “here take this\!”


**080.** `12:42` **Meredith Lamb (+14169386001)**

lol


**081.** `12:55` **You**

Heh


**082.** `14:01` **You**

Hope haris is doing well


**083.** `14:05` **Meredith Lamb (+14169386001)**

Super frustrated with Deb but good otherwise\.


**084.** `14:05` **Meredith Lamb (+14169386001)**

We hadn’t caught up in a while so had a good chat


**085.** `14:06` **Meredith Lamb (+14169386001)**

He’s happy I’m going back lol he’s like “maybe you can help me with all this res crap”


**086.** `14:06` **You**

Yeah I know he is pissed at dev


**087.** `14:06` **You**

Deb


**088.** `14:07` **You**

How did he react to your situation?


**089.** `14:09` **Meredith Lamb (+14169386001)**

In a very Haris way 🙂


**090.** `14:11` **You**

lol I will let you explain that later


**091.** `14:18` **Meredith Lamb (+14169386001)**

You know Haris… very calm and respectful\.


**092.** `14:41` **You**

I feel guilty about not telling bailey\. Ow these are my people\.


**093.** `14:41` **You**

Arghhhhh


**094.** `14:43` **Meredith Lamb (+14169386001)**

Telling Bailey about your separation?


**095.** `14:43` **Meredith Lamb (+14169386001)**

You should feel guilty


**096.** `14:43` **Meredith Lamb (+14169386001)**

I told her about mine


**097.** `14:45` **You**

She is like my person for all things emotionally horrible we share everything


**098.** `14:45` **Meredith Lamb (+14169386001)**

At least you told Carolyn\. I think you were causing her undue stress


**099.** `14:45` **You**

I feel really bad I am telling her


**100.** `14:45` **You**

Yeah well I didn’t mean to


**101.** `15:15` **You**

Ok all done I can stop for a while\.


**102.** `15:47` **Meredith Lamb (+14169386001)**

Stop what?


**103.** `15:47` **Meredith Lamb (+14169386001)**

Telling ppl? Lol


**104.** `15:48` **You**

Yeah\.\. I am exhausted\. Cancelled my meeting with haris


**105.** `15:48` **You**

Couldn’t deal with him today


**106.** `16:47` **You**

Going over very curious as to what Yolanda wants\.


**107.** `18:30` **You**

Srry not trying to come down just worried about you\.


**108.** `18:31` **You**

Will leave it alone\.\. I love you just the way you are anyways\.


**109.** `18:36` **Meredith Lamb (+14169386001)**

>
? Not trying to come down?

*💬 Reply*

**110.** `18:37` **You**

I felt like I was being a sick about the drinking\.\. I should just shut up


**111.** `18:37` **You**

None of my business anyways\.


**112.** `18:38` **You**

Again sry\.\. can’t help it sometimes lol big mouth\.


**113.** `18:38` **Meredith Lamb (+14169386001)**

It’s fine\. I’m completely aware that I’ve been going overboard\. Lol


**114.** `18:40` **You**

Still I don’t need to pile on


**115.** `18:40` **Meredith Lamb (+14169386001)**

I actually asked ChatGPT the other day why I do this and others don’t\. Lol


**116.** `18:40` **You**

I am part of the reason for the stress you are dealing with anyways


**117.** `18:40` **Meredith Lamb (+14169386001)**

Didn’t tell me anything I didn’t already know\.


**118.** `18:41` **You**

I might do it if I wasn’t so focused on getting in shape… even low calorie alcohol can mess up a plan


**119.** `18:41` **You**

That and I get addicted to shit


**120.** `18:42` **Meredith Lamb (+14169386001)**

>
Possibly…\. \(That wasn’t abrupt was it? 😜\)

*💬 Reply*

**121.** `18:42` **You**

Nope just the truth lol I feel bad but i cannot help it\.


**122.** `18:43` **You**

You could tell me to go away if it is too
Much you know\.


**123.** `18:43` **You**

😜


**124.** `18:45` **Meredith Lamb (+14169386001)**

Suuure


**125.** `18:45` **Meredith Lamb (+14169386001)**

That definitely sounds LESS stressful


**126.** `18:46` **You**

I mean less obligations


**127.** `18:46` **You**

Less juggling


**128.** `18:47` **You**

But I mean you are used to that what is one more thing 🙂


**129.** `18:49` **Meredith Lamb (+14169386001)**

>
Omg just stop

*💬 Reply*

**130.** `18:49` **Meredith Lamb (+14169386001)**

lol


**131.** `18:49` **Meredith Lamb (+14169386001)**

My stress is not obligation


**132.** `18:49` **Meredith Lamb (+14169386001)**

Like not even close


**133.** `18:50` **Meredith Lamb (+14169386001)**

My stress is not being able to be with you, not being able to work with you, secrecy secrecy secrecy, your family finding out


**134.** `18:50` **Meredith Lamb (+14169386001)**

That’s about it


**135.** `18:50` **Meredith Lamb (+14169386001)**

Minimal


**136.** `18:51` **You**

I was joking mer\.\.


**137.** `18:51` **You**

This the last sentence


**138.** `18:51` **You**

Thus\.


**139.** `18:51` **You**

>
I know will be over soon

*💬 Reply*

**140.** `18:52` **Meredith Lamb (+14169386001)**

I know\. I just felt like listing it out to refresh myself actually\.


**141.** `18:52` **Meredith Lamb (+14169386001)**

Because that is only the stress related to us\.


**142.** `18:52` **Meredith Lamb (+14169386001)**

Not to mention the rest


**143.** `18:57` **Meredith Lamb (+14169386001)**

Biggest stress right now: can I get a settlement agreement before Andrew finds out


**144.** `18:58` **Meredith Lamb (+14169386001)**

And: did I ruin my rep at work through all this


**145.** `18:58` **Meredith Lamb (+14169386001)**

And: can I afford a place to rent in my area


**146.** `18:59` **You**

Ruin your reputation?


**147.** `18:59` **You**

That is manageable


**148.** `18:59` **You**

Easily


**149.** `18:59` **You**

Andrew won’t find out\. At least not from my side for sure


**150.** `19:00` **You**

Did you have a hard time working with me today?


**151.** `19:08` **Meredith Lamb (+14169386001)**

>
Omg you just jinxed it\.

*💬 Reply*

**152.** `19:09` **You**

No I didn’t


**153.** `19:09` **You**

I have been saying that for days


**154.** `19:09` **Meredith Lamb (+14169386001)**

>
Today was fine but the last month or so has been difficult\.

*💬 Reply*

**155.** `19:09` **You**

Reaction: 😂 from Meredith Lamb
Well only one thing was different 😛


**156.** `19:09` **You**

Glad it went well


**157.** `19:15` **Meredith Lamb (+14169386001)**

>
Yes, you win\.

*💬 Reply*

**158.** `19:15` **Meredith Lamb (+14169386001)**

I will give you this one\.


**159.** `19:16` **You**

I appreciate that


**160.** `19:16` **You**

Will take all the wins I can get\.\. you are a tough nut to get wins by\.


**161.** `19:17` **Meredith Lamb (+14169386001)**

You deserve it I guess\.


**162.** `19:17` **You**

I only see you deserve it\.\. rest is fuzzy\.


**163.** `20:28` **Meredith Lamb (+14169386001)**

Driving done\. Dog walking done\. Making some neocitran for my throat and then watching documentary in bed\.


**164.** `20:29` **You**

Nice had to run to get carts for Gracie


**165.** `20:30` **You**

Heading home now


**166.** `21:12` **You**

suspect you will be asleep soon if you aren't already\.\. Have a good night\.\. I will be up tomorrow same routine as always now\.\. will see you when I see you\.\. hope you get some rest\.


**167.** `21:16` **Meredith Lamb (+14169386001)**

You doing your application tonight?


**168.** `21:16` **You**

no got sidetracked


**169.** `21:39` **Meredith Lamb (+14169386001)**

Going to sleep super early\. Nite xoxo love you


**170.** `21:41` **You**

Night love you too xoxo ❤️


