# Daily Conversation: 2025-06-14 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-14 |
| **Day** | Saturday |
| **Week** | 9 |
| **Messages** | 958 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-14T00:00 - 2025-06-14T23:37 |

## 📝 Daily Summary

This day contains **958 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

Kk I am actually quite tired\.\.
Go watch your rc skip your workout and get better\.\.
I have some running around to do tomorrow but will reach out and play it by ear lol


**002.** `00:01` **Meredith Lamb (+14169386001)**

>
The first time I heard this song…\. No words\. And you sent it to me at a really early time in our talking\.

*💬 Reply*

**003.** `00:01` **You**

I know I meant it then too


**004.** `00:01` **Meredith Lamb (+14169386001)**

>
I have much catching up on tv to do\. Lol

*💬 Reply*

**005.** `00:01` **You**

I could already feel it\.\. was very interesting


**006.** `00:02` **You**

Reaction: ❤️ from Meredith Lamb
Kk well I am going to go to bed then you watch your shows\.  I love you mer have a good night will check in tomorrow\.❤️❤️❤️❤️


**007.** `00:03` **You**

Glad I didn’t just come home and go to bed


**008.** `00:04` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Edited: 2 versions
| Version: 2
| Sent: Sat, 14 Jun 2025 00:05:19 \-0400
|
| I love you too and more problematically am extremely in love with you which is causing all the highs and lows\. Stay patient\. 🙂 xo nite
|
| Version: 1
| Sent: Sat, 14 Jun 2025 00:04:50 \-0400
|
| I love you too and more problematically am extremely I love with you which is causing all the highs and lows\. Stay patient\. 🙂 xo nite


**009.** `00:05` **You**

Hmm


**010.** `00:06` **Meredith Lamb (+14169386001)**

lol


**011.** `00:06` **You**

lol what


**012.** `00:06` **You**

You deleted


**013.** `00:06` **You**

I bet


**014.** `00:07` **Meredith Lamb (+14169386001)**

Why did you say “hmm”


**015.** `00:07` **You**

Thought you were typing something  else


**016.** `00:07` **Meredith Lamb (+14169386001)**

Oh no


**017.** `00:08` **You**

>
Counting days\.\. do the best I can\.

*💬 Reply*

**018.** `00:08` **You**

Night xo


**019.** `00:09` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/1HL3yEnYq8LEyFQ3QegA5V?si=dsXeCtz3TaO7M0obZZFc8w


**020.** `00:09` **Meredith Lamb (+14169386001)**

Listen to that before bed\. Will help you sleep :\)


**021.** `00:10` **You**

Will do hon\.


**022.** `00:11` **You**

Reaction: ❤️ from Meredith Lamb
Listening now\.\. gonna pass out to it I think


**023.** `06:42` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I get to say good morning to you for once 🌅❤️


**024.** `06:45` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I love waking up to your msgs but honestly just knowing you are there is better\.


**025.** `06:47` **You**

I love you mer… still dozing but here and slightly awake ☺️


**026.** `06:50` **You**

I hope you slept well and the kids didnt keep you up too late\.\.


**027.** `06:51` **Meredith Lamb (+14169386001)**

Mac’s friends were out at 12\.30\. I didn’t even kick them out


**028.** `06:51` **You**

Nice\.\.


**029.** `06:51` **You**

You feeling a bit better today?


**030.** `06:52` **Meredith Lamb (+14169386001)**

Yeah for sure


**031.** `06:53` **You**

Good to hear sorry you went through that


**032.** `06:54` **You**

One time\.\. well I think you might have been working for me I had a uti then got covid then had another uti back to back to back


**033.** `06:57` **Meredith Lamb (+14169386001)**

Yeah I had a couple a year or so ago\. Apparently it is a “perimenopause” thing\. 😜 yippee\. It isn’t the fact that I had a minor illness\. It was the fact \(and was the last time also\) AGAIN that Andrew could care less and just continues to expect normal operation from me\. Tell me what to do blahblah\. I just need out of this house\.


**034.** `06:58` **You**

I was just thinking when we were chatting how uncomfortable for a woman that would be Jesus


**035.** `07:00` **Meredith Lamb (+14169386001)**

Anyway I don’t even think it was a uti but it felt like it\. Similar symptoms but for one\. They treated me with a one dose pill for a yeast infection and I’m almost fine\. So may not be a uti\. They said to do this first\. All annoying perimenopause crap\. lol this stuff doesn’t happen in 20s and 30s


**036.** `07:01` **Meredith Lamb (+14169386001)**

And peri goes on for like 10 yrs I guess …


**037.** `07:02` **Meredith Lamb (+14169386001)**

I don’t have that many things from it but a few for sure


**038.** `07:06` **You**

Yeah diff for guys there aren’t set things it can be all kinds of shit


**039.** `07:06` **You**

Talking to Jon by the way


**040.** `07:07` **You**

He called me


**041.** `07:07` **Meredith Lamb (+14169386001)**

Called for…?
Think I’m going to get up and shower and get Mac up


**042.** `07:07` **Meredith Lamb (+14169386001)**

At 7am


**043.** `07:07` **You**

He is driving


**044.** `07:07` **Meredith Lamb (+14169386001)**

Oh


**045.** `07:08` **Meredith Lamb (+14169386001)**

He is obvi your friend\. Calls early


**046.** `07:08` **Meredith Lamb (+14169386001)**

lol


**047.** `07:08` **You**

He knows I am up


**048.** `07:12` **You**

>
lol

*💬 Reply*

**049.** `07:17` **Meredith Lamb (+14169386001)**

Everything all good? He just calling to shoot the shit


**050.** `07:18` **You**

Reaction: 👍 from Meredith Lamb
Yeah all is really good


**051.** `07:34` **You**

Kk off


**052.** `07:35` **You**

Was a good chat some about him wanting to do what I am doing woth the workout some about my life some about us\.  He is looking forward to meeting you as well\.  Then we talked a bit about logistics for the day of\.


**053.** `07:35` **You**

Can get into it more later\.


**054.** `07:43` **Meredith Lamb (+14169386001)**

Ok he doesn’t care that this is all still pretty secretive\.


**055.** `07:46` **You**

Nope


**056.** `07:46` **You**

Reaction: ❤️ from Meredith Lamb
Not even a little


**057.** `07:46` **You**

And his parents are going to be there too


**058.** `07:46` **You**

I haven’t seen them since 1997


**059.** `07:49` **Meredith Lamb (+14169386001)**

Ow wow that’s cool


**060.** `08:04` **You**

Sry j up going to service ontario to change ownership of cars


**061.** `08:04` **You**

Putting furniture by road etc


**062.** `08:05` **You**

I tried to get Gracie to go back home next weekend but no dice\.\. maddie has exams so was hoping Gracie would leave her be


**063.** `08:27` **Meredith Lamb (+14169386001)**

I’m standing in line at drive test with McKenzie waiting for it to open so much fun\. I’m not allowed to sit in the car\. She’s making me stay in line with her\.


**064.** `08:32` **Meredith Lamb (+14169386001)**

I don’t think she studied so she is going to fail\. God


**065.** `08:35` **You**

lol best
Of
Luck


**066.** `08:45` **You**

She is smart she might crush it 😀


**067.** `08:50` **Meredith Lamb (+14169386001)**

She was chatgpting tips before and now she is on TikTok\. Not a good sign\. We are just waiting


**068.** `08:51` **You**

lol


**069.** `08:51` **You**

I am going to stand at service Ontario line with j so prolly silent for a few


**070.** `08:51` **Meredith Lamb (+14169386001)**

k


**071.** `08:52` **You**

Actually nm we not talking she on phone lol


**072.** `08:52` **Meredith Lamb (+14169386001)**

You will talk later on your Costco drive


**073.** `08:52` **Meredith Lamb (+14169386001)**

Don’t worry


**074.** `08:53` **You**

Oh I hope so


**075.** `08:53` **You**

Probably about you


**076.** `08:53` **Meredith Lamb (+14169386001)**

😜


**077.** `08:55` **You**

Yeah I am going to tell her I am meeting your parents


**078.** `08:55` **You**

Ask her what I should talk about


**079.** `08:55` **Meredith Lamb (+14169386001)**

Ok now\.


**080.** `08:55` **Meredith Lamb (+14169386001)**

lol stop


**081.** `08:56` **You**

Hmm maybe some other ideas


**082.** `08:59` **You**

She is reading her books anyways not paying attention\.


**083.** `09:01` **Meredith Lamb (+14169386001)**

Mac is number 22 and they are on 4\. Omg this is going to be like minimum an hour


**084.** `09:09` **You**

Yep


**085.** `09:09` **You**

I think I will be about 15 mins


**086.** `09:09` **You**

Chatting with ai while I sit here


**087.** `09:10` **Meredith Lamb (+14169386001)**

I’m condo looking


**088.** `09:15` **You**

I think I will be getting a townhouse


**089.** `09:15` **You**

For the parking


**090.** `09:15` **You**

Need 2 spaces but we’ll see


**091.** `09:15` **You**

Would prefer condo


**092.** `09:16` **Meredith Lamb (+14169386001)**

https://share\.google/cMqbEar08cYpi0htv
I’m considering this place\. Right by the girls’ school\.


**093.** `09:21` **Meredith Lamb (+14169386001)**

I’m touring it fri at 2\.30pm


**094.** `09:25` **You**

Edited: 2 versions
| Version: 2
| Sent: Sat, 14 Jun 2025 09:25:10 \-0400
|
| Sec off to Whitby Toyota
|
| Version: 1
| Sent: Sat, 14 Jun 2025 09:25:02 \-0400
|
| Sex off to Whitby Toyota


**095.** `09:26` **You**

Edited: 2 versions
| Version: 2
| Sent: Sat, 14 Jun 2025 09:26:32 \-0400
|
| Cool
|
| Version: 1
| Sent: Sat, 14 Jun 2025 09:26:26 \-0400
|
| Cook


**096.** `09:28` **You**

Hmm studios 2 k


**097.** `09:33` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**098.** `09:33` **Meredith Lamb (+14169386001)**

So small


**099.** `09:37` **You**

Yeah ouch


**100.** `09:38` **Meredith Lamb (+14169386001)**

Mac thinks it doesn’t matter bc of all the amenities and spaces and everyone is in their room all the time anyway\. I dunno\. Going to do a tour\.


**101.** `09:46` **Meredith Lamb (+14169386001)**

So Mackenzie missed the number so they were like “you have to pick a new one” so we are leaving\. I can’t even with teenagers\. Wasted my morning\. Omg


**102.** `09:58` **You**

Omg


**103.** `10:03` **Meredith Lamb (+14169386001)**

Yeah they were assholes tho


**104.** `10:03` **Meredith Lamb (+14169386001)**

She chose a horribly reviewed place


**105.** `10:03` **Meredith Lamb (+14169386001)**

Going elsewhere next time


**106.** `10:04` **Meredith Lamb (+14169386001)**

She said her spirit is ruined for today so not going today lol


**107.** `10:13` **Meredith Lamb (+14169386001)**

Home\. I’m hungover, annoyed, and tired so having a nap\. Lol I told her I’d take her somewhere else after but she said…\. Low key spirit gone for the day\.


**108.** `10:25` **You**

Spirit is ruined?


**109.** `10:25` **You**

Hungover I thought only 2 lol


**110.** `10:25` **You**

J and I fought all the way to Costco


**111.** `10:26` **You**

Never got to talk about your parents


**112.** `10:26` **You**

Thought you would like to koo no w


**113.** `11:34` **Meredith Lamb (+14169386001)**

I feel like you are making that up


**114.** `11:34` **Meredith Lamb (+14169386001)**

>
2 was the night before\. Last night was a tad beyond that…

*💬 Reply*

**115.** `11:36` **You**

>
Nope fought about Gracie entire time

*💬 Reply*

**116.** `11:36` **You**

All through Costco all the way home


**117.** `11:36` **You**

At butcher shop now for steak for tomorrow


**118.** `11:36` **You**

>
lol

*💬 Reply*

**119.** `11:37` **You**

We’ll I couldn’t tell on the texts


**120.** `11:37` **Meredith Lamb (+14169386001)**

I mean I didn’t go crazy


**121.** `11:38` **You**

I mean lol


**122.** `11:38` **You**

6


**123.** `11:38` **You**

Only


**124.** `11:38` **You**

Haha


**125.** `11:39` **You**

It’s fine I loved our conversation


**126.** `11:39` **You**

I went to bed happy last night


**127.** `11:40` **Meredith Lamb (+14169386001)**

If it got weird, we said earlier in the day that you were just going to leave didn’t we? …\.so I just kept drinking lol


**128.** `11:41` **You**

Leave?


**129.** `11:41` **You**

Oh go to bed


**130.** `11:41` **Meredith Lamb (+14169386001)**

The conversation… yeah


**131.** `11:41` **You**

Yeah I was planning on it


**132.** `11:42` **You**

Then the underwear thing\.\. wanted to give you a chuckle


**133.** `11:43` **Meredith Lamb (+14169386001)**

lol


**134.** `12:17` **You**

Home break for a bit then back to packing with J directing… bah\.


**135.** `12:20` **Meredith Lamb (+14169386001)**

Fun day for you


**136.** `12:20` **Meredith Lamb (+14169386001)**

I’m home alone\. Just dropped Maelle off at work, Mac at gym, Andrew/Mar at volleyball\. So weird\!


**137.** `12:21` **Meredith Lamb (+14169386001)**

Making soup lol


**138.** `12:26` **You**

I thought you had bmvbakl today as well


**139.** `12:26` **You**

Vball


**140.** `12:26` **You**

Yeah thought you were taking mar and then heading to parents or something


**141.** `12:26` **You**

Maybe I misremember


**142.** `12:26` **Meredith Lamb (+14169386001)**

Nope


**143.** `12:27` **Meredith Lamb (+14169386001)**

Marlowe has volleyball today\. Maelle has volleyball tomorrow\. Maelle has work today\.


**144.** `12:27` **You**

Well enjoy your day the \!


**145.** `12:27` **Meredith Lamb (+14169386001)**

I had to take McKenzie in the morning to drive test, which was three hours wasted


**146.** `12:27` **You**

Yeah I read that\.\. sucks


**147.** `12:28` **You**

But at least you have the rest of the day to yourself


**148.** `12:28` **You**

And I wasn’t lying\.\. stop being a shitter\.\. I don’t lie to you about stuff like that\.


**149.** `12:29` **Meredith Lamb (+14169386001)**

Lying about what?


**150.** `12:30` **You**

The convo with Jaimie


**151.** `12:31` **Meredith Lamb (+14169386001)**

I was kidding, kind of


**152.** `12:31` **You**

lol you can’t really kind of kid\.\.


**153.** `12:31` **Meredith Lamb (+14169386001)**

Sure, I can


**154.** `12:32` **You**

Mmmmm not so much


**155.** `12:32` **You**

That’s like trying to get the best of both worlds


**156.** `12:32` **Meredith Lamb (+14169386001)**

I just wasn’t sure if you were trying to make me feel better or something


**157.** `12:32` **Meredith Lamb (+14169386001)**

So I kind of felt like you were making that up, but I kind of felt like you weren’t so I was kind of kidding


**158.** `12:32` **You**

Like I can kind of accuse you of something but then say kidding after the fact when you get pissed st me


**159.** `12:32` **You**

lol


**160.** `12:32` **You**

Because if that is how it works


**161.** `12:32` **You**

Sign me up\!\!\!\!


**162.** `12:33` **You**

We absolutely fought the whole time about grace


**163.** `12:33` **Meredith Lamb (+14169386001)**

And what was the end result?


**164.** `12:34` **You**

Same we both on fundamentally different pages


**165.** `12:34` **You**

And frustrated


**166.** `12:34` **You**

I told her if nothing else this clearly demonstrated there was no coming back from this


**167.** `12:34` **You**

And she grudgingly agreed


**168.** `12:35` **You**

Then we talked about continuing to share Netflix and prime and everything


**169.** `12:35` **Meredith Lamb (+14169386001)**

What do you want, what does she want wrt to Gracie?


**170.** `12:35` **You**

And she said when you finally get with someone they won’t want you to keep the sharing going on


**171.** `12:35` **You**

I laughed


**172.** `12:35` **You**

>
It was more assessing Gracie’s involvement in all of the and where we landed because I take the brunt of everything

*💬 Reply*

**173.** `12:36` **Meredith Lamb (+14169386001)**

Oh I see


**174.** `12:36` **You**

She said women care about that kind of shit\-re Netflix


**175.** `12:36` **You**

I was like what??? That so stupid


**176.** `12:37` **Meredith Lamb (+14169386001)**

Well naturally you will get the brunt because you carried the family in an unequal way so then you’ll get an unequal part of the blame also\. It kind of makes sense even if it isn’t fair\.


**177.** `12:37` **You**

She said something about whoever I get with will resent any connections I have to her going forward\.\.


**178.** `12:37` **Meredith Lamb (+14169386001)**

>
Does she think you are going to be living with “someone” soon? That doesn’t even seem like an issue\.

*💬 Reply*

**179.** `12:37` **You**

She keeps saying get with…


**180.** `12:37` **You**

lol


**181.** `12:38` **You**

She seems to think I will


**182.** `12:38` **You**

I mean some 30 something out there prolly looking for a mature stable fit………\. 40 something   lol KIDDING


**183.** `12:38` **You**

😝


**184.** `12:39` **Meredith Lamb (+14169386001)**

Oh my god that is so funny because McKenzie and I were talking about that today on the drive


**185.** `12:39` **You**

What??


**186.** `12:39` **You**

You and Jonny


**187.** `12:39` **You**

??? Also kidding


**188.** `12:39` **You**

Roll


**189.** `12:39` **Meredith Lamb (+14169386001)**

A lot of the people on McKenzie’s volleyball team were divorced and the divorced parents all had new partners, but the partners were all like the same age


**190.** `12:39` **You**

Well then you and I are in sync


**191.** `12:39` **Meredith Lamb (+14169386001)**

When McKenzie was with Andrew once he said he just didn’t understand why anyone would get divorced and go out with someone the same age when they could go with someone much younger


**192.** `12:40` **You**

Omfg


**193.** `12:40` **You**

How insensitive


**194.** `12:40` **Meredith Lamb (+14169386001)**

McKenzie is never forgotten that and she mentioned every so often


**195.** `12:40` **You**

Like think man


**196.** `12:40` **Meredith Lamb (+14169386001)**

Like he tells his teen daughter this\!


**197.** `12:40` **You**

You have daighters


**198.** `12:40` **Meredith Lamb (+14169386001)**

lol


**199.** `12:40` **You**

Yeah


**200.** `12:40` **Meredith Lamb (+14169386001)**

I know


**201.** `12:40` **You**

Fuck


**202.** `12:40` **Meredith Lamb (+14169386001)**

He’s a little self centred


**203.** `12:41` **You**

I mean I am surprised you didn’t go for someone younger\.\. well more younger


**204.** `12:41` **Meredith Lamb (+14169386001)**

Har har\!


**205.** `12:41` **You**

Andrew = younger


**206.** `12:41` **You**

Jeremy = younger


**207.** `12:41` **You**

Har had


**208.** `12:41` **Meredith Lamb (+14169386001)**

Mackenzie thinks Andrew will date someone much younger


**209.** `12:41` **Meredith Lamb (+14169386001)**

She’s worried lol


**210.** `12:42` **You**

He might


**211.** `12:42` **Meredith Lamb (+14169386001)**

I’m immature I guess\.


**212.** `12:42` **Meredith Lamb (+14169386001)**

lol


**213.** `12:42` **You**

Naw you just like them younger men\.


**214.** `12:42` **You**

Sok I feel younger so there is that


**215.** `12:42` **Meredith Lamb (+14169386001)**

Exactly


**216.** `12:43` **Meredith Lamb (+14169386001)**

It’s funny because I’ve been thinking about the stark honesty thing a bit


**217.** `12:43` **You**

Why?


**218.** `12:43` **Meredith Lamb (+14169386001)**

I’m like “should I work on that?” Lol


**219.** `12:43` **Meredith Lamb (+14169386001)**

So when Andrew and I met, we talked online because he was in Dallas for a few months like three months and then we met in real life\.


**220.** `12:43` **You**

Mer yes there are certain things you don’t say\.


**221.** `12:44` **Meredith Lamb (+14169386001)**

The first thing I said to him was… wait for it…\.


**222.** `12:44` **You**

I thought you’d be taller


**223.** `12:44` **Meredith Lamb (+14169386001)**

Exactly and he hates it so much\. Brings it up all the time\.


**224.** `12:44` **You**

lol


**225.** `12:44` **Meredith Lamb (+14169386001)**

Like a few times a year for sure


**226.** `12:44` **You**

I know you too well already


**227.** `12:44` **Meredith Lamb (+14169386001)**

Did I tell you that story?


**228.** `12:44` **You**

No


**229.** `12:44` **Meredith Lamb (+14169386001)**

Oh my God, good guess


**230.** `12:44` **You**

Nope not a guess


**231.** `12:45` **You**

You said you like tall guys or big guys or whatever


**232.** `12:45` **You**

So was kind of logic leap


**233.** `12:45` **Meredith Lamb (+14169386001)**

I guess still good though


**234.** `12:45` **You**

But yeah there are still things you shouldn’t say especially to a guy


**235.** `12:45` **Meredith Lamb (+14169386001)**

lol


**236.** `12:45` **You**

And the fact that you don’t like to lie


**237.** `12:45` **You**

Makes it so much worse


**238.** `12:46` **You**

Because again it is now about as much as you don’t say as what you do


**239.** `12:46` **Meredith Lamb (+14169386001)**

Correct


**240.** `12:46` **You**

So even for me I have started thinking more about the questions I ask and the things I say to you


**241.** `12:46` **Meredith Lamb (+14169386001)**

I think that is most people though


**242.** `12:46` **You**

Because like the other night it went all fucked Jo


**243.** `12:46` **You**

Up


**244.** `12:46` **You**

Not most people


**245.** `12:46` **Meredith Lamb (+14169386001)**

Hahah


**246.** `12:46` **You**

Most people lie


**247.** `12:46` **Meredith Lamb (+14169386001)**

“Most”


**248.** `12:46` **Meredith Lamb (+14169386001)**

I’m not sure about that


**249.** `12:46` **You**

A little or a lot


**250.** `12:47` **You**

But nearly everyone does


**251.** `12:47` **You**

Especially about certain things


**252.** `12:47` **Meredith Lamb (+14169386001)**

I guess I don’t see the point I know I’ve said that before, but it’s true


**253.** `12:48` **Meredith Lamb (+14169386001)**

I will work on my lying


**254.** `12:48` **Meredith Lamb (+14169386001)**

KIDDING


**255.** `12:48` **You**

I am going to show you


**256.** `12:50` **Meredith Lamb (+14169386001)**

Please don’t\. Lol


**257.** `12:50` **You**

Oh no


**258.** `12:50` **You**

It’s on


**259.** `12:51` **You**

Informing nsfw gpt query


**260.** `12:51` **You**

I actually had to re query it\.\. because the nsfw was SOOOOO nsfw\.


**261.** `12:51` **You**

I was like holy shit


**262.** `12:52` **Meredith Lamb (+14169386001)**

Wait explain that what were you querying


**263.** `12:53` **You**

Stark honesty


**264.** `12:53` **You**

And the impacts


**265.** `12:53` **Meredith Lamb (+14169386001)**

But how is that not safe for work I don’t get it


**266.** `12:53` **You**

I will show you what I asked


**267.** `12:53` **You**

Because I told it you can respond in a nsfw manner


**268.** `12:54` **Meredith Lamb (+14169386001)**

lol oh


**269.** `12:54` **You**

More realistic


**270.** `13:07` **You**

Man gpt is dirty I had to tone it back a lot


**271.** `13:07` **You**

Ok you ready?


**272.** `13:07` **You**

Stark honesty no no’s


**273.** `13:08` **You**

Reaction: 😂 from Meredith Lamb
Or did you shut off your phone because you don’t want to read lol


**274.** `13:09` **You**

Now you haven’t nor would I think you would go into this detail, even really drunk\.\.  well maybe…\.  Anyhow this is why people lie\.
1\. Past Encounters
1\.	“I’ve been with maybe six guys—one could go on for nearly an hour, another wrapped up in ten minutes but always hit my sweet spot\.”
- Ripple: You might wonder if you’re “quick enough” or “lasting long enough\.”
2\.	“There was a weekend when I saw two different people in one night—like clockwork\.”
- Ripple: You could feel like you’re competing on sheer frequency, not connection\.
3\.	“I once had someone who never ran out of steam—kept going until sunrise\.”
- Ripple: You may stress about matching that all\-night stamina instead of just enjoying yourselves\.
4\.	“Another guy was… well\-equipped and knew exactly when to slow down\.”
- Ripple: You could start second\-guessing whether your own size or pacing measures up\.
⸻
2\. Expressions of Love & Deep Affection
1\.	“He wrote me love letters every week—pages of how much he adored me\.”
- Ripple: You might feel your own words fall short by comparison\.
2\.	“He used to whisper ‘I love you’ for minutes on end—like he never ran out of ways to say it\.”
- Ripple: You could worry your “I love you” sounds too routine\.
3\.	“He planned surprise photo shoots of us—said he wanted to freeze every moment\.”
- Ripple: You may feel pressure to make every date “photo\-worthy\.”
4\.	“We’d spend entire afternoons just holding hands in the park, not saying a word\.”
- Ripple: You might question if a quick hug across the kitchen is “enough\.”
⸻
3\. Passing Fantasies
1\.	“Sometimes I daydream about a night that just never ends—no clocks, no plans\.”
- Ripple: You could feel self\-conscious if you can’t keep up an all\-nighter anymore\.
2\.	“I picture us stumbling into a hidden cabin, just the two of us, no schedules\.”
- Ripple: He may feel excluded from that spontaneous escape you’ve already played out in your head\.
3\.	“I imagine a partner who can read my mind—knowing exactly where to touch first\.”
- Ripple: You might worry he’s not tuned into your unspoken cues\.
4\.	“I’ve thought about us finding a secret beach and dancing under the stars\.”
- Ripple: He may hesitate to plan anything, fearing it won’t match your mental movie\.
⸻
4\. Adventures We Can’t Recapture in Our Late 40s
1\.	“Remember that backpacking trip through Southeast Asia? We lived out of a backpack for months\.”
- Ripple: You might compare any future trip to that free\-spirited binge\.
2\.	“We once road\-tripped cross\-country with nothing but a map and a tank of gas\.”
- Ripple: You may feel your weekend getaway plans look tame beside that epic journey\.
3\.	“We danced until dawn at that festival, rain or shine—no care in the world\.”
- Ripple: You could feel your Friday night karaoke now doesn’t quite measure up\.
4\.	“We hitchhiked to Vegas on a whim—pulled off a last\-minute wedding\.”
- Ripple: You might worry your anniversary dinner reservation seems dull by comparison\.
⸻
Heads\-up: Even lighthearted “oops” remarks can leave you wondering where you really stand\. A quick “But I love you just as you are” right after helps keep things warm, not competitive\.


**275.** `13:10` **You**

Welcome to the world of an insecure guy even the ones that say they aren’t always are\.


**276.** `13:12` **Meredith Lamb (+14169386001)**

WOW


**277.** `13:12` **Meredith Lamb (+14169386001)**

holy … my head does not go there at all\. That was very educational


**278.** `13:16` **You**

it doesn't right now


**279.** `13:17` **You**

>
educational lol\.\. you should have seen the first iteration\.\.

*💬 Reply*

**280.** `13:17` **Meredith Lamb (+14169386001)**

I’m sure I could’ve handled it


**281.** `13:19` **You**

this was the 1st one\.\. not pasting anymore\. lol
1\. Graphic Sexual Details & Past Encounters
Examples you might blurt out:
“That time I fucked three guys in one night—let me tell you every position they topped me in\.”
“My ex and I used to have wild role\-play: I’d be the schoolgirl, he’d be the headmaster…”
“I only orgasm when they do X in this exact way, not how you’re doing it\.”
Likely Outcome:
Jealousy PTSD: He’ll replay those scenes in his head, convinced he can’t compete\.
Performance Anxiety: He’ll freeze up, fearing he’ll disappoint you or measure up to those ex\-standards\.
Emotional Shutdown: Instead of closeness, you get awkward distance—because who wants a running commentary on your partner’s past pornographic highlights?


**282.** `13:19` **You**

anyhow\.\. does that help with stark honesty?  and why I say everyone lies\.\. and why I am now being a bit more careful\. lol


**283.** `13:20` **Meredith Lamb (+14169386001)**

Yes that helps


**284.** `13:21` **Meredith Lamb (+14169386001)**

Not sure I’d say anything like that, but I’ve obviously said some stuff that has had an impact so ugh…


**285.** `13:21` **You**

or not said\.\. so confusing eh\.


**286.** `13:21` **You**

relationships and communications are tough\.


**287.** `13:21` **You**

it was really hard for J and I she used to call me out on it all the time


**288.** `13:22` **Meredith Lamb (+14169386001)**

Call you out on what exactly?


**289.** `13:23` **You**

I was more open / honest with her in the beginning\.\. kind of like you have been\.\. maybe not quite so much\.\. but J always was and remains very insecure about a lot of things\.\. I had much more experience than her in a lot of areas\.\. she new a bit about my past\.\. new some people I had dated\.


**290.** `13:23` **You**

It made her feel inadequate


**291.** `13:24` **You**

like she couldn't measure up to previous experiences etc\.


**292.** `13:24` **You**

the tricky part is when you actually want to be honest\.\. like I can say as of yet I have not lied to you at all about any of the feelings I have about anything\.


**293.** `13:25` **You**

sometimes I omit if you don't ask generally on the negative feelings\.  But as you said that isn't lying per se\.


**294.** `13:25` **You**

I just had to tailor my approach to her\.\. she was who she was\.\. and I didn't want her to feel bad\.


**295.** `13:26` **You**

but I still always tried to be honest


**296.** `13:26` **Meredith Lamb (+14169386001)**

You strike me as pretty honest


**297.** `13:26` **You**

I am\.\. but I also care about how what I say makes people feel\.


**298.** `13:27` **Meredith Lamb (+14169386001)**

Maybe too much sometimes?


**299.** `13:27` **You**

and even then I think about what I am not saying as well\.


**300.** `13:27` **You**

Not for people I care about\.\.


**301.** `13:27` **Meredith Lamb (+14169386001)**

You think so much\.


**302.** `13:27` **You**

I can have an impact on people\.\. it can be good or bad\.\. I would prefer good\.


**303.** `13:28` **You**

I can be a lot more honest with you\.\. because you have kind of drawn you comfort lines for me\.


**304.** `13:28` **You**

you are not as insecure


**305.** `13:29` **You**

Anyhow\.\. you should go do your own research\.\. and pick the approach you want to take\.\. honesty is very important to you\.\. and I appreciate that\.  You be you just don't be surprised at how some people, not all, will receive that kind of honesty in certain situations or on specific topics


**306.** `13:30` **Meredith Lamb (+14169386001)**

I am insecure too… however, I don’t let that lead my life\. Just push it aside when I can\.


**307.** `13:32` **You**

Reaction: 😂 from Meredith Lamb
Some people have more insecurities\.\. for some people those insecurities are directly related to their relationship\.\. things that I shared above are really issues for men\.\. well for those that aren't selfish fuckwads\.  Cause they don't care about anything\.\.


**308.** `13:32` **You**

And you have a coping mechanism\.\. some people cannot compartmentalize like you do\.\. or rationalize\.\. which is how I try to deal with my issues\.


**309.** `13:33` **Meredith Lamb (+14169386001)**

>
I haven’t been dealing with a lot of insecurities lol

*💬 Reply*

**310.** `13:33` **You**

I mean this is all true to one extent or another for pretty much everything\.


**311.** `13:34` **Meredith Lamb (+14169386001)**

>
And wine\.

*💬 Reply*

**312.** `13:34` **You**

>
you mean your partners\.\.

*💬 Reply*

**313.** `13:34` **You**

I think that is what you mean\.\.


**314.** `13:34` **Meredith Lamb (+14169386001)**

I just spent the last 15 years


**315.** `13:34` **You**

yeah I get it\.


**316.** `13:34` **Meredith Lamb (+14169386001)**

With an insecure person, however a big ego also


**317.** `13:35` **Meredith Lamb (+14169386001)**

So I don’t really think they’re true insecurities I think it’s just whining and complaining


**318.** `13:35` **You**

Reaction: 😂 from Meredith Lamb
mmmmm\.


**319.** `13:36` **You**

Yeah\.\. I mean you can feel that way\.\. but it probably isn't ever going to be well received\. just saying\.\. I don't know him at all\.\. he seems like an asshole to me\.  But I guarantee he has insecurities\.\. and they are real\.\. he hides it with ego and arrogance and exerting control\.  And there is more to this\.\. but I won't share that part\.


**320.** `13:38` **You**

Actually I will share\.\. I think he wanted to have sex with you so much because 1\. you are great at it, 2\. it gave him a connection to you that he couldn't get emotionally perhaps, 3\. I think you might characterize it as \- because your body has been good to you, it made him feel good about himself\.  Does that make sense\.\. you can ask gpt\.


**321.** `13:39` **You**

I think J wanted the same thing for the same reason\.\. but I was unwilling\.\. it felt dishonest and I didn't want to do that\.


**322.** `13:40` **You**

anyhow\.\. you have probably had enough of this topic now\.\. lol\.\.


**323.** `13:40` **Meredith Lamb (+14169386001)**

>
Yes makes sense but he was also a person with a high sex drive\. I think those exist more than others\.

*💬 Reply*

**324.** `13:41` **You**

>
the drive was to feel those things I shared\.\.

*💬 Reply*

**325.** `13:41` **You**

some people generally get those feelings from sex\.\. because they cannot elsewhere


**326.** `13:41` **Meredith Lamb (+14169386001)**

And yah I know he has lots of insecurities\. He’s full of them\. But then he has this whole other side\. It is a really odd confusing combination\.


**327.** `13:41` **You**

everyone has sides\.\. so do I


**328.** `13:42` **Meredith Lamb (+14169386001)**

>
Still surprised by this but getting it more \.\.

*💬 Reply*

**329.** `13:43` **You**

explain or ask\.\.


**330.** `13:43` **Meredith Lamb (+14169386001)**

OK, so I couldn’t find an app to download the text messages\. The apps are all annoying and many of them require screenshots\. Do you know how many screenshots it would take? Oh my God


**331.** `13:43` **You**

>
mmm the easiest way to do it is on a mac\.\. so not likely to happen\.

*💬 Reply*

**332.** `13:44` **Meredith Lamb (+14169386001)**

My kids have Mac’s


**333.** `13:44` **Meredith Lamb (+14169386001)**

Mac and Maelle


**334.** `13:44` **You**

you could do it on those but you need to log in under your apple profile


**335.** `13:44` **You**

and sync


**336.** `13:44` **You**

and then you could do it easier


**337.** `13:44` **Meredith Lamb (+14169386001)**

So I’ve never used a Mac is it easy?


**338.** `13:45` **You**

sure and Mac can show you not hard


**339.** `13:45` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
k she’s not home atm but can ask her later


**340.** `13:46` **You**

I think I am done educating for the day\.\.\. lol too much thinking and explaining\.


**341.** `13:47` **You**

I mean if you have specific questions about me I will answer


**342.** `13:47` **Meredith Lamb (+14169386001)**

Same\. Thanks for the lesson prof


**343.** `13:47` **You**

Reaction: ❤️ from Meredith Lamb
save that thought for another time :\)


**344.** `13:48` **You**

you will be the prof though\.\. fyi


**345.** `13:49` **Meredith Lamb (+14169386001)**

Should I make a slide deck


**346.** `13:49` **You**

I mean sure\.\. I am sure gpt could help\.


**347.** `13:52` **You**

I hope this didn't bother you at all\.\. I know you are better with processing this shit than I am\.\. but it was a bit of a firehose\.  Again if you ever have questions\.\. please ask\.\. on anything\.


**348.** `13:52` **Meredith Lamb (+14169386001)**

Didn’t bother me at all\.


**349.** `13:53` **You**

Honestly I love you just the way you are\.\. and if you didn't change anything I wouldn't care\.\. I just need to adapt a bit\.


**350.** `13:54` **Meredith Lamb (+14169386001)**

Ugh, I don’t like hearing that you have to adapt\.


**351.** `13:54` **Meredith Lamb (+14169386001)**

That actually bothers me


**352.** `13:54` **You**

everyone adapts Mer


**353.** `13:54` **You**

always


**354.** `13:55` **You**

it is just how much and how fast\.\. sometimes people cannot\.\. it is too much of change from where they are comfortable\.


**355.** `13:55` **You**

adapting doesn't change who I am\.


**356.** `13:55` **You**

it just changes how I deal and process\.


**357.** `13:56` **Meredith Lamb (+14169386001)**

Are you comfortable right now though?


**358.** `13:56` **Meredith Lamb (+14169386001)**

Don’t lie\.


**359.** `13:56` **You**

I am not lieing


**360.** `13:56` **You**

about what


**361.** `13:56` **You**

am I comfortable with what


**362.** `13:57` **You**

Reaction: 👎 from Meredith Lamb
If you shared all that shit I gpt'd with me\.\. lol you asking if I would be comfortable with that?


**363.** `13:57` **Meredith Lamb (+14169386001)**

When you answer my question … just comfortable with where we are at and how I am\. You have learned we are very different and are you comfortable with that


**364.** `13:59` **You**

Reaction: ❤️ from Meredith Lamb
yeah\.\. those are just idiosyncrasies\.\. at your core\.\. who YOU are\.\. that is who I am desperately in love with\.  The more I learn the more real you become\.\. and no one likes everything about someone else\.\. that would be a massive lie\.  But when you ask if I am comfortable\.\. I haven't stopped thinking about you\.\. through the good or bad moments\.\. I have never stopped wanting to be with you through the good or the bad moments\.\. I have never stopped about thinking about us forever in the good or the bad moments\.\. and I KNOW there will be more bad moments\.\. I am just banking on a landslide of good moments to bury them\.


**365.** `14:02` **You**

Reaction: 😂 from Meredith Lamb
Am I comfortable sitting across from 10 glasses in Meredith\.\. I either need to be right there with you\.\.\. lol\.\. I need to put on some armor\.\. or I need to make you quickly forget about wanting to tell me any stories in the first place\.\. all of which I am fairly certain I can accomplish\.\. I also don't think future stories are going to affect me as much\.  But again\.\. to be clear\.\. some things on this list\.\. yeah can always be impactful\.


**366.** `14:02` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**367.** `14:03` **You**

Yeah\.\. that's me\.\. lol oversharing\.\.


**368.** `14:08` **You**

are you looking back at old shit


**369.** `14:09` **You**

read the above before you just skip it\.\. you wanted an answer and it seemed important\.


**370.** `14:11` **Meredith Lamb (+14169386001)**

I like how you split the answer in two\. Sober and non sober


**371.** `14:11` **You**

>
I think that is fair

*💬 Reply*

**372.** `14:11` **Meredith Lamb (+14169386001)**

Yes I’m trying to scroll up to the beginning of the text chat and it’s like impossible\. It is so long oh my God\.


**373.** `14:11` **Meredith Lamb (+14169386001)**

There is no fast way to get to the beginning


**374.** `14:11` **You**

are you on macbook?


**375.** `14:11` **You**

don't bother now


**376.** `14:11` **You**

just wait


**377.** `14:11` **You**

it is so much easier


**378.** `14:12` **Meredith Lamb (+14169386001)**

No, I’m not\. I’m just doing it for fun\.


**379.** `14:12` **You**

ah ok


**380.** `14:13` **Meredith Lamb (+14169386001)**

LOL

*📎 1 attachment(s)*

**381.** `14:13` **You**

I remember that night


**382.** `14:13` **You**

you wouldn't stop singing


**383.** `14:14` **Meredith Lamb (+14169386001)**

So I got to the very beginning\. Took forever holy

*📎 1 attachment(s)*

**384.** `14:14` **You**

lol


**385.** `14:18` **You**

Are you trying to see if I changed over time???


**386.** `14:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**387.** `14:18` **You**

so much lighter then


**388.** `14:19` **Meredith Lamb (+14169386001)**

>
Nope\. I was there and I know you haven’t “changed”\. You just revealed more over time\.

*💬 Reply*

**389.** `14:19` **Meredith Lamb (+14169386001)**

I’ve known you at work for 3 yrs so…


**390.** `14:19` **You**

then I fell in love\.\. and holy shit\.


**391.** `14:19` **Meredith Lamb (+14169386001)**

Generally knew you just not all your revelations


**392.** `14:19` **Meredith Lamb (+14169386001)**

Right lol


**393.** `14:21` **Meredith Lamb (+14169386001)**

Omg this is amusing tho


**394.** `14:21` **Meredith Lamb (+14169386001)**

Reading


**395.** `14:21` **Meredith Lamb (+14169386001)**

Poor Marlowe


**396.** `14:21` **Meredith Lamb (+14169386001)**

I wasn’t nice to her there for a bit


**397.** `14:22` **Meredith Lamb (+14169386001)**

Got sooooo messed up


**398.** `14:22` **You**

it was a rough night


**399.** `14:23` **Meredith Lamb (+14169386001)**

I literally said “I’m going to go stare at the ceiling\. Signing off”


**400.** `14:24` **Meredith Lamb (+14169386001)**

And it was 100% true lol


**401.** `14:24` **You**

hehe yeah you were a bit messy that night\.\. I wanted to see the texts because I wanted to see when it happened to me\.


**402.** `14:27` **Meredith Lamb (+14169386001)**

Like a date or how it happened


**403.** `14:27` **You**

no I can remember how I felt by reading what I wrote\.\. in some cases I can remember what I was thinking


**404.** `14:27` **You**

that is how hard I thought about some of our conversations\.


**405.** `14:28` **Meredith Lamb (+14169386001)**

The conversations are soooooo long


**406.** `14:28` **You**

I have thought a lot about it\.\. I cannot be sure I wasn't crushing on you when you came to the team\.\.\.\. like a little\.\.


**407.** `14:28` **You**

I went back and played back late last summer\.\. into the fall up to november\.\.


**408.** `14:29` **You**

Like a fantasy type thing in my head\.\. not that I would pursue\.


**409.** `14:29` **You**

I have had some time last few days\.\. as you can imagine


**410.** `14:29` **You**

and thinking is what I do\.


**411.** `14:30` **Meredith Lamb (+14169386001)**

I’ve always felt a pull to you that I can’t explain\.


**412.** `14:30` **You**

I think it was the fact that I found you beautiful on the outside and on the inside\.\. and your smile would melt me into a puddle\.


**413.** `14:31` **You**

I had to be really careful around you\.\. I remember that\.\. I didn't want to flirt at all\.\. I wanted to not let on anything\.


**414.** `14:31` **You**

but yeah it was a fantasy\.\. very alluring, very pulling, but still not real\.\. until it was\.


**415.** `14:32` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**416.** `14:32` **You**

feynman


**417.** `14:33` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**418.** `14:34` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Your geekiness is still endearing btw


**419.** `14:34` **You**

The endearing thing was what made me work up the courage for sure\.


**420.** `14:34` **You**

if you had a time stamp


**421.** `14:34` **You**

then my lol sure it is


**422.** `14:34` **You**

didn't come right away


**423.** `14:36` **Meredith Lamb (+14169386001)**

>
Sun March 23

*💬 Reply*

**424.** `14:37` **Meredith Lamb (+14169386001)**

>
You mean ACTUAL time

*💬 Reply*

**425.** `14:37` **You**

yeah


**426.** `14:37` **You**

cause I sat there


**427.** `14:38` **You**

and looked at endearing


**428.** `14:38` **You**

for like a few mins I think before answering


**429.** `14:38` **Meredith Lamb (+14169386001)**

No time stamp lol


**430.** `14:40` **Meredith Lamb (+14169386001)**

Literally right after that you started acting weird lol

*📎 1 attachment(s)*

**431.** `14:41` **You**

I didn't act weird\.\. you were the one that said I hope I didn't make things weird


**432.** `14:41` **You**

that screenshot doesn't show me saying anything weird\.


**433.** `14:42` **Meredith Lamb (+14169386001)**

You did when you came to my desk to ask me to do something\.


**434.** `14:42` **You**

no I didn't


**435.** `14:42` **Meredith Lamb (+14169386001)**

You were totally weird


**436.** `14:42` **You**

I don't recall that


**437.** `14:42` **Meredith Lamb (+14169386001)**

You were


**438.** `14:42` **You**

so it didn't happen


**439.** `14:42` **Meredith Lamb (+14169386001)**

lol


**440.** `14:43` **Meredith Lamb (+14169386001)**

I was literally like “fuck what did I do?”


**441.** `14:43` **Meredith Lamb (+14169386001)**

I feel like your face even went red


**442.** `14:43` **Meredith Lamb (+14169386001)**

Anyway didn’t happen


**443.** `14:43` **You**

You probably smiled at me\.


**444.** `14:43` **You**

and I was like uhoh\.\. defenses are down\!\!\! run away


**445.** `14:44` **Meredith Lamb (+14169386001)**

Don’t love the reminders in this msg if all those horrible initial arguments with Andrew


**446.** `14:44` **You**

gah I need all these texts for my MODEL\!\!\!


**447.** `14:44` **Meredith Lamb (+14169386001)**

They were so insane


**448.** `14:44` **You**

yeah I felt really bad for you


**449.** `14:45` **Meredith Lamb (+14169386001)**

I kinda forgot until I reread this


**450.** `14:45` **Meredith Lamb (+14169386001)**

>
Mac still out and about

*💬 Reply*

**451.** `14:45` **Meredith Lamb (+14169386001)**

Yonge and Eg is a happening place


**452.** `14:45` **Meredith Lamb (+14169386001)**

lol


**453.** `14:46` **You**

Like I said\.\. 2k for studio's


**454.** `14:46` **You**

felt like that one flew past you


**455.** `14:47` **Meredith Lamb (+14169386001)**

No it didn’t


**456.** `14:47` **Meredith Lamb (+14169386001)**

lol


**457.** `14:47` **You**

good


**458.** `14:53` **Meredith Lamb (+14169386001)**

When it started getting messier lol

*📎 1 attachment(s)*

**459.** `14:54` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**460.** `14:55` **You**

and the descent begins


**461.** `14:55` **You**

LOL


**462.** `14:59` **Meredith Lamb (+14169386001)**

You were very conflicted\. Some is hard to read


**463.** `14:59` **You**

:\(


**464.** `14:59` **You**

how so


**465.** `15:00` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**466.** `15:00` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**467.** `15:01` **You**

That isn't conflict


**468.** `15:01` **You**

that was me being honest\.\.


**469.** `15:01` **You**

I had already decided I just needed to figure out how to move forward\.\. not whether I was going to or not\.


**470.** `15:02` **You**

The reconcile comment hit me like a bucket of ice cold water though\.


**471.** `15:02` **You**

when I first read it\.\.


**472.** `15:02` **You**

I didn't read he


**473.** `15:02` **You**

I thought I read I\.


**474.** `15:02` **You**

and I was like WTF did I do\!\!


**475.** `15:06` **Meredith Lamb (+14169386001)**

lol


**476.** `15:06` **Meredith Lamb (+14169386001)**

This thing moves very quickly for sure\. Lightening speed


**477.** `15:06` **Meredith Lamb (+14169386001)**

Ha


**478.** `15:07` **Meredith Lamb (+14169386001)**

You shared your home videos the next weekend


**479.** `15:07` **You**

yeah\.\. when I read he I was fine\.


**480.** `15:08` **You**

because I needed you to understand me\.\. I wanted you to be able to know me\.\. I was trying to give you a complete picture before anything else\.\. I suspected there was a connection\.\. at least from my perspective\.  And I felt like there might be one on your side\.\. but more tentative\.


**481.** `15:08` **You**

I thought showing you who I was would help you decide\.


**482.** `15:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**483.** `15:10` **You**

I remember that\.\.


**484.** `15:11` **You**

my emotions were literally exploding everywhere then\.\. was really hard to remain in control\.


**485.** `15:11` **You**

Reaction: 🙂 from Meredith Lamb
I am surprised I was as in control on our first date lol\.\.


**486.** `15:12` **Meredith Lamb (+14169386001)**

K Mac is home and apparently I can use her Mac but she doesn’t know how to do it


**487.** `15:12` **You**

ask chatgpt


**488.** `15:12` **You**

it will guide you


**489.** `15:12` **Meredith Lamb (+14169386001)**

>
Not sure I was tentative but more cautious

*💬 Reply*

**490.** `15:14` **You**

fair enough \- makes sense\.


**491.** `15:17` **You**

omg I was sooooooo hopeful\.\.\.\.

*💬 Reply*

**492.** `15:18` **Meredith Lamb (+14169386001)**

Omg I was literally laughing out loud

*📎 1 attachment(s)*

**493.** `15:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**494.** `15:19` **You**

mmmm hmmm I like housecoats


**495.** `15:22` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**496.** `15:29` **You**

there was more to that I think


**497.** `15:30` **You**

what did she know\.\.\. now you know what she knew\.

*💬 Reply*

**498.** `15:32` **Meredith Lamb (+14169386001)**

What did who know?


**499.** `15:32` **You**

you wrote back to me what did she know\.\.\.\.\.


**500.** `15:32` **You**

you were commenting on what she said for when nights are long and life is in the pits


**501.** `15:32` **You**

having read her note\.\. you know what she knew


**502.** `15:33` **You**

her sensitive little boy\.\. blech


**503.** `15:33` **Meredith Lamb (+14169386001)**

>
I meant because life was so shitty for both of us\. It was like she knew you were going to go through a divorce\.

*💬 Reply*

**504.** `15:33` **You**

ahhhh


**505.** `15:33` **You**

no she wouldn't have forecasted that


**506.** `15:33` **Meredith Lamb (+14169386001)**

My comment was a joke


**507.** `15:33` **Meredith Lamb (+14169386001)**

>
I know lol

*💬 Reply*

**508.** `15:33` **You**

mmmmm


**509.** `15:33` **You**

actually


**510.** `15:33` **You**

with Jaimie maybe


**511.** `15:34` **You**

she did eventually like J but not at first


**512.** `15:34` **You**

and she never thought we were right for each other


**513.** `15:34` **Meredith Lamb (+14169386001)**

Mac just made me an account on her Mac book


**514.** `15:34` **You**

cool


**515.** `15:34` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**516.** `15:34` **Meredith Lamb (+14169386001)**

Her friend had to show her


**517.** `15:34` **You**

How is her spirit?? ask her for me\.\.?


**518.** `15:35` **You**

hope she is feeling better


**519.** `15:37` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
She said her spirit is great now


**520.** `15:38` **Meredith Lamb (+14169386001)**

It is setting up my account\- this might take me a while so will let you know


**521.** `15:38` **Meredith Lamb (+14169386001)**

lol


**522.** `15:38` **You**

no worries\. I am busy here


**523.** `15:50` **You**


*📎 1 attachment(s)*

**524.** `15:50` **You**

really wierd tool


**525.** `15:50` **You**

called whisk


**526.** `15:50` **You**

It is an image generation tool\.\.\. but it allows you to iterate repeatedly


**527.** `15:51` **You**

I was trying to recreate your cottage family room


**528.** `15:51` **You**

just with words


**529.** `15:51` **Meredith Lamb (+14169386001)**

That corner window is nice


**530.** `15:51` **Meredith Lamb (+14169386001)**

We should have done that lol


**531.** `15:53` **You**


*📎 1 attachment(s)*

**532.** `15:53` **You**

pain in ass


**533.** `15:54` **You**


*📎 1 attachment(s)*

**534.** `15:54` **You**

don my experiment that is too tough to recreate with words


**535.** `15:54` **Meredith Lamb (+14169386001)**

Pretty cool tho


**536.** `15:56` **Meredith Lamb (+14169386001)**

Trying to sync all my messages to my icloud


**537.** `15:57` **You**

lol THOUSANDS\!\!\!\!


**538.** `15:57` **You**

that might take a bit\.


**539.** `15:57` **Meredith Lamb (+14169386001)**

It has done 37,000


**540.** `15:57` **You**

yeah that is likely more than all of my messages combined


**541.** `15:57` **Meredith Lamb (+14169386001)**

I can’t get any of the apps to work


**542.** `15:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**543.** `15:58` **You**

hehe


**544.** `15:58` **You**

not surprised even a little


**545.** `16:22` **Meredith Lamb (+14169386001)**

The apps don’t work and the sync keeps pausing sooooo


**546.** `16:22` **You**

LOL :\(


**547.** `16:22` **Meredith Lamb (+14169386001)**

The imazing app is not free


**548.** `16:22` **Meredith Lamb (+14169386001)**

$70


**549.** `16:22` **You**

no no


**550.** `16:22` **Meredith Lamb (+14169386001)**

I know but that is the one everyone uses I guess


**551.** `16:27` **You**

ok


**552.** `16:27` **You**

Option 2: The "Print to PDF" Workaround \(Free\)
If you don't want to pay for software and only need to save a few important conversations, you can use the Mac's built\-in Print function to create a PDF\. From there, you can extract the text\.
Pros: Free, preserves the visual layout of the conversation\.
Cons: Must be done one conversation at a time, which is very time\-consuming for a large archive\.
Step\-by\-Step Instructions:
Open the Messages app on your Mac\.
Select the single conversation you want to export\.
In the menu bar at the top of the screen, click File > Print\.\.\.
A print dialog box will appear\. In the bottom\-left corner, click the PDF dropdown menu\.
Select Save as PDF\.
Name the file and choose where to save it\. You now have a PDF copy of that conversation\.
To get this into a text file:
Open the newly created PDF file in the Preview app\.
Click and drag to select all the text, or press Cmd \+ A\.
Copy the text \(Cmd \+ C\)\.
Open the TextEdit app, and in the menu bar, select Format > Make Plain Text\.
Paste the text \(Cmd \+ V\) and save your file\.
Note: The formatting \(like who said what\) can be a bit jumbled with this copy\-paste method from a PDF\.


**553.** `16:28` **You**

that should be able to work for every exchange we have ever had\.\.


**554.** `16:28` **Meredith Lamb (+14169386001)**

Well, this is what I will do if I can get the messages synced and on my iCloud, but it’s not happening so


**555.** `16:28` **Meredith Lamb (+14169386001)**

I was never backing up my messages to my iCloud


**556.** `16:28` **Meredith Lamb (+14169386001)**

Just photos


**557.** `16:29` **You**

you are the only one that has access to that account right?


**558.** `16:29` **Meredith Lamb (+14169386001)**

Yeah


**559.** `16:29` **You**

kk when you are done\.\. log out of her comp as well\.


**560.** `16:29` **You**

like out of your apple account


**561.** `16:30` **You**

That is a very common and frustrating problem\. The iCloud sync process can be finicky and often appears to freeze, especially if you have a large message history\.
Let's work through a direct, step\-by\-step troubleshooting process, starting with the simplest fixes\.
\#\#\# \*\*Checklist: The Quick Fixes\*\*
Before doing anything drastic, let's ensure the fundamentals are in place\. These solve the problem more often than you'd think\.
\* \*\*Check Apple's Servers:\*\* First, verify that the issue isn't on Apple's end\. Visit their \[System Status page\]\(https://www\.apple\.com/ca/support/systemstatus/\) and ensure "iCloud Mail" and "Messages" have a green circle\. If they are yellow or red, the only solution is to wait for Apple to fix it\.
\* \*\*Check Your Internet:\*\* The sync requires a stable Wi\-Fi connection on \*\*both\*\* your iPhone and your Mac\. A weak or intermittent signal can cause it to stall\.
\* \*\*Plug Both Devices In:\*\* The sync process is energy\-intensive\. Both iOS and macOS can pause background activities like this to save power\. Plug both your iPhone and your Mac into their chargers\.
\* \*\*Check Your iCloud Storage:\*\* If your iCloud account is full, the sync will fail\.
\* On your iPhone: Go to \*\*Settings > \[Your Name\] > iCloud\*\*\.
\* On your Mac: Go to \*\*System Settings > \[Your Name\] > iCloud\*\*\.
\* If the storage bar is full, you will need to free up space for the sync to complete\.
\* \*\*Be Patient:\*\* How long has it been frozen? If you have years of messages and photos, the initial sync can take many hours, or even overnight\. On your Mac's Messages app, look at the bottom\-left corner\. If it says "Downloading Messages from iCloud\.\.\." it is still working, even if the progress bar hasn't moved\.
\#\#\# \*\*Step 2: The "Forced Nudge"\*\*
If the basics are all good, the next step is to give the system a push to restart the process\.
1\.  \*\*Restart Both Devices:\*\* A simple restart is the most effective troubleshooting step for a reason\.
\* Shut down your Mac and restart it\.
\* Completely power off your iPhone and turn it back on\.
2\.  \*\*Manually Trigger Sync:\*\*
\* On your Mac, open the \*\*Messages\*\* app\.
\* In the menu bar, go to \*\*Messages > Settings > iMessage\*\*\.
\* Click the \*\*"Sync Now"\*\* button\. This should force it to re\-check the sync status\.
\#\#\# \*\*Step 3: The "Hard Reset" of the Sync\*\*
If it's still frozen after a restart, the next step is to toggle the service off and on\. This forces a complete re\-authentication with Apple's servers\.
\*\*Important:\*\* Do these steps in the exact order listed\.
1\.  \*\*On your Mac:\*\*
\* Go to \*\*Messages > Settings > iMessage\*\*\.
\* \*\*Uncheck\*\* the box next to "Enable Messages in iCloud\."
\* Close the Messages app completely \(\`Cmd \+ Q\`\)\.
2\.  \*\*On your iPhone:\*\*
\* Go to \*\*Settings > \[Your Name\] > iCloud\*\*\.
\* Tap \*\*Show All\*\*, then tap \*\*Messages\*\*\.
\* Toggle \*\*OFF\*\* "Sync this iPhone\."
\* A popup will appear\. Choose \*\*"Disable and Download Messages\."\*\* This is safe; it just ensures your messages remain on your phone\.
3\.  \*\*Wait:\*\* Leave both devices like this for at least 10\-15 minutes\.
4\.  \*\*Re\-Enable \(iPhone First\):\*\*
\* On your iPhone, go back to the same setting and toggle \*\*ON\*\* "Sync this iPhone\."
\* Wait for it to finish its initial connection\.
5\.  \*\*Re\-Enable \(Mac Second\):\*\*
\* On your Mac, open Messages and go back to \*\*Messages > Settings > iMessage\*\*\.
\* \*\*Check\*\* the box to "Enable Messages in iCloud" and click \*\*"Sync Now\."\*\*
Now, let the process run again\. It will start from the beginning, but this often clears whatever was causing the freeze\.


**562.** `16:30` **You**

I ended up doing nothing today lol\.\. no packing\.\. spent virtually with you\.\. :\) worth it\.


**563.** `16:31` **Meredith Lamb (+14169386001)**

Same\. Also did nothing lol


**564.** `16:32` **You**

except reminisced


**565.** `16:32` **Meredith Lamb (+14169386001)**

True


**566.** `16:32` **You**

and learned some valuable lessons


**567.** `16:32` **You**

lol


**568.** `16:32` **You**

j/k


**569.** `16:34` **Meredith Lamb (+14169386001)**

🤓


**570.** `16:35` **Meredith Lamb (+14169386001)**

They will likely be forgotten and need to be relearned


**571.** `16:35` **Meredith Lamb (+14169386001)**

Just saying


**572.** `16:35` **Meredith Lamb (+14169386001)**

Setting expectations


**573.** `16:35` **Meredith Lamb (+14169386001)**

lol


**574.** `16:35` **You**

Ouch


**575.** `16:35` **Meredith Lamb (+14169386001)**

I don’t want you to be disappointed


**576.** `16:36` **You**

so by lowering expectations to the bottom I won't be\.\.\. lol


**577.** `16:36` **You**

well I have a counter for you


**578.** `16:37` **Meredith Lamb (+14169386001)**

>
Exactly

*💬 Reply*

**579.** `16:37` **You**

Part of my sharing that was to also share with you some of the outcomes from that kind of sharing\.\. so let me manage your expectations :\)  don't be surprised if I react exactly like chatgpt describes if some of that stuff gets fired my way\. lol


**580.** `16:37` **Meredith Lamb (+14169386001)**

Oh my God, I would never say stuff like that


**581.** `16:38` **Meredith Lamb (+14169386001)**

Drunk or not


**582.** `16:38` **You**

mmmm hmmm


**583.** `16:38` **Meredith Lamb (+14169386001)**

I really don’t think I would say anything like that honestly


**584.** `16:38` **Meredith Lamb (+14169386001)**

That was pretty intense


**585.** `16:38` **You**

not explicitly\.


**586.** `16:38` **You**

I will tell you the last change i made to the prompt,


**587.** `16:39` **You**

because even drunk\.\. you almost never come out straight and say something lol\.\. you infer and suggest without being specific\.


**588.** `16:39` **You**

so I asked it to apply that approach


**589.** `16:40` **You**

so I don't think you would say those things exactly no\.\. but you might infer, suggest or reference\.\. drunk only\.\. hey you were the one that was concerned about stark honesty to begin with\.


**590.** `16:40` **Meredith Lamb (+14169386001)**

Is there something I HAVEN’T answered that bothers you still? Or just in the moment


**591.** `16:41` **You**

what does just in the moment mean?


**592.** `16:41` **Meredith Lamb (+14169386001)**

Does it bother you in the moment and then you forget about it? Like in the moment when we are talking I mean


**593.** `16:42` **You**

I mean it depends on all kinds of things\.\. context for one\.\. are we together or apart etc\.\.  I tend to forget more when we are together\.\. except really stark things LOL\.


**594.** `16:43` **Meredith Lamb (+14169386001)**

Fair enough


**595.** `16:43` **Meredith Lamb (+14169386001)**

lol


**596.** `16:44` **You**

I know what you are digging for\.\. and we aren't going there tonight\. 😝


**597.** `16:44` **You**

Had a good night last night, a good day today\.\. not going to ruin it now\.


**598.** `16:45` **Meredith Lamb (+14169386001)**

I am digging\!


**599.** `16:46` **You**

I know\.\. but some of this shit you don't need or want to know\.\. you have TONS of that kind of stuff you don't want me digging into\.\. so better to maybe not dig?


**600.** `16:46` **Meredith Lamb (+14169386001)**

>
I meant to say, I am not digging sorry

*💬 Reply*

**601.** `16:46` **You**

lol


**602.** `16:46` **Meredith Lamb (+14169386001)**

Honestly, I am not


**603.** `16:47` **You**

>
sorry I must have misread the ALL CAPS rofl\.

*💬 Reply*

**604.** `16:47` **You**

typo probably\.\. oops caps lock


**605.** `16:48` **Meredith Lamb (+14169386001)**

It was a serious question you say I avoid or whatever and I was just curious if there was something that I was avoiding, that was sitting with you happy if not cause I don’t think I avoid regularly


**606.** `16:48` **You**

So you know how I told you many / most people tell white lies\.\.  they learn to do it, it becomes natural and then they don't notice it\.


**607.** `16:50` **You**

That is you with avoid / omit\.\. although I might need to chalk it up to just not reading\.  But yeah you avoid shit all the time\.  About as much as other people tell the little white lies I would say\.  Omit too\.\. like if the question didn't explicitly ask something but it was basic to infer that is what it meant\.\. you will jump through the loop hole and run\.  It's fine\.\. I like chasing most of the time\.


**608.** `16:52` **Meredith Lamb (+14169386001)**

lol


**609.** `16:52` **You**

sometimes I can see you thinking about it


**610.** `16:52` **You**

other times you just do it\.


**611.** `16:53` **Meredith Lamb (+14169386001)**

Maybe you just ask hard questions


**612.** `16:53` **You**

hard or easy\.\.


**613.** `16:53` **Meredith Lamb (+14169386001)**

Ever think about that?


**614.** `16:53` **You**

you look for traps


**615.** `16:53` **You**

best way to characterize


**616.** `16:53` **Meredith Lamb (+14169386001)**

Traps? Lol what?


**617.** `16:53` **Meredith Lamb (+14169386001)**

No


**618.** `16:53` **Meredith Lamb (+14169386001)**

I do not


**619.** `16:53` **You**

yeah you look for traps\.\. I don't know how else to say


**620.** `16:54` **Meredith Lamb (+14169386001)**

You are being goofy now


**621.** `16:54` **You**

I wouldn't say tentative, I would say cautious\.


**622.** `16:54` **Meredith Lamb (+14169386001)**

>
They are different\!

*💬 Reply*

**623.** `16:54` **You**

the distinction there is pretty fine\.\. and that is an innocent one\.\. like nothing but you like to be very specific about some things\.


**624.** `16:54` **You**

but could care less about others


**625.** `16:55` **Meredith Lamb (+14169386001)**

Key Difference:
- Tentative is more about being unsure or not yet decided\.
- Cautious is about being careful and avoiding risk, even if you’re sure of your intent\.


**626.** `16:56` **You**

I already did that


**627.** `16:56` **You**

LOL


**628.** `16:56` **Meredith Lamb (+14169386001)**

lol


**629.** `16:56` **Meredith Lamb (+14169386001)**

The exact difference I meant\!


**630.** `16:56` **Meredith Lamb (+14169386001)**

I wasn’t undecided


**631.** `16:56` **You**

ok ok\.\. it's fine you think what you want\.\. I can only share what I observe


**632.** `16:56` **Meredith Lamb (+14169386001)**

But I was worried about work, your marriage, etc etc etc


**633.** `16:57` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
So cautious 😇


**634.** `16:57` **Meredith Lamb (+14169386001)**

You have to let me win sometimes


**635.** `16:58` **You**

I mean you are right about tentaive and cautious\.\. I can give you that win\.


**636.** `16:59` **Meredith Lamb (+14169386001)**

k thanks 🙂


**637.** `16:59` **You**

np\.\. you earned it\.\.\.


**638.** `17:02` **You**

but on the rest of the stuff I am right\.\. 😝😝


**639.** `17:04` **Meredith Lamb (+14169386001)**

Okay but you may need to prove it at some point\. :\)


**640.** `17:05` **You**

\.\.\.\.\. I will have to find something safe\.


**641.** `17:06` **You**

I mean I did already prove this once


**642.** `17:06` **You**

a while back


**643.** `17:06` **You**

you actually recognized it


**644.** `17:06` **Meredith Lamb (+14169386001)**

Yeah I recall


**645.** `17:06` **You**

ohhhhh


**646.** `17:06` **Meredith Lamb (+14169386001)**

I’m just not sure how regular it is of an occurrence


**647.** `17:06` **You**

now you recall


**648.** `17:06` **You**

LOL


**649.** `17:07` **You**

I just have to update my transcript\.\.


**650.** `17:08` **Meredith Lamb (+14169386001)**

:p


**651.** `17:09` **You**

and done


**652.** `17:09` **You**

that easy


**653.** `17:12` **Meredith Lamb (+14169386001)**

I think I’m going to nap until 6pm\. I’m tired from doing so much today \(lol joke\) \- no, still not 100%


**654.** `17:12` **Meredith Lamb (+14169386001)**

I will ttyl ❤️


**655.** `17:12` **You**

go enjoy your sleep\.\. maybe when you wake up I will have something for you\.


**656.** `17:12` **You**

Love you


**657.** `17:12` **Meredith Lamb (+14169386001)**

Love u too


**658.** `19:14` **Meredith Lamb (+14169386001)**

So it synced apparently but the messages aren’t showing up in the cloud for some reason\. Just looking into it

*📎 1 attachment(s)*

**659.** `19:15` **You**

welcome back to the land of the living


**660.** `19:19` **You**

how was your sleep


**661.** `19:25` **Meredith Lamb (+14169386001)**

I got up at 6\.30


**662.** `19:25` **Meredith Lamb (+14169386001)**

Sleep was good bc I couldn’t this morning so I actually could which was nice


**663.** `19:26` **Meredith Lamb (+14169386001)**

What are you up to


**664.** `19:26` **Meredith Lamb (+14169386001)**

The messages are actually syncing on Mac’s Mac now


**665.** `19:27` **Meredith Lamb (+14169386001)**

Will take a while but I see them coming in


**666.** `19:31` **You**

I am playing


**667.** `19:31` **You**

up to no good


**668.** `19:32` **Meredith Lamb (+14169386001)**

lol ruh roh


**669.** `19:32` **You**

I have your transcript in an llm


**670.** `19:32` **Meredith Lamb (+14169386001)**

Llm?


**671.** `19:34` **You**

Large Language Model


**672.** `19:37` **Meredith Lamb (+14169386001)**

And what have you asked it


**673.** `19:37` **You**

things


**674.** `19:37` **You**

it is kinda clunky not loving it atm might try something else


**675.** `19:38` **Meredith Lamb (+14169386001)**

I don’t even really care what it says\. I’m just more curious what you asked it\. lol


**676.** `20:03` **Meredith Lamb (+14169386001)**

Send to shooter mcgavin email?


**677.** `20:05` **You**

sure


**678.** `20:05` **You**

or paste here


**679.** `20:05` **You**

you can add the file in here I think


**680.** `20:05` **Meredith Lamb (+14169386001)**

It’s on the Mac


**681.** `20:05` **Meredith Lamb (+14169386001)**

I don’t have it on my phone


**682.** `20:06` **Meredith Lamb (+14169386001)**

Are you going to make me email it to myself and then download and then drop here


**683.** `20:06` **Meredith Lamb (+14169386001)**

lol


**684.** `20:06` **You**

you can just email it lol


**685.** `20:06` **You**

sorry


**686.** `20:06` **Meredith Lamb (+14169386001)**

K


**687.** `20:06` **You**

LOL


**688.** `20:06` **Meredith Lamb (+14169386001)**

I didn’t check it to see if it did it right btw


**689.** `20:06` **Meredith Lamb (+14169386001)**

No quality control


**690.** `20:07` **You**

lol


**691.** `20:07` **You**

not up to your typical standards


**692.** `20:09` **You**

I cna make this work :\)


**693.** `20:09` **You**

it does only cover april 10th to 13th though


**694.** `20:09` **You**

fyi


**695.** `20:09` **Meredith Lamb (+14169386001)**

Omg


**696.** `20:09` **Meredith Lamb (+14169386001)**

Why


**697.** `20:09` **You**

I don't know it just does


**698.** `20:09` **Meredith Lamb (+14169386001)**

One sec I will check


**699.** `20:09` **Meredith Lamb (+14169386001)**

Maybe the sync wasn’t done


**700.** `20:11` **Meredith Lamb (+14169386001)**

Looking at the messages and it goes back further, so I might’ve done it too early


**701.** `20:11` **Meredith Lamb (+14169386001)**

So don’t use that one


**702.** `20:20` **You**

There was a massive fight here


**703.** `20:20` **You**

I was not involved


**704.** `20:20` **Meredith Lamb (+14169386001)**

Oh no


**705.** `20:21` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**706.** `20:21` **Meredith Lamb (+14169386001)**

It won’t stop downloading


**707.** `20:22` **You**

so much stuff


**708.** `20:22` **Meredith Lamb (+14169386001)**

Or is it glitching gahhh


**709.** `20:22` **You**

just give it time


**710.** `20:27` **You**

I am not sure what happened\.\. but I think Gracie said something about maddie lying about being sexually assaulted for attention\.\. I don't even know how that happens\.\.\. but I am staying the fuck down here\.


**711.** `20:28` **Meredith Lamb (+14169386001)**

Oh that’s pretty brutal, low\.


**712.** `20:28` **You**

yeah\.\. Jaimie lost her fucking shit\.\.


**713.** `20:29` **You**

ironically\.\. this was something I raised to Jaimie earlier when she tried to defend gracie


**714.** `20:29` **You**

I think I told you so would be bad


**715.** `20:29` **Meredith Lamb (+14169386001)**

Very bad\!\! Don’t say that lol


**716.** `20:29` **You**

But I feel like I should


**717.** `20:29` **You**

It might diffuse the situation


**718.** `20:30` **Meredith Lamb (+14169386001)**

Omg no


**719.** `20:31` **Meredith Lamb (+14169386001)**

393 pages


**720.** `20:31` **You**

HAHAHA


**721.** `20:31` **Meredith Lamb (+14169386001)**

Taking forever to save


**722.** `20:31` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**723.** `20:34` **You**

fun excercise


**724.** `20:34` **You**

but once it is done and I extract I will send everything back to you


**725.** `20:36` **Meredith Lamb (+14169386001)**

It is 244mb hmmmh


**726.** `20:36` **You**

holy shit\.\.


**727.** `20:36` **You**

it is because of all the images in it too


**728.** `20:37` **Meredith Lamb (+14169386001)**

Didn’t download the images though


**729.** `20:37` **You**

just the pages as images then\.


**730.** `20:38` **Meredith Lamb (+14169386001)**

It sent as a Google doc link


**731.** `20:39` **Meredith Lamb (+14169386001)**

When you have it I’m deleting it off of my Google drive


**732.** `20:39` **You**

I have it


**733.** `20:39` **You**

did you buy that thing or did you print to pdf


**734.** `20:40` **Meredith Lamb (+14169386001)**

Print to pdf


**735.** `20:42` **You**

kk good


**736.** `20:47` **You**

How are you feeling?


**737.** `20:47` **Meredith Lamb (+14169386001)**

Better now that that is done 🙃


**738.** `20:47` **You**

well I mean health wise\.\. I am sure the wine must be helping tonight


**739.** `20:51` **Meredith Lamb (+14169386001)**

I am not drinking tonight


**740.** `20:51` **Meredith Lamb (+14169386001)**

I have to be in good shape tomorrow for my parents


**741.** `20:51` **You**

:\)


**742.** `20:51` **You**

I hope you have a lot of fun\.


**743.** `20:52` **Meredith Lamb (+14169386001)**

Meh it will be fine


**744.** `20:52` **Meredith Lamb (+14169386001)**

lol


**745.** `20:53` **You**

eesh\.\. all of my heartfelt thoughts\.\. kicked to the curb\.\. LOL I hope you have a mediocre slightly lackluster time, that you really are just barely able to tolerate\.


**746.** `20:53` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
Thank you\.

*💬 Reply*

**747.** `20:54` **You**

That's how much I love you right there\!\!@


**748.** `20:54` **Meredith Lamb (+14169386001)**

So your “transcript” is going to be massive now


**749.** `20:54` **Meredith Lamb (+14169386001)**

How many pages?


**750.** `20:54` **You**

well it needs to be broken in 2


**751.** `20:54` **You**

I won't be able to join them


**752.** `20:55` **Meredith Lamb (+14169386001)**

Why not


**753.** `20:55` **You**

hmm maybe I can


**754.** `20:55` **You**

let me see


**755.** `20:56` **Meredith Lamb (+14169386001)**

But it would be way too large for any ai to mine … no?


**756.** `20:57` **You**

let me show you what I am doing


**757.** `20:58` **You**

\# Sunday, April 13, 2025
\#\#\# Daily Summary
\- Keywords: scott hicks, the house, 13 apr, meredith lamb, the idea
\- Entities: 13 \(CARDINAL\), 2025 \(DATE\), Scott Hicks \(PERSON\), tonight \(TIME\), Meredith Lamb \(PERSON\)
\- Messages: 227
\-\-\-
\#\# 20:48:54 — Scott
\#\# 20:53:33 — Scott
\#\# 20:53:44 — Meredith Lamb
\#\# 20:53:51 — Scott
\#\# 20:53:56 — Scott
\#\# 20:54:01 — Scott
\#\# 20:54:03 — Scott
\#\# 20:54:17 — Meredith Lamb
\#\# 20:54:30 — Scott
I am soooopo bad
\#\# 20:54:35 — Scott
\#\# 20:54:54 — Meredith Lamb
\#\# 20:55:00 — Scott
\#\# 20:55:29 — Meredith Lamb
\#\# 20:56:07 — Meredith Lamb
\#\# 20:56:11 — Scott
As
Well
I\. Your profile settings
\#\# 20:56:15 — Scott
\#\# 20:56:26 — Meredith Lamb
\#\# 20:56:38 — Meredith Lamb
\#\# 20:56:53 — Meredith Lamb
\#\# 20:57:01 — Meredith Lamb
\#\# 20:57:19 — Scott
\#\# 20:57:27 — Scott
\#\# 20:57:32 — Meredith Lamb
\#\# 20:57:33 — Scott
\#\# 20:57:45 — Meredith Lamb
\#\# 20:57:58 — Scott
To do it for
You
\#\# 20:58:03 — Scott
\#\# 20:58:11 — Meredith Lamb
\#\# 20:58:29 — Meredith Lamb
\#\# 20:58:38 — Meredith Lamb
\#\# 20:58:41 — Meredith Lamb
\#\# 20:58:52 — Scott
\#\# 20:59:10 — Meredith Lamb
\#\# 20:59:25 — Scott
\#\# 20:59:32 — Meredith Lamb

*💬 Reply*

**758.** `20:58` **You**

I reformatted the text I get into something a bit more readable


**759.** `20:58` **You**

I also broke out all of the files into days\.


**760.** `20:59` **You**

So I can take these and put them on a Google drive


**761.** `20:59` **You**

and then gemini can access them all from there


**762.** `21:01` **You**

now I am ocr'ing your doc


**763.** `21:02` **Meredith Lamb (+14169386001)**

Ocr


**764.** `21:02` **You**

Optical Character Recognition


**765.** `21:02` **You**

basically it identifies text in pictures


**766.** `21:02` **You**

that is step 1


**767.** `21:02` **You**

of a few


**768.** `21:03` **Meredith Lamb (+14169386001)**

You are hardcore\.


**769.** `21:03` **You**

no\.\. not really\.\. I am too distracted to be hardcore


**770.** `21:04` **You**

brb need food


**771.** `21:04` **Meredith Lamb (+14169386001)**

I’m going to shower


**772.** `21:14` **You**

kk let me think about that for a bit\.\.  you know\.\. I can help you do that sometime\.\.\. I kind of expected an invitation and none was forthcoming\. 😭


**773.** `21:22` **Meredith Lamb (+14169386001)**

lol


**774.** `21:23` **Meredith Lamb (+14169386001)**

Eventually maybe?


**775.** `21:23` **Meredith Lamb (+14169386001)**

\(Did you like the maybe on the end?\)


**776.** `21:23` **You**

mmmm\.\.\. I just think you would be missing out on fun time\.\. your call\.


**777.** `21:27` **You**

fun time does seem like a while ago now that I think about it


**778.** `21:27` **You**

eesh


**779.** `21:27` **Meredith Lamb (+14169386001)**

I get that \- very much do\.\. speaking of insecurities, I honestly have never “dated” at this weight before so I’m still navigating it\. It is just very different and I’m being patient with myself\.


**780.** `21:28` **Meredith Lamb (+14169386001)**

>
Feels like forever

*💬 Reply*

**781.** `21:28` **Meredith Lamb (+14169386001)**

Which is weird bc it wasn’t


**782.** `21:28` **You**

I love every bit of you\.\. maybe you should relax more\.\. and let me do more of that\.


**783.** `21:28` **Meredith Lamb (+14169386001)**

Yeah yeah yeah, I get it I get it\. It is just a real thing that is different\.


**784.** `21:28` **You**

>
because i have let down my guard re my insecurities :\)

*💬 Reply*

**785.** `21:30` **Meredith Lamb (+14169386001)**

I know you have big time and I really value that and admire your ability to do so\. I am not so vulnerable in the way you can be


**786.** `21:31` **You**

>
you should be\.\. you are amazing just the way you are\.\. never doubt I feel that way\.  Actions are supposed to speak louder right\.\.  I think mine have spoken a few times\.\. seriously Mer give yourself a break\.

*💬 Reply*

**787.** `21:33` **Meredith Lamb (+14169386001)**

It is not something that is keeping me up at night\. It is just there\.


**788.** `21:34` **You**

ok\.\. well if it bothers just tell me how to stay within my lane\.\. and I will be happy to try to make you more comfortable\.


**789.** `21:35` **Meredith Lamb (+14169386001)**

Stay within your lane lol


**790.** `21:35` **Meredith Lamb (+14169386001)**

Huh


**791.** `21:35` **You**

I mean don't do things that make you feel uncomfortable\.


**792.** `21:35` **Meredith Lamb (+14169386001)**

Ahhhh


**793.** `21:35` **Meredith Lamb (+14169386001)**

You don’t do that


**794.** `21:36` **Meredith Lamb (+14169386001)**

I don’t think I’d be uncomfortable with you but it has been like a short time so I’m still getting used to things yunnno


**795.** `21:38` **You**

I think I know\.\. but I am not sure\.\. lol so sure\.\. let's just say I do


**796.** `21:38` **Meredith Lamb (+14169386001)**

Haha


**797.** `21:39` **You**

I mean let's say there have been kind of some guidelines I am supposed to stay within


**798.** `21:39` **You**

so if those were to relax then sure more things to get used to


**799.** `21:39` **You**

maybe?


**800.** `21:39` **You**

lol


**801.** `21:39` **You**

trying here\.\. rofl


**802.** `21:41` **You**

you ok there


**803.** `21:41` **You**

a lot of typing or deleting or both or start stopping


**804.** `21:42` **Meredith Lamb (+14169386001)**

It’s pretty simple\. I have a complicated relationship with my weight like most women \(many factors contribute to it obviously\) but in my 20s/30s it wasn’t a thing as much\. Since kids it has always been a thing… when you are with someone throughout all that, it is less of a thing\. Then all of a sudden you are split up and with someone and it is just a consideration to navigate that wasn’t AS much there before in the past\.
All that to say, I am figuring it out and will be fine


**805.** `21:42` **Meredith Lamb (+14169386001)**

lol


**806.** `21:43` **Meredith Lamb (+14169386001)**

But shower…\. Right now…\. Feels uh …\.\. uncomfortable for sure


**807.** `21:43` **You**

kk but it didn't bother you and then it did?


**808.** `21:43` **Meredith Lamb (+14169386001)**

>
Didn’t bother me when?

*💬 Reply*

**809.** `21:43` **You**

just because it is me\.\. there is nothing daunting over here\.\. lol


**810.** `21:44` **You**

it didn't bother you previously\. as in let's say last year


**811.** `21:44` **Meredith Lamb (+14169386001)**

Oh no for sure it did like last year the year before


**812.** `21:44` **You**

:\(


**813.** `21:44` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Sat, 14 Jun 2025 21:45:27 \-0400
|
| Honestly, the first day at Enbridge I was super paranoid because I was like 30 to 40 pounds heavier than when I left union and I thought everyone was gonna notice
|
| Version: 1
| Sent: Sat, 14 Jun 2025 21:44:34 \-0400
|
| Honestly, the first day at Embridge I was super paranoid because I was like 3040 pounds heavier than when I left union and I thought everyone was gonna notice


**814.** `21:44` **You**

ok\.\. well I hope you get comfortable\.


**815.** `21:44` **Meredith Lamb (+14169386001)**

Then Allison is like “you look exactly the same you haven’t changed”


**816.** `21:44` **Meredith Lamb (+14169386001)**

LOL


**817.** `21:45` **Meredith Lamb (+14169386001)**

>
I mean, I’m semi\-comfortable\. I’m just not fully comfortable\.

*💬 Reply*

**818.** `21:46` **You**

you and your qualifying statements\.\.\.\.\.\.


**819.** `21:46` **You**

well I am not not somewhat comfortable\.


**820.** `21:46` **Meredith Lamb (+14169386001)**

But I am semi\-comfortable\!


**821.** `21:46` **You**

maybe


**822.** `21:46` **You**

sometimes


**823.** `21:47` **Meredith Lamb (+14169386001)**

Like comfortable with some things but not others


**824.** `21:47` **Meredith Lamb (+14169386001)**

Listen, I will get there


**825.** `21:47` **You**

Reaction: 😂 from Meredith Lamb
you smashed right through my semi comfort


**826.** `21:47` **You**

you were like psssh\.\.\. ignored


**827.** `21:47` **Meredith Lamb (+14169386001)**

LOL


**828.** `21:47` **Meredith Lamb (+14169386001)**

It is funny because it is true


**829.** `21:48` **You**

I know\.\.\.\. but one barrier down\.\. not sure how many to go\.\. we will have to see\.\. cause well that was probably my biggest uncomfort zone\.


**830.** `21:48` **Meredith Lamb (+14169386001)**

I think you like to be challenged lol


**831.** `21:48` **You**

mmmm  I like to be engaged\.


**832.** `21:49` **You**

not so much a contest\.\. against one another\.\.


**833.** `21:49` **Meredith Lamb (+14169386001)**

Not fun sometimes?


**834.** `21:49` **Meredith Lamb (+14169386001)**

lol


**835.** `21:49` **You**

well honestly never tried it\.\.


**836.** `21:49` **You**

so sure we can have a go sometime


**837.** `21:49` **Meredith Lamb (+14169386001)**

Haha


**838.** `21:50` **Meredith Lamb (+14169386001)**

How open of you


**839.** `21:50` **You**

if we are being competitive\.\. I would say I am more open than you atm\.


**840.** `21:50` **You**

and I don't think you were ready for that\.


**841.** `21:51` **Meredith Lamb (+14169386001)**

I know, well it is like you got permission and then you just wanted to go full force in one day


**842.** `21:51` **Meredith Lamb (+14169386001)**

That wasn’t really what I meant when I raised it lol


**843.** `21:51` **You**

I mean a\) permission \- more like a request\.\. b\) that wasn't even close to full force


**844.** `21:51` **Meredith Lamb (+14169386001)**

And honestly I don’t mind


**845.** `21:52` **You**

but we can slow it way down if you want


**846.** `21:52` **You**

like turtle speed


**847.** `21:52` **Meredith Lamb (+14169386001)**

Well the request was like some sort of permission really in the end


**848.** `21:52` **Meredith Lamb (+14169386001)**

>
Stop

*💬 Reply*

**849.** `21:52` **You**

ummmmmmmmmmmmmmmmmmm


**850.** `21:53` **Meredith Lamb (+14169386001)**

Just because I’m not doing things doesn’t mean I’m not thinking about them\.


**851.** `21:53` **Meredith Lamb (+14169386001)**

I just don’t need to do everything all at once lol


**852.** `21:53` **Meredith Lamb (+14169386001)**

Not sure if that makes sense


**853.** `21:54` **You**

Reaction: 🙃 from Scott Hicks
I mean no really I might be onto something\.\. like if we really really slow it down\.\. like to kind of hold hands and no tongue\.\. well that could be great for anticipations right??


**854.** `21:55` **Meredith Lamb (+14169386001)**

I don’t think we have issues with anticipation


**855.** `21:55` **Meredith Lamb (+14169386001)**

I feel like that is the LAST issue we have


**856.** `21:55` **Meredith Lamb (+14169386001)**

If there was a list


**857.** `21:55` **You**

Reaction: 🤔 from Meredith Lamb
but it might make it better\.


**858.** `21:55` **Meredith Lamb (+14169386001)**

Bottom of list


**859.** `21:56` **Meredith Lamb (+14169386001)**

Do you think we need to make it better?


**860.** `21:57` **Meredith Lamb (+14169386001)**

What are you saying?


**861.** `21:57` **Meredith Lamb (+14169386001)**

lol


**862.** `21:57` **You**

rofl


**863.** `21:57` **You**

absolutely nothing I was waiting for you to agree with me, and then backpeddle


**864.** `21:58` **Meredith Lamb (+14169386001)**

Not agreeing …\.


**865.** `21:58` **Meredith Lamb (+14169386001)**

Maybe you are drinking tonight


**866.** `21:59` **You**

nope


**867.** `21:59` **You**

honestly goofing around thinking of you\. Always thinking of angles on how to see you more\.


**868.** `22:00` **Meredith Lamb (+14169386001)**

You are talented at that… seriously


**869.** `22:00` **You**

are you taking an sdo friday?


**870.** `22:01` **You**

nm


**871.** `22:01` **You**

I forgot friday is work from home no reason to be out of house


**872.** `22:02` **You**

errrrrmmmmm


**873.** `22:02` **Meredith Lamb (+14169386001)**

This Friday?


**874.** `22:02` **You**

yeah it won't work\.\.


**875.** `22:02` **Meredith Lamb (+14169386001)**

I was going to work yeah


**876.** `22:02` **You**

Sat\- could try a repeat of last Sat and then parents\.\. but not sure scheudle


**877.** `22:02` **You**

for vball


**878.** `22:04` **Meredith Lamb (+14169386001)**

I’m so bad at planning like I haven’t even told anyone about Saturday next Saturday


**879.** `22:04` **Meredith Lamb (+14169386001)**

It will be fine though if I’m not here


**880.** `22:05` **You**

mmm\.\. yeah I am just trying to think can we get the day\.\. or just the afternoon\.\. you think about it let me know or we can revisit


**881.** `22:06` **Meredith Lamb (+14169386001)**

k I’m sure I can be gone for the day easily\. I use my parents’ health…


**882.** `22:06` **Meredith Lamb (+14169386001)**

My family knows right now so they understand


**883.** `22:07` **You**

ok then the idea would be a repeat of last saturday with us going to your parents after\.\. except you would get there at 10 maybe?


**884.** `22:07` **You**

🤪


**885.** `22:08` **You**

or whenever lol


**886.** `22:08` **Meredith Lamb (+14169386001)**

Har har


**887.** `22:10` **Meredith Lamb (+14169386001)**

I feel bad you having to do all the booking/$ …\. I could not book something like this right now\. But I could give you $


**888.** `22:13` **You**

ROFL\.\. make up for it later if it makes you feel better\.\. I don't care\.\. honestly using fun money I won't have it forever hehe


**889.** `22:13` **You**

you get lunch


**890.** `22:13` **You**

there that is something :\)


**891.** `22:14` **Meredith Lamb (+14169386001)**

Pretty minimal :p


**892.** `22:14` **You**

fine you decide how and when


**893.** `22:14` **Meredith Lamb (+14169386001)**

How and when to give you $? Ok :\)


**894.** `22:15` **You**

how and when you do whatever I dun care\.\. :\)


**895.** `22:16` **Meredith Lamb (+14169386001)**

k


**896.** `22:18` **You**

I just mean it isn't really important to me\.\. you know someday\.\. we can kind of get on the same page\.\. and some other time\.\. if you want to take me out\.\. I am all for it\.\. but I don't keep score :\)


**897.** `22:19` **You**

but if it is easier for this to happen this way, and I am able to accommodate\.\. then hell fucking yeah I am going to and keep going to\.\. because worth\.


**898.** `22:23` **Meredith Lamb (+14169386001)**

Well I do appreciate it and all the effort you put in but I’d just like to pay half\. We don’t have to talk about it anymore though \- I will figure it out\. :\)


**899.** `22:23` **You**

>
now I am not going to tell you\.

*💬 Reply*

**900.** `22:23` **You**

so there


**901.** `22:24` **Meredith Lamb (+14169386001)**

🙄


**902.** `22:27` **You**

shiiiiit


**903.** `22:27` **You**

I thought I had less on there


**904.** `22:27` **You**

rofl


**905.** `22:27` **You**

fun money balance = $9480\.24


**906.** `22:29` **Meredith Lamb (+14169386001)**

Crazy


**907.** `22:29` **You**

I worked hard for all the Stellar Love\.\.


**908.** `22:30` **You**

so maybe you don't worry so much :\)


**909.** `22:31` **Meredith Lamb (+14169386001)**

I’m not worried, but I’d like to be fair


**910.** `22:32` **You**

ok Mer


**911.** `22:34` **You**

maybe try a different place next time


**912.** `22:37` **Meredith Lamb (+14169386001)**

So you never told me what you were asking ai about your transcript earlier when it was “clunky”


**913.** `22:38` **You**

I was asking it to consider the conversation\.\. consider the questions being asked, and the answers being given or not given\.  Consider literally and inferentially what someone might be looking for versus receiving\.


**914.** `22:38` **You**

Consider the responses and whether or not they are directly related, not related at all, or vague in general\.


**915.** `22:44` **Meredith Lamb (+14169386001)**

And it wasn’t helpful?


**916.** `22:44` **You**

holy shit


**917.** `22:45` **You**

well notebook lm is interesting'


**918.** `22:45` **You**

now that I reorganized all the content


**919.** `22:46` **You**

this is insane


**920.** `22:47` **Meredith Lamb (+14169386001)**

And you are going to share what is “interesting”


**921.** `22:47` **You**

I can't really you need to see it


**922.** `22:47` **You**

sec


**923.** `22:49` **You**

do you have chrome on your phone


**924.** `22:52` **Meredith Lamb (+14169386001)**

No


**925.** `22:53` **Meredith Lamb (+14169386001)**

Oh yeah, I do for the kids school\. I just never use it anymore\.


**926.** `22:53` **You**

Chrome Remote Desktop


**927.** `22:53` **You**

download that


**928.** `22:54` **You**

then if you get that doine in 3 mins\.\. there should be a place where it says connect to another computer


**929.** `22:54` **You**

182790557392 that is your connect code


**930.** `22:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**931.** `22:55` **Meredith Lamb (+14169386001)**

I’m too tired to go to a laptop


**932.** `22:56` **You**

ok


**933.** `22:56` **You**

one last try


**934.** `22:56` **You**

download skype lol


**935.** `22:56` **You**

nm


**936.** `22:56` **You**

FACK


**937.** `22:56` **You**

do you have teams on your phone>?


**938.** `22:57` **You**

you can use it with a personal email account\.


**939.** `22:58` **Meredith Lamb (+14169386001)**

Nooo I do not


**940.** `22:58` **Meredith Lamb (+14169386001)**

I have zoom


**941.** `23:00` **You**

what email address for that zoom


**942.** `23:00` **Meredith Lamb (+14169386001)**

My only one lamberrymer@gmail\.com


**943.** `23:01` **You**

Shooter McGavvvin is inviting you to a scheduled Zoom meeting\.
Topic: My Meeting
Time: Jun 14, 2025 11:00 PM Montreal
Join Zoom Meeting
https://us05web\.zoom\.us/j/2884409337?pwd=djOOiFsIzIF9qq3TfXmBaDUjfIgRTL\.1&omn=88437701347
Meeting ID: 288 440 9337
Passcode: C0V3p0


**944.** `23:05` **You**

I wasn't going to talk because I didn't want tyo get you in trouvle


**945.** `23:07` **You**

i figured full house tonight\.\. and little shadow always around


**946.** `23:08` **You**

I am not supposed to be hearing you right


**947.** `23:08` **Meredith Lamb (+14169386001)**

Can you hear me


**948.** `23:09` **You**

no just sec


**949.** `23:29` **Meredith Lamb (+14169386001)**

Someone coming upstairs\. Sec


**950.** `23:29` **Meredith Lamb (+14169386001)**

Andrew


**951.** `23:29` **Meredith Lamb (+14169386001)**

:p


**952.** `23:29` **You**

figured


**953.** `23:30` **You**

that is why i was quiet\.\. not like you\.\. HEY MEREDITH WHAT'S GOING ON\!\!\!\!


**954.** `23:31` **You**

I assume he is still there you are still muted etc


**955.** `23:31` **Meredith Lamb (+14169386001)**

lol I turned my volume down even if you weren’t quiet


**956.** `23:37` **You**

night❤️❤️❤️❤️


**957.** `23:37` **Meredith Lamb (+14169386001)**

Nite \- behave please ❤️


**958.** `23:37` **You**

Reaction: ❤️ from Meredith Lamb
I mean\.\. how could I not behave


