# Daily Conversation: 2025-04-24 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-24 |
| **Day** | Thursday |
| **Week** | 2 |
| **Messages** | 523 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-24T00:00 - 2025-04-24T23:40 |

## 📝 Daily Summary

This day contains **523 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

lol


**002.** `00:00` **You**

of course not\.\. but it is saved


**003.** `00:00` **Meredith Lamb (+14169386001)**

Let’s just not fully plan out Detroit


**004.** `00:00` **Meredith Lamb (+14169386001)**

Could you handle that?


**005.** `00:00` **Meredith Lamb (+14169386001)**

lol


**006.** `00:00` **Meredith Lamb (+14169386001)**

Just don’t plan


**007.** `00:00` **You**

I am glad we didn't either\.\. car would have been uncomfortable


**008.** `00:01` **You**

and more rug burns


**009.** `00:01` **You**

in all kinds of ouchy spots


**010.** `00:01` **You**

no


**011.** `00:01` **You**

I am not planning detroit at all \- but I would like to have breakfast with you\.\. and maybe go for a walk if we could manage it\.


**012.** `00:02` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I think we can manage that :\)


**013.** `00:02` **You**

and I won't plan anything else I promise


**014.** `00:02` **Meredith Lamb (+14169386001)**

k good


**015.** `00:04` **Meredith Lamb (+14169386001)**

Honestly I just want to be in room with you and actually feel you lol work is painful


**016.** `00:05` **Meredith Lamb (+14169386001)**

I’m sure the rest will work out


**017.** `00:05` **You**

hmm\.\. yeah nothing comes to mind\.\. not that wouldn't be suspicious\.


**018.** `00:05` **You**

lol


**019.** `00:08` **Meredith Lamb (+14169386001)**

I meant a room in Detroit


**020.** `00:08` **You**

oh yeah\.\.\. and Chatham and wherever the hell else I can find a room\.


**021.** `00:08` **You**

my room shortly\.\. because damn I have to get out of here\.


**022.** `00:09` **Meredith Lamb (+14169386001)**

Doesn’t seem like things will turnaround there?


**023.** `00:09` **Meredith Lamb (+14169386001)**

Just getting worse?


**024.** `00:09` **You**

yep


**025.** `00:09` **You**

Reaction: 😢 from Meredith Lamb
Gracie is an absolute mess\.


**026.** `00:10` **Meredith Lamb (+14169386001)**

Hmm not sure how my kids will react fully …


**027.** `00:10` **You**

in all honesty she should have been admitted last year I think\.\. she has done real damage to herself and the house


**028.** `00:10` **You**

But J wouldn't allow it then she went on leave and sat for 6 months reading romance novels whyl Gracie went bananas


**029.** `00:10` **You**

like\.\. this is crazy


**030.** `00:11` **Meredith Lamb (+14169386001)**

Oh yikes


**031.** `00:11` **You**

I tried to get her into the whitby mental hospital behind my house\.\. it is a brilliant place and they do amazing things, but there is a massive wait list


**032.** `00:11` **You**

and honestly the only way to get her in there sooner is to admit her to the psyche ward\.\. and I won't do that\.


**033.** `00:11` **Meredith Lamb (+14169386001)**

Crap\.


**034.** `00:11` **You**

yeah it is a mess


**035.** `00:12` **Meredith Lamb (+14169386001)**

Leslie had a similar issue with miles


**036.** `00:12` **Meredith Lamb (+14169386001)**

She started taking him to emerg bc there was nowhere else


**037.** `00:12` **You**

that sucks


**038.** `00:14` **You**

is andrew leaving you alone now I hope


**039.** `00:14` **Meredith Lamb (+14169386001)**

Yeah


**040.** `00:14` **You**

good


**041.** `00:14` **Meredith Lamb (+14169386001)**

He always rolls his eyes and leaves


**042.** `00:14` **You**

I thought that was bad and offesnive and disrespectfuil


**043.** `00:14` **Meredith Lamb (+14169386001)**

I have to ask like 5x always lol


**044.** `00:15` **Meredith Lamb (+14169386001)**

His style


**045.** `00:15` **Meredith Lamb (+14169386001)**

Does it to the kids sometimes too


**046.** `00:15` **You**

no you said he criticized you of that


**047.** `00:15` **You**

the eye roll


**048.** `00:15` **You**

lol


**049.** `00:15` **Meredith Lamb (+14169386001)**

Oh yeah lol\!


**050.** `00:15` **You**

see


**051.** `00:15` **You**

memory


**052.** `00:15` **Meredith Lamb (+14169386001)**

He might just sigh


**053.** `00:15` **Meredith Lamb (+14169386001)**

It seems like an eye roll but not 100%


**054.** `00:15` **Meredith Lamb (+14169386001)**

Haha


**055.** `00:16` **Meredith Lamb (+14169386001)**

I think I’m going to go to bed\.


**056.** `00:16` **Meredith Lamb (+14169386001)**

Funny thing is that I was going to go to bed early tonight


**057.** `00:16` **You**

good\.\. I am just trying to put together a doc for J for the morning\.


**058.** `00:16` **You**

I am sorry you were kept up and berated


**059.** `00:17` **Meredith Lamb (+14169386001)**

We have to go through these stupid discussions\. As painful as they are\.


**060.** `00:18` **You**

I think he is being really unfair\.\.\.\. I am literally shocked\.\.


**061.** `00:18` **Meredith Lamb (+14169386001)**

You shouldn’t stay up too late


**062.** `00:18` **You**

I wont


**063.** `00:18` **You**

I will still be up early\.


**064.** `00:18` **Meredith Lamb (+14169386001)**

>
Literally shocked? Have you not been listening to me? Lol

*💬 Reply*

**065.** `00:18` **Meredith Lamb (+14169386001)**

Kidding


**066.** `00:18` **Meredith Lamb (+14169386001)**

It really isn’t shocking


**067.** `00:19` **Meredith Lamb (+14169386001)**

\(If you knew him\.\)


**068.** `00:19` **You**

I mean\.\. I keep flipping and flopping from being humble to breaking his hand\.\.


**069.** `00:19` **You**

I am still up in the air


**070.** `00:20` **Meredith Lamb (+14169386001)**

Maybe you never meet\. ;\)


**071.** `00:20` **You**

I will take my queue from you\.\. there can be a sign\.\. you get to make the call\.


**072.** `00:20` **Meredith Lamb (+14169386001)**

We will be pleasant\.


**073.** `00:20` **Meredith Lamb (+14169386001)**

I am generally pleasant\.


**074.** `00:20` **Meredith Lamb (+14169386001)**

lol


**075.** `00:20` **Meredith Lamb (+14169386001)**

Generally


**076.** `00:20` **You**

I was going to ask earlier


**077.** `00:20` **You**

What does a Meredith black rage laugh look like\.\.


**078.** `00:21` **You**

because I assume you laughed evilly


**079.** `00:21` **Meredith Lamb (+14169386001)**

I go completely silent I have learned


**080.** `00:21` **Meredith Lamb (+14169386001)**

Honestly just have no words and the world pauses for a minute


**081.** `00:22` **You**

man\.\. I will never make you feel anything like that\.


**082.** `00:22` **You**

maybe mild annoyance\.


**083.** `00:22` **Meredith Lamb (+14169386001)**

Mild lol


**084.** `00:22` **You**

lightly annoyed


**085.** `00:22` **You**

kk I love you I would keep talking to you all night but you should sleep hon\.


**086.** `00:23` **You**

we can look at each other tomorrow and do nothing\.\.


**087.** `00:23` **You**

looking forward to it


**088.** `00:23` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Yeah I look forward to that\. 🙄 it’s so never ending……


**089.** `00:23` **Meredith Lamb (+14169386001)**

Nite I love you too


**090.** `00:23` **You**

xox


**091.** `01:18` **You**

Suggestion quiet park out of the way morning hug into work\.  Maybe a kiss\.  Suggesting parkway forest park\.\. feel free to decline\.\. I will always keep trying :\) luv you


**092.** `06:54` **You**

Boo you won’t have checked this until too late\.\. another park rendezvous missed\. Oh the sadness\!


**093.** `06:55` **You**

Reaction: 😵‍💫 from Meredith Lamb
Guess I will just go by myself maybe I will meet a kind stranger\.


**094.** `07:05` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Ugh I’m so tiiiireed\. Slept through my alarm\. :\(


**095.** `07:06` **You**

Don’t worry I didn’t invite j for a friendly forest walk\.


**096.** `07:06` **You**

I did not 🥰


**097.** `07:07` **You**

Reaction: ❤️ from Meredith Lamb
Dreamt about you all night


**098.** `07:07` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**099.** `07:08` **Meredith Lamb (+14169386001)**

Great question\.
The 10\-year spousal support duration I used earlier is based on a common interpretation of the Spousal Support Advisory Guidelines \(SSAGs\) and your situation—but I’ll walk you through exactly why that figure is reasonable, and when it might be shorter, longer, or even indefinite\.
⸻
SSAG Duration Guidelines for Spousal Support
For long relationships like yours \(15 years\), there are three duration pathways under the SSAGs:
⸻
1\. Rule of 20
If the relationship lasted 20 years or more → Indefinite support
Does not apply here—your relationship was 15 years\.
⸻
2\. Rule of 65
If length of relationship \+ recipient’s age at separation = 65 or more
→ Indefinite support
You didn’t mention your age\. If you’re, say, 50 or older, this might apply\. For example:
- 50 years old \+ 15 years = 65 → You could qualify for indefinite support under Rule of 65\.
⸻
3\. Without Rule of 20 or 65: Use the Standard Duration Range
For relationships under 20 years, but not short\-term, the SSAGs suggest:
0\.5 to 1 year of spousal support per year of cohabitation
So for your 15\-year common law relationship:
- Minimum duration: 7\.5 years
- Maximum duration: 15 years
⸻
Why I Used 10 Years
I chose 10 years as a midpoint for modeling purposes because:
- It falls squarely within the guideline range
- You have three children, suggesting a more “family\-centered” marriage
- You took 5 years off work, strengthening your compensatory claim
- A 10\-year horizon is often used by lawyers for present value calculations when negotiating lump\-sum buyouts
- It’s a pragmatic middle ground if indefinite support doesn’t apply but long\-term support is clearly warranted
⸻
It Could Be Longer or Indefinite If:
- You’re near or over age 50 \(Rule of 65\)
- You face barriers to full earning recovery after taking 5 years off
- The settlement is reviewed in court and a judge finds your financial disadvantage ongoing
⸻
It Could Be Shorter If:
- You initiated the separation and are economically secure
- You agreed voluntarily \(with legal advice\) to a clean break for a lump sum
- There’s a clear plan for financial self\-sufficiency within a few years


**100.** `07:08` **Meredith Lamb (+14169386001)**

Not sure what I would do without ChatGPT


**101.** `07:09` **You**

I know 😊


**102.** `07:22` **You**

Eesh super aggressive driving this morning


**103.** `07:22` **You**

Reaction: 😂 from Meredith Lamb
Mistake butt dial


**104.** `07:31` **Meredith Lamb (+14169386001)**

So he’s very disappointed I\. Our expenses analysis he did last night lol


**105.** `07:32` **Meredith Lamb (+14169386001)**

He said we shouldn’t take it into account bc we will have to cut back


**106.** `07:32` **Meredith Lamb (+14169386001)**

I was like obviously we will cut back but that is our current standard of living


**107.** `07:32` **Meredith Lamb (+14169386001)**

🙄


**108.** `07:32` **Meredith Lamb (+14169386001)**

Sigh


**109.** `07:32` **Meredith Lamb (+14169386001)**

Guess we aren’t as close as I thought


**110.** `07:32` **Meredith Lamb (+14169386001)**

This process is literal whip lash


**111.** `07:33` **You**

Yeah because he wasn’t treating you fair\.\. so yeah he is taking it bad


**112.** `07:34` **You**

Almost to park for my walk 😃


**113.** `07:35` **Meredith Lamb (+14169386001)**

For real?


**114.** `07:35` **You**

Yep


**115.** `07:35` **Meredith Lamb (+14169386001)**

I’m so far behind today


**116.** `07:35` **You**

Committed


**117.** `07:35` **Meredith Lamb (+14169386001)**

This morning I was thinking about telling Carolyn\.


**118.** `07:35` **Meredith Lamb (+14169386001)**

I feel bad I’ve been slacking


**119.** `07:35` **You**

Sok I will go by myself


**120.** `07:35` **You**

lol


**121.** `07:36` **Meredith Lamb (+14169386001)**

I don’t want her to think this is how I normally am


**122.** `07:36` **You**

Ur call Cm will be curious


**123.** `07:36` **Meredith Lamb (+14169386001)**

I think she heard me talking to Jim about cottage\. I tried to hide it\. She def heard some of my convo with Jim and actually asked about some of it later


**124.** `07:36` **Meredith Lamb (+14169386001)**

I would never do that\!


**125.** `07:36` **Meredith Lamb (+14169386001)**

lol


**126.** `07:37` **Meredith Lamb (+14169386001)**

I didn’t care but it made me feel bad\. I should tell her


**127.** `07:37` **Meredith Lamb (+14169386001)**

Also she is probably wondering about my performance lately :p


**128.** `07:39` **Meredith Lamb (+14169386001)**

I could not tell her if you think it would make her suspicious about us


**129.** `07:39` **Meredith Lamb (+14169386001)**

But maybe she will just think I’ve been talking to you about my separation


**130.** `07:39` **You**

Might be good yah


**131.** `07:39` **You**

Later could explain things better


**132.** `07:39` **Meredith Lamb (+14169386001)**

She complained to me about Eli yday so I feel like we are on a new level lol


**133.** `07:40` **You**

Right we came together over this


**134.** `07:40` **You**

She could buy into that


**135.** `07:40` **Meredith Lamb (+14169386001)**

So don’t tell her or do?


**136.** `07:40` **You**

I would


**137.** `07:40` **You**

Now it will come out we both went to Michigan


**138.** `07:40` **You**

Just so you know


**139.** `07:40` **You**

So just have to play it off


**140.** `07:40` **Meredith Lamb (+14169386001)**

I will tell her only you Jim Erin and her know


**141.** `07:40` **You**

Which I will likely do I n a bit of a crass way


**142.** `07:41` **You**

Warning\. You ahead of time


**143.** `07:41` **You**

lol


**144.** `07:41` **Meredith Lamb (+14169386001)**

Yeah looks fishy


**145.** `07:41` **You**

Park is nice this morning


**146.** `07:41` **You**

Not really secluded though


**147.** `07:41` **You**

Still beggars and choosers


**148.** `07:47` **You**

You won’t be able to make her this morning I suppose being late and all eh\.\. I can head in to work if so I got a bit of air so that is on


**149.** `07:47` **Meredith Lamb (+14169386001)**

I just got confronted in the washroom lol


**150.** `07:48` **Meredith Lamb (+14169386001)**

“So you think it is fair to assume I will make my current salary for 10 yrs?”


**151.** `07:48` **Meredith Lamb (+14169386001)**

Me: yah


**152.** `07:48` **You**

Jesus


**153.** `07:48` **You**

I bathroom


**154.** `07:48` **Meredith Lamb (+14169386001)**

What would I do without work\. Literally running away


**155.** `07:49` **You**

😞


**156.** `07:49` **You**

You can call me
In car if you want\. Maybe I could calm you down?


**157.** `07:56` **You**

Ok luv I am going to head into work some other time\.


**158.** `07:59` **Meredith Lamb (+14169386001)**

He accosted me in kitchen so now I’m late


**159.** `07:59` **Meredith Lamb (+14169386001)**

Argh


**160.** `08:00` **You**

Sorry mer why don’t you call me from the car I am not at
Work yet just sitting t at park I\. My car


**161.** `08:02` **You**

M


**162.** `08:29` **Meredith Lamb (+14169386001)**

Just at Tim’s\. Be at work in 5 min


**163.** `09:54` **You**

Things progressing more smoothly I put a my hr request
In for a pension valuation… and asked her if she would do same and she was fine\.  Said I am not rushing to move out as long as things can calm down\.\. suggested since I won’t have kids during week maybe I could move closer to work\.\. also said I will still be over at the house a lot especially in first
Year to fix it up kow the lawn etc


**164.** `09:55` **Meredith Lamb (+14169386001)**

Good to hear\. Get ready for the whip lash tho lol


**165.** `09:56` **Meredith Lamb (+14169386001)**

I told Carolyn\. She knows you and Jim know also


**166.** `10:04` **You**

No I am being generous and I have been transparent


**167.** `10:05` **You**

I I told here there are some valuations amwhich would give you more a lot that would give you less she also hates the idea of wasting money on lawyers


**168.** `10:06` **Meredith Lamb (+14169386001)**

That’s good that she is on the same page re: lawyers\.


**169.** `10:06` **You**

She does want me to update my wit kk with a clause that guarantees a certain percentage of my net worth goes to kids on death now matter
My situation


**170.** `10:06` **You**

Will


**171.** `10:06` **Meredith Lamb (+14169386001)**

Wouldn’t you give everything to your kids?


**172.** `10:06` **You**

How did Carolyn react I am on with her in a min


**173.** `10:06` **You**

Yeah I would


**174.** `10:06` **You**

But she is worried if I remarry or meet someone else


**175.** `10:06` **You**

Blah blah


**176.** `10:06` **Meredith Lamb (+14169386001)**

She was probably the best reaction out of anyone


**177.** `10:07` **You**

Interesting


**178.** `10:07` **You**

5$


**179.** `10:07` **Meredith Lamb (+14169386001)**

But you wouldn’t give your new spouse anything\. Has to go to your kids no


**180.** `10:07` **Meredith Lamb (+14169386001)**

That’s what Andrew and I are doing I think


**181.** `10:07` **You**

Yeah that is what I would do for sure


**182.** `10:08` **You**

I mean it would depend on their financial
Situation\. As
Well and right now they do t need shit from
Me\.\.


**183.** `10:08` **Meredith Lamb (+14169386001)**

lol


**184.** `10:56` **You**

That was interesting…………


**185.** `11:04` **Meredith Lamb (+14169386001)**

Explain…


**186.** `11:07` **You**

Mmm no some things can only be spoke about in person sorry


**187.** `11:59` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/0duALa6UlxVWqEqpmhv73p?si=JqoCHm0OR06h1\_krdoNHww


**188.** `13:03` **Meredith Lamb (+14169386001)**

I’m not talking to him about this again until next week\. I need some cool off time\. I mentioned the pension etc though\. He brushed it off

*📎 1 attachment(s)*

**189.** `14:09` **You**

Sorry mer\.\. I that sucks… honestly lawyer build your own model with your own backup get in down on paper\.\. then he cannot dismiss


**190.** `14:09` **You**

This sucks he is being an asshole


**191.** `14:36` **Meredith Lamb (+14169386001)**

Cote is giving me suspicious smile/look


**192.** `15:45` **You**

ROFL why


**193.** `15:45` **You**

What


**194.** `15:45` **You**

I just spoke with her and I got nothing


**195.** `15:45` **You**

I am taking your lead and leaving now


**196.** `15:45` **You**

Had enough


**197.** `15:46` **Meredith Lamb (+14169386001)**

Coming out of your office\. 😬


**198.** `15:46` **You**

Whatever…
Zzzzzz


**199.** `15:46` **Meredith Lamb (+14169386001)**

I can never get drunk around her\. Omg


**200.** `15:46` **You**

Rofl


**201.** `15:47` **You**

No she will steal all of your secrets


**202.** `15:47` **Meredith Lamb (+14169386001)**

Absolute


**203.** `15:48` **Meredith Lamb (+14169386001)**

I told Andrew I’d walk through financials with him tonight if I can have a drink and do laundry also


**204.** `15:48` **You**

Kk well I will leave you alone just let me know when you are free or want to talk\.


**205.** `15:49` **Meredith Lamb (+14169386001)**

Michelle for sure suspects something\. She came to my desk and asked me about my kids and if I was single


**206.** `15:50` **You**

lol awesome


**207.** `15:50` **You**

Do you want me to talk to her


**208.** `15:51` **Meredith Lamb (+14169386001)**

Nooooo


**209.** `15:51` **Meredith Lamb (+14169386001)**

lol


**210.** `15:51` **You**

Ok


**211.** `15:51` **You**

Let
Me know if you change your mind happy to help


**212.** `15:51` **Meredith Lamb (+14169386001)**

I like hr\. I’m just not a good actress so…\.


**213.** `15:52` **Meredith Lamb (+14169386001)**

She seems sneaky lol


**214.** `15:57` **You**

She is


**215.** `15:57` **You**

Very very


**216.** `15:58` **You**

She is also loyal


**217.** `17:13` **You**

You don’t need to text back\.  Hope all is ok \.\. thinking of you\.


**218.** `17:21` **Meredith Lamb (+14169386001)**

We aren’t talking until 6


**219.** `17:22` **Meredith Lamb (+14169386001)**

Going to do a couple influencer slides for Monday :p


**220.** `17:23` **Meredith Lamb (+14169386001)**

He skipped a “happy hour” for this lol


**221.** `17:24` **You**

I am watching Oklahoma city bombing


**222.** `17:25` **You**

Because I love you not because I love documentaries but we can talk about it then\.


**223.** `17:28` **Meredith Lamb (+14169386001)**

Omg watch the foo fighter one\!


**224.** `17:28` **You**

I thought you wanted to watch that with me


**225.** `17:28` **You**

I will if you want


**226.** `17:28` **Meredith Lamb (+14169386001)**

Oklahoma one isn’t that great relative to so many others


**227.** `17:29` **Meredith Lamb (+14169386001)**

You are watching tv?


**228.** `17:29` **You**

Well I am I to it now so I have to finish


**229.** `17:29` **You**

No


**230.** `17:29` **You**

On iPad


**231.** `17:29` **Meredith Lamb (+14169386001)**

Oh


**232.** `17:29` **Meredith Lamb (+14169386001)**

lol


**233.** `17:29` **You**

Hehe oh ye with no technology


**234.** `17:30` **You**

Yeah it is not exciting…


**235.** `17:30` **You**

Mehhhhhhhhhhh


**236.** `17:30` **Meredith Lamb (+14169386001)**

So I can’t walk in the fields


**237.** `17:30` **You**

Why


**238.** `17:30` **Meredith Lamb (+14169386001)**

They sprayed last week and will be spraying again pending weather on weekend


**239.** `17:30` **Meredith Lamb (+14169386001)**

Don’t want cancer lol


**240.** `17:30` **You**

Sad


**241.** `17:31` **Meredith Lamb (+14169386001)**

I can still drop by and look around


**242.** `17:31` **You**

Well that is something


**243.** `17:31` **Meredith Lamb (+14169386001)**

Yeah I haven’t been there in a few years


**244.** `17:31` **You**

Will be cathartic


**245.** `17:33` **Meredith Lamb (+14169386001)**

Could be an interesting day talking to other Scott for an hour and then visiting home lol


**246.** `17:33` **Meredith Lamb (+14169386001)**

Very old school


**247.** `17:34` **You**

Yeah I hope it is nice for you\.\. you need some more nice in your life\.


**248.** `17:34` **Meredith Lamb (+14169386001)**

Ps my parents met Scott and my mom liked him … just bc of his name


**249.** `17:34` **Meredith Lamb (+14169386001)**

Just kidding lol


**250.** `17:36` **You**

Oh so you have a thing for Scott’s it seems\.  And Jonny’s


**251.** `17:36` **You**

I feel like I should be worried now


**252.** `17:36` **Meredith Lamb (+14169386001)**

When I started working for you she kept thinking it was him


**253.** `17:36` **Meredith Lamb (+14169386001)**

lol


**254.** `17:36` **Meredith Lamb (+14169386001)**

No no no


**255.** `17:36` **Meredith Lamb (+14169386001)**

We were like brother sister


**256.** `17:37` **Meredith Lamb (+14169386001)**

We travelled a lot to district offices so would stop at my parents place


**257.** `17:37` **Meredith Lamb (+14169386001)**

Total big brother


**258.** `17:38` **You**

Ah ok \.\. sure sure\.\. I get it 🙄


**259.** `17:38` **Meredith Lamb (+14169386001)**

https://flic\.kr/p/2dRF1K
My last day in Chatham


**260.** `17:39` **Meredith Lamb (+14169386001)**

Seriously he’s like a Jim


**261.** `17:51` **You**

oh shit I thought I responded\.\. sorry\.\. here 🙄 a thing for scott's in glasses \- with hair 😥 j/k


**262.** `17:52` **Meredith Lamb (+14169386001)**

You know he is very very very happy in a second relationship\.


**263.** `17:52` **Meredith Lamb (+14169386001)**

Chill


**264.** `17:52` **Meredith Lamb (+14169386001)**

lol


**265.** `17:53` **You**

dude\.\. lol I know you have told me about him already his first relationship and second


**266.** `17:53` **Meredith Lamb (+14169386001)**

And he lives in ridgetown


**267.** `17:53` **You**

:P


**268.** `17:53` **You**

just having a bit o fun\.


**269.** `17:53` **Meredith Lamb (+14169386001)**

I would never even consider dating him in a million years


**270.** `17:53` **You**

I never had someone like that\.


**271.** `17:54` **Meredith Lamb (+14169386001)**

So the influence part of Monday seems to be…\. Meh


**272.** `17:54` **You**

I haven't seen anything yet\.


**273.** `17:54` **Meredith Lamb (+14169386001)**

Im going over the Dec 2024 dnv report to see if there is something there


**274.** `17:54` **Meredith Lamb (+14169386001)**

Maybe


**275.** `17:54` **You**

feels like I might have to work this weekend


**276.** `17:54` **You**

:\(


**277.** `17:55` **Meredith Lamb (+14169386001)**

I know but you will have some time I think? Maybe not actually


**278.** `17:55` **Meredith Lamb (+14169386001)**

lol


**279.** `17:55` **You**

I am sure I will find some :\)


**280.** `17:55` **Meredith Lamb (+14169386001)**

Probably somewhere


**281.** `17:58` **You**

I don't have a Scott with glasses\.\. but I used to travel a bit with this Nutbar\.\.


**282.** `17:58` **You**

Reaction: 😂 from Meredith Lamb

*📎 1 attachment(s)*

**283.** `17:59` **You**

We sent this to Jim


**284.** `17:59` **You**

when he was sick\.


**285.** `18:00` **You**

he was actually supposed to come with me\.


**286.** `18:00` **You**

oh nm\.\. it is conversation time\.\. I will leave you alone\.\. chat later\. hope all goes well\.


**287.** `18:01` **Meredith Lamb (+14169386001)**

I want to finish a slide first


**288.** `18:01` **You**

ah ok\.\. well have at it\.\. I am going to go do my taxes and go to gym\.


**289.** `18:01` **You**

and then pack


**290.** `18:07` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
kk going to start now…\.


**291.** `18:07` **You**

give him hell Merv


**292.** `18:07` **You**

:\)


**293.** `19:12` **Meredith Lamb (+14169386001)**

😵‍💫


**294.** `19:12` **Meredith Lamb (+14169386001)**

Thank goodness I’m drinking at least\. Lol


**295.** `20:24` **You**

You doing ok


**296.** `20:24` **You**

Just had an explosion here


**297.** `20:24` **You**

Gracie not Jaimie


**298.** `20:24` **You**

Reaction: 😮 from Meredith Lamb
She got home from downtown\.\. but we found out she took my new laptop into her room and broke the screen


**299.** `20:26` **You**

Jaimie seemed happy with my proposal she still had questions feels it might still be bent a bit in her favour ChatGPT said it was more than generous and that I would be much better off doing monthly payments\. But I don’t want to I will pay her out net 200k more to offset\.


**300.** `20:31` **You**

Anyway there are a few things I want to revisit  with her to maybe save a bit back but we’ll see


**301.** `20:31` **You**

But generally she feels more comfortable that I am not trying to rip her off


**302.** `20:31` **Meredith Lamb (+14169386001)**

We are considering lump sum plus monthly right now


**303.** `20:32` **Meredith Lamb (+14169386001)**

He doesn’t like it but…\.


**304.** `20:32` **You**

I hope you kicked him in the balls hard


**305.** `20:32` **You**

He was not being even close to fair with you


**306.** `20:47` **You**

Wish I could talk to you tonight… sucks


**307.** `20:56` **Meredith Lamb (+14169386001)**

I mean we are making progress but not perfect


**308.** `20:58` **You**

Glad it’s getting better I hope you get what you deserve\.


**309.** `21:15` **Meredith Lamb (+14169386001)**

Trying to land where girls get house and cottage\. Still need a mediator


**310.** `21:15` **Meredith Lamb (+14169386001)**

Still need to look at it this weekend


**311.** `21:16` **You**

Sounds like fun


**312.** `21:16` **Meredith Lamb (+14169386001)**

Child \+ spousal comes to over $1m and he is not pleased


**313.** `21:17` **Meredith Lamb (+14169386001)**

So we need to sit on it a while


**314.** `21:17` **You**

Ok


**315.** `21:17` **You**

Math wins


**316.** `21:17` **Meredith Lamb (+14169386001)**

I can show you on the weekend


**317.** `21:17` **You**

Only if you want to\.\. I will help however I can


**318.** `21:18` **Meredith Lamb (+14169386001)**

I don’t want you to feel like you need to save me\. You do that with your family\. You don’t need to with me


**319.** `21:18` **You**

I know I do t need to save you\.\.
You will need to save me rofl


**320.** `21:18` **You**

Hahahaha


**321.** `21:19` **You**

I know mer


**322.** `21:19` **You**

I just want to help not saving you but just want you to put him in his place didnt want him to wear you down you have given more
Than enough to him in a number of ways


**323.** `21:24` **Meredith Lamb (+14169386001)**

I know i know…\.


**324.** `21:24` **Meredith Lamb (+14169386001)**

I would just rather we focus on other stuff


**325.** `21:24` **Meredith Lamb (+14169386001)**

lol


**326.** `21:25` **You**

Well I am
Focused on cardio atm


**327.** `21:25` **You**

Then legs hips and back
Tonight


**328.** `21:25` **Meredith Lamb (+14169386001)**

lol k\. I thought your gym membership was done


**329.** `21:25` **You**

I paid to may 22


**330.** `21:25` **Meredith Lamb (+14169386001)**

Ah gotcha


**331.** `21:26` **You**

Besides
Sharon is here I cannot leave sharp


**332.** `21:26` **You**

Sharon


**333.** `21:26` **Meredith Lamb (+14169386001)**

Omg


**334.** `21:26` **You**

She appreciates my witty banter and my glasses


**335.** `21:27` **Meredith Lamb (+14169386001)**

She really does


**336.** `21:27` **Meredith Lamb (+14169386001)**

You have no idea


**337.** `21:28` **You**

Too bad you weren’t free tomorrow


**338.** `21:28` **Meredith Lamb (+14169386001)**

I mean you aren’t free either


**339.** `21:28` **You**

I have hours


**340.** `21:29` **Meredith Lamb (+14169386001)**

Mac has relaxed the schedule and is allowing me to leave at 9\.30 now


**341.** `21:29` **Meredith Lamb (+14169386001)**

lol


**342.** `21:29` **You**

lol


**343.** `21:29` **Meredith Lamb (+14169386001)**

So I can pack in the morning


**344.** `21:29` **You**

Nice of her


**345.** `21:29` **You**

No I am leaving early but Jon is not home till 5 pm


**346.** `21:30` **Meredith Lamb (+14169386001)**

And how are you explaining to anyone curious how we are both in the same state this weekend


**347.** `21:30` **You**

Pictures


**348.** `21:30` **Meredith Lamb (+14169386001)**

Pure coincidence


**349.** `21:30` **You**

lol you asking me how


**350.** `21:30` **You**

Me the planner


**351.** `21:31` **You**

ROFL


**352.** `21:31` **You**

Silly girl


**353.** `21:31` **Meredith Lamb (+14169386001)**

lol


**354.** `21:31` **Meredith Lamb (+14169386001)**

The planner with the overall sketchy story


**355.** `21:32` **You**

Pics and video it will be fine


**356.** `21:32` **You**

Cote probably suspect if she asked you that


**357.** `21:32` **You**

I think she overhears me today


**358.** `21:33` **Meredith Lamb (+14169386001)**

She totally does\. You should have seen her face


**359.** `21:33` **You**

With her fucking insane hearing


**360.** `21:33` **Meredith Lamb (+14169386001)**

Never seen her make that face


**361.** `21:33` **You**

I was talking to my hr


**362.** `21:33` **You**

Asking about a pension valuation


**363.** `21:33` **You**

Because of an impending separation


**364.** `21:33` **You**

I wasn’t talking loud


**365.** `21:33` **You**

But door was open e


**366.** `21:34` **You**

Still doesn’t prove anything


**367.** `21:34` **Meredith Lamb (+14169386001)**

She made the face and then like 10 min later asked if I was single


**368.** `21:34` **Meredith Lamb (+14169386001)**

I doubt it was that


**369.** `21:34` **You**

Maybe she is jealous


**370.** `21:34` **Meredith Lamb (+14169386001)**

It was me in your office today


**371.** `21:34` **Meredith Lamb (+14169386001)**

She totally is


**372.** `21:34` **Meredith Lamb (+14169386001)**

lol


**373.** `21:34` **You**

ROFL


**374.** `21:34` **Meredith Lamb (+14169386001)**

Haha


**375.** `21:34` **You**

She would never do anything even she walked up and saw it


**376.** `21:34` **You**

She would likely be happy for us


**377.** `21:34` **Meredith Lamb (+14169386001)**

Why else would she care so much


**378.** `21:34` **You**

Because she likes me


**379.** `21:35` **You**

For real as a friend


**380.** `21:35` **Meredith Lamb (+14169386001)**

🙄


**381.** `21:35` **You**

Not like that


**382.** `21:35` **Meredith Lamb (+14169386001)**

Doubt it


**383.** `21:35` **You**

She does we have known each other a long time


**384.** `21:35` **Meredith Lamb (+14169386001)**

K, I’m not kidding\. Literally less than 10’min after fixing me that face asks me if I’m single


**385.** `21:35` **Meredith Lamb (+14169386001)**

\*giving me


**386.** `21:35` **You**

Maybe she was interested in you


**387.** `21:35` **Meredith Lamb (+14169386001)**

MAYBE


**388.** `21:35` **Meredith Lamb (+14169386001)**

that might make more sense


**389.** `21:35` **Meredith Lamb (+14169386001)**

lol


**390.** `21:36` **You**

It is possible


**391.** `21:36` **Meredith Lamb (+14169386001)**

Doubt it


**392.** `21:36` **Meredith Lamb (+14169386001)**

She has a very straight vibe


**393.** `21:37` **You**

lol well you got nothing to worry about out there\.\. in either case imho


**394.** `21:37` **You**

I am sure she will find a way to say something to
Me this weekend


**395.** `21:37` **Meredith Lamb (+14169386001)**

I’m worried she will call me on it and I will stumble


**396.** `21:37` **Meredith Lamb (+14169386001)**

That’s all


**397.** `21:38` **You**

You need to take lessons


**398.** `21:38` **You**

lol


**399.** `21:38` **Meredith Lamb (+14169386001)**

kkkkkkkk


**400.** `21:38` **You**

Take Sharon for instance


**401.** `21:38` **Meredith Lamb (+14169386001)**

Where do I get those?


**402.** `21:38` **You**

It is a trick we learned in public speaking


**403.** `21:38` **You**

How to speak about almost anything given 30 seconds prep


**404.** `21:39` **You**

Then it is about backstopping


**405.** `21:39` **Meredith Lamb (+14169386001)**

Sigh… gobbleey gook


**406.** `21:39` **You**

ROFL


**407.** `21:40` **Meredith Lamb (+14169386001)**

Sorry, on my third glass of wine\.


**408.** `21:40` **Meredith Lamb (+14169386001)**

Had to survive tonight


**409.** `21:40` **Meredith Lamb (+14169386001)**

lol


**410.** `21:40` **Meredith Lamb (+14169386001)**

It kept me calm


**411.** `21:40` **You**

So yeah if you had have been free for a walk or anything was gonna stop to see you indetroit for an hour then continue on but sounds like you got a packed day\.


**412.** `21:40` **You**

I will head through and find a gym in grand rapids


**413.** `21:40` **Meredith Lamb (+14169386001)**

Is Detroit on the way?


**414.** `21:40` **You**

Yeah


**415.** `21:41` **You**

Very slight southern detour like 20 mins


**416.** `21:41` **Meredith Lamb (+14169386001)**

I mean you could stop


**417.** `21:41` **You**

I just thought of it tonight


**418.** `21:41` **Meredith Lamb (+14169386001)**

I’m sure I won’t be busy


**419.** `21:41` **You**

Thought I would let you decide


**420.** `21:41` **Meredith Lamb (+14169386001)**

lol


**421.** `21:43` **You**

Will prolly leave right around when you got that was my plan thought you would be out earlier


**422.** `21:43` **Meredith Lamb (+14169386001)**

Mac didn’t book nails bc she waited too long so places were closed but she is going to try tomorrow but even still, I don’t even NEED a pedi\. I mean I could get one but not mandatory\. Her nails are really outgrown


**423.** `21:43` **You**

Girls… push


**424.** `21:43` **You**

Psssh


**425.** `21:43` **Meredith Lamb (+14169386001)**

Will see what time she books for in morning


**426.** `21:44` **You**

This is where I get my makeover… lol so lame


**427.** `21:44` **Meredith Lamb (+14169386001)**

My toenails are blue\. I should get something cheerier lol


**428.** `21:44` **Meredith Lamb (+14169386001)**

But I don’t have to lol


**429.** `21:44` **You**

So what you stopping in Detroit or before


**430.** `21:44` **You**

So is shouldn’t leave early then


**431.** `21:45` **Meredith Lamb (+14169386001)**

What time is early


**432.** `21:45` **You**

Well you said you were going around 9:30


**433.** `21:45` **You**

But more like 11 if nails right


**434.** `21:46` **Meredith Lamb (+14169386001)**

9\.30 get there at 1 or 1\.30


**435.** `21:46` **Meredith Lamb (+14169386001)**

She is going to book appt on the way


**436.** `21:46` **You**

Ah kk


**437.** `21:47` **You**

Well I want to shoot to get to grand rapids around 5


**438.** `21:47` **Meredith Lamb (+14169386001)**

We can check in at 3


**439.** `21:47` **You**

So that means I should leave Detroit around 3 lol


**440.** `21:47` **You**

So yeah not gonna work lol


**441.** `21:47` **Meredith Lamb (+14169386001)**

I don’t need to get my nails done but should be in vicinity


**442.** `21:47` **You**

Sry


**443.** `21:47` **Meredith Lamb (+14169386001)**

:\(


**444.** `21:47` **You**

I mean I would come just to go for a walk


**445.** `21:47` **You**

Mind you


**446.** `21:48` **You**

But if it is too much will wait


**447.** `21:48` **You**

All good


**448.** `21:48` **Meredith Lamb (+14169386001)**

I mean, all I want to do is see you so…\.


**449.** `21:49` **You**

Tell me where and I will be there


**450.** `21:50` **Meredith Lamb (+14169386001)**

We will be around the hotel or at the hotel really\. Who knows what this teen can organize


**451.** `21:50` **Meredith Lamb (+14169386001)**

You could come get your nails done\.


**452.** `21:50` **Meredith Lamb (+14169386001)**

Kidding


**453.** `21:51` **You**

Can you call me on your earbuds so Mac cannot hear?


**454.** `21:54` **Meredith Lamb (+14169386001)**

I never use these ear buds but will try


**455.** `21:55` **You**

lol


**456.** `22:25` **You**

Reaction: ❤️ from Meredith Lamb
Nice talking to you tonight love hope you have a nice peaceful sleep if I don’t chat with you later\.


**457.** `22:27` **Meredith Lamb (+14169386001)**

We should do that more often\. I just watch you work out\. Lol


**458.** `22:27` **Meredith Lamb (+14169386001)**

Eventually we can do it together


**459.** `22:27` **You**

Oh that yeah thought you might get a chuckle\.


**460.** `22:27` **You**

Whatever makes you happy\.


**461.** `22:28` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
It did\. :\)


**462.** `22:28` **You**

Alright I will check in later but if I do t hear back will assume you are asleep


**463.** `22:39` **Meredith Lamb (+14169386001)**

Just trying to not think about you and focus on handmaids tale lol


**464.** `23:01` **You**

You can do both


**465.** `23:01` **You**

Was a nice shower


**466.** `23:02` **Meredith Lamb (+14169386001)**

>
Stop\. You are doing that on purpose

*💬 Reply*

**467.** `23:03` **You**

Man and the sauna was nice like 210 F


**468.** `23:03` **You**

Go\. A miss this place I think


**469.** `23:03` **You**

>
Well I do want you thinking about me

*💬 Reply*

**470.** `23:03` **Meredith Lamb (+14169386001)**

Just need a condo with a gym and sauna  lingers


**471.** `23:04` **You**

Yeah that’s work


**472.** `23:03` **Meredith Lamb (+14169386001)**

\*I guess


**473.** `23:04` **You**

I will have to look


**474.** `23:04` **You**

Well shit


**475.** `23:05` **You**

Awkward


**476.** `23:05` **Meredith Lamb (+14169386001)**

\(Still thinking about your shower ugh\)


**477.** `23:05` **You**

Well think about this the


**478.** `23:05` **You**

N


**479.** `23:06` **You**

Unintentional but hasn’t happened before


**480.** `23:06` **You**

Sooooo


**481.** `23:06` **You**

I didn’t bring my new boxers for after the shower\.\. sooo\.\. oh well\.  Swear not joking but not planned rofl\!\!\!


**482.** `23:06` **You**

Should be interesting


**483.** `23:07` **Meredith Lamb (+14169386001)**

Ok just stop


**484.** `23:07` **You**

No it’s true\.\. I can\.\.
Oh nooo that would be nsfw\. ☺️


**485.** `23:08` **Meredith Lamb (+14169386001)**

This is all nsfw at this point


**486.** `23:09` **You**

It’s ok comfy\.\. I can do this\.\.


**487.** `23:10` **You**

I wonder if there are dudes that do this all the time\.\.


**488.** `23:10` **You**

It could be a thing


**489.** `23:10` **Meredith Lamb (+14169386001)**

You are literally just going home I hope\. No sharon dates


**490.** `23:11` **You**

Well Sharon is 4 drinks or 5 drinks I\. And unfortunately somewhere else tonight\.


**491.** `23:12` **Meredith Lamb (+14169386001)**

She sounds amazing


**492.** `23:12` **You**

She is\.\.
Absolutely\.  Nothing I have ever felt before\.


**493.** `23:13` **You**

And I am positive I never will again\.


**494.** `23:13` **Meredith Lamb (+14169386001)**

🫠


**495.** `23:13` **Meredith Lamb (+14169386001)**

Gah


**496.** `23:14` **Meredith Lamb (+14169386001)**

I think it is solely due to this guy that has captivated her\.


**497.** `23:15` **You**

Nah he just normal\.\. just wants to make her happy\. Simple dude simple needs\.


**498.** `23:15` **You**

I mean who knows what tomorrow brings


**499.** `23:16` **You**

I mean maybe we get
Lucky


**500.** `23:16` **Meredith Lamb (+14169386001)**

Not sure simple is the word I’d use to describe him


**501.** `23:16` **Meredith Lamb (+14169386001)**

Word has never come to mind


**502.** `23:17` **You**

Maybe people find something to do with their teammates maybe the room
Is ready early
lol j/k


**503.** `23:17` **You**

I am simple though


**504.** `23:17` **You**

Really


**505.** `23:17` **You**

I just need you nothing
Else


**506.** `23:17` **You**

Seriously that is how I feel


**507.** `23:19` **You**

Think I might try this whole freedom thing tomorrow confey to drive in


**508.** `23:21` **Meredith Lamb (+14169386001)**

You are not simple\. I don’t know anyone who would describe you that way\.


**509.** `23:21` **Meredith Lamb (+14169386001)**

>
Whole new world …

*💬 Reply*

**510.** `23:21` **You**

We’ll see


**511.** `23:27` **You**

Sounds like you are about done for the night


**512.** `23:28` **Meredith Lamb (+14169386001)**

Sorry watching Caitlin Clark on David letterman


**513.** `23:28` **You**

Don’t apologize I should let you enjoy your quiet…


**514.** `23:29` **Meredith Lamb (+14169386001)**

Just distracting myself 🙃


**515.** `23:30` **You**

Well I am sorry for messing with you wasn’t niceS


**516.** `23:31` **Meredith Lamb (+14169386001)**

It is ok… countdown is so short now


**517.** `23:32` **You**

Yeah still


**518.** `23:32` **You**

Feels
Too long


**519.** `23:32` **Meredith Lamb (+14169386001)**

I knoooooow


**520.** `23:33` **You**

Reaction: ❤️ from Meredith Lamb
I hope
To see you tomorrow I know it is selfish but I do\.


**521.** `23:39` **Meredith Lamb (+14169386001)**

k, Caitlin Clarke done\. Going to bed\. Love you\. Will be thinking of us xo


**522.** `23:40` **You**

Love you mer so much want to dream of you like last night\.  I msg you when I am on road will be about 9 am after I drop maddie at school


**523.** `23:40` **You**

Xoxoxoxo❤️❤️🔥🔥❤️❤️


