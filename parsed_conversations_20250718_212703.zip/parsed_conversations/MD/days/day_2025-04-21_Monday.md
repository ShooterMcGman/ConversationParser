# Daily Conversation: 2025-04-21 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-21 |
| **Day** | Monday |
| **Week** | 2 |
| **Messages** | 151 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-21T01:19 - 2025-04-21T23:37 |

## 📝 Daily Summary

This day contains **151 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `01:19` **Meredith Lamb (+14169386001)**

Can’t sleep so got on my phone\. Stupid\. Anyway please do not apologize\. I was feeling shitty from painting all day not from you\!\! And I don’t want you to keep things under wraps…\. We are in this together and you don’t have to “control” your head around me\.


**002.** `06:09` **You**

Sorry you couldn’t sleep\. Hope things are ok\.  I am just getting going this morning\.  J and I exploded last night kind of where you and Andrew were a few weeks ago, except I don’t expect her to try for any more cuddles or anything more based on where it ended\.  Just hoping to level it out and proceed\.


**003.** `06:14` **You**

I did speak to her briefly this morning and think I was able to level set\.  We shall see


**004.** `06:16` **You**

Anyways hitting the shower now cannot wait to see you tomorrow\.  Hope your day goes well\. Will be around if you are bored I have a slow day\.


**005.** `06:42` **You**

Oh the Andrew thing did get into my head the other night\.  I don’t know if j is still bouncing around in yours that way but, hard to think about that\.\.  I can let
You know that I feel like as of Sat morning there will
W no suggestions of any kind of reconciliation, no more overtures or invitations or requests
Of any kind\.  So if that helps your head, you have nothing to worry about there whatsoever\.  I think we’re our situations reversed you might have a tough time thinking about j and I at the cottage is all\.  lol man\. This is like no situation ever is it\.  It is like you are getting together with someone who is literally living with their ex who is trying to get back together with them on both sides of the fence\.\. insane tricks on the mind\.  Just cannot wait for tomorrow then Thursday then Detroit then Chatham then everything else\.  Luv you have a good day\.


**006.** `07:47` **Meredith Lamb (+14169386001)**

It’s definitely a fucked up situation\. Anytime there is silence from you I’m also wondering if you both are having some sort of productive conversation where things shift\. Or your girls say something that impacts a shift in your head\. If you and j were at the cottage together… yeah I guess that would mess with my head a bit potentially\. The reality is that this place is just a second home and there are just as many bad memories here as at home \(we lived here during Covid so…\) so my reality is that this isn’t entirely a lovely vacation home and more a second home with all the work and drudgery that comes with our other place in Toronto\.
For the record, j absolutely bounces around in my head\. I saw you two together at work when we sat near each other and she would go to your desk\. So i kind of saw how you guys interacted at that time at work at least\. So I can easily get visions in my head bc of that\. I do compartmentalize it away though so I don’t go crazy with everything else going on\. Just being honest\. Healthy not healthy… survival mechanism\. Not sure\. 🙈
Andrew is in a good mood and leaving me alone bc I agreed to the cottage thing\. It is what he cares about most in the world\. 🙄


**007.** `07:57` **You**

Reaction: ❤️ from Meredith Lamb
Appreciate your take the time to share it makes me feel like I am not crazy\.  Just sorting out some stuff this morning changing a bit with my diet, going off the 16  hour fasts to include lunch again\. Trying a few other things\.\. down 15 lbs this morning, so feeling good about that at least\.  I also talked to maddie ahe does want to come with me but she is being supportive of j right now because of all going on and she thinks I am stronger\.\.


**008.** `07:58` **You**

I wish I had your skills at compartmentalization


**009.** `07:58` **You**

I am also going to look for a therapist tonight just for me\.\. I think I need one too\.


**010.** `07:58` **You**

Love you\.


**011.** `08:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
The only compartment I thought about this morning was kissing you so yeah, compartmentalization can have its benefits\. Lol love you too and I was so happy to read the stuff wrt maddie\.


**012.** `09:26` **Meredith Lamb (+14169386001)**

So morning was amazing…\. driving home with girls\. Everything fine but :P
Andrew staying\.


**013.** `10:00` **You**

Andrew staying at cottage?


**014.** `10:01` **You**

Glad
You guys had a great morning\.


**015.** `10:30` **Meredith Lamb (+14169386001)**

That was sarcasm fyi


**016.** `11:12` **You**

I think you will need to deconstruct the last sentence rofl I don’t k is what was sarcasm the morning being amazing?  Him staying\.\. everything fine?


**017.** `11:13` **You**

Usually I can pick up on it \.\. but not on that one\.\.


**018.** `11:59` **Meredith Lamb (+14169386001)**

Amazing morning was sarcasm


**019.** `11:59` **Meredith Lamb (+14169386001)**

Yeah Andrew staying until tomorrow


**020.** `11:59` **Meredith Lamb (+14169386001)**

Just arrived in the shwa to pick up Maelle on way home


**021.** `12:11` **You**

Ahh kk sorry what was bad about the morning maybe tell me later\.\.


**022.** `12:11` **You**

Also any interest in Detroit game on Sunday \- pistons\.


**023.** `12:13` **Meredith Lamb (+14169386001)**

So Mac was looking at her schedule and she doesn’t start until 2pm\. She’s afternoon set


**024.** `12:13` **Meredith Lamb (+14169386001)**

I should go to some games but told I won’t be going to all and she can uber back


**025.** `12:15` **You**

Sunday game is at 1 pm so that probably won’t work no worries\.


**026.** `12:17` **Meredith Lamb (+14169386001)**

Yeah prob with afternoon set is in May not get to Chatham until late fyi


**027.** `12:17` **Meredith Lamb (+14169386001)**

Will depend how they do


**028.** `12:19` **You**

Well you will know where I will be\.


**029.** `12:33` **Meredith Lamb (+14169386001)**

Just having lunch with folks and then on our way home\. Phewwwww


**030.** `12:35` **You**

Nice busy day…\. What set you off this morning\.\. I thought everything was super duper lol\.


**031.** `12:36` **You**

I could also stick around and watch the afternoon set miss dinner lol good excuse… rofl


**032.** `12:37` **Meredith Lamb (+14169386001)**

>
Not suspicious at all

*💬 Reply*

**033.** `12:37` **Meredith Lamb (+14169386001)**

>
Ugh same old\. Will talk later

*💬 Reply*

**034.** `12:37` **You**

😩


**035.** `12:37` **You**

Kk


**036.** `12:38` **You**

>
Ok sarcasm I will just go do whatever I have to\.

*💬 Reply*

**037.** `12:40` **Meredith Lamb (+14169386001)**

How’s work?


**038.** `12:40` **You**

It’s work quiet I have a meeting with Ian in 20 mins\.\.


**039.** `12:40` **You**

30 mins every two weeks very useful ……


**040.** `12:41` **Meredith Lamb (+14169386001)**

That’s good…\.


**041.** `12:41` **You**

lol quiet is good 30 mins is shit how can I get him up to speed on anything


**042.** `12:42` **You**

I will try to sit with him tomorrow night


**043.** `12:42` **You**

And figure out a way to parlay educating him into being one of the guys should be a fun line to walk


**044.** `12:43` **Meredith Lamb (+14169386001)**

K I’m back on the road


**045.** `12:43` **You**

Kk later


**046.** `12:51` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
https://open\.spotify\.com/track/3EXrtClWmgsM7dw75Mw2M1?si=ea1iUvK\-QkWSv1xcgoaqew


**047.** `13:00` **You**

Are you sad?


**048.** `13:01` **You**

Nm read the words


**049.** `15:16` **You**

God I miss you cannot say that in teams\.\.


**050.** `15:17` **You**

Did you want a quick call I have time this afternoon


**051.** `15:22` **Meredith Lamb (+14169386001)**

lol got my phone back :\)


**052.** `15:23` **Meredith Lamb (+14169386001)**

Doh


**053.** `15:26` **You**

Ffs I am a moron


**054.** `15:26` **Meredith Lamb (+14169386001)**

>
Yeah call whenever\. I’m going to clear out some emails

*💬 Reply*

**055.** `15:27` **Meredith Lamb (+14169386001)**

I will shut my door lol\. Marlowe\. Lol


**056.** `15:27` **You**

You call me whenever you are settled and sorted\.  Set yourself to away maybe\.


**057.** `15:28` **You**

Out of office with show you circle ⭕️


**058.** `18:00` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Me in 2015…\. “How the fuck did I end up here?” Kids always crying and fighting\. 3 against 1 constantly\. Exhausted all the time\.

*📎 8 attachment(s)*

**059.** `18:05` **Meredith Lamb (+14169386001)**

I was still very me \(always taking photos but stopped using Flickr for some reason for like 10 yrs\) but always doing kid stuff \(and working still until 2017\) and typically with a drink to survive mentally\. Typically on my own bc Andrew worked all the time\.

*📎 3 attachment(s)*

**060.** `18:10` **You**

I don’t want that for us\. Btw\.


**061.** `18:10` **You**

Hopefully no one else has your phone now


**062.** `18:24` **Meredith Lamb (+14169386001)**

lol no


**063.** `18:26` **Meredith Lamb (+14169386001)**

My girls were 2,4,6 yrs old in 2015\. So exhausting\. I think it is funny when Louise complains about her one 2 yr old\. It’s all relative though\.


**064.** `19:02` **You**

lol yeah I don’t know how you did any of what you did of course you had to compartmentalize 3 kids a partner pretty much focused on himself and you\. 😞


**065.** `19:08` **Meredith Lamb (+14169386001)**

I was also working for Tina and at monthly meetings with Jay at the oeb\. Lol\. 2015 sucked\. 2016 turned around though


**066.** `19:17` **You**

Then 2025 now that was a real breakthrough year


**067.** `19:17` **Meredith Lamb (+14169386001)**

Right? Shit\.


**068.** `19:18` **You**

Specifically 2025 April 25 26 27 28


**069.** `19:26` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
lol


**070.** `19:31` **You**

Heading to gym chat later\.  Hope your night is going well going well read your emails responded to lost\.


**071.** `19:31` **You**

Most


**072.** `19:34` **Meredith Lamb (+14169386001)**

kk


**073.** `19:40` **You**

No videos for tonight doing chest and that would not be appropriate


**074.** `19:44` **Meredith Lamb (+14169386001)**

I think it’s be fine\.


**075.** `19:44` **Meredith Lamb (+14169386001)**

\*it’d


**076.** `19:44` **You**

Nah I am not sure this is way too one sided jow


**077.** `19:48` **Meredith Lamb (+14169386001)**

Haha


**078.** `19:48` **You**

Yeah we will have to see I am doing weights after j leaves but yeah not really feeling it\.\. needs give and take\.


**079.** `19:49` **You**

😜


**080.** `19:49` **Meredith Lamb (+14169386001)**

Should I be worried that you guys are working out together now? 😵‍💫


**081.** `19:51` **Meredith Lamb (+14169386001)**

Maybe just don’t mention that part next time\.


**082.** `19:53` **You**

Oh mer come on I am trying to get us back on her not wanting to stab me ground


**083.** `19:53` **You**

She will likely leave after 20 mins I will text you when she is gone and you can relax
I don’t think you are worried you are too strong\!\!


**084.** `19:54` **Meredith Lamb (+14169386001)**

Totally don’t care\. Just unnecessary to mention lol


**085.** `20:51` **You**

You somewhere you can talk?


**086.** `20:53` **Meredith Lamb (+14169386001)**

Yeah but aren’t you working out?


**087.** `21:12` **You**

U hav?


**088.** `21:13` **Meredith Lamb (+14169386001)**

Can’t find mine so charging my kids


**089.** `21:13` **Meredith Lamb (+14169386001)**

Marlowe asked if I was talking to my mom


**090.** `21:14` **Meredith Lamb (+14169386001)**

She wanted math help


**091.** `21:14` **Meredith Lamb (+14169386001)**

The girl never ends I swear


**092.** `21:14` **You**

Just making sure you have your phone


**093.** `21:14` **You**

Before


**094.** `21:14` **Meredith Lamb (+14169386001)**

Oh lol I always do\. This was a grocery one off lol


**095.** `21:15` **You**

Luv you cranky pants xoxoxox ❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️


**096.** `21:15` **Meredith Lamb (+14169386001)**

I am not cranky I swear\!


**097.** `21:16` **You**

Still love you even if you were


**098.** `21:16` **Meredith Lamb (+14169386001)**

Maybe a little annoyed but not cranky lol


**099.** `21:16` **Meredith Lamb (+14169386001)**

Love you too


**100.** `21:16` **You**

Annoyed pants


**101.** `21:16` **You**

It same
Ring


**102.** `21:16` **You**

Not


**103.** `21:16` **Meredith Lamb (+14169386001)**

Definitely not


**104.** `21:17` **You**



**105.** `21:17` **You**

Don’t like that one


**106.** `21:17` **You**

🥰


**107.** `21:18` **Meredith Lamb (+14169386001)**

lol I feel like I shouldn’t even ask


**108.** `21:18` **You**

Perhaps not


**109.** `21:33` **You**

The building blows up in the end


**110.** `21:33` **You**

Ooos spoiler


**111.** `21:33` **You**

😝


**112.** `21:34` **Meredith Lamb (+14169386001)**

Stop


**113.** `21:34` **Meredith Lamb (+14169386001)**

14 min left\. No spoilers


**114.** `21:35` **You**

Rofl


**115.** `21:35` **You**

https://open\.spotify\.com/track/43z6scIZU2QcEieMQFAJRG?si=KUZPx4RAQzK8rGSg6NNU\_A&context=spotify%3Aplaylist%3A4o0w2C4v7JfY6AwQTKoWoD


**116.** `21:35` **Meredith Lamb (+14169386001)**

I’m learning about The Turner Diaries\. So interesting


**117.** `21:37` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
❤️


**118.** `21:38` **You**

Wed more emojis


**119.** `21:38` **You**

Need


**120.** `21:39` **Meredith Lamb (+14169386001)**

Nah we’re good


**121.** `21:39` **Meredith Lamb (+14169386001)**

We need more time in person


**122.** `21:57` **You**

Def absolutely


**123.** `21:57` **You**

Can’t send you a pic though don’t think you can handle it\.


**124.** `22:00` **Meredith Lamb (+14169386001)**

Again, unnecessary\.


**125.** `22:00` **Meredith Lamb (+14169386001)**

\(That was a joke\!\)


**126.** `22:02` **You**

lol I know totally unnecessary \.\.


**127.** `22:02` **You**

Sounds like you good not getting one anyways\.\.  all good\.


**128.** `22:03` **Meredith Lamb (+14169386001)**

Such a tease\.


**129.** `22:03` **Meredith Lamb (+14169386001)**

You’re making me cry\. Just being mean


**130.** `22:03` **Meredith Lamb (+14169386001)**

I’m tearing up


**131.** `22:04` **You**

Yeah w/e


**132.** `22:04` **You**

Non  crier


**133.** `22:11` **Meredith Lamb (+14169386001)**

⏳


**134.** `22:18` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**135.** `22:18` **You**

Nothing special tonight


**136.** `22:18` **You**

Reaction: 😂 from Meredith Lamb
No ass shot


**137.** `22:20` **You**

If you are going to be up for a bit I could call you in the car\.\.


**138.** `22:21` **You**

If you wont get caught


**139.** `22:21` **Meredith Lamb (+14169386001)**

k, of course and no I won’t get caught


**140.** `22:22` **You**

lol sure you say that now and when I call Marlo’s picks up and says who are
You Mr sh\.


**141.** `22:23` **Meredith Lamb (+14169386001)**

LOL she is a little shadow sometimes but I think she is up in her room now


**142.** `22:24` **You**

Reaction: 👍 from Meredith Lamb
Kk shower time call you in a few


**143.** `22:47` **You**

Lonely shower…\.\.☺️


**144.** `22:47` **Meredith Lamb (+14169386001)**

Thank goodness\! Lol


**145.** `22:49` **You**

Reaction: 😂 from Meredith Lamb
Yeah a dude tried to come in but I was comeon\.\. I am taken\.


**146.** `22:55` **You**

Now good


**147.** `22:56` **Meredith Lamb (+14169386001)**

Yep


**148.** `23:18` **Meredith Lamb (+14169386001)**

Ugh I knew Marlowe was outside of here in the kitchen …\. Yep\. She should have been in bed\. I was quiet tho bc I figured\. I’m going to have to be more careful around her \- she is annoying me\.


**149.** `23:25` **You**

That sucks sorry\.\.  maybe she senses something


**150.** `23:36` **You**

Bout to get yelled at love
You good night


**151.** `23:37` **Meredith Lamb (+14169386001)**

:\( nite xoxoxo


