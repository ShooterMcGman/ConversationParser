# Daily Conversation: 2025-05-14 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-14 |
| **Day** | Wednesday |
| **Week** | 5 |
| **Messages** | 403 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-14T06:26 - 2025-05-14T22:20 |

## 📝 Daily Summary

This day contains **403 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `06:26` **You**

Wake up lazy bones


**002.** `06:26` **You**

lol saw
You typing


**003.** `06:26` **You**

All ok?


**004.** `06:27` **Meredith Lamb (+14169386001)**

So I was thinking maybe I go Thursday and you go Friday morning \(if you are taking day off\)\. Then, I can clean and move stuff onto front porch and cover the ring with it\!


**005.** `06:28` **You**

Sure whatever works\.  I convinced j I was going to leave from work tomorrow afternoon but can switch that up for sure


**006.** `06:34` **Meredith Lamb (+14169386001)**

Just driving my kid to her garage trip drop off and she forgot her headphones so I have to drive back\. Ugh


**007.** `06:34` **You**

Eesh sucks boooo


**008.** `06:35` **Meredith Lamb (+14169386001)**

Grad trip


**009.** `06:35` **Meredith Lamb (+14169386001)**

If I can get there earlier than you, I will look at my schedule then I can clean and put some stuff in front of the ring and that is probably the easiest thing to do


**010.** `06:35` **Meredith Lamb (+14169386001)**

But I need to get there earlier than you in order to do that and make it realistic


**011.** `06:36` **You**

Ok so depends on when you leave and when I leave Thursday I could leave later and you earlier or I could tell Jaimie I am going to change plans\.\. just don’t want to change too much she is already sus a bit\.


**012.** `06:37` **You**

We can chat
This morning if you have some tine or whenever\.


**013.** `06:39` **You**

I could also leave later thurs and just find a bnb or something couple of options


**014.** `06:46` **Meredith Lamb (+14169386001)**

>
No not necessary

*💬 Reply*

**015.** `06:46` **Meredith Lamb (+14169386001)**

k Maelle has her headphones and I am free of her


**016.** `06:46` **You**

lol


**017.** `06:46` **Meredith Lamb (+14169386001)**

Will go home and check my schedule


**018.** `06:47` **You**

For something funny to tell you in a min\.\.


**019.** `06:53` **Meredith Lamb (+14169386001)**

You know what I have Thursday aft?


**020.** `06:56` **Meredith Lamb (+14169386001)**

YOUR meeting


**021.** `06:57` **You**

So take half an sdo


**022.** `06:57` **Meredith Lamb (+14169386001)**

I think I also told Andrew I’d take Marlowe to vball thurs night 6\-8pm\. But can’t remember why he couldn’t hmmmh


**023.** `06:57` **You**

It won’t be the last
Meeting


**024.** `06:57` **Meredith Lamb (+14169386001)**

Have to text him


**025.** `06:58` **You**

Kk well let me know I am holding off telling j anything further


**026.** `06:58` **Meredith Lamb (+14169386001)**

I mean I have driven to cottage in morning before work before and then worked from there


**027.** `06:58` **Meredith Lamb (+14169386001)**

I could do that


**028.** `06:58` **Meredith Lamb (+14169386001)**

Leave at 6am


**029.** `06:58` **You**

Tomorrow morning


**030.** `06:58` **You**

Yeah I mean if volleyball is sorted


**031.** `06:59` **Meredith Lamb (+14169386001)**

I will text him what that is about\. I can’t store all of this info in my brain


**032.** `06:59` **You**

lol


**033.** `07:01` **Meredith Lamb (+14169386001)**

This is why I can’t store shit\. Honestly his requests are all over the place\.

*📎 1 attachment(s)*

**034.** `07:01` **You**

Yeah a lot of juggling


**035.** `07:02` **Meredith Lamb (+14169386001)**

He can’t even remember the reason


**036.** `07:02` **Meredith Lamb (+14169386001)**

Seriously


**037.** `07:02` **Meredith Lamb (+14169386001)**

But when things change he doesn’t tell me so I have it in my calendar still


**038.** `07:03` **Meredith Lamb (+14169386001)**

Anyway I don’t have to do it


**039.** `07:03` **You**

Kk so that works out head up early I will leave later in day\.


**040.** `07:04` **Meredith Lamb (+14169386001)**

That’s good\. I will clean over lunch hour which will be “normal” and pile stuff in front of ring\. Not out of norm when Andrew makes messes\. He said there are big messes so probably lots of stuff to pile up 🤞


**041.** `07:05` **You**

lol this is slightly silly but sweet at the same time that you would go to this much trouble\.  Very much appreciated will have to make it up to
You\.


**042.** `07:10` **Meredith Lamb (+14169386001)**

You know what I’m missing for you right?


**043.** `07:10` **Meredith Lamb (+14169386001)**

Let’s see how good your memory is\.


**044.** `07:11` **You**

For or from


**045.** `07:11` **Meredith Lamb (+14169386001)**

For


**046.** `07:11` **Meredith Lamb (+14169386001)**

Testing your memory


**047.** `07:11` **Meredith Lamb (+14169386001)**

What will I be missing?


**048.** `07:12` **Meredith Lamb (+14169386001)**

You have no idea\.


**049.** `07:12` **Meredith Lamb (+14169386001)**

Johnny is coming over thurs night


**050.** `07:12` **Meredith Lamb (+14169386001)**

I will no longer be here lol


**051.** `07:13` **You**

Oh shit


**052.** `07:13` **You**

I forgot no stay


**053.** `07:13` **You**

Seriously


**054.** `07:13` **You**

Not joking


**055.** `07:13` **Meredith Lamb (+14169386001)**

LOL NO


**056.** `07:13` **You**

That is so important to you it is important to me too\.


**057.** `07:13` **You**

I totally forgot


**058.** `07:13` **Meredith Lamb (+14169386001)**

No but I will leave him a gift


**059.** `07:14` **You**

🙁 your should stay and go up Friday morning


**060.** `07:14` **Meredith Lamb (+14169386001)**

No it isn’t that important


**061.** `07:14` **Meredith Lamb (+14169386001)**

Mac can FaceTime me


**062.** `07:14` **Meredith Lamb (+14169386001)**

lol


**063.** `07:15` **You**

I definitely need to do something to make that up\.


**064.** `07:16` **Meredith Lamb (+14169386001)**

Just saying\. :\)


**065.** `07:16` **You**

Kk well you think of something


**066.** `07:17` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**067.** `07:18` **You**

You excited
Anyways I can avoid cameras
To come I\. Walks
With you??


**068.** `07:18` **You**

Excited
For dogs\.


**069.** `07:19` **Meredith Lamb (+14169386001)**

If I keep stuff in front of ring it is possible but our stupid side camera is pretty wide


**070.** `07:19` **Meredith Lamb (+14169386001)**

The dogs love the lake side tho


**071.** `07:19` **Meredith Lamb (+14169386001)**

And the driveway will be so buggy


**072.** `07:19` **You**

Kk


**073.** `07:19` **Meredith Lamb (+14169386001)**

May 24 weekend is so bad for black flies every year


**074.** `07:20` **Meredith Lamb (+14169386001)**

They will want to swim a lot


**075.** `07:20` **Meredith Lamb (+14169386001)**

I think it is supposed to rain a lot tho


**076.** `07:21` **Meredith Lamb (+14169386001)**

Which means more bugs


**077.** `07:23` **You**

lol should be interesting


**078.** `07:23` **You**

May have to wash clothes before I come back dog smell will be real lol\.\.


**079.** `07:24` **Meredith Lamb (+14169386001)**

No worries\. We have a laundry room\. It is basically just a house\.


**080.** `07:25` **You**

I figured


**081.** `07:26` **Meredith Lamb (+14169386001)**

We call it a cottage but…


**082.** `07:30` **You**

Yeah I know how the 1% lives\.\. lol


**083.** `07:30` **You**

J/k


**084.** `07:31` **You**

Tbh I am fairly certain we
Could do same thing if we wanted\.\. we thiught about buying a place in Aruba\.\. but that was back when I thought
Things could fix relationships\.


**085.** `07:32` **Meredith Lamb (+14169386001)**

So Mac said she doesn’t even care if I’m not here thurs night\. Rude\.


**086.** `07:32` **Meredith Lamb (+14169386001)**

She’s like “I’m not FaceTiming you”


**087.** `07:32` **You**

Ouch


**088.** `07:32` **Meredith Lamb (+14169386001)**

She’s grumpy


**089.** `07:32` **You**

Ask her to do it for me?? lol


**090.** `07:32` **You**

No dont


**091.** `07:33` **Meredith Lamb (+14169386001)**

lol no


**092.** `07:33` **Meredith Lamb (+14169386001)**

She’s making her smoothie\. Shouldn’t have talked to her prior


**093.** `07:33` **You**

Kk finished double
Workout heading down to get showered  yeah those chia seeds make a difference\.


**094.** `07:35` **Meredith Lamb (+14169386001)**

lol k, I’m going to order him a gift online and then get ready for the day


**095.** `07:35` **You**

Kk chat I\. A bit\.


**096.** `10:46` **Meredith Lamb (+14169386001)**

I couldn’t sense how bothered you were by this\. You can not go and or go for a shorter time if it makes it easier\.


**097.** `10:47` **Meredith Lamb (+14169386001)**

I am going regardless


**098.** `10:48` **You**

I am not bothered\.  J is just lashing out\.\. as much as she says I don’t accept responsibility she definitely doesn’t\.\. I just let her rail at me for like 2 hours she was scraping up all
Kinds
Of shit


**099.** `10:48` **You**

She is a dirty fighter


**100.** `10:48` **You**

Anyways I am fine shutting communication off for the weekend\.


**101.** `10:50` **Meredith Lamb (+14169386001)**

I leave it to you lol


**102.** `10:50` **You**

Yep… I am good here, tonight might be spicy but that is what locks are for\.


**103.** `10:53` **Meredith Lamb (+14169386001)**

Oh boy lol you guys are intense


**104.** `10:54` **You**

You have no idea\.\. she is insanely intense\.\. I almost never fought in relationships before her\.\. super aggressive


**105.** `10:57` **Meredith Lamb (+14169386001)**

I find that a little scary tbh lol


**106.** `10:58` **You**

I mean I have lived with it for 20’years\.


**107.** `13:47` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**108.** `13:47` **You**

Rofl


**109.** `13:49` **Meredith Lamb (+14169386001)**

Story of my life


**110.** `13:53` **Meredith Lamb (+14169386001)**

Um, not sure how you feel about that lol


**111.** `13:54` **Meredith Lamb (+14169386001)**

Looks like Brett is dropping them off tonight


**112.** `13:55` **You**

5 dogs


**113.** `13:55` **You**

Right


**114.** `13:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**115.** `13:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**116.** `13:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**117.** `13:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**118.** `13:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**119.** `13:55` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**120.** `13:55` **Meredith Lamb (+14169386001)**

Yah


**121.** `13:55` **You**

I am sleeping beside you griffon can bite me\.


**122.** `13:55` **You**

Literally


**123.** `13:56` **Meredith Lamb (+14169386001)**

Griffin, Rosie, Bo, Walter and Lisa


**124.** `13:56` **Meredith Lamb (+14169386001)**

Bo and Lisa bark at noises :p


**125.** `13:57` **Meredith Lamb (+14169386001)**

I basically always have kids or dogs lol


**126.** `14:03` **You**

I mean I am good with either kids or dogs


**127.** `14:03` **You**

Or both


**128.** `14:05` **Meredith Lamb (+14169386001)**

Wasn’t really looking to have 5 dogs this weekend but ugh


**129.** `14:06` **You**

It’s fine\. lol we will have fun\.


**130.** `14:13` **Meredith Lamb (+14169386001)**

We will see\. Lol


**131.** `14:13` **Meredith Lamb (+14169386001)**

Kidding


**132.** `14:14` **Meredith Lamb (+14169386001)**

I was actually looking forward to only 3\. Serves me right


**133.** `14:25` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**134.** `14:25` **Meredith Lamb (+14169386001)**

Ok so I couldn’t do it, I’m too anxious about the weather


**135.** `14:25` **Meredith Lamb (+14169386001)**

I think I’m leaving Walt and Lisa here


**136.** `14:25` **Meredith Lamb (+14169386001)**

Brett is ok with it


**137.** `14:26` **Meredith Lamb (+14169386001)**

He contacted me too late\. I’m not mentally prepared to clean with 5 dogs … like HOW


**138.** `15:09` **You**

So is it just big words or stats does that do it too?


**139.** `15:11` **Meredith Lamb (+14169386001)**

All of the above


**140.** `15:15` **You**

Any other subjects history\.\. we could watch jeopardy
Together


**141.** `15:15` **You**

lol


**142.** `15:18` **Meredith Lamb (+14169386001)**

Never gotten into jeopardy lol


**143.** `15:21` **Meredith Lamb (+14169386001)**

Why Mackenzie wants me to go… Andrew is sooooo messy when he does stuff\. I mean he does Reno’s but the collateral damage is usually huge\.

*📎 1 attachment(s)*

**144.** `15:25` **You**

Well I have never messed with building shit but the clean up and the lifting etc\.\. good labour I just worry too much that I don’t know enough I am sure I could figure it out and I have but I don’t like it\.


**145.** `15:26` **Meredith Lamb (+14169386001)**

I am just very relieved not to have 5 dogs\. Feeling a bit drained for that\.


**146.** `15:33` **You**

lol it is a lot of responsibility for sure


**147.** `15:35` **Meredith Lamb (+14169386001)**

And general mess


**148.** `15:35` **You**

Cleaning is easy I will help


**149.** `15:44` **Meredith Lamb (+14169386001)**

Be careful what you volunteer for


**150.** `15:44` **You**

Anything is better than here\.


**151.** `15:45` **Meredith Lamb (+14169386001)**

We can finally play ticket to ride lol


**152.** `15:46` **Meredith Lamb (+14169386001)**

Not as good with 2 ppl but still good


**153.** `15:47` **You**

Yeah I was actually thinking about that


**154.** `15:47` **You**

Last night


**155.** `16:01` **Meredith Lamb (+14169386001)**

Ugh I have volleyball duties 5\-9pm tonight…\.\. so annoyed\.


**156.** `16:57` **You**

Nice


**157.** `16:57` **You**

I will be available to entertain you as needed


**158.** `16:59` **Meredith Lamb (+14169386001)**

My little shadow is coming with me too :p


**159.** `17:17` **You**

Ok so all the entertainment you need lol


**160.** `18:27` **Meredith Lamb (+14169386001)**

On our way to homesense


**161.** `18:28` **You**

for?


**162.** `18:28` **Meredith Lamb (+14169386001)**

Bedrooms for Mac’s bday lol


**163.** `18:28` **You**

lol


**164.** `18:28` **Meredith Lamb (+14169386001)**

And to kill time while she is at vball


**165.** `18:28` **You**

can I bring anything tomorrow\.\. please say yes I want to help


**166.** `18:29` **Meredith Lamb (+14169386001)**

I will think about it\. I mean if there is stuff you need to eat then that but there is a grocery store nearby\.


**167.** `18:30` **You**

Reaction: 🙄 from Meredith Lamb
yeah I as long as there is a path outside of cams I planned to give you some time to yourself each day, you will get sick of me\.\. :\(


**168.** `18:30` **Meredith Lamb (+14169386001)**

Cold pillow lol


**169.** `18:30` **You**

yeah it comes where i go


**170.** `19:15` **Meredith Lamb (+14169386001)**

We had to leave bc we spent too much $


**171.** `19:15` **Meredith Lamb (+14169386001)**

lol


**172.** `19:16` **You**

Surprise


**173.** `19:16` **You**

lol


**174.** `19:16` **Meredith Lamb (+14169386001)**

Mac will be happy


**175.** `19:51` **Meredith Lamb (+14169386001)**

Ps\. I bought new bedding so it’s not weird \(for you or me\)\. I had to get some for renovated bedrooms anyway


**176.** `19:55` **You**

Um that was thoughtful\.  Wouldn’t have thought of that but yeah I guess some weirdness… hmmm that’s gonna fester lol\.


**177.** `19:56` **You**

I will try to think happy thoughts


**178.** `19:57` **Meredith Lamb (+14169386001)**

It’s kind of our second house so…


**179.** `20:04` **You**

I mean it is something you will have to get used to\.


**180.** `20:04` **You**

Goes both ways


**181.** `20:07` **Meredith Lamb (+14169386001)**

I think I will be fine


**182.** `20:07` **Meredith Lamb (+14169386001)**

:\)


**183.** `20:07` **Meredith Lamb (+14169386001)**

Yaye I get to drive an hour home now


**184.** `20:07` **Meredith Lamb (+14169386001)**

Soooooo tired


**185.** `20:14` **You**

Long night and monger day tomorrow yku are going to be exhausted… massage??  Haven’t tried that yet you might enjoy who knows\.


**186.** `21:00` **Meredith Lamb (+14169386001)**

Walking dogs then bed\. Omg considering taking a vacation day tomorrow\. Would that be bad last minute? I’d work Friday\.


**187.** `21:00` **You**

naw do it


**188.** `21:01` **You**

going to bed soon as well\.\. getting up early again tomorrow\.\. all packed though\.


**189.** `21:01` **You**

bought the house tonight


**190.** `21:01` **You**

put 10k down


**191.** `21:01` **Meredith Lamb (+14169386001)**

I thought it was bought


**192.** `21:01` **You**

offer was accepted


**193.** `21:01` **You**

conditions had to be removed


**194.** `21:01` **Meredith Lamb (+14169386001)**

Ah I see


**195.** `21:01` **You**

she almost flipped again today


**196.** `21:01` **You**

spent the entire last night and this morning berating me


**197.** `21:02` **Meredith Lamb (+14169386001)**

😬


**198.** `21:02` **You**

it was fun


**199.** `21:02` **Meredith Lamb (+14169386001)**

Oh man


**200.** `21:02` **You**

still she had an out and she didn't take it


**201.** `21:02` **You**

so\.\. I told her I am not wearing this shit rest of my life


**202.** `21:03` **Meredith Lamb (+14169386001)**

Hopefully she likes it eventually but it is a massive change


**203.** `21:03` **You**

no she loves the house\.\. loves the idea of going home\.\. just Gracie


**204.** `21:03` **You**

anyways


**205.** `21:03` **You**

think about what you need tomorrow\.  take an SDO\.\. although I think Carolyn was going to reach out for something


**206.** `21:03` **You**

think about how I can pay you back for being awesome\.


**207.** `21:04` **Meredith Lamb (+14169386001)**

Carolyn reached out today


**208.** `21:04` **Meredith Lamb (+14169386001)**

Something else?


**209.** `21:04` **You**

I dunno\.


**210.** `21:04` **You**

yeah


**211.** `21:04` **You**

end of day


**212.** `21:04` **You**

we talked about roll over


**213.** `21:04` **Meredith Lamb (+14169386001)**

Oh blech k


**214.** `21:04` **You**

she might ask you a question\.


**215.** `21:04` **You**

I dunno\.\.


**216.** `21:04` **You**

has to do with OC


**217.** `21:04` **Meredith Lamb (+14169386001)**

Oh weird ok


**218.** `21:05` **You**

Erin was a git this afternoon again


**219.** `21:05` **Meredith Lamb (+14169386001)**

Re: ai??


**220.** `21:05` **You**

I think she used the word neophyte too much\.\.


**221.** `21:05` **You**

guessing she looked that bad boy up


**222.** `21:05` **Meredith Lamb (+14169386001)**

lol


**223.** `21:05` **You**

Reaction: 😂 from Meredith Lamb
anyways she def needs to chill the fuck out lol\.


**224.** `21:05` **Meredith Lamb (+14169386001)**

I need t look up “git”


**225.** `21:05` **You**

its british


**226.** `21:06` **You**

or australian or something


**227.** `21:06` **Meredith Lamb (+14169386001)**

Erin has never been ‘chill’


**228.** `21:06` **You**

well she needs to just sit back and stop talking then and listen and learn\.


**229.** `21:06` **You**

she keeps saying she knows what to do\.\. she doesn


**230.** `21:06` **You**

t


**231.** `21:06` **Meredith Lamb (+14169386001)**

Why is she even in the meetings?


**232.** `21:06` **You**

Because they have "capacity"


**233.** `21:07` **Meredith Lamb (+14169386001)**

Oh lol


**234.** `21:07` **Meredith Lamb (+14169386001)**

That’s what I need\. Capacity


**235.** `21:07` **You**

yeah that is what i need


**236.** `21:07` **You**

in another job


**237.** `21:07` **Meredith Lamb (+14169386001)**

She will chill when I get there


**238.** `21:08` **You**

Reaction: 👎 from Meredith Lamb
Reaction: 👍 from Scott Hicks
once I leave DSM  whooo


**239.** `21:08` **Meredith Lamb (+14169386001)**

As much as Erin can chill


**240.** `21:08` **You**

neutral


**241.** `21:08` **You**

i forgot to check today


**242.** `21:09` **Meredith Lamb (+14169386001)**

Shit I have to stay up until Bo gets here gah


**243.** `21:09` **You**

sucks how long


**244.** `21:09` **Meredith Lamb (+14169386001)**

Not sure\.


**245.** `21:10` **You**

so was thinking of leaving after CM takes me to an intimate coffee get together\.\.\. ROFL\.\. cannot even type that without laughing\.


**246.** `21:12` **You**

there was an OEB manager job posted\.


**247.** `21:12` **You**

I could go for that


**248.** `21:13` **Meredith Lamb (+14169386001)**

Why leave?


**249.** `21:13` **You**

safer


**250.** `21:13` **Meredith Lamb (+14169386001)**

Safer huh?


**251.** `21:13` **Meredith Lamb (+14169386001)**

Is tomorrow your Carolyn thing?


**252.** `21:13` **You**

yeah the intimate coffee rendez\-vous


**253.** `21:13` **You**

see that is better


**254.** `21:13` **You**

lol


**255.** `21:13` **Meredith Lamb (+14169386001)**

Omg


**256.** `21:14` **You**

she is actually worried I am going to leave


**257.** `21:14` **You**

and she wants to figure out what is wronge


**258.** `21:14` **You**

lol


**259.** `21:14` **You**

imma tell her about us\.\.\. I feel like that is the play


**260.** `21:15` **Meredith Lamb (+14169386001)**

Yeah right you would never


**261.** `21:15` **Meredith Lamb (+14169386001)**

You are way smarter than that


**262.** `21:16` **You**

I will leave her a trail of hints\.\. in the form of riddles that will drive her insane\!\!


**263.** `21:17` **Meredith Lamb (+14169386001)**

Be nice to her\. I think she worries too much about you though\. Seriously


**264.** `21:17` **You**

I will tell her I have a crush on someone \- unrequited love \- something that can never be\!


**265.** `21:17` **Meredith Lamb (+14169386001)**

🙄


**266.** `21:17` **Meredith Lamb (+14169386001)**

Your situation isn’t even close to that\.


**267.** `21:17` **You**

\.\.\.\.\. \(negative fun\) \.\.\.\.\.


**268.** `21:18` **You**

lol


**269.** `21:18` **You**

I thought you would say something like \- she will probably think it is her\.


**270.** `21:18` **You**

then it would have been funny


**271.** `21:18` **Meredith Lamb (+14169386001)**

Haha


**272.** `21:18` **You**

man so much fun to be had\.\.


**273.** `21:19` **You**

but yea thnking of leaving right after that if that is ok\.


**274.** `21:19` **You**

or can wait till later


**275.** `21:19` **You**

or can wait till dark\.\. lol


**276.** `21:19` **Meredith Lamb (+14169386001)**

What time are you guys having coffee?


**277.** `21:20` **Meredith Lamb (+14169386001)**

I assumed morning\.


**278.** `21:20` **You**

lunch


**279.** `21:20` **Meredith Lamb (+14169386001)**

Coffee = morning


**280.** `21:20` **Meredith Lamb (+14169386001)**

Oh


**281.** `21:20` **You**

lunch


**282.** `21:20` **You**

or dinner as they say on east coast


**283.** `21:20` **Meredith Lamb (+14169386001)**

What about your afternoon meeting


**284.** `21:20` **Meredith Lamb (+14169386001)**

I’m confused


**285.** `21:20` **You**

cancelling


**286.** `21:21` **You**

team meeting


**287.** `21:21` **Meredith Lamb (+14169386001)**

Really


**288.** `21:21` **You**

nothing to share


**289.** `21:21` **Meredith Lamb (+14169386001)**

lol


**290.** `21:21` **You**

except people complaining about seating


**291.** `21:21` **You**

and other bullshit


**292.** `21:21` **Meredith Lamb (+14169386001)**

That makes my day a bit less


**293.** `21:22` **You**

hm?


**294.** `21:22` **You**

i can wait until later if you want


**295.** `21:22` **You**

oh you mean to not take sdo


**296.** `21:22` **Meredith Lamb (+14169386001)**

No no


**297.** `21:23` **You**

and work


**298.** `21:23` **Meredith Lamb (+14169386001)**

Yeah


**299.** `21:23` **You**

yeah yeah do that\.,


**300.** `21:23` **You**

if you want


**301.** `21:23` **Meredith Lamb (+14169386001)**

I still have to get up early


**302.** `21:24` **You**

4 am here


**303.** `21:24` **Meredith Lamb (+14169386001)**

That’s just dumb


**304.** `21:24` **Meredith Lamb (+14169386001)**

lol


**305.** `21:24` **You**

feels awesome though


**306.** `21:24` **You**

after the sauna\.\. like 20\-30 mins


**307.** `21:24` **You**

amazing


**308.** `21:25` **Meredith Lamb (+14169386001)**

Sure until you get all tired and grumpy later on


**309.** `21:25` **You**

I haven't been eating


**310.** `21:25` **You**

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


**311.** `21:25` **You**

although I had something at the mgr meeting


**312.** `21:25` **You**

I was fine monday\.\. cranky tuesday\.


**313.** `21:25` **You**

waves


**314.** `21:26` **Meredith Lamb (+14169386001)**

Maybe slow your roll a bit


**315.** `21:26` **Meredith Lamb (+14169386001)**

You are going to do something stupid like leave your job


**316.** `21:26` **Meredith Lamb (+14169386001)**

Ughhhhhhh


**317.** `21:27` **You**

I cannot slow any rolls


**318.** `21:27` **You**

then I wouldn't be me


**319.** `21:27` **You**

I would be a lamer version of me\.


**320.** `21:27` **You**

who slows on rolls all the time\.


**321.** `21:27` **You**

\.\.\.\.\.\. lame


**322.** `21:28` **You**

Leaving my job wouldn't be stupid\.\.


**323.** `21:28` **You**

it might be awesome\.


**324.** `21:28` **Meredith Lamb (+14169386001)**

Maybe\.


**325.** `21:29` **Meredith Lamb (+14169386001)**

Bo…


**326.** `21:29` **You**

lol


**327.** `21:30` **You**

no dog yet


**328.** `21:37` **Meredith Lamb (+14169386001)**

No he’s here now


**329.** `21:39` **You**

yay\.\. just looking at job postings while I waited for you to come back


**330.** `21:40` **Meredith Lamb (+14169386001)**

Don’t you think we have enough change going on? Lol


**331.** `21:40` **You**

mmmmm


**332.** `21:43` **You**

https://www\.linkedin\.com/jobs/search/?currentJobId=4217715683&geoId=100761630&keywords=AI%20Management&origin=JOB\_SEARCH\_PAGE\_SEARCH\_BUTTON&originalSubdomain=ca&refresh=true


**333.** `21:44` **Meredith Lamb (+14169386001)**

AI management


**334.** `21:44` **You**

:\)


**335.** `21:44` **You**

the VP product role looks fun


**336.** `21:47` **You**

https://www\.linkedin\.com/jobs/view/4221714781


**337.** `21:49` **You**

hm I could go work at ecobee with Lisa Scott


**338.** `21:50` **Meredith Lamb (+14169386001)**

How about you just get your life settled first?


**339.** `21:50` **Meredith Lamb (+14169386001)**

lol I will not stop on this


**340.** `21:52` **You**

Relentless


**341.** `21:52` **You**

challenge accepted\.


**342.** `21:52` **Meredith Lamb (+14169386001)**

We can talk about it this weekend


**343.** `21:53` **You**

ok how about you go to bed now hon and I will go finish packing and getting ready myself\.\. fast I go to sleep, fast I wake up, work out, work, have a fantastic little coffee break, then drive for 2\.5 hours then see you\.\.


**344.** `21:53` **You**

:\)


**345.** `21:53` **Meredith Lamb (+14169386001)**

I’m going to watch the first bit of handmaids tale and then yeah bed


**346.** `21:54` **Meredith Lamb (+14169386001)**

Can’t stop yawning


**347.** `21:54` **Meredith Lamb (+14169386001)**

Making my list of things not to forget


**348.** `21:54` **You**

kk Love you\.\. don't stay up too late\.


**349.** `21:54` **You**

I can pick things up you forget as well


**350.** `21:54` **Meredith Lamb (+14169386001)**

No like keys, dump card, etc


**351.** `21:54` **Meredith Lamb (+14169386001)**

lol power cord


**352.** `21:54` **You**

rofl


**353.** `21:54` **Meredith Lamb (+14169386001)**

Important stuff


**354.** `21:54` **You**

fair enough


**355.** `21:55` **Meredith Lamb (+14169386001)**

Bo’s food


**356.** `21:55` **You**

see you are making a list now\.\. already on top of it


**357.** `21:55` **Meredith Lamb (+14169386001)**

Fresh coffee, wine


**358.** `21:55` **Meredith Lamb (+14169386001)**

These are plate priorities


**359.** `21:55` **You**

i am bringing tequila


**360.** `22:06` **Meredith Lamb (+14169386001)**

Rose?


**361.** `22:07` **Meredith Lamb (+14169386001)**

I am not going to get super wasted this weekend lol responsibilities \(dogs\)


**362.** `22:07` **You**

Rose


**363.** `22:07` **Meredith Lamb (+14169386001)**

Plus I’m not feeling as stressed


**364.** `22:07` **You**

Reaction: 😂 from Meredith Lamb
I didn’t say I was going to Lou d it


**365.** `22:07` **You**

Pound it


**366.** `22:07` **You**

lol


**367.** `22:07` **Meredith Lamb (+14169386001)**

Because Andrew has been away\. Been calmer


**368.** `22:07` **You**

I would prefer to stay relatively sober tbh


**369.** `22:08` **You**

Relatively


**370.** `22:08` **You**

Still need some courage and all


**371.** `22:08` **Meredith Lamb (+14169386001)**

It’s hard not to drink at a cottage\. But I do it a lot


**372.** `22:08` **You**

I think it would be relaxing\.\.


**373.** `22:09` **Meredith Lamb (+14169386001)**

It can be except I do all the cleaning lol


**374.** `22:09` **You**

Not like at home in the basement in the dark


**375.** `22:09` **Meredith Lamb (+14169386001)**

And Andrew is a very messy and pack rat type person\.


**376.** `22:09` **Meredith Lamb (+14169386001)**

I like the dark\!


**377.** `22:10` **You**

Well then we have some work to do\.\. since I won’t be working out I will be cleaning


**378.** `22:11` **Meredith Lamb (+14169386001)**

You could work out in the basement\. I might have like 10 lb or 15 lb weights 😂


**379.** `22:11` **You**

This will work


**380.** `22:11` **You**

Those


**381.** `22:11` **You**

Been studying alternative approaches


**382.** `22:11` **You**

Light weights and like 100 reps can be amazing


**383.** `22:12` **Meredith Lamb (+14169386001)**

There you go


**384.** `22:12` **Meredith Lamb (+14169386001)**

lol


**385.** `22:12` **You**

Awesome done\.\.


**386.** `22:12` **Meredith Lamb (+14169386001)**

k, I’m going to set my alarm now for a ridiculously early time


**387.** `22:12` **Meredith Lamb (+14169386001)**

Then watch the beginning of handmaids tale


**388.** `22:12` **Meredith Lamb (+14169386001)**

Then pass out


**389.** `22:12` **You**

I will get up and work out yku will sleep and if you tell me what you like I can try to make you breakfast


**390.** `22:13` **You**

Kk you go so that


**391.** `22:13` **Meredith Lamb (+14169386001)**

Sleep with 3 dogs? LOL


**392.** `22:13` **You**

Hrm…


**393.** `22:13` **Meredith Lamb (+14169386001)**

I will nap


**394.** `22:13` **Meredith Lamb (+14169386001)**

lol


**395.** `22:14` **You**

We get cleaning done we can do whatever your hearts desire


**396.** `22:17` **Meredith Lamb (+14169386001)**

Set up my bra pong game?


**397.** `22:18` **Meredith Lamb (+14169386001)**

lol


**398.** `22:19` **Meredith Lamb (+14169386001)**

k, I’m going to watch tv for real\. Have a good sleep, I love you and am very much looking forward to spending time with you… not the ring camera part but all the rest :p 😍


**399.** `22:19` **Meredith Lamb (+14169386001)**

Be nice to Carolyn


**400.** `22:20` **You**

I will and I want to play that trains game


**401.** `22:20` **You**

And bra pong


**402.** `22:20` **You**

Just to test it out


**403.** `22:20` **You**

Love you and looking very much forward just to being with you\.\. nite ❤️❤️❤️❤️


