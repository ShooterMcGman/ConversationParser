# Daily Conversation: 2025-04-28 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-28 |
| **Day** | Monday |
| **Week** | 3 |
| **Messages** | 110 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-28T01:35 - 2025-04-28T21:19 |

## 📝 Daily Summary

This day contains **110 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `01:35` **You**

All safe?


**002.** `01:35` **Meredith Lamb (+14169386001)**

Oh right forgot\. Yes\! Lol


**003.** `01:36` **Meredith Lamb (+14169386001)**

All Mackenzie said was “bruh”…


**004.** `01:37` **You**

Rofl


**005.** `01:37` **You**

Have a good sleep chat in morning


**006.** `01:38` **Meredith Lamb (+14169386001)**

💕


**007.** `06:37` **You**

Morning sunshine boy did I pass out hard oof hope today goes ok I know it isn’t going to be a ton of fun\.


**008.** `06:48` **Meredith Lamb (+14169386001)**

Morning xo Omg my throat…… swear to god\.


**009.** `06:50` **Meredith Lamb (+14169386001)**

Throat so intense\. Like last night 😋


**010.** `06:57` **You**

Rofl this the best and the most insane I think I have ever felt\.  Man\.\. well I am up and grabbing a shower and then something from downstairs likely a coffee\.  Anything you want or need?  Really sorry about throat I have more losanges\.


**011.** `06:57` **You**

Or Advil cold


**012.** `06:58` **You**

I have vitamin c packets vitamin d and zinc that is supposed to help lessen and ouch back on symptoms\.


**013.** `06:59` **You**

Reaction: 😂 from Meredith Lamb
Now crossing fingers that I dot t have an awkward conversation with Carolyn this morning\.


**014.** `07:06` **Meredith Lamb (+14169386001)**

I’m ok thanks\. You and your pharmacy\. Lol


**015.** `07:09` **You**

Btw I do want to chat
Sometime about stuff making you happy and what I can do\.  Again 47 seems to take away any reservations about talking about certain topics\.


**016.** `07:10` **You**

Btw talking with Carolyn now on teams\.


**017.** `07:18` **Meredith Lamb (+14169386001)**

Someone is listening to metal music near me or foo fighters maybe? You don’t hear that?


**018.** `07:20` **Meredith Lamb (+14169386001)**

>
Of course, we have lots of time \(2 yrs :p\)\. Please know you make me so happy\. The feel of you, the taste …\. It’s really wild\. I will think about it all day and it will be super awkward\. lol

*💬 Reply*

**019.** `07:25` **You**

I don’t hear anything, and I appreciate the sentiment\.\.
Pretty much everything about you drives me nuts… especially the kissing which is why I say I don’t think that will ever get old\.\. feels more intimate for some reason\. Yeah we can talk about other stuff, but I am glad you feel that way because I do too\.


**020.** `07:32` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Same, I am at ease the minute I’m in the same room with you\. The connection we have makes everything a little haywire\. In a good way\. 💋


**021.** `07:50` **Meredith Lamb (+14169386001)**

Girl that bought our home\. Grew up with her so I get to see photos a lot\.

*📎 1 attachment(s)*

**022.** `08:00` **You**

That’s really nice you can tell you have a deep connection to your hometown\.\. I would really like to go there with you\.  Just walk around and listen to you tell me stories\.\. ☺️\. You can tell they mean a lot to you when you relive them for me\.


**023.** `08:01` **You**

I thought your screenshot was beautiful\. Can imagine what the rest is like\.


**024.** `08:02` **Meredith Lamb (+14169386001)**

For the record I am incredible freezing and achy\. Full out cold\. Lol this is hilarious … 2 days and boom\. Science, wow\.


**025.** `08:03` **You**

Just stay home call in remotely


**026.** `08:03` **You**

Seriously


**027.** `08:04` **You**

If it is hitting you that hard\.\. I mean I eat 3 Advil extra str
Every six hours to kick the shit out of this and two packs kf extreme c per day/


**028.** `08:05` **Meredith Lamb (+14169386001)**

I have a low immune system right now\. Stress and “stuff” lol


**029.** `08:05` **Meredith Lamb (+14169386001)**

Are you in your room


**030.** `08:06` **You**

Yeah I am totally to blame my immune system is pretty solid on the worst of days\.


**031.** `08:06` **Meredith Lamb (+14169386001)**

The iron is missing from this room


**032.** `08:06` **Meredith Lamb (+14169386001)**

Argh


**033.** `08:11` **You**

I have one here already heated up


**034.** `08:11` **You**

Should I bring it over


**035.** `08:11` **Meredith Lamb (+14169386001)**

You could put it outside my door


**036.** `08:11` **You**

lol ok


**037.** `08:11` **You**

203


**038.** `08:11` **You**

Give 4
Mins


**039.** `08:11` **Meredith Lamb (+14169386001)**

So the heavy metal just stopped lol


**040.** `08:12` **Meredith Lamb (+14169386001)**

Mac: bruuuh


**041.** `08:14` **You**

Ok


**042.** `08:14` **You**

It is out there


**043.** `08:14` **You**

Only country playing in my room I don’t know about yours ☺️


**044.** `08:15` **You**

Coyote in a field of wolves right now\.


**045.** `08:16` **Meredith Lamb (+14169386001)**

>
Thank u\!

*💬 Reply*

**046.** `08:16` **You**

Np


**047.** `08:44` **You**

Heading down for coffee then likely driving I\. Figured you would take your own vehicle\.


**048.** `08:45` **Meredith Lamb (+14169386001)**

Yeah\. Had to get Mac coffee :p


**049.** `08:52` **You**

Ah ok I forgot my phone


**050.** `08:52` **You**

Leaving now was going to crow place for coffee I guess


**051.** `08:58` **Meredith Lamb (+14169386001)**

I’m taking a little detour to look around and then going


**052.** `08:58` **Meredith Lamb (+14169386001)**

Been a few years since I’ve been here


**053.** `09:14` **Meredith Lamb (+14169386001)**

This is a little weird being back after 10 years\. Yeah I could move back here\-ish\. Lol … ish\.


**054.** `09:15` **Meredith Lamb (+14169386001)**

Difficult if I have a F’ing cottage near north bay tho


**055.** `09:22` **Meredith Lamb (+14169386001)**

Where are we ugh


**056.** `09:28` **Meredith Lamb (+14169386001)**

I opened my laptop and found the rm \#\. I need a work phone gah


**057.** `09:57` **You**

lol sorry I ended up getting waylaid missed all of this\.\. btw going to try to use a lot of big
Words today\.


**058.** `14:20` **You**

You feeling ok


**059.** `14:32` **You**

You look so unhappy and I feel soooooooooo guilty


**060.** `14:32` **Meredith Lamb (+14169386001)**

Defend ok


**061.** `14:32` **Meredith Lamb (+14169386001)**

\*define


**062.** `14:36` **You**

I feel soooooo bad I am a bad bad bad person


**063.** `14:41` **Meredith Lamb (+14169386001)**

It’s fine\. It’s worth it\. If I didn’t have these lozenges I’d be dying tho


**064.** `14:46` **You**

It will be more worth it


**065.** `16:44` **You**

At hotel going up to room to rest for a bit I have to grab a drink with Sophear at 8 but otherwise staying in room and shouldn’t be a long drink
Out\.


**066.** `16:48` **Meredith Lamb (+14169386001)**

I’m having some neocitran and then going to nap\. 😴


**067.** `16:51` **Meredith Lamb (+14169386001)**

I feel like I have Covid btw\. Lol it’s in my chest now…


**068.** `16:52` **You**

Omg :\( I didn’t get that at all\.


**069.** `16:52` **You**

I mean a little cough nothing more


**070.** `16:52` **You**

But again I hammered vitamin c and water


**071.** `16:52` **You**

I had to stop for restroom like 25 times on way to Detroit


**072.** `16:52` **Meredith Lamb (+14169386001)**

It’s fine\. Just tired\.


**073.** `16:53` **You**

I feel like such a selfish ass I should have stayed home and just saw you on Sunday\.


**074.** `16:53` **Meredith Lamb (+14169386001)**

I would have been upset if you did that


**075.** `16:53` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
No winning lol


**076.** `16:54` **You**

Reaction: 👍 from Meredith Lamb
Ok well depending on how long you sleep I might see you before I go out\. I am setting up the couch for us to actually watch something and for you to be able to lay down with your head in my lap on a pillow and sleep or watch but just want to make
You feel better


**077.** `16:57` **Meredith Lamb (+14169386001)**

k\.\.


**078.** `17:01` **You**

If you want me to poke you after a certain time I will do that as well let me know I will be just relaxing in my
Room\.


**079.** `17:54` **You**

Reaction: 😮 from Meredith Lamb
Fack j called more fucking separation discussions\.  I told her to take it to a lawyer to see if it is fair


**080.** `17:54` **You**

Soo tired of this shit


**081.** `18:29` **You**

Reaction: ❤️ from Meredith Lamb
Going to meet sophear at 7 instead hoping to end it earlier so I can spend more time with you\.


**082.** `18:46` **You**

Reaction: ❤️ from Meredith Lamb
Just been sitting here listening to the mix tape thinking about you since I got back\.  There are so many thing is wish\.\. but mostly I wish I was the one that read your blog and reached out…\.\. I know it is a pointless wish but I wish it anyways\.


**083.** `18:49` **Meredith Lamb (+14169386001)**

Just woke up bc of Mackenzie\. She is so loud\.


**084.** `18:49` **Meredith Lamb (+14169386001)**

Argh


**085.** `18:50` **Meredith Lamb (+14169386001)**

Going to lay here half asleep and eventually have a hot shower\.


**086.** `18:51` **Meredith Lamb (+14169386001)**

>
Ditto\.

*💬 Reply*

**087.** `18:51` **You**

Gah I hate feeling like that\.\. so much I want to do with you\.


**088.** `18:51` **Meredith Lamb (+14169386001)**

I might need some more of your cepacols lol


**089.** `18:52` **Meredith Lamb (+14169386001)**

>
Like…\.\. lol

*💬 Reply*

**090.** `18:52` **You**

I mean with you not to you\.\. although that to


**091.** `18:52` **You**

Just make our own memories


**092.** `18:52` **You**

So jealous


**093.** `18:53` **You**

It is stupid


**094.** `18:53` **Meredith Lamb (+14169386001)**

We will absolutely do that\. And hopefully it will be outside of work lol


**095.** `18:54` **You**

Hope so\.


**096.** `18:55` **Meredith Lamb (+14169386001)**

So are you leaving now?


**097.** `18:56` **Meredith Lamb (+14169386001)**

It’s almost 7


**098.** `18:56` **You**

Yeah I am heading downstairs but if you are decent I could use a hug lol\.


**099.** `18:57` **Meredith Lamb (+14169386001)**

I am in bed with Mac…\. After?


**100.** `18:57` **Meredith Lamb (+14169386001)**

She’s ordering food


**101.** `18:58` **You**

lol yeah I have something I want to do with you later will tell you about it then\.  Will let you know when I am back enjoy your super and your time with Max


**102.** `18:58` **You**

Mac


**103.** `18:58` **Meredith Lamb (+14169386001)**

K love you


**104.** `18:58` **You**

Love you too\. ❤️❤️❤️❤️


**105.** `21:10` **You**

Hey I am back you still awake lol?


**106.** `21:11` **Meredith Lamb (+14169386001)**

Yeah did some emails and watching a documentary on my phone now


**107.** `21:11` **You**

Nice well the bolt
Is
Over I\. The door I am just going to jump in the shower you are welcome
To
Come over whenever
You want\.


**108.** `21:18` **You**

Are you here already


**109.** `21:19` **Meredith Lamb (+14169386001)**

lol yah


**110.** `21:19` **You**

Ok let me jump in shower I will be quick damn that was fast


