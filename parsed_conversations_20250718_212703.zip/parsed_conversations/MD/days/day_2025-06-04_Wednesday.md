# Daily Conversation: 2025-06-04 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-04 |
| **Day** | Wednesday |
| **Week** | 8 |
| **Messages** | 543 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-04T04:29 - 2025-06-04T22:12 |

## 📝 Daily Summary

This day contains **543 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:29` **You**

lol u know I always thought admired was an odd word to choose\.  Kind of like saying someone has a nice personality for lack of a better reference to call out\.  But I have to say in all honesty I admire you tremendously more so the more I learn about you and your life\.  You have maximized what life has to offer for all those around you and just made it “better”\. For Andrew to call you selfish is such an injustice because to me you are selfless\.  You have lived your life not only for yourself but both for those most important to you, as well as others not so close, always willing to give your time, help, support etc\.  So odd word or not Mer I admire you so much, it makes me want to be more like you in some ways\.  And I never thought I would be lucky enough to be in a relationship with someone like you\.


**002.** `04:31` **You**

I am up and going to crush it\. One
More cycle down will have to see if status photo update is worth it today or not\.  Love you\!\!\!\!


**003.** `04:32` **You**

Btw me wanting to be away from you at work is natural it is an out of site out of mind thing\.\. nothing g more\.


**004.** `04:33` **You**

Additionally please think about what I suggested re verbalizing\.  This would be very uncomfortable for me too\.  But I think it might be worth trying perhaps\.\. we can always turf it if we want\.  I mean it could be a while until we get the opportunity so maybe take some
Time to think on it\.


**005.** `05:44` **You**

Gl with your workout this morning\.


**006.** `06:19` **Meredith Lamb (+14169386001)**

>
Well it is the right word\. I’m more talking about your brain and work style with that comment but also the way everyone went to you for advice, help etc\.
I am just getting up because I’m going to sleep a bit longer on wfh days I’ve decided\. lol

*💬 Reply*

**007.** `06:20` **You**

Rofl I get that sleep\.\. love you chat later just in the middle of a set\.\.


**008.** `06:22` **You**

Whatever it was you noticed about me I am just glad you did\.


**009.** `06:30` **Meredith Lamb (+14169386001)**

k, slept until 6\.30\. NOW I am getting up :\)


**010.** `06:31` **You**

ROFL


**011.** `06:31` **You**

❤️


**012.** `06:31` **Meredith Lamb (+14169386001)**

Reaction: 🫠 from Scott Hicks
>
I noticed lots of things\. I can list them out for you sometime later\. Lol

*💬 Reply*

**013.** `06:32` **You**

So did I


**014.** `06:33` **Meredith Lamb (+14169386001)**

My sister has been oddly silent to me lately\. Now I know why\. I actually don’t think I told her about you bc she has been leaving me alone\. No drunken messaging\. lol

*📎 1 attachment(s)*

**015.** `06:34` **You**

ROFL i think you told me yoj dodnt plan on telling her at one point


**016.** `06:34` **Meredith Lamb (+14169386001)**

Haha eventually but yeah we can be a drunk mess together sometimes


**017.** `06:35` **Meredith Lamb (+14169386001)**

So if we are chatting while drinking … well, things come out inevitably


**018.** `06:35` **Meredith Lamb (+14169386001)**

lol


**019.** `06:37` **You**

Will look forward to seeing that sometime\.


**020.** `06:40` **You**

If I give
You An update
Photo I want one back


**021.** `06:44` **Meredith Lamb (+14169386001)**

So I was a bitch this morning bc I have no idea what time Andrew got home\.


**022.** `06:44` **You**

???


**023.** `06:44` **You**

I thought you gave zero shits lol


**024.** `06:45` **Meredith Lamb (+14169386001)**

I do however if he is doing something, it is annoying that it is taking into taxes time\.


**025.** `06:46` **You**

That is more than fair


**026.** `06:46` **Meredith Lamb (+14169386001)**

Me: where were you last night?


**027.** `06:46` **Meredith Lamb (+14169386001)**

Him: no response


**028.** `06:46` **Meredith Lamb (+14169386001)**

lol


**029.** `06:46` **You**

Rofl


**030.** `06:46` **You**

Interesting


**031.** `06:46` **You**

Check your ring


**032.** `06:46` **You**

It will tell you


**033.** `06:46` **Meredith Lamb (+14169386001)**

So i let dogs out and go ANDREW


**034.** `06:46` **You**

What time


**035.** `06:47` **Meredith Lamb (+14169386001)**

He sighed “I had a conference yday and then a happy hour thing and then 4 of us went out drinking”


**036.** `06:47` **Meredith Lamb (+14169386001)**

That’s all I got\. Lol


**037.** `06:47` **You**

lol ok


**038.** `06:47` **You**

Sounds like a safe story


**039.** `06:48` **Meredith Lamb (+14169386001)**

Haha totally


**040.** `06:49` **Meredith Lamb (+14169386001)**

Checked ring


**041.** `06:49` **Meredith Lamb (+14169386001)**

He came home at 3am


**042.** `06:49` **Meredith Lamb (+14169386001)**

So this will make me life easier as long as he gets the taxes done


**043.** `06:49` **You**

Rofl


**044.** `06:49` **You**

Sounds like more than drinking


**045.** `06:49` **You**

Since he apparently doesnt


**046.** `06:49` **You**

lol


**047.** `06:50` **You**

Maybe Let’s not tit for tat today


**048.** `06:50` **You**

Though


**049.** `06:51` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**050.** `06:51` **Meredith Lamb (+14169386001)**

lol


**051.** `06:51` **Meredith Lamb (+14169386001)**

I think I will keep the screenshot for the future tho


**052.** `06:52` **Meredith Lamb (+14169386001)**

I’m stupid bc I wouldn’t have checked if you didn’t say to lol


**053.** `06:52` **Meredith Lamb (+14169386001)**

Dumb


**054.** `06:52` **Meredith Lamb (+14169386001)**

Having coffee


**055.** `06:52` **You**

lol hope this doesn’t affect your day too much


**056.** `06:53` **Meredith Lamb (+14169386001)**

I really don’t care I just need taxes done\. I was looking at rentals yday but have no clue what the f I can do


**057.** `06:53` **You**

Yeah I get your frustration\.\. not sure what your day is like but if you want to chat later on comp I can since it is well I guess the second last day you work
For me lol


**058.** `06:54` **Meredith Lamb (+14169386001)**

I think my day is nuts but not 100%\. I always have time tho


**059.** `06:54` **Meredith Lamb (+14169386001)**

Soon I will have nooooooooo meetings lol


**060.** `06:55` **Meredith Lamb (+14169386001)**

Going to be so weird


**061.** `06:55` **Meredith Lamb (+14169386001)**

I will get to actually work again


**062.** `06:55` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/0qmhTHMVxnXRmT5N92wTD9?si=\-\_X1VWFFQzSn\-2\_ZvYQITw
I can’t stop listening to this song the last few days


**063.** `06:56` **You**

Guessing I am not getting a status shot booo


**064.** `06:58` **Meredith Lamb (+14169386001)**

I will later\. I’m taking photos everyday


**065.** `06:58` **Meredith Lamb (+14169386001)**

It’s just part of what I do


**066.** `06:58` **Meredith Lamb (+14169386001)**

I haven’t started yet\! Late today


**067.** `06:58` **Meredith Lamb (+14169386001)**

Still drinking coffee and writing


**068.** `06:59` **Meredith Lamb (+14169386001)**

Ps\. I told Ehsan yday


**069.** `07:00` **You**

What did he say


**070.** `07:00` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**071.** `07:00` **Meredith Lamb (+14169386001)**

Same old\. Sorry\. Sounds like role move is a good move for now\. You know, supportive stuff


**072.** `07:00` **You**


*📎 1 attachment(s)*

**073.** `07:00` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**074.** `07:01` **You**

Reaction: 😢 from Meredith Lamb
1st back shot I think my left shoulder is fucked


**075.** `07:01` **You**

Reaction: 😮 from Meredith Lamb
lol I might need physio


**076.** `07:01` **You**

>
When he hears the second part
Later he will give us both never ending amounts of shit

*💬 Reply*

**077.** `07:02` **Meredith Lamb (+14169386001)**

My time hop today… 6 years ago today\. I was still working out … started to go to shit about a year after this\.

*📎 1 attachment(s)*

**078.** `07:03` **You**

>
Globes and everything\!

*💬 Reply*

**079.** `07:03` **Meredith Lamb (+14169386001)**

Suicides\. I did these 2 days ago and almost died

*📎 1 attachment(s)*

**080.** `07:03` **You**

Easy to get back\.\. and those are HARD\.


**081.** `07:03` **Meredith Lamb (+14169386001)**

>
I hate physio\!\!

*💬 Reply*

**082.** `07:03` **You**

I dun mind


**083.** `07:04` **Meredith Lamb (+14169386001)**

>
Omg he won’t be the only one\.

*💬 Reply*

**084.** `07:05` **You**

Yeah I know idc honestly\.\.like truly as long as our jobs are safe and our families know\.\. I will just be looking forward to more and more freedom as we go forward\.


**085.** `07:05` **You**

That being said


**086.** `07:05` **You**

The people that know me the best


**087.** `07:05` **You**

Even Carolyn


**088.** `07:05` **You**

Will be very happy for me I am absolutely sure of it


**089.** `07:09` **Meredith Lamb (+14169386001)**

I hope so\.


**090.** `07:10` **You**

Reaction: 👍 from Meredith Lamb
Kk going to hit sauna and get home\.


**091.** `07:11` **You**

Reaction: 😂 from Meredith Lamb
My day tomorrow will be fucked it good\. I have to bring
Jaimie to airport leaving at 4:30 am workout on way back maddie to school packing and dog watching gonna be a great day and weekend lol\.\.


**092.** `07:12` **Meredith Lamb (+14169386001)**

She needs to learn how to drive and park or take an uber\. Just saying\.


**093.** `07:12` **Meredith Lamb (+14169386001)**

lol


**094.** `07:14` **You**

Yeah and I have to pick her up at midnight on Monday


**095.** `07:14` **You**

Fucking stupid


**096.** `07:23` **Meredith Lamb (+14169386001)**

Sorry but 🙄


**097.** `07:23` **Meredith Lamb (+14169386001)**

lol


**098.** `07:24` **Meredith Lamb (+14169386001)**

Andrew and I never picked each other up \(probably not a good thing in retrospect lol just seemed unnecessary\)


**099.** `07:45` **You**

Yeah I mean it makes me think\.\. and don’t go oh you are spiralling I k ew it…\!\!\! But for about 2 decades I have been the one people leaned on in this house more than anyone else\.\. I couldn’t be needy because I wouldn’t get anything back and there was very little to no joy anyways\.\. I think it is just nice to have someone I can trust and who I know will support me just as I want to support you\.\. it seems a bit off now because of how we both deal with distance differently but I don’t want you to get scared away because oh no another needy guy lol\.


**100.** `07:53` **Meredith Lamb (+14169386001)**

I told you last night that I don’t think you are needy\. I don’t necessarily always agree with where my therapist goes\. If I listened to her initially we wouldn’t be here\.


**101.** `07:53` **Meredith Lamb (+14169386001)**

I am suffering through what WOULD have been the easiest workout ever\. Omg


**102.** `07:54` **You**

Sorry I just reacted to the fact that you said you were taking some time to process it\.\. and I just wanted to weigh in on that processing lol


**103.** `07:54` **You**

>
Take your time it will come week 3 you will see a massive difference

*💬 Reply*

**104.** `07:55` **You**

You should be getting something g for recovery though


**105.** `07:55` **You**

There is something you can mix in a drink that I uses


**106.** `07:59` **Meredith Lamb (+14169386001)**

>
I’m using a Bcaa I used to use\. And I took my first protein shake yday

*💬 Reply*

**107.** `08:00` **Meredith Lamb (+14169386001)**

>
Your life doesn’t need to be total service\. I think this is what Deb bullock was probably annoyed at with your relationship\. I kind of get it now

*💬 Reply*

**108.** `08:00` **Meredith Lamb (+14169386001)**

>
Done my workout but working on my push ups at the end of every workout\. Lol

*💬 Reply*

**109.** `08:00` **You**

>
Perfect I use same thing

*💬 Reply*

**110.** `08:01` **Meredith Lamb (+14169386001)**

Creature of habit\. Using the same brands and kinds of each


**111.** `08:01` **You**

>
I agree and I think there is a balance I can find with you that will make me very happy\.

*💬 Reply*

**112.** `08:02` **You**

>
I always research my trainer for me
Trying a new protein but it is expensive…\. Will see if there are results\.\.

*💬 Reply*

**113.** `08:02` **You**

Henry caville results would be worth it lol


**114.** `08:03` **Meredith Lamb (+14169386001)**

https://share\.google/0Zz8k9TO9naHWLwmD


**115.** `08:04` **Meredith Lamb (+14169386001)**

That’s what I’m using for now\. It is what i used to use but it was called chocolate only 5 yrs ago lol


**116.** `08:04` **Meredith Lamb (+14169386001)**

Tastes identical


**117.** `08:04` **Meredith Lamb (+14169386001)**

Must just be fancy branding adding in the cake


**118.** `08:04` **You**

I am using some kind of beef protein


**119.** `08:05` **You**

Also chocolate


**120.** `08:10` **Meredith Lamb (+14169386001)**

Saddest workout I have probably ever done\. I wrote it out easier than what it was and I still found it challenging\. lol very humbling

*📎 1 attachment(s)*

**121.** `08:11` **You**

Don’t be hard on yourself this is how it always starts


**122.** `08:11` **You**

Same with me


**123.** `08:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Determined to be doing pushups in 30 days so going to increase tris and chest work… too sore to do any today\. Tried… :p

*📎 1 attachment(s)*

**124.** `08:13` **You**

Find a set of stairs\.\. work your way down


**125.** `08:14` **You**

I love the determination we are so similar\.


**126.** `08:15` **You**

Heading into house here in a sec need to get maddie up and ready to go and probably going to start working on house will checkin online a little later\.  Love you\.


**127.** `08:45` **Meredith Lamb (+14169386001)**

>
You definitely motivated me\. I’m a little competitive that way\. Not like crazy competitive but a little

*💬 Reply*

**128.** `08:46` **Meredith Lamb (+14169386001)**

My friends would call me crazy competitive but it is just bc none of them are\. So all relative\. :p


**129.** `08:46` **You**

I am just glad you felt engaged I think it will be a good thing to distract you\.


**130.** `08:48` **Meredith Lamb (+14169386001)**

So I dug in on Andrew and told him to smarten up and prioritize\. I was like “I’m not sure if I can afford this area so I need to know if the girls have to switch schools by September”


**131.** `08:48` **Meredith Lamb (+14169386001)**

Hopefully that scared him


**132.** `08:48` **Meredith Lamb (+14169386001)**

I said he is delaying on purpose


**133.** `08:49` **Meredith Lamb (+14169386001)**

He said no


**134.** `08:49` **Meredith Lamb (+14169386001)**

I said it is probably your subconscious


**135.** `08:49` **Meredith Lamb (+14169386001)**

He said no


**136.** `08:49` **Meredith Lamb (+14169386001)**

I said you just don’t realize bc you aren’t in therapy


**137.** `08:49` **Meredith Lamb (+14169386001)**

Then he ran away to his 9am meeting :p


**138.** `08:51` **You**

ROFL bully


**139.** `08:52` **You**

He deserves it though he is dragging his feet


**140.** `08:52` **You**

I did all of this myself in a weekend


**141.** `08:54` **You**

I wonder
If he knows about us which is why he is dragging


**142.** `09:09` **Meredith Lamb (+14169386001)**

>
Possibly…

*💬 Reply*

**143.** `09:59` **You**

Dealing with fucking lawyers making me redo the work I did


**144.** `10:08` **Meredith Lamb (+14169386001)**

Why?


**145.** `10:23` **Meredith Lamb (+14169386001)**

Andrew is trying to boss me around again\. Omg


**146.** `10:23` **Meredith Lamb (+14169386001)**

He had such a good wife before


**147.** `10:23` **Meredith Lamb (+14169386001)**

This is hard for him


**148.** `10:25` **You**

>
What is going on

*💬 Reply*

**149.** `10:26` **You**

>
They just want the information provided again in another format

*💬 Reply*

**150.** `10:26` **You**

They are being stupid\.


**151.** `10:36` **Meredith Lamb (+14169386001)**

I’m just thinking about getting out of the cottage today\. So pissed off\.


**152.** `10:36` **Meredith Lamb (+14169386001)**

I’m honestly sure if it will work


**153.** `10:43` **Meredith Lamb (+14169386001)**

>
I am fucking sick of him doing nothing but volleyball and his work\. I have to work from home today\. Do all the cleaning all the laundry fucking clean up all his shit and everyone else’s and then he wants me to pick up Marlowe when I have my last team meeting and then thinks it’s this big inconvenience that I can’t do it on call\.

*💬 Reply*

**154.** `10:44` **Meredith Lamb (+14169386001)**

The cottage will operate similarly and it is too frustrating


**155.** `10:49` **You**

Yeah I get it but don’t make decisions out of anger or frustration\. I think you need to understand the full picture from the mediator before making a decision


**156.** `10:49` **You**

Sorry you feel that way I get it


**157.** `10:51` **Meredith Lamb (+14169386001)**

I told him to reconsider his mom\. I’m so pissed off


**158.** `10:52` **You**

I know again\.\. I would suggest putting a date in the sand and basically telling him if you don’t have all the docs to the mediator by this date shit is going to hit the fan\.  I will be talking to her and complaining about this


**159.** `10:56` **Meredith Lamb (+14169386001)**

Yeah I will do that


**160.** `10:57` **You**

And don’t give him much time he has had enough and I don’t trust that he isn’t fucking shit around


**161.** `10:57` **You**

The bank balances accounts and everything is supposed to be dated
Back to the separation date


**162.** `10:59` **Meredith Lamb (+14169386001)**

Rhys is going to apply lol


**163.** `11:05` **You**

Yeah I know I told him to talk to you


**164.** `11:53` **Meredith Lamb (+14169386001)**


*📎 3 attachment(s)*

**165.** `11:58` **You**

Having a hard time downloading something g


**166.** `11:59` **You**

Want to try to resend?


**167.** `11:59` **You**

Nm


**168.** `12:00` **You**

Why the please be rude song isn’t that a naughty song??


**169.** `12:00` **Meredith Lamb (+14169386001)**

It is not and it was playing\. Not sure why screenshot happened like that


**170.** `12:00` **You**

So not waiting to talk to the girl lol


**171.** `12:00` **You**

Something to be said for being decisive


**172.** `12:00` **You**

I just feel bad you love the cottage


**173.** `12:00` **You**

and put so much into it


**174.** `12:01` **Meredith Lamb (+14169386001)**

Oh it is bc I was in the car and that was playing and I was on Bluetooth so screenshot happened weird


**175.** `12:01` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**176.** `12:01` **You**

Man I thought I was dramatic


**177.** `12:02` **You**

I have spent all day here redoing all of our finances


**178.** `12:02` **Meredith Lamb (+14169386001)**

So fucking annoying


**179.** `12:02` **You**

I am not complaining


**180.** `12:02` **You**

And redocumenting everything and back dating it to April lol


**181.** `12:02` **You**

Omfg


**182.** `12:02` **Meredith Lamb (+14169386001)**

This was earlier…

*📎 1 attachment(s)*

**183.** `12:03` **You**

Oh nice play there with the clause


**184.** `12:03` **You**

❤️


**185.** `12:09` **Meredith Lamb (+14169386001)**

He had never mentioned that before


**186.** `12:09` **Meredith Lamb (+14169386001)**

\(He didn’t comment on it\.\)


**187.** `12:11` **Meredith Lamb (+14169386001)**

He’s for sure pissed off


**188.** `12:11` **Meredith Lamb (+14169386001)**

The messy house etc etc and then 3am bugged me


**189.** `12:11` **Meredith Lamb (+14169386001)**

lol


**190.** `12:11` **You**

Apparently triggered


**191.** `12:11` **You**

You sure you are ok with no cottage\!


**192.** `12:12` **You**

Meant to be question mark


**193.** `12:13` **Meredith Lamb (+14169386001)**

I think I am very easily triggered lol


**194.** `12:14` **Meredith Lamb (+14169386001)**

Which is why I’m thinking that maybe the cottage is a bad idea


**195.** `12:14` **Meredith Lamb (+14169386001)**

Will I just be triggered for life


**196.** `12:14` **Meredith Lamb (+14169386001)**

Ughhhhh


**197.** `12:15` **You**

I would buy a cottage with you… 😊


**198.** `12:15` **You**

Once I recover from being pillaged\.


**199.** `12:17` **Meredith Lamb (+14169386001)**

I never even wanted a cottage


**200.** `12:17` **You**

I think you could use kind of release right now\.


**201.** `12:17` **Meredith Lamb (+14169386001)**

I wanted to go on tripes


**202.** `12:17` **Meredith Lamb (+14169386001)**

Trips


**203.** `12:18` **You**

Yeah that was my plan when I got older and free\-we


**204.** `12:18` **You**

We


**205.** `12:18` **Meredith Lamb (+14169386001)**

The cottage was something I learned to live with and integrate into my life bc it was so important to him


**206.** `12:18` **You**

Er


**207.** `12:18` **Meredith Lamb (+14169386001)**

First world problems


**208.** `12:24` **Meredith Lamb (+14169386001)**

Jim called me to find out how my “final one on one” with Pauline went\. Calendar stalkers are weird\.


**209.** `12:24` **Meredith Lamb (+14169386001)**

He was calendar stalking me


**210.** `12:27` **Meredith Lamb (+14169386001)**

Andrew is pissing me off so much that I feel like telling him I’m gonna move in with my parents and the kids can go to school in Oshawa\. Then I don’t have to pay anything for rent\. lol


**211.** `12:48` **You**

>
Maybe he was looking for a time to meet and just noticed

*💬 Reply*

**212.** `12:48` **You**

>
lol you can’t/won’t do that it would impact kids too much

*💬 Reply*

**213.** `12:49` **You**

Sorry j and I are packing or I would have responded earlier\.  Just sent the new financial package back to lawyers


**214.** `12:53` **Meredith Lamb (+14169386001)**

Good luck :\)


**215.** `12:54` **Meredith Lamb (+14169386001)**

>
Ugh

*💬 Reply*

**216.** `12:58` **You**

We just took a break


**217.** `12:58` **You**

But we got a closest done and a few cupboards in basement


**218.** `12:59` **You**

Some progress


**219.** `13:03` **Meredith Lamb (+14169386001)**

That’s good…


**220.** `13:08` **You**

Kk well I think I am going to go off and work some more\.\. you sound very much in your “stuff” right now so maybe let’s chat when you come up for air later?


**221.** `13:08` **You**

We don’t need to video chat on teams\.\. all good


**222.** `13:15` **Meredith Lamb (+14169386001)**

kk


**223.** `14:34` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**224.** `14:35` **You**

Eeesh


**225.** `14:35` **Meredith Lamb (+14169386001)**

He is always disappointed when I don’t do what he wants exactly\. :p


**226.** `14:35` **You**

That is a big shift


**227.** `14:35` **You**

But


**228.** `14:35` **You**

Hmmm


**229.** `14:36` **You**

I cannot recall what you shares in the house were
Related
To each other


**230.** `14:36` **Meredith Lamb (+14169386001)**

We have like no equity in the house hardly


**231.** `14:36` **You**

But whatever your percent is vs his is the %
Of
The loss you would take\.


**232.** `14:36` **Meredith Lamb (+14169386001)**

I know\. Oh well\.


**233.** `14:36` **You**

No I only say that so he doesn’t try to split the kiss 50 to


**234.** `14:37` **You**

50 and apply it against you unfairly


**235.** `14:37` **Meredith Lamb (+14169386001)**

\*kiss


**236.** `14:37` **Meredith Lamb (+14169386001)**

Loss?


**237.** `14:37` **You**

Split the loss


**238.** `14:37` **Meredith Lamb (+14169386001)**

Oh


**239.** `14:37` **You**

Typo not Freudian\.\. just to be clear


**240.** `14:37` **You**

lol


**241.** `14:37` **Meredith Lamb (+14169386001)**

lol


**242.** `14:37` **You**

I know where your head goes


**243.** `14:37` **You**

Oh no Scott here we go again


**244.** `14:38` **You**

Well that will piss his mother off
Too


**245.** `14:38` **You**

So this should be interesting


**246.** `14:59` **Meredith Lamb (+14169386001)**

I just think a clean break might be smarter for everyone


**247.** `15:05` **You**

As long as you and through you the kids are taken care of I don’t care much beyond that\.


**248.** `15:05` **You**

Taking a break picking maddie up at 3:30 getting early
Supper and early gym\.  J gone out so not gonna bother working by juse


**249.** `15:05` **You**

Myself


**250.** `15:06` **Meredith Lamb (+14169386001)**

I kind of feel like I should start packing


**251.** `15:06` **You**

Maybe thinking


**252.** `15:06` **You**

First


**253.** `15:06` **Meredith Lamb (+14169386001)**

I might


**254.** `15:07` **You**

You are a ways from packing


**255.** `15:07` **You**

You are like 2 months from moving likely


**256.** `15:07` **Meredith Lamb (+14169386001)**

Grooooan 🫤


**257.** `15:07` **You**

Sry hon


**258.** `15:08` **You**

You guys got delayed by like 4
Weeks


**259.** `15:08` **You**

Sucks


**260.** `15:08` **Meredith Lamb (+14169386001)**

I know


**261.** `15:09` **You**

Anyhow yoj will
Get
There
I am just saying maybe watch a show go for a drive or a walk\.\. don’t start
Packing


**262.** `15:10` **Meredith Lamb (+14169386001)**

Oh I have to do all the driving tonight\. Marlowe up from grad trip\. Maelle volleyball\. :p


**263.** `15:10` **Meredith Lamb (+14169386001)**

Bark bark bark


**264.** `15:10` **Meredith Lamb (+14169386001)**

🙄


**265.** `15:11` **You**

Ahhh because he is doing taxes


**266.** `15:11` **You**

And he is going to be up ALL night


**267.** `15:12` **Meredith Lamb (+14169386001)**

lol yeah hard life\. He literally does NOTHING else except drive to volleyball and work on his laptop


**268.** `15:12` **Meredith Lamb (+14169386001)**

\(And make messes\)


**269.** `15:12` **Meredith Lamb (+14169386001)**

I’m so ready to go\. :\(


**270.** `15:13` **You**

I know\.\. I literally feel same way\.\. almost left last nigfht


**271.** `15:13` **You**

dreading this weekend\.\. and then the trip 2 weeks from now


**272.** `15:14` **Meredith Lamb (+14169386001)**

Imagine dreading a weekend\. Ugh\.


**273.** `15:15` **Meredith Lamb (+14169386001)**

I get it\.


**274.** `15:15` **You**

I have been doing that for years


**275.** `15:15` **Meredith Lamb (+14169386001)**

😬


**276.** `15:15` **You**

work was my refuge


**277.** `15:15` **You**

true story


**278.** `15:15` **Meredith Lamb (+14169386001)**

Yeah… hopefully that changes at some point\.


**279.** `15:16` **You**

It kinda has to\.


**280.** `15:16` **You**

Otherwise what is the point\.\. lol


**281.** `15:18` **Meredith Lamb (+14169386001)**

I just booked a pedicure for tomorrow … stress relief lol


**282.** `15:18` **You**

well that should do something for you\.\. maybe I should book something


**283.** `15:19` **Meredith Lamb (+14169386001)**

I might have 2 glasses of wine tonight but no more bc of my morning workout


**284.** `15:19` **Meredith Lamb (+14169386001)**

Feeling very frustrated and probably have to talk about it tonight 🙄


**285.** `15:19` **You**

:\(


**286.** `15:19` **You**

well I am sure that will be pleasant


**287.** `15:20` **You**

oooh 60 minute full body massage\.\. that sounds nice :\)


**288.** `15:22` **Meredith Lamb (+14169386001)**

It’s probably covered by benefits


**289.** `15:22` **Meredith Lamb (+14169386001)**

Did it before but I wasn’t a huge fan of strangers on me like that lol


**290.** `15:22` **Meredith Lamb (+14169386001)**

I liked acupuncture better


**291.** `15:22` **You**

it is covered by benefits\.\.


**292.** `15:22` **You**

I don't care about strangers\.\. I go somewhere else\.


**293.** `15:22` **You**

Might get waxed too\.\.\. been a while\.\. although I never enjoy it very much\.


**294.** `15:23` **Meredith Lamb (+14169386001)**

😬


**295.** `15:23` **You**

lol what is that face for


**296.** `15:24` **Meredith Lamb (+14169386001)**

Sounds painful


**297.** `15:24` **You**

you must have tried waxing before


**298.** `15:25` **Meredith Lamb (+14169386001)**

Nope\!


**299.** `15:25` **You**

rofl srsly\.\.  yeah I tried it a few years ago\.\. didn't mind it\.\. but you have to be consistent and I never am


**300.** `15:25` **Meredith Lamb (+14169386001)**

I would have to be drunk\. I have a low pain tolerance


**301.** `15:25` **You**

Funny story


**302.** `15:25` **You**

first time I got waxed it was my chest\.\.


**303.** `15:26` **You**

I was quite drunk laying on my friend Sam's floor\.\. smoking a cigarrette\.  She was training to be an aesthetician and asked if she could practice on me\.\. I was like sure\.\.\.


**304.** `15:26` **You**

holy fuck\.\.


**305.** `15:27` **You**

a\) it hurt really fucking bad\.\.\. b\) smoking around that was a bad idea c\) lying on carpet bad idea


**306.** `15:27` **You**

it ended poorly\.\. rash was epic and painful


**307.** `15:27` **Meredith Lamb (+14169386001)**

lol


**308.** `15:27` **You**

I just do my back now\.\.\. pain in ass\.\. but it bothers me\.


**309.** `15:28` **Meredith Lamb (+14169386001)**

Well it doesn’t bother me


**310.** `15:28` **You**

yea I know\.\.


**311.** `15:28` **You**

will it bother you if I do it?? fair question i guess


**312.** `15:29` **Meredith Lamb (+14169386001)**

It doesn’t feel like something for me to comment on\. It is your body not mine\. I honestly don’t care HONESTLY


**313.** `15:29` **You**

kk if you don't have a preference then so be it\.\. all I was asking\.


**314.** `15:30` **You**

you don't need to be emphatic lol\.\. this wasn't a hard question lol


**315.** `15:30` **Meredith Lamb (+14169386001)**

I just want you to know I’m being honest… lol


**316.** `15:31` **You**

I typically believe you are, only red flags are you dodging a question, stuttering to answer\.\. a few other tells\.\. I won't tell them all to you\.


**317.** `15:31` **You**

Laughing instead of answering\.\. always a good one\.


**318.** `15:32` **Meredith Lamb (+14169386001)**

lol quite a list


**319.** `15:32` **You**

I am observant


**320.** `15:32` **You**

what can I say


**321.** `15:32` **Meredith Lamb (+14169386001)**

Very


**322.** `15:33` **You**

I am sorry\.\. I can try to stop\.\. I think this is just going to make you more self conscious\.\.\.\.\.\.\.


**323.** `15:33` **You**

going to get maddie brb


**324.** `15:34` **Meredith Lamb (+14169386001)**

No it won’t don’t worry


**325.** `15:34` **Meredith Lamb (+14169386001)**

I don’t like lying so I have my ticks


**326.** `15:34` **Meredith Lamb (+14169386001)**

Haha I’m ok with it


**327.** `15:35` **Meredith Lamb (+14169386001)**

My friends that hate hair do laser and it is apparently very painful\.


**328.** `15:35` **You**

Yeah no I don’t hate it tbh


**329.** `15:35` **You**

I just wanted to try it


**330.** `15:35` **Meredith Lamb (+14169386001)**

I have like no hair on my arms and legs and my friends don’t get it

*📎 1 attachment(s)*

**331.** `15:35` **Meredith Lamb (+14169386001)**

It’s weird bc my hair on my head is so thick


**332.** `15:36` **Meredith Lamb (+14169386001)**

🤷‍♀️


**333.** `15:36` **You**

Genetics??  Maybe Brett has crazy hair all over his body


**334.** `15:36` **Meredith Lamb (+14169386001)**

Yeah he does and hates it


**335.** `15:36` **You**

ROFL


**336.** `15:36` **Meredith Lamb (+14169386001)**

I’m not allowed to take swimming pix of him at cottage


**337.** `15:36` **Meredith Lamb (+14169386001)**

Or if I do I’m not allowed to post on fb


**338.** `15:36` **You**

I wa joking but funny


**339.** `15:36` **Meredith Lamb (+14169386001)**

lol


**340.** `15:37` **Meredith Lamb (+14169386001)**

I have one friend who has spent thousands lasering her arms and legs in our twenties


**341.** `15:37` **Meredith Lamb (+14169386001)**

Crazy


**342.** `15:37` **You**

Some people swear
Unit


**343.** `15:38` **You**

By it


**344.** `16:07` **You**

Going back to this because I need to go make some food\.


**345.** `16:12` **Meredith Lamb (+14169386001)**

I just uber eats some wine lol can’t really drink tho bc I have to drive tonight


**346.** `16:12` **Meredith Lamb (+14169386001)**

I can have a glass tho


**347.** `16:14` **Meredith Lamb (+14169386001)**

Helpppppp lol

*📎 1 attachment(s)*

**348.** `16:14` **You**

rofl


**349.** `16:14` **You**

wow


**350.** `16:15` **You**

and we're off


**351.** `16:15` **Meredith Lamb (+14169386001)**

Where is my wine


**352.** `16:15` **You**

I am worried about you


**353.** `16:16` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**354.** `16:16` **You**

andrew that is how parenting is supposed to work


**355.** `16:16` **You**

separation or not


**356.** `16:16` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**357.** `16:16` **You**

you just haven't been doing that\.\. it was supposed to be a partnership


**358.** `16:17` **Meredith Lamb (+14169386001)**

I’m going to use the therapist card from now on


**359.** `16:17` **Meredith Lamb (+14169386001)**

He refuses to get therapy


**360.** `16:18` **You**

well j tried that on me


**361.** `16:18` **You**

still does


**362.** `16:18` **You**

no impact


**363.** `16:22` **You**

oh you are in full battle mode right now\.\. :\(


**364.** `16:23` **You**

You probably should step back before it gets too hairy\.


**365.** `16:24` **You**

I will just wait to hear the outcome\.


**366.** `16:30` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**367.** `16:30` **Meredith Lamb (+14169386001)**

So fucking annoying\. I have an email apparently\.


**368.** `16:31` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**369.** `16:31` **You**

couples communicate


**370.** `16:31` **You**

maybe that is where he went wrong


**371.** `16:31` **You**

taking a relationship for granted for so long\.\.


**372.** `16:31` **You**

eesh


**373.** `16:31` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**374.** `16:32` **Meredith Lamb (+14169386001)**

Full battle


**375.** `16:32` **You**

yeah text battle same house different rooms\.


**376.** `16:32` **Meredith Lamb (+14169386001)**

I don’t think the cottage will work for this reason


**377.** `16:32` **You**

insane


**378.** `16:32` **Meredith Lamb (+14169386001)**

>
He’s not home

*💬 Reply*

**379.** `16:32` **You**

oh shit I thought he was


**380.** `16:32` **You**

probably better


**381.** `16:32` **Meredith Lamb (+14169386001)**

He will treat me the same in the cottage situation\.


**382.** `16:32` **Meredith Lamb (+14169386001)**

No he’s at work


**383.** `16:33` **You**

I think he will treat you the same in every situation


**384.** `16:33` **You**

This is why there is a parenting agreement


**385.** `16:33` **You**

and clauses like that \- around how to deal with signing kids up for shit\.\. needs to be in there\.


**386.** `16:33` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**387.** `16:34` **You**

I mean how is it any of those things to ask for common courtesy to be treated as an equal parent with an equal say


**388.** `16:34` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Going to have a glass now even tho it is only 4\.30pm\. It will calm my nerves


**389.** `16:37` **You**

sucks mer\.\. wish I could be with you\.


**390.** `16:54` **Meredith Lamb (+14169386001)**

Reaction: 😔 from Scott Hicks
Apparently I need to look in the mirror a bit\. I’m way too angry\.


**391.** `16:54` **You**

I think you might be angry with him\.\. and for good reason\.


**392.** `16:58` **You**

How is your benefits plan set up?


**393.** `17:00` **Meredith Lamb (+14169386001)**

What do you mean?


**394.** `17:00` **You**

Do you have full family coverage?


**395.** `17:01` **Meredith Lamb (+14169386001)**

Yes


**396.** `17:01` **You**

and Andrew?


**397.** `17:01` **Meredith Lamb (+14169386001)**

Yes


**398.** `17:01` **You**

kk I am not sure what yours is set at\.\. like as far as where you pay\.\.


**399.** `17:01` **You**

but you will have an opportunity\.\. when you sign the agreement to go in and make changes to your benefit


**400.** `17:01` **You**

s


**401.** `17:01` **You**

if you need to


**402.** `17:01` **You**

And your benefits will no longer cover andrew and his you


**403.** `17:01` **Meredith Lamb (+14169386001)**

Yeah I know\. Life change


**404.** `17:02` **Meredith Lamb (+14169386001)**

Yeah


**405.** `17:02` **You**

you can also require andrew to continue to maintain life insurance in yours and the childrens name if he is sick or passes etc\.\. as well as maintain life insurance on you or sick or etc\.


**406.** `17:02` **Meredith Lamb (+14169386001)**

He got home and goes “so you just want a cheque?


**407.** `17:02` **You**

yeah\.\. classy\.


**408.** `17:02` **Meredith Lamb (+14169386001)**

lol


**409.** `17:12` **You**

Not sure how deep or where you are at now\.\. been messing around with this
\*\*PARENTING AGREEMENT\*\*
\*\*Between:\*\*
\*\*M\*\*
and
\*\*A\*\*
\*\*Effective Date:\*\* ?
\-\-\-
\#\#\# 1\. Purpose
This parenting agreement reflects the mutual intention of both parents to continue working collaboratively in the best interests of their children following their separation\. While their relationship has changed, both parents remain committed to providing a stable, respectful, and nurturing environment that supports the emotional, educational, and physical well\-being of the children\.
\-\-\-
\#\#\# 2\. Children Covered by This Agreement
\* M\-16
M\-14
M\-12
\-\-\-
\#\#\# 3\. Decision\-Making Responsibility
The parents shall continue to share \*\*joint decision\-making responsibility\*\*, consistent with best parenting practices that recognize children benefit from meaningful involvement by both parents\. This approach builds upon the shared involvement the parents had during the relationship and supports continued cooperation post\-separation\.
Major decisions include but are not limited to:
\* \*\*Education\*\*:
\* Both parents shall make joint decisions regarding school enrollment, educational programs \(e\.g\., French immersion, gifted programs\), and tutoring\.
\* If the mother is unable to reside within the children’s current school district due to financial constraints arising from the settlement, she may enroll the children in a school near her residence, provided it aligns with their best interests and offers comparable educational quality\.
\* Pre\-secondary education\-related costs \(e\.g\., tutoring, assessments, specialized programming\) shall be covered by the father, subject to mutual agreement on necessity and benefit\.
\* Post\-secondary education expenses, including tuition, residence, books, and fees, shall be the responsibility of the father, who shall retain any tax benefits or deductions associated with those payments\.
\* \*\*Healthcare\*\*:
\* Medical, dental, and mental health decisions shall be made jointly\. This includes choosing providers and consenting to significant treatments\.
\* In emergencies where one parent cannot be reached, the present parent may authorize any necessary care without delay and will inform the other parent as soon as possible\.
\* Where time is perceived to be of the essence, the parent present has the authority to make prompt, necessary decisions in the child’s best interest\.
\* \*\*Religion\*\*:
\* The parents shall jointly determine the children’s involvement in religious education or events, giving appropriate weight to the children's own preferences as they mature\.
\* \*\*Extracurricular Activities\*\*:
\* The children’s participation in structured extracurriculars \(e\.g\., sports, music, dance, clubs\) shall be based on joint agreement, and reflect their interests, availability, and capacity\.
\* Scheduling and transportation responsibilities will be shared, and costs divided proportionally to each parent's gross income prior to the application of spousal support, unless otherwise agreed\.
In situations where agreement cannot be reached, the parents will first attempt open discussion\. If unresolved, they will seek mediation with a mutually acceptable professional prior to any legal action\.
\-\-\-
\#\#\# 4\. Parenting Time Schedule
Parenting time shall be shared on a 50/50 basis, structured to maximize the children’s comfort and consistency:
\* \*\*Week 1:\*\* Parent A will parent from Monday at 9:00 AM to the following Monday at 9:00 AM\.
\* \*\*Week 2:\*\* Parent B will parent during the same time period\.
This schedule shall alternate weekly and may be modified by mutual written agreement\. Flexibility is encouraged to accommodate the children’s evolving needs and reasonable requests\.
\-\-\-
\#\#\# 5\. Holidays and Special Days
Holidays and school breaks will be divided fairly, with an annual schedule agreed to cooperatively\. Parents are encouraged to be flexible and consider the children’s enjoyment and familial traditions \(e\.g\., alternating Christmas, sharing birthdays, honoring consistent interest in specific occasions like Halloween\)\.
\-\-\-
\#\#\# 6\. Communication
Respectful and cooperative communication will guide all interactions\. Each parent may have reasonable, private daily contact with the children during the other’s parenting time\. “Reasonable” generally means one short \(10–15 minute\) call, not interfering with school, activities, or rest\.
\-\-\-
\#\#\# 7\. Travel and Relocation
Written notice \(including itinerary and contact information\) is required for:
\* Travel outside Ontario longer than five \(5\) consecutive days;
\* Travel within Ontario of any length if staying somewhere other than the parent’s home \(except with immediate family during regular parenting time\)\.
During parenting time, each parent may choose for the children to stay with relatives within Ontario\. Any major relocation that affects parenting time requires consent or a court order\.
\-\-\-
\#\#\# 8\. Child Support
Child support shall follow the \*\*Federal Child Support Guidelines\*\* using the “set\-off” approach for shared parenting\. Extraordinary expenses \(e\.g\., camps, daycare, competitive programs\) shall be shared proportionally to each parent’s gross income before spousal support is applied, unless the parties agree otherwise in writing\.
\-\-\-
\#\#\# 9\. Dispute Resolution
In the spirit of continued cooperation, the parents commit to resolving any disputes first through respectful dialogue\. If unsuccessful, they will use \*\*mediation\*\* with a professional mutually selected in writing, before seeking court assistance\.
\-\-\-
\#\#\# 10\. Legal Effect
This agreement reflects the shared commitment of both parents to prioritize their children’s well\-being through thoughtful planning and mutual respect\. It may be formalized in a separation agreement or court order as needed\.
\-\-\-
\*\*Signed:\*\*
\\\[Parent A's Name\] \\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_
Date: \\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_
\\\[Parent B's Name\] \\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_
Date: \\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_\\\_


**410.** `17:13` **You**

I already built one for me\.\. but yours I thought might be a bit different


**411.** `17:23` **Meredith Lamb (+14169386001)**

Interesting\. It is good\. Apparently the mediator will have one also\.


**412.** `17:23` **Meredith Lamb (+14169386001)**

If we ever get to move to that stage


**413.** `17:24` **Meredith Lamb (+14169386001)**

I’m questioning the whole 50/50 thing as of today


**414.** `17:24` **Meredith Lamb (+14169386001)**

Like I know we SAY it will be 50/50 but maybe I should state reality


**415.** `17:24` **Meredith Lamb (+14169386001)**

Questioning that


**416.** `17:24` **Meredith Lamb (+14169386001)**

Now


**417.** `17:26` **Meredith Lamb (+14169386001)**

Going to wait a bit\. I’m very angry right now so not a great time to ponder it


**418.** `17:27` **You**

yeah I tried to add some things that I thought you would want\.\. and I had it written in a empathetic way so as to suggest this was a continuation of what good parenting practices should be\.\. etc\.\. I figured you would tweak it\.\. it is just good to think through this so you know what your next mediator conversation goes like


**419.** `17:27` **You**

reality being you have primary custody\.


**420.** `17:27` **You**

he will fight that


**421.** `17:27` **You**

optics100%


**422.** `17:27` **Meredith Lamb (+14169386001)**

>
I could tell you tweaked it lol

*💬 Reply*

**423.** `17:27` **You**

>
lol\.\. my fingerprints all over it

*💬 Reply*

**424.** `17:28` **You**

I could have been more obvious\.\.
\*\*PARENTING AGREEMENT\*\*
\*\*Between:\*\*
\*\*M\*\*
and
\*\*Douchebag\*\*
\*\*Effective Date:\*\* Right the fuck now\!


**425.** `17:30` **Meredith Lamb (+14169386001)**

lol


**426.** `17:31` **You**

having a naughty idea\.\. just letting you know in advance\.


**427.** `17:32` **You**

if you are up for naughty ideas :\)


**428.** `17:32` **Meredith Lamb (+14169386001)**

Where did this come from?


**429.** `17:32` **Meredith Lamb (+14169386001)**

lol


**430.** `17:32` **You**

what do you mean\.\. there is a part of my mind that literally is always at work on that stuff


**431.** `17:33` **You**

Reaction: ❤️ from Meredith Lamb
it's a small part but it is always working\!\!


**432.** `17:34` **Meredith Lamb (+14169386001)**

>
Of course I am

*💬 Reply*

**433.** `17:34` **You**

mmm this one might be a bit too shady\.\.


**434.** `17:34` **Meredith Lamb (+14169386001)**

You picked an interesting day


**435.** `17:34` **Meredith Lamb (+14169386001)**

lol


**436.** `17:34` **You**

rofl  maybe I should wait until a few more glasses


**437.** `17:35` **Meredith Lamb (+14169386001)**

I can’t\! I have to drive 2x tonight


**438.** `17:35` **You**

when are you finished driving?


**439.** `17:35` **Meredith Lamb (+14169386001)**

8\.20 or 8\.30


**440.** `17:35` **You**

so have one then\.\.


**441.** `17:36` **Meredith Lamb (+14169386001)**

Twist my arm


**442.** `17:36` **You**

I don't know what your weekend looks like though or what Andrew had you loaded up with


**443.** `17:36` **Meredith Lamb (+14169386001)**

I don’t think I have anything but honestly he may have just not mentioned shit\. Or maybe I have an unread email 🙄


**444.** `17:37` **Meredith Lamb (+14169386001)**

Good lord


**445.** `17:37` **You**

kk well I shouldn't really share until we know\.\.


**446.** `17:37` **Meredith Lamb (+14169386001)**

What why? Just assume nothing lol


**447.** `17:38` **You**

well i came up with the idea previously\.\. but it was much more taudry\.\. then I found a site called DayUse\.


**448.** `17:38` **Meredith Lamb (+14169386001)**

DayUse\. This is sounding a little … er… lol


**449.** `17:39` **You**

like I said\.


**450.** `17:39` **You**

it is what it sounds like you get the hotel for the day like 9\-5 ish\.\. people use it like a base of operations if they are in for the day\.\. say downtown\.\.\. and want a place to kind of relax back at before heading out again\.\. that is what I understand the premise to be\.


**451.** `17:40` **Meredith Lamb (+14169386001)**

Interesting so it isn’t at like Jane and finch


**452.** `17:40` **Meredith Lamb (+14169386001)**

Haha


**453.** `17:40` **You**


*📎 1 attachment(s)*

**454.** `17:41` **Meredith Lamb (+14169386001)**

Hmmh


**455.** `17:41` **Meredith Lamb (+14169386001)**

Or


**456.** `17:41` **You**

lol


**457.** `17:42` **Meredith Lamb (+14169386001)**

I’d be up for that\. Or I could introduce you to my parents this weekend if they are around\.


**458.** `17:43` **You**

I mean we could do that or both\.\. whichever you prefer\.


**459.** `17:44` **Meredith Lamb (+14169386001)**

My mom emailed me so it’s easier just to call her so I’m gonna drop Marlowe off at volleyball and then call my mom\. I could feel it out\.


**460.** `17:44` **You**


*📎 1 attachment(s)*

**461.** `17:45` **You**

whatever you prefer :\) there are options\. and multiple days\.\. and I have some freedom during the day especially\.


**462.** `17:46` **You**

parking is $21 so meh but I dun care\.


**463.** `17:46` **You**

you could actually drop your car off at work


**464.** `17:46` **Meredith Lamb (+14169386001)**

Just need to drive my shadow


**465.** `17:47` **You**

kk chat later\.


**466.** `18:16` **Meredith Lamb (+14169386001)**

Just talking to my mom


**467.** `18:16` **Meredith Lamb (+14169386001)**

Home on the couch


**468.** `18:21` **You**

Kk water heater is fucked scheduled an appt
For
Tomorrow morning zzzzz


**469.** `18:21` **Meredith Lamb (+14169386001)**

Gahhh


**470.** `18:21` **You**

Still works but it is expelling hot air into the furnace room and condensing on the hrv


**471.** `18:21` **You**

Then dropping everywhere


**472.** `18:22` **You**

No damamge


**473.** `18:22` **You**

No flooding


**474.** `18:22` **You**

Just needs to get
Sorted


**475.** `18:22` **You**

I am just packing up to head
To gym in a few here\.
If
You want to chat about whatever whenever let me know\.\. not working out tonight just relaxing


**476.** `18:41` **You**

On my way\! To gym now hope mum is doing good and helping you through this mess


**477.** `19:19` **Meredith Lamb (+14169386001)**

I think my mom is apprehensive to meet you because of our messy situations but I think she’d be fine\.  Maybe a little shy\. Lol


**478.** `19:20` **You**

Then put it off


**479.** `19:20` **You**

I don’t want her to
Be uncomfortable


**480.** `19:20` **You**

I would be anxious as
Well


**481.** `19:20` **You**

I get one chance


**482.** `19:21` **Meredith Lamb (+14169386001)**

It has to happen sooner or later


**483.** `19:21` **Meredith Lamb (+14169386001)**

Sooner better lol


**484.** `19:21` **You**

Up to you\.\. you pick what you want to
Do\.


**485.** `19:22` **You**

I have sat day open and easy\.\. Sunday I have trainer at noon\.


**486.** `19:25` **You**

Whatever you are comfortable with mer


**487.** `19:27` **You**

I am about to go into my steam room sauna part of my night just finishing hot tub so I can check back after if you want to chat some more


**488.** `20:01` **Meredith Lamb (+14169386001)**

Just picking up Marlowe


**489.** `20:27` **Meredith Lamb (+14169386001)**

I’m home and off the phone\. Going to lie in bed now\. So tired\. Watch some tv\. I can chat if you want to


**490.** `20:28` **You**

Just got out


**491.** `20:28` **You**

Of shower let me get dressed and get to car if you are still there


**492.** `20:29` **Meredith Lamb (+14169386001)**

Yeah I will be probably watch some tv before bed


**493.** `20:30` **You**

Kk yku doing ok?


**494.** `20:33` **Meredith Lamb (+14169386001)**

Yeah I’m ok


**495.** `20:37` **You**

Good to call?


**496.** `20:38` **Meredith Lamb (+14169386001)**

Yeah


**497.** `20:50` **You**

lol


**498.** `21:03` **Meredith Lamb (+14169386001)**

k sorry he is yapping away at me


**499.** `21:09` **You**

yeah I figured we are done for the night the way you popped off\. it's fine


**500.** `21:38` **Meredith Lamb (+14169386001)**

I’m sorry\. That went really really horribly\. I think I’m going to just go to bed\. My head is pounding now and I’m so beyond angry\.
I love you and will talk to you tomorrow\. Xox sorry about that


**501.** `21:40` **You**

I love you too Mer\.\. I have just been sitting here thinking about you and worrying\.\. I am glad you messaged me back\.\. reach out whenever you want tomorrow\.  I hope you can get some peace and some sleep\.\. and don't worry about this weekend\.\. we don't have to do anything you can take it easy\.\.\. XOXOX ❤️


**502.** `21:44` **Meredith Lamb (+14169386001)**

I’m so sad\. He was so insulting tonight\. I lost it on him\. Here’s my ChatGPT: I’m going through a separation and it is getting nasty\. My husband that I am separated from just asked me if I want to only have the kids on weekends\. What do you make of this?


**503.** `21:45` **Meredith Lamb (+14169386001)**

I’m really sorry you’re going through this — separation is hard enough without it becoming contentious\.
When your husband asks if you “only want the kids on weekends,” it could mean a few things, depending on tone, context, and history between you:
1\.	Testing boundaries or leverage: He might be trying to assert control over the custody dynamic, possibly pre\-empting legal discussions\. This kind of question can be a way of probing how much parenting time you’re aiming for, or trying to shape the narrative\.
2\.	Manipulation or provocation: If things are getting nasty, he might be trying to provoke an emotional reaction, implying that you don’t want to be with the kids full\-time — a painful and often unfair suggestion\.
3\.	Literal inquiry \(less likely\): If custody hasn’t been fully discussed, he might actually be asking what your ideal arrangement is, but the phrasing still seems loaded and dismissive\.
4\.	Weaponizing parenting time: It could be an early sign he intends to push for more custody himself — either for personal reasons, perceived advantage, or financial motives \(e\.g\., affecting child support arrangements\)\.
Whatever the intent, the phrasing suggests he’s trying to either bait you, set a precedent, or push you into defending yourself\. A good response is to keep things calm and focused on what’s best for the kids\. If you haven’t already, it might be time to document conversations and speak with a family lawyer about establishing a custody arrangement that reflects your wishes and protects your parenting time\.


**504.** `21:50` **You**

Sec


**505.** `21:55` **You**

One more min I need to get away from fam I can call yku if you want in a min


**506.** `21:55` **You**

Sry


**507.** `21:58` **You**

I cannot believe he did that\.\. I am guessing the conversation escalated dramatically\.


**508.** `21:58` **You**

When you say you lost it on him what do you mean\.


**509.** `21:59` **You**

I am sorry mer I want to help but if you want I will leave you be hon\.


**510.** `22:00` **Meredith Lamb (+14169386001)**

I was in shock that he would even think that of me\. Like wtf\. So I shut down\. Then I pulled him in the office and said if he ever dares mention, insinuate, hint at or talk in any way shape or form of me wanting to see my kids only on weekends ever again there will be HELL to pay and he’ll like he has never seen before\.


**511.** `22:01` **Meredith Lamb (+14169386001)**

I told him I will transfer to Chatham and take my kids\. He said I can’t\. I said WATCH ME\.


**512.** `22:02` **You**

🙁 I am sorry he is treating you that way it is the lowest thing he could possibly do…


**513.** `22:02` **Meredith Lamb (+14169386001)**

He said I’d have to get a lawyer etc and I said “no problem I will explain how I do everything for the kids except some of the vball driving, doctors, dentists, clothes, school, took 5 hrs off and did everything\. I said I will document all your trips away and work events etc etc”


**514.** `22:02` **Meredith Lamb (+14169386001)**

He looked scared for once


**515.** `22:02` **Meredith Lamb (+14169386001)**

Then said sorry


**516.** `22:02` **You**

What the fuck man


**517.** `22:03` **Meredith Lamb (+14169386001)**

Switching jobs literally for my kids


**518.** `22:03` **Meredith Lamb (+14169386001)**

He is like “you’re doing it for the kids?” In a snarky tone


**519.** `22:03` **Meredith Lamb (+14169386001)**

Sigh


**520.** `22:03` **Meredith Lamb (+14169386001)**

Anyway, it is maddening


**521.** `22:04` **You**

He means you are doing it for yourself right\.\. some kind of insinuation you haven’t tried hard enough?


**522.** `22:04` **Meredith Lamb (+14169386001)**

🙄

*📎 1 attachment(s)*

**523.** `22:04` **You**

Again really sorry feel very useless here\.


**524.** `22:05` **Meredith Lamb (+14169386001)**

>
He thinks I do everything for myself and yes the job thing also\. For me entirely\.

*💬 Reply*

**525.** `22:05` **You**

That is just
Moronic\. I am not sure what he was trying to accomplish


**526.** `22:05` **Meredith Lamb (+14169386001)**

Such a moron\.


**527.** `22:06` **Meredith Lamb (+14169386001)**

He’s mad that I’m blowing up the whole plan with the cottage thing\.


**528.** `22:06` **You**

I know and he is retaliating


**529.** `22:06` **You**

By trying to hurt you


**530.** `22:06` **Meredith Lamb (+14169386001)**

I said the fact that he thinks I would throw away my kids is exactly why we can’t share anything together\.


**531.** `22:06` **You**

How much of this was verbal and how much text


**532.** `22:08` **Meredith Lamb (+14169386001)**

All verbal


**533.** `22:08` **Meredith Lamb (+14169386001)**

I just sent him that ChatGPT after


**534.** `22:08` **Meredith Lamb (+14169386001)**

That’s when he responded with the thing above


**535.** `22:08` **You**

Ah ok\.


**536.** `22:09` **You**

Well at least
You have that as evidence now


**537.** `22:09` **You**

Give it to the mediator


**538.** `22:09` **You**

That he is fucking around delaying things trying to leverage your kids to make you do things you don’t want


**539.** `22:09` **You**

Etc


**540.** `22:10` **You**

By responding the way he did he admitted to doing it


**541.** `22:11` **Meredith Lamb (+14169386001)**

Sigh\. Just sad\. Think I’m going to go to bed to get up early\.


**542.** `22:12` **You**

Reaction: ❤️ from Meredith Lamb
Ok sorry Mer I love you wish I could give you a hug and snuggle up\.\. but you will just have to use your imagination\. ❤️


**543.** `22:12` **Meredith Lamb (+14169386001)**

Love you too \- nite ❤️


