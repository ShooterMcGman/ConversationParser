# Daily Conversation: 2025-07-18 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-18 |
| **Day** | Friday |
| **Week** | 14 |
| **Messages** | 676 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-18T00:00 - 2025-07-18T16:52 |

## 📝 Daily Summary

This day contains **676 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

>
you are definitely an expert in this field\.

*💬 Reply*

**002.** `00:00` **You**

we don't need to go deeper, this all started by me not wanting to be compared ot andrew


**003.** `00:00` **You**

you didn't understand why


**004.** `00:00` **You**

this is why


**005.** `00:01` **Meredith Lamb (+14169386001)**

>
So your consistency checks are pretty consistent?

*💬 Reply*

**006.** `00:01` **You**

Any guy reads that and wilts\.


**007.** `00:01` **You**

No I know you are honest


**008.** `00:01` **You**

and I know when you are drunk you are especially so


**009.** `00:01` **You**

you asked me to share it


**010.** `00:01` **Meredith Lamb (+14169386001)**

lol


**011.** `00:01` **You**

I did\.


**012.** `00:01` **You**

and you confirmed AGAIN\.\. lol


**013.** `00:01` **You**

that it was true


**014.** `00:01` **Meredith Lamb (+14169386001)**

Glad you did


**015.** `00:02` **You**

yeah me too\.\. warm and fuzzies\.\.


**016.** `00:02` **You**

lol


**017.** `00:02` **Meredith Lamb (+14169386001)**

Honestly you realize that you don’t compare to Andrew right?


**018.** `00:02` **Meredith Lamb (+14169386001)**

Like it is awkward, having conversations with him now about it


**019.** `00:02` **Meredith Lamb (+14169386001)**

I don’t wanna lie to him


**020.** `00:03` **Meredith Lamb (+14169386001)**

It’s super awkward so I just need to get out of this house so that we don’t have these conversations in person\. At least text is easier\.


**021.** `00:03` **You**

>
I think I wouldn't compare favourably to Andrew in a number of areas\.\. and perhaps more favorable in others\.\. that would be the HONEST truth\.

*💬 Reply*

**022.** `00:03` **Meredith Lamb (+14169386001)**

Reaction: 👎 from Scott Hicks
Wrong


**023.** `00:03` **Meredith Lamb (+14169386001)**

Like I don’t even need to think about it


**024.** `00:03` **Meredith Lamb (+14169386001)**

I can immediately answer without even processing or thinking


**025.** `00:04` **Meredith Lamb (+14169386001)**

Which I don’t have an easy time doing


**026.** `00:04` **You**

I think you believe that because you love me like you do\.  And I appreciate that\.  but I think my statement was more objectively true\.


**027.** `00:05` **Meredith Lamb (+14169386001)**

OK so


**028.** `00:05` **Meredith Lamb (+14169386001)**

I drank the whole bottle of wine


**029.** `00:05` **You**

yep


**030.** `00:05` **Meredith Lamb (+14169386001)**

So here’s the thing


**031.** `00:05` **You**

now it gets interesting


**032.** `00:05` **You**

now she get's REAL


**033.** `00:05` **You**

lol


**034.** `00:05` **You**

buckle up\!\!\!


**035.** `00:05` **You**

I am self talking\.\. to prepare


**036.** `00:06` **Meredith Lamb (+14169386001)**

Like there’s no comparison with Andrew\. I’m not even sure how to state that differently or more effectively\.,\. I really don’t know how to say it differently so that you will understand it\.


**037.** `00:06` **Meredith Lamb (+14169386001)**

Where it gets more complicated


**038.** `00:06` **Meredith Lamb (+14169386001)**

Is like you feel more familiar to what I experienced before Andrew


**039.** `00:06` **Meredith Lamb (+14169386001)**

However


**040.** `00:07` **Meredith Lamb (+14169386001)**

I wasn’t who I am now the age I didn’t have kids\. I didn’t know what I know\. There’s so many differences that it all feels more satisfying and meaningful and it just feels like I actually chose this and followed some sort of weird path that I knew that you were a connection for me like an actual soulmate connection in a weird way, which wasn’t the case in earlier relationships


**041.** `00:08` **Meredith Lamb (+14169386001)**

Not sure if that makes sense


**042.** `00:08` **Meredith Lamb (+14169386001)**

I tried to explain to my mom the whole thing


**043.** `00:08` **Meredith Lamb (+14169386001)**

It was challenging


**044.** `00:08` **You**

I mean\.\. it is a catch all commentary\.


**045.** `00:08` **You**

It basically says don't bother comparing this is more important


**046.** `00:08` **You**

which is what GPT says


**047.** `00:08` **You**

but that isn't how humans think


**048.** `00:08` **You**

lol


**049.** `00:08` **Meredith Lamb (+14169386001)**

I did explain to my mom that at that conference in Florida\. I don’t remember anyone else I met not one person\. I only remember you\.


**050.** `00:09` **You**

she wouldn't have really engaged\.\. she probably doesn't believe in that kind othing


**051.** `00:09` **Meredith Lamb (+14169386001)**

I mean, when I explained the Florida thing she couldn’t really argue


**052.** `00:09` **Meredith Lamb (+14169386001)**

It is kind of weird, isn’t it?


**053.** `00:10` **You**

I am sure there are other people you remember\.


**054.** `00:10` **Meredith Lamb (+14169386001)**

No, not one


**055.** `00:10` **You**

I remembered you\.\. and someone else stood out but for different reasons


**056.** `00:10` **You**

Reaction: 🤔 from Meredith Lamb
because she was fucking insane


**057.** `00:10` **Meredith Lamb (+14169386001)**

Seriously, not one other person


**058.** `00:11` **You**

Well I am very happy I made that kind of impression\.  I am not sure why\.\. but I won't tell jaimie\.


**059.** `00:11` **You**

>
First time I met Katie Fotheringham

*💬 Reply*

**060.** `00:11` **Meredith Lamb (+14169386001)**

I don’t know who that is


**061.** `00:11` **You**

fucking nutbar


**062.** `00:11` **You**

worked for IESO


**063.** `00:11` **You**

and CLear Result


**064.** `00:11` **You**

Ehsan knows her well


**065.** `00:11` **Meredith Lamb (+14169386001)**

Actually, it was the first time I met Deb too, and I do remember that we were in a session and I do recall meeting her and talking to her


**066.** `00:11` **You**

she ran their New Construction program when I ran SBD Res and Comm


**067.** `00:12` **Meredith Lamb (+14169386001)**

DAD was brand new to Enbridge evaluation\. She didn’t know anything about an evaluation\.


**068.** `00:12` **You**

well Mer again\.\. what it doesn't do is compare\.\. because you are saying comparing is irrelevant\.  It is sweet\.\. but it is not the same\.\. lol


**069.** `00:13` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 00:13:21 \-0400
|
| I had been in eval for about 6 yrs at that point so I was 🙄
|
| Version: 1
| Sent: Fri, 18 Jul 2025 00:13:08 \-0400
|
| I had been in evil for about 6 yrs at that point so I was 🙄


**070.** `00:13` **You**

eval


**071.** `00:13` **You**

lol


**072.** `00:13` **You**

or evil


**073.** `00:13` **You**

Reaction: 😂 from Meredith Lamb
they both work


**074.** `00:13` **Meredith Lamb (+14169386001)**

Deb was so green I remember


**075.** `00:14` **Meredith Lamb (+14169386001)**

I do remember Deb being green


**076.** `00:14` **Meredith Lamb (+14169386001)**

Odd


**077.** `00:14` **Meredith Lamb (+14169386001)**

Not many people probably have that experience


**078.** `00:14` **You**

Well I do\.\. but yeah


**079.** `00:15` **Meredith Lamb (+14169386001)**

I remember her asking evaluation questions and it being very like ugh


**080.** `00:15` **Meredith Lamb (+14169386001)**

lol


**081.** `00:15` **You**

she was a fast learner


**082.** `00:15` **Meredith Lamb (+14169386001)**

Like I can actually picture her seated on this chair and I was standing


**083.** `00:15` **Meredith Lamb (+14169386001)**

Very fast learner very smart


**084.** `00:15` **Meredith Lamb (+14169386001)**

obviously


**085.** `00:16` **Meredith Lamb (+14169386001)**

It was just funny at the time because it was like ugh\. Someone knew to evaluation\. Yay\.


**086.** `00:16` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 00:17:06 \-0400
|
| You were all I’m a marketing person, but I’m just learning evaluation for fun so it was different
|
| Version: 1
| Sent: Fri, 18 Jul 2025 00:16:44 \-0400
|
| You were all I’m a marketing person, but I’m just learning a evaluation for fun so it was different


**087.** `00:17` **You**

I thought evaluation was a smart play


**088.** `00:17` **You**

learn all the rules of the game


**089.** `00:17` **You**

read and learn everything


**090.** `00:17` **You**

the more I knew the better I was


**091.** `00:18` **You**

So now that you are good and drunk and it is late


**092.** `00:18` **Meredith Lamb (+14169386001)**

Bed time?


**093.** `00:18` **You**

Do you have any questions you want to ask me


**094.** `00:19` **You**

No I am still wide awake but you can find you want to


**095.** `00:19` **You**

I will be up for a bit


**096.** `00:19` **You**

You kind of got me going


**097.** `00:19` **Meredith Lamb (+14169386001)**

I stole one of Mac’s vapes


**098.** `00:19` **You**

And you won’t remember some of this but you should read it back


**099.** `00:19` **Meredith Lamb (+14169386001)**

I will


**100.** `00:19` **Meredith Lamb (+14169386001)**

Everything before one bottle I remember


**101.** `00:19` **Meredith Lamb (+14169386001)**

I think it’s like a bottle and a half or the memory starts to go


**102.** `00:20` **Meredith Lamb (+14169386001)**

I feel like you need to be drunk before I ask you anything


**103.** `00:20` **You**

I am happy you feel the way you do but it doesn’t take insecurities away sorry being honest


**104.** `00:20` **You**

No


**105.** `00:20` **You**

You can ask me anything


**106.** `00:20` **You**

And I will be honest


**107.** `00:20` **Meredith Lamb (+14169386001)**

OK


**108.** `00:21` **Meredith Lamb (+14169386001)**

New information so let me process for a minute


**109.** `00:21` **Meredith Lamb (+14169386001)**

And Andrew and Maelle just arrived home so I just went up to my room


**110.** `00:21` **You**

K


**111.** `00:21` **Meredith Lamb (+14169386001)**

But will you be completely honest if you’re stone cold sober?


**112.** `00:21` **You**

Yes


**113.** `00:22` **You**

I might need to process the question but you will get an honest answer


**114.** `00:22` **Meredith Lamb (+14169386001)**

Ok so here’s one


**115.** `00:23` **Meredith Lamb (+14169386001)**

You said you didn’t like being intimate \(having sex\) with Jaimie\. Right? You said this\. So what got you through it … what did you think about


**116.** `00:24` **Meredith Lamb (+14169386001)**

Is that a good starter


**117.** `00:24` **You**

Other people


**118.** `00:24` **Meredith Lamb (+14169386001)**

lol


**119.** `00:24` **You**

Previous partner


**120.** `00:24` **You**

A


**121.** `00:24` **You**

S


**122.** `00:24` **You**

Is the follow up who?


**123.** `00:24` **You**

lol


**124.** `00:24` **Meredith Lamb (+14169386001)**

And you never thought this was an issue?


**125.** `00:25` **You**

I mean wait wait


**126.** `00:25` **Meredith Lamb (+14169386001)**

Do you do this with us?


**127.** `00:25` **You**

Ok remember I was 22
When I met Jaimie


**128.** `00:25` **You**

Sex wasn’t always bad or terrible


**129.** `00:25` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 00:25:59 \-0400
|
| I always forget how young you guys were
|
| Version: 1
| Sent: Fri, 18 Jul 2025 00:25:43 \-0400
|
| Forget, I always forget how young you guys were


**130.** `00:26` **You**

But not long after before kids\.\. I think I realized the lack of connection


**131.** `00:26` **Meredith Lamb (+14169386001)**

>
This was the follow up

*💬 Reply*

**132.** `00:26` **You**

Then it became more of a thing I still wanted her to be happy, wired that way\.\.


**133.** `00:26` **You**

>
Nope I told you

*💬 Reply*

**134.** `00:26` **You**

Already


**135.** `00:26` **You**

When we are together everything else fades


**136.** `00:27` **You**

Honestly not poetry it just is


**137.** `00:27` **You**

There is just you\. It has been that way from the first kiss


**138.** `00:27` **Meredith Lamb (+14169386001)**

Ok it feels like it but you promise?


**139.** `00:27` **You**

From before but definitely the first kiss told me a lot


**140.** `00:28` **You**

>
Yeah I already admitted to this without the question even being asked\.

*💬 Reply*

**141.** `00:28` **You**

I have to try so hard not to lose myself “control”


**142.** `00:28` **You**

Anyhow that was a wierd follow up given the intensity the eye contact the everything\.\.


**143.** `00:29` **Meredith Lamb (+14169386001)**

I know


**144.** `00:29` **You**

But if it was important to you\. Yeah there is only you


**145.** `00:29` **Meredith Lamb (+14169386001)**

Insecurity


**146.** `00:29` **You**

I told you I can close my eyes and still see your face from this nights


**147.** `00:29` **You**

Those


**148.** `00:29` **You**

That was too easy


**149.** `00:30` **Meredith Lamb (+14169386001)**

Ok question 2


**150.** `00:30` **Meredith Lamb (+14169386001)**

lol


**151.** `00:31` **Meredith Lamb (+14169386001)**

Next time we get to spend actual time together, what is happening?


**152.** `00:31` **Meredith Lamb (+14169386001)**

Same… diff…\.


**153.** `00:31` **Meredith Lamb (+14169386001)**

?


**154.** `00:32` **You**

Reaction: 😢 from Meredith Lamb
Ok you need to be more explicit\.\. if you are talking about the act… I dunno I think the way I work especially with you\.\. is that with long stretches in between I get anxious nervous and insecure all over again\.


**155.** `00:33` **You**

So if that’s what you are talking about it like progress over time but to where I mean I dunno I don’t have a roadmap\.


**156.** `00:34` **You**

I assume this was your question\.\. what do you want to happen\.


**157.** `00:34` **You**

I mean once we are more normal that doesn’t happen as much I think


**158.** `00:35` **Meredith Lamb (+14169386001)**

I don’t think you need to be insecure


**159.** `00:35` **Meredith Lamb (+14169386001)**

Blows my mind that you would even feel that way


**160.** `00:35` **You**

Oh listen you are amazing and supportive and patient I feel like I can have problems or hiccups or anything and it would be ok\.


**161.** `00:35` **You**

Again never felt that way about anyone


**162.** `00:36` **You**

But I still am the way I am\.  I want to make you happier than you have ever been every moment we are together\.\. it is just where is set my sights\.


**163.** `00:36` **Meredith Lamb (+14169386001)**

But…\.


**164.** `00:36` **You**

So yeah


**165.** `00:36` **Meredith Lamb (+14169386001)**

lol


**166.** `00:37` **Meredith Lamb (+14169386001)**

I felt the but


**167.** `00:37` **You**

Insecure that I cannot achieve that as well as others etc


**168.** `00:37` **You**

It is true mer sorry


**169.** `00:37` **Meredith Lamb (+14169386001)**

And you never wanted to do that with your wife?


**170.** `00:37` **Meredith Lamb (+14169386001)**

Explain that…


**171.** `00:38` **You**

I wanted to make her happy she was so sad all the time and completely insecure herself way worse than me\.\. but the same connection desire\.\. the ability to feel something back wasn’t there for me with her\.


**172.** `00:39` **You**

Again she wasn’t a bad person isn’t a bad person


**173.** `00:39` **You**

Just not my person


**174.** `00:40` **You**

These are still easy nothing hard yet but you didn’t answer mine


**175.** `00:40` **Meredith Lamb (+14169386001)**

What was yours?


**176.** `00:40` **Meredith Lamb (+14169386001)**

And why would I have hard questions?


**177.** `00:40` **Meredith Lamb (+14169386001)**

I’m chill


**178.** `00:40` **You**

Wha do you want to happen


**179.** `00:41` **Meredith Lamb (+14169386001)**

Huh? When? Wdym


**180.** `00:41` **Meredith Lamb (+14169386001)**

Context pls


**181.** `00:41` **You**

You asked me what did I want to happen next time we got together


**182.** `00:41` **You**

I assumed you meant sex wise\.\. I asked you same question


**183.** `00:42` **Meredith Lamb (+14169386001)**

For the record \(Gemini transcript are you listening?\) I didn’t mean sex


**184.** `00:43` **Meredith Lamb (+14169386001)**

I want time to happen


**185.** `00:43` **Meredith Lamb (+14169386001)**

Just time


**186.** `00:43` **Meredith Lamb (+14169386001)**

Do you want to know IN that time?


**187.** `00:43` **Meredith Lamb (+14169386001)**

lol


**188.** `00:44` **You**

You said


**189.** `00:44` **You**

Next time we get to spend actual time together, what is happening?


**190.** `00:44` **Meredith Lamb (+14169386001)**

Yes, I mean sex would be nice\. I miss your body incredibly


**191.** `00:44` **You**

And then same or different


**192.** `00:44` **You**

You were talking sex


**193.** `00:44` **You**

Monkey


**194.** `00:44` **Meredith Lamb (+14169386001)**

I mean, I was talking whatever came to mind


**195.** `00:44` **You**

Monkey was not a typo


**196.** `00:45` **Meredith Lamb (+14169386001)**

I know


**197.** `00:45` **You**

Gemini she was talking sexual stuff for sure


**198.** `00:45` **Meredith Lamb (+14169386001)**

lol


**199.** `00:45` **You**

So answer please


**200.** `00:45` **Meredith Lamb (+14169386001)**

I honestly don’t need to be having sex with you if that puts pressure on you like seriously


**201.** `00:45` **You**

I mean
That is a given


**202.** `00:45` **You**

But it is also what I want


**203.** `00:46` **Meredith Lamb (+14169386001)**

I just want to have time with you …\.time


**204.** `00:46` **You**

I want that too


**205.** `00:46` **Meredith Lamb (+14169386001)**

I mean, I’m fine to spend it having sex if you want lol


**206.** `00:46` **You**

Ok so you are going to dodge the sex question fair enough\.


**207.** `00:47` **You**

I mean the first question was good cause there was some vulnerability there\.\.


**208.** `00:47` **You**

Now you are jumping and dodging


**209.** `00:47` **Meredith Lamb (+14169386001)**

>
Which was…

*💬 Reply*

**210.** `00:47` **Meredith Lamb (+14169386001)**

I’m losing track


**211.** `00:48` **You**

What did I think about


**212.** `00:48` **You**

And then you asked about us


**213.** `00:48` **Meredith Lamb (+14169386001)**

So you’re grading my questions now?


**214.** `00:48` **Meredith Lamb (+14169386001)**

That’s fine


**215.** `00:48` **You**

I am just saying the first was good


**216.** `00:48` **Meredith Lamb (+14169386001)**

lol


**217.** `00:48` **Meredith Lamb (+14169386001)**

I like a challenge


**218.** `00:48` **You**

This last one you ran away from your own question


**219.** `00:48` **You**

For the record I told you I am up for anything g


**220.** `00:48` **Meredith Lamb (+14169386001)**

What are you talking about? I did not\.


**221.** `00:49` **You**

But for lack of a better term I need to warm up


**222.** `00:49` **Meredith Lamb (+14169386001)**

I am happy to warm up with you


**223.** `00:49` **Meredith Lamb (+14169386001)**

Anytime


**224.** `00:49` **You**

Ok so nothing different all the same?


**225.** `00:49` **You**

That was your question to me


**226.** `00:49` **You**

lol


**227.** `00:49` **Meredith Lamb (+14169386001)**

I don’t know what do you think? I’m curious what your thoughts are on this


**228.** `00:50` **Meredith Lamb (+14169386001)**

I feel like you’ve never really contemplated it


**229.** `00:50` **You**

Bullshit


**230.** `00:50` **Meredith Lamb (+14169386001)**

LOL


**231.** `00:50` **Meredith Lamb (+14169386001)**

OK


**232.** `00:50` **You**

You 100% have


**233.** `00:50` **Meredith Lamb (+14169386001)**

yeah but I kind of do what I want


**234.** `00:51` **Meredith Lamb (+14169386001)**

In time


**235.** `00:51` **You**

Mmmmmm you have not been leading


**236.** `00:51` **You**

Let’s be honest


**237.** `00:51` **Meredith Lamb (+14169386001)**

I feel like I’ve been pretty satisfied so if I’ve not been leading, then I guess I don’t have to


**238.** `00:51` **You**

Rofl


**239.** `00:52` **Meredith Lamb (+14169386001)**

I mean, I will lead more if I need to


**240.** `00:52` **You**

So now if you lead I will assume I am fairing poorly or you are bored


**241.** `00:52` **Meredith Lamb (+14169386001)**

LOL OMG


**242.** `00:52` **You**

You set it up


**243.** `00:52` **You**

It was
So easy


**244.** `00:52` **Meredith Lamb (+14169386001)**

I can’t even


**245.** `00:52` **You**

Just read


**246.** `00:52` **You**

lol


**247.** `00:53` **You**

I feel like I’ve been pretty satisfied so if I’ve not been leading, then I guess I don’t have to


**248.** `00:53` **You**

Hahah


**249.** `00:53` **Meredith Lamb (+14169386001)**

Doh\!


**250.** `00:53` **You**

Yes yes\.\.


**251.** `00:54` **Meredith Lamb (+14169386001)**

Change of topic …\. So what have you always desired but never done? Anything? Nothing?


**252.** `00:54` **Meredith Lamb (+14169386001)**

Did it in your 20s?


**253.** `00:54` **You**

We still talking physically or in general


**254.** `00:54` **Meredith Lamb (+14169386001)**

LOL


**255.** `00:54` **Meredith Lamb (+14169386001)**

Either


**256.** `00:55` **You**

Um I do t frel
Like there is much


**257.** `00:55` **You**



**258.** `00:56` **You**

I do like what you do to me\.\. surprisingly comfortable with it\.\. and it is pretty amazing\.\. so there is that\.


**259.** `00:56` **Meredith Lamb (+14169386001)**

>
Sad response

*💬 Reply*

**260.** `00:57` **You**

I think doing more of the same to you would be fun but you aren’t comfortable or don’t like


**261.** `00:57` **Meredith Lamb (+14169386001)**

>
Huh?

*💬 Reply*

**262.** `00:57` **You**

Comeon mer you cannot be that far gone


**263.** `00:57` **Meredith Lamb (+14169386001)**

I am on board with this but don’t understand the last half


**264.** `00:58` **You**

When you go down I go down\.\.


**265.** `00:58` **Meredith Lamb (+14169386001)**

lol


**266.** `00:58` **Meredith Lamb (+14169386001)**

Ahhhh


**267.** `00:58` **You**

That direct enough


**268.** `00:58` **Meredith Lamb (+14169386001)**

Yes


**269.** `00:58` **Meredith Lamb (+14169386001)**

Got it


**270.** `00:58` **You**

See honest answer


**271.** `00:59` **Meredith Lamb (+14169386001)**

Appreciate that


**272.** `00:59` **Meredith Lamb (+14169386001)**

But didn’t get it at first


**273.** `00:59` **Meredith Lamb (+14169386001)**

I stand firm in my beliefs


**274.** `01:00` **Meredith Lamb (+14169386001)**

It’s different for males and females


**275.** `01:00` **Meredith Lamb (+14169386001)**

But hey maybe I’m wrong


**276.** `01:00` **Meredith Lamb (+14169386001)**

But I believe it


**277.** `01:01` **Meredith Lamb (+14169386001)**

Also, ………\.\.


**278.** `01:01` **Meredith Lamb (+14169386001)**

Actually, I just did a whole bunch of dots because you do that to me all the time


**279.** `01:01` **Meredith Lamb (+14169386001)**

I didn’t feel like articulating that thought


**280.** `01:05` **You**

Kk


**281.** `01:05` **Meredith Lamb (+14169386001)**

I thought you passed out


**282.** `01:05` **You**

Well now we just need to find some time\.\. sometime


**283.** `01:05` **Meredith Lamb (+14169386001)**

I brushed my teeth


**284.** `01:06` **Meredith Lamb (+14169386001)**

Ready to pass out myself


**285.** `01:06` **Meredith Lamb (+14169386001)**

lol


**286.** `01:06` **You**

Reaction: 😂 from Meredith Lamb
I might have rested
My eyes


**287.** `01:06` **You**

Kk well you go to bed Mer
I hope I helped to take your anxiety off today


**288.** `01:06` **Meredith Lamb (+14169386001)**

You absolutely did


**289.** `01:07` **Meredith Lamb (+14169386001)**

I mean I feel like it was a great day


**290.** `01:07` **Meredith Lamb (+14169386001)**

When it wasn’t


**291.** `01:07` **Meredith Lamb (+14169386001)**

🤔


**292.** `01:07` **You**

Well I wanted to try to make you happy instead of stressed


**293.** `01:07` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 01:07:39 \-0400
|
| Confusing
|
| Version: 1
| Sent: Fri, 18 Jul 2025 01:07:31 \-0400
|
| Co fusing


**294.** `01:07` **You**

Could have done more in person


**295.** `01:07` **You**

Some other time


**296.** `01:08` **Meredith Lamb (+14169386001)**

>
Cottage?

*💬 Reply*

**297.** `01:08` **Meredith Lamb (+14169386001)**

My place next week? Wed


**298.** `01:08` **You**

Well that is current plan yeah


**299.** `01:08` **You**

Wed is a hard yes


**300.** `01:08` **Meredith Lamb (+14169386001)**

Tuesday night?


**301.** `01:08` **Meredith Lamb (+14169386001)**

lol


**302.** `01:09` **You**

Reaction: 😂 from Meredith Lamb
Mmm that would be tough


**303.** `01:09` **You**

I could come home


**304.** `01:09` **You**

So yeah


**305.** `01:09` **Meredith Lamb (+14169386001)**

I was pushing


**306.** `01:09` **You**

I can do things


**307.** `01:09` **Meredith Lamb (+14169386001)**

I am good with Wednesday


**308.** `01:09` **You**

Wed morning and work from there whatever you want just let me know but wait


**309.** `01:09` **You**

You have kids all week


**310.** `01:10` **Meredith Lamb (+14169386001)**

But during day and early evening doesn’t matter


**311.** `01:10` **You**

Kk


**312.** `01:10` **Meredith Lamb (+14169386001)**

Dog walker taking dogs


**313.** `01:10` **Meredith Lamb (+14169386001)**

No diff than mon, tues


**314.** `01:10` **You**

lol\. How early is early evening


**315.** `01:11` **You**

I am jking\.\. go to bed


**316.** `01:11` **Meredith Lamb (+14169386001)**

Depends on shadow


**317.** `01:11` **Meredith Lamb (+14169386001)**

No one else cares


**318.** `01:11` **You**

Yeah little shadow lol


**319.** `01:11` **Meredith Lamb (+14169386001)**

She’s getting better


**320.** `01:12` **Meredith Lamb (+14169386001)**

Fortunately, her best friend Ellie is going through a similar situation


**321.** `01:12` **Meredith Lamb (+14169386001)**

Her dad cheated on her mom back in the winter\. I told you this anyways her mom is dating now apparently


**322.** `01:12` **Meredith Lamb (+14169386001)**

Ellie is the only friend that Marlowe feels she can talk to about all of this


**323.** `01:12` **You**

Yeah confusing for kids


**324.** `01:12` **Meredith Lamb (+14169386001)**

Edited: 3 versions
| Version: 3
| Sent: Fri, 18 Jul 2025 01:13:13 \-0400
|
| Marlowe told Ellie that I was dating and Ellie was like yeah my mom’s dating too\. She talks to this guy for like hours on the phone, blah blah blah\.
|
| Version: 2
| Sent: Fri, 18 Jul 2025 01:12:57 \-0400
|
| Marlowe told Ellie that I was dating and Allie was like yeah my mom’s dating too\. She talks to this guy for like hours on the phone, blah blah blah\.
|
| Version: 1
| Sent: Fri, 18 Jul 2025 01:12:44 \-0400
|
| Marlowe told Ellie that I was dating and Allie was like yeah my mom’s dating too\. She talks this guy for like hours on the phone, blah blah blah\.


**325.** `01:12` **You**

Hehe


**326.** `01:13` **You**

Well now they can chat about that


**327.** `01:13` **Meredith Lamb (+14169386001)**

Yeah, they’ve been best friends for a couple years now


**328.** `01:13` **Meredith Lamb (+14169386001)**

Well, Kinda Marlowe has a couple of best friends\. It’s kind of weird\.


**329.** `01:13` **Meredith Lamb (+14169386001)**

Anyway, I’m ready for bed and I’m sure you’re super tired because you didn’t drink at all tonight


**330.** `01:14` **You**

Yep sleepy


**331.** `01:14` **Meredith Lamb (+14169386001)**

Did you take an SDO tomorrow?


**332.** `01:14` **You**

Yes


**333.** `01:14` **You**

I will be around tho


**334.** `01:14` **Meredith Lamb (+14169386001)**

Oh, that’s good


**335.** `01:14` **You**

Will be tough day\.\.


**336.** `01:14` **Meredith Lamb (+14169386001)**

OK, well I’m gonna go to sleep good night\. I love you\. Miss you\. 😢


**337.** `01:15` **You**

Love you too\.\. always missing you\.


**338.** `01:15` **Meredith Lamb (+14169386001)**

Thanks for cheering me up


**339.** `01:15` **You**

Same ☺️


**340.** `01:15` **You**

❤️


**341.** `01:15` **Meredith Lamb (+14169386001)**

😍


**342.** `01:15` **You**

Night hun\.


**343.** `07:00` **You**

Gah


**344.** `07:10` **You**

Tired going to be a rough day


**345.** `07:11` **You**

Reaction: 😂 from Meredith Lamb
Morning though\.\. ❤️ happy re reading you had some great dodges last night\!   Love ya\.


**346.** `07:47` **Meredith Lamb (+14169386001)**

Sleeping for 15 more minutes……\.


**347.** `08:20` **You**

lol


**348.** `08:20` **You**

I bet you are still sleeping


**349.** `08:32` **Meredith Lamb (+14169386001)**

I am up 😭


**350.** `08:32` **Meredith Lamb (+14169386001)**

I want to be sleeping tho


**351.** `08:32` **Meredith Lamb (+14169386001)**

Making coffee


**352.** `08:44` **You**

Lots of emotions here this morning\.\. going to be challenging to navigate\.\. hope you slept well


**353.** `08:47` **Meredith Lamb (+14169386001)**

I do not envy you at all\. Glad you took the day off


**354.** `08:59` **You**

Reaction: 😮 from Meredith Lamb
Js mom in the hospital again she is getting a pacemaker tomorrow she is a mess, I am trying to stand her up and help out, Gracie is attacking\.\. I am a bit of a mess a lot of guilt today\.\. I will get better\.\. don’t worry


**355.** `08:59` **You**

A shit ton of work to get the house ready\.\. with no help is going to be fun wish she had have engaged when I took those two weeks off\.


**356.** `09:00` **You**

Whatever I will likely work all weekend\.\. anyhow back at it ❤️


**357.** `09:00` **You**

Hope you have a good day and Andrew leaves you be\.


**358.** `09:05` **Meredith Lamb (+14169386001)**

It is going to be a big guilt day for you for sure… no words\. 😵‍💫
Love you ❤️


**359.** `12:19` **You**

How is your day


**360.** `12:33` **Meredith Lamb (+14169386001)**

Omg


**361.** `12:33` **Meredith Lamb (+14169386001)**

You?


**362.** `12:36` **You**

What’s wrong


**363.** `12:36` **You**

Please share


**364.** `12:36` **You**

I could use distraction


**365.** `12:37` **You**

Mine is ok getting through it lots of work left to do did a dump run need a donation run


**366.** `12:37` **Meredith Lamb (+14169386001)**

I’m OK now


**367.** `12:38` **You**

Almost all stuff packed but I have a lot to do myself


**368.** `12:38` **Meredith Lamb (+14169386001)**

It has just been a morning and a half


**369.** `12:38` **You**

Work or andrew


**370.** `12:38` **Meredith Lamb (+14169386001)**

Andrew


**371.** `12:38` **Meredith Lamb (+14169386001)**

Work? Lol


**372.** `12:38` **Meredith Lamb (+14169386001)**

Funny


**373.** `12:38` **You**

Whats he doing now


**374.** `12:38` **Meredith Lamb (+14169386001)**

I was just trying to understand the numbers so made my own spreadsheet


**375.** `12:38` **Meredith Lamb (+14169386001)**

I feel like I understand now


**376.** `12:39` **Meredith Lamb (+14169386001)**

I don’t necessarily like all of it


**377.** `12:39` **You**

Did anything I shared help I hope


**378.** `12:39` **Meredith Lamb (+14169386001)**

But if I don’t accept he will sell I think


**379.** `12:39` **Meredith Lamb (+14169386001)**

I don’t think he is bluffing


**380.** `12:39` **Meredith Lamb (+14169386001)**

We had a big convo


**381.** `12:39` **Meredith Lamb (+14169386001)**

I put together a spreadsheet for selling and I’m definitely worse off


**382.** `12:39` **Meredith Lamb (+14169386001)**

The market is the problem


**383.** `12:39` **You**

How?


**384.** `12:40` **Meredith Lamb (+14169386001)**

Our house is not renovated


**385.** `12:40` **Meredith Lamb (+14169386001)**

We bought high


**386.** `12:40` **Meredith Lamb (+14169386001)**

We just fucked up


**387.** `12:40` **Meredith Lamb (+14169386001)**

Is what it is


**388.** `12:40` **You**

Again your equity is your equity


**389.** `12:40` **You**

Which is low


**390.** `12:40` **You**

Compared to his


**391.** `12:40` **You**

So any fees would be proportionally dispersed


**392.** `12:40` **You**

If he sells he would be disproportionally worse


**393.** `12:40` **You**

It would be stupid


**394.** `12:41` **You**

I think he is forcing you to sacrifice but who am I to criticize I guess


**395.** `12:42` **Meredith Lamb (+14169386001)**

Yeah I’m still mulling over realtor fees but am fine on everything else


**396.** `12:42` **You**

Well only you can decide that right


**397.** `12:43` **You**

Anyhow any other trouble any more nonsense?


**398.** `12:54` **You**

Think you might have gotten busy maybe we can chat later\.


**399.** `13:11` **Meredith Lamb (+14169386001)**

Yeah we keep discussing


**400.** `13:11` **Meredith Lamb (+14169386001)**

I’m going to try to close this off today because it is bugging me


**401.** `13:40` **You**

Kk well gl hun hope you get what you think is fair


**402.** `14:04` **You**

Omfg


**403.** `14:04` **You**

The ultimate ask and I want to ask you if you are ok with me doing this\.


**404.** `14:04` **You**

I do need you to respond though


**405.** `14:05` **You**

Like


**406.** `14:05` **You**

She is asking me to go to a store to pick her something up


**407.** `14:05` **Meredith Lamb (+14169386001)**

lol


**408.** `14:05` **Meredith Lamb (+14169386001)**

Shut up


**409.** `14:05` **You**

It is bad


**410.** `14:05` **You**

Swear


**411.** `14:05` **Meredith Lamb (+14169386001)**

What


**412.** `14:05` **You**

Stufff


**413.** `14:05` **Meredith Lamb (+14169386001)**

Why is going to a store bad


**414.** `14:06` **You**

For single lonely people


**415.** `14:06` **Meredith Lamb (+14169386001)**

What are you kidding me that is so weird\. Why doesn’t she just order shit online?


**416.** `14:06` **You**

She would never go and I feel bad


**417.** `14:06` **You**

I dunno


**418.** `14:06` **You**

But please just tell me you ar wok


**419.** `14:06` **You**

Ok


**420.** `14:06` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 14:07:08 \-0400
|
| Whatever I don’t care you do you\!…my stupid microphone won’t work because I had an update on my laptop yesterday\. Today is so annoying\.
|
| Version: 1
| Sent: Fri, 18 Jul 2025 14:06:54 \-0400
|
| Whatever I don’t care you do you my stupid microphone won’t work because I had an update on my laptop yesterday\. Today is so annoying\.


**421.** `14:07` **You**

Yeah it is


**422.** `14:07` **You**

This is dumb as hell but I feel guilty


**423.** `14:07` **You**

I have someone she never will


**424.** `14:08` **Meredith Lamb (+14169386001)**

I mean it is dumb because you can order anything online nowadays


**425.** `14:08` **You**

Yeah well just give me a pass she is almost leaving and distraught and I am hustling trying to be nice


**426.** `14:08` **You**

I love you thank you for not berating me because you could


**427.** `14:09` **You**

You do care what I do pls just don’t be angry\.


**428.** `14:09` **You**

Pls


**429.** `14:10` **Meredith Lamb (+14169386001)**

I do care what you do generally but I don’t care about this\. Just think it is weird\. But I’m weird too so it doesn’t matter lol honestly


**430.** `14:10` **You**

Ok\.
Interested to see what kind of wierd\.


**431.** `14:11` **You**

❤️


**432.** `14:11` **You**

Will check in later


**433.** `14:11` **Meredith Lamb (+14169386001)**

I just mean I do weird things you don’t love


**434.** `14:11` **Meredith Lamb (+14169386001)**

lol


**435.** `14:11` **You**

I love you period even weird things


**436.** `14:11` **Meredith Lamb (+14169386001)**

It’s totally okay


**437.** `14:11` **You**

Thx


**438.** `14:14` **Meredith Lamb (+14169386001)**

❤️


**439.** `14:37` **You**

There was alot of wierd shit there


**440.** `14:37` **You**

\#vanillaforlife


**441.** `14:40` **You**

I saw some relatively scary and intimidating stuff\.\.


**442.** `14:40` **You**

If I questioned my adequacy last night I def questioned it today rofl\!\!\!


**443.** `14:48` **Meredith Lamb (+14169386001)**

So how did this come up? I’m so curious


**444.** `14:48` **Meredith Lamb (+14169386001)**

She just out of the blue asks you to do this?


**445.** `14:48` **Meredith Lamb (+14169386001)**

I can’t even imagine asking Andrew or anyone to do that for me


**446.** `14:48` **Meredith Lamb (+14169386001)**

Like can’t even comprehend


**447.** `14:49` **You**

She mentioned it a while ago but then never followed up\.


**448.** `14:49` **You**

I had bought her something previously for obvious reasons


**449.** `14:49` **You**

Since I was no longer engaging pretty much at all\.


**450.** `14:49` **You**

That was when she finally got mad at me


**451.** `14:50` **You**

She never had before


**452.** `14:50` **You**

Just sad,, but then it was like wtf am I expected to do


**453.** `14:50` **You**

And I said I Dino


**454.** `14:50` **You**

Dunno


**455.** `14:50` **You**

So she decided she wanted something and sent me to get it


**456.** `14:50` **You**

So\.\.


**457.** `14:50` **Meredith Lamb (+14169386001)**

Did she do that just to make you feel guilty


**458.** `14:51` **Meredith Lamb (+14169386001)**

Do you think?


**459.** `14:51` **You**

Um no


**460.** `14:51` **Meredith Lamb (+14169386001)**

Like she can just order online so easy


**461.** `14:51` **You**

She was happier for a while\.


**462.** `14:51` **Meredith Lamb (+14169386001)**

Why make you go when she can just go online


**463.** `14:51` **Meredith Lamb (+14169386001)**

I’m so confused


**464.** `14:51` **You**

I know but it doesn’t bother me


**465.** `14:51` **You**

She doesn’t want anyone to know


**466.** `14:51` **Meredith Lamb (+14169386001)**

I feel like there was an ulterior motive


**467.** `14:51` **You**

And if it gets shipped


**468.** `14:51` **You**

Someone could pick it up


**469.** `14:51` **You**

And open it


**470.** `14:51` **Meredith Lamb (+14169386001)**

All the places have discreet shipping


**471.** `14:52` **You**

When I got home she ran and hid it


**472.** `14:52` **Meredith Lamb (+14169386001)**

🙄


**473.** `14:52` **You**

Yeah yeah I know


**474.** `14:52` **You**

Pls just don’t judge me and don’t tell jim this should be one of the last really stupid things I am asked to do


**475.** `14:53` **Meredith Lamb (+14169386001)**

Omg I wouldn’t tell anyone


**476.** `14:53` **You**

I thought you would laugh at my jokes but you went this way lol


**477.** `14:53` **Meredith Lamb (+14169386001)**

I’m not judging either


**478.** `14:54` **You**

Ok


**479.** `14:54` **Meredith Lamb (+14169386001)**

How are the kids doing today


**480.** `14:54` **You**

Not great


**481.** `14:55` **Meredith Lamb (+14169386001)**

Naturally


**482.** `14:55` **You**

Maddie depressed Gracie difficult


**483.** `14:55` **Meredith Lamb (+14169386001)**

Tough day


**484.** `14:55` **You**

I told j again she cannot stay she could fly back in late August if she wants


**485.** `14:55` **You**

To see her friends for a week


**486.** `14:55` **You**

But I have shit to do and she will make it impossible


**487.** `14:55` **Meredith Lamb (+14169386001)**

And…


**488.** `14:55` **Meredith Lamb (+14169386001)**

How did that go over


**489.** `14:56` **You**

I mean she gets it


**490.** `14:56` **You**

She does


**491.** `14:56` **You**

We just have to see how tomorrow goes


**492.** `14:56` **You**

She had a one day grace Charlene will stay till Sunday if j cannot get everything ready


**493.** `14:56` **You**

So if needed that might happen depends on tonight and Gracie


**494.** `14:56` **You**

I am going to pick up Charlene from the airport so j had more time


**495.** `14:57` **You**

Should be a fun drive


**496.** `14:57` **You**

How are
You doing


**497.** `14:57` **You**

Close the book yet?


**498.** `14:58` **Meredith Lamb (+14169386001)**

No\. Had a meeting and summer school assignment to read and edit


**499.** `14:58` **Meredith Lamb (+14169386001)**

Going to close it now\-ish


**500.** `14:58` **You**

Busy mom


**501.** `14:58` **You**

Get some wine tonight


**502.** `14:58` **You**

You can ask me more questions\.


**503.** `14:59` **You**

With Charlene here I will likely steer clear


**504.** `15:00` **Meredith Lamb (+14169386001)**

I am definitely getting wine tonight, but I’m not gonna drink as much as last night because I gotta move tomorrow but I also have to move a couple things tonight so it’ll be a bit later and I’m getting a pedicure at 5:30 to try to destress


**505.** `15:00` **Meredith Lamb (+14169386001)**

I find them very relaxing


**506.** `15:00` **Meredith Lamb (+14169386001)**

And helpful


**507.** `15:00` **Meredith Lamb (+14169386001)**

So today is a good day


**508.** `15:00` **Meredith Lamb (+14169386001)**

For it


**509.** `15:01` **You**

Good well at least you will feel good\.\. we don’t have to do anything if you are busy\. I can amuse myself or find something to do\.


**510.** `15:02` **Meredith Lamb (+14169386001)**

So today I had to confirm cottage plans with Andrew and i was too chicken to ask him if it’s fine if you go up


**511.** `15:02` **Meredith Lamb (+14169386001)**

LOL


**512.** `15:02` **Meredith Lamb (+14169386001)**

I’m gonna get my comments in on this agreement and then I’ll tell him after


**513.** `15:06` **You**

Kk


**514.** `15:07` **Meredith Lamb (+14169386001)**

Little scared honestly lol


**515.** `15:08` **You**

why


**516.** `15:08` **You**

cat's out of bag


**517.** `15:10` **You**

I mean if you don't want to I get it\.\. and even if he reacts poorly\.\. I don't have to come\.  I don't want to cause problems


**518.** `15:30` **Meredith Lamb (+14169386001)**

Mac said to just not tell him


**519.** `15:30` **Meredith Lamb (+14169386001)**

lol


**520.** `15:30` **You**

I think that is a bad idea


**521.** `15:31` **Meredith Lamb (+14169386001)**

I think telling is probably right


**522.** `15:31` **Meredith Lamb (+14169386001)**

I will


**523.** `15:31` **You**

yeah


**524.** `15:31` **Meredith Lamb (+14169386001)**

Just after I send mediator my comments


**525.** `15:31` **You**

ok\.


**526.** `15:33` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 15:33:56 \-0400
|
| I mean, if he didn’t want you in this house I think he’s gonna react pretty strongly to the cottage but he doesn’t really have a say honestly
|
| Version: 1
| Sent: Fri, 18 Jul 2025 15:33:46 \-0400
|
| I mean, if he didn’t want you in this house I think he’s gonna react pretty strongly to the cottage but he doesn’t really have to stay honestly


**527.** `15:33` **You**

I thought he already agreed


**528.** `15:34` **You**

otherwise he couldn't bring people there


**529.** `15:34` **Meredith Lamb (+14169386001)**

That was before he knew about us / YOU specifically


**530.** `15:34` **You**

it is still a double standard


**531.** `15:34` **Meredith Lamb (+14169386001)**

If you were a stranger, he would be feeling differently


**532.** `15:34` **You**

if he says no, then he cannot bring people there either


**533.** `15:35` **Meredith Lamb (+14169386001)**

Oh, I’m not asking him sorry I misspoke\. I just am going to notify him


**534.** `15:35` **Meredith Lamb (+14169386001)**

I just have to deal with the reaction that’s all


**535.** `15:35` **You**

ah ok\.


**536.** `15:37` **You**

sorry I make your life difficult\.\. I am definitely not worth\.


**537.** `15:38` **You**

kidding \- mostly :\)


**538.** `15:38` **Meredith Lamb (+14169386001)**

You have not made my life difficult you have made my life easier


**539.** `15:38` **You**

HAHAHA


**540.** `15:38` **Meredith Lamb (+14169386001)**

So it’s funny you see it that way


**541.** `15:38` **You**

no


**542.** `15:39` **Meredith Lamb (+14169386001)**

Yes


**543.** `15:39` **Meredith Lamb (+14169386001)**

Absolutely


**544.** `15:39` **Meredith Lamb (+14169386001)**

150%


**545.** `15:39` **You**

I make you happier maybe\.\.


**546.** `15:39` **You**

but life hasn't been easy since me for sure\.


**547.** `15:40` **Meredith Lamb (+14169386001)**

I never said my life was easier since I met you\. I said you have made my life easier\.


**548.** `15:40` **Meredith Lamb (+14169386001)**

It is a coincidence that my life is difficult and I met you at the same time


**549.** `15:40` **Meredith Lamb (+14169386001)**

There is no cause and effect there


**550.** `15:41` **You**

Edited: 2 versions
| Version: 2
| Sent: Fri, 18 Jul 2025 15:41:31 \-0400
|
| Ah I see\.\. so you were separating anyways\.\. I had no influence on that?
|
| Version: 1
| Sent: Fri, 18 Jul 2025 15:41:17 \-0400
|
| Ah I see\.\. so you were separating anyways\.\. I had not influence on that?


**551.** `15:41` **Meredith Lamb (+14169386001)**

I mean, I like to believe that, but I’m not sure if it’s true, but I do like to believe that


**552.** `15:42` **Meredith Lamb (+14169386001)**

I like to believe that I was ready


**553.** `15:42` **Meredith Lamb (+14169386001)**

Finally


**554.** `15:42` **You**

I remember at one point\.\. when I was already falling for you but hadn't said anything


**555.** `15:42` **You**

you were talking about maybe living as roomates


**556.** `15:42` **Meredith Lamb (+14169386001)**

But he wouldn’t have gone for that


**557.** `15:42` **You**

Reaction: 😋 from Meredith Lamb
I had a hard time\.\. not saying anything lol


**558.** `15:42` **You**

that was before I told you I was separating


**559.** `15:42` **You**

I think\.'


**560.** `15:43` **You**

Well all I meant was yeah you were separating\.\. complicated\.\. but then add me\.\. more complicated\.


**561.** `15:43` **You**

all I meant


**562.** `15:44` **You**

>
Part of me worries you might not have

*💬 Reply*

**563.** `15:44` **Meredith Lamb (+14169386001)**

Honestly you helped me be strong and keep going through it quite frankly


**564.** `15:44` **You**

like you might have again stayed for the kids


**565.** `15:45` **Meredith Lamb (+14169386001)**

Maybe but I hope not


**566.** `15:45` **You**

or even for him


**567.** `15:45` **Meredith Lamb (+14169386001)**

The text was wearing on me


**568.** `15:45` **Meredith Lamb (+14169386001)**

I just couldn’t get over it


**569.** `15:45` **Meredith Lamb (+14169386001)**

Mental block


**570.** `15:45` **You**

well I would like to believe as well that you would have separated regardless\.


**571.** `15:46` **Meredith Lamb (+14169386001)**

I think I was more likely than you lol


**572.** `15:47` **You**

pfft


**573.** `15:47` **You**

no


**574.** `15:47` **You**

while i didnt feel the same about j as you did about a\.\.\. i was done


**575.** `15:49` **Meredith Lamb (+14169386001)**

I think you could have stayed with her forever easily out of duty


**576.** `15:49` **You**

no


**577.** `15:49` **You**

i decided i deserved a chance to be happy


**578.** `15:50` **You**

you influenced that part\.


**579.** `15:50` **You**

but I was already on the way out regardless


**580.** `15:52` **Meredith Lamb (+14169386001)**

Ok we both have muddy situations and did what we thought was best\. Nothing else really matters


**581.** `15:52` **You**

Just whatever happens next\.


**582.** `15:52` **You**

gotta do a bit more work\.\. will check in later\.  Very interested to see how comments and notification go\.


**583.** `15:54` **Meredith Lamb (+14169386001)**

Ok good luck\. I have pretty minimal comments at this point


**584.** `15:54` **Meredith Lamb (+14169386001)**

And I’m thinking of giving it 24 hrs


**585.** `15:58` **You**

Maybe good idea


**586.** `15:59` **Meredith Lamb (+14169386001)**

Mackenzie wasn’t even a year old yet\.

*📎 1 attachment(s)*

**587.** `15:59` **Meredith Lamb (+14169386001)**

Look at the date


**588.** `16:01` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**589.** `16:15` **You**

What does the end of that mean I am not stacking up and I know how I am


**590.** `16:15` **Meredith Lamb (+14169386001)**

All sex frequency related\.


**591.** `16:16` **You**

Yeah I think my gpt fears were right last night lol


**592.** `16:16` **Meredith Lamb (+14169386001)**

I couldn’t tell him “I will do better” because I knew I was tired, sick from taking metformin \(fertility drug\) and just couldn’t do better at that time\. I wasn’t going to lie


**593.** `16:16` **You**

But meh whatever


**594.** `16:16` **Meredith Lamb (+14169386001)**

I never lied to him


**595.** `16:17` **Meredith Lamb (+14169386001)**

I never promised to do better when I knew I wasn’t capable


**596.** `16:17` **You**

The phrase I will do better in that regard is awful


**597.** `16:17` **You**

So messed up


**598.** `16:17` **Meredith Lamb (+14169386001)**

I think it is many females experience


**599.** `16:17` **Meredith Lamb (+14169386001)**

Honestly


**600.** `16:17` **You**

Can you possibly think of I didn’t get sex that much I would say that


**601.** `16:20` **You**

>
Honestly never heard of it maybe I got

*💬 Reply*

**602.** `16:20` **Meredith Lamb (+14169386001)**

His response 🙄

*📎 1 attachment(s)*

**603.** `16:23` **Meredith Lamb (+14169386001)**

What? You haven’t


**604.** `16:23` **Meredith Lamb (+14169386001)**

Well it is


**605.** `16:23` **You**

No I have t


**606.** `16:24` **Meredith Lamb (+14169386001)**

Well I wish it wasn’t such a huge point of contention over the past 16\+ years but it was…


**607.** `16:24` **You**

I think you shared this with me before


**608.** `16:24` **You**

Or something like it


**609.** `16:24` **You**

Not the meta email


**610.** `16:25` **Meredith Lamb (+14169386001)**

>
This is the reason I shared the emails\.

*💬 Reply*

**611.** `16:25` **You**

It is amazing you even want to have sex with me lol


**612.** `16:25` **You**

>
Yeah but you did decide not to many times right

*💬 Reply*

**613.** `16:25` **Meredith Lamb (+14169386001)**

Yes, but everyone has a breaking point


**614.** `16:25` **You**

Like it was weaponized against you basically


**615.** `16:26` **You**

Honestly most fucked up thing


**616.** `16:26` **Meredith Lamb (+14169386001)**

>
It’s honestly surprising to me a little also\. I wasn’t fully ready to live alone and be happy\.

*💬 Reply*

**617.** `16:27` **You**

I have t gotten all the logs downloaded yet\.\. but really wanted to after last night


**618.** `16:27` **You**

Think I will now


**619.** `16:27` **You**

Reaction: 😂 from Meredith Lamb
I have some questions to ask my guy\.


**620.** `16:30` **Meredith Lamb (+14169386001)**

So this is way earlier on in the email thread that I’ve been sharing, but I can’t send this full email because it’s too embarrassing\. He listed seven complaints about me and this was the final one\.

*📎 1 attachment(s)*

**621.** `16:31` **Meredith Lamb (+14169386001)**

He hated my mom\. Still does\.

*📎 1 attachment(s)*

**622.** `16:33` **Meredith Lamb (+14169386001)**

>
Everything was very transactional so just be careful joking about “I did this for you so what are you going to do for me?” It triggers me big time\.

*💬 Reply*

**623.** `16:33` **Meredith Lamb (+14169386001)**

lol


**624.** `16:33` **Meredith Lamb (+14169386001)**

So sad I get really triggered because he tried to stop doing it the last 3 yrs but would always slip up


**625.** `16:34` **Meredith Lamb (+14169386001)**

And my blood would boil……\.\.


**626.** `16:36` **You**

It cannot be that embarrassing


**627.** `16:37` **Meredith Lamb (+14169386001)**

PO5 dropped


**628.** `16:37` **Meredith Lamb (+14169386001)**

Tech conference next week for sure


**629.** `16:39` **You**

>
sorry I mean this couldn't be that embarassing

*💬 Reply*

**630.** `16:39` **Meredith Lamb (+14169386001)**

>
It is …\. He complains that I got mad at him 3 to 4 times for waking me up during the night because of McKenzie\. McKenzie was 10 months old at the time\.

*💬 Reply*

**631.** `16:39` **Meredith Lamb (+14169386001)**

It’s a little embarrassing like honestly why wouldn’t I get mad??


**632.** `16:40` **Meredith Lamb (+14169386001)**

I nursed all three kids so did all of the night shifts until they were like nine months old and then after that I expected help at night and he’s complaining about me getting mad at him 3 to 4 times literally 3 to 4 times it’s fucking embarrassing


**633.** `16:40` **You**

eesh


**634.** `16:40` **Meredith Lamb (+14169386001)**

For a 10 month old like are you kidding me?


**635.** `16:40` **You**

I split night shifts


**636.** `16:40` **You**

we bottle fed


**637.** `16:40` **Meredith Lamb (+14169386001)**

It is really embarrassing that I put up with that shit


**638.** `16:40` **You**

oh


**639.** `16:41` **You**

that is what you meant


**640.** `16:41` **Meredith Lamb (+14169386001)**

I breastfed all my kids


**641.** `16:41` **You**

ok


**642.** `16:41` **Meredith Lamb (+14169386001)**

Until 9 months


**643.** `16:41` **You**

j could n ot


**644.** `16:41` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
So I was up every night all night with all three of them


**645.** `16:41` **You**



**646.** `16:42` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**647.** `16:42` **Meredith Lamb (+14169386001)**

You have to admit that’s kind of embarrassing for a 10 month old??


**648.** `16:42` **Meredith Lamb (+14169386001)**

Like I got maybe needing help for a newborn or something


**649.** `16:42` **You**

yep


**650.** `16:42` **Meredith Lamb (+14169386001)**

But why wake me up for a 10 month old??


**651.** `16:43` **Meredith Lamb (+14169386001)**

Anyway it was a disaster from the beginning lol


**652.** `16:43` **You**

I just feel sad\.


**653.** `16:43` **Meredith Lamb (+14169386001)**

Why? Sad house


**654.** `16:43` **You**

and other things


**655.** `16:44` **You**

sad for your situation


**656.** `16:44` **Meredith Lamb (+14169386001)**

Oh you don’t need to


**657.** `16:44` **Meredith Lamb (+14169386001)**

So long ago


**658.** `16:44` **Meredith Lamb (+14169386001)**

But I was ready to leave


**659.** `16:44` **You**

I think maybe\.\.\. here this is what it is


**660.** `16:44` **You**

i got it


**661.** `16:44` **You**

I deal with time differently that you\.\. and maybe others\.


**662.** `16:44` **You**

some


**663.** `16:45` **You**

I can remember things\.\. details\.\. vividly from childhood on up\.\. so memories are more fresh and real\.\. so are the feelings associated with them


**664.** `16:45` **You**

I think sometimes I assume others feel the same


**665.** `16:45` **Meredith Lamb (+14169386001)**

No, definitely not\. I don’t think many people are like that\.


**666.** `16:45` **You**

I think that is in part why the past has an impact on me so much


**667.** `16:46` **You**

because if you could remember intimately how you felt in some of the situations you described\. like I can\.\.


**668.** `16:46` **You**

then I would well insecure lol


**669.** `16:48` **You**

kind of makes sense from my perspective


**670.** `16:50` **You**

I would feel


**671.** `16:50` **Meredith Lamb (+14169386001)**

I have general feelings I remember being nagged at a lot, nitpicked sort of almost harassed at times and having the same conversation over and over and over and over again for years and years so like I can remember the general feelings and stuff, but not the specific conversations


**672.** `16:51` **Meredith Lamb (+14169386001)**

I’m gonna have a 20 minute nap before my pedicure FYI


**673.** `16:51` **Meredith Lamb (+14169386001)**

lol


**674.** `16:52` **You**

have fun enjoy your time


**675.** `16:52` **You**

I have some ai stuff I want to work on


**676.** `16:52` **Meredith Lamb (+14169386001)**

lol k


