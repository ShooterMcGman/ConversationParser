# Daily Conversation: 2025-05-21 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-21 |
| **Day** | Wednesday |
| **Week** | 6 |
| **Messages** | 109 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-21T04:14 - 2025-05-21T22:06 |

## 📝 Daily Summary

This day contains **109 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:14` **You**

Reaction: ❤️ from Meredith Lamb
Morning 💕\.   Nothing like waking up to Morgan and thinking about the person that got me addicted to his magical mustache\!\!\!  Love you mer\. Off to the gym I go 😋


**002.** `06:24` **You**

Reaction: 😢 from Meredith Lamb
Going into office today cannot deal with home\. 😣


**003.** `07:02` **Meredith Lamb (+14169386001)**

I woke up at 6am to a dream of us kissing\. First time I think\. 🫠


**004.** `07:03` **Meredith Lamb (+14169386001)**

Went back to sleep for an hour thinking of that\. Sigh\. Up now


**005.** `07:09` **You**

lol nice dream… I would take that dream every day for sure\.


**006.** `07:14` **Meredith Lamb (+14169386001)**

Yes and now I get to chauffeur again\. 🤦‍♀️ fml


**007.** `07:15` **You**

Yeah that’s right early day for you\.\. have fun\.\. I have to go home get my work shit wait to drive Maddy at 9 then in to work


**008.** `08:30` **Meredith Lamb (+14169386001)**

WHMIS done\. 😝


**009.** `08:30` **Meredith Lamb (+14169386001)**

Did it with coffee this morning


**010.** `08:33` **You**

The excitement continues\!\!\!


**011.** `08:33` **Meredith Lamb (+14169386001)**

Super boring but was easy fortunately


**012.** `08:33` **You**

I will do later I think kind of not overly motivated today\.


**013.** `09:12` **You**

There my chauffeuring is done driving into office now


**014.** `09:37` **Meredith Lamb (+14169386001)**

My internet just randomly went out


**015.** `09:37` **Meredith Lamb (+14169386001)**

No idea why


**016.** `09:49` **You**

That sucks\.\. maybe work in area\.


**017.** `09:55` **Meredith Lamb (+14169386001)**

Neighbours is down too\. And 310\-BELL number isn’t even working\.


**018.** `09:55` **Meredith Lamb (+14169386001)**

Something major must be wrong


**019.** `09:55` **You**

Carolyn’s was down too


**020.** `09:55` **You**

Works in here lol


**021.** `09:56` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**022.** `09:56` **Meredith Lamb (+14169386001)**

At least it isn’t just me\. Thought it was just me\.


**023.** `10:09` **Meredith Lamb (+14169386001)**

How many people are offline?


**024.** `10:09` **Meredith Lamb (+14169386001)**

It isn’t coming back on argh


**025.** `10:10` **You**

I think Carolyn is off too


**026.** `10:12` **Meredith Lamb (+14169386001)**

That’s it?\!


**027.** `10:13` **Meredith Lamb (+14169386001)**

Hmm should I come into office?


**028.** `10:13` **Meredith Lamb (+14169386001)**

Oh wait


**029.** `10:13` **Meredith Lamb (+14169386001)**

I thought it was back on but no


**030.** `10:25` **You**

Maybe you should come in 🙂


**031.** `10:31` **Meredith Lamb (+14169386001)**

lol will decide in a minute


**032.** `15:13` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**033.** `15:14` **You**

Max replacement lucky you didnt get more than bruh\.\.


**034.** `15:14` **You**

lol


**035.** `15:15` **Meredith Lamb (+14169386001)**

😇


**036.** `15:15` **You**

lol


**037.** `15:15` **Meredith Lamb (+14169386001)**

I mean we all know it is true


**038.** `15:15` **Meredith Lamb (+14169386001)**

I just said it out loud


**039.** `15:15` **You**

I know she prolly doesn’t want to hear it lol


**040.** `15:16` **You**



**041.** `17:38` **You**

Pouring rain\.\. awesome\!


**042.** `17:56` **Meredith Lamb (+14169386001)**

All day basically


**043.** `17:56` **You**



**044.** `17:57` **You**



**045.** `18:18` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**046.** `18:20` **You**

Miss dogs


**047.** `18:20` **You**

Reaction: 😂 from Meredith Lamb
Not bo


**048.** `18:35` **Meredith Lamb (+14169386001)**

So today you called me bossy \(on the weekend\) at least twice\. You are going to have to clarify if this was a negative thing\. I’m not sure I was “bossy” per se……


**049.** `18:35` **You**

You weren’t at all\.  Sarcasm


**050.** `18:35` **You**

You never are


**051.** `18:35` **You**

It is a carryover


**052.** `18:36` **You**

From when you said you were the boss outside of work


**053.** `18:36` **You**

And in the context you used it\.\. you can be the boss of me whenever


**054.** `18:38` **You**

Should have been more jokey I guess


**055.** `18:39` **Meredith Lamb (+14169386001)**

Okay, just clarifying … thought it might be important


**056.** `18:39` **You**

No\.\. you do focus in on interesting things\.


**057.** `18:40` **Meredith Lamb (+14169386001)**

Again, is this negative feedback? Lol I can’t tell


**058.** `18:44` **You**

Errrrrrrrr no mer\.\. everything ok?  Just an observation we talk about all kinds of shit and joke back and forth just hard to predict what you focus in on sometimes\. I don’t think you are bossy\.\. man I need to be careful with my sarcasm and jokes lol\.


**059.** `18:45` **You**

I told you last night I thought or maybe today\.\. or some time recently I love everything about you\.\. there isn’t anything I don’t like\.


**060.** `18:46` **You**

I do promise if I have a real problem I would never hesitate to tell you\.\. not these stupid insecurities and shit I mentioned earlier today, but something real\.  If it bothers me I will tell you, and I hope you do likewise because that kind of communication is really important\.


**061.** `18:47` **You**

Sorry if I said something to bother you you\.\. wasn’t intended\.


**062.** `18:47` **You**

What even triggered the thought?


**063.** `18:48` **Meredith Lamb (+14169386001)**

No I’m fine… I just equate bossy to bad so was just checking


**064.** `18:49` **You**

Could you share with me your bad words?


**065.** `18:49` **Meredith Lamb (+14169386001)**

lol


**066.** `18:49` **You**

Just so I can avoid them


**067.** `18:49` **Meredith Lamb (+14169386001)**

Omg I will start a list and share later


**068.** `18:49` **Meredith Lamb (+14169386001)**

:p


**069.** `18:50` **You**

So you know I am thinking bossy like the safe word is…


**070.** `18:50` **You**

Sooooooo plus, I literally had to beg you to let me do work on the weekend lol


**071.** `18:51` **Meredith Lamb (+14169386001)**

Whatever you did tons


**072.** `18:55` **You**

Still you didnt boss me around ever\.


**073.** `18:59` **Meredith Lamb (+14169386001)**

Well you don’t have to change your story now\. As long as it didn’t bother you I’m good\. 🙂 lol


**074.** `19:06` **You**

Reaction: 😂 from Meredith Lamb
Ohhhhhhh come onnnnnnnnn


**075.** `19:14` **You**

>
There are all kinds of things you do that bother me\.\. but none of them are in bad ways\. 🤪

*💬 Reply*

**076.** `19:19` **You**

btw there is another aspect to this younger more sensitive me\.\. I don't think the Sailor song does it justice\. I just think you need some happier things to focus on / look forward to\.


**077.** `19:23` **Meredith Lamb (+14169386001)**

>
We are still very much getting to know each other so it’s a bit weird \(for lack of a better word sorry\) and just want to ensure I’m not bothering you for real\. Negative bothering you\.

*💬 Reply*

**078.** `19:23` **Meredith Lamb (+14169386001)**

>
Of course I do\. Don’t we all?

*💬 Reply*

**079.** `19:37` **You**

>
Ok\.\. so we can get this part of the getting to know each other out of the way\.  I have made a LOT of mistakes throughout my life, throughout this relationship and previous\.  Some of those I am hard wired for\.\. can't change\.\. I am intense, sometimes people find that \- stifling, overbearing, smothering etc\.\.\. and with this kind of love, it is a whole new thing, and I really am trying to hold it back\.  But other things, like not communicating when things are tough, like really tough, or when something happens that really bothers or hurts me, I will never hold that back from you\.  I have already told you and shared things with you that haven't and would never be comfortable sharing with anyone else ever\. I know we are new \- and there are going to be quirks and things that pop up over time\.\. but the really big things\.\. the, can you trust me to be patient, to wait this out, to support you through this process, to not hurt you, while I know you still need to believe on your end, I cannot be more emphatic that this is something you absolutely do not need to be concerned with\.  The communication \- you know everything I do that really matters\.\. small fears and insecurities are mine to bear, and are not coming from anything you have given me cause to be concerned with\.\. they come from a history of being cheated on and taken advantage of\.\. they are not a reflection of anything you have done, or not done\.  I don't just worry about you 95% of the time\.\. but alot of what I am worried about is connected to you, and to the relationship I hope we get to have\.  It does have to do with my situation, what this looks like when I am done, what kind of flexibility and freedom I will have\.  If you were really bothering me\.\. why have I tried every excuse possible to find time to be with you be that for moments, or days at a time\.\.\. from the parks, to suggesting maybe you come in for the day, to looking at timetables 3 weeks from now lol\.\. When I joke with you it is meant to be that way only\.\. I poke fun, I am sarcastic\.\. but I think I am realizing that you have been insulted and kicked, and marginalized for a really long time\.\. and that is where you are really sensitive\.  And I am sorry that I didn't pay attention to that before\.\. being called self\-centered, lazy, making things more difficult\.\.\. all of that is complete bullshit\.\. but I think it might have done a bit of damage too\.  So while this is long and drawn out\.\.\. as is my style\.\.\. please take comfort that I mean everything here\.   And while I know given any circumstance where I come across you in life, I have no doubt I would fall in love with you, I think it being later on in life gives me a perspective and an appreciation that I could never have really had before now, and it just makes this that much more special and important to me\.

*💬 Reply*

**080.** `19:42` **You**

you should take a min I don't say any of that lightly\.\. and if you have any questions as I have told you before\.\. I will answer anything\.


**081.** `19:45` **You**

That was a lot\.\. I hope I didn't say something wrong LOL


**082.** `19:47` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
That was looong but I appreciate it\. I’m not sure if I’ve been marginalized but I’ve certainly dealt with a major um, complainer I guess is the right word\. I mean even when we were dating\. I didn’t listen to that red flag\. Doh\. So I am probably a little sensitive to things that could be construed as complaining or critiquing maybe is a better word\. Not sure\. I didn’t complain about anything until 3 yrs ago when I said fuck it\. I grew up with my mom being a constant nag to my dad and complaining all the time so I vowed not to be like that\. My therapist says I went too far to the extreme to my detriment\. But whatever\. Done now\. So yeah I’m probably overly sensitive to negative connotation words like bossy\. lol


**083.** `19:50` **You**

You deserve a lot more \- please just understand you can ask me anything\.\. you will get an answer\.\. and you do not need to reciprocate\.\. we are different people will different levels of comfort in sharing, but I think similar in some ways of needing reassurance or understanding\. So any time, on any topic, do not hesitate to ask, even if you think it might bother me etc\.


**084.** `19:53` **Meredith Lamb (+14169386001)**

I asked\. We resolved\. And we are still apart\. 😒


**085.** `19:54` **You**

Not tomorrow morning we aren't 😊


**086.** `19:54` **Meredith Lamb (+14169386001)**

lol k\.\.


**087.** `19:58` **You**

Look I want everything\.\. I think you know that right?  I don't know if that scares you a bit\.\. it scares me a lot\.\. I want everything but I am willing to take whatever we can have at whatever time we can have it\. It is almost june\.\. time will hopefully get going faster or feel like it once we start making legal progress\.\. most of july I will be focused on moving\.\. but then there is august\.\. so some potential?  And whatever we can find in the meantime, is fine by me\.  I hope it is enough for you as well\.


**088.** `20:03` **Meredith Lamb (+14169386001)**

I’m not really scared by that no\. More scared by us getting annoyed at the whole thing\. Not if we can find time but if we can’t I guess\. But it doesn’t occupy my mind a whole lot really\.


**089.** `20:03` **Meredith Lamb (+14169386001)**

But I think after the weekend things get a tad more difficult…


**090.** `20:03` **You**

even if we couldn't find a minute together for the rest of this year\.\. as miserable as that would make me\.\. it wouldn't change anything that matters to me\.


**091.** `20:04` **Meredith Lamb (+14169386001)**

But it is okay… lots to sort through\.


**092.** `20:04` **You**

>
what do you mean?

*💬 Reply*

**093.** `20:05` **Meredith Lamb (+14169386001)**

Just knowing it will not be an even semi\-regular occurrence, if at all\. That’s all


**094.** `20:05` **Meredith Lamb (+14169386001)**

>
Somehow I doubt this\. lol

*💬 Reply*

**095.** `20:05` **Meredith Lamb (+14169386001)**

You don’t think you would explode


**096.** `20:06` **You**

>
Mer come on\.\. seriously\.\. whatever explosions occur wouldn't change how I feel\.\. I think as long as we reassured each other\.\. we would be fine\.  And we just might need that more often than not, if we had to be apart that long\.  And trust would be pretty big too\.\. which I have\.

*💬 Reply*

**097.** `20:07` **You**

>
we sure as hell won't get 4 days together like that\.\. but I have to believe we will find some time\.\. date nights at the water would be good enough for me or like I said, park in the morning\.  I mean I am speaking for me\.\. I cannot speak for you\.

*💬 Reply*

**098.** `20:12` **You**

Listen if you feel differently\.\. please don't be afraid to say so Mer\.\. I mean if you are worried about me \- I think you said it earlier\.\. I hope I haven't given you any reason to think I would ever walk away from this for any reason\.


**099.** `20:14` **Meredith Lamb (+14169386001)**

No not worried about you at all\. Just the situation\. But honestly, there is so much going on and things seem to have been just falling into place so far, hopefully it will continue that way\.


**100.** `20:15` **Meredith Lamb (+14169386001)**

So we can put a pin in this and continue to do what we do… hope for the best\. More time, opportunities, whatever…\.


**101.** `20:15` **You**

>
Honestly Mer, I will do the best I can\.

*💬 Reply*

**102.** `20:16` **Meredith Lamb (+14169386001)**

Same :\)


**103.** `20:17` **You**

>
But again\.\. and I am just being honest\.\. I am not built this way\.\. so please be patient with me, because I know this is going to be hard\.\. and I definitely will slip up now and then\.

*💬 Reply*

**104.** `20:18` **You**

Anyhow\.\. we can drop it, I know it is too heavy\.\.\.\.


**105.** `20:21` **Meredith Lamb (+14169386001)**

You have not slipped up\.


**106.** `20:39` **Meredith Lamb (+14169386001)**

I feel bad if I caused unnecessary drama tonight\. I know you don’t need it with your drama at home\. Just know, I love you\. ❤️


**107.** `20:42` **You**

Reaction: ❤️ from Meredith Lamb
>
There is nothing to feel bad about \- we lean on each other, we pick each other up, we find our moments, and then we maximize the minutes, hours or days we have, until that isn't an issue anymore\.  Rinse and repeat until then\.  Just know I love you too ❤️ \- you are everything to me, my home, and my friend\.

*💬 Reply*

**108.** `21:43` **Meredith Lamb (+14169386001)**

Off to bed\. Sweet dreams\. 💤 see you tomorrow\. Xoxo


**109.** `22:06` **You**

Reaction: 😢 from Meredith Lamb
Massive fight here really bad hope your night was better\.  Nite ❤️😩


