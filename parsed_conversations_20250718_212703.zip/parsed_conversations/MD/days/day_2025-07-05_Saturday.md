# Daily Conversation: 2025-07-05 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-05 |
| **Day** | Saturday |
| **Week** | 12 |
| **Messages** | 174 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-05T00:15 - 2025-07-05T21:45 |

## 📝 Daily Summary

This day contains **174 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:15` **You**

I will be forever in love with you Mer\.\. it’s true… and the movie was meh\.


**002.** `00:16` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
❤️
Bad movie\. Lol I’m passing out momentarilyZzzzz…\.


**003.** `00:16` **You**

I will be going back to sleep soon


**004.** `00:17` **Meredith Lamb (+14169386001)**

Soon …\. You only have 4 hrs hop to it 😛


**005.** `00:18` **You**

>
I have slept already I will be fine

*💬 Reply*

**006.** `00:21` **You**

Go to sleep knowing that what happened last weekend will only ever happen with you\.\. and that I always have the image of your face from that night in my mind\.\. I love only you\.\. we just have to figure out a few small details before we can chase forever together\.


**007.** `00:21` **You**

❤️❤️❤️


**008.** `00:22` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I had a bottle and a half of wine and a gummy so being reminded about last weekend isn’t helpful right now lol but I love you


**009.** `00:23` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**010.** `00:23` **You**

Just go with wherever the thoughts take you and have a good sleep\.


**011.** `00:24` **You**

Boo

*💬 Reply*

**012.** `00:25` **Meredith Lamb (+14169386001)**

lol


**013.** `00:28` **Meredith Lamb (+14169386001)**

k, I’m going to go to bed for real unless you are awake and can’t sleep lol


**014.** `00:28` **Meredith Lamb (+14169386001)**

🤔


**015.** `00:28` **You**

lol why the thinking face


**016.** `00:29` **Meredith Lamb (+14169386001)**

Just wondering if you are awake or going back to sleep


**017.** `00:29` **Meredith Lamb (+14169386001)**

Seriously curious


**018.** `00:29` **You**

I can do either was waiting on you tbh


**019.** `00:29` **Meredith Lamb (+14169386001)**

Because when we are together and we go to sleep, we go to sleep


**020.** `00:30` **Meredith Lamb (+14169386001)**

No waking


**021.** `00:30` **You**

I know except when I wake up early


**022.** `00:30` **You**

And watch you sleep


**023.** `00:30` **You**

And say nice things to you


**024.** `00:30` **Meredith Lamb (+14169386001)**

Well yeah given


**025.** `00:30` **Meredith Lamb (+14169386001)**

Used to that now


**026.** `00:31` **Meredith Lamb (+14169386001)**

I mean I don’t hate it


**027.** `00:31` **Meredith Lamb (+14169386001)**

You bring coffee


**028.** `00:31` **Meredith Lamb (+14169386001)**

lol


**029.** `00:31` **You**

I try lol


**030.** `00:31` **Meredith Lamb (+14169386001)**

Watching 😵‍💫


**031.** `00:31` **You**

It isn’t weird it is a love thing


**032.** `00:32` **Meredith Lamb (+14169386001)**

k…


**033.** `00:32` **Meredith Lamb (+14169386001)**

<nods head>


**034.** `00:33` **You**

lol it is you are peaceful and beautiful and just\.\. you\.


**035.** `00:33` **Meredith Lamb (+14169386001)**

Very peaceful


**036.** `00:33` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Dreaming of murder or something probably


**037.** `00:33` **Meredith Lamb (+14169386001)**

lol


**038.** `00:33` **You**

And very beautiful Mer\. Don’t forget that\.


**039.** `00:34` **Meredith Lamb (+14169386001)**

Wanna come over?


**040.** `00:35` **Meredith Lamb (+14169386001)**

Kidding lol


**041.** `00:35` **You**

lol


**042.** `00:35` **You**

Wish\.\. some other time


**043.** `00:35` **Meredith Lamb (+14169386001)**

Marlowe in my room\. Andrew downstairs lol


**044.** `00:37` **You**

Reaction: ❤️ from Meredith Lamb
Listen you go to sleep… I am going to try to shut back down again\.\. might be a bit challenging given our discussion but I will figure it out\.


**045.** `00:38` **Meredith Lamb (+14169386001)**

k I’m passing out for sure zzzz … gnite miss u 😢


**046.** `00:38` **You**

Night I love you and miss you always\.🥲


**047.** `05:01` **You**

Well wine and gummies to the rescue again\.  Thanks for picking me up out of my hole Mer\.  I wish it would be the last one, but my life sure has not been blessed outside of my time with you\.


**048.** `05:09` **You**

I guess I better get going to get my morning run in\. This won’t be a heavy workout day because that is tomorrow\.  I asked j to get up early this morning to work so will see how that goes\.\. not sure what your day looks like but I hope it is a good one\.  If timing and weather allow would love to see you Monday and/or Tuesday for a few mins at park\.\. because again I think we might be in store for a drought as it relates to seeing each other and it might be by far the worst one yet\.  I always seem to fair worse in those\.  We’ll see\.  Anyway up I get seize the day and all that shit\.  Love you Mer\. Will be thinking about you today no matter what I am doing or where I am at\.


**049.** `07:14` **You**

Fasted 40 min interval sprint / jog / walk program 850 cals \+ core workout… absolutely done…\.\.


**050.** `07:22` **You**

Down to 220\.\. but lost a bit of muscle mass\.\. no surprise after last weekend and all
The wine lol


**051.** `07:36` **You**

Reaction: ❤️ from Meredith Lamb
Tomorrow should be better

*📎 1 attachment(s)*

**052.** `07:36` **You**

Could use a pic of you\.\. just saying\.  Hope you slept well\.


**053.** `08:25` **You**

Hey one other thing\.\. I feel a bit weird but the Andrew thing is bothering me too… would it bother you if Jaimie was suddenly really nice to me like that\.\. am I in my own head again on this?


**054.** `08:29` **You**

Lots to read no skipping\.


**055.** `08:58` **You**

And now off to taxi my wife around\.\. who wouldn’t want to stay in my life atm god I don’t know\. Eeesh


**056.** `09:00` **You**

Edited: 2 versions
| Version: 2
| Sent: Sat, 5 Jul 2025 09:08:03 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Sat, 5 Jul 2025 08:25:29 \-0400
| >
| > Hey one other thing\.\. I feel a bit weird but the Andrew thing is bothering me too… would it bother you if Jaimie was suddenly really nice to me like that\.\. am I in my own head again on this?
|
| I know you want to be amicable I get it just weird feeling…………\.\.
|
| Version: 1
| Sent: Sat, 5 Jul 2025 09:00:03 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Sat, 5 Jul 2025 08:25:29 \-0400
| >
| > Hey one other thing\.\. I feel a bit weird but the Andrew thing is bothering me too… would it bother you if Jaimie was suddenly really nice to me like that\.\. am I in my own head again on this?
|
| I know you want to be amicable I get it just weird feeling\.


**057.** `10:13` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**058.** `10:16` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**059.** `10:18` **Meredith Lamb (+14169386001)**

>
Happy to do park Monday

*💬 Reply*

**060.** `10:20` **Meredith Lamb (+14169386001)**

I’m just waking up lol


**061.** `10:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**062.** `10:31` **You**

Reaction: 😬 from Meredith Lamb
Just at sparkle
Light now


**063.** `10:34` **Meredith Lamb (+14169386001)**

My towels from Etsy

*📎 1 attachment(s)*

**064.** `10:35` **Meredith Lamb (+14169386001)**

>
Maybe try Home Depot or lowes lol

*💬 Reply*

**065.** `10:42` **You**

>
lol cute

*💬 Reply*

**066.** `10:42` **You**

>
Nope done here

*💬 Reply*

**067.** `10:43` **You**

Will have some questions for you later hard to read and do this


**068.** `10:43` **You**

Sorry bout all the shit you had not resd


**069.** `12:05` **You**

Read was what I meant


**070.** `12:05` **You**

At Costco now


**071.** `12:06` **Meredith Lamb (+14169386001)**

You guys and your Costco …\.


**072.** `12:07` **You**

No this whole day has been shot


**073.** `12:08` **You**

Shit


**074.** `12:08` **You**

Hope yours is better


**075.** `12:08` **You**

Hard to tell from your messages


**076.** `12:08` **You**

Back to it will text
You when I get home and have a moment to rest before working in basement


**077.** `12:08` **You**

Love you\.


**078.** `12:12` **Meredith Lamb (+14169386001)**

My day is fine\. Just hanging with Mac\. But now Mac mar and I are going to structube and homesense


**079.** `12:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Love u too and just miss u


**080.** `13:13` **You**

Just got home you are probably out


**081.** `13:16` **You**

So butchers bill 2300


**082.** `13:16` **You**

From sparkle light


**083.** `13:16` **Meredith Lamb (+14169386001)**

Huh?????


**084.** `13:17` **Meredith Lamb (+14169386001)**

At Marshall’s getting Mac a business casual outfit\. She is doing a law course at u of t next week


**085.** `13:17` **You**

Bought new entry way dining and kitchen lights 4 pendants and a light above the bath\.


**086.** `13:17` **You**

Cool


**087.** `13:17` **You**

Needs to look sharp


**088.** `13:17` **Meredith Lamb (+14169386001)**

Wow quite a bill


**089.** `13:17` **You**

Yeah


**090.** `13:17` **You**

There will
Be more


**091.** `13:18` **Meredith Lamb (+14169386001)**

😬


**092.** `13:18` **You**

Reaction: ❤️ from Meredith Lamb
Glad
You don’t love me
For my money


**093.** `13:18` **You**

Cause I don’t have any anymore


**094.** `13:18` **You**

lol


**095.** `13:47` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**096.** `14:35` **You**

yep accurate


**097.** `14:35` **You**

well played


**098.** `14:35` **You**

wierd I am just getting this now but it says it was sent 48 min ago


**099.** `15:30` **Meredith Lamb (+14169386001)**

We bought lots of “getting started” stuff and dropped it off at house\. Girls seemed in good spirits


**100.** `15:31` **You**

awesome\.\. what kind of spirits are you in


**101.** `15:40` **Meredith Lamb (+14169386001)**

Just busy mode\. Grocery shopping now\. Gotta walk dogs


**102.** `15:40` **Meredith Lamb (+14169386001)**

You?


**103.** `15:41` **You**

just finished a movie\.\. messing around with GPT\.\. J is going out to drive maddie somewhere coming back and basement work\.


**104.** `15:41` **You**

and of course thinking about you\.\. like I said this morning\.\., all day


**105.** `15:42` **Meredith Lamb (+14169386001)**

I’m looking forward to chilling soon\. Bit hungover today lol


**106.** `15:42` **You**

yeah you were pretty messed last night\.


**107.** `15:42` **Meredith Lamb (+14169386001)**

I have to get up early tomorrow so no shenanigans tonight


**108.** `15:42` **You**

yeah vball outside half the day


**109.** `15:42` **You**

fun


**110.** `15:43` **Meredith Lamb (+14169386001)**

>
“Messed” or “perfectly relaxed” lol

*💬 Reply*

**111.** `15:43` **You**

you were messed up


**112.** `15:43` **You**

sry


**113.** `15:43` **You**

but mostly in a good way


**114.** `15:43` **You**

you helped me\.


**115.** `15:43` **Meredith Lamb (+14169386001)**

lol that’s a sign\. You should have had a few drinks


**116.** `15:44` **You**

no\.\. it won't help me if I do that Mer\.\.


**117.** `15:44` **You**

it will be like the drugs


**118.** `15:44` **You**

I feel too alone\.\. it will drag me down


**119.** `15:44` **You**

sry\.\. I am not like you that way


**120.** `15:44` **You**

wish I was


**121.** `15:45` **Meredith Lamb (+14169386001)**

Nothing wrong with being alone\. Lol


**122.** `15:45` **Meredith Lamb (+14169386001)**

I actually stayed in the room with Andrew and Marlowe for that whole awful movie


**123.** `15:46` **You**

there wasn't about 5 months ago


**124.** `15:46` **Meredith Lamb (+14169386001)**

Got drunker and drunker and drunker lol


**125.** `15:46` **You**

well at least it was fun\.\. I cannot be in room with them without a fight\.\.


**126.** `15:46` **You**

Reaction: 😮 from Meredith Lamb
fight in car today all the way to lighting store\.\. so tired\.


**127.** `15:46` **Meredith Lamb (+14169386001)**

Used to be that way but Andrew is diff now


**128.** `15:47` **Meredith Lamb (+14169386001)**

Why so much fighting?


**129.** `15:47` **You**

I am glad for you it must make it easier\.\. still makes me feel all weird but cannot help it\.


**130.** `15:47` **Meredith Lamb (+14169386001)**

Just like final day anxiety?\!


**131.** `15:47` **You**

I dunno mer\.\. I have given up trying to figure it out\.


**132.** `15:47` **Meredith Lamb (+14169386001)**

>
You’d rather he be nasty to me? Lol

*💬 Reply*

**133.** `15:48` **You**

No but you would be equally sketched if J were doing same thing\.


**134.** `15:48` **You**

I just want you to understand not for it to change


**135.** `15:48` **You**

anyhow go do your stuff\. you are busy\.\. get it all done so you can chill etc\.


**136.** `15:51` **Meredith Lamb (+14169386001)**

>
But u guys do so much together

*💬 Reply*

**137.** `15:51` **Meredith Lamb (+14169386001)**

We do like zero together ever


**138.** `15:52` **You**

>
it is not because I want to\.\. it is because I feel like I have to\.\. and then I get tortured\.\. I don't have a choice\. If I say no it blows up if I go it blows up\.\. it will likely blow up again in basement this aft\.

*💬 Reply*

**139.** `15:52` **You**

Reaction: 😮 from Meredith Lamb
We talked about kids again\.\. she is telling me they both now might be staying\.\. I am like how do I get the house done, the renos, staging, work etc and deal with Gracie and her stuff\.\. like there is no plan no thought no consideration\.


**140.** `15:53` **You**

Anyhow you go do your stuff\.\. I am going to sign off for now\.\. maybe I will check in later\.\. I won't have anything good to share I am sure anyways\.


**141.** `15:53` **You**

ttyl


**142.** `16:10` **Meredith Lamb (+14169386001)**

>
When you say “staying” do you mean sept onwards or like staying for the summer even\.

*💬 Reply*

**143.** `16:11` **You**

Summer sept I dunno I pushed back\.


**144.** `16:15` **Meredith Lamb (+14169386001)**

Well hopefully it works out\. Time is running out so you will be there soon and at least know what is going on


**145.** `16:24` **You**

All I am looking for is a path forward for my life and for Maddie’s to be slightly easier and I don’t see one\. It’s fine just
Going to work now\.


**146.** `16:33` **Meredith Lamb (+14169386001)**

Even if it isn’t clear now it will work out \- especially because we will be in it together\. You won’t be alone
I’m going to try to have a nap before dinner lol


**147.** `18:34` **Meredith Lamb (+14169386001)**

Everything good?


**148.** `18:42` **You**

Still here


**149.** `18:45` **You**

Eating and leaving soon though


**150.** `18:46` **Meredith Lamb (+14169386001)**

Well hope it’s going ok


**151.** `18:57` **You**

Super 👍


**152.** `19:16` **Meredith Lamb (+14169386001)**

A word you use often…


**153.** `19:19` **You**

Yep especially when I mean it\.


**154.** `19:26` **Meredith Lamb (+14169386001)**

Sigh\. You are half way through the weekend\. 🙃


**155.** `19:35` **You**

Deleted…\.\. instead… yep\.


**156.** `19:42` **Meredith Lamb (+14169386001)**

The deleted was some down in a hole depressing message?


**157.** `19:42` **Meredith Lamb (+14169386001)**

“Yep” is the cheerier response?


**158.** `19:42` **Meredith Lamb (+14169386001)**

lol


**159.** `19:42` **You**

Yep is as good as it gets


**160.** `19:43` **You**

Actually yep is more like it doesn’t really matter\.\. to be more accurate


**161.** `19:48` **Meredith Lamb (+14169386001)**

Zero response\. Sorry lol


**162.** `19:49` **You**

Yeah I know why don’t you got enjoy yourself I am taxing kids then gym sauna shower home and fuck it\.


**163.** `19:53` **Meredith Lamb (+14169386001)**

I don’t like it when you always tell me to go “enjoy myself” :p I will go but I may not enjoy myself…\.


**164.** `20:05` **You**

Sure you will I know and have faith in you\.\.


**165.** `20:06` **You**

I only tell you to go because I am a miserable sack and you don’t need any of this\.


**166.** `20:07` **You**

When I don’t see a light it gets like this


**167.** `20:07` **You**

And that is where I am


**168.** `20:12` **Meredith Lamb (+14169386001)**

Okay\. Well maybe gym sauna will make you feel better xo


**169.** `21:41` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
This is my I’m worried about Scott photo\. He’s been short and pushing me away all day and I just want him to know that I’m here even if he doesn’t want to talk\. ❤️ going to bed soon…\. So saying g’nite xo

*📎 1 attachment(s)*

**170.** `21:42` **You**

Mer if you want to talk about anything but me\.\. I am for it\.


**171.** `21:44` **You**

But there is nothing here to talk about\.\. talk about your day, what you bought how the kids are, what the fuck were those texts this morning and how did that start up\.\. but how I am feeling is shitty\.\. I don't feel optimistic, I don't feel happy, and this environment is just getting worse\.\. so again\.\. me piling my problems onto you only makes you feel worse and I don't want that\.


**172.** `21:44` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Sat, 5 Jul 2025 21:44:24 \-0400
|
| It’s okay
|
| Version: 1
| Sent: Sat, 5 Jul 2025 21:44:17 \-0400
|
| It’s oksy


**173.** `21:45` **Meredith Lamb (+14169386001)**

I am going to bed soon so I can survive the heat tomorrow


**174.** `21:45` **You**

Reaction: ❤️ from Meredith Lamb
kk well if you going to bed I guess I will say good night too\.\. xo


