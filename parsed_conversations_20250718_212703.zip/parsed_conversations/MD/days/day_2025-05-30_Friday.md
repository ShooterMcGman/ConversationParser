# Daily Conversation: 2025-05-30 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-30 |
| **Day** | Friday |
| **Week** | 7 |
| **Messages** | 1073 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-30T04:11 - 2025-05-30T23:57 |

## 📝 Daily Summary

This day contains **1073 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:11` **You**

Hope the rest of night was fun and uneventful\.  Up for the gym\.


**002.** `07:39` **Meredith Lamb (+14169386001)**

I went to sleep so it was great :\) woke up at 3\.30am and all was quiet \.\. I just shut lights off basically\. I love your 4am messages ❤️


**003.** `07:40` **You**

lol always something to wake up to
🥰


**004.** `07:40` **You**

Virtually at least


**005.** `07:42` **Meredith Lamb (+14169386001)**

With Andrew showing up, it got me thinking about you wondering if I would do anything with him when I was all messed up and/or drunk… it’s a big no, but I get the concern\. You know, we have never had a sexual relationship like you and I\. It has always been very different and hence not very fun most of the years/time\. Like even the beginning I remember when I was pregnant with Mac\. He had many expectations and made certain things feel very obligatory\. I don’t feel anything like that with you so our experience together is different\. I would never choose to go back, messed up, drunk or not\. FYI\.


**006.** `07:44` **Meredith Lamb (+14169386001)**

Just want you to know that I’m into you, not sex in general\. :p


**007.** `07:45` **You**

I appreciate that mer… tbh I have always been quite self
Conscious in this particular area\.\. I cannot possibly understand any word like obligation being associated with it\.\. completely foreign to me\.\. I would want to be with you because you want to be with me\.\. that’s it\.  I very much enjoy being with you it isn’t like anything I have experienced before\.\. very intimate\.\. literally blows my mind, heart and well everything else\.


**008.** `07:47` **Meredith Lamb (+14169386001)**

Some guys don’t care about obligation type feelings for women\. You are clearly different\. :\)


**009.** `07:47` **You**

You should never worry about me being bored\.\. you are what I want\.\. the watching movies,
The kissing, the working in shit together all of it\.
I will confide something in you\.\. while I am 1000% in favour of not having any more children\.\. I have
To confess for a second yesterday I thought about it lol… just bad timing\.


**010.** `07:48` **You**

No I was more the opposite I want to make you happy because that is what makes me the most happy\.


**011.** `07:48` **You**

>
And I did feel a tiny bit sad lol\.\.

*💬 Reply*

**012.** `07:48` **Meredith Lamb (+14169386001)**

>
lol super bad timing, like only 10 years too late

*💬 Reply*

**013.** `07:48` **You**

Irrational


**014.** `07:48` **You**

Hope you weren’t too sick from the pill


**015.** `07:49` **Meredith Lamb (+14169386001)**

I wasn’t at all actually\. Makes me think it didn’t work


**016.** `07:49` **Meredith Lamb (+14169386001)**

Ack


**017.** `07:49` **You**

lol don’t say that


**018.** `07:49` **Meredith Lamb (+14169386001)**

I think I was just so hung over and not eating a lot, I probably couldn’t get any sicker feeling\. Lol


**019.** `07:50` **Meredith Lamb (+14169386001)**

I’m just used to it


**020.** `07:50` **Meredith Lamb (+14169386001)**

Feel fine today


**021.** `07:50` **You**

ROFL\.\. what brought on all the thoughts btw in the first place?


**022.** `07:50` **Meredith Lamb (+14169386001)**

Andrew being here I think


**023.** `07:50` **Meredith Lamb (+14169386001)**

And you wondering if we did anything last weekend


**024.** `07:52` **Meredith Lamb (+14169386001)**

Like when I was pregnant with Mac, I had horrible nausea for the first 14 weeks\. I didn’t feel like sex at all so he thought I should just do “other stuff”… it began very early on and then I hated all that crap


**025.** `07:52` **You**

I guess it
Kind of came
Down to this\.\. consciously I don’t believe
You would ever do anything but the way you have talked about him and his lack of respect\.\. and that experience you had with that “friend” where you blacked out… that is more what concerned me


**026.** `07:52` **You**

>
For the record I have never been comfortable with other stuff\.

*💬 Reply*

**027.** `07:52` **You**

It is very weird


**028.** `07:53` **You**

Now what you do\.\. umm


**029.** `07:53` **Meredith Lamb (+14169386001)**

>
Yeah I know\. I was just trying to reassure I guess\. Add some context

*💬 Reply*

**030.** `07:53` **You**

Yeah… that is different but I think it is a trust thing among other things


**031.** `07:53` **Meredith Lamb (+14169386001)**

>
You more comfortable? Lol

*💬 Reply*

**032.** `07:54` **You**

Like at risk of tmi I would never let J ever do that\.


**033.** `07:54` **You**

Ever


**034.** `07:54` **You**

In 25 years


**035.** `07:54` **You**

lol


**036.** `07:54` **Meredith Lamb (+14169386001)**

Interesting\. And Andrew was pissed because I stopped many years ago bc he made it no fun\.


**037.** `07:55` **You**

Deleted


**038.** `07:55` **You**

Eesh


**039.** `07:55` **You**

Not going down that road\.


**040.** `07:56` **Meredith Lamb (+14169386001)**

No go down that road… I’m curious


**041.** `07:56` **Meredith Lamb (+14169386001)**

I think you feel it is an obligation for women maybe


**042.** `07:56` **You**

It was more to spare me but ok


**043.** `07:56` **Meredith Lamb (+14169386001)**

I remember you saying once “you don’t have to” during the long weekend


**044.** `07:56` **You**

I feel like based on the text and what you have told me\.\. I can imagine his requirements


**045.** `07:57` **You**

>
I feel it is or isn’t

*💬 Reply*

**046.** `07:57` **Meredith Lamb (+14169386001)**

Super non\-committal\. Nice


**047.** `07:57` **You**

Confused?????


**048.** `07:57` **You**

Lost


**049.** `07:58` **You**

Please restart\.\.


**050.** `07:58` **Meredith Lamb (+14169386001)**

>
Not exactly, he didn’t require what I know you are thinking\.

*💬 Reply*

**051.** `07:58` **Meredith Lamb (+14169386001)**

>
You said “I feel like it is or it isn’t” … super non\-committal

*💬 Reply*

**052.** `07:58` **You**

You don’t know what I am thinking


**053.** `07:58` **You**

lol


**054.** `07:59` **Meredith Lamb (+14169386001)**

I think I do


**055.** `07:59` **Meredith Lamb (+14169386001)**

I read the text


**056.** `08:00` **Meredith Lamb (+14169386001)**

Anyway, with you or any past people other than Andrew, never felt like an obligation\. FYI\.


**057.** `08:00` **You**

Ok let me back this up\.\. my comment o\. Andrew\.\. while I am not experience in this area personally I am also not ignorant\.\. lol I have friends k know all the shit they would try to have done to them\.\. so I have some idea\.


**058.** `08:01` **Meredith Lamb (+14169386001)**

I don’t want you to think I’m doing anything out of obligation\. Not starting that\. Isn’t healthy\.


**059.** `08:01` **You**

Oh ok\.\. yeah no sex isn’t obligatory at all\.


**060.** `08:01` **You**

It is totally a respect thing, mutually engaged hopefully enjoyed etc\.


**061.** `08:02` **You**

Nothing is obligatory


**062.** `08:02` **You**

I mean sure love support mutual respect\.\. I don’t
Like saying obligatory ever but it is foundational\.


**063.** `08:02` **You**

That is a better word


**064.** `08:03` **Meredith Lamb (+14169386001)**

>
So why haven’t you stopped me?

*💬 Reply*

**065.** `08:03` **You**

Although… studies show a healthy sexual relationship can also lead to an overall healthy relationship\.


**066.** `08:04` **Meredith Lamb (+14169386001)**

>
Right but there are so many ways to have an unhealthy sexual relationship too\. Experienced that for sure\.

*💬 Reply*

**067.** `08:04` **You**

>
1 it feels amazing, 2 it is you and I trust
You implicitly 3 I don’t think you would do it if you didn’t want to\.\. and I didn’t want you to think I wouldn’t want you to either\.

*💬 Reply*

**068.** `08:04` **You**

>
Yeah I don’t have that experience with j or anyone else
For that matter

*💬 Reply*

**069.** `08:04` **You**

Well unhealthy as in not having it nearly ever


**070.** `08:04` **You**

I mean yeah that\.\.


**071.** `08:05` **Meredith Lamb (+14169386001)**

>
Well this makes me happy because I feel like we really know each other\. I want to be a safe space for you bc you are for me\.

*💬 Reply*

**072.** `08:06` **You**

You are a safe
Space\. Completely I have told you virtually everything without holding back and without regret


**073.** `08:06` **You**

Even the real embarrassing and insecure stuff


**074.** `08:07` **You**

Additionally there is the time factor


**075.** `08:08` **You**

While it is overwhelming I know how much I love you how\.\. and it is so far beyond anything I have experienced


**076.** `08:08` **You**

I don’t want it to take years


**077.** `08:08` **You**

For you to get to know me


**078.** `08:11` **Meredith Lamb (+14169386001)**

You have definitely helped move things along faster\. Very open :\)


**079.** `08:12` **You**

No regrets


**080.** `08:16` **You**

Kk I am getting home you might have gone back
To sleep or girls are up or whatever\.\. I have to go in and get maddie up\.\. and get her going to school then quick last prep for this stupid 10 am meeting\.\. I assume if Andrew made any progress on agreement you would have mentioned something\.\. I will share whatever I find out later todays


**081.** `08:16` **You**

Love you\!\!


**082.** `08:16` **You**

Xoxoxoxo ❤️❤️❤️❤️❤️


**083.** `08:19` **Meredith Lamb (+14169386001)**

I’m walking dogs\. Griffin got me up early today\. Weird\. I asked last night and Andrew started taxes but didn’t finish :p
k I will talk to you later\. Have a good morning ❤️


**084.** `08:21` **You**

I will you too❤️


**085.** `11:03` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**086.** `11:06` **You**

So tired


**087.** `11:06` **You**

How long were you in the call\.


**088.** `11:07` **Meredith Lamb (+14169386001)**

Almost the whole call\. Missed the beginning\. Then had to vacuum quick at one point but otherwise got it all


**089.** `11:08` **Meredith Lamb (+14169386001)**

It was good\. Erin said she needs something even simpler tho because she hasn’t used it at all :p I think most ppl have played around with it


**090.** `11:08` **Meredith Lamb (+14169386001)**

She is an anomaly


**091.** `11:08` **You**

It was tiring no energy


**092.** `11:09` **You**

You kissed the charicature fun time


**093.** `11:09` **You**

I took your brothers drawing kf me and improved on it lol


**094.** `11:09` **You**

Will send it to you in teams


**095.** `11:09` **Meredith Lamb (+14169386001)**

lol


**096.** `11:09` **Meredith Lamb (+14169386001)**

Of course you did


**097.** `11:09` **You**

Sent


**098.** `11:10` **Meredith Lamb (+14169386001)**

Shit my internet just disconnected


**099.** `11:10` **Meredith Lamb (+14169386001)**

Oh it’s back


**100.** `11:16` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/0qRR9d89hIS0MHRkQ0ejxX?si=X9JdyeGtRZyOho2gFEinww
Girls are blaring this and making brunch THEMSELVES\!


**101.** `11:19` **You**

Awesome\.\. like\.\. sounds like I am glad
You are there and not me\.\.


**102.** `11:19` **You**

But for you I would be there if you wanted me to and I could be lol\. Just for you though


**103.** `11:20` **Meredith Lamb (+14169386001)**

Of COURSE I would want you to be here\.


**104.** `11:23` **Meredith Lamb (+14169386001)**

Wifi is spotty now because of all the girls and Andrew in calls lol just clued in to that


**105.** `11:26` **You**

Ah well you shouldn’t be online anyways you should be resting or having fun etc


**106.** `11:26` **Meredith Lamb (+14169386001)**

Waiting for the twins to show up so I can go to store


**107.** `11:26` **Meredith Lamb (+14169386001)**

Mac wants me here bc their dad is dropping them off and apparently he is mean


**108.** `11:26` **Meredith Lamb (+14169386001)**

lol


**109.** `11:27` **Meredith Lamb (+14169386001)**

They are 15 min out


**110.** `11:28` **Meredith Lamb (+14169386001)**

They just asked me if I want a mimosa


**111.** `11:28` **Meredith Lamb (+14169386001)**

I said no thanks 😇


**112.** `11:28` **You**

Well if Andrew is staying you can have some fun\.\. you won’t need to drive


**113.** `11:29` **Meredith Lamb (+14169386001)**

He is leaving after the workday


**114.** `11:29` **Meredith Lamb (+14169386001)**

He doesn’t have a 3 hr window to drive


**115.** `11:29` **Meredith Lamb (+14169386001)**

AND he did the dump trip this morning 🎉🎉🎉🎉


**116.** `11:29` **Meredith Lamb (+14169386001)**

I didn’t have to


**117.** `11:30` **Meredith Lamb (+14169386001)**

The ring now :\(

*📎 1 attachment(s)*

**118.** `11:32` **You**

lol nice


**119.** `11:32` **Meredith Lamb (+14169386001)**

I will not be partaking in the mimosas \(my mantra\)

*📎 1 attachment(s)*

**120.** `11:34` **You**

No more coming to cottage for me\.


**121.** `11:34` **Meredith Lamb (+14169386001)**

Well once we confirm we are keeping cottage together somehow we need to get rid of ring\. We already talked about it\.


**122.** `11:34` **You**

Glad I got up there and saw dogs again


**123.** `11:35` **Meredith Lamb (+14169386001)**

>
And we both seem on the same page there\.

*💬 Reply*

**124.** `11:35` **Meredith Lamb (+14169386001)**

It’s just when does that happen? Not sure


**125.** `11:36` **You**

Well wait until you see the numbers first


**126.** `11:36` **You**

Wrote you agree agree


**127.** `11:36` **You**

Before


**128.** `11:36` **Meredith Lamb (+14169386001)**

Yeah have to wait for a bit for sure


**129.** `11:37` **Meredith Lamb (+14169386001)**

My girlfriends confirmed they are coming up aug1\-3 weekend fyi


**130.** `11:37` **You**

Reaction: ❤️ from Meredith Lamb
September 15


**131.** `11:37` **Meredith Lamb (+14169386001)**

lol


**132.** `11:37` **Meredith Lamb (+14169386001)**

Probably


**133.** `11:37` **Meredith Lamb (+14169386001)**

Hopefully before


**134.** `11:37` **You**

>
Good I should be all quiet by then j and girls gone

*💬 Reply*

**135.** `11:37` **Meredith Lamb (+14169386001)**

I still have faith in before sept 15


**136.** `11:37` **You**

Will just be me in house most of august


**137.** `11:38` **Meredith Lamb (+14169386001)**

Both girls gone?


**138.** `11:39` **You**

Yep


**139.** `11:39` **You**

Everyone


**140.** `11:39` **You**

Just me


**141.** `11:39` **You**

All alone in a big house


**142.** `11:39` **You**

I am pretty sure but who knows it could change


**143.** `11:40` **Meredith Lamb (+14169386001)**

Yaye new music doc coming

*📎 1 attachment(s)*

**144.** `11:40` **Meredith Lamb (+14169386001)**

>
So August could be interesting

*💬 Reply*

**145.** `11:40` **Meredith Lamb (+14169386001)**

We’ll see


**146.** `11:42` **You**

Yep could be interesting just need to get there lol


**147.** `11:50` **Meredith Lamb (+14169386001)**

So the dad wasn’t mean\. Probably just doesn’t like teen girls


**148.** `11:50` **You**

ROFL yeah they can be challenging


**149.** `13:22` **Meredith Lamb (+14169386001)**

They are fun so far tho\. At least for me lol


**150.** `13:22` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**151.** `13:23` **Meredith Lamb (+14169386001)**

Making them an Oreo lasagna for dessert tonight


**152.** `13:23` **Meredith Lamb (+14169386001)**

My friends switched to Aug 7\-10


**153.** `13:24` **Meredith Lamb (+14169386001)**

Our friend that has a hubby with cancer can’t go Aug 1\-3 and everyone really wants her there\. She can go Aug 7\-10 so people are shifting plans for her


**154.** `13:48` **You**

They look pretty happy\.

*💬 Reply*

**155.** `13:49` **You**

>
So far out I have no clue what is going on\.\. but glad you will get your weekend\.

*💬 Reply*

**156.** `13:53` **Meredith Lamb (+14169386001)**

They are so happy\. In their bikinis and off to hick rock to jump off the cliff


**157.** `14:02` **You**

This will
Be memorable for all of them I am sure


**158.** `14:18` **Meredith Lamb (+14169386001)**

Forgot to show you that\. Right afterwards she was complaining about something\. :p

*📎 1 attachment(s)*

**159.** `14:33` **You**

ROFL


**160.** `14:33` **You**

Appreciate you sharing


**161.** `14:33` **You**

With her


**162.** `14:38` **Meredith Lamb (+14169386001)**

They just made me do a photo shoot at high rock


**163.** `14:38` **Meredith Lamb (+14169386001)**

lol


**164.** `14:40` **Meredith Lamb (+14169386001)**

They all jumped off and said the water “stung”\. I was like “it IS may\!”


**165.** `14:40` **You**

Yeah like 60 degree water


**166.** `14:52` **Meredith Lamb (+14169386001)**

So Andrew knew about the oven\. Just told me\. He thinks it works fine on convection though so I will have to tell him no at some point\.


**167.** `14:52` **You**

ROFL


**168.** `14:53` **You**

Least it wasn’t me


**169.** `14:55` **Meredith Lamb (+14169386001)**

lol can’t believe he never mentioned it to me


**170.** `14:56` **You**

Maybe he was scared of you


**171.** `14:56` **You**

You can be scary\!\!


**172.** `14:56` **Meredith Lamb (+14169386001)**

Haha or maybe we just have a lot going on :p


**173.** `14:58` **You**

Maybe I think the fear factor though


**174.** `14:59` **Meredith Lamb (+14169386001)**

lol whatever


**175.** `15:02` **You**

Whatever


**176.** `15:03` **Meredith Lamb (+14169386001)**

I am the furthest thing from scary\. It’s laughable to even think about


**177.** `15:03` **Meredith Lamb (+14169386001)**

Pretty sure at work ppl are scared of YOU


**178.** `15:22` **You**

I am scared of you you are the boss\!\!\!


**179.** `15:56` **Meredith Lamb (+14169386001)**

I think you just want me to be the boss


**180.** `15:56` **Meredith Lamb (+14169386001)**

lol


**181.** `15:57` **You**

Yep


**182.** `15:57` **You**

I am all about that\.


**183.** `15:57` **You**

😋


**184.** `15:59` **Meredith Lamb (+14169386001)**

Tired of being the boss at work


**185.** `16:02` **You**

You are\.\. I am\.\.


**186.** `16:03` **You**

Just tired honestly long day\. And now I get to work


**187.** `16:03` **You**

More


**188.** `16:04` **Meredith Lamb (+14169386001)**

Really at 4?


**189.** `16:04` **Meredith Lamb (+14169386001)**

Work work or house work?


**190.** `16:05` **You**

House work no one did anything today\.\.


**191.** `16:05` **You**

So going to build
Some dump runs in the garage\.


**192.** `16:07` **Meredith Lamb (+14169386001)**

I’m at the grocery store for the third time today yay


**193.** `16:09` **You**

Jesus wow


**194.** `16:09` **You**

Hopefully local not the far away one


**195.** `16:13` **Meredith Lamb (+14169386001)**

Yeah for sure


**196.** `16:14` **You**

Well I am just going to be in here listening to music and ripping shit apart yay\!\!\! Kids won’t help nothing it’s awesome


**197.** `16:40` **Meredith Lamb (+14169386001)**

I can’t take it

*📎 1 attachment(s)*

**198.** `16:41` **You**

Reaction: ❤️ from Meredith Lamb
I fucking TOLD YOU SO\!\!\!\!\!


**199.** `16:41` **You**

Ahh


**200.** `16:41` **You**

That felt
Good


**201.** `16:41` **You**

Was holding that in


**202.** `16:41` **You**

Now it’s out I feel better


**203.** `16:41` **You**

Gummies are next


**204.** `16:41` **You**

Just text me when


**205.** `16:43` **Meredith Lamb (+14169386001)**

Oh stop acting like you know me


**206.** `16:44` **You**

ROFL I do know you\!\!\! And love every bit of it\.\. even this slightly silly part\.


**207.** `16:51` **Meredith Lamb (+14169386001)**

🙈


**208.** `16:56` **You**

Have fun I am around puttering still going to bed early and gym tomorrow\.\. very disappointed in people around here no one willing to work\.


**209.** `17:17` **Meredith Lamb (+14169386001)**

I’m going to sit for a bit and continue my doc\. Girls had apps at 4 so we are doing dinner late thank goodness


**210.** `17:17` **Meredith Lamb (+14169386001)**

What’s the excuse for not helping?


**211.** `17:18` **Meredith Lamb (+14169386001)**

“It’s all your fault” ?


**212.** `17:21` **You**

Yeah


**213.** `17:21` **You**

It is


**214.** `17:21` **You**

I guess


**215.** `17:21` **You**

It’s fine hopefully tomorrow j will be more motivated and in turn motivate kids\.


**216.** `17:25` **Meredith Lamb (+14169386001)**

You should just relax tonight\.


**217.** `17:27` **You**

And do what\.\.


**218.** `17:27` **You**

Don’t say watch docs…\.\.


**219.** `17:27` **Meredith Lamb (+14169386001)**

lol


**220.** `17:27` **You**

Negative


**221.** `17:28` **You**

Might go to the gym


**222.** `17:28` **Meredith Lamb (+14169386001)**

We need an online version of ticket to ride :p


**223.** `17:28` **You**

lol
For iPhone yku mean


**224.** `17:28` **Meredith Lamb (+14169386001)**

I only have my iPhone and work laptop right now


**225.** `17:29` **You**

https://apps\.apple\.com/ca/app/ticket\-to\-ride\-the\-board\-game/id6463616555


**226.** `17:29` **You**

lol


**227.** `17:30` **Meredith Lamb (+14169386001)**

I’m I did not know that existed


**228.** `17:30` **You**

Most of those board games have been ported to iPhone in some form


**229.** `17:31` **Meredith Lamb (+14169386001)**

Do you think it’s bad


**230.** `17:31` **You**

Great question\. While Ticket to Ride iOS is a faithful adaptation of the board game, there are a few key differences—some subtle, some impactful—between the digital version and the physical tabletop version\.
⸻
🎯 Core Gameplay – Same
- Rules, objectives, and mechanics are identical to the board game\.
- Train routes, destination tickets, scoring system, and gameplay flow are all preserved\.
⸻
🔁 What’s Different
1\. Setup & Scoring
- ✅ iOS: Setup is instant, and scoring is automated \(including longest route detection and completed tickets\)\.
- 🧩 Board Game: Manual setup takes time, and scoring is done by hand \(can be error\-prone\)\.
2\. Game Speed
- ✅ iOS: Much faster turns, especially in solo play\. No shuffling, counting, or disputes\.
- 🧩 Board Game: Slower pace, especially with new players or when double\-checking rules\.
3\. Rule Enforcement
- ✅ iOS: Strict rules are enforced by the app; no accidental cheating or missed rules\.
- 🧩 Board Game: Players can make mistakes in rules or scoring \(especially newer players\)\.
4\. Player Interaction
- 🧩 Board Game: Face\-to\-face bluffing, conversation, reading expressions—adds a social dynamic\.
- ✅ iOS: Lacks in\-person cues; interaction is limited to game actions \(unless playing with friends via voice chat\)\.
5\. Expansions
- ✅ iOS: Buy and download instantly, no storage needed\. You can toggle expansions/maps on demand\.
- 🧩 Board Game: Physical expansions require table space and manual setup/storage\.
6\. Aesthetics and Tactile Feel
- 🧩 Board Game: You physically move pieces, handle cards, and build routes—this tactile element is part of the fun\.
- ✅ iOS: Offers beautiful visuals, but lacks the hands\-on element\.
7\. Multiplayer Logistics
- ✅ iOS: Online multiplayer \(cross\-platform\) lets you play with strangers or friends anywhere\.
- 🧩 Board Game: Requires everyone to be present physically\.
8\. Variants and House Rules
- 🧩 Board Game: Easier to customize or invent house rules \(e\.g\., 3\-card draw limit, open tickets\)\.
- ✅ iOS: You’re locked into official rule sets\.
⸻
🧠 Summary: Is iOS Better or Worse?
Feature	iOS Version	Physical Version
Speed & Convenience	✅ Faster	❌ Slower setup & scoring
Rule Clarity	✅ Always correct	❌ Error\-prone
Tactile Feel	❌ Digital\-only	✅ Hands\-on fun
Multiplayer Flexibility	✅ Remote play	❌ In\-person only
Social Interaction	❌ Minimal	✅ Richer, in\-person
Replay Value	✅ High w/ expansions	✅ High but space\-dependent
⸻
Let me know if you’d like a recommendation for best expansion maps to buy on iOS, or tips on beating the AI\!


**231.** `17:32` **You**

The iOS version of Ticket to Ride has generally been well\-received, praised for its faithful adaptation of the board game and its convenience\. However, it has also faced criticism, particularly following a significant overhaul\. Here’s an overview of its reception:
⸻
✅ Strengths
- Faithful Adaptation: The app closely mirrors the physical board game, maintaining its core mechanics and strategic depth\.
- User\-Friendly Interface: The digital format streamlines gameplay with automated scoring, tutorials, and intuitive controls, making it accessible to both new and seasoned players\.
- Multiplayer Options: Offers various modes including solo play against AI, online multiplayer, and pass\-and\-play, catering to different playstyles\.
⸻
⚠️ Criticisms
- Transition to New App: The shift from the original app to a new version developed by Marmalade Game Studio led to user dissatisfaction\. Players were required to repurchase the game and its expansions, and previous progress or purchases did not carry over\.
- Technical Issues: Some users have reported bugs, such as games freezing or issues with online connectivity, which have affected the gaming experience\.
- Removed Features: Certain features present in the original app, like the pass\-and\-play mode, were initially missing in the new version, leading to disappointment among long\-time users\.
⸻
📊 Overall Reception
- App Store Rating: The app holds a rating of 4\.5 out of 5 stars based on over 7,000 reviews, indicating a generally positive reception despite some criticisms\.
- Community Feedback: While many appreciate the app’s convenience and faithful gameplay, the transition to a new version and associated issues have led to mixed feelings within the community\.
⸻
If you’re considering purchasing the iOS version of Ticket to Ride, it’s worth weighing the convenience and features of the digital format against the reported issues and the need to repurchase content if transitioning from the older app\.


**232.** `17:34` **Meredith Lamb (+14169386001)**

Rule enforcement?\!?


**233.** `17:34` **Meredith Lamb (+14169386001)**

🤪


**234.** `17:34` **You**

lol


**235.** `17:34` **You**

Hahaha


**236.** `17:34` **You**

Thought you would like that


**237.** `17:34` **Meredith Lamb (+14169386001)**

Love


**238.** `17:34` **Meredith Lamb (+14169386001)**

Not


**239.** `17:35` **You**

I might dl and try it is only 7


**240.** `17:35` **Meredith Lamb (+14169386001)**

k we can play it later tonight?


**241.** `17:35` **Meredith Lamb (+14169386001)**

I don’t want to think quite yet


**242.** `17:35` **Meredith Lamb (+14169386001)**

lol


**243.** `17:36` **You**

Reaction: 👍 from Meredith Lamb
Sure I am going to dl now though just to see


**244.** `17:36` **Meredith Lamb (+14169386001)**

Girls are going in boat across lake so I need to go down and make sure they all have lifejackets


**245.** `17:37` **You**

Kk


**246.** `17:37` **You**

Think about any other games you might be interested in playing card games crib whatever lol


**247.** `17:49` **Meredith Lamb (+14169386001)**

I forget how to play crib but would totally play


**248.** `17:50` **You**

Reaction: 👍 from Meredith Lamb
I will find a good platform


**249.** `17:50` **You**

Ticket to ride is easy to play different rules


**250.** `17:51` **You**

And playing with ai players is pretty cut throat


**251.** `17:53` **Meredith Lamb (+14169386001)**

But can you not play with ai players?


**252.** `17:54` **You**

https://apps\.apple\.com/ca/app/cribbage\-pro/id409644287


**253.** `17:54` **You**

Yes


**254.** `17:54` **You**

You can just play you and I


**255.** `17:54` **You**

The crib one is free


**256.** `18:02` **Meredith Lamb (+14169386001)**

Downloaded crib but I will need to do the tutorial


**257.** `18:02` **Meredith Lamb (+14169386001)**

Waiting for Andrew to leave :p


**258.** `18:02` **Meredith Lamb (+14169386001)**

Ticket to ride is downloading and taking a long time


**259.** `18:06` **You**

lol you will want to do the tutorial for it as well


**260.** `18:07` **You**

It isn’t as bad for me on an iPad\.


**261.** `18:10` **Meredith Lamb (+14169386001)**

For crib reading in ChatGPT


**262.** `18:10` **You**

lol


**263.** `18:10` **You**

cmon it is easy


**264.** `18:11` **Meredith Lamb (+14169386001)**

I haven’t played since I was a kid


**265.** `18:11` **Meredith Lamb (+14169386001)**

Not easy


**266.** `18:12` **Meredith Lamb (+14169386001)**

Omg Mac wants me to start making dinner


**267.** `18:12` **Meredith Lamb (+14169386001)**

This doesn’t feel “late”


**268.** `18:12` **Meredith Lamb (+14169386001)**

She just texted me from the middle of the lake


**269.** `18:13` **You**

rofl ah well a mothers work is never done


**270.** `18:24` **Meredith Lamb (+14169386001)**

I’m having a second glass of wine but this is not going to go south\. Don’t worry


**271.** `18:25` **You**

uh huh\.


**272.** `18:26` **You**

in a little while\.\. \- on glass four\.\. it is all good, because I can still only see two glasses\.\. it hasn't gotten worse\.\. lol


**273.** `18:31` **Meredith Lamb (+14169386001)**

Andrew stayed bc he was worried Mac would wreck the motor at the beach across the lake


**274.** `18:31` **Meredith Lamb (+14169386001)**

She got home and he is outside and I’m like “did you wreck the motor?”


**275.** `18:31` **Meredith Lamb (+14169386001)**

Her: almost


**276.** `18:31` **Meredith Lamb (+14169386001)**

She’s like “I had to dig it out of the sand\. Don’t tell him”


**277.** `18:31` **Meredith Lamb (+14169386001)**

Sigh…\.\.


**278.** `18:33` **You**

lol


**279.** `18:33` **You**

Good times


**280.** `18:40` **You**

Well if he is staying tonight we can try playing tomorrow all good


**281.** `18:41` **Meredith Lamb (+14169386001)**

He just left :\)


**282.** `18:43` **Meredith Lamb (+14169386001)**

Almost done dinner\. They are just having a taco night so super easy


**283.** `18:44` **You**

Yeah I used to make that all the time… good for my diet too but I have as a salad


**284.** `18:45` **Meredith Lamb (+14169386001)**

LOL


**285.** `18:45` **Meredith Lamb (+14169386001)**

You love these kind of photos right

*📎 1 attachment(s)*

**286.** `18:56` **You**

Reaction: 😂 from Meredith Lamb
Cmon mer\.\.


**287.** `18:56` **Meredith Lamb (+14169386001)**

k walking dogs briefly in bugs and then going to watch tutorial lol


**288.** `18:56` **You**

Kk


**289.** `19:01` **Meredith Lamb (+14169386001)**

I had a glass of water so I feel sharper


**290.** `19:01` **You**

I mean you will feel
Sharper only though right??


**291.** `19:04` **Meredith Lamb (+14169386001)**

K I need to concentrate


**292.** `19:06` **Meredith Lamb (+14169386001)**

This tutorial is shit\. Can you just give me one?


**293.** `19:10` **You**

Which one for crib


**294.** `19:10` **You**

Or ticket


**295.** `19:12` **Meredith Lamb (+14169386001)**

Crib\. Seems complicated


**296.** `19:12` **Meredith Lamb (+14169386001)**

lol


**297.** `19:13` **You**

Try get cards to add up to 15 pairs or runs of 3 or more also flush of 4
Or more


**298.** `19:13` **You**

Two cards to the crib each hand


**299.** `19:13` **You**

Take turns getting it\.


**300.** `19:13` **You**

Cut to flip the top card and everyone can use it as a community card


**301.** `19:14` **You**

Then you peg


**302.** `19:14` **Meredith Lamb (+14169386001)**

>
But how do you know which ones? Throwaways? Ones that don’t add to 15

*💬 Reply*

**303.** `19:14` **Meredith Lamb (+14169386001)**

Peg?


**304.** `19:16` **Meredith Lamb (+14169386001)**

Reading\.   …,\.

*📎 1 attachment(s)*

**305.** `19:16` **You**

ROFL


**306.** `19:16` **You**

I think you just need to play\.\. maybe?


**307.** `19:17` **Meredith Lamb (+14169386001)**

Dealing with this omg

*📎 1 attachment(s)*

**308.** `19:18` **You**

sooooo sad


**309.** `19:18` **Meredith Lamb (+14169386001)**

>
I can try but this sounds like a lot of math

*💬 Reply*

**310.** `19:18` **You**

you have to set up username and password


**311.** `19:19` **Meredith Lamb (+14169386001)**

I did


**312.** `19:19` **Meredith Lamb (+14169386001)**

lamberrym


**313.** `19:24` **You**

sent you an invite


**314.** `19:25` **Meredith Lamb (+14169386001)**

Wait where don’t see anything?


**315.** `19:30` **You**

hmm


**316.** `19:31` **You**

just sent it again


**317.** `19:31` **You**

You downloaded cribbage pro right


**318.** `19:31` **You**

if you did you actually have to click on multiplayer and log in


**319.** `19:36` **You**

and you have to activate your account under the email in which you set it up


**320.** `19:37` **You**

you might be better off with ticket honestly\.\. lol


**321.** `19:38` **Meredith Lamb (+14169386001)**

Ok I accepted your friend request\. Sorry had to clean dinner up


**322.** `19:38` **Meredith Lamb (+14169386001)**

Girls are done


**323.** `19:38` **Meredith Lamb (+14169386001)**

Doing dessert later


**324.** `19:38` **You**

ah ok\.\. no worries\.\. just wondered if you got confused


**325.** `19:38` **Meredith Lamb (+14169386001)**

lol no


**326.** `19:38` **Meredith Lamb (+14169386001)**

I mean NOT YET


**327.** `19:39` **You**

lol


**328.** `19:39` **Meredith Lamb (+14169386001)**

Wait so what do you select for your crib


**329.** `19:39` **You**

your crivb


**330.** `19:39` **You**

build you hand


**331.** `19:40` **You**

discard to crib


**332.** `19:40` **You**

try to get 15 or 21 or pairs or runs


**333.** `19:40` **Meredith Lamb (+14169386001)**

I’m clueless


**334.** `19:40` **Meredith Lamb (+14169386001)**

lol


**335.** `19:40` **You**

in this phase


**336.** `19:40` **You**

disconnected lol\.\.


**337.** `19:41` **Meredith Lamb (+14169386001)**

What is this 3diamonds

*📎 1 attachment(s)*

**338.** `19:41` **You**

it is community card


**339.** `19:41` **You**

for when you cout hand


**340.** `19:42` **You**

you have a timer lol


**341.** `19:42` **Meredith Lamb (+14169386001)**

I can’t play this online I have no idea what I’m doing lol


**342.** `19:42` **Meredith Lamb (+14169386001)**

I need someone to teach me irl


**343.** `19:42` **You**

just play out the hand you will see


**344.** `19:43` **You**

so person who doesnt have crib counts first


**345.** `19:44` **Meredith Lamb (+14169386001)**

Too confusing online


**346.** `19:44` **You**

try ticket or is that too much for you\.\. 2 glasses in\.\. well 3 now


**347.** `19:45` **Meredith Lamb (+14169386001)**

I played it with my dad as a kid so I know it isn’t too complicated


**348.** `19:45` **You**

and a gummy


**349.** `19:45` **You**

I bet


**350.** `19:45` **Meredith Lamb (+14169386001)**

But the online thing is weird


**351.** `19:45` **Meredith Lamb (+14169386001)**

>
No

*💬 Reply*

**352.** `19:45` **You**

what about the wine count


**353.** `19:45` **Meredith Lamb (+14169386001)**

Hmm


**354.** `19:45` **You**

LOL


**355.** `19:46` **Meredith Lamb (+14169386001)**

Stop


**356.** `19:46` **Meredith Lamb (+14169386001)**

I have 8 girls partying beside me\. It is so hard


**357.** `19:46` **You**

I mean I know\.\. it is\.\.


**358.** `19:46` **Meredith Lamb (+14169386001)**

lol


**359.** `19:46` **Meredith Lamb (+14169386001)**

Maybe there is an EASY game


**360.** `19:47` **Meredith Lamb (+14169386001)**

I feel like ticket to ride is going to be weird online


**361.** `19:47` **You**

it actually wasn;t


**362.** `19:47` **You**

you have to set up this account thing\.\. on right of main secreen called bubble something


**363.** `19:47` **You**

but the rules are diff


**364.** `19:47` **You**

like for instance if you take one of those rainbow train cards\.\. you can only take 1 card that round\.


**365.** `19:49` **Meredith Lamb (+14169386001)**

😣


**366.** `19:50` **Meredith Lamb (+14169386001)**

Everytime I open it I can’t get out of it without turning my phone off


**367.** `19:50` **Meredith Lamb (+14169386001)**

wtf


**368.** `19:51` **You**

lol


**369.** `19:52` **You**

It just slides from the bottom up like any other app\.


**370.** `19:52` **Meredith Lamb (+14169386001)**

Hi\! I'm playing Ticket To Ride\!\. Get the app here:
https://get\.bubbleplay\.com/TicketToRide
Once you've installed it, sign up to Bubble and be my friend\!
My Friend Code is C90AAC3B623C1FA3
https://invites\.bubbleplay\.com/Bubble/eyJyb3V0ZSI6IkFkZEZyaWVuZCIsIkZyaWVuZENvZGUiOiJDOTBBQUMzQjYyM0MxRkEzIn0=


**371.** `19:56` **You**

ROFL\!\!\!\!


**372.** `19:56` **Meredith Lamb (+14169386001)**

I have no idea what just happened lol


**373.** `19:56` **Meredith Lamb (+14169386001)**

It played and I didn’t mean to


**374.** `19:56` **You**

kk I can restart


**375.** `19:57` **Meredith Lamb (+14169386001)**

It’s fine


**376.** `19:57` **Meredith Lamb (+14169386001)**

Learning


**377.** `19:57` **You**

no


**378.** `19:57` **You**

it will be an excuse if you lose


**379.** `19:57` **You**

unacceptable


**380.** `19:57` **You**

lol


**381.** `19:57` **Meredith Lamb (+14169386001)**

No stop


**382.** `19:57` **Meredith Lamb (+14169386001)**

It won’t be the only learning I’m sure


**383.** `19:57` **You**

kk


**384.** `19:57` **You**

pull cards from the right


**385.** `19:58` **Meredith Lamb (+14169386001)**

I can’t find my routes\. Gimme a minute


**386.** `19:58` **Meredith Lamb (+14169386001)**

Studying


**387.** `19:58` **You**

the routes are actually reflects on the map with little icons


**388.** `19:58` **You**

and they match each other


**389.** `20:03` **You**

bullshit rainbows\.\.\.


**390.** `20:03` **You**

they hate me


**391.** `20:04` **Meredith Lamb (+14169386001)**

I don’t get it


**392.** `20:04` **Meredith Lamb (+14169386001)**

lol


**393.** `20:09` **You**

you are so going to beat me LOL


**394.** `20:09` **Meredith Lamb (+14169386001)**

Nope I have a shitty hand tbh but we will see :\)


**395.** `20:13` **You**

look at you\!\!


**396.** `20:13` **You**

all completed


**397.** `20:15` **Meredith Lamb (+14169386001)**

They were dumb tho


**398.** `20:15` **Meredith Lamb (+14169386001)**

What is happening right now


**399.** `20:19` **You**

:P


**400.** `20:19` **You**

risky


**401.** `20:19` **You**

lol


**402.** `20:19` **You**

hoping for an already completed one for free points


**403.** `20:20` **You**

errrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr


**404.** `20:21` **Meredith Lamb (+14169386001)**

Oh I wasn’t paying attention to your trains


**405.** `20:20` **You**

you win


**406.** `20:21` **Meredith Lamb (+14169386001)**

Man


**407.** `20:21` **Meredith Lamb (+14169386001)**

Shit


**408.** `20:21` **You**

you got 7 completes


**409.** `20:21` **You**

I got 5


**410.** `20:21` **Meredith Lamb (+14169386001)**

How do you know that


**411.** `20:21` **Meredith Lamb (+14169386001)**

Mine were small tho


**412.** `20:21` **You**

because it shows on your avatar


**413.** `20:21` **You**

so you have one final play\.\. because I am laying down next turn


**414.** `20:22` **You**

I love you\.\. just saying


**415.** `20:22` **You**

A whole big bunch


**416.** `20:23` **You**

❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️ that much and more


**417.** `20:23` **Meredith Lamb (+14169386001)**

lol you suck


**418.** `20:23` **You**

I do not


**419.** `20:23` **You**

well\.\.


**420.** `20:24` **Meredith Lamb (+14169386001)**

I did lose my first turn


**421.** `20:24` **Meredith Lamb (+14169386001)**

lol


**422.** `20:24` **You**

LOL


**423.** `20:24` **You**

Reaction: 😂 from Meredith Lamb
I knew it


**424.** `20:24` **You**

or it is the 4 or 5 glasses of wine


**425.** `20:24` **Meredith Lamb (+14169386001)**

I think it is just the online thing PLUS a bad hand


**426.** `20:25` **Meredith Lamb (+14169386001)**

I had a shitty first hand


**427.** `20:24` **You**

I mean\.\. ok\.\. it could be that


**428.** `20:25` **Meredith Lamb (+14169386001)**

My thing is “reconnecting”


**429.** `20:25` **You**

your "thing"


**430.** `20:25` **Meredith Lamb (+14169386001)**

Game


**431.** `20:25` **Meredith Lamb (+14169386001)**

I think too many girls are online maybe


**432.** `20:25` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**433.** `20:26` **You**

perhaps\.\. we don't have to play again\.\.\. you can go watch your show if you want\.


**434.** `20:26` **You**

you might just feel like relaxing and not thinking\.\. I figure\.


**435.** `20:27` **Meredith Lamb (+14169386001)**

I will play again if it reconnects


**436.** `20:31` **You**

no worries\.\.\. I am good either way\.


**437.** `20:33` **Meredith Lamb (+14169386001)**

You totally could have come back up here\. Lol just like drive all the time\. They are in the other cottage door shut by themselves\.


**438.** `20:33` **You**

Yeah I would have if this didn't exist down here\.


**439.** `20:34` **Meredith Lamb (+14169386001)**

😕


**440.** `20:34` **You**

who knows maybe Jaimie and I get in a huge fight tomorrow and I fuck off\.\. lol not likely so don't get hopes up rofl\.


**441.** `20:34` **Meredith Lamb (+14169386001)**

I could get the girls to disconnect  the side ring in some drunken state\. Believable lol


**442.** `20:34` **You**

totally


**443.** `20:34` **You**

rofl


**444.** `20:35` **You**

again unlikely\.\. I think J is going to have to engage and we need to actually fucking get this cleaning going\.


**445.** `20:35` **Meredith Lamb (+14169386001)**

🍸🍸🍸


**446.** `20:35` **Meredith Lamb (+14169386001)**

At dinner they were discussing what kind of drunk they were going to get tonight


**447.** `20:35` **You**

rofl


**448.** `20:35` **Meredith Lamb (+14169386001)**

Apparently “silly” won


**449.** `20:35` **You**

kids


**450.** `20:35` **You**

was stupid on the table


**451.** `20:36` **You**

wrekt?


**452.** `20:36` **You**

they probably don't know that one


**453.** `20:36` **Meredith Lamb (+14169386001)**

I was in another room so not sure but there were several options


**454.** `20:36` **You**

I know that one well


**455.** `20:36` **You**

I mean messy, sloppy


**456.** `20:36` **Meredith Lamb (+14169386001)**

>
When are you thinking of listing?

*💬 Reply*

**457.** `20:36` **You**

asap


**458.** `20:36` **You**

but I have decided I will likely rent


**459.** `20:36` **You**

a condo out of port whitby


**460.** `20:37` **Meredith Lamb (+14169386001)**

Oh then yeah maybe get going


**461.** `20:37` **You**

right by where I live


**462.** `20:37` **Meredith Lamb (+14169386001)**

“Port” Whitby?


**463.** `20:37` **You**

The Port


**464.** `20:37` **You**

the Yaht Club


**465.** `20:37` **You**

it is right on top of it


**466.** `20:37` **Meredith Lamb (+14169386001)**

Renting bc of us or you?


**467.** `20:38` **You**

Reaction: ❤️ from Meredith Lamb
Us\.\. I have to admit\.\. mostly\.


**468.** `20:38` **You**

hopeful


**469.** `20:38` **You**

tbh though what I was thinking\.\.


**470.** `20:38` **You**

was buying somewhere that you might like to live after you are done there


**471.** `20:39` **Meredith Lamb (+14169386001)**

Like


**472.** `20:39` **You**

I dunno


**473.** `20:39` **Meredith Lamb (+14169386001)**

lol


**474.** `20:39` **You**

you would have to tell me\.\. It would likely be slightly country\-ish


**475.** `20:39` **You**

problem would be I couldn't afford what I would really want\.\.


**476.** `20:39` **You**

but still I could figure something out'


**477.** `20:40` **Meredith Lamb (+14169386001)**

We could maybe figure something out together


**478.** `20:40` **You**

we have time for sure\.\. Summer of 2026 would be when I would start looking\.


**479.** `20:41` **Meredith Lamb (+14169386001)**

So you don’t want to live beside Jim?


**480.** `20:41` **Meredith Lamb (+14169386001)**

LOL


**481.** `20:41` **You**

No\.\. I want to go where you would want to be\.


**482.** `20:41` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I mean, currently, I could be anywhere with you and be amazing


**483.** `20:41` **You**

I mean do you want to be closer to parents\.\. north west east??


**484.** `20:42` **You**

>
feel same\.\. wouldn't matter\.\. would be awesome\.

*💬 Reply*

**485.** `20:42` **Meredith Lamb (+14169386001)**

Are you worried of that blowing up?


**486.** `20:42` **You**

no


**487.** `20:42` **Meredith Lamb (+14169386001)**

I was reading on ChatGPT


**488.** `20:42` **Meredith Lamb (+14169386001)**

And


**489.** `20:43` **Meredith Lamb (+14169386001)**

It said sometimes the secrecy and the manager/employee thjnf can amplify things


**490.** `20:43` **Meredith Lamb (+14169386001)**

\*thing


**491.** `20:43` **You**

it amplifies anxiety


**492.** `20:43` **Meredith Lamb (+14169386001)**

Omg drunk girls in my kitchen


**493.** `20:43` **Meredith Lamb (+14169386001)**

Haha


**494.** `20:43` **You**

honestly\.\. the way I feel isn't a function of secrecy\.\. do you know how much I would like to share this with others \- given I don't get in shit at work\.


**495.** `20:44` **Meredith Lamb (+14169386001)**

They keep talking about smores


**496.** `20:44` **You**

I am excited about this\.\. proud isn't the right word\.\. but I want people to know\.


**497.** `20:44` **You**

Reaction: 😵‍💫 from Meredith Lamb
Just not J or any of her relations


**498.** `20:44` **You**

:P


**499.** `20:45` **You**

naw she will know soon enough\.\. then we will see what happens\.


**500.** `20:45` **Meredith Lamb (+14169386001)**

I just keep hearing “can we open these?” I’m in my room and I go “you can open anything you want\!”


**501.** `20:45` **You**

if I get invited home for christmas or not


**502.** `20:45` **You**

>
LOL

*💬 Reply*

**503.** `20:46` **Meredith Lamb (+14169386001)**

>
She has to know eventually

*💬 Reply*

**504.** `20:46` **You**

yep


**505.** `20:46` **You**

she did ask me if I was coming home for xmas with Maddie


**506.** `20:46` **Meredith Lamb (+14169386001)**

My therapist said there is no good time\. But yeah get your shit settled first obviously


**507.** `20:46` **You**

Right now I think I am invited\.\. not sure after this though


**508.** `20:46` **Meredith Lamb (+14169386001)**

>
Omg you will be

*💬 Reply*

**509.** `20:47` **Meredith Lamb (+14169386001)**

“Meredith?\! Are these cupcakes for tomorrow??”


**510.** `20:47` **Meredith Lamb (+14169386001)**

lol


**511.** `20:47` **Meredith Lamb (+14169386001)**

I like teen girls


**512.** `20:47` **You**

she told me to wake her up first thing when I get back from gym and we crushing the garage\.\. that will be really good start\.


**513.** `20:47` **You**

>
I think you want to be a teen girl

*💬 Reply*

**514.** `20:48` **Meredith Lamb (+14169386001)**

Yes\.


**515.** `20:47` **You**

I mean we are acting like teenagers


**516.** `20:48` **Meredith Lamb (+14169386001)**

Mid life crisis?


**517.** `20:48` **You**

the making out\.\. all the\.\. other stuff\.


**518.** `20:48` **You**

I already had my mid life crisis at 40


**519.** `20:48` **Meredith Lamb (+14169386001)**

I’m pretty sure there are some adults doing that stuff too tho lol but yeah teen stuff


**520.** `20:48` **Meredith Lamb (+14169386001)**

>
For real?

*💬 Reply*

**521.** `20:49` **Meredith Lamb (+14169386001)**

Did you tell me about this?


**522.** `20:49` **You**

Really\.\. again\.\. I have been so out of touch with all of that\.\. making out was like what???\!\!\!


**523.** `20:49` **You**

Yeah I think I did\.\. mortality issues\.


**524.** `20:49` **You**

went on welbutrin


**525.** `20:49` **Meredith Lamb (+14169386001)**

Oh right


**526.** `20:49` **You**

but it was all about rationalizing it


**527.** `20:49` **Meredith Lamb (+14169386001)**

You mentioned that


**528.** `20:49` **You**

and I am fine now


**529.** `20:50` **Meredith Lamb (+14169386001)**

>
lol sort of the same\. I mean I haven’t liked Andrew for a long time but he tried :p doesn’t work when you have no connection or like

*💬 Reply*

**530.** `20:50` **Meredith Lamb (+14169386001)**

I think we could continue to make out for quite a while :\)


**531.** `20:51` **You**

Yeah\.\. I mean\.\. there was no trying here\.\.


**532.** `20:51` **Meredith Lamb (+14169386001)**

Luck maybe\.


**533.** `20:51` **Meredith Lamb (+14169386001)**

My bro was texting today


**534.** `20:51` **Meredith Lamb (+14169386001)**

He was surprised my fam doesn’t know about you


**535.** `20:52` **Meredith Lamb (+14169386001)**

I was all “whaaa?”


**536.** `20:52` **You**

>
I mean yeah\.\. but the other night\.\. on the couch\.\. there was no way I could continue that\.\. like it was crazy\.\. you laughed at me when I said something like "passionate much" lol

*💬 Reply*

**537.** `20:52` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I told him I will introduce you to mom and dad soon tho


**538.** `20:52` **You**

does he think we look alike?


**539.** `20:52` **You**

lol


**540.** `20:52` **Meredith Lamb (+14169386001)**

>
Honestly don’t remember that comment

*💬 Reply*

**541.** `20:52` **You**

yeah that was when I got up and said I am going to the other room


**542.** `20:52` **Meredith Lamb (+14169386001)**

>
Did not ask\. Will not ask\. Because it isn’t true\.

*💬 Reply*

**543.** `20:53` **Meredith Lamb (+14169386001)**

>
I remember that part

*💬 Reply*

**544.** `20:53` **You**

but yeah\.\. mer I could make out with you or just sit and cuddle\.\. wouldn't matter\.\. it's all good to me\.\.


**545.** `20:53` **You**

but yeah honestly the making out is super fun\.


**546.** `20:53` **You**

tbh


**547.** `20:53` **Meredith Lamb (+14169386001)**

>
Same\. I could just sit and watch you do ai talks… lol

*💬 Reply*

**548.** `20:54` **Meredith Lamb (+14169386001)**

I was like “too bad I can’t start everyday like this”


**549.** `20:54` **You**

:\) yeah or end every day\.\.\. or sometimes after lunch\.\. ☺️


**550.** `20:55` **You**

>
what\.\. no

*💬 Reply*

**551.** `20:55` **You**

that sounds wrong\.\.\. lol\.\. I sucked today\.


**552.** `20:57` **Meredith Lamb (+14169386001)**

>
What… yeah

*💬 Reply*

**553.** `20:57` **Meredith Lamb (+14169386001)**

>
No

*💬 Reply*

**554.** `20:57` **Meredith Lamb (+14169386001)**

I FaceTimed Mac to see if she was passed out


**555.** `20:57` **You**

there is nothing hot about me presenting about AI\.


**556.** `20:57` **Meredith Lamb (+14169386001)**

I’m like “why aren’t you in the kitchen?”
She goes “they are shit faces and we are painting shot glasses”


**557.** `20:57` **You**

hehe


**558.** `20:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**559.** `20:58` **You**

well done


**560.** `20:58` **Meredith Lamb (+14169386001)**

>
well…\.

*💬 Reply*

**561.** `20:58` **Meredith Lamb (+14169386001)**

I was glad she wasn’t passed out


**562.** `20:58` **You**

I especially like the pic of you in the bottom right


**563.** `20:58` **You**

I like when you look genuinely happy\.


**564.** `20:59` **Meredith Lamb (+14169386001)**

They are good girls\. But call each other bitch and slut too much lol


**565.** `20:59` **Meredith Lamb (+14169386001)**

>
I think it depends on the audience

*💬 Reply*

**566.** `21:00` **Meredith Lamb (+14169386001)**

Literally the only reason I logged on


**567.** `21:00` **Meredith Lamb (+14169386001)**

lol


**568.** `21:00` **You**

>
Next time I will give you a private AI presentation\.\. just talk about random AI nonsense\.\. lol see what happens ROFL\.

*💬 Reply*

**569.** `21:04` **Meredith Lamb (+14169386001)**

Promise?


**570.** `21:04` **You**

I will need wine


**571.** `21:04` **You**

and a cowboy hat\.


**572.** `21:04` **Meredith Lamb (+14169386001)**

Deal


**573.** `21:04` **Meredith Lamb (+14169386001)**

Deal


**574.** `21:04` **You**

LOL


**575.** `21:04` **Meredith Lamb (+14169386001)**

I can do both of those easily


**576.** `21:05` **You**

hmm\.\. I will have to think of something else then


**577.** `21:06` **Meredith Lamb (+14169386001)**

Wdym


**578.** `21:06` **Meredith Lamb (+14169386001)**

Why


**579.** `21:07` **You**

to make it more nonsensical\.\. Hmm\.\. I will ask you did you know Ai questions mid makeout while wearing a cowboy hat and no shirt\.


**580.** `21:07` **You**

Also had an idea\.


**581.** `21:07` **You**

fyi


**582.** `21:07` **You**

Reaction: ❓ from Meredith Lamb
you know those plans I said I wouldn't make


**583.** `21:07` **You**

cannot help it\.


**584.** `21:08` **Meredith Lamb (+14169386001)**

>
I don’t want it to be nonsensical\!

*💬 Reply*

**585.** `21:08` **You**

well it will be real\.\.


**586.** `21:08` **You**

you might not get it though\.\. unless you understand python, and claude, and gemini and some of the new things they can do\.


**587.** `21:09` **Meredith Lamb (+14169386001)**

Unlikely… I think I need a session


**588.** `21:09` **You**

when is the school year over?


**589.** `21:09` **Meredith Lamb (+14169386001)**

Usually June 28ish


**590.** `21:09` **You**

kk\.\. well I had an idea we can do a few different ways\.\. which I think you would be into\.


**591.** `21:09` **You**

well maybe\.


**592.** `21:10` **You**

We could do something with Jim\.\. and family\.\.


**593.** `21:10` **Meredith Lamb (+14169386001)**

>
Probably

*💬 Reply*

**594.** `21:10` **Meredith Lamb (+14169386001)**

Family?


**595.** `21:10` **You**

well friends


**596.** `21:10` **You**

I guess


**597.** `21:11` **Meredith Lamb (+14169386001)**

Not computing\. Elaborate


**598.** `21:11` **You**

ok\.\. i can sell going to Jims, drinking and staying the night there and most of the next day easily\.


**599.** `21:11` **You**

so I will start with that\.


**600.** `21:11` **Meredith Lamb (+14169386001)**

I feel like if I gave you a good cowboy hat you would have nowhere to keep it\. Birthday\.


**601.** `21:11` **You**

I cannot keep anything atm


**602.** `21:12` **Meredith Lamb (+14169386001)**

I know


**603.** `21:12` **Meredith Lamb (+14169386001)**

There is a really great place for country stuff in London


**604.** `21:12` **You**

except for the rock because I can hide it at work


**605.** `21:12` **Meredith Lamb (+14169386001)**

>
Yes I could do this too bc it is near my parents

*💬 Reply*

**606.** `21:12` **You**

btw I don't tink you are ever reconnecting\.\. going to turn the game off\.\. the music is driving me\.


**607.** `21:12` **Meredith Lamb (+14169386001)**

Kind of


**608.** `21:12` **You**

well that was the next phase


**609.** `21:13` **Meredith Lamb (+14169386001)**

>
Oh I wasn’t even trying sorry

*💬 Reply*

**610.** `21:13` **Meredith Lamb (+14169386001)**

lol


**611.** `21:13` **Meredith Lamb (+14169386001)**

\!\!\!


**612.** `21:13` **You**

after we are done there\.\. we could hotel, bnb, or basement?? lol


**613.** `21:13` **Meredith Lamb (+14169386001)**

Listening to girls in my kitchen


**614.** `21:13` **You**

>
lol

*💬 Reply*

**615.** `21:13` **Meredith Lamb (+14169386001)**

>
If I intro you to my parents we could likely stay there in a less awkward way

*💬 Reply*

**616.** `21:13` **Meredith Lamb (+14169386001)**

>
Fine with any

*💬 Reply*

**617.** `21:13` **You**

Could do that before going to Jims? or whatever\.


**618.** `21:14` **Meredith Lamb (+14169386001)**

Kristine liked my bra pong


**619.** `21:14` **You**

just need to do a weekend when Jaimie is home\.


**620.** `21:14` **Meredith Lamb (+14169386001)**

Kristine said I’m a “cool mom”


**621.** `21:14` **You**

because like as she is away next weekend\.\. if I went out for the night she would lose her goddamn mind\.


**622.** `21:14` **You**

>
you are

*💬 Reply*

**623.** `21:14` **Meredith Lamb (+14169386001)**

Yeah we wouldn’t when she is away


**624.** `21:14` **Meredith Lamb (+14169386001)**

Of course


**625.** `21:15` **Meredith Lamb (+14169386001)**

Jim started texting me more\. I think he REALLY was flattered


**626.** `21:15` **Meredith Lamb (+14169386001)**

Like “wow they consider me a friend”


**627.** `21:15` **Meredith Lamb (+14169386001)**

Haha


**628.** `21:15` **You**

he won't text me at all\.\. so sad\.


**629.** `21:15` **Meredith Lamb (+14169386001)**

Seriously?


**630.** `21:15` **Meredith Lamb (+14169386001)**

lol


**631.** `21:15` **You**

yeah I invited him to signal and everything\.\.


**632.** `21:16` **You**

he did say he was too busy to connect this aft with everything going on with residential\.\. I completely understood


**633.** `21:16` **Meredith Lamb (+14169386001)**

lol well he probably doesn’t like new apps\. He isn’t good with tech


**634.** `21:16` **Meredith Lamb (+14169386001)**

Apparently their rec is 0\.4


**635.** `21:16` **Meredith Lamb (+14169386001)**

\*trc


**636.** `21:16` **You**

good stuff


**637.** `21:20` **Meredith Lamb (+14169386001)**

Does Gracie post on social media?


**638.** `21:20` **You**

Sometimes not much though why


**639.** `21:20` **You**

actually almost never


**640.** `21:21` **Meredith Lamb (+14169386001)**

Just some drunk girls asking


**641.** `21:21` **You**

she is too paranoid


**642.** `21:21` **Meredith Lamb (+14169386001)**

lol


**643.** `21:21` **You**

why they want to see her?


**644.** `21:21` **Meredith Lamb (+14169386001)**

Yeah


**645.** `21:21` **You**

like a pic or something?


**646.** `21:21` **You**

sec


**647.** `21:21` **Meredith Lamb (+14169386001)**

Yeah


**648.** `21:21` **Meredith Lamb (+14169386001)**

I’m drinking in kitchen with them now


**649.** `21:21` **You**

don't show them any pics of me\.\. only the young one\.


**650.** `21:21` **You**

:P


**651.** `21:21` **You**

with hair lol


**652.** `21:22` **Meredith Lamb (+14169386001)**

Haha


**653.** `21:22` **You**

and none of those other ones from gym either\.\. behave\.


**654.** `21:22` **Meredith Lamb (+14169386001)**

lol


**655.** `21:26` **Meredith Lamb (+14169386001)**

So I just learned that Johnnie’s gummies are indigenous


**656.** `21:26` **You**

Jim literally told you that


**657.** `21:26` **Meredith Lamb (+14169386001)**

Apparently there is an indigenous place at Yonge and Eglinton


**658.** `21:26` **You**

in the breakout room


**659.** `21:26` **Meredith Lamb (+14169386001)**

lol


**660.** `21:26` **You**

when we talked to him


**661.** `21:30` **Meredith Lamb (+14169386001)**

I knooow I didn’t believe it


**662.** `21:30` **Meredith Lamb (+14169386001)**

So the girls are on board to disable the ring if required


**663.** `21:30` **You**

ok I am still looking for images\.\.


**664.** `21:31` **You**

I don't think it will happen Mer\.\. honestly\.\. I cannot find a reason\.\. j would kick my fucking ass\.


**665.** `21:31` **You**

we would have to get in a massive fight\.\. and I would rather not


**666.** `21:31` **Meredith Lamb (+14169386001)**

I honestly was kidding


**667.** `21:31` **You**

would love to see you don't get me wrong


**668.** `21:31` **You**

kk


**669.** `21:31` **Meredith Lamb (+14169386001)**

I probably couldn’t handle you coming\. Stay up too late etc


**670.** `21:32` **Meredith Lamb (+14169386001)**

I have a lot to take care of after these girls


**671.** `21:32` **Meredith Lamb (+14169386001)**

And Andrew has to come back Sunday


**672.** `21:34` **Meredith Lamb (+14169386001)**

>
Can you stop\. They don’t even care who you are\. They are happy for Meredith\.

*💬 Reply*

**673.** `21:34` **Meredith Lamb (+14169386001)**

lol


**674.** `21:34` **You**


*📎 1 attachment(s)*

**675.** `21:34` **You**

>
I am good with that

*💬 Reply*

**676.** `21:34` **You**

Gracie is in Green


**677.** `21:34` **Meredith Lamb (+14169386001)**

And who is in black


**678.** `21:34` **You**

Demon Woman


**679.** `21:35` **Meredith Lamb (+14169386001)**

Hannah


**680.** `21:34` **You**

Hanah\.\.


**681.** `21:34` **You**

yeah


**682.** `21:36` **You**

maddie is a little more shy

*📎 1 attachment(s)*

**683.** `21:42` **Meredith Lamb (+14169386001)**

Like my daughter Maelle


**684.** `21:42` **Meredith Lamb (+14169386001)**

:\)


**685.** `21:42` **You**

lol


**686.** `21:42` **You**

I thought there were more pics but cannot find\.


**687.** `21:49` **Meredith Lamb (+14169386001)**

Sorry took a gummy but it is a tame one\. Not one of johnnys


**688.** `21:49` **You**


*📎 1 attachment(s)*

**689.** `21:49` **You**

ROFL


**690.** `21:49` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**691.** `21:49` **You**

I am right about everything


**692.** `21:49` **You**

forever


**693.** `21:50` **Meredith Lamb (+14169386001)**

Johnny had promised tonight\. He wanted Mac and I to come over

*💬 Reply*

**694.** `21:50` **You**

I do worry about you\.\. though\.


**695.** `21:50` **Meredith Lamb (+14169386001)**

This is him with his parents\. Aw


**696.** `21:50` **You**

he's a good looking kid\.\. they look proud\.


**697.** `21:51` **Meredith Lamb (+14169386001)**

>
The his is why I like you 🤮

*💬 Reply*

**698.** `21:51` **Meredith Lamb (+14169386001)**

>
Did I mention he’s 6’7” lol

*💬 Reply*

**699.** `21:52` **You**

>
You did mer\.\. you said you like them big remember\.\. or maybe you don't  heheh

*💬 Reply*

**700.** `21:52` **Meredith Lamb (+14169386001)**

I didn’t necessarily mean tall


**701.** `21:53` **Meredith Lamb (+14169386001)**

But tall is good yes


**702.** `21:53` **Meredith Lamb (+14169386001)**

But I consider 6’ tall


**703.** `21:53` **You**

>
you should probably leave this one alone\.

*💬 Reply*

**704.** `21:53` **You**

lol


**705.** `21:53` **Meredith Lamb (+14169386001)**

Oh stop


**706.** `21:53` **Meredith Lamb (+14169386001)**

You are tall


**707.** `21:54` **You**

maddie dressed\.\. well more like Mac and her friends LOL\.

*📎 1 attachment(s)*

**708.** `21:54` **You**

She was Grade 10 there\.


**709.** `21:54` **Meredith Lamb (+14169386001)**

They are gr 10 now :\)


**710.** `21:54` **You**

>
I think this kind of sailed past you\.

*💬 Reply*

**711.** `21:54` **You**

sok though


**712.** `21:55` **Meredith Lamb (+14169386001)**

>
Leave what alone?

*💬 Reply*

**713.** `21:55` **You**

Nothing\.\. nm\.\. oh look it is almost bed time\.


**714.** `21:55` **Meredith Lamb (+14169386001)**

No you can’t do that


**715.** `21:56` **Meredith Lamb (+14169386001)**

Come on


**716.** `21:56` **Meredith Lamb (+14169386001)**

No oh look squirrel


**717.** `21:56` **You**

Naw\.\. it is too awkward\.\. and you are likely now drunk with a bunch of teens around\.


**718.** `21:56` **Meredith Lamb (+14169386001)**

I’m actually in my room alone


**719.** `21:56` **You**

plus we did this once before\.\.


**720.** `21:56` **Meredith Lamb (+14169386001)**

They are in other cottage


**721.** `21:57` **Meredith Lamb (+14169386001)**

>
Huh?

*💬 Reply*

**722.** `21:57` **Meredith Lamb (+14169386001)**

I’m so confused


**723.** `21:57` **Meredith Lamb (+14169386001)**

Come on


**724.** `21:57` **You**

I know hon its ok\.


**725.** `21:57` **Meredith Lamb (+14169386001)**

Put me out of my misery


**726.** `21:57` **Meredith Lamb (+14169386001)**

Clarify


**727.** `21:57` **Meredith Lamb (+14169386001)**

I am not too drunk


**728.** `21:57` **Meredith Lamb (+14169386001)**

Bottle is not gone


**729.** `21:58` **You**

You said you like them big\.\. lol\.\. has so many meanings\.\. and you were drunk last time\.\. and you just kept going on\.\. lol I tried to drop the line on you again to see if you would react but I guess you forgot\.


**730.** `21:58` **You**

brb


**731.** `21:58` **Meredith Lamb (+14169386001)**

Oh I didn’t mean like appendage big\. I meant like I don’t like skinny guys


**732.** `21:58` **Meredith Lamb (+14169386001)**

God


**733.** `21:58` **You**

bio will just be a min\.\. and I am turning game off lol bedtime shortly\.


**734.** `22:05` **You**

>
mmmmmm hmmmmmm\.\.\. I can be a little skeptical on that right\.\. and please no further explanation necessary LOL\.

*💬 Reply*

**735.** `22:05` **Meredith Lamb (+14169386001)**

I’m being serious


**736.** `22:05` **Meredith Lamb (+14169386001)**

Like 150%


**737.** `22:05` **Meredith Lamb (+14169386001)**

Ask anyone who knows me


**738.** `22:06` **You**

You want me to ask people that know you about appendages?


**739.** `22:06` **You**

lol


**740.** `22:06` **Meredith Lamb (+14169386001)**

I’ve always dated like bigger guys\. Not skinny guys


**741.** `22:06` **You**

I mean\.\. hey I'm Scott


**742.** `22:06` **Meredith Lamb (+14169386001)**

Has nothing to do with anything else


**743.** `22:06` **You**

and I would like to ask you a question about appendages


**744.** `22:06` **You**

heheh


**745.** `22:06` **Meredith Lamb (+14169386001)**

When I say that it doesn’t have to do with that


**746.** `22:07` **Meredith Lamb (+14169386001)**

Seriously


**747.** `22:07` **You**

now did you actually like chubby me better\.\. ??


**748.** `22:07` **You**

I am a bit confused if big is dad bod or big is just\.\.\. hmm


**749.** `22:08` **Meredith Lamb (+14169386001)**

I mean it is flexible, I like you as long as you don’t go anorexic


**750.** `22:09` **Meredith Lamb (+14169386001)**

I guess it is contextual


**751.** `22:09` **You**

again\.\. shooting for this still my goal :\)

*📎 1 attachment(s)*

**752.** `22:09` **You**

:P


**753.** `22:09` **Meredith Lamb (+14169386001)**

I mean that is “big”


**754.** `22:09` **You**

believe it or not he isn't even 200 lbs there


**755.** `22:09` **Meredith Lamb (+14169386001)**

It’s definitely not skinny


**756.** `22:10` **Meredith Lamb (+14169386001)**

I think I’m attracted to so much more than just physical but don’t like skinny people generally lol


**757.** `22:10` **You**

actually nm he fluctuates from 200\-220 and he is 6'1


**758.** `22:10` **You**

I can definitely pull this off\.


**759.** `22:10` **Meredith Lamb (+14169386001)**

lol


**760.** `22:11` **Meredith Lamb (+14169386001)**

We talk a lot about things I like … hmmh


**761.** `22:11` **You**

what are you curious about?


**762.** `22:12` **You**

We talk about it because I am focused on it\.\. like to a fault\.


**763.** `22:12` **Meredith Lamb (+14169386001)**

Why


**764.** `22:13` **You**

That pic there\.\. I wanted to look like that pic since I saw the movie\.


**765.** `22:13` **Meredith Lamb (+14169386001)**

I’m curious how you have just completely disregarded your needs and desires for like 20 years? How that happens?


**766.** `22:13` **You**

what needs


**767.** `22:14` **Meredith Lamb (+14169386001)**

I dunno, whatever they are


**768.** `22:14` **Meredith Lamb (+14169386001)**

They obviously are not being met


**769.** `22:14` **You**

I didn't disregard them\.\. the whole needs thing turning off happened when I met you\.  Like I explained\.\. i took care of myself\.\. when I met you\.\. that just kind of turned off\.\. completely\.\. it was like nope\.\. that isn't good enough\.\. just you\.\. that is what I need\.


**770.** `22:15` **You**

but before that yeah I obviously had to deal with what I was going through\.


**771.** `22:15` **You**

and no cheating or anything else\.\. so it is what it is\.


**772.** `22:15` **Meredith Lamb (+14169386001)**

🤔


**773.** `22:15` **Meredith Lamb (+14169386001)**

That’s weird response


**774.** `22:16` **You**

how so?


**775.** `22:16` **Meredith Lamb (+14169386001)**

Because you were in a marriage


**776.** `22:16` **You**

what do you think single people do?


**777.** `22:16` **You**

lol


**778.** `22:16` **Meredith Lamb (+14169386001)**

You were in a marriage though


**779.** `22:16` **You**

just pretend I was single 95% of my marriage


**780.** `22:16` **Meredith Lamb (+14169386001)**

Huh no


**781.** `22:17` **Meredith Lamb (+14169386001)**

That is not normal


**782.** `22:17` **You**

I know it is hard for you to understand\.\. your situation was 180 degrees the other direciton\.


**783.** `22:17` **You**

just our situations were different


**784.** `22:17` **You**

after a while the needs kind of go away\.


**785.** `22:17` **Meredith Lamb (+14169386001)**

Your situation is really confusing


**786.** `22:17` **You**

yeah\.\. well\.\. I didn't envy you yours either\.


**787.** `22:18` **Meredith Lamb (+14169386001)**

Me neither


**788.** `22:18` **You**

I think you are wondering how am I like this now maybe?


**789.** `22:18` **You**

because so am I


**790.** `22:18` **You**

I think it is you


**791.** `22:18` **Meredith Lamb (+14169386001)**

I’m just wondering how you and j lasted so long?


**792.** `22:18` **You**

that is about it


**793.** `22:18` **You**

because I felt obligated towards her\.


**794.** `22:18` **You**

I brought her here\.


**795.** `22:18` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/2QQ0lfEAu3ncUHM3C6Rkg3?si=5\-COHErFQK65ZYLI2B8VYg


**796.** `22:19` **Meredith Lamb (+14169386001)**

I’m doing an OLP night tonight


**797.** `22:19` **Meredith Lamb (+14169386001)**

>
But like she was ok with it?

*💬 Reply*

**798.** `22:19` **You**

I meant to pla foo fighters the other night\.


**799.** `22:19` **You**

>
well we didn't have a lot of options\.

*💬 Reply*

**800.** `22:19` **You**

but she always wanted to move home


**801.** `22:20` **Meredith Lamb (+14169386001)**

Ok well I look forward to the day where we we can tell our respective families the truth\. I know it is a ways out


**802.** `22:21` **You**

>
again\.\. sex isn't the only thing in a relationship\.\. I think it is important\.\. but I don't think it is like Glue\.\.  in fact I think it can be toxic and shitty in many cases\.

*💬 Reply*

**803.** `22:21` **You**

>
I mean\.\. J will find out eventually\.\.\. likely before christmas

*💬 Reply*

**804.** `22:23` **Meredith Lamb (+14169386001)**

>
Andrew thinks it is \#1 so to each their own I guess

*💬 Reply*

**805.** `22:24` **Meredith Lamb (+14169386001)**

>
This still bothers you

*💬 Reply*

**806.** `22:24` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**807.** `22:25` **Meredith Lamb (+14169386001)**

I heard them playing a game so ran down


**808.** `22:25` **Meredith Lamb (+14169386001)**

They are playing “the vape game”


**809.** `22:25` **Meredith Lamb (+14169386001)**

The bag is full of vapes


**810.** `22:25` **Meredith Lamb (+14169386001)**

LOL


**811.** `22:25` **Meredith Lamb (+14169386001)**

I got them to give me a real one


**812.** `22:25` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I’m such a pathetic mom lol


**813.** `22:27` **You**

Reaction: 😂 from Meredith Lamb
>
Def not number one\.  But like I said\.\. it has been so long since any sense of normalcy and beyond that since I was happy about it\.\. I mean\.\. I probably don't have a lot of perspective on this\.  And again\.\. you don't even register for me like I don't even know how to explain it\.\. but it is unique in an extremely good, happy, comforting, safe way\.\. all of those things\.\. and more\.  I don't see these feelings changing\.\. but I would never oblige you to do anything\.\. like there aren't quota's or required things you must do to or for me lol\.\. that is fucking nonsense\.  There are things I would happily do to or for you though\.\. just so you know\.\. I am kind of more built that way\.

*💬 Reply*

**814.** `22:28` **You**

sounds like best game ever


**815.** `22:28` **You**

>
it doesn

*💬 Reply*

**816.** `22:28` **You**

no


**817.** `22:28` **You**

it doesn't


**818.** `22:28` **You**

i just would prefer it to be when she is back in Moncton\.\. and slightly established


**819.** `22:29` **Meredith Lamb (+14169386001)**

>
I think it does

*💬 Reply*

**820.** `22:28` **You**

>
it's true\.\.\. :P

*💬 Reply*

**821.** `22:29` **You**

>
No\.\. I am not afraid of her finding out we are together\.\. but I cannot tell her how I feel about you\.\.

*💬 Reply*

**822.** `22:29` **You**

not the extent


**823.** `22:29` **You**

I don't want to break her\.


**824.** `22:29` **Meredith Lamb (+14169386001)**

>
It’s okay\. I know you care\. She is the mom to your kids etc etc etc etc\. been there for you through a lot etc

*💬 Reply*

**825.** `22:30` **Meredith Lamb (+14169386001)**

All valid


**826.** `22:30` **You**

>
I think we are talking about different things\.\. let's set this aside and you can go back and think about the things I want to do to you instead\.\. happier thoughts before bed

*💬 Reply*

**827.** `22:31` **Meredith Lamb (+14169386001)**

I think we are talking the same things but okay lol


**828.** `22:31` **Meredith Lamb (+14169386001)**

You can go to bed Yunno


**829.** `22:31` **You**

>
Can you explain what your concern / focus is on tis particular thing\.\. like are you going to tell Andrew\.\. I am dating Scott\.\. and I love him more than I ever loved you\.

*💬 Reply*

**830.** `22:32` **You**

like no\.\.


**831.** `22:32` **You**

you aren't


**832.** `22:32` **Meredith Lamb (+14169386001)**

I probably will actually


**833.** `22:32` **You**

Jaimie will know we are dating\.\. and that is the extent to which we would need to discuss it\.


**834.** `22:32` **Meredith Lamb (+14169386001)**

But I’m different than you


**835.** `22:32` **Meredith Lamb (+14169386001)**

It’s ok


**836.** `22:32` **You**

she would want to know if and when you met Maddie\.


**837.** `22:33` **Meredith Lamb (+14169386001)**

I don’t tend to lie to Andrew


**838.** `22:33` **Meredith Lamb (+14169386001)**

I omit sometimes


**839.** `22:33` **You**

But she wouldn't want to hear how so soon after I basically divorced her, I actually met my soulmate\.  and completely fell for her so hard that I don't even know how to deal with it most of the time\.


**840.** `22:33` **You**

Like that kind of truth


**841.** `22:33` **You**

would crush her\.


**842.** `22:33` **Meredith Lamb (+14169386001)**

I dont think it needs to be articulated that way


**843.** `22:34` **Meredith Lamb (+14169386001)**

I won’t articulate it that way


**844.** `22:34` **You**

I will let her know it is serious\.


**845.** `22:34` **You**

I think beyond that she doesn't need any details\.


**846.** `22:34` **Meredith Lamb (+14169386001)**

Agree


**847.** `22:34` **You**

I mean she has Guessed half the shit already


**848.** `22:34` **Meredith Lamb (+14169386001)**

But it is more than discussions and we hardly talk anymore


**849.** `22:35` **You**

she said something sarcastically the other night\.\. fishing I think more than anything else\.\. but saying something about how I would never even touch her let alone have sex with her\.\. and she said I bet you don't have any problems having sex with Meredith\.


**850.** `22:35` **You**

I obviously didn't respond\.\. but she was right\.\. :/


**851.** `22:35` **You**

There is a connection and a psychological component to it\.


**852.** `22:36` **You**

and an emotional one for me


**853.** `22:36` **Meredith Lamb (+14169386001)**

Of course\. Exact same for me


**854.** `22:37` **Meredith Lamb (+14169386001)**

Jim asked my relationship history bc he was like “Scott had never experienced this before”


**855.** `22:37` **You**

the feelings\.\.


**856.** `22:37` **You**

yeah he is right


**857.** `22:38` **Meredith Lamb (+14169386001)**

I told him basically I’ve had 3 prior longer term relationships but only one where maybe some emotional component was involved but honestly it became unstable and always felt a little shifty and what I have with you feels unbreakable


**858.** `22:39` **Meredith Lamb (+14169386001)**

But basically it was because too many drugs were involved \(in retrospect\)


**859.** `22:40` **You**

Yeah that is unfortunate\.\. like I want to be honest\.\. it isn't that I haven't had long term relationships where there weren't emotions\.\. I had very emotional relationships\. with a couple of people\.\. again\.\. nothing like this\.\. nothing even close\.\. but I would say much stronger than what i had with Jaimie nonetheless\.\.


**860.** `22:41` **You**

So I haven't fallen in love this hard\.\. ever\.\. and am a little afraid\.\. but I am not completely inexperienced at protecting myself\.


**861.** `22:41` **Meredith Lamb (+14169386001)**

I do feel kind of bad for Jaimie


**862.** `22:41` **You**

I know you do\.


**863.** `22:42` **Meredith Lamb (+14169386001)**

But I feel bad for me too so


**864.** `22:42` **Meredith Lamb (+14169386001)**

lol\!


**865.** `22:42` **You**

yes there is that\.


**866.** `22:42` **Meredith Lamb (+14169386001)**

We all have our stories


**867.** `22:42` **You**

it comes back to do we deserve to be happy


**868.** `22:42` **You**

I feel like yes\.\.


**869.** `22:43` **You**

I have gone through 25 years\.\.  and I have been a good boy\.\. even though it wasn't what I really wanted or hoped for\.


**870.** `22:43` **You**

So yeah\.\. I want some happiness


**871.** `22:43` **You**

and before you say some nonsense\.


**872.** `22:43` **You**

You will always make me happy


**873.** `22:43` **You**

I will always want to come home to you\.


**874.** `22:44` **Meredith Lamb (+14169386001)**

>
I want you to have some too

*💬 Reply*

**875.** `22:44` **You**

well I have some\.\. so we are already there\.\. :\)


**876.** `22:45` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/2gz6rDUWhKn1XWi7iapbpm?si=OzVnyG29RSu50mVzGOZJdw
One of my favourite songs just came on


**877.** `22:45` **You**

>
>
I wore that cd down to nothing I played it so much

*💬 Reply*

**878.** `22:46` **Meredith Lamb (+14169386001)**

>
Me…\. Nonsense?

*💬 Reply*

**879.** `22:46` **You**

you always worry


**880.** `22:47` **Meredith Lamb (+14169386001)**

>
Good boy? 🫤

*💬 Reply*

**881.** `22:46` **You**

about some nonsense shit


**882.** `22:47` **You**

and I wish you could get in my head


**883.** `22:47` **You**

because you would see how silly it is


**884.** `22:48` **Meredith Lamb (+14169386001)**

So can I confess something bc I’m almost a bottle in?


**885.** `22:47` **You**

Reaction: 🙄 from Meredith Lamb
>
i\.e\. true to J\.

*💬 Reply*

**886.** `22:48` **You**

>
sure

*💬 Reply*

**887.** `22:48` **You**

like a bad confession or a good confession or a neutral


**888.** `22:48` **Meredith Lamb (+14169386001)**

>
No idea what you would think

*💬 Reply*

**889.** `22:48` **You**

>
you think I broke that with you?

*💬 Reply*

**890.** `22:49` **You**

>
sure fire away

*💬 Reply*

**891.** `22:49` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/06O0ARnlFjcI6U2uIe6rMU?si=NHqcslAnQOSEwRRMd\_q6MQ


**892.** `22:50` **You**

deleted?


**893.** `22:50` **You**

if deleted


**894.** `22:51` **You**

you must share the original copy


**895.** `22:51` **You**

in addition to the updated


**896.** `22:51` **You**

that is the rule


**897.** `22:51` **You**

you deleted again I bet


**898.** `22:51` **Meredith Lamb (+14169386001)**

So before AD \(Andrew lol\) I acted a lot differently in relationships and even physically was more into trying different things etc and then with Andrew, nothing ever\. Not sure why\.
But with you I feel safe to be pre\-AD and wonder if you feel similar


**899.** `22:51` **Meredith Lamb (+14169386001)**

I don’t delete anything


**900.** `22:51` **Meredith Lamb (+14169386001)**

I’m it as fast as typer as you apparently


**901.** `22:51` **You**

so\.\. hmmm\.\.\.


**902.** `22:52` **Meredith Lamb (+14169386001)**

Honestly no deleting


**903.** `22:52` **Meredith Lamb (+14169386001)**

I just don’t type as fast


**904.** `22:52` **You**

well I am on comp


**905.** `22:52` **Meredith Lamb (+14169386001)**

And I swear to god the girls just broke something in


**906.** `22:52` **You**

so it is easier


**907.** `22:52` **Meredith Lamb (+14169386001)**

I’m on my phone so yeah slower


**908.** `22:52` **You**

>
please go back to this and comment\.\. I am curious\.\. sounded like you disagreed with the good boy\.\. want to know if that is because of us?

*💬 Reply*

**909.** `22:54` **You**

>
>
>
Like\.\. hmm\.\. so you know I am slightly insecure\.\. in general\.\. I wasn't as much in my 20's and late teens\.\. I had no problems trying different things\.\. but I will be honest\.\. I was usually the one being tossed around lol\.

*💬 Reply*

**910.** `22:55` **You**

>
I mean\.\. lol\.\. I need a fucking drink\.

*💬 Reply*

**911.** `22:55` **Meredith Lamb (+14169386001)**

>
I don’t think you broke it with me\. I think you broke it LONG before\. You were never all in with her it sounds\. But this is someone on the outside looking in…\. I just mean it doesn’t sound like you let yourself go with her\. You just saved her and took care of her\. Didn’t sound like a mutual thing but maybe it was at times and just isn’t now\.

*💬 Reply*

**912.** `22:55` **You**

yeah that is fair\.


**913.** `22:55` **You**

I can accept that


**914.** `22:56` **Meredith Lamb (+14169386001)**

At the end of the day, the two of you are the only ones that truly know your relationship


**915.** `22:56` **You**

well it was different for her than me\.


**916.** `22:56` **Meredith Lamb (+14169386001)**

>
Tossed around? Lol wtf?

*💬 Reply*

**917.** `22:56` **You**

TMI


**918.** `22:57` **Meredith Lamb (+14169386001)**

No it’s not


**919.** `22:57` **Meredith Lamb (+14169386001)**

lol


**920.** `22:57` **You**

I feel like it is\.\. like talking about other sexual partners\.\. is awkward talking details\.\. eeesh much more so\.  Let's say I am flexible\.\. and will go with pretty much anything


**921.** `22:57` **Meredith Lamb (+14169386001)**

Where does your insecurity come from?


**922.** `22:58` **You**

I dunno\.\. just always felt kind of meh


**923.** `22:58` **Meredith Lamb (+14169386001)**

>
I don’t find it awkward at all

*💬 Reply*

**924.** `22:58` **Meredith Lamb (+14169386001)**

You have a past


**925.** `22:58` **Meredith Lamb (+14169386001)**

You are 47


**926.** `22:58` **Meredith Lamb (+14169386001)**

\(Basically\)


**927.** `22:59` **You**

It is just we might have slightly different comfort levels there\.\. \+ we have established my past is a bit more checkered in that respect from yours\.\. not a proud thing to be sure\.  more of a misguided youth thing\.


**928.** `22:59` **Meredith Lamb (+14169386001)**

But I have no issues with that


**929.** `22:59` **Meredith Lamb (+14169386001)**

Mine isn’t great either


**930.** `23:00` **Meredith Lamb (+14169386001)**

I mean, not proud of some scenarios


**931.** `23:00` **Meredith Lamb (+14169386001)**

But it is done\. Can’t control


**932.** `23:00` **You**

yeah\.\. I think for me it is looking back is like reliving some of it\.\. hmm\.\. let me put it to you another way\.\. this is going to sound really weird ok\.\. so just let me get through it\.


**933.** `23:02` **You**

I always wanted to connect with someone\.\. at some level even if it was \.\.\.\. fleeting\.\. that is a nice way to say it\.\. I never liked feeling like I was "fucking" someone\.\. that really didn't do anything for me except make me feel bad\.  I would go along with whatever a person wanted\.\. because again\.\. if it made them happy I would be all for it\.\. but I never really liked the way it made me feel\.\. now with you\.\. I think that could be different again\.\. more just from how much I do feel\.\. and well how much we have communicated about these kinds of things\.


**934.** `23:04` **You**

And I mean let's be honest\.\. I am 47\.\. I am shocked I can even do what I am doing atm\.\. with all the shit that was wrong with me\.  So just a little cautious\.\. but again with you I would be up for pretty much whatever would make you happy\.


**935.** `23:05` **You**

Plus as I said previously\.\. you are hard to read\.\.\. you internalize everything \- and I mean everything\.\.\.\.\. lol  so it is kind of difficult to know what is going on happy, engaged, not so much\.\. again\.\. kind of challenging\.


**936.** `23:06` **You**

>
I have lot's and lot's of these\.

*💬 Reply*

**937.** `23:11` **You**

Curious to see your response\.\. you vanished\.\. lol


**938.** `23:11` **Meredith Lamb (+14169386001)**

Just had to clean up a broken glass\. One sec need to read


**939.** `23:11` **You**

also curious what brought the confession on\.\.


**940.** `23:11` **You**

when you get through this


**941.** `23:12` **Meredith Lamb (+14169386001)**

They were going to watch a horror movie


**942.** `23:12` **Meredith Lamb (+14169386001)**

I walk by “what are you watching?”


**943.** `23:12` **You**

lol


**944.** `23:12` **Meredith Lamb (+14169386001)**

Them: Superstore


**945.** `23:12` **Meredith Lamb (+14169386001)**

😳


**946.** `23:12` **You**

haha


**947.** `23:13` **Meredith Lamb (+14169386001)**

So weird


**948.** `23:14` **Meredith Lamb (+14169386001)**

>
Why didn’t Jaimie just tell you to take viagara?

*💬 Reply*

**949.** `23:15` **You**

I basically am on a version of that\.\.


**950.** `23:15` **Meredith Lamb (+14169386001)**

Would you two still be together had you done that?


**951.** `23:15` **You**

just a low dose every day\.\. I tried Viagara\.\. it was far less effective by far than what I am experiencing with you\.\. on a quarter of the dosage\.


**952.** `23:15` **You**

>
No\.\.\.\. LOL

*💬 Reply*

**953.** `23:16` **You**

I told you sex for me isn't the same as perhaps other people\.


**954.** `23:16` **You**

more sex in an unhappy relationship solves nothing


**955.** `23:16` **Meredith Lamb (+14169386001)**

I do think there is so much more than “intercourse”


**956.** `23:16` **You**

when the underlying problems/


**957.** `23:16` **You**

>
there probably is\.\. I haven't chatgpt'd that yet

*💬 Reply*

**958.** `23:16` **You**

I will now


**959.** `23:17` **Meredith Lamb (+14169386001)**

>
I have experienced a relationship of this nature\. I think you think it is all you “performing” …?

*💬 Reply*

**960.** `23:17` **Meredith Lamb (+14169386001)**

>
Don’t ChatGPT

*💬 Reply*

**961.** `23:18` **Meredith Lamb (+14169386001)**

lol


**962.** `23:18` **You**

That's a beautiful place to be — when two people feel deeply connected, trust each other, and are open to exploration\. The phrase \*“there is so much more than intercourse”\* speaks to a broader, richer experience of intimacy that goes beyond just penetration\. It sounds like your partner is expressing a desire to deepen your sensual connection and explore the full spectrum of pleasure, which can actually heighten the experience of sex as a whole\.
Here’s how to think about this:
\#\#\# 1\. \*\*Emotional and Erotic Intimacy\*\*
When partners feel safe and deeply connected, the possibilities for exploration multiply\. Intimacy can involve:
\* Prolonged eye contact
\* Emotional vulnerability
\* Non\-verbal communication
\* Playfulness and shared fantasies
This emotional groundwork can make physical intimacy feel more profound and satisfying\.
\#\#\# 2\. \*\*Sensual Touch and Body Worship\*\*
Exploring each other's bodies without a goal of climax or penetration can lead to incredible discoveries\. Try:
\* Sensate focus: slow, mindful touching
\* Body mapping: learning which areas bring pleasure
\* Massage, oil play, or even bathing each other
\#\#\# 3\. \*\*Erotic Play and Kink Exploration\*\*
Being adventurous could include experimenting with:
\* Light bondage or restraint \(e\.g\., silk scarves, handcuffs\)
\* Sensory play \(feathers, temperature play, blindfolds\)
\* Role play or fantasy exploration
This doesn't have to be extreme — even mild forms of exploration can be thrilling when trust is strong\.
\#\#\# 4\. \*\*Oral, Manual, and Mutual Pleasure\*\*
Spending more time on oral sex, mutual masturbation, or simply pleasuring one another without rushing to intercourse can allow both partners to focus on each other’s needs in new ways\.
\#\#\# 5\. \*\*Tantra and Energy Connection\*\*
Practices like tantric sex emphasize presence, breathing, and slow, conscious touch\. It can enhance emotional and physical intimacy by shifting focus from performance to connection\.
Would you like ideas or specific techniques to start exploring this together — or perhaps ways to bring up deeper conversations about your desires and boundaries?


**963.** `23:18` **You**

there you go


**964.** `23:18` **You**

100% I was going to do that


**965.** `23:19` **You**

Reaction: 😂 from Meredith Lamb
you knew it too\.\.\. lol


**966.** `23:19` **You**

>
I don't understand this statement\.\. sorry\.\.

*💬 Reply*

**967.** `23:21` **Meredith Lamb (+14169386001)**

I think \(and may be wrong\) that you used to worry about performing during sex\.


**968.** `23:21` **Meredith Lamb (+14169386001)**

Rather than actually connecting


**969.** `23:21` **You**

>
if by used to you mean currently and forever more then yes\.\. nailed it\.

*💬 Reply*

**970.** `23:21` **You**

lol


**971.** `23:22` **Meredith Lamb (+14169386001)**

You don’t worry about performing for me tho?


**972.** `23:22` **You**

but you read the other stuff right\.\.


**973.** `23:22` **You**

the earlier stuff\.\. because that is relevant too\.


**974.** `23:22` **Meredith Lamb (+14169386001)**

>
What earlier stuff exactly lol

*💬 Reply*

**975.** `23:23` **You**

>
this and

*💬 Reply*

**976.** `23:23` **You**

>
this

*💬 Reply*

**977.** `23:23` **You**

>
and that second one should answer this\.

*💬 Reply*

**978.** `23:23` **You**

lol


**979.** `23:24` **Meredith Lamb (+14169386001)**

>
Why did you feel bad?

*💬 Reply*

**980.** `23:23` **You**

I told you\.\. I am a pleaser\.\. that is basically who I am\.


**981.** `23:24` **You**

>
because I didn't feel the connection the same way\.\. I mean I enjoyed\.\. it \.\. most of it\.\. some was fucking wierd and some I was like nope nope nope\.\.

*💬 Reply*

**982.** `23:24` **Meredith Lamb (+14169386001)**

>
Am I still hard to read?

*💬 Reply*

**983.** `23:24` **You**

Reaction: ❓ from Meredith Lamb
yes


**984.** `23:25` **Meredith Lamb (+14169386001)**

>
I’m sure other ppl couldn’t have formed connections at that point

*💬 Reply*

**985.** `23:25` **Meredith Lamb (+14169386001)**

Same on both sides


**986.** `23:25` **You**

it's fine\.\. I feel you love me, and i feel you are happy\.\. so I kind of go with that\.\. but I think you understand what I am saying\.\.


**987.** `23:25` **Meredith Lamb (+14169386001)**

>
I don’t believe this\.

*💬 Reply*

**988.** `23:26` **You**

>
mmm they weren't looking for connections  and yes you are\.

*💬 Reply*

**989.** `23:26` **Meredith Lamb (+14169386001)**

>
“It’s fine\.\.” LOL is it?

*💬 Reply*

**990.** `23:26` **You**

Reaction: 😂 from Meredith Lamb
I am saying I can read the love and happiness\.\.


**991.** `23:26` **Meredith Lamb (+14169386001)**

>
Yeah but I had my situations many yrs ago where I was not\.

*💬 Reply*

**992.** `23:27` **You**

>
I mean I don't judge to each their own\.

*💬 Reply*

**993.** `23:28` **You**

Like\.\. I dunno\.\. for me it was all about making the other person happy\.\. I don't know how to explain it\.\. that is just how I work\.\. it didn't matter if it was 1 year or 1 night\.  And I never treated anyone like well\.\. like they didn't matter\.


**994.** `23:28` **You**

I think it surprised a lot of people\.


**995.** `23:30` **You**

I really hope nothing I am saying bothers you\.\.


**996.** `23:30` **You**

this is a pretty honest conversation


**997.** `23:30` **You**

lol


**998.** `23:30` **You**

but when don't we


**999.** `23:31` **You**

hehe


**1000.** `23:31` **Meredith Lamb (+14169386001)**

Not at all\. But I think you can make someone else happy and let them make you happy\.


**1001.** `23:32` **You**

>
But I am happy when they are happy\.\. I let you do "stuff" lol and I never let my wife do that in 25 years\.\. so I mean\.\. I am open to it\.\. I cannot help being polite though\.

*💬 Reply*

**1002.** `23:32` **You**

the tap on the shoulder etc\.\. LOL


**1003.** `23:34` **Meredith Lamb (+14169386001)**

So you don’t like it? 🤔


**1004.** `23:34` **You**

but hey I am interested in whatever you are interested in\.\.  Mer I have done pretty much everything\.\. from whatever they fuck idea someone has\.\. to public, very public, to dangerous\.\. like holy fuck dangerous\.\.  so I am not like an "innocent" I just feel certain ways about certain things\. And honestly the high I get, especially well at the end\.\. being with you loving you this much\.\. jesus better than anything ever\.


**1005.** `23:35` **You**

lol no you need to read what I just wrote first\.\. of course I like it\.\. of course I was up for almost anything, any time, dares it didn't matter\.\. but fundamentally my motivation was the same\.


**1006.** `23:35` **You**

let's do this\.\.


**1007.** `23:36` **Meredith Lamb (+14169386001)**

You are weird


**1008.** `23:36` **You**

tell me what you want to do\.\.


**1009.** `23:36` **You**

you want honesty


**1010.** `23:36` **Meredith Lamb (+14169386001)**

So what was your reasoning to Jaimie for being so closed off


**1011.** `23:36` **You**

tell me what you would like\.\. and we will make it happen\.


**1012.** `23:36` **You**

why i was closed off to her


**1013.** `23:36` **Meredith Lamb (+14169386001)**

Well you said you didn’t let her do things


**1014.** `23:37` **Meredith Lamb (+14169386001)**

I think that is closed off\. Not sure


**1015.** `23:37` **You**

well there wasn't a connection for one\.\. I didn't want her to\.\. I am not sure how to explain why\.\. but I didn't, and she didn't have any experience in that respect anyways as I understood it\.


**1016.** `23:37` **You**

We never talked about this\.


**1017.** `23:38` **You**

I tried a few times early on but she wouldn't


**1018.** `23:38` **Meredith Lamb (+14169386001)**

Ok…\.


**1019.** `23:39` **Meredith Lamb (+14169386001)**

Processing


**1020.** `23:38` **You**

>
having a hard time following where you are going\.\. lol you are circling

*💬 Reply*

**1021.** `23:40` **You**

Cmon mer\.\. you have dug enough\.\. time for you to circle back \- tell me what brought the question on\.\. or the suggestion or confession I guess you called it\.\.  let's start with that\.


**1022.** `23:40` **You**

Reaction: 😂 from Meredith Lamb
then I am going to start asking you the questions\.\. lol


**1023.** `23:42` **Meredith Lamb (+14169386001)**

Sorry girls called


**1024.** `23:42` **Meredith Lamb (+14169386001)**

Back


**1025.** `23:42` **You**

ok\.\. read last two from me\.


**1026.** `23:42` **You**

then you get to answer some questions


**1027.** `23:43` **Meredith Lamb (+14169386001)**

>
Sure\.

*💬 Reply*

**1028.** `23:43` **You**

no\.\.\.\.\.


**1029.** `23:43` **You**

>
this one first

*💬 Reply*

**1030.** `23:43` **Meredith Lamb (+14169386001)**

>
I am circling\. You should go to bed for gym

*💬 Reply*

**1031.** `23:43` **You**

Reaction: 😂 from Meredith Lamb
HAHAHA


**1032.** `23:43` **You**

way past my bedtime


**1033.** `23:44` **You**

just pushing gym forward\.


**1034.** `23:44` **Meredith Lamb (+14169386001)**

It totally is


**1035.** `23:44` **You**

don't worry about it\.


**1036.** `23:44` **Meredith Lamb (+14169386001)**

\(Not worried\)


**1037.** `23:45` **You**

ok\.\. so\.\. to my question above\.\.


**1038.** `23:45` **You**

it wasn't just the wine talking :\)  what prompted the question\.


**1039.** `23:45` **You**

or confession or whatever


**1040.** `23:46` **Meredith Lamb (+14169386001)**

Am I going to regret this tomorrow


**1041.** `23:46` **You**

I doubt it


**1042.** `23:46` **Meredith Lamb (+14169386001)**

😒


**1043.** `23:46` **You**

but you started it


**1044.** `23:46` **You**

and I was honest\.\.


**1045.** `23:46` **You**

and you kept digging\.\. so now it is my turn


**1046.** `23:46` **Meredith Lamb (+14169386001)**

I’ve been honest also


**1047.** `23:47` **You**

yeah\.\. but mostly questions\.\. and I haven't probed any of your answers\.


**1048.** `23:47` **You**

>
like this one

*💬 Reply*

**1049.** `23:48` **You**

>
I kind of felt these were one and the same\.\. but my ultimate goal\.\. let's say one way or the other was for the other person to be "happy"

*💬 Reply*

**1050.** `23:48` **You**

ok\.\.


**1051.** `23:48` **You**

so no more from me\.\. only answers from you\.\. if you want I can itemize and list the questions again


**1052.** `23:48` **Meredith Lamb (+14169386001)**

>
I mean, your POV

*💬 Reply*

**1053.** `23:49` **You**

yep


**1054.** `23:49` **Meredith Lamb (+14169386001)**

>
I mean I’m unlikely to address anything unless directly asked or I feel like it\. Lol

*💬 Reply*

**1055.** `23:49` **You**

really\.\. is that how it is\.


**1056.** `23:50` **Meredith Lamb (+14169386001)**

>
You had a one night stand to make the other person happy? 🤔

*💬 Reply*

**1057.** `23:51` **Meredith Lamb (+14169386001)**

>
I’m just saying I go with the flow

*💬 Reply*

**1058.** `23:51` **You**

Reaction: 🙂 from Meredith Lamb
>
>
>
ok this was where this started\.\. or we could go back and discuss Big Men again\. :\)

*💬 Reply*

**1059.** `23:51` **You**

>
No

*💬 Reply*

**1060.** `23:52` **You**

I had a one night stand\.\. and in the process of that\.\. my goal was always to make the other person happy\.\. invariably I was degrees of happy\.\. I guess\.\. the connection wasn't there so it was different\.


**1061.** `23:52` **You**

And like I said it was generally unexpected\.


**1062.** `23:53` **You**

ok I will not be deterred\!\!\! lol


**1063.** `23:53` **Meredith Lamb (+14169386001)**

lol


**1064.** `23:53` **Meredith Lamb (+14169386001)**

I was just listening…\.


**1065.** `23:53` **You**

What brought us down this path Mer\.


**1066.** `23:54` **You**

You might be surprised with how I respond if you are at all concerned\.


**1067.** `23:55` **Meredith Lamb (+14169386001)**

>
I think I just like you and was … sigh I dunno

*💬 Reply*

**1068.** `23:55` **Meredith Lamb (+14169386001)**

>
Concerned?

*💬 Reply*

**1069.** `23:56` **You**

Reaction: ❤️ from Meredith Lamb
>
I thought you might be worried I wouldn't be open to it\.\. so let's clear this up\.\. I am up for anything with you Mer\.\. because it is you\.\. and because I love you that much, and because I am happy to go on any adventure with you\.

*💬 Reply*

**1070.** `23:56` **You**

>
so back to this\.\.

*💬 Reply*

**1071.** `23:56` **You**

can you expand?


**1072.** `23:56` **You**

lol


**1073.** `23:57` **You**

Reaction: 🙃 from Meredith Lamb
ask chatgpt maybe on how to be more articulate?


