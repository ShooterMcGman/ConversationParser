# Daily Conversation: 2025-04-29 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-29 |
| **Day** | Tuesday |
| **Week** | 3 |
| **Messages** | 89 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-29T00:29 - 2025-04-29T21:07 |

## 📝 Daily Summary

This day contains **89 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**002.** `01:10` **You**

Night mer you def are my home ❤️ love you xoxo\.


**003.** `01:14` **Meredith Lamb (+14169386001)**

🏡❤️ Amazing unforgettable night…\.\. love you


**004.** `07:43` **You**

Ur damn right it was the whole weekend was I will never forget this weekend\.   I love you mer\.  God help me through this next phase\.


**005.** `07:49` **Meredith Lamb (+14169386001)**

God help “us”…\.


**006.** `07:49` **Meredith Lamb (+14169386001)**

lol


**007.** `08:02` **Meredith Lamb (+14169386001)**

Ps\. I know you think it was “irresponsible” or whatever but I was just so focused on having you completely … honestly can’t stop thinking about it\. Will be an interesting day\. Lol xo hope you made it to your meeting on time\! Xoxoxox


**008.** `08:05` **You**

Reaction: ❤️ from Meredith Lamb
I am leaving now will see how that goes\.   I wanted the same\.\. that is what I was debating\.  I just wanted to be with you in the same way\.  ❤️ this whole level of emotions is quite overwhelming for me but so much in a good way\.  Love you\!\!\!


**009.** `08:05` **You**

Too many firsts for me at this age\.


**010.** `09:02` **Meredith Lamb (+14169386001)**

Erin just told me about the rollover\. I didn’t even reach out\. She is so deflated\. Needed to vent\.


**011.** `10:03` **You**

Yeah I am messaging the sup group\.


**012.** `10:54` **You**

Going to Leave after my lunch not staying this afternoon very tired will tell you more about this process later\.


**013.** `10:56` **Meredith Lamb (+14169386001)**

I’m just in caf with other Scott


**014.** `11:01` **You**

Cool hope you are having fun\.


**015.** `11:01` **You**

You of course are
Welcome to join us for lunch just my team and Octavian but I suspect
You will want to get
Back in the road\.


**016.** `11:17` **Meredith Lamb (+14169386001)**

Yeah we are just finishing up


**017.** `11:17` **Meredith Lamb (+14169386001)**

He’s got a meeting and I need to get Mac by 12


**018.** `11:17` **Meredith Lamb (+14169386001)**

Checkout time


**019.** `11:18` **Meredith Lamb (+14169386001)**

I got some good separation tips


**020.** `11:18` **Meredith Lamb (+14169386001)**

lol


**021.** `11:41` **You**

lol just finished my meeting also had a conversation with Ian felt it was time to tell him about my separation\.  He was very empathetic\.


**022.** `11:59` **Meredith Lamb (+14169386001)**

Oh wow


**023.** `11:59` **Meredith Lamb (+14169386001)**

That is good to hear\. We just bought dog sitter gift and are leaving\. Not going to Glencoe\. Too tired and want to do some work / emails at home


**024.** `12:00` **You**

Safe drive mer will chat at
You later ❤️


**025.** `12:40` **Meredith Lamb (+14169386001)**

At the Dutton on route\. My first job :P


**026.** `12:41` **Meredith Lamb (+14169386001)**

I should probably think about telling my manager about my separation too\.


**027.** `13:19` **You**

Might not be a bad idea that is probably something he should be aware of\.  😝


**028.** `13:19` **You**

Just finished lunch about to go fill up and get on the road\.\. it is getting windy here\.


**029.** `14:03` **You**

J is back to wanting to move back to Moncton before end of summer now


**030.** `14:03` **You**

Going to chat tonight


**031.** `14:33` **Meredith Lamb (+14169386001)**

Whip lash\. I told you lol


**032.** `14:49` **You**

I mean yeah but I would be happier with that


**033.** `14:53` **You**

You must almost be home


**034.** `14:57` **Meredith Lamb (+14169386001)**

Yep\! Getting dogs first


**035.** `15:00` **Meredith Lamb (+14169386001)**

Marlowe won first game so just getting ready for QF 😬


**036.** `15:01` **You**

Wow excitement\!\!\! Bout 1\.5 hours out from home now…


**037.** `15:01` **You**

Gym tonight lol


**038.** `15:03` **You**

Back to the grind


**039.** `15:14` **Meredith Lamb (+14169386001)**

Just driving Mac to gym now 🙄 chauffeuring continues


**040.** `15:16` **You**

Geese


**041.** `15:16` **You**

Geeze


**042.** `15:16` **You**

Fun never stops


**043.** `15:16` **You**

I need to start cleaning and fixing house at a rapid pace


**044.** `15:17` **You**

Because no one else will going to need to focus


**045.** `15:17` **Meredith Lamb (+14169386001)**

Reality 🙃


**046.** `15:18` **You**

Means to an end\.


**047.** `15:26` **Meredith Lamb (+14169386001)**

Yeah I have so much to do also\.


**048.** `15:34` **You**

Yeah I guess you have a tough week ahead of you too


**049.** `15:55` **Meredith Lamb (+14169386001)**

On my way home finally

*📎 1 attachment(s)*

**050.** `15:57` **You**

Going to doctor


**051.** `15:57` **You**

Cute pups bet you glad to be with them again


**052.** `16:45` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**053.** `16:46` **Meredith Lamb (+14169386001)**

>
Doctor??

*💬 Reply*

**054.** `16:59` **You**

Tough break but they had a good run\.

*💬 Reply*

**055.** `17:01` **Meredith Lamb (+14169386001)**

Why did you say “going to doctor”?


**056.** `17:09` **You**

I had to take over Gracie’s appointment because she wouldn’t go…\. Again… I had to go see him anyways\.\. just some stuff,
Nothing for you to worry about\.


**057.** `17:13` **Meredith Lamb (+14169386001)**

Oh kk thought something might be wrong


**058.** `17:14` **You**

Well we are
Old there is always something “wrong”


**059.** `17:15` **You**

Anyways it doesn’t help not having a paternal history… Fack\.


**060.** `17:20` **You**

Not much more I can do anyways\.\.
BP related, trying to get off that\.\. he is hesitant\.\. something about some potential tests\.\. I have to track a bunch of stuf for the next little while\.


**061.** `17:42` **Meredith Lamb (+14169386001)**

High BP?


**062.** `17:45` **Meredith Lamb (+14169386001)**

My niece … gah\. I never told her\. My sis obviously did

*📎 1 attachment(s)*

**063.** `17:58` **You**

I love how much support you are getting it must make things  little easier\.


**064.** `17:58` **You**

>
Yeah, pretty much\.

*💬 Reply*

**065.** `18:03` **Meredith Lamb (+14169386001)**

My low bp will even you out :\)


**066.** `18:07` **You**

Not sure that is how it works


**067.** `18:08` **Meredith Lamb (+14169386001)**

lol


**068.** `18:08` **Meredith Lamb (+14169386001)**

I mean it can’t hurt


**069.** `18:26` **You**

Nah I got shot
To take care
If I am not happy with where I am at\.\. there stuff that isn’t right and it needs to be addressed\.  Like I said don’t worry about it, just something I will need to deal with\.


**070.** `18:31` **Meredith Lamb (+14169386001)**

My mom has always had high bp\.
Our power was out for hours and just came back on phewwww going to do some work now


**071.** `19:19` **You**

Kkk have fun whiplash all over the place here we’re staying we’re going can we work something out where I buy you out of the house but can still afford to stay\.\. to which I said no\.\. I would need to give a lot more and that would be well beyond reasonable Gracie still refuses to go what a fucking shit show\.


**072.** `19:26` **Meredith Lamb (+14169386001)**

Total shit show\. My crew is on the way home and not looking forward to arrival\. Ugh\.


**073.** `19:56` **You**

What are you predicting I thought you and Andrew had reached an accommodation or is there whiplash there too?


**074.** `19:56` **Meredith Lamb (+14169386001)**

Sorry accident


**075.** `19:56` **Meredith Lamb (+14169386001)**

I don’t think I can predict at this point\.


**076.** `19:57` **Meredith Lamb (+14169386001)**

I’d just like to go to a mediator now so hoping he will be receptive to that\.


**077.** `19:57` **Meredith Lamb (+14169386001)**

We haven’t talked all weekend


**078.** `19:57` **Meredith Lamb (+14169386001)**

Since night before I left


**079.** `19:57` **Meredith Lamb (+14169386001)**

It’s been lovely\.


**080.** `20:24` **You**

Reaction: ❤️ from Meredith Lamb
If things get bad mer think about the slow dance think about the fact that someone loves you so much you are home to them\. Think about all of that and then think somewhere down the road, we get to have that\.  That is what I am holding onto here\.


**081.** `20:28` **Meredith Lamb (+14169386001)**

Today is definitely a bit of an adjustment\. Quite the rollercoaster we are on…


**082.** `20:32` **You**

Yeah I know but at least we are on it together\.


**083.** `20:34` **You**

I am heading to the gym can you please
Let me know you are ok tonight\.\. I worry that all the stuff he would be thinking about this weekend will hit you like a truck\.


**084.** `20:35` **You**

Gracie had a meltdown here\.\. she wants to stay I basically said I am selling the house one way or the other\.
Which is really what she is trying to control she cannot deal with any change\.  She thinks she is ready for university
But she is not\.\. this will be tough but I still hope she can make it back to Moncton I will have to fly up regularly I suspect but she will do better there\.


**085.** `20:37` **Meredith Lamb (+14169386001)**

That sounds very difficult for her for sure\. Not easy\.
I can msg later but I might go to bed early and then I don’t have to talk to him\. lol


**086.** `20:38` **You**

Ok :\( well please let
Me know you are ok I am really worried\. I will leave you be, going to get my shit and go in and try to work off everything I am feeling\.


**087.** `20:42` **Meredith Lamb (+14169386001)**

I will be good\. The missing you will be worse than anything here\.


**088.** `20:59` **You**

😞


**089.** `21:07` **You**

Uggh


