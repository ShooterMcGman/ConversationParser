# Daily Conversation: 2025-04-17 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-17 |
| **Day** | Thursday |
| **Week** | 1 |
| **Messages** | 100 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-17T01:56 - 2025-04-17T21:36 |

## 📝 Daily Summary

This day contains **100 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `travel`, `food`

## 💬 Messages

**001.** `01:56` **You**

Fack just getting to bed now another mean fight… fucking tired cannot say I didn’t fight back tonight which is probably why it lasted so long\. Anyhow nite xoxo will try to get in a bit early to see you\.


**002.** `06:35` **Meredith Lamb (+14169386001)**

Omg sleep in\. I have a meeting at 9 and Erin wants to have morning chat before at some point\. xo


**003.** `07:29` **You**

I am already up big fight apparently Gracie got into my chat gpt and saw something about the gym and a coffee shop\.  So I had to admit that I had a conversation with someone at the gym and that I was thinking about actually asking them to grab a coffee\.  Obviously that is about you,  if I wasn’t saying that\.  Anyone not a massive explosion but a lot of
Guilt and bullshit being thrown around\.  I basically said I am just going to accelerate my timeline to leave\.   Very frustrated
Drained and tired today\.  Leaving in a few don’t worry you focus on work today all good\.  Have a good one\! ❤️


**004.** `07:43` **Meredith Lamb (+14169386001)**

Eeek\.


**005.** `07:44` **Meredith Lamb (+14169386001)**

I am so drained also\. Andrew pissed me off last night\. Talk later\.


**006.** `07:45` **Meredith Lamb (+14169386001)**

Sounds like you have a sleuth on your hands\. 🙈


**007.** `07:51` **You**

Yeah I think I defused\.


**008.** `08:21` **Meredith Lamb (+14169386001)**

I am curious what else was in your ChatGPT 😬


**009.** `08:25` **You**

Nothing or I would have heard about it


**010.** `08:25` **You**

And I didn’t


**011.** `08:25` **You**

I am going back through today and deleting everything if there is anything it will be gone\.


**012.** `08:31` **You**

We fought again since 6 am just in car now it think everything is sorted but man I am just… I don’t want to work… but no choices today\.


**013.** `09:03` **Meredith Lamb (+14169386001)**

Draining\. Sorry\.


**014.** `09:04` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
It’s so challenging\. Just talked to Erin\. \(I had already told her\.\.\) She called me bold\. lol


**015.** `09:08` **You**

I mean the more support you can get the better you will feel\.


**016.** `09:13` **Meredith Lamb (+14169386001)**

Yeah, especially after my scolding last night\. I essentially got in trouble for not having our finances exactly figured out and blamed for that so now he says he can’t do the Julian/cassy thing bc of me\. When it isn’t bc of me\. He just likes to blame me\. I told him he was scolding me and he said his voice wasn’t raised so how could he be scolding? Omg\. Then he wouldn’t leave\. Gahhhh


**017.** `09:14` **You**

Yeah I was honestly worried when you mentioned not respecting your boundaries\.\.


**018.** `09:18` **Meredith Lamb (+14169386001)**

He just wouldn’t leave despite my practical begging\. I need to get out faster but we have this damn cottage thing\.


**019.** `09:19` **You**

>
Yeah it sucks mer I wish I had a solution for you\.\. 🙁

*💬 Reply*

**020.** `12:40` **Meredith Lamb (+14169386001)**

Looking at a new spreadsheet for proposed division of assets that includes a $30k engagement ring\. Lol


**021.** `13:02` **You**

I mean a gift is not supposed to be considered I think that way\.


**022.** `13:02` **You**

I feel like that is lame


**023.** `13:02` **You**

Nickel and dining


**024.** `13:02` **You**

Diming


**025.** `13:12` **Meredith Lamb (+14169386001)**

I said I don’t want it anyway\. He can have it\. :p


**026.** `14:13` **You**

lol


**027.** `15:42` **You**

:\( long day


**028.** `15:54` **You**

We still on for tonight or too much reality for you lol\.


**029.** `15:59` **Meredith Lamb (+14169386001)**

I am if you are :\)


**030.** `16:02` **You**

I was hoping you were


**031.** `16:04` **Meredith Lamb (+14169386001)**

But are you going to be too tired?


**032.** `16:04` **Meredith Lamb (+14169386001)**

And is your daughter going to follow you?


**033.** `16:04` **Meredith Lamb (+14169386001)**

lol


**034.** `16:04` **You**

I refused to turn it back on


**035.** `16:05` **You**

I don’t know when you are available but I might go to the gym early


**036.** `16:05` **You**

If you are going to gto be a bit


**037.** `16:08` **Meredith Lamb (+14169386001)**

Carolyn isn’t sure whether to wait for you so ping her


**038.** `16:08` **Meredith Lamb (+14169386001)**

I’m leaving\!


**039.** `16:09` **You**

Yeah head out tell her too


**040.** `16:09` **You**

I will work tomorrow


**041.** `16:09` **You**

Pls


**042.** `16:09` **Meredith Lamb (+14169386001)**

I need to go home and then get Mac and stuff … will then be heading to Oshawa


**043.** `16:11` **You**

Kk well I will go home eat and straight to gym my plan is to stay there all night officially because I am cancelling it soon\.


**044.** `16:12` **You**

Might we be able to drive your vehicle wherever we go however?


**045.** `16:25` **Meredith Lamb (+14169386001)**

>
That’s fine, we can go to my mom’s basement\. Not tonight \- nephew still there\.

*💬 Reply*

**046.** `16:25` **Meredith Lamb (+14169386001)**

>
lol yeah

*💬 Reply*

**047.** `16:25` **You**

>
Man… don’t tease me\.

*💬 Reply*

**048.** `16:26` **You**

>
Thx

*💬 Reply*

**049.** `16:38` **Meredith Lamb (+14169386001)**

Can’t get away from Michelle


**050.** `16:39` **Meredith Lamb (+14169386001)**

lol


**051.** `16:42` **You**

Cote is all over everything she needs to calm down and stay at her desk sometimes\.


**052.** `16:50` **Meredith Lamb (+14169386001)**

Wow can she ever talk lol


**053.** `16:51` **You**

Leaving


**054.** `17:38` **Meredith Lamb (+14169386001)**

Omg traffic is so bad


**055.** `17:38` **Meredith Lamb (+14169386001)**

I need to do some packing here and eat and get Mac/dogs ready


**056.** `17:39` **Meredith Lamb (+14169386001)**

I might not actually get there until 7\.30… too late? Plus Mac wants me to take her to Walmart ugh


**057.** `17:44` **You**

I am going to workout anyways first I will take whatever time we can get mer but it is up to you a lot of running around for you\. Only if it isn’t too much trouble for you


**058.** `17:44` **Meredith Lamb (+14169386001)**

It’s fine just the later the better


**059.** `17:44` **You**

I only just got to my subdivision now


**060.** `17:45` **Meredith Lamb (+14169386001)**

I will keep you updated


**061.** `17:45` **You**

Ok like I said going to go eat then gym then whenever you are ready to come I will hit the shower and come out or whatever works for you


**062.** `17:46` **Meredith Lamb (+14169386001)**

So later is fine?


**063.** `17:46` **You**

Sure all good


**064.** `17:46` **Meredith Lamb (+14169386001)**

I don’t want you to get in trouble\!\!


**065.** `17:47` **You**

I won’t but I won’t see you again for like more than a week


**066.** `17:47` **You**

God I sound like a fucking 15 year old


**067.** `17:47` **Meredith Lamb (+14169386001)**

>
I knoooooooow sucks

*💬 Reply*

**068.** `17:48` **Meredith Lamb (+14169386001)**

Today was a little challenging sitting in meetings with you


**069.** `17:48` **You**

Yeah I was in a bad mood I am sorry


**070.** `17:49` **You**

I have bad days too


**071.** `17:49` **Meredith Lamb (+14169386001)**

That wasn’t the challenge\.


**072.** `17:51` **You**

Well other than feel the overwhelming urge to just be somewhere else with you\.\. nothing nasty just together\.\. yeah I thought about it all day but I got work done


**073.** `17:51` **You**

I just want to fast forward……


**074.** `17:54` **Meredith Lamb (+14169386001)**

Same\.


**075.** `17:55` **Meredith Lamb (+14169386001)**

k, I gotta pack up stuff and get going\!


**076.** `17:55` **Meredith Lamb (+14169386001)**

Xo


**077.** `17:57` **You**

Kk xo see
You later


**078.** `18:46` **Meredith Lamb (+14169386001)**

Phew we are just leaving TO


**079.** `19:15` **You**

Kk I suspect you are still going to be a while yet going to hit gym for a quick let me know when you want to connect\. I can stay as long or as little as you need\.


**080.** `19:20` **Meredith Lamb (+14169386001)**

Probably won’t be done Walmart and at my moms until 8\.45 😬


**081.** `19:29` **You**

Kk


**082.** `19:52` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**083.** `19:52` **Meredith Lamb (+14169386001)**

Help


**084.** `19:52` **Meredith Lamb (+14169386001)**

Just arriving at Walmart


**085.** `19:52` **You**

ROFL


**086.** `19:53` **You**

lol just arriving at gym


**087.** `19:53` **You**

You can call me on this app if you want when you leaving to come here


**088.** `19:54` **You**

She is so funny lol


**089.** `20:03` **Meredith Lamb (+14169386001)**

The traffic in this area makes Yonge and Eg seem light\. Holy


**090.** `20:04` **You**

It was really bad getting home tonight


**091.** `20:42` **Meredith Lamb (+14169386001)**

Ok so it will take me 20 min to drive to your gym\. Just let me know when a good time to leave is… can leave whenever\.


**092.** `20:43` **You**

Reaction: 👍 from Meredith Lamb
Give me 5 to finish up last excercise then I down to showe will message you when I am going down and you can leave then if you are ready


**093.** `20:51` **You**

I am done


**094.** `20:51` **You**

Downstairs now


**095.** `20:53` **You**

Going to hop in shower so you don’t need to wait to hear back should be out in around 20


**096.** `21:00` **Meredith Lamb (+14169386001)**

Omg my dogs ran away lol my mom doesn’t have a fence\. Just had a run with Mackenzie\. Geez


**097.** `21:00` **Meredith Lamb (+14169386001)**

On my way


**098.** `21:18` **You**

Rofl


**099.** `21:24` **Meredith Lamb (+14169386001)**

k, I am here


**100.** `21:36` **You**

Sry brt


