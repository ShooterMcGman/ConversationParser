# Daily Conversation: 2025-04-16 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-16 |
| **Day** | Wednesday |
| **Week** | 1 |
| **Messages** | 280 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-16T00:00 - 2025-04-16T22:34 |

## 📝 Daily Summary

This day contains **280 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

Sorry had to feed puppy


**002.** `00:01` **You**

Not desparte just I think fulfilled differently\. I mean in some ways\.  Companionship and compatibility mean so much more I think\.


**003.** `00:02` **Meredith Lamb (+14169386001)**

Wait, you’re digging a hole\. Mean so much more than what? Lol


**004.** `00:03` **You**



**005.** `00:03` **You**

Wrf


**006.** `00:03` **Meredith Lamb (+14169386001)**

lol


**007.** `00:03` **You**

lol


**008.** `00:03` **You**

I mean more than when we were younger


**009.** `00:04` **You**

Not more than what you are
Thinking naughty naughty


**010.** `00:04` **You**

But I think you get the gist


**011.** `00:05` **Meredith Lamb (+14169386001)**

Not thinking anything just reading 😇


**012.** `00:05` **You**

Yeah bossy mogul is it a good read


**013.** `00:05` **You**

Or ChatGPT answering some questions


**014.** `00:06` **Meredith Lamb (+14169386001)**

I meant reading your messages


**015.** `00:06` **Meredith Lamb (+14169386001)**

I still need to google bossy mogul


**016.** `00:07` **You**

Which messages?  So many now


**017.** `00:07` **Meredith Lamb (+14169386001)**

https://search\.app/iHw2Gxr4Lgha9t3Z9


**018.** `00:07` **Meredith Lamb (+14169386001)**

I think you might be the bossy mogul


**019.** `00:07` **Meredith Lamb (+14169386001)**

Sorry


**020.** `00:07` **Meredith Lamb (+14169386001)**

lol


**021.** `00:08` **You**

>
And if you have questions ask you don’t need to try to guess unless that is part of the fun\.

*💬 Reply*

**022.** `00:09` **You**

ROFL\. No I am not lol\.  My voice is t that deep


**023.** `00:09` **Meredith Lamb (+14169386001)**

I mean READ THE SUMMARY


**024.** `00:09` **You**

I did lol


**025.** `00:09` **You**

Elevator moves


**026.** `00:09` **You**

Etc etc


**027.** `00:09` **Meredith Lamb (+14169386001)**

LOL


**028.** `00:10` **Meredith Lamb (+14169386001)**

My mom totally read all that shit


**029.** `00:10` **Meredith Lamb (+14169386001)**

I never understood it\. So funny


**030.** `00:10` **You**

I feel like you are going to Remeber this and there will be an elevator some alcohol and a role play involved in my future


**031.** `00:10` **Meredith Lamb (+14169386001)**

It’s much better living it in real life


**032.** `00:10` **Meredith Lamb (+14169386001)**

lol


**033.** `00:11` **Meredith Lamb (+14169386001)**

>
I mean a couple weeks

*💬 Reply*

**034.** `00:11` **You**

Substitute elevator for backseat
Of
Rental
Car


**035.** `00:11` **You**

So much classier


**036.** `00:11` **You**

lol


**037.** `00:11` **Meredith Lamb (+14169386001)**

I don’t think the bossy mogul cares about classy


**038.** `00:12` **You**

That is officially our first date forever back seat of dental
Car \- how so many classic romances over the years have started


**039.** `00:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I kind of consider the rc show the first


**040.** `00:12` **Meredith Lamb (+14169386001)**

Rental car second


**041.** `00:13` **Meredith Lamb (+14169386001)**

Both full of surprises \(per\)


**042.** `00:13` **You**

Reaction: ❤️ from Meredith Lamb
“Hey babd how about we hop in the back of my Tiguan and watch some T2 and see where this goes”, he says hopefully\.


**043.** `00:14` **You**

Yeah fair enough


**044.** `00:14` **You**

lol


**045.** `00:15` **Meredith Lamb (+14169386001)**

I mean you cannot go wrong with T2\.


**046.** `00:15` **Meredith Lamb (+14169386001)**

It was a smooth move\.


**047.** `00:15` **You**

It sure got the job done\!\!


**048.** `00:15` **You**

Hehe


**049.** `00:15` **You**

I thought soo hard about what to do that night


**050.** `00:16` **Meredith Lamb (+14169386001)**

So funny, we could have just walked around


**051.** `00:16` **You**

Wouldn’t have been as fun though


**052.** `00:16` **You**

Well would have been nice
Don’t get me wrong


**053.** `00:17` **You**

But with all the banter we had and inuendos I was curious\.


**054.** `00:17` **Meredith Lamb (+14169386001)**

I am glad you were lol


**055.** `00:18` **You**

Ok I am pretty wiped I am glad we could end the day with each other even if virtually


**056.** `00:19` **You**

Deleted


**057.** `00:19` **Meredith Lamb (+14169386001)**

Same\. So exhausted yet so glad to chat


**058.** `00:19` **You**

You are more careful than I am you know that right and I am
The Virgo


**059.** `00:20` **Meredith Lamb (+14169386001)**

Yes I am very careful … self preservation


**060.** `00:20` **You**

Luv luv … night xoxoxoxo you don’t need to be what more is there?


**061.** `00:21` **Meredith Lamb (+14169386001)**

>
Such a loaded question\. Lol nite ❤️

*💬 Reply*

**062.** `00:22` **You**

Yeah leave me hanging ok\.\. I see how it is\.  Turnaround is fair play\.


**063.** `00:22` **You**

❤️


**064.** `00:22` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Detroit :\)


**065.** `07:09` **You**

❤️


**066.** `07:24` **Meredith Lamb (+14169386001)**

Morning \- rushing off to sick kids blood clinic for girls to get bloodwork they need\. :p hopefully won’t take very long\.


**067.** `07:33` **You**

Hope they ok\.


**068.** `07:34` **Meredith Lamb (+14169386001)**

Yeah all fine


**069.** `07:49` **Meredith Lamb (+14169386001)**

I have a dna gene variant that can cause blood clotting so in order for my girls to go on birth control we need to know if they have it\. That’s all\. :p Annoying\. And only sick kids does the dna test\.


**070.** `07:50` **You**

Man that sucks\.  Are you ok??


**071.** `07:51` **Meredith Lamb (+14169386001)**

Yes, this is all pretty standard\. Just an annoyance that we can’t go to life labs\.


**072.** `07:52` **You**

Ah kk I don’t think I have any dna related thingies\.\. I did 23 and me and ancestery


**073.** `07:53` **You**

But I always worry because I don’t know who my biological
Father is


**074.** `07:53` **You**

So there could be all kinds of shit I am unaware of


**075.** `07:56` **Meredith Lamb (+14169386001)**

Yeah i had 3 miscarriages and they did generic testing and found this gene variant I got from one of my parents\. Causes blood clots


**076.** `07:57` **Meredith Lamb (+14169386001)**

So after surgeries I give myself shots for 2 wks to prevent\. That’s kinda thing\.


**077.** `07:57` **You**

>
Aww mer I am so sorry…\.😞 that must have been so tough\.

*💬 Reply*

**078.** `07:58` **Meredith Lamb (+14169386001)**

So with this stupid gene variant you can’t go on the pill and Mac wants to lol


**079.** `07:58` **You**

What about the needle


**080.** `07:59` **You**

Or is it same


**081.** `07:59` **You**

I don’t know much about that stuff


**082.** `08:01` **Meredith Lamb (+14169386001)**

Needle in arm?


**083.** `08:01` **You**

Yeah there is a birth control that can be delivered by a needle once every theee months I think


**084.** `08:03` **You**

Depo provers


**085.** `08:03` **You**

Provera


**086.** `08:03` **You**

It doesn’t contain estrogen like the pill and is considered safer for people with clotting disorders\.\. but probably best not to risk anything anyways\.


**087.** `08:07` **Meredith Lamb (+14169386001)**

Yeah my nieces got this like chip needle thing in their arm


**088.** `08:07` **Meredith Lamb (+14169386001)**

One had a bad reaction


**089.** `08:07` **Meredith Lamb (+14169386001)**

Had to have it removed


**090.** `08:08` **Meredith Lamb (+14169386001)**

Girls dr won’t consider anything until this dna test done


**091.** `08:11` **Meredith Lamb (+14169386001)**

Yeah well we are here and doing it\. :p


**092.** `08:11` **Meredith Lamb (+14169386001)**

Will find out who I passed it onto\! Yaye science


**093.** `08:18` **Meredith Lamb (+14169386001)**

Mac and I might stay over at my parents tomorrow night


**094.** `08:21` **You**

Cool \- sound like your mom is gonna be super happy again 😊


**095.** `08:24` **Meredith Lamb (+14169386001)**

I have to give her all the candy for the Easter we are missing and she lives right next to a Benjamin Moore


**096.** `08:25` **You**

Heheh so the paints yeah I guess we
Are
Off
Friday right


**097.** `08:30` **Meredith Lamb (+14169386001)**

Yep\!


**098.** `08:30` **You**

Cool well if
You want to try to connect Thursday let me know will figure something out


**099.** `08:34` **Meredith Lamb (+14169386001)**

So Ehsan and Jamie are in to be in a 4some with you and someone else at hrai wholesaler golf tourn


**100.** `08:34` **Meredith Lamb (+14169386001)**

lol


**101.** `08:34` **Meredith Lamb (+14169386001)**

Michelle made me ask


**102.** `08:35` **You**

Do you golf?


**103.** `08:35` **Meredith Lamb (+14169386001)**

I do not\. Sorry


**104.** `08:35` **You**

lol


**105.** `08:35` **You**

I dunno will think about it


**106.** `08:35` **Meredith Lamb (+14169386001)**

Michelle already committed you


**107.** `08:35` **Meredith Lamb (+14169386001)**

lol


**108.** `08:37` **You**

I’m h I know she did cause she is a shit


**109.** `08:37` **Meredith Lamb (+14169386001)**

Haha talking to her now


**110.** `08:38` **You**

Tell her I said that


**111.** `08:38` **Meredith Lamb (+14169386001)**

>
My mom would probably give me trouble\. You would also get in trouble\.

*💬 Reply*

**112.** `08:39` **Meredith Lamb (+14169386001)**

>
You can tell her yourself lol

*💬 Reply*

**113.** `08:40` **You**

>
No worries your call I have kept my find me off\.  Nothing has been said\.   Will leave the ball
In your court and be good no matter what\.

*💬 Reply*

**114.** `08:42` **Meredith Lamb (+14169386001)**

You have kept it off… interesting\. That feels like a big thing\. Haha


**115.** `08:43` **You**

Well it was a decision


**116.** `08:43` **You**

But I turned it off for everyone


**117.** `08:44` **Meredith Lamb (+14169386001)**

If I turned it off for my 12 year old she would scold me for sure\.


**118.** `08:44` **Meredith Lamb (+14169386001)**

Mac and Maelle wouldn’t care\. Never use it


**119.** `08:44` **You**

I doubt anyone says anything


**120.** `08:45` **You**

And if I keep it off consistently it looks more like adecision and not an instance


**121.** `08:48` **Meredith Lamb (+14169386001)**

k, well I could leave Mac with my parents for a bit if you can get away … we can talk tomorrow


**122.** `08:49` **You**

Yep I am easy whatever works


**123.** `08:50` **You**

Btw my responses are intended to make you feel less pressured
lol not to indicate am neutral as to whether I see you\.\. cause I am not lol\.
Def not neutral at all\.


**124.** `08:56` **Meredith Lamb (+14169386001)**

Omg Mackenzie passed out so bad


**125.** `08:56` **You**

ROFL


**126.** `08:56` **Meredith Lamb (+14169386001)**

Looked like she was seizing


**127.** `08:56` **You**

Oh shit


**128.** `08:56` **Meredith Lamb (+14169386001)**

All from blood work\!\!


**129.** `08:56` **You**

Sorry I thought that was meant to be passed
Out in car


**130.** `08:56` **You**

Shit


**131.** `08:56` **You**

Is she ok


**132.** `08:57` **You**

Maddie has something called pots that can do the same thing but that isn’t necessarily blood loss but poor blood flow in some
Cases


**133.** `09:00` **Meredith Lamb (+14169386001)**

She was literally seizing … crazy


**134.** `09:00` **Meredith Lamb (+14169386001)**

Nurse wasn’t concerned … so weird\. I will be researching this


**135.** `09:01` **You**

Shit that is crazy


**136.** `09:01` **Meredith Lamb (+14169386001)**

Her pupils were huge\. Eyes rolled back in her head and hands were all tense and weird\. Nurse had to hold her and massage her


**137.** `09:01` **Meredith Lamb (+14169386001)**

Current status

*📎 1 attachment(s)*

**138.** `09:02` **Meredith Lamb (+14169386001)**

Heat pack because she is freezing


**139.** `09:02` **You**

When someone passes out and appears to seize after donating blood, it’s typically due to a vasovagal reaction, which is a common, though sometimes dramatic, response\. Here’s a breakdown of what could be happening:
1\. Vasovagal Syncope \(Fainting\)
This is the most likely cause\. It happens when the body overreacts to a trigger — in this case, blood donation — by:
- Suddenly dropping heart rate and blood pressure
- Reducing blood flow to the brain
- Causing temporary loss of consciousness
2\. Convulsive Syncope
During vasovagal fainting, some people experience brief, seizure\-like activity — jerking, stiffening, or shaking — due to the brain being deprived of oxygen for a few seconds\. These movements can mimic a seizure but are not true epileptic seizures\.
3\. Hypoglycemia \(Low Blood Sugar\)
If the person hadn’t eaten before donating, their blood sugar might dip too low, especially combined with the stress of the procedure, leading to:
- Lightheadedness
- Fainting
- Seizure\-like activity in extreme cases
4\. Hyperventilation or Anxiety\-Induced Response
Strong anxiety or panic \(especially in those afraid of needles or blood\) can:
- Cause hyperventilation
- Lead to fainting
- Occasionally produce tremors or twitching during the episode
5\. True Seizure \(Less Common\)
In rare cases, someone might have a coincidental first\-time seizure or underlying epilepsy that gets triggered by the stress, anxiety, or blood pressure drop\. However, this is rare compared to vasovagal syncope\.
⸻
Key Differences: Vasovagal vs\. Seizure
Feature	Vasovagal Syncope	Epileptic Seizure
Duration of loss of consciousness	Usually <1 min	>1\-2 min
Recovery	Rapid, full	Postictal confusion, fatigue
Movements	Mild jerks or stiffness	Strong, rhythmic convulsions
Trigger	Needle, heat, anxiety	Often none, or flashing lights, stress
Aura	Nausea, tunnel vision, sweating	Strange smell, déjà vu \(possible\)
⸻
What to Do:
- Lie the person flat with legs elevated
- Loosen tight clothing
- Cool environment, water, and sugar may help
- Seek medical attention if the episode lasted longer than a minute, they didn’t recover quickly, or you’re unsure if it was a seizure
If you were there when this happened, I can help assess the situation more closely — what symptoms did you observe?


**140.** `09:03` **You**

Absolutely — people with POTS \(Postural Orthostatic Tachycardia Syndrome\) can definitely experience similar symptoms after donating blood, and may even be at higher risk for these kinds of episodes\.
⸻
How POTS Can Cause Similar Reactions:
POTS is a form of dysautonomia, meaning the autonomic nervous system \(which controls heart rate, blood pressure, and other automatic functions\) doesn’t regulate properly — especially when standing or under physical stress \(like blood donation\)\.
What happens during or after blood donation in someone with POTS?
1\.	Blood volume decreases: Even a small drop from donating can tip them into hypovolemia \(low blood volume\), which their system already struggles with\.
2\.	Heart rate spikes abnormally: Their body tries to compensate, but the response can be exaggerated or ineffective\.
3\.	Blood pressure may drop: Causing lightheadedness, blurred vision, nausea — and in severe cases, syncope \(fainting\)\.
4\.	Shaking or convulsive\-like movements: These can be part of a hypoperfusion response, looking seizure\-like but caused by low brain oxygen\.
⸻
Key Symptoms of a POTS\-Triggered Episode:
- Feeling like you’re “blacking out” or fainting
- Trembling or jerky movements while unconscious
- Nausea, cold sweat, blurry vision
- Rapid heart rate \(especially if they try to sit or stand up\) afterward
- Long recovery time — fatigue can last hours to days
⸻
Is This Dangerous?
It can be very distressing and feel dangerous, but most episodes resolve without permanent harm\. That said, it’s strongly advised that people with POTS:
- Avoid donating blood, unless medically cleared
- Stay hydrated and well\-fed before procedures
- Lie down during and after donation or any needle\-based medical procedure
⸻
Would you like help crafting a way to talk to a friend who might have POTS — or exploring if this might be what’s going on with someone you’re worried about?


**141.** `09:03` **You**

Maddie has this


**142.** `09:12` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**143.** `09:12` **You**


*📎 1 attachment(s)*

**144.** `09:13` **You**

Teddy girl and Maddie’s
Manatee\.


**145.** `09:13` **You**

Hope Mac is feeling better and the rest
Of the girls are ok


**146.** `09:09` **Meredith Lamb (+14169386001)**

Omg she passed out again in elevator


**147.** `09:09` **Meredith Lamb (+14169386001)**

We are sitting in parking lot outside elevator


**148.** `09:10` **Meredith Lamb (+14169386001)**

wtf lol


**149.** `09:29` **You**

Jesus maybe she should chill a bit?  Give her a cookie


**150.** `09:29` **You**

Or some sugar


**151.** `09:51` **Meredith Lamb (+14169386001)**

All good and home\. Phew


**152.** `09:53` **You**

Good to hear maybe max should stay home


**153.** `13:14` **You**

Reaction: 😂 from Meredith Lamb
Look how dumb the people on the call that don’t have glasses
On look 😛🤓


**154.** `13:16` **Meredith Lamb (+14169386001)**

Ok looked 👓


**155.** `14:46` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/6qqrTXSdwiJaq8SO0X2lSe?si=BHVNKKIsTeK38UmU5ZlxBA&context=spotify%3Asearch%3Aordinary
I know you don’t listen to the radio so sending\. lol you have to read the lyrics


**156.** `14:46` **Meredith Lamb (+14169386001)**

It’s a popular song right now


**157.** `15:04` **You**

I listened to that on the drive the other night made her play it again really liked it\.  Ava, Maddies friend is a big country music fan and that was in the list


**158.** `15:04` **You**

But I will read
Lyrics too


**159.** `15:19` **You**

Those are some heavy lyrics wow\.


**160.** `15:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**161.** `15:30` **Meredith Lamb (+14169386001)**

I like it but was wondering if it was a Christian song and how that got on the radio lol


**162.** `16:05` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**163.** `16:06` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**164.** `16:06` **Meredith Lamb (+14169386001)**

He always says he kept making more $ for us\. Total BS\.


**165.** `16:07` **Meredith Lamb (+14169386001)**

He likes to blame for me his Amazon gig when I told him not to leave EQ\.


**166.** `16:07` **Meredith Lamb (+14169386001)**

Anyway, is this over yet?\!


**167.** `16:08` **You**

Never over… the guilt is real it will always keep getting tossed around\.


**168.** `16:11` **You**

But I will be honest I said similar
To Jaimie but honestly literally could not keep up with what she wanted\. Suddenly only new cars were
Good enough …\. Fucking highlanders\.\. lol I have been driving a half broken 2013 Camry\.  We had the first trailer in Peter borough then a much more expensive one, then the pool then another highlander hybrid \- she didnt like it, then the crv, then just everything\.  200\-300 into the house
On stuff I never cared about\.


**169.** `16:11` **You**

But yeah I don’t think it is the same for someone making 500\-750 k per year


**170.** `16:11` **You**

I went from making 80 when I started here\.


**171.** `16:12` **You**

Like I doubt he has gone without for you guys\.\. that has been my life for a decade\.   I’ll continue that way and I am not even complaining lol\.  He needs to just let it go\.


**172.** `16:13` **Meredith Lamb (+14169386001)**

He has not gone without at all\. Everything he does is for “his mental health”\. Lol


**173.** `16:14` **Meredith Lamb (+14169386001)**

And our new cars are because of him not me which is actually funny\.


**174.** `16:14` **Meredith Lamb (+14169386001)**

He’s just a little delusional\.


**175.** `16:15` **You**

I feel like I am kind of dealing with a bit of the same here\.


**176.** `16:15` **Meredith Lamb (+14169386001)**

Just the name of the game I think\. Super complicated\.


**177.** `18:06` **You**

Fack just getting off now damnit people need to stop calling\!\!  lol


**178.** `18:07` **Meredith Lamb (+14169386001)**

You could be in the hood in scarboro instead\. Silver lining lol


**179.** `18:21` **You**

Come on if I was there with you that would be the silver lining


**180.** `18:25` **Meredith Lamb (+14169386001)**

That’d be like a gold lining 😋


**181.** `18:48` **You**

One upped me
Well played and accurate


**182.** `18:51` **You**

I should play the same games with you that you play with me\.\. what would we be doing if I was there right now……\. lol


**183.** `18:53` **Meredith Lamb (+14169386001)**

I have no idea what you are talking about\! I play no such games\.


**184.** `18:54` **You**

No no you can’t back out I play along


**185.** `18:56` **Meredith Lamb (+14169386001)**

>
You would be walking through bulk barn and the lcbo with me\. It’d be super hot\. :p

*💬 Reply*

**186.** `18:59` **You**

Rofl I would say something to you but I k ow your uncomfortable hearing it but I mean it lol best answer ever


**187.** `19:01` **Meredith Lamb (+14169386001)**

You know do you?


**188.** `19:01` **Meredith Lamb (+14169386001)**

lol


**189.** `19:03` **You**

I feel like you are


**190.** `19:04` **Meredith Lamb (+14169386001)**

Maybe I like being uncomfortable


**191.** `19:05` **Meredith Lamb (+14169386001)**

I think you might like it also


**192.** `19:07` **You**

Let’s agree
Who the brave one here is\.  I love you mer\.\.  you are absolutely for me\.


**193.** `19:10` **Meredith Lamb (+14169386001)**

Stopped me in the aisle …\.\. lol


**194.** `19:11` **You**

I told you you wouldn’t be ready for it\. It’s fine just relax no expectations we are all good mer\.  Felt
Good just saying it\.


**195.** `19:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I am more than ready\. I have loved you Scott for a while\.


**196.** `19:12` **Meredith Lamb (+14169386001)**

Maybe we can tell each other in person someday lol … someday


**197.** `19:15` **You**

We will always have whenever\.\. lol whenever I see you is fine with me\.


**198.** `19:15` **You**

>
Huge happy feeling\.

*💬 Reply*

**199.** `19:19` **Meredith Lamb (+14169386001)**

You’re sure we aren’t dreaming and this is real right? 🙃


**200.** `19:28` **You**

I would never say that I scares me all to hell


**201.** `19:29` **You**

Sorry for the delay had to deal


**202.** `19:30` **You**

It’s how feel it is just as plain as that\.  I think about you when I go to bed and when I wake up\.\. and they aren’t all dirty thoughts\.  I have never felt like that about anyone\.


**203.** `19:36` **You**

>
Never say it if I didn’t 100% mean it as it is quite terrifying to say\.\. and apparently type\.

*💬 Reply*

**204.** `19:38` **Meredith Lamb (+14169386001)**

I’m a teeny bit scared too\. What this all means, the changes coming, how that impacts things, if you turn to feeling differently what happens at work, etc etc etc


**205.** `19:45` **You**

Mer there could be other things that happen and we can deal with those, we can be careful\.  But I do love you and that isn’t going to change\.  Everything that has happened has been unique to me\.  And I have had plenty of relationships both serious and not, and not any have rivalled this regardless of their duration or intensity\.  I am scared too\.  But I just don’t want there to be any confusion or uncertainty at least about how I feel, and that I am 100% going forward to whatever you and I can figure out together for what comes next\.


**206.** `19:46` **You**

Reaction: ❤️ from Meredith Lamb
You know when I think about this texting thing there is one upside\.  My dad always told me never write something you don’t mean because it is there to stay…\. Unless I delete it\.  It reminds me of the letters him and mum
Exchanged\.  I have never done anything or wanted to do anything close to that with anyone else\.


**207.** `19:50` **Meredith Lamb (+14169386001)**

So Mackenzie asked me if you were married on the drive here\.


**208.** `19:50` **You**

Separated


**209.** `19:50` **You**

But past tense is fine


**210.** `19:50` **Meredith Lamb (+14169386001)**

lol


**211.** `19:50` **You**

What did you say


**212.** `19:51` **Meredith Lamb (+14169386001)**

\(She doesn’t understand tenses\.  She did French immersion\)


**213.** `19:51` **Meredith Lamb (+14169386001)**

Kidding


**214.** `19:51` **You**

I could translate :\)


**215.** `19:51` **Meredith Lamb (+14169386001)**

I said you were but you are in the process of separating\.


**216.** `19:51` **Meredith Lamb (+14169386001)**

I was just honest\.


**217.** `19:51` **You**

How much beyond that have you shared curious\.


**218.** `19:52` **Meredith Lamb (+14169386001)**

With Mac?


**219.** `19:52` **You**

Ya


**220.** `19:52` **Meredith Lamb (+14169386001)**

Um, not much tbh\.


**221.** `19:52` **Meredith Lamb (+14169386001)**

She just asked that tonight\.


**222.** `19:53` **Meredith Lamb (+14169386001)**

She thought we were co workers


**223.** `19:53` **You**

Kk just wondering what she will know if/when I meet her\.  That absolutely terrifies me


**224.** `19:53` **Meredith Lamb (+14169386001)**

I corrected her assumption on the co worker thing and got a big eyebrow raise\.


**225.** `19:53` **You**

I am sure it did


**226.** `19:53` **Meredith Lamb (+14169386001)**

lol


**227.** `19:54` **You**

Well I hope this erases any apprehensions you have left at least with regards to me and where I am at\.


**228.** `19:54` **Meredith Lamb (+14169386001)**

>
You don’t need to be terrified of meeting her\. Seriously\. She’d be cool about it

*💬 Reply*

**229.** `19:55` **You**

Yeah but I wouldn’t know what to do how to act it would be hilarious for you and embarrassing for me lol


**230.** `19:55` **Meredith Lamb (+14169386001)**

>
I don’t have any different apprehensions than you probably have… your life is messy, you are going through a lot… gets complicated\.

*💬 Reply*

**231.** `19:56` **You**

It is progressing though that is for certain


**232.** `19:56` **Meredith Lamb (+14169386001)**

>
She would be the same I’m sure\. Gotta be weird for her also

*💬 Reply*

**233.** `19:57` **You**

I gotta pack my shit up and hit the gym…
I will check in in a bit\.
Very interested to see how we do tomorrow\.


**234.** `19:57` **Meredith Lamb (+14169386001)**

How we do… ha


**235.** `19:57` **Meredith Lamb (+14169386001)**

I have a full day of meetings so no time for you


**236.** `19:57` **Meredith Lamb (+14169386001)**

:\(


**237.** `19:57` **You**

There is always after work


**238.** `19:57` **Meredith Lamb (+14169386001)**

Yes


**239.** `19:58` **You**

Kk heading out ttyiab


**240.** `19:58` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Yup ❤️


**241.** `20:28` **You**

Reaction: ❤️ from Meredith Lamb
https://open\.spotify\.com/track/6pwhSBxhaF5x0WbNZRyzlD?si=f966\_3TdQZSpt23CJWF94w&context=spotify%3Aplaylist%3A4o0w2C4v7JfY6AwQTKoWoD


**242.** `20:28` **You**

Listen and read words


**243.** `20:29` **You**

The more I listen the more I like


**244.** `20:56` **You**

So while I am lifting tonight what can I imagine you are doing


**245.** `21:10` **Meredith Lamb (+14169386001)**

I just got home from scarboro\. Sitting with my puppers thinking of you\.


**246.** `21:13` **Meredith Lamb (+14169386001)**

If we could be together tonight, I’d give you a massage after gym before bed\. Might be thinking of that… might not be\.


**247.** `21:17` **You**

Would be a short massage\.


**248.** `21:18` **You**

This is a rough night, legs and back a middle aged man’s worst enemy\.


**249.** `21:18` **Meredith Lamb (+14169386001)**

>
No\.

*💬 Reply*

**250.** `21:19` **You**

Sure it would be\.\. lol would transition to something else isn’t that what they say about massages\.\. I think I read that somewhere\.\. not experience mind you\.


**251.** `21:20` **Meredith Lamb (+14169386001)**

I’ll keep you down :\)


**252.** `21:21` **You**

Hehe I am not sure you would have any control over that\.


**253.** `21:21` **You**

Phew


**254.** `21:21` **You**

Eesh\.\. ok next set


**255.** `21:22` **Meredith Lamb (+14169386001)**

>
Well in my mind I do\. Lol

*💬 Reply*

**256.** `21:22` **You**

Really you think that I could even kept
Control over that?


**257.** `21:24` **You**

😏 lol


**258.** `21:26` **Meredith Lamb (+14169386001)**

Maybe…\.


**259.** `21:27` **You**

Kk will put this to the test sometime\.\. you can scroll back to this conversation and have chuckle\.


**260.** `21:27` **You**

Hope
You at least get a peaceful night


**261.** `21:29` **You**

Check out this listing
https://realtor\.ca/real\-estate/28178340/202\-coronation\-road\-whitby\-rural\-whitby?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**262.** `21:29` **Meredith Lamb (+14169386001)**

My mother in law is here\. Lol


**263.** `21:29` **Meredith Lamb (+14169386001)**

Sooooo


**264.** `21:31` **Meredith Lamb (+14169386001)**

“Rural” Whitby :\)


**265.** `21:32` **Meredith Lamb (+14169386001)**

No way you want to spend that much $


**266.** `21:33` **You**

Ahhh ok so no more fun time\.\. maybe later\.\. stay cool\!\! lol


**267.** `21:35` **You**

Ah damn and pony just came on\.


**268.** `21:35` **You**

Interesting song to workout to\.


**269.** `21:35` **Meredith Lamb (+14169386001)**

Great song


**270.** `21:53` **You**

Check out this listing
https://realtor\.ca/real\-estate/28063406/8\-calloway\-way\-whitby\-downtown\-whitby\-downtown\-whitby?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**271.** `21:53` **You**



**272.** `21:54` **You**

Trying to book a walkthrough for this one\.


**273.** `22:04` **Meredith Lamb (+14169386001)**

Very nice\.


**274.** `22:04` **Meredith Lamb (+14169386001)**

Getting a financial talking to…\. I’m soooo tired\.


**275.** `22:05` **You**

From you mother in law or Andrew


**276.** `22:28` **Meredith Lamb (+14169386001)**

Andrew\. MIL left a while ago\.


**277.** `22:28` **Meredith Lamb (+14169386001)**

Nasty conversation\. No respect for boundaries\. I literally said “my therapist would say this is an example of you not respecting my boundaries\.”


**278.** `22:30` **Meredith Lamb (+14169386001)**

I’m so tired and got literal chest pains\. It has been a long day with Mac and everything\. Now I’m pissed off\. I’m going to go to bed\. I will try to go to sleep thinking of loving you\. xo see you tomorrow


**279.** `22:34` **You**

Love you too mer\. Get used to hearing that or rather reading that\.


**280.** `22:34` **You**

Or both


