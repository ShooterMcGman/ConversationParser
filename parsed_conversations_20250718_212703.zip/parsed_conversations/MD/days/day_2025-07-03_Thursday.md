# Daily Conversation: 2025-07-03 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-03 |
| **Day** | Thursday |
| **Week** | 12 |
| **Messages** | 302 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-03T04:13 - 2025-07-03T22:49 |

## 📝 Daily Summary

This day contains **302 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:13` **You**

Well awake\.\. not happy, not looking forward to today\.  It’s a self doubt kinda day, and I sure don’t want to go to work\. Still have all the feelings from yesterday morning and the weekend though lol that’ll never change I suspect\.  Anyhow love you Mer hope you had a good sleep and a good morning\. Will see you at work I am sure\.


**002.** `07:12` **Meredith Lamb (+14169386001)**

Yeah same\. I’m in a weird place mentally and didn’t sleep well\. Boo\. Trrrrrying to get up\. :p do not want to go to work either\. Gahh
Hope you had a good workout xo


**003.** `09:59` **You**

Sorry not chatty today in a bad mood\.😒


**004.** `10:06` **Meredith Lamb (+14169386001)**

Yeah same…\. no worries\. Sigh


**005.** `10:56` **You**

Just want to go home and go to sleep I have no desire to do any of this shit today\.  I might leave early I have to come in tomorrow anyways\.


**006.** `10:57` **You**

This is going to be bad… 🙁\.  lol


**007.** `11:00` **You**

That was one of your sad lol’s btw not a real one\.


**008.** `11:07` **Meredith Lamb (+14169386001)**

I feel like I’m bi\-polar now\. \(sad lol\)


**009.** `12:14` **Meredith Lamb (+14169386001)**

Ps\. Pauline messed up the midstream reporting in March and never mentioned to me anything about it so…\.\. ughhhh


**010.** `12:14` **You**

>
Yeah this isn’t good\.  I am not sure how to deal\.

*💬 Reply*

**011.** `12:14` **Meredith Lamb (+14169386001)**

So who figures it out? Musarrat? Me? Pauline? What a shit show


**012.** `12:14` **You**

Pauline


**013.** `12:14` **You**

If she did it she fixes it


**014.** `12:15` **Meredith Lamb (+14169386001)**

“I remember a conversation where I was told that I was not a good fit for this work\.”


**015.** `12:15` **You**

She can work with mus to do that but she needs to fix her own stuff


**016.** `12:15` **Meredith Lamb (+14169386001)**

Case in point Pauline\.


**017.** `12:15` **You**

……\.


**018.** `12:15` **Meredith Lamb (+14169386001)**

She messed up April too but not as material\.


**019.** `12:16` **You**

I mean I was going to ask
Messed up how but honestly I don’t care\.\. she just needs to fix it\. If you need me to tell her I will\.


**020.** `12:18` **You**

Honestly how can this be this fucking bad\.\. fuck stuck here till 330


**021.** `12:18` **Meredith Lamb (+14169386001)**

She didn’t reconcile the numbers to the invoice properly so the numbers coded to large/small are incorrect


**022.** `12:18` **Meredith Lamb (+14169386001)**

Not sure of the impact really


**023.** `12:18` **Meredith Lamb (+14169386001)**

I honestly don’t care lol


**024.** `12:18` **You**

So do I need to tell her…… just let me know\.


**025.** `12:19` **Meredith Lamb (+14169386001)**

Let me talk to mus


**026.** `12:19` **You**

K


**027.** `12:23` **You**

I already warned her you might reach out\.  Really should pave the way for an easier request


**028.** `12:58` **Meredith Lamb (+14169386001)**

😵‍💫 she doesn’t like me so Musarrat might reach out lol


**029.** `12:58` **You**

K


**030.** `13:03` **You**

Shouldn’t be your problem anyways\.\. let mus push her and I will intervene if I must\.  Just don’t worry about it you should be done with your old job now regardless\.


**031.** `13:44` **Meredith Lamb (+14169386001)**

Some things never change\. A year ago…

*📎 1 attachment(s)*

**032.** `13:46` **You**

lol kids…


**033.** `13:57` **Meredith Lamb (+14169386001)**

2\.20am god…


**034.** `13:58` **You**

Harmless I wish I was them instead of me\.


**035.** `14:19` **Meredith Lamb (+14169386001)**

Musarrat didn’t want to contact Pauline so I did… we will see what happens\. Will go to you if Pauline doesn’t respond\.


**036.** `14:33` **You**

I don’t understand this at all… I should have just done it if mus wouldn’t\.\. again you shouldn’t have to be involved anymore\.  Thanks for doing it though and for the heads up\.


**037.** `14:34` **Meredith Lamb (+14169386001)**

Musarrat isn’t comfortable enough with the reporting yet\. It is a really annoying reporting process\.


**038.** `14:35` **You**

I am going to fix it it sounds stupid\.  We shouldn’t be doing it it is what we pay CR for\.


**039.** `14:36` **You**

I should engage today\.\. that would be a good experience for Matthew\.


**040.** `15:30` **You**

And fucking done meetings for the day to go or not to go…\. Blech


**041.** `15:40` **Meredith Lamb (+14169386001)**

Well you lucked out on PO4


**042.** `15:40` **You**

Not really


**043.** `15:40` **You**

Octavian


**044.** `15:40` **Meredith Lamb (+14169386001)**

But I mean you relative to Craig


**045.** `15:41` **You**

Yeah they took a complex route\.


**046.** `15:41` **You**

Whatever I will be happy to be left alone\.


**047.** `16:18` **Meredith Lamb (+14169386001)**

I’m heading out\. Marlowe had given me instructions on things to pick up on way home\.
Love you\. Great day\. 🙃❤️🫤


**048.** `16:21` **You**

Sorry will not be returning the enthusiasm but love you and have a good night\.


**049.** `17:39` **You**



**050.** `17:44` **Meredith Lamb (+14169386001)**

🤔


**051.** `17:52` **You**

Botched apology\.\. ignore


**052.** `18:20` **You**



**053.** `18:20` **You**

omg ffs


**054.** `18:22` **You**

attempt 3:  Sorry this took long to get back to, have been fighting with Jaimie for last 30 mins\.\. super fun\.  Basically I thought limiting communication would make it easier\.\. but you know it made it worse\.  When I talk to you I can't stop thinking about you, and that causes its own pain and frustration\.\. but not talking to you at all is way worse 😥


**055.** `18:24` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 18:51:29 \-0400
|
| I wanted to ask how your night was last night, how much wine you ended up having, as you were going to go to bed early lol, if you and Andrew had any parental planning discussions and how those went wanted to know about your day\.\. but yeah\.\. moron\.  I mean I was back to back all day, just annoying\.\. maybe it will level out to just general disappointment like it was before last Thursday\. Here’s hoping\.
|
| Version: 1
| Sent: Thu, 3 Jul 2025 18:24:07 \-0400
|
| I wanted to ask how your night was last night, how much wine you ended up having, as you were going to go to bed early lol, wanted to know about your day\.\. but yeah\.\. moron\.  I mean I was back to back all day, just annoying\.\. maybe it will level out to just general disappointment like it was before last Thursday\.


**056.** `20:19` **Meredith Lamb (+14169386001)**

Just getting this\. Had a nap……\. So tired\. Ugh


**057.** `20:19` **Meredith Lamb (+14169386001)**

You do not need to apologize to me\. Geez


**058.** `20:21` **Meredith Lamb (+14169386001)**

I am not feeling like myself and not particularly chatty either


**059.** `20:21` **Meredith Lamb (+14169386001)**

I knew you had a busy day also


**060.** `20:21` **Meredith Lamb (+14169386001)**

Etc etc


**061.** `20:21` **You**

I just felt really disconnected and I didn’t like it and I felt like I caused it\.


**062.** `20:22` **You**

It’s fine doesn’t matter like I said hoping this will just level out


**063.** `20:24` **Meredith Lamb (+14169386001)**

Yeah felt / feeling that way also\. Also don’t like it\. 🙁


**064.** `20:26` **You**

How do we make this work Mer any thoughts?


**065.** `20:26` **You**

I don’t have any more ideas tbh\.  Except wait


**066.** `20:27` **You**

I am also worried you won’t be able to deal with the stress of all this\.


**067.** `20:29` **Meredith Lamb (+14169386001)**

Wrt to your question: i am not sure… waiting seems to be the only thing right now\.


**068.** `20:30` **Meredith Lamb (+14169386001)**

I am finding the swing between the weekend and the back to reality quite a large shift this time for sure\.


**069.** `20:30` **Meredith Lamb (+14169386001)**

It is honestly a little like taking e …\. lol


**070.** `20:31` **You**

Sorry typo at end?


**071.** `20:31` **Meredith Lamb (+14169386001)**

Maybe I just need to eat more potassium 🍌


**072.** `20:31` **You**

Oh


**073.** `20:31` **Meredith Lamb (+14169386001)**

Not a typo


**074.** `20:31` **You**

Nm


**075.** `20:34` **You**

I mean the upside is we are compatible I think in a lot of different ways and for the future that bodes well\.\. I have to tell you though I am worried you might change direction\.\. you have so much responsibility so much you are worried about\.  Honestly I thought about it a lot on the weekend\.\. just concerned\.  In addition to me feeling you would want your freedom this the other part to me suggesting you would regret being with me\.


**076.** `20:35` **You**

I don’t know I keep thinking the longer this goes the closer this gets to something it will get easier but I am less sure\.\. maybe I am messing with my own head


**077.** `20:38` **Meredith Lamb (+14169386001)**

You are definitely messing with your head\. But I’ve been having weird thoughts too\. So many thoughts in my head since getting my new place, discussions about that here, etc etc then just with work today and since the weekend and everything\. It’s just all so weird feeling\.
I have not thought about changing direction at all but my head is certainly wondering if the direction we are on is even sustainable but I really hope it is\. All I can do


**078.** `20:38` **You**

😢


**079.** `20:40` **Meredith Lamb (+14169386001)**

My head has never even once considered taking a pause until today\. But I don’t want to but shit it was /is difficult in a way that is really hard to explain


**080.** `20:44` **You**

>
Honestly last thing I wanted to hear not sure how to respond\.

*💬 Reply*

**081.** `20:45` **You**

Appreciate the honesty though\.\. still feels like I am about to be dropped lol pretty awful feeling\.\. but if that is what you need to do I would understand\.


**082.** `20:45` **Meredith Lamb (+14169386001)**

Not even close


**083.** `20:45` **Meredith Lamb (+14169386001)**

Just struggling


**084.** `20:47` **You**

I never thought this kind of love would cause this kind of pain\. Honestly\.


**085.** `20:47` **You**

Not your fault\.\. just this situation


**086.** `20:47` **You**

Anyhow I do t want to bug you about it we don’t need to discuss it\.


**087.** `20:52` **Meredith Lamb (+14169386001)**

I really just don’t understand it but I think it has to do with the secrecy everywhere\. Work, home… I mean it helps that Jim and my extended family and friends I can be open and honest with for sure\. Helps a lot but it feels so challenging elsewhere\. Once I get our agreement signed, perhaps I will feel like I have a bit more freedom/flexibility to make my own decision about telling Andrew/kids but I feel very strapped atm\. And it also causes me to feel pretty limited about where we can actually spend time together in future


**088.** `20:52` **Meredith Lamb (+14169386001)**

Learned of Andrew’s Reno plan after work


**089.** `20:52` **Meredith Lamb (+14169386001)**

Omg


**090.** `20:52` **Meredith Lamb (+14169386001)**

He and girls to move into basement in August


**091.** `20:52` **Meredith Lamb (+14169386001)**

And no access to upper two floors for 8 months


**092.** `20:52` **Meredith Lamb (+14169386001)**

I got mad at him


**093.** `20:52` **Meredith Lamb (+14169386001)**

Like wtf


**094.** `20:53` **Meredith Lamb (+14169386001)**

The girls will be miserable


**095.** `20:53` **Meredith Lamb (+14169386001)**

They will have to be with me


**096.** `20:53` **Meredith Lamb (+14169386001)**

There isn’t even a proper kitchen down there\. It is tiny


**097.** `20:53` **Meredith Lamb (+14169386001)**

So I have a feeling I may have kids or partial kids full time


**098.** `20:54` **Meredith Lamb (+14169386001)**

He’s a moron and thinks people can live in squalor conditions


**099.** `20:54` **You**

I figured that would be the case when you said it the other night


**100.** `20:54` **Meredith Lamb (+14169386001)**

And stay mentally sane


**101.** `20:54` **Meredith Lamb (+14169386001)**

The original plan was to live in basement but have access to upper kitchen and living room


**102.** `20:54` **Meredith Lamb (+14169386001)**

Not anymore


**103.** `20:54` **You**

I also know what that means for you and for us\.\. it is what it is


**104.** `20:56` **Meredith Lamb (+14169386001)**

Yeah and then I booked time off to go to cottage bc I am babysitting Bo\. But of course girls want to come with me even tho Marlowe has vball\. She wants to skip vball


**105.** `20:56` **Meredith Lamb (+14169386001)**

All good


**106.** `20:56` **Meredith Lamb (+14169386001)**

I don’t mind


**107.** `20:56` **Meredith Lamb (+14169386001)**

But just another thing


**108.** `20:56` **Meredith Lamb (+14169386001)**

Yunno


**109.** `20:56` **You**

I already told you though I don’t plan on walking away from you or this for any reason\. So unless you have other ideas\.\. we’ll just have to figure it out as best we can until there is enough flexibility to be more normal\.


**110.** `20:57` **You**

>
Was this why you asked me about the cottage?

*💬 Reply*

**111.** `20:57` **Meredith Lamb (+14169386001)**

No


**112.** `20:57` **Meredith Lamb (+14169386001)**

I just booked it today


**113.** `20:57` **You**

Ah ok


**114.** `20:58` **Meredith Lamb (+14169386001)**

Before the PO tho lol


**115.** `20:58` **You**

When did you book


**116.** `20:59` **Meredith Lamb (+14169386001)**

Week of tech conf\. That is the second week I have bo\. Can’t the week before bc Andrew in Montreal for work


**117.** `20:59` **Meredith Lamb (+14169386001)**

I didn’t book off Wed and Fri\. Just office days


**118.** `20:59` **Meredith Lamb (+14169386001)**

>
You don’t plan on walking away but you can’t talk to me either\. Lol 🧐

*💬 Reply*

**119.** `21:00` **You**

I can


**120.** `21:00` **You**

I will figure it out\.


**121.** `21:01` **You**

You have to understand just like I understand your situation


**122.** `21:02` **You**

When they leave I will be alone\.\. it will be a bit tough\.\. dealing with everything in my head that last week of July\.\. then most of august likely alone\.\. so i will try my best


**123.** `21:07` **You**

I guess the issue you have is you are actually looking at a few months where we don't see each other right\.


**124.** `21:07` **You**

is that the problem you are having


**125.** `21:08` **Meredith Lamb (+14169386001)**

I honestly can’t see when we see each other next… isn’t the full issue but it is an issue for sure


**126.** `21:08` **Meredith Lamb (+14169386001)**

Like literally don’t see it


**127.** `21:08` **Meredith Lamb (+14169386001)**

And if work sucks as bad as it did today


**128.** `21:08` **Meredith Lamb (+14169386001)**

On top of that


**129.** `21:08` **Meredith Lamb (+14169386001)**

I mean maybe if you ever move offices it changes somewhat… unlikely


**130.** `21:09` **You**

I am going into the office tomorrow\.\. to fill my boxes\.\. I will be in new office Monday\.


**131.** `21:09` **You**

I mean I thought it would be easier when you had a place, and signed the agreement\.\. but I guess now that won't be the case\.\. I guess that changes things for you\.


**132.** `21:10` **Meredith Lamb (+14169386001)**

It doesn’t “change things”


**133.** `21:11` **You**

I am not sure even you believe that\.\. lol


**134.** `21:13` **You**

anyhow like I said\.\. not going anywhere\.\. never found this before, I couldn't leave if I wanted to\.\. and if I ever did I would be the biggest fool ever\.  Again like I said at the beginning of this\.\. I got a sense that this became "different" for you in past few days\.  thus the "changed things"


**135.** `21:15` **Meredith Lamb (+14169386001)**

It is just a strange way to live and is wearing I think\. Nothing has changed per se…\. Just time is passing


**136.** `21:15` **Meredith Lamb (+14169386001)**

I’m not leaving or going anywhere


**137.** `21:15` **Meredith Lamb (+14169386001)**

But that doesn’t make the situation “easier”


**138.** `21:15` **Meredith Lamb (+14169386001)**

If anything that realization makes it more difficult


**139.** `21:16` **You**

Well\.\. I mean I was hoping for some kind of once a week or once every couple of weeks\.\. but hey will have to try to work with once every couple of months for a while I guess\.


**140.** `21:17` **You**

See I told you the universe wanted to fucking destroy me\.\. lol


**141.** `21:19` **You**

It's fine\.\. will get a life\.\. and see what that does for me, maybe it makes the waiting easier\.  With this new revelation I don't think I have a choice at this point\.


**142.** `21:20` **Meredith Lamb (+14169386001)**

I honestly don’t think the universe is against you


**143.** `21:22` **You**

I don't see how you think it is not\.\. everything in my life was literally going to shit\.\. then I found you, literally my one person\.\. and then tells me sorry can't have her\.  Like it definitely wants me to just break into pieces lol\.\. like you were suggesting a while back hehe\.


**144.** `21:25` **You**

I also think Jim thinks this is a huge mistake too\.\. like I feel like we might be the only ones that want this to work\.\. and nothing is lining up to make it any easier\.\. everything is a fight\.\. and when we win\.\. god is it worth it\.\. but holy fuck\.\.\.\.\.\.\. gah maybe we should stop talking about it\.\. I am sure this isn't making you feel better\. And we have a long fucking time between now and whenever\.\. we definintely cannot keep talking like this\.


**145.** `21:25` **Meredith Lamb (+14169386001)**

>
I was suggesting???

*💬 Reply*

**146.** `21:26` **You**

you said you felt like i was going to fall apart in front of yo


**147.** `21:26` **Meredith Lamb (+14169386001)**

>
I don’t think Jim thinks that\.

*💬 Reply*

**148.** `21:26` **Meredith Lamb (+14169386001)**

Oh like a long time ago?


**149.** `21:26` **You**

>
I don't believe you\.\. lol\.\.

*💬 Reply*

**150.** `21:26` **You**

>
yeah a while back

*💬 Reply*

**151.** `21:26` **Meredith Lamb (+14169386001)**

Why?


**152.** `21:27` **You**

because you wouldn't tell me if he did, because you know it would hurt me\.\. he already doesn't talk to me at all anymore\./


**153.** `21:27` **You**

literally not at all


**154.** `21:27` **You**

since we told him


**155.** `21:27` **Meredith Lamb (+14169386001)**

Well that is interesting but there must be some other reason behind it because I don’t think he thinks that


**156.** `21:27` **You**

I guess I feel pretty isolated no matter where I am at anymore\.\. here, work\.\. anywhere really\.


**157.** `21:28` **Meredith Lamb (+14169386001)**

And if Jim did think that and I was aware, I would tell you


**158.** `21:28` **Meredith Lamb (+14169386001)**

He might just find the whole thing awkward?


**159.** `21:28` **Meredith Lamb (+14169386001)**

No idea


**160.** `21:28` **You**

anyway, we should agree to try to put this discussion to bed tonight\.\. if I just have to fake it I will for as long as I have to\.


**161.** `21:29` **Meredith Lamb (+14169386001)**

Maybe we put him in an awkward position


**162.** `21:29` **You**

>
doesn't seem to stop him from talking to you\.

*💬 Reply*

**163.** `21:29` **You**

just saying


**164.** `21:29` **Meredith Lamb (+14169386001)**

I feel like we talked more to begin with tho


**165.** `21:29` **Meredith Lamb (+14169386001)**

Just saying


**166.** `21:30` **You**

no\.\. before you came on Jim and I talked all the time\. like ALL the time\.\. even a lot after I took the Manager role\.  But after we told him\.\. it went to zero\.


**167.** `21:30` **You**

its fine it doesn't matter\.


**168.** `21:30` **Meredith Lamb (+14169386001)**

Hmmh


**169.** `21:30` **You**

it really doesn't nothing really matters\.\. everything just is\.\. and there is nothing I can do\.


**170.** `21:31` **You**

not something I am used to to be honest


**171.** `21:31` **Meredith Lamb (+14169386001)**

What aren’t you used to?


**172.** `21:31` **You**

Not being able to do anything to improve my situation\.  I can always do something, solve a problem figure something out\.  There is literally nothing I can do here\.\. I have no control\.


**173.** `21:32` **You**

again I will figure something out\.\. a combination of faking it, distracting myself, continuing to work out insane amounts\.\. and just hoping for an opportunity\.


**174.** `21:34` **Meredith Lamb (+14169386001)**

I honestly don’t think this will ever be better until our families know the truth\.


**175.** `21:34` **Meredith Lamb (+14169386001)**

And that just is what it is\.


**176.** `21:34` **Meredith Lamb (+14169386001)**

Maybe not on your end


**177.** `21:34` **You**

Jaimie already knows


**178.** `21:34` **Meredith Lamb (+14169386001)**

But certainly on mine


**179.** `21:34` **You**

like she knows knows


**180.** `21:35` **Meredith Lamb (+14169386001)**

Knows knows?


**181.** `21:35` **You**

that was part of what we fought about tonight


**182.** `21:35` **You**

she knows suspects and has convinced herself about my trips the past few weeks\.


**183.** `21:35` **You**

she knows I am seeing you\.


**184.** `21:35` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 21:35:58 \-0400
|
| I don’t get why you get to have these discussions and I don’t
|
| Version: 1
| Sent: Thu, 3 Jul 2025 21:35:38 \-0400
|
| I don’t get why you get to have these discussions I don’t


**185.** `21:36` **You**

she knows that I am not going to be alone when she leaves\.\.


**186.** `21:36` **You**

well she doesn't know the full situation\.


**187.** `21:36` **You**

like it isn't like we will be "together" lol


**188.** `21:36` **You**

you cannot tell Andrew until you sign your agreement\.\. your situation is different\.


**189.** `21:37` **Meredith Lamb (+14169386001)**

It doesn’t seem fair that mine has to be different


**190.** `21:37` **You**

and even then like what\.\. am I going to come over and hang with the kids\.\. lol\.\. no\.\. like you said\.\. there is no point in the future you see that works for us is there\.


**191.** `21:37` **Meredith Lamb (+14169386001)**

It isn’t about hanging out with the kids\. It is socializing the concept


**192.** `21:37` **Meredith Lamb (+14169386001)**

That will take some time


**193.** `21:38` **Meredith Lamb (+14169386001)**

It is just frustrating not even being able to socialize anything but I’m probably being selfish


**194.** `21:39` **You**

I don't see how socializing fixes things for you anyways\.


**195.** `21:39` **You**

again other than perhaps makes you feel better\.


**196.** `21:41` **Meredith Lamb (+14169386001)**

I mean it is part of moving forward and actually having some sort of future\. Without that what is there


**197.** `21:41` **You**

sorry\.\. that is not quite what I meant\.\. no I totally agree with what you are saying there\.


**198.** `21:41` **Meredith Lamb (+14169386001)**

How did you guys start fighting?


**199.** `21:41` **You**

I was being selfish there\.\. I was thinking more about the near term


**200.** `21:41` **You**

um


**201.** `21:42` **Meredith Lamb (+14169386001)**

Andrew is still being so weirdly nice to me


**202.** `21:42` **You**

\.\.\.\. well that isn't here\.\. one more thing that is different\.\.\.


**203.** `21:43` **You**

I asked about the agreement and should we message Nichole\. it has been a week since she said we would expect the draft\.\. that started a fight about me kicking her to the curb getting her out of here as fast as I can so I can be with my girlfriend\.\. I actually laughed at her and said you have know idea what you are talking about\.\. she doesn't know about these challenges obviously\.\. but it was ironic\.\. and then she commented on the past few weeks/months as if I didn't know what was going on\.


**204.** `21:44` **You**

Like I said all coming up snake eyes for me\.\.


**205.** `21:45` **Meredith Lamb (+14169386001)**

>
We haven’t gotten ours and it has been a week too\.

*💬 Reply*

**206.** `21:45` **You**

at least you and andrew seem to be getting along should make some things easier


**207.** `21:45` **Meredith Lamb (+14169386001)**

It seems so weird though\. I don’t get why he is acting nice\. It is making no sense


**208.** `21:46` **Meredith Lamb (+14169386001)**

He offered to help move a couple beds for me today


**209.** `21:46` **Meredith Lamb (+14169386001)**

Like wtf


**210.** `21:46` **Meredith Lamb (+14169386001)**

Offered to help


**211.** `21:46` **Meredith Lamb (+14169386001)**

?????


**212.** `21:46` **Meredith Lamb (+14169386001)**

And just generally is being nice


**213.** `21:46` **Meredith Lamb (+14169386001)**

It’s stressing me out


**214.** `21:46` **You**

Just accept it\.\. and stop over thinking it\.


**215.** `21:47` **Meredith Lamb (+14169386001)**

Sure and then something hits me in the face


**216.** `21:47` **Meredith Lamb (+14169386001)**

lol


**217.** `21:47` **You**

hmmm\.\. maybe\.\. but I don't think so at this point\.\. it might change depending on how further financial discussion go  who knows\.


**218.** `21:49` **Meredith Lamb (+14169386001)**

We will see… bracing myself for the whiplash when it happens


**219.** `21:50` **You**

All you can do\. That and drink wine and eat gummies\.


**220.** `21:50` **Meredith Lamb (+14169386001)**

Maybe I should stop that and my head would be better


**221.** `21:50` **You**

Maybe I should start\.


**222.** `21:51` **Meredith Lamb (+14169386001)**

So your separation is now basically viewed as my fault 🤦‍♀️


**223.** `21:51` **Meredith Lamb (+14169386001)**

Like 100%


**224.** `21:51` **Meredith Lamb (+14169386001)**

I don’t think that will be the case around here …


**225.** `21:51` **Meredith Lamb (+14169386001)**

But maybe


**226.** `21:52` **Meredith Lamb (+14169386001)**

But don’t think so


**227.** `21:52` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 21:52:26 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Thu, 3 Jul 2025 21:51:13 \-0400
| >
| > So your separation is now basically viewed as my fault 🤦‍♀️
|
| This is kind of unfortunate
|
| Version: 1
| Sent: Thu, 3 Jul 2025 21:52:17 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Thu, 3 Jul 2025 21:51:13 \-0400
| >
| > So your separation is now basically viewed as my fault 🤦‍♀️
|
| This is kind of info


**228.** `21:52` **You**

>
Not even close and it is not info because you said it

*💬 Reply*

**229.** `21:52` **You**

It is more like insult to injury


**230.** `21:53` **You**

Not only did I leave but then I found someone in like 2 weeks


**231.** `21:53` **You**

That is what it is like


**232.** `21:53` **Meredith Lamb (+14169386001)**

For real?


**233.** `21:53` **You**

Yes


**234.** `21:53` **Meredith Lamb (+14169386001)**

She doesn’t believe otherwise?


**235.** `21:54` **You**

She originally had thoughts but I think she recognizes there were significant underlying issues\.\.


**236.** `21:54` **You**

At most it impacted timing


**237.** `21:55` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 21:55:44 \-0400
|
| Look it is the truth\.\. so you can at least get that off your mind
|
| Version: 1
| Sent: Thu, 3 Jul 2025 21:55:33 \-0400
|
| Look it is the truth\.\. so you can at least get that off your kindle


**238.** `21:55` **You**

Mind


**239.** `21:56` **Meredith Lamb (+14169386001)**

Oh the lives we live now…


**240.** `21:57` **You**

They are not good\.\. I was relatively invulnerable for a long long time… my current situation not so much\.\. great for when things are hopeful\.\. not feeling a lot of that atm\.  Again more worried you will realize this either isn’t worth it or won’t work\.\. you will think you are doing me a favour and give me a kick in the ass\.\. that is my nightmare scenario\.


**241.** `21:58` **You**

Reaction: ❤️ from Meredith Lamb
Anyhow bedtime soon\.\. not right now but soon, so not much more time for this discussion, then I think we need to try to put it away\.  We might need to try the park again where we can there is at least that\.


**242.** `22:00` **You**

>
Either that or you hope I give up so then it isn’t on you lol\.\. I mean that is pretty nightmarish too\.

*💬 Reply*

**243.** `22:02` **Meredith Lamb (+14169386001)**

>
I will not do this\. At most, I will get really bummed and be all mopey\. 😕 I know I said I had a pause thought come into my head but it wasn’t like I listened to it nor would I\. But my brain will keep searching for time or a future path or whatever\. Just natural\. I feel really confident that we will be together, I really do\. It’s just a matter of figuring out what that looks like and I just am having trouble right now\. Doesn’t mean I don’t think it will happen, I just don’t see the path right now…

*💬 Reply*

**244.** `22:02` **Meredith Lamb (+14169386001)**

>
Gasp\.

*💬 Reply*

**245.** `22:03` **You**

I mean have seen it happen\.  I have seen people make it happen\.


**246.** `22:06` **Meredith Lamb (+14169386001)**

>
Who are these ppl? Lol

*💬 Reply*

**247.** `22:07` **You**

There aren’t any good choices here so we will just to see how long this lasts\.\. I hope it wins out\.\. my mum used to tell me if you loved something enough it would work out\.\. and god knows with the amount I love you it should but I am not sure she was right\.  We will just have to see\.


**248.** `22:09` **Meredith Lamb (+14169386001)**

It will work out\. I just don’t want to go insane in the meantime so…\. lol


**249.** `22:10` **Meredith Lamb (+14169386001)**

Please don’t say again “we will just see how long this lasts”


**250.** `22:10` **Meredith Lamb (+14169386001)**

That phrase is not allowed


**251.** `22:10` **Meredith Lamb (+14169386001)**

🚫


**252.** `22:11` **You**

I already told you what I wanted from you that hasn’t changed, and it won’t\.\.


**253.** `22:11` **You**

But


**254.** `22:11` **Meredith Lamb (+14169386001)**

No buts


**255.** `22:12` **You**

I don’t know how it will work anymore\.  It won’t be for lack of wanting or trying though\.


**256.** `22:16` **Meredith Lamb (+14169386001)**

Gpt says:
You’re allowed to have days when this feels impossible\. It’s okay to wonder if you’re breaking under the weight of love that doesn’t fit cleanly into life\.


**257.** `22:16` **Meredith Lamb (+14169386001)**

Maybe it is that simple


**258.** `22:16` **Meredith Lamb (+14169386001)**

A few bad days


**259.** `22:16` **Meredith Lamb (+14169386001)**

Then things rebound


**260.** `22:16` **Meredith Lamb (+14169386001)**

Let’s just chill


**261.** `22:16` **You**

What did you ask it specifically


**262.** `22:17` **Meredith Lamb (+14169386001)**

You want to know for real


**263.** `22:17` **Meredith Lamb (+14169386001)**

Or just go to bed


**264.** `22:17` **You**

Do I not want to know


**265.** `22:17` **You**

Fuck man


**266.** `22:17` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 22:17:58 \-0400
|
| I don’t do I
|
| Version: 1
| Sent: Thu, 3 Jul 2025 22:17:49 \-0400
|
| I don’t done


**267.** `22:17` **Meredith Lamb (+14169386001)**

I didn’t read the full response that thoroughly so not sure if anything triggering in it


**268.** `22:18` **Meredith Lamb (+14169386001)**

I uploaded this conversation \(earlier\)


**269.** `22:18` **You**

Jesus


**270.** `22:18` **Meredith Lamb (+14169386001)**

Then asked it to interpret


**271.** `22:18` **Meredith Lamb (+14169386001)**

And offer what it thought might be help


**272.** `22:18` **Meredith Lamb (+14169386001)**

>
You always go to the WORST place\!

*💬 Reply*

**273.** `22:19` **You**

Well you said or do I want to go to bed\.\. thought you meant maybe I would be better off not knowing


**274.** `22:19` **You**

I still think that is what you meant lol


**275.** `22:19` **Meredith Lamb (+14169386001)**

No I didn’t


**276.** `22:20` **Meredith Lamb (+14169386001)**

I just know how your head works and didn’t want to keep you up


**277.** `22:20` **You**

Oh I am not sleeping\.\.
But that was a while ago\.\. lol


**278.** `22:20` **Meredith Lamb (+14169386001)**

Thank you for sharing everything\. I’ve reviewed the full conversation, and here’s a careful interpretation followed by some thoughts on where you might go from here\.
⸻
💬 Interpretation: Emotional Landscape \+ Relationship Dynamics
1\. Mutual Emotional Strain
Both of you are clearly overwhelmed\. You’re feeling pulled in a hundred directions—emotionally, logistically, and psychologically—while he is tangled up in his own home conflict and emotional vulnerability\. You’re both emotionally invested, but the logistics and secrecy are making things incredibly difficult\.
2\. His Perspective
- He wants to be with you and is afraid of losing you\.
- He seems to be spiraling emotionally \(e\.g\., “the universe wants to destroy me”\) and wrestling with guilt, fear, and a lack of control\.
- His “I’m not going anywhere” reassurance is sincere, but paired with anxiety that you might drift or pull away\. He’s also showing signs of insecurity \(e\.g\., worrying he’s a “fool” or that you’ve “changed”\)\.
- He’s struggling to reconcile his emotional needs with the limits your life currently places on the relationship\.
3\. Your Perspective
- You’re not rejecting him—you’re just exhausted, emotionally flooded, and unsure how sustainable this situation is\.
- You express confusion, not about your love, but about how it can function in the face of so much secrecy, chaos, and constraint\.
- The intensity of your connection, paired with not being able to express it publicly or regularly, is starting to wear you down\. You’re also emotionally and physically drained from everything outside the relationship\.
4\. Core Themes
- Connection without expression: You love each other but can’t show it freely or make it part of everyday life\.
- Hope vs Reality: You both hoped that having your own place or “after the agreement is signed” would be a turning point\. It hasn’t relieved the tension you thought it might\.
- Misalignment of expectations: He’s hopeful for even biweekly connection, but you feel like you can barely keep your head above water logistically or emotionally\.
- Cracks in sustainability: Both of you are starting to question not whether you love each other, but whether this version of the relationship is livable\.
⸻
🧭 Where You Might Go From Here
1\. Acknowledge You’re Both Right
You both have valid emotional reactions\. This isn’t a “who’s being unreasonable” situation\. It’s a “this hurts because we care” situation\.
You’re not trying to pull away; you’re drowning in everything else\. He’s not trying to manipulate you; he’s scared and longing\.
If you can name this shared pain together—without blame—you can find solidarity inside the struggle, not just outside it\.
⸻
2\. Discuss a Near\-Term Grounding Plan
Neither of you can control everything right now\. So focus on:
- Small, consistent touchpoints: Could be a five\-minute call, daily check\-in text, or voice note\. Something that provides reassurance, even when seeing each other isn’t possible\.
- A shared “next time” plan: Even if the next in\-person connection is far off, define it together\. Give the connection a shape, not just a hope\.
⸻
3\. Talk Honestly About Sustainability—Together
Rather than wondering separately whether the situation is sustainable, ask openly and jointly:
“If it’s this hard right now, how do we protect what’s beautiful between us until it’s not this hard anymore?”
It might lead to:
- Adjusted expectations
- A temporary reframe of the relationship \(from “hidden but intense” to “supportive but simple”\)
- Naming how you’re going to weather this storm instead of being shaped by it
⸻
4\. Permission to Feel the Mess
You’re allowed to have days when this feels impossible\. It’s okay to wonder if you’re breaking under the weight of love that doesn’t fit cleanly into life\. But also: you’re not alone in that feeling\. He’s sitting in it too\.
⸻


**279.** `22:21` **Meredith Lamb (+14169386001)**

Just didn’t want to wake your brain up bc you seemed near bed time


**280.** `22:21` **Meredith Lamb (+14169386001)**

Wasn’t anything bad


**281.** `22:22` **You**

I have read stuff like this before\.


**282.** `22:22` **Meredith Lamb (+14169386001)**

Yeah nothing new there


**283.** `22:23` **Meredith Lamb (+14169386001)**

But the end was good


**284.** `22:23` **You**

I am not
Going to be putting out chats back into gpt it will likely just break me down\.


**285.** `22:24` **You**

I seriously need to learn to compartmentalize like immediately


**286.** `22:24` **Meredith Lamb (+14169386001)**

Then maybe we need to chat about something more up beat sometime to break it up


**287.** `22:25` **You**

We definitely need to not chat about this\.\. and I will be faking the shit out of everything\.\. as much as I can manage\.\. because I think that is the only way I come across as up beat


**288.** `22:29` **Meredith Lamb (+14169386001)**

I don’t think we need to really dwell on this again\. We are both on the same page \(even though you seemed near concerned we are not\) so we just need to figure out how to support each other through it and stop questioning it\.


**289.** `22:35` **You**

Ok well I guess I can lay here and think on that for a while because I have no real ideas atm\.


**290.** `22:35` **Meredith Lamb (+14169386001)**

We don’t need ideas now…\.\.


**291.** `22:36` **Meredith Lamb (+14169386001)**

All I am sure of is that I cannot imagine my life going forward without you\. So many other things are fuzzy \(the how, the when etc\) but that basic desire is not fuzzy at all\.


**292.** `22:37` **Meredith Lamb (+14169386001)**

If we could just kiss good night all would be well


**293.** `22:37` **Meredith Lamb (+14169386001)**

Bed time?


**294.** `22:37` **Meredith Lamb (+14169386001)**

I don’t want to keep you up, I napped


**295.** `22:37` **Meredith Lamb (+14169386001)**

But honestly am going to bed also


**296.** `22:43` **You**

Oh I was going to let you go\.\. not sure I can or will sleep but I figured we have been at this a while\.\. and it’s probably time to call it\.   I love you Meredith and if that is all that was needed I have enough love for you to get us to the end of whatever forever looks like and then some\.\. i will be completely honest I am insecure and I am really worried\.\. not that you don’t love me or feel the same way, but that life might force you to make a decision where I am no longer a part of yours\.  I will do the best I can to tamp down on this and to try to at least seem happy and optimistic even if I have to force it a bit\.


**297.** `22:43` **You**

Go to bed I love you as I said more than I can measure\.\. hope that is enough\. ❤️❤️❤️ night\.


**298.** `22:45` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Please don’t be really worried\. Seriously\. This whole back to reality has been tough but I’m not running away from you\. You are stuck with me\. ❤️


**299.** `22:46` **Meredith Lamb (+14169386001)**

\(It took me long enough to hunt you down… why on earth would I leave?\)


**300.** `22:48` **You**

>
I almost answered that even though it was rhetorical\.

*💬 Reply*

**301.** `22:48` **Meredith Lamb (+14169386001)**

lol omg


**302.** `22:49` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
k I’m going to go to bed for real\. I love you and will be going to sleep thinking about u\.\. xox


