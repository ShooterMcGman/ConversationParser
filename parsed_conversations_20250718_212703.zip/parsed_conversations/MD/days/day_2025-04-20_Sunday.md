# Daily Conversation: 2025-04-20 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-20 |
| **Day** | Sunday |
| **Week** | 2 |
| **Messages** | 1185 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-20T02:56 - 2025-04-20T22:46 |

## 📝 Daily Summary

This day contains **1185 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `02:56` **You**

Reaction: 😮 from Meredith Lamb
ok sorry hon\.\. had to come home\.\. clean the kitchen get bitched at get asked if I would still do a family grad trip to mexico over christmas\.\. and awkward silence\.\. then retreat down here to sarcastic comments from J\.


**002.** `02:56` **You**

Whee


**003.** `02:57` **You**

Hope you are being left alone now at least


**004.** `02:58` **You**

was annoyed


**005.** `02:58` **You**

Reaction: 🙄 from Meredith Lamb
I cooked supper and cleaned up as I went J said she had kitchen get home all sitting on couch\. watching renno show\.\. I put headphones in turn on music and get cleaning then get criticized for listening to music\.\. rofl\.\.


**006.** `02:59` **You**

what is chatgpt saying\.\.


**007.** `02:59` **You**

your boyfriend is a wierdo


**008.** `02:59` **You**

probably


**009.** `02:59` **You**

and I have decided that is what I am'


**010.** `02:59` **You**

I feel it does


**011.** `03:00` **You**

Cause I like organization\.\.


**012.** `03:00` **You**

and boxes


**013.** `03:00` **You**

and clarity


**014.** `03:00` **You**

and certainty


**015.** `03:00` **You**

and I think there is a degree of certainty that comes with that label / box


**016.** `03:01` **You**

She must be getting some kind of kick out of this


**017.** `03:02` **You**

>
Perfect ☺️

*💬 Reply*

**018.** `03:02` **You**

Now I can tell everyone at work that I have a girlfriend\!\!


**019.** `03:03` **You**

I have thought about that alot btw


**020.** `03:04` **You**

>
thought about this\.\. I mean\. tbh never believed\.\. not even a bit\.\. I think I told you about the Disney bullshit expectations \-\-\- and I still don't believe in that\.\. but maybe the soulmate thing might have something to it??  Feels like it could\.

*💬 Reply*

**021.** `03:05` **You**

Reaction: 😮 from Meredith Lamb
So I went and saw a house in North Oshawa today\.


**022.** `03:06` **You**

>
actually before I move on\.\. no it feels like it is\.\. which is kind of scary in and of itself\. From someone who never believed\.

*💬 Reply*

**023.** `03:07` **You**

anyways this house in north oshawa\.\. not the nicest but I could probably make it work \- would be an absolute SHIT drive\.\. it would go for around 620k\.\. and no basement :\(


**024.** `03:07` **You**

So probably keep trying to find something in Whitby\.  She is gonna have the nice house\. lol no mortgage and I am going to pay for property taxes and all the utilities\.  And I will live in a shithole ROFL\.


**025.** `03:08` **You**

I don't even care\. I can clean something up make it nice enough for me\.


**026.** `03:22` **You**

>
yeah that is what I mean I am not sure what it is\.\. thus the soulmate thing\.\. unsure how to characterize it\.

*💬 Reply*

**027.** `03:23` **You**

>
I mean we should\.\. I think about it a lot\.\. but there is a lot of planning between now and then\.\. and you have to see if you even like being around me\.\. I mean come on\.\. I am such a pain in the ass\.

*💬 Reply*

**028.** `03:23` **You**

but that is definitely what I want


**029.** `03:24` **You**

I think I have to balance my desire with time and the optics from my kids\.\. there has to be a timeline that works\.


**030.** `03:25` **You**

They are all crazye


**031.** `03:26` **You**

I think you definitely need your space for sure\. refocus on yourself\.


**032.** `03:26` **You**

it's important\.\. when I was at Dad's I felt amazing


**033.** `03:26` **You**

I mean i missed my kids\.\.


**034.** `03:26` **You**

but man I felt good


**035.** `03:26` **You**

went to bed at like 10


**036.** `03:27` **You**

up at 5 workout breakfast walk the dog\.


**037.** `03:27` **You**

lost 20 more lbs when I was back in moncton


**038.** `03:28` **You**

here listen to this oldy but a goody


**039.** `03:28` **You**

https://open\.spotify\.com/track/42oNny7A4CqwQzmCLTRXv9?si=c8d60eb5f9b542da


**040.** `03:28` **You**

not my usual


**041.** `03:28` **You**

but the words are kind of nice


**042.** `03:29` **You**

I am not a big fan of the pause


**043.** `03:31` **You**

rofl\.\. good song\.\.


**044.** `03:31` **You**

I mean I like faith and freedom of course\.\.


**045.** `03:32` **You**

and the don't let the sun go down on me with elton john was a classic\.


**046.** `03:32` **You**

so I know george a bit


**047.** `03:32` **You**

but no poster


**048.** `03:32` **You**

yeah I know


**049.** `03:32` **You**

andrew


**050.** `03:32` **You**

don't hate elton because of andrew\.


**051.** `03:33` **You**

>
must be nice\.\. eesh

*💬 Reply*

**052.** `03:33` **You**

best I get from work are raptors tickets


**053.** `03:33` **You**

lol


**054.** `03:33` **You**

good seats though


**055.** `03:34` **You**

Reaction: 😂 from Meredith Lamb
knowing our luck we go get on the kissing cam and J is watching\.


**056.** `03:34` **You**

lol


**057.** `03:36` **You**

wtf\.\. Passe\-Partout just popped up on my Spotify


**058.** `03:36` **You**

do you remember that show or did you not get that one?


**059.** `03:37` **You**

rofl\.\.


**060.** `03:37` **You**

it is an old French tv show for kids\.


**061.** `03:37` **You**

I can still remember the opening song and scene\.\. I always thought it was creepy\.\.


**062.** `03:38` **You**

so you in bed for the night?


**063.** `03:38` **You**

just getting a mental image\.


**064.** `03:38` **You**

hey listen\.\. you have talked to me for months now\.\. I know this isn't normal\.\. I am not this forward\.\. I have no clue what has happened\./


**065.** `03:39` **You**

she is going to be sad isn't she


**066.** `03:39` **You**

that is gonna suck


**067.** `03:40` **You**

she knows what


**068.** `03:40` **You**

us


**069.** `03:41` **You**

Mummy why is all this skin scraped off back here in the back of the buick?


**070.** `03:41` **You**

my elbow hurts


**071.** `03:41` **You**

you could see it in the video I think\.\. right elbow


**072.** `03:42` **You**

ON squats


**073.** `03:42` **You**

first video back of right elbow


**074.** `03:43` **You**

yeah\.\. I know exactly how and when I got that too\.


**075.** `03:43` **You**

and I didn't care at the time


**076.** `03:44` **You**

lol yeah\.\. uncomfortable but fun\.\. it just sucks that we have to cram it all into a short timeframe\.\. that is what is so annoying\.\. I want to go out and hold hands go for a walk go to a bar get a drink grab some supper\.\. walk the dogs\.\. and then all the other stuff\.


**077.** `03:46` **You**

detach?


**078.** `03:46` **You**

What\.\. do you think this is about the chase\.\.


**079.** `03:46` **You**

the chase is annoying\.\. the fun happens later


**080.** `03:47` **You**

mer you have an amazing mind too\.\. you are so much fun just to talk to\.\.\. I will never get tired of you\.\. I just don't see it\.\. I feel like we will just keep evolving as we get older\.\. that's all\.


**081.** `03:48` **You**

you shouldn't  you are more exciting than I am\.\.


**082.** `03:49` **You**

I don't think I ever really attached\.\. I think I told you\.\. she was nice\.\. I cared for her\.\. loved her\.\. but was never in love with her\.\. like not even before we were married\.


**083.** `03:49` **You**

I had kind of gone berserk for about 4\.5 years


**084.** `03:49` **You**

and felt\.\. well this is just what comes next and this isn't a bad girl to be with\.


**085.** `03:49` **You**

but even my mum was like wtf


**086.** `03:50` **You**

I mean she always liked J but she never understood


**087.** `03:50` **You**

Yeah I don't remember much of the wedding\.\. I mean we weren't unhappy\.\. especially early on\.


**088.** `03:50` **You**

But I never felt drawn to her\.


**089.** `03:50` **You**

J was not my type at all


**090.** `03:50` **You**

opposite


**091.** `03:50` **You**

Mum was didn't get it\.


**092.** `03:50` **You**

She wanted me to go back to Cheyenne


**093.** `03:50` **You**

lol


**094.** `03:51` **You**

I feel like she did\.\.  but while J was opposite she complemented me in some ways\.


**095.** `03:51` **You**

and we did have fun\.\. there just was never that spark\.


**096.** `03:51` **You**

I honestly did try to find it\.\. but couldn't


**097.** `03:52` **You**

then the pleaser in me takes over\.


**098.** `03:52` **You**

so I work hard\.\. get ahead try to give her whatever I can \- because she grew up with literally nothing\.


**099.** `03:52` **You**

then that just continued until now\.


**100.** `03:53` **You**

don't get me wrong\.\. I disconnected from her\.\. we fought\.


**101.** `03:53` **You**

I didn't have any desire\.\.


**102.** `03:53` **You**

so I hid in games\.


**103.** `03:53` **You**

then I got so miserable that games didn't even do anything for me\.\. nothing did\.


**104.** `03:53` **You**

then I started working 16 hours a day


**105.** `03:54` **You**

I feel like that has to be the case\.\. the timing\.\. the connecting when we did \- my hiring you


**106.** `03:54` **You**

bringing you over to my team again


**107.** `03:54` **You**

lol


**108.** `03:54` **You**

always right place right time\.\.


**109.** `03:55` **You**

Reaction: 😂 from Meredith Lamb
Someday when we talk to him about this I am going to hug him and pick him up off the ground


**110.** `03:55` **You**

yep that would have sucked a lot\.\.


**111.** `03:56` **You**

lol\.\. I haven't spoken with him in years\.\. I am not surprised\.\. I was more the guy who helped him do his work\.\. lol


**112.** `03:56` **You**

He fucking sucked at excel


**113.** `03:56` **You**

LIKE BAD


**114.** `03:58` **You**

w/e I solved the triangle math problem while stoned\.


**115.** `03:58` **You**

rofl no it wasnt


**116.** `03:58` **You**

man are you attracted to people that can do math while high


**117.** `03:59` **You**

well so am I\.\. so there\.


**118.** `03:59` **You**

I need to know what it is called


**119.** `00:00` **Meredith Lamb (+14169386001)**

Wait


**120.** `00:00` **Meredith Lamb (+14169386001)**

You have never researched this?


**121.** `04:00` **You**

nope


**122.** `00:00` **Meredith Lamb (+14169386001)**

Sapiosexuality


**123.** `04:00` **You**

wtf


**124.** `04:00` **You**

now I am looking it up


**125.** `00:00` **Meredith Lamb (+14169386001)**

ChatGPT that


**126.** `00:00` **Meredith Lamb (+14169386001)**

lol


**127.** `00:01` **Meredith Lamb (+14169386001)**

It is kind of how Andrew tricked me


**128.** `00:01` **Meredith Lamb (+14169386001)**

He is SUPER smart


**129.** `00:01` **Meredith Lamb (+14169386001)**

Was gifted blahblahblah


**130.** `04:01` **You**

he uses big words too\.


**131.** `00:01` **Meredith Lamb (+14169386001)**

Haha just really smart and tricked me with it


**132.** `00:02` **Meredith Lamb (+14169386001)**

Weakness of mine


**133.** `04:02` **You**

hmmm\.\. well\.\. I was really smart\.\. aren't you worried\.\. I mean my east coast does kind of tone it down\.\. lol


**134.** `00:02` **Meredith Lamb (+14169386001)**

I know you are smart\. Obviously


**135.** `00:03` **Meredith Lamb (+14169386001)**

We wouldn’t be talking right now otherwise


**136.** `04:03` **You**

I did the whole enrichment bullshit when I was a kid\.\.  computer programming in grade 4 all that shit\.\. I just liked sports, trouble, fun more\.


**137.** `00:04` **Meredith Lamb (+14169386001)**

Trust me, there are many moments at work that impact me and you have no idea\. That is all I will say in that\.


**138.** `04:05` **You**

ok tongue in cheek watch this\.\.


**139.** `04:05` **You**

https://www\.youtube\.com/watch?v=s2qNgWKqJYc


**140.** `04:07` **You**

>
You always impressed me at work \- you are really highly regarded\.\. your talent was anticipation\.\. you would look beyond the request to figure out what the person asking the question didn't even know they wanted and then give it to them on a silver platter\.  The more I worked with you the more I was just like shit \- she is being completely wasted here\.\. she is way too smart for this\.

*💬 Reply*

**141.** `04:08` **You**

kk that was a freudian slip\.


**142.** `04:08` **You**

you had the ability to anticipate\.\.


**143.** `04:08` **You**

I am feeling anticipation\.


**144.** `04:08` **You**

ROFL


**145.** `04:08` **You**

did you get to the I like big words part?  lol


**146.** `00:11` **Meredith Lamb (+14169386001)**

>
I don’t remember that\. So funny\. I guess I can relate\. lol that guy is in the new season of handmaid’s tale\!

*💬 Reply*

**147.** `04:11` **You**

He is also a main character in the goodwife


**148.** `04:11` **You**

among other things


**149.** `04:11` **You**

Did you ever see Threesome?


**150.** `04:11` **You**

that was the movie


**151.** `04:12` **You**

was kind of like a cult classic back in the 90's


**152.** `00:12` **Meredith Lamb (+14169386001)**

>
Nope

*💬 Reply*

**153.** `04:12` **You**

I mean it was a bit out of my wheelhouse\.\. I think it ended up getting played at one of our parties


**154.** `04:12` **You**

Reaction: ❤️ from Meredith Lamb
I am more Dazed and Confused


**155.** `00:13` **Meredith Lamb (+14169386001)**

So what is your “wheelhouse”?


**156.** `04:13` **You**

well\.\.\. I mean it is kind of a big wheelhouse\.\.


**157.** `04:13` **You**

but threesome was never really in it\.\.


**158.** `00:13` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
Best movie ever

*💬 Reply*

**159.** `00:14` **Meredith Lamb (+14169386001)**

>
I mean like romantic relationship attraction wise?

*💬 Reply*

**160.** `04:14` **You**

hmm\.


**161.** `00:14` **Meredith Lamb (+14169386001)**

Have you ever thought about it


**162.** `04:14` **You**

gimme a min\.\. I have a few that I can dredge up


**163.** `04:14` **You**

oh no I was a romantic before I wasn't


**164.** `04:14` **You**

big time


**165.** `04:14` **You**

I think this is a resurgeance


**166.** `00:14` **Meredith Lamb (+14169386001)**

>
Very obvious

*💬 Reply*

**167.** `04:15` **You**

sorry one min distracted \- further research on Sapiosexuality\.


**168.** `00:16` **Meredith Lamb (+14169386001)**

lol 😂


**169.** `04:17` **You**

eeek


**170.** `00:18` **Meredith Lamb (+14169386001)**

?


**171.** `04:18` **You**

I asked a question and got an answer I wasn't expecting\.


**172.** `04:18` **You**

will have to see how far out of my box I can stretch


**173.** `00:19` **Meredith Lamb (+14169386001)**

I mean it has been a big day for that\. Might as well keep going 🙃


**174.** `04:20` **You**

I was curious \- if someone is Sapiosexual \- which I think I am partly\.\. maybe not as much as you though\.\. how to carry over the connection into the physical \- and it had some suggestions that I am not entirely thinking I am capable of ROFL\.


**175.** `04:20` **You**

I mean some \- most sure\.


**176.** `00:20` **Meredith Lamb (+14169386001)**

lol really


**177.** `00:20` **Meredith Lamb (+14169386001)**

Share


**178.** `04:20` **You**

it is just about maintaining open communication\.


**179.** `04:21` **You**

before, after,\.\.\.\. during\.\.\.\. errrr


**180.** `04:21` **You**

lol


**181.** `00:21` **Meredith Lamb (+14169386001)**

lol


**182.** `00:21` **Meredith Lamb (+14169386001)**

Just share it


**183.** `04:21` **You**

before and after\.\. I got it\.\.


**184.** `04:21` **You**

sec


**185.** `00:21` **Meredith Lamb (+14169386001)**

Are you editing


**186.** `04:21` **You**

No


**187.** `04:21` **You**

I will share everything including the prompts


**188.** `04:22` **You**

Can you tell me about saposexuality? Is it more common with people in their middle years?
Show thinking
Okay, let's break down sapiosexuality based on your preferences\.
Core Concepts: Sapiosexuality
Definition: Sapiosexuality describes a type of attraction where a person finds high levels of intelligence \(the "mind"\) to be the most sexually attractive feature in another person\.
Primary Driver: For someone identifying as sapiosexual, intelligence isn't just a desirable trait; it's the primary trigger for sexual or romantic attraction, often outweighing physical appearance, social status, or other common factors\.
Mechanism: The attraction often stems from the quality of conversation, intellectual depth, wit, curiosity, and how someone thinks and expresses their thoughts\.
Addressing Your Specific Question: Prevalence in Middle Years
Lack of Evidence: There is no significant scientific data or reliable research to indicate that sapiosexuality is inherently more common among people in their middle years \(e\.g\., roughly 40s\-60s\) compared to younger or older adults\.
Origin & Study: The term is relatively new in mainstream discussion, largely popularized through online platforms and dating apps within the last decade or so\. Formal demographic studies on its prevalence across different age groups are scarce to non\-existent\.
Possible Speculation \(Not Fact\): One might speculate that maturity could lead some individuals to prioritize non\-physical traits like intellect more than they did when younger\. Life experience might shift focus towards compatibility in thought and conversation\. However, this is purely theoretical and doesn't mean sapiosexuality as a primary driver of attraction specifically increases with middle age\. Many young people also prioritize intelligence\.
Further Context and Considerations \(Candid & Critical Perspective\)
Orientation vs\. Preference Debate:
There's considerable debate about whether sapiosexuality qualifies as a distinct sexual orientation \(like heterosexuality, homosexuality, bisexuality, asexuality\) or if it's better described as a strong preference within one's existing orientation\.
Many people, regardless of orientation, find intelligence attractive\. The key differentiator claimed by sapiosexuality is the primacy of intelligence over essentially all else\.
It's generally not included in the LGBTQ\+ acronym or recognized in the same way as established sexual orientations\.
Criticisms & Nuances:
Elitism/Ableism Concerns: Critics argue the term can come across as elitist, potentially valuing specific types \(often academic or verbal\) of intelligence over others \(e\.g\., emotional, practical, artistic intelligence\)\. It could also be seen as inadvertently exclusionary towards people with cognitive disabilities\.
Redundancy Argument: Some feel the term is unnecessary because finding intelligence attractive is a common human experience, not requiring a special label\.
Overlap with Demisexuality: There can be overlap\. Demisexuality involves needing a strong emotional bond before feeling sexual attraction\. Deep intellectual connection, often central to sapiosexuality, is a powerful way to build such an emotional bond\.
Analogy \(Relating to Familiar Concepts\):
Think about preferences in food\. Most people enjoy flavorful food \(analogous to generally finding attractive people appealing\)\. Someone might have a strong preference for spicy food – they actively seek it out and enjoy it more than other flavors \(analogous to someone strongly preferring partners who are, say, kind or funny\)\. Sapiosexuality would be like someone saying the only thing that makes food appealing at all is if it's intensely spicy; without that specific heat, they have no interest, regardless of other qualities like texture or presentation \(analogous to intelligence being the necessary and primary trigger for attraction, overriding looks, etc\.\)\.
Summary:
Sapiosexuality is defined as being primarily sexually attracted to intelligence\. While an interesting concept describing a specific focus of attraction, there's currently no evidence to support the idea that it's more common in middle age\. The term itself is relatively new to popular use and is subject to ongoing discussion and critique regarding its classification and potential implications\.
Sources and related content
What Does It Mean to Be Sapiosexual? \- Verywell Mind
www\.verywellmind\.com
Sapiosexual: What It Means \- WebMD
www\.webmd\.com
Could I be sapiosexual? \- Happiful Magazine
happiful\.com
Why Intelligence Is So Sexy to So Many, and When It isn't \- Psychology Today
www\.psychologytoday\.com
Sexual Orientation: 4 Common Questions \- WebMD
www\.webmd\.com
So what turns on someone that is Sapiosexual?
Show thinking
Okay, building on the definition, here's what typically "turns on" someone who identifies as sapiosexual, focusing on the triggers for their attraction and potential arousal:
Core Triggers for Sapiosexual Attraction:
Deep, Stimulating Conversation: This is often paramount\. Engaging in discussions that are insightful, analytical, philosophical, witty, or explore complex ideas can be highly attractive\. It's about the quality and depth of the verbal exchange\.
Demonstrations of Intellect: Seeing or hearing someone:
Articulate complex thoughts clearly and eloquently\.
Display sharp wit or clever humor\.
Solve problems creatively or analytically\.
Show deep knowledge or passion about a particular subject \(and explain it well\)\.
Engage in skillful debate or logical reasoning\.
Exhibit intellectual curiosity and a genuine desire to learn\.
The Mind in Action: It's often less about static intelligence \(like an IQ score or a degree\) and more about observing intelligence dynamically – how someone thinks, processes information, connects ideas, and expresses their inner world\.
Intellectual Challenge: Being mentally stimulated or even challenged by the other person's intellect can be a significant turn\-on\.
Wit and Wordplay: Clever use of language, puns, or sharp banter often appeals strongly\.
Insight and Perspective: Someone offering unique, insightful perspectives on various topics can be very attractive\.
Elaboration:
Think of it less like a checklist and more about the experience of interacting with someone's mind\. For a sapiosexual individual, the excitement or arousal might build during a fascinating conversation, while listening to someone passionately explain something complex, or during a shared moment of intellectual discovery or clever banter\.
The "turn on" is the mental connection, the spark that comes from recognizing and appreciating the way someone else's mind works\. It's the feeling of being engaged, stimulated, and sometimes even awed by their intellectual capabilities or the way they express their thoughts\.
Important Nuance:
While intelligence is the primary driver, it doesn't necessarily mean other forms of attraction are entirely absent\. However, the intellectual component is the essential gateway and the most powerful element for igniting significant romantic or sexual interest\. What one person considers an attractive display of intelligence might also differ from another's preference \(e\.g\., some might prefer analytical prowess, others creative genius, others emotional intelligence expressed thoughtfully\)\.
In essence, if intelligence is the main course, everything else is secondary\. The way someone thinks and communicates that thinking is the core of what ignites attraction for a sapiosexual person\.
So how do I integrate this with physical intimacy to its maximum effect
Show thinking
Okay, this is about weaving that mental connection into the physical experience to amplify it\. If attraction is significantly sparked by intellect \(sapiosexual traits\), then integrating that spark into physical intimacy is key for maximizing satisfaction and connection\. Think of the intellectual stimulation not just as a prerequisite, but as an integral part of the entire intimate experience – before, during, and after\.
Here’s how you can approach integrating this for maximum effect:
Strategies for Integration:
Intellectual Foreplay is Crucial: Treat stimulating conversation and mental engagement as essential foreplay\.
Verbalize the Mental Attraction: Express why you find your partner intellectually stimulating, even during physical moments\.
Bridge the Mental & Physical: Consciously link the appreciation for their mind with the physical act\.
Maintain Presence: The focus and engagement required for deep conversation can translate into focused presence during intimacy\.
Post\-Intimacy Connection: Continue the blend of intellectual and physical closeness afterward\.
Elaborating on the Strategies:
Make Intellectual Engagement Purposeful Foreplay:
Don't Separate Them: Instead of having a deep talk then shifting gears entirely, see the conversation as the start of the intimate encounter\. Let the energy build from there\.
Examples:
Engage in a topic you both find fascinating right before initiating physical touch\. Let the excitement from the ideas flow into physical excitement\.
Share something insightful you read or thought about, specifically highlighting why you wanted to share it with her\.
Engage in witty banter or playful intellectual teasing that builds connection and sparks energy\.
Read something stimulating or evocative aloud to each other\.
Verbal Affirmation During Intimacy:
Connect Mind to Body: Don't just compliment physical attributes\. Explicitly state your attraction to her mind during the physical experience\.
Examples: Whisper things like, "I love how your mind works," "Talking with you earlier was such a turn\-on," "You're so incredibly smart, and that's so attractive," or reference a specific insightful thing she said\.
Why it Works: It validates the core trigger of attraction \(her intelligence\) and reinforces that the physical intimacy is deeply connected to who she is intellectually, making the experience feel more holistic and potent for someone aroused by intellect\.
Let the Mental Spark Fuel the Physical:
Carry the Feeling: Bring the feeling generated by the intellectual connection \(excitement, admiration, engagement\) into the physical interaction\.
Analogy: Think of how listening to a piece of music you love \(mental/emotional stimulation\) can make a physical activity like dancing or driving feel more intense and enjoyable\. The intellectual "charge" can similarly amplify the physical sensations\.
Focus on the 'Why': Remind yourself that the physical closeness is an expression of that deeper appreciation for her way of thinking and being\.
Shared Presence and Focus:
Mirror Mental Engagement: The intense focus you might have during a captivating discussion? Bring that level of focused attention to your partner's body, reactions, and the shared physical experience\. Being fully present bridges the mental and physical divide\.
Non\-Verbal Cues: This focus communicates appreciation as effectively as words sometimes\.
Blend Connection in Aftercare/Pillow Talk:
Continue the Dialogue: After intimacy, don't immediately switch off the connection\. Continue talking, perhaps reflecting on the shared experience, revisiting interesting points from earlier, or simply enjoying the quiet connection that follows both mental and physical closeness\.
Reinforce the Bond: Express appreciation for both the physical intimacy and the mental connection you share\.
Key Principle for Maximum Effect:
The goal is synergy\. Don't treat the mind and body as separate arenas\. For someone turned on by intellect, the most powerful intimate experiences often happen when the mental stimulation and the physical expression feel seamlessly integrated\. The intellectual attraction isn't just a key to unlock the door to physical intimacy; it's meant to be part of the experience inside the room\.
Crucial Caveat: Communication with Your Partner
Talk About It: Discuss this with your wife\. What aspects of intellectual connection does she find most engaging or attractive? How does she feel about blending verbal appreciation of her mind with physical intimacy? Her preferences and comfort are paramount\.
Mutual Experience: Intimacy is shared\. Ensure these approaches enhance the experience for both of you\. It should feel authentic and connecting, not forced or performative\.
By consciously weaving appreciation for the mind into the fabric of physical intimacy, you can potentially create a more profound, satisfying, and uniquely connected experience, especially if sapiosexual traits are a strong component of attraction for either or both of you\.


**189.** `04:23` **You**

Now I asked the middle years question \- because I kind of had the same logical conclusion as Gemini did \- as you get older you tend to evolve and appreciate a more nuanced relationship\.\. not just purely physical\.\. I kinda was never about that anyways\.


**190.** `04:24` **You**

I mean the verbal affirmation during I was like \- what??? I am not saying that\.\. she will laugh her ass off at me\.


**191.** `04:27` **You**

hrm you are really processing this eh\.


**192.** `04:27` **You**

lots of big words in there?  🫠


**193.** `00:27` **Meredith Lamb (+14169386001)**

That was so long\!


**194.** `00:28` **Meredith Lamb (+14169386001)**

That explained you though :\)


**195.** `04:27` **You**

yep a lot to process


**196.** `00:28` **Meredith Lamb (+14169386001)**

It was pretty accurate on my end


**197.** `00:28` **Meredith Lamb (+14169386001)**

It is not a middle age thing for the record


**198.** `00:28` **Meredith Lamb (+14169386001)**

Even high school


**199.** `04:28` **You**

Yeah I mean I can kind of see how this could evolve especially with most of the relationship development coming through sharing thoughts etc through these chats\.


**200.** `04:29` **You**

for me trying to engage you\.\. was like I will use any medium I can\.


**201.** `04:29` **You**

If you said you liked art instead of music


**202.** `04:29` **You**

I mean to be clear I LOVE MUSIC and I am not an Art fan really\.


**203.** `04:29` **You**

But I would have built a connection


**204.** `04:29` **You**

or at least used art to convey my feelings


**205.** `04:30` **You**

like I did with music


**206.** `04:30` **You**

I am an odd duck\.\. I know\.


**207.** `04:31` **You**

I mean I appreciate art\.\.


**208.** `00:31` **Meredith Lamb (+14169386001)**

Sorry had to switch rooms


**209.** `04:31` **You**

I have favorites


**210.** `04:31` **You**

hmm


**211.** `00:31` **Meredith Lamb (+14169386001)**

Andrew won’t leave me alone sigh


**212.** `04:31` **You**

oh marlow


**213.** `00:31` **Meredith Lamb (+14169386001)**

Anyway


**214.** `04:31` **You**

what's andrew at now?


**215.** `00:32` **Meredith Lamb (+14169386001)**

He just has no issues sleeping with me… annoying so I have to leave


**216.** `00:32` **Meredith Lamb (+14169386001)**

Anyway this might be weird to say


**217.** `00:32` **Meredith Lamb (+14169386001)**

I know you hate that word


**218.** `04:32` **You**

say whatever you need to


**219.** `00:33` **Meredith Lamb (+14169386001)**

But when I first started working for you I liked your brain, intelligence, etc etc etc


**220.** `00:33` **Meredith Lamb (+14169386001)**

This is not a new found thing


**221.** `04:33` **You**

well that isn't weird\.


**222.** `04:33` **You**

now that I have researched it


**223.** `04:33` **You**

and it has a lable


**224.** `00:33` **Meredith Lamb (+14169386001)**

Maybe a little


**225.** `04:33` **You**

and a box


**226.** `04:33` **You**

so I am good


**227.** `04:33` **You**

lol


**228.** `04:34` **You**

btw I can type fast now because I have downloaded this as an app to my comp


**229.** `04:34` **You**

easier to hide\.


**230.** `00:34` **Meredith Lamb (+14169386001)**

See, smart


**231.** `04:34` **You**

>
J has suggested this a few times\.\. I politely but firmly suggest it would be a bad idea, and that isn't really where my head is at\.

*💬 Reply*

**232.** `00:35` **Meredith Lamb (+14169386001)**

Yeah Andrew is just pushy and inconsiderate so…


**233.** `04:35` **You**

well both sleeping and the other thing\.\. still no  lol


**234.** `04:36` **You**

Yeah J isn't really like that\.\. but doesn't like no\.


**235.** `00:36` **Meredith Lamb (+14169386001)**

I don understand how you, as a male, can reject that?


**236.** `00:37` **Meredith Lamb (+14169386001)**

Andrew would be all over it


**237.** `04:36` **You**

sex


**238.** `04:36` **You**

it is just sex


**239.** `00:37` **Meredith Lamb (+14169386001)**

3x per week


**240.** `04:37` **You**

ROFL


**241.** `00:37` **Meredith Lamb (+14169386001)**

Yeah


**242.** `04:37` **You**

3x per week was in my 20's


**243.** `04:37` **You**

and then never


**244.** `04:37` **You**

lol


**245.** `00:37` **Meredith Lamb (+14169386001)**

Doesn’t matter if no emotional connection


**246.** `00:37` **Meredith Lamb (+14169386001)**

I don’t get it


**247.** `00:37` **Meredith Lamb (+14169386001)**

Honestly


**248.** `04:38` **You**

No\.\. that isn't me\.\. I mean I kind of did what was expected to\.\. but like honestly\.\. months and months and months\. in between\.  in an ever widening gap\.


**249.** `04:38` **You**

I just wouldn't do what I didn't want to


**250.** `00:38` **Meredith Lamb (+14169386001)**

Omg I would have been crucified


**251.** `04:38` **You**

that sounds like a very unfortunate situation


**252.** `00:39` **Meredith Lamb (+14169386001)**

Only 16 years… no biggie


**253.** `00:39` **Meredith Lamb (+14169386001)**

😭


**254.** `04:39` **You**

oh yeah\.\.


**255.** `04:39` **You**

lol


**256.** `04:39` **You**

naw no biggy


**257.** `00:40` **Meredith Lamb (+14169386001)**

One time during Covid I literally got in the car with Maelle and drove back to Toronto because I was so pissed at him over it\.


**258.** `00:40` **Meredith Lamb (+14169386001)**

Just a constant issue


**259.** `00:41` **Meredith Lamb (+14169386001)**

I guess high sex drive ppl cheat


**260.** `04:41` **You**

I mean I know I told you how I deal with the past and not trying to engage or compete etc\.\. but I kind of do feel anger towards him\.\. and I don't even know him\.


**261.** `00:41` **Meredith Lamb (+14169386001)**

Join the club :\)


**262.** `00:42` **Meredith Lamb (+14169386001)**

My therapist is in this club too


**263.** `04:41` **You**

Sex is about control\.\. to some\.\. it isn't even about the drive\.


**264.** `00:42` **Meredith Lamb (+14169386001)**

She knows soooooooo much


**265.** `04:42` **You**

It is about power


**266.** `04:42` **You**

it is about exerting authority getting what you want \- or forcing \(not in a violent way\) but making someone else give it to you\.


**267.** `04:42` **You**

I have known people like that


**268.** `00:43` **Meredith Lamb (+14169386001)**

Yes I think you are right\. To me, it is not that at all\.


**269.** `04:43` **You**

they would talk about it at the office\.\. it used to make me want to smash their faces off the desk\.


**270.** `04:43` **You**

like the Ron incident\.


**271.** `04:43` **You**

he almost ate the bar


**272.** `04:43` **You**

it was close


**273.** `00:45` **Meredith Lamb (+14169386001)**

I find it so weird he wants to stay together and just keep harassing me


**274.** `00:45` **Meredith Lamb (+14169386001)**

Just odd\. But image I guess\.


**275.** `00:45` **Meredith Lamb (+14169386001)**

Finances too


**276.** `00:45` **Meredith Lamb (+14169386001)**

Honestly has nothing to do with the me


**277.** `04:46` **You**

Well i suspect mer that approach has worked throughout your marriage \- the negotiation, sex, other things\.\. he just wears you down\.\. and keeps coming\.\. persistence\.\. it is a strategy some people use\.


**278.** `04:47` **You**

It doesn't have to be smart if it works\.\. either\.


**279.** `04:47` **You**

It has worked on me in the past\.\.


**280.** `04:47` **You**

Not for a long long long time\.\. but it did once\.\.


**281.** `00:48` **Meredith Lamb (+14169386001)**

>
You should be a therapist bc that is what mine says

*💬 Reply*

**282.** `04:48` **You**

Psyche minor :\)


**283.** `00:48` **Meredith Lamb (+14169386001)**

lol


**284.** `04:48` **You**

And I study people\.


**285.** `04:48` **You**

I have known people like Andrew\.\. and I know how to shut them donw\.


**286.** `04:48` **You**

Brandon Ott was similar to Andrew in some ways\.\. but he knew when to back down\.


**287.** `00:49` **Meredith Lamb (+14169386001)**

What would happen if you had to meet Andrew? Lol


**288.** `04:49` **You**

at least that was my interpretation of him


**289.** `00:49` **Meredith Lamb (+14169386001)**

2 years


**290.** `04:49` **You**

Reaction: ❤️ from Meredith Lamb
nothing I would shake his hand


**291.** `04:49` **You**

and see how hard he wanted to squeeze


**292.** `04:49` **You**

Reaction: 😂 from Meredith Lamb
and then make him cry


**293.** `00:50` **Meredith Lamb (+14169386001)**

It is awkward bc I already know Jaime


**294.** `04:50` **You**

I am not really worried about Andrew\.\. my what if mind has already went through 1000 scenario's how it would go what he could say to bother or hurt me\.


**295.** `04:50` **You**

again\.\. I cannot turn it off


**296.** `00:51` **Meredith Lamb (+14169386001)**

He is very non\-confrontational so wouldn’t say anything honestly


**297.** `04:51` **You**

He doesn't seem non confrontational with you\.


**298.** `04:51` **You**

that tells me something else about him


**299.** `00:52` **Meredith Lamb (+14169386001)**

Well yeah with me and girls he is very confrontational but with other ppl no\. I think at work he is too


**300.** `04:52` **You**

I think he perhaps can be a bit of a bully in certain situations\.\.


**301.** `00:52` **Meredith Lamb (+14169386001)**

He just won’t stop\. Like once Mac told me a story


**302.** `00:53` **Meredith Lamb (+14169386001)**

He wouldn’t stop talking to her about volleyball and coaching her etc \(he’s obsessed\) and she literally broke down in the car and THAT is when he stopped


**303.** `00:53` **Meredith Lamb (+14169386001)**

That has stayed with her


**304.** `00:53` **Meredith Lamb (+14169386001)**

I have so many of those situations


**305.** `00:53` **Meredith Lamb (+14169386001)**

Shared them all with my therapist lol


**306.** `04:53` **You**

😕


**307.** `00:54` **Meredith Lamb (+14169386001)**

I talked to Mac about it\. She gets it now


**308.** `00:54` **Meredith Lamb (+14169386001)**

Is what it is


**309.** `04:54` **You**

I mean I think everyone is a bit obsessed\.\. about some things\.\. J and I got in an argument about that today\.


**310.** `00:54` **Meredith Lamb (+14169386001)**

About…


**311.** `04:57` **You**

We were arguing about a bunch of shit\.\. and then she did the whole my happiness was not important enough for you to give up your career and move back to moncton, and I suggested my happiness wasn't important enough for her to make an effort to get herself to a good place where she could be happy\.\. then we went back and forth and she called me a bunch of shit\.\. I called her out\.\.etc etc\.\. But it got to a point where we were arguing about parenting\.\. and she said I was unfair because it was always about getting on my page\.\. and I said Jaimie look at where they are at and what they have learned\.\. I didn't want them to behave differently because I wanted trophy children\.\. I wanted to have them go through life differently so they would learn different lessons, and not end up in this situation\.  My obsession was about giving my kids the same opportunities and support I had


**312.** `04:57` **You**

But that didn't happen


**313.** `04:58` **You**

I just hope Andrew leaves you alone now \- or non\-confrontational or not\.\. we will meet\.\. and it will be \.\.\.\. as you would like to say\.\. interesting\.


**314.** `00:59` **Meredith Lamb (+14169386001)**

>
Yeah this is too bad that you were railroaded out…

*💬 Reply*

**315.** `04:59` **You**

he plays hockey right?


**316.** `00:59` **Meredith Lamb (+14169386001)**

lol uh yeah did you not read his “text”?


**317.** `04:59` **You**

see a great way to send a message would be for me to put the gear back on, get back into shape\.\. and join his league\.\. :\)  he wouldn't even know who I was\.


**318.** `05:00` **You**

Reaction: 😮 from Meredith Lamb
>
I don't think I did

*💬 Reply*

**319.** `01:00` **Meredith Lamb (+14169386001)**

Omg no


**320.** `01:00` **Meredith Lamb (+14169386001)**

Really?


**321.** `05:00` **You**

>
why it would be fun\.\. and confusing for him

*💬 Reply*

**322.** `05:00` **You**

and perhaps a little painful\.\. couple of open ice hits\.\.  all is fair on the ice\.


**323.** `01:01` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**324.** `05:01` **You**

jesus


**325.** `05:01` **You**

christ


**326.** `01:01` **Meredith Lamb (+14169386001)**

Yah


**327.** `05:01` **You**

OMFG


**328.** `05:01` **You**

how the FUCK does he try to walk that back?


**329.** `01:01` **Meredith Lamb (+14169386001)**

Definitely plays hockey :P


**330.** `05:02` **You**

Reaction: 😂 from Meredith Lamb
Not the same hockey I used to play lol\.


**331.** `05:02` **You**

maybe i left too young\.\. apparently this is a thing???  like wtf


**332.** `01:02` **Meredith Lamb (+14169386001)**

He plays on two teams


**333.** `01:02` **Meredith Lamb (+14169386001)**

This is the younger team night


**334.** `05:02` **You**

like the words he uses\.\. are disgusting even\.\. and terrible\.\. I would phrase that so much better\.\.\. GROSS\!\!


**335.** `05:03` **You**

I don't know why that annoys me as well but it does


**336.** `01:03` **Meredith Lamb (+14169386001)**

lol


**337.** `01:03` **Meredith Lamb (+14169386001)**

Hilarious


**338.** `05:03` **You**

I don't talk like that do I\.??


**339.** `05:03` **You**

I don't even think like that\.


**340.** `01:03` **Meredith Lamb (+14169386001)**

No


**341.** `01:04` **Meredith Lamb (+14169386001)**

Honestly he has never owned up to it and won’t talk about it


**342.** `05:04` **You**

I mean the appeal \- there is no fucking thought to the other person\.\. how is what he is suggesting appealing to anyone\.\. the fucking arrogance\.\. ok\.\. handshake is going to be a lot firmer\.\. he WILL feel it and know\.\. rofl\.


**343.** `01:05` **Meredith Lamb (+14169386001)**

The only thing he will say is that it is my fault because he was “sexually depraved”


**344.** `05:05` **You**

deprived


**345.** `01:05` **Meredith Lamb (+14169386001)**

Which is fine whatever


**346.** `05:05` **You**

but he was depraved as well


**347.** `01:06` **Meredith Lamb (+14169386001)**

lol


**348.** `05:05` **You**

which was the problem'


**349.** `05:06` **You**

and 3x a week is not deprived\.\. that is well\.\. at our age lucky as hell\.


**350.** `05:06` **You**

but you have to want it\.\. and I sure as hell did not\.


**351.** `01:08` **Meredith Lamb (+14169386001)**

Yeah it is a challenging topic\. When you don’t like someone and basically have no respect for them and are just there bc of your kids, …\. It’s hard\. Did the best I could\. But never enough\. To this day he will tell me all my fault\.


**352.** `01:08` **Meredith Lamb (+14169386001)**

The text was my fault


**353.** `01:08` **Meredith Lamb (+14169386001)**

🤷‍♀️


**354.** `05:08` **You**

that is borderline abusive\.\. naw it is abusive\.\.


**355.** `01:09` **Meredith Lamb (+14169386001)**

Therapist just says some narcissist tendencies


**356.** `05:08` **You**

If I wasn't your boss I think I would like him to know about me sooner than later\.


**357.** `01:09` **Meredith Lamb (+14169386001)**

I have so many stories but don’t want to make you sad/mad\. Another time maybe


**358.** `01:09` **Meredith Lamb (+14169386001)**

Fortunately I have a therapist for that


**359.** `01:09` **Meredith Lamb (+14169386001)**

lol


**360.** `05:10` **You**

I mean it is up to you\.\. I will listen and support you\.\. whatever you need\.\. I won't like it\.\. and it will make me mad\.\. but I would only care that it helped you to share it\.


**361.** `05:10` **You**

there is nothing like that I would have to share with you for instance\.\. so you won't have to worry about that\.


**362.** `01:11` **Meredith Lamb (+14169386001)**

My therapist has been a god send\.


**363.** `01:11` **Meredith Lamb (+14169386001)**

Just to help process stuff


**364.** `01:12` **You**

Yeah some of them are pretty good\.  I have only went to see one a few times\.  I always just
Kind of pushed shit down processed over time and trudged forward


**365.** `01:12` **You**

But I wasn’t dealing with anything like you


**366.** `01:12` **You**

The opposite


**367.** `01:12` **Meredith Lamb (+14169386001)**

Sometimes I thought I was crazy but my therapist confirmed I was not\. It allowed me to share more with my parents


**368.** `01:12` **You**

Manic depressive with no self
Esteem
Or confidence


**369.** `01:13` **Meredith Lamb (+14169386001)**

I do it online\. Easy\. But it is exhausting\.


**370.** `01:13` **Meredith Lamb (+14169386001)**

And she thinks we should pause\.


**371.** `01:13` **Meredith Lamb (+14169386001)**

Urg


**372.** `01:13` **You**

Well look


**373.** `01:13` **You**

I mean


**374.** `01:13` **You**

Sex is kind of a traumatic thing for you


**375.** `01:14` **You**

Me too but in a totally different way rofl


**376.** `01:14` **Meredith Lamb (+14169386001)**

lol


**377.** `01:14` **You**

I definitely want to


**378.** `01:14` **Meredith Lamb (+14169386001)**

I’m not “traumatized”\. Just annoyed\. Lol


**379.** `01:14` **You**

When you are teasy


**380.** `01:14` **You**

Ready


**381.** `01:14` **You**

lol


**382.** `01:14` **You**

Autocorrect is dumb


**383.** `01:14` **Meredith Lamb (+14169386001)**

lol


**384.** `01:15` **You**

No you say annoyed


**385.** `01:15` **You**

That isn’t what you feel


**386.** `01:15` **You**

Your therapist would blow that shit up


**387.** `01:15` **Meredith Lamb (+14169386001)**

I actually had a traumatizing sexual incident when I was 20\. I got over it\. Andrew was more just annoying\. Harassing\. Not traumatizing\.


**388.** `01:15` **Meredith Lamb (+14169386001)**

It’s all relative right


**389.** `01:16` **You**

>
Jesus you have lived a lot of life and not all good

*💬 Reply*

**390.** `01:16` **You**

I think you are good at rationalizing


**391.** `01:16` **Meredith Lamb (+14169386001)**

I mean most women have a “me too” moment


**392.** `01:16` **You**

Again


**393.** `01:16` **You**

Doesn’t make it right


**394.** `01:16` **You**

Or normal


**395.** `01:16` **Meredith Lamb (+14169386001)**

Still, part of life


**396.** `01:16` **You**

Or less important or impactful


**397.** `01:16` **Meredith Lamb (+14169386001)**

Part of being a female


**398.** `01:16` **You**

Mmmmmmm


**399.** `01:17` **You**

I am not a female \.\. but when someone physically assaulted maddie I almost ripped him apart


**400.** `01:17` **Meredith Lamb (+14169386001)**

Have you seen Luckiest Girl Alive?


**401.** `01:17` **Meredith Lamb (+14169386001)**

Mila Kunis


**402.** `01:17` **You**

>
I have not

*💬 Reply*

**403.** `01:17` **Meredith Lamb (+14169386001)**

I seriously had ptsd watching that movie


**404.** `01:18` **Meredith Lamb (+14169386001)**

>
Same when it happened to Mac

*💬 Reply*

**405.** `01:18` **You**

Ugh now I have to look it up and then I am going to feel like poo


**406.** `01:18` **Meredith Lamb (+14169386001)**

Don’t look it up tonight


**407.** `01:18` **Meredith Lamb (+14169386001)**

Later


**408.** `01:18` **Meredith Lamb (+14169386001)**

Good movie tho


**409.** `01:18` **Meredith Lamb (+14169386001)**

Never watching it again


**410.** `01:18` **You**

We have met on school grounds since\.\. I just say to him go somewhere else\.\. far away from me\.


**411.** `01:19` **You**

And off he scoots


**412.** `01:19` **You**

No I have to look now brain won’t let me\. It


**413.** `01:19` **Meredith Lamb (+14169386001)**

Did he date rape her?


**414.** `01:20` **Meredith Lamb (+14169386001)**

This rich fucker, pierce, made Mac give him a bj when she was drunk and waiting for a ride home\. Longer story than that but fuck I was so mad


**415.** `01:20` **Meredith Lamb (+14169386001)**

Called 911


**416.** `01:20` **Meredith Lamb (+14169386001)**

Got her mouth swabbed in case she wants to press charges later


**417.** `01:20` **Meredith Lamb (+14169386001)**

Went to sick kids


**418.** `01:20` **Meredith Lamb (+14169386001)**

I contacted his parents


**419.** `01:21` **You**

😩


**420.** `01:21` **Meredith Lamb (+14169386001)**

Horrible ppl


**421.** `01:21` **You**

I read the synopsis on Gemini


**422.** `01:21` **Meredith Lamb (+14169386001)**

Ah, k


**423.** `01:21` **You**

I don’t even know what to say\.


**424.** `01:22` **Meredith Lamb (+14169386001)**

Just to be clear I was not gang raped like in the movie


**425.** `01:22` **You**

He mentally pressured her
Kind of like Andrew’s approach of
Breaking down she said\. O first 5 or 6 times and then just didn’t answer so he did it\.\. had sex with her


**426.** `01:22` **Meredith Lamb (+14169386001)**

My situation was just very similar\. Date rape\. Guy j thought was a friend\.


**427.** `01:22` **You**

In my basement


**428.** `01:23` **You**

Like you were drugged


**429.** `01:23` **You**

I hope the other is worse


**430.** `01:23` **You**

Not being drugged


**431.** `01:23` **You**

I guess


**432.** `01:23` **You**

I don’t know


**433.** `01:23` **You**

Fuck


**434.** `01:23` **Meredith Lamb (+14169386001)**

>
Yeah my first high school bf did this too\. Pretty common teen boys suck

*💬 Reply*

**435.** `01:23` **You**

I didn’t do that


**436.** `01:24` **You**

I was the victim


**437.** `01:24` **You**

She was
Evil


**438.** `01:24` **Meredith Lamb (+14169386001)**

I was not drugged\. I was drunk tho\.


**439.** `01:24` **You**

Same


**440.** `01:24` **You**

Or close enough


**441.** `01:24` **Meredith Lamb (+14169386001)**

Anyway many years ago…


**442.** `01:24` **Meredith Lamb (+14169386001)**

Was only 20


**443.** `01:25` **You**

So sad bad experiences\.\.


**444.** `01:25` **Meredith Lamb (+14169386001)**

Life right…


**445.** `01:25` **You**

I mean no


**446.** `01:25` **You**

Or life right


**447.** `01:25` **You**

Not


**448.** `01:25` **You**

I mean if you deal that way I get it but that shit isn’t just ah well we love and learn


**449.** `01:26` **You**

That is I will cut your fucking balls off kind of stuff


**450.** `01:26` **You**

If I was a parent


**451.** `01:26` **You**

And that was my daughter


**452.** `01:26` **Meredith Lamb (+14169386001)**

Well it is weird bc I considered the person a friend\.


**453.** `01:26` **You**

That boy would not be having sex again


**454.** `01:26` **You**

I have had sex with friends


**455.** `01:26` **Meredith Lamb (+14169386001)**

Same with Mac and pierce


**456.** `01:26` **You**

On a few occasions


**457.** `01:27` **You**

But it was never like that it was always kind of we are old enough we are single and comfortable that this will not blow up the relationship so let’s have fun


**458.** `01:28` **You**

Man I was never on the forceful
End of anything g more like the receiving end\.  Women can be aggressive too but nothing like you have experienced fuck mer so sorry\.\. for all of it


**459.** `01:29` **Meredith Lamb (+14169386001)**

It is honestly not that unusual for women


**460.** `01:29` **You**

Ok like I want you to set the pace here mer\.  I don’t want to say slow down or pause because honestly I do t want to\.  But I need you to be the one to kind of let me know where the line is\.


**461.** `01:30` **You**

I just don’t want to be another bad experience


**462.** `01:30` **Meredith Lamb (+14169386001)**

I compartmentalized it until I watched that movie one day


**463.** `01:30` **You**

>
Not healthy

*💬 Reply*

**464.** `01:30` **Meredith Lamb (+14169386001)**

Meh lol


**465.** `01:30` **Meredith Lamb (+14169386001)**

Yoh do it too\!\!\!\!


**466.** `01:30` **Meredith Lamb (+14169386001)**

\*you


**467.** `01:30` **You**

See there is this kind of thing about you


**468.** `01:31` **You**

I think initially it confused me


**469.** `01:31` **You**

You have this way of brushing off negative emotions so I thought well maybe she just isn’t emotional\.\. but you are\.\. a lot


**470.** `01:31` **Meredith Lamb (+14169386001)**

>
There’s a line still?

*💬 Reply*

**471.** `01:31` **You**

>
The line is a dot to you\.

*💬 Reply*

**472.** `01:32` **Meredith Lamb (+14169386001)**

>
Who wants to live in negative emotions?

*💬 Reply*

**473.** `01:32` **You**

Never know if you will get the quotes


**474.** `01:32` **You**

lol


**475.** `01:32` **Meredith Lamb (+14169386001)**

I’m more like let’s get on with it


**476.** `01:32` **You**

>
I mean no one\.  But I have to believe no one can remain unaffected and then choose not to deal and then let it sit

*💬 Reply*

**477.** `01:33` **You**

>
It is Joey to chandler
In friends\.

*💬 Reply*

**478.** `01:33` **Meredith Lamb (+14169386001)**

>
I mean did you not do this in your basement?

*💬 Reply*

**479.** `01:33` **Meredith Lamb (+14169386001)**

>
Thanks I didn’t get it\.

*💬 Reply*

**480.** `01:33` **Meredith Lamb (+14169386001)**

lol


**481.** `01:34` **You**

My moving to the basement was a part of a process to detach or
To indicate that was coming\.  I have been dealing with negativity head on for a decade


**482.** `01:35` **You**

I didn’t have a choice


**483.** `01:35` **You**

No one else would


**484.** `01:35` **Meredith Lamb (+14169386001)**

So not compartmentalizing?


**485.** `01:35` **You**

Mm well yeah you got me there


**486.** `01:36` **You**

My analogy is an invisible box in the corner of any room I am in and I put the things I cannot xo tell in that box


**487.** `01:36` **You**

Control


**488.** `01:37` **You**

Because when I don’t well crazy shit can happen


**489.** `01:37` **Meredith Lamb (+14169386001)**

Pretty sure that is compartmentalizing


**490.** `01:37` **You**

I was
Agreeing with you lol


**491.** `01:37` **Meredith Lamb (+14169386001)**

But hey I never took psych


**492.** `01:37` **Meredith Lamb (+14169386001)**

lol


**493.** `01:37` **Meredith Lamb (+14169386001)**

I think we all do it


**494.** `01:38` **Meredith Lamb (+14169386001)**

Survival


**495.** `01:38` **You**

For example I haven’t put my love for you in the box and I cannot control it at all\. It makes me do all kinds of wierd shit


**496.** `01:38` **You**

Rationalization is for survival


**497.** `01:38` **You**

That is what you do


**498.** `01:38` **Meredith Lamb (+14169386001)**

In that movie the mom tells mila kunis to just lock it away\. I agreed with her


**499.** `01:38` **You**

You have done it in this conversation all night


**500.** `01:39` **Meredith Lamb (+14169386001)**

>
Done what? Rationalize?

*💬 Reply*

**501.** `01:39` **You**

Rationalization \- if you lock it away you never have to deal with it and it cannot hurt you so it is ok


**502.** `01:39` **You**

>
Yeah

*💬 Reply*

**503.** `01:39` **Meredith Lamb (+14169386001)**

Yes exactly\!


**504.** `01:39` **You**

Normal
For women


**505.** `01:39` **Meredith Lamb (+14169386001)**

That’s good


**506.** `01:39` **You**

lol


**507.** `01:39` **Meredith Lamb (+14169386001)**

lol


**508.** `01:39` **You**

Jesus


**509.** `01:39` **Meredith Lamb (+14169386001)**

Haha


**510.** `01:39` **You**

An advocate for repression


**511.** `01:40` **You**

And then you read about the woman that cut the socks off of 30 men\.\.


**512.** `01:40` **You**

Not socks


**513.** `01:40` **You**

lol


**514.** `01:40` **Meredith Lamb (+14169386001)**

Lorena Bobbit


**515.** `01:40` **You**

Well mine was hypothetical but I know her


**516.** `01:41` **Meredith Lamb (+14169386001)**

Good doc on that ;\)


**517.** `01:41` **Meredith Lamb (+14169386001)**

I mean good if you are female


**518.** `01:41` **You**

I would rather watch the cutting edge\.


**519.** `01:41` **Meredith Lamb (+14169386001)**

Great movie lol


**520.** `01:42` **You**

ROFL yeah


**521.** `01:42` **You**

Reaction: 😂 from Meredith Lamb
I mean I have seen it a few times I will admit… toepick\!


**522.** `01:42` **You**

Or just a good
Memory


**523.** `01:42` **You**

Ok


**524.** `01:42` **You**

A way back question


**525.** `01:42` **You**

Romantic movies


**526.** `01:43` **You**

From when I was one


**527.** `01:43` **Meredith Lamb (+14169386001)**

?


**528.** `01:45` **You**

When I was a romantic not one year old\.  This was an earlier question and I wanted to get you into a happier topic


**529.** `01:46` **You**

You are going to sleep
Though I can tell if you want why don’t you go to bed and we can do this tomorrow


**530.** `01:46` **Meredith Lamb (+14169386001)**

15 more minutes lol


**531.** `01:46` **You**

Ok let
Me
Get
Ack down stairs easier\.


**532.** `01:46` **Meredith Lamb (+14169386001)**

I’m a 10 year old asking for more screen time


**533.** `01:46` **Meredith Lamb (+14169386001)**

lol


**534.** `01:47` **You**

I can remember saying the same thing about my phone


**535.** `01:47` **You**

We had a second line and I would sneak a portable in my room and call my gf and stay up all night talking lol


**536.** `01:47` **You**

Yeah I know sounds lame meh w/e


**537.** `01:47` **Meredith Lamb (+14169386001)**

lol


**538.** `01:47` **You**

It wa the early 90s


**539.** `01:48` **You**

That is what we had to work with


**540.** `01:48` **Meredith Lamb (+14169386001)**

I remember, I was in them too


**541.** `01:49` **You**

I can Remeber one night with Jen that girl in the black dress you didn’t think I liked to much we started a convo at 9 pm and talked until 7:30 am… and then went to school


**542.** `01:49` **You**

That was a rough day


**543.** `01:49` **Meredith Lamb (+14169386001)**

Yikes


**544.** `01:49` **Meredith Lamb (+14169386001)**

Mac would punish me


**545.** `05:49` **You**

lol well like you said 15 minutes\.


**546.** `01:54` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/6MjfEIHOMW6MaDO3LpFcmW?si=szXMH6j5Qam\_QKIlNOKBXg
Sorry this came on my Spotify and I got a bit mesmerized


**547.** `06:00` **You**

so\.\. in no particular order\.\. Princess Bride \- near top of list I have always loved it and always will\.  Pretty Woman \- huge julia roberts fan \- Notting Hill is one of the most romantic movies of all time imho\. Four Weddings and a Funeral \- not as mainstream\.\.\. both True Romance and Reality Bites \- fringe but there\.\. I really liked them\.\. but I liked some others more\.  Poetic Justice \- I mean I am not getting into details suffice to say \- strong memory here\.  I am a guy so Jerry Maguire \- you had me at hello\. Legends of the Fall \.\.\. errr\.\. As good as it gets \- fuck nicholson \- You make me want to be a better man\.\. I thought about that quote in regards to you yesterday\.  Good Will Hunting \- the intelligence was great in how this movie was made\.\. Robin Williams was brilliant\.\. I loved his character the most\.  Ever After \- Drew Berrymore \- great\!\!  Ok\.\. a couple other off the beaten path \- Empire Records, Pump up the Volume, 10 things I hate about you, Love JOnes, How Stella got her Groove back \- I am bouncing between genres a few more incoming


**548.** `06:01` **You**

and even though it was techincally released in 2000 HIgh Fidelity \- Jack Black and Cusak  really great film\.


**549.** `06:02` **You**

I am sure there are more especially in 2000's but those should cover most of them\.


**550.** `02:02` **Meredith Lamb (+14169386001)**

Love High Fidelity


**551.** `02:03` **Meredith Lamb (+14169386001)**

Empire records


**552.** `02:03` **Meredith Lamb (+14169386001)**

Pump up the volume I was obsessed with in high school bc Christian slater


**553.** `02:03` **Meredith Lamb (+14169386001)**

Same with true romance


**554.** `06:03` **You**

lol everyone was


**555.** `06:03` **You**

Christian Slater was awesome


**556.** `06:03` **You**

one sec


**557.** `02:03` **Meredith Lamb (+14169386001)**

My friends all hated him


**558.** `02:04` **Meredith Lamb (+14169386001)**

I have watched legends of the fall too many times in my youth


**559.** `02:05` **Meredith Lamb (+14169386001)**

I’m honestly not a huge Romance/chick flick watcher though :\) lol but I will watch anything with you


**560.** `02:07` **Meredith Lamb (+14169386001)**

Most romantic in my vibe: Divergent


**561.** `06:06` **You**

I would watch any of those or anything with you\.\. I cannot promise not to try to makeout if it is boring or even if it is not\.


**562.** `06:07` **You**

Divergent\.\. really?
\\


**563.** `02:07` **Meredith Lamb (+14169386001)**

Yeah totally\. Four…\. Swoon


**564.** `02:07` **Meredith Lamb (+14169386001)**

I’ve read all the books too


**565.** `06:08` **You**

hehe\.\. I have seen the movies\.


**566.** `06:08` **You**

A while back\.\. I didn't swoon\.\. lol


**567.** `06:08` **You**

but I am a boy


**568.** `06:08` **You**

I am trying to think if there is a romance that melted me ever


**569.** `06:08` **You**

Notting Hill


**570.** `02:08` **Meredith Lamb (+14169386001)**

Omg that was my favourite movie for a while


**571.** `06:08` **You**

that is the one and only


**572.** `06:09` **You**

I am just a girl standing in front of a boy telling him she loves him\.


**573.** `02:09` **Meredith Lamb (+14169386001)**

>
Divergent nit noting hill

*💬 Reply*

**574.** `06:09` **You**

like jesus\.\. stand up and deliver


**575.** `02:09` **Meredith Lamb (+14169386001)**

I liked noting hill fine tho lol


**576.** `02:09` **Meredith Lamb (+14169386001)**

\*notting


**577.** `06:09` **You**

It had to be my fave I know I watched it many many times\.\. and never got bored\.\. and always felt happy\.


**578.** `02:10` **Meredith Lamb (+14169386001)**

Notting hill …\. Interesting


**579.** `06:10` **You**

I think I related to him


**580.** `02:10` **Meredith Lamb (+14169386001)**

You are sappy\. Lol


**581.** `02:10` **Meredith Lamb (+14169386001)**

Can I say that?


**582.** `06:10` **You**

>
you can

*💬 Reply*

**583.** `06:10` **You**

no one would believe you


**584.** `02:10` **Meredith Lamb (+14169386001)**

lol\! Truth


**585.** `02:11` **Meredith Lamb (+14169386001)**

Like I would never think you would like that movie


**586.** `02:11` **Meredith Lamb (+14169386001)**

So much to learn


**587.** `06:11` **You**

naw\.\. it was sweet\.\. he was this unassuming man \- smart quiet, funny\.\.


**588.** `06:12` **You**

who never even thought he could be with someone like Roberts character\.\. bit how I feel about you tbh\.\. not in a bad way\.\. and I don't feel like I cannot be with you\.\. just like surreal\.


**589.** `02:12` **Meredith Lamb (+14169386001)**

I dunno if I will have enough sap for you


**590.** `06:12` **You**

LOL I also like Transformers\.


**591.** `06:12` **You**

Lord of the Rings


**592.** `06:12` **You**

Star Wars


**593.** `02:13` **Meredith Lamb (+14169386001)**

Ok PHEWF


**594.** `02:13` **Meredith Lamb (+14169386001)**

Thank you


**595.** `06:13` **You**

Reaction: ❤️ from Meredith Lamb
Some war movies\-not all\. lol\.\. Terminator OBVIOUSLY


**596.** `02:13` **Meredith Lamb (+14169386001)**

Best movie of all time\. Obvi


**597.** `06:13` **You**

Like I think I told you \- as much as I like boxes\.\. I don't know that I fit one very well\.


**598.** `02:14` **Meredith Lamb (+14169386001)**

I’m certainly seeing that more everyday


**599.** `02:14` **Meredith Lamb (+14169386001)**

It’s intriguing


**600.** `06:14` **You**

I am kind of all over the place with music, movies, literature \- sports, computers\.\.


**601.** `06:14` **You**

ai :\)


**602.** `02:14` **Meredith Lamb (+14169386001)**

Pick a lane\!


**603.** `02:14` **Meredith Lamb (+14169386001)**

Kidding


**604.** `06:14` **You**

I think that is what did it btw\.


**605.** `06:14` **You**

When I think back


**606.** `02:15` **Meredith Lamb (+14169386001)**

Did what


**607.** `06:14` **You**

You got to see the most of my brain\.


**608.** `06:15` **You**

when I was talking about ai or showing you things or showing you what I did\.


**609.** `06:15` **You**

You were always super interested right away


**610.** `06:15` **You**

or maybe you just liked me  who knows\.


**611.** `02:16` **Meredith Lamb (+14169386001)**

Very true but even before ai when we only had alpha sense… I still liked your brain lol


**612.** `06:16` **You**

Alpha Garbage


**613.** `02:16` **Meredith Lamb (+14169386001)**

lol\!\!\!


**614.** `06:16` **You**

btw Don't forget about notebook LLM


**615.** `06:16` **You**

it has a new feature


**616.** `06:16` **You**

It can generate references off of content you provide it now


**617.** `06:16` **You**

so it is kind of a like a search bot\.


**618.** `02:17` **Meredith Lamb (+14169386001)**

Don’t forget\. Did you tell me about this already?


**619.** `06:17` **You**

yep


**620.** `02:17` **Meredith Lamb (+14169386001)**

Oh lol


**621.** `06:17` **You**

NotebookLLM is a fantastic tool for Mac\.\.


**622.** `06:17` **You**

if she learns how to use it right


**623.** `02:18` **Meredith Lamb (+14169386001)**

Will look at it\. When did you tell me about this


**624.** `06:18` **You**

remember the thing where it gave a podcast


**625.** `06:18` **You**

about the content it reviewed


**626.** `02:18` **Meredith Lamb (+14169386001)**

Ohhhhh


**627.** `06:18` **You**

yeah


**628.** `02:18` **Meredith Lamb (+14169386001)**

Didn’t know the name


**629.** `06:18` **You**

ahh kk sorry thought I shared\.\. maybe didn't


**630.** `06:19` **You**

Alright mer 15 minutes are gone\.\. you want to keep going?  I will give you whatever you want\.


**631.** `02:20` **Meredith Lamb (+14169386001)**

I should go to bed 😥


**632.** `02:20` **Meredith Lamb (+14169386001)**

I could talk to you all night but shouldn’t


**633.** `06:21` **You**

Yeah that is the responsible thing\.\. Marlow will be bugging you in the morning\.  Hope you guys have a great easter\.\.  I could talk to you forever\.\. but sleep is unfortunately needed\.


**634.** `02:21` **Meredith Lamb (+14169386001)**

Thanks for saving the day today ❤️


**635.** `06:24` **You**

Reaction: ❤️ from Meredith Lamb
Honestly I wish we were together for that discussion\.\. as hard as it would have been\.\. and sorry about Andrew and the shit\.\. sorry I still feel like you might be making a decision based on him finding out about us\.  Sorry you had that shit happen to you in the past\.\. I cannot make that better or go away\.\. but I can try to make you happy\.\.  Like I said last night\.\. god I love you\.\. all of you\.\. I cannot wait to see you on Tuesday :\)  But until then I am around tomorrow\.\. and Monday for whatever you need\.


**636.** `06:25` **You**

ROFL I bet you passed out again \- like a little kid\.\. love you mer, nite, xoxo\.


**637.** `02:26` **Meredith Lamb (+14169386001)**

I did not pass out\. Had to get water\. Lol


**638.** `02:27` **Meredith Lamb (+14169386001)**

I feel sometimes like I don’t deserve you but I will compartmentalize that feeling\. 😇


**639.** `02:27` **Meredith Lamb (+14169386001)**

Love you xo


**640.** `06:28` **You**

>
you deserve far better than me\. but I will try anyways\.  ❤️

*💬 Reply*

**641.** `06:28` **You**

nite


**642.** `06:28` **You**

xo


**643.** `10:02` **Meredith Lamb (+14169386001)**

G’morn 🙂


**644.** `10:02` **Meredith Lamb (+14169386001)**

We actually just had a very positive 2 hour discussion


**645.** `10:02` **Meredith Lamb (+14169386001)**

Changed the plan


**646.** `10:02` **Meredith Lamb (+14169386001)**

I think I will keep my equity in the cottage instead of buying in Toronto


**647.** `10:02` **Meredith Lamb (+14169386001)**

We will share the cottage 50/50


**648.** `10:03` **Meredith Lamb (+14169386001)**

I will rent in Toronto


**649.** `10:03` **Meredith Lamb (+14169386001)**

It feels like a better plan for everyone\. And I still keep my equity


**650.** `10:05` **Meredith Lamb (+14169386001)**

This plan also allows me to get out whenever I want\.


**651.** `10:05` **You**

Interesting


**652.** `10:05` **You**

Morning luv\.


**653.** `10:07` **You**

You should choose whatever is best for you and the kids whatever will make you the happiest because that is all that matters


**654.** `10:08` **You**

Renting seems a bit meh but I shared that with you about my situation yesterday\.


**655.** `10:12` **You**

The glasses… agh now I get it…… rofl looks smart\.


**656.** `10:12` **You**

Just need suspenders and a pocket protector soooooo hot…\. 🥵 lol jk


**657.** `10:14` **Meredith Lamb (+14169386001)**

lol


**658.** `10:14` **Meredith Lamb (+14169386001)**

I would pay $1500 a month to carry this place\.


**659.** `10:15` **Meredith Lamb (+14169386001)**

I said I won’t have $ for repairs or maintenance and he said he doesn’t care


**660.** `10:15` **Meredith Lamb (+14169386001)**

The place doesn’t need much in short term


**661.** `10:15` **Meredith Lamb (+14169386001)**

He said we could think about a contract where he pays first $10k in repairs per year or something like that


**662.** `10:16` **You**

Holy shit you guys are deep I\. It


**663.** `10:16` **Meredith Lamb (+14169386001)**

Honestly renting at YEG makes more sense bc I don’t see myself there forever


**664.** `10:16` **You**

True I mean you avoid property taxes\.\.


**665.** `10:16` **You**

And more flex but still a lot of money


**666.** `10:16` **Meredith Lamb (+14169386001)**

I avoid real estate buying and selling etc


**667.** `10:16` **You**

Yeah that too


**668.** `10:17` **You**

Which is several hundred thousand


**669.** `10:17` **Meredith Lamb (+14169386001)**

Exactly\. For an area I don’t see myself forever


**670.** `10:17` **You**

Maybe I should rent too


**671.** `10:17` **You**

Hmmm will have to consider


**672.** `10:18` **Meredith Lamb (+14169386001)**

Not sure how you feel about me sharing a cottage with him\.


**673.** `10:18` **You**

Not up to me\.\. I don’t have a say or a position\.  I love you and want you to be as happy as you can be\.


**674.** `10:19` **You**

And btw that is not me saying I don’t like the idea


**675.** `10:19` **You**

I don’t do that kind of thing


**676.** `10:19` **Meredith Lamb (+14169386001)**

I would let him buy me out down the line if I ever wanted to buy elsewhere


**677.** `10:19` **You**

Just as N fyi


**678.** `10:19` **You**

lol


**679.** `10:19` **Meredith Lamb (+14169386001)**

>
What kind of thing?

*💬 Reply*

**680.** `10:19` **You**

The passive aggressive I don’t like something but I am not
Going to say it outright


**681.** `10:20` **Meredith Lamb (+14169386001)**

Oh lol


**682.** `10:20` **Meredith Lamb (+14169386001)**

I mean, maybe you would like it up here eventually\. 2 yrs


**683.** `10:21` **You**

The thought crossed my mind\.  I mean there are a lot of you memories up there\.\. that might be a challenge for me but who knows I am old now\.\. a little more mature than when I was younger hehe


**684.** `10:23` **Meredith Lamb (+14169386001)**

Yeah that is why I asked what you thought initially


**685.** `10:24` **You**

Well again I want what makes you happy mer\.  If I cannot deal I will let you know but i doubt it will be a problem


**686.** `10:28` **Meredith Lamb (+14169386001)**

I think I have to do it for 1\.  My girls 2\. My sanity and 3\. I don’t want Andrew having to share it with his mom and awful stepdad\. I mean I don’t like Andrew but I don’t hate him either\. And he is my girls’ dad


**687.** `10:29` **Meredith Lamb (+14169386001)**

Very complicated ugh


**688.** `10:29` **You**

Totally understand\.\. your logic makes sense\.  And I suspect both 1 & 2 are very very important to you which  wry much appreciate


**689.** `10:29` **You**

We can make our own memories mer


**690.** `10:29` **You**

That is what is truly important to me


**691.** `10:30` **Meredith Lamb (+14169386001)**

>
I mean we are now…

*💬 Reply*

**692.** `10:30` **You**

Reaction: ❤️ from Meredith Lamb
Yes virtually remember that time at the cottage when I sent you dirty workout video gosh that was fun lol


**693.** `10:31` **You**

Haha


**694.** `10:31` **You**

But I love the idea that these texts that you have kept\.\. are a record of everything that got us here


**695.** `10:31` **Meredith Lamb (+14169386001)**

>
Totally turned my day around :\)

*💬 Reply*

**696.** `10:32` **You**

All I wanted\.


**697.** `10:33` **Meredith Lamb (+14169386001)**

Just don’t feel like you have to save me all the time\. Lol


**698.** `10:35` **Meredith Lamb (+14169386001)**

I am not that broken\. Just an emotional time of life


**699.** `10:35` **You**

I don’t I know you are strong… it isn’t about saving\.  Trying to make you happy isn’t an instance\.\. or one off it is an everything all the time as much as possible and not I some self satisfying way


**700.** `10:36` **You**

Reaction: ❤️ from Meredith Lamb
I mean I am happy when you are happy there is a mutual benefit don’t get me wrong


**701.** `10:36` **You**

But my happiness is not the driver


**702.** `10:41` **Meredith Lamb (+14169386001)**

Lake melting FAST

*📎 1 attachment(s)*

**703.** `10:47` **You**

Wow yeah that was fast shot


**704.** `10:48` **You**

Cute dog lol


**705.** `11:31` **You**

You know what I never did as the same detach question back to you\.\. you are getting out of a smothering invasive ish relationship will you not just detach from me eventually\.\. your words never thought of it that way\.  Curious is all\.\. any concerns there\.\. you have asked me on several occasions if I have had any hesitations\.\. have you\.\. don’t worry about the answers if you think I won’t like them… would rather knowing than not\.  I don’t know why I thought of this was just walking around cleaning no one is up here yet\.  I got all the Easter shit ready in middle of night but everyone still asleep


**706.** `11:39` **Meredith Lamb (+14169386001)**

Scott you are different\. This is different\. I can feel that\. My only hesitation has been the whole work situation\. But even that has not been enough for me to pause things\.


**707.** `11:40` **Meredith Lamb (+14169386001)**

We are skipping Easter this year\. Everyone being too healthy\. Mac won’t go near chocolate\. Mar has provincials next weekend\. Maelle is having Easter with her cousins at my mom and dad’s\.


**708.** `11:44` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
This is not fragile\. I will not detach\. I’m in this just as much as you are\. Seriously\.


**709.** `11:44` **You**

Just thought to ask\.\. I don't keep track of all of the questions I have answered\.\. lol and then think to ask you later\.


**710.** `12:03` **Meredith Lamb (+14169386001)**

Sigh this feels like a long break in seeing you\.


**711.** `12:04` **You**

it is\.\. and even Tuesday doesn't really count\.\. unless we go to dinner and grab a few mins after\.\. lol


**712.** `12:05` **You**

but you might have kid stuff I know\.\. tough to sort on short notice


**713.** `12:06` **You**

Reaction: 😂 from Meredith Lamb
again I am going because I feel I now need to ingratiate myself with Ian, and Haris literally treats me like his besty\.\. I mean honestly I  really like the guy\.\. but he makes it obvious even in the management meetings\.


**714.** `12:06` **You**

almost a bit uncomfortable\.\. like my friend Mike telling me he loves me and I am like\.\. yeah dude same\.\.\. \{fistbump\}


**715.** `12:07` **Meredith Lamb (+14169386001)**

I have an appt tues so prefer not to go :p and yah, we wouldn’t get to hang anyway


**716.** `12:08` **You**

ah np\.\. therapist right\.\. sorry I forgot\.


**717.** `12:08` **You**

so yeah\.\. this will be a really long stretch


**718.** `12:08` **You**

rofl


**719.** `12:09` **Meredith Lamb (+14169386001)**

No not therapy\. Hair cut\. Booked for a while so don’t want to cancel


**720.** `12:09` **You**

Shit yeah I hate cancelling those\.\.


**721.** `12:09` **You**

so hard to get my guy\.\.


**722.** `12:10` **Meredith Lamb (+14169386001)**

Har har


**723.** `12:10` **You**

Do you know how much I have saved in appointments and hair care products since 2000 lol


**724.** `12:12` **Meredith Lamb (+14169386001)**

lol


**725.** `12:50` **Meredith Lamb (+14169386001)**

I am spending about 1/4 extra time cleaning up Mackenzie’s messy painting mistakes\. Omg


**726.** `13:24` **You**

Sucks boo\.\.


**727.** `13:44` **You**

Sorry just had to step away watched a couple of shows with fam to try to make Gracie happy\.


**728.** `13:45` **You**

J was not happy…\.\.


**729.** `13:46` **Meredith Lamb (+14169386001)**

I don’t think she is going to be happy for quite sometime\. Unless you change your mind\.


**730.** `13:50` **You**

And now everyone is fighting and I ran to his in bathroom… so brave am I


**731.** `13:50` **You**

>
Now it is your turn to stop it\.

*💬 Reply*

**732.** `13:53` **You**

I think you would be more likely to change your mind than me\.\. you have an ability I don’t, your kids are younger your ability to compartmentalize and rationalize is far greater than mine I think\.  So stop worrying about me lol I am a stubborn ass\.\. I have thought this through… think about my what if process you don’t think I did that with our marriage 1000 times or more\.  I never saw a good outcome especially last few years\.


**733.** `13:54` **You**

I couldn’t put up with what you did for so long… if she had have pressured me I would have told her to fuck off\.\. I always tried to be nice but sometimes I had to be more direct\.  But I know our situations are different… you had a really rough go\.


**734.** `13:55` **You**

Reaction: ❤️ from Meredith Lamb
I am never going to change my mind I only want you and that is that\.


**735.** `13:59` **You**

You know some of the things I have done the pictures and vids and shit\.\. the brutally open honesty about how I feel I would never have done that it isn’t who I am\.  When I say I have never been like this with or felt like this for anyone… ever I mean ever like ever ever\.  You don’t need to worry even this shit this time apart, even with me trying to be nice and supportive to j\.\. that is just the shitty process we have to go through to get to what we want down the road\.\. I hope it will make you realize actually how much you mean to me and how much I love you\.


**736.** `14:05` **Meredith Lamb (+14169386001)**

I am not “more likely to change my mind”…\. It sounds like we are both on the same page\. It is just going to be a bit of a messy road\.


**737.** `14:06` **Meredith Lamb (+14169386001)**

I just miss you\.


**738.** `14:08` **You**

Same always better when you are around in any capacity at work, in the back of a car… wherever is better with you\.


**739.** `14:09` **You**

I think keeping the cottage was a good idea\.\. btw thought more about it


**740.** `14:10` **You**

Sometimes it takes me a bit to weigh the pros and cons in my head but very much see it as a good idea for you\.\. and the kids and the dogs\.\. and yes even douchebag\.\. I am going to start calling him that now\.


**741.** `14:11` **Meredith Lamb (+14169386001)**

lol yeah I just need to talk to him about the “what if we meet other people” and if he’d be fine with that\. I don’t want to be in a mean nasty arrangement


**742.** `14:11` **Meredith Lamb (+14169386001)**

Apparently his mom told him yesterday that she thinks I will want him back when he starts dating\. She is so clueless


**743.** `14:12` **Meredith Lamb (+14169386001)**

He never tells her anything so she thinks he is amazing


**744.** `14:12` **You**

I think that is just an exclusionary provision I\. The agreement\.  Regardless of relationship status, job status, etc this agreement persists


**745.** `14:12` **You**

So if he gets promoted he doesn’t pay you more if you get promoted he doesn’t pay you less same with relationships


**746.** `14:13` **Meredith Lamb (+14169386001)**

But mentally will he be fine


**747.** `14:13` **Meredith Lamb (+14169386001)**

He throws tantrums


**748.** `14:13` **Meredith Lamb (+14169386001)**

🙄


**749.** `14:14` **You**

I mean I don’t know about that\.\. but he is the one going out looking for a place to deposit his…\.\.  not you… eeesh that is sooo fucking nasty\.\. 🤮 so he can just grow the fuck up\.


**750.** `14:14` **You**

I think once we meet everything will be fine


**751.** `14:15` **Meredith Lamb (+14169386001)**

I maybe shouldn’t have showed you that? Lol


**752.** `14:15` **You**

I will turn into someone else, try to not be threatening, try to be humble, etc if for no other reason than to make it easier for you and importantly the kids


**753.** `14:15` **You**

I want to do the other stuff but I know the right thing to do


**754.** `14:16` **You**

He will
Have so much ammo on me though


**755.** `14:16` **Meredith Lamb (+14169386001)**

What do you think Jaime will think when she finds out \(2yrs I know\)


**756.** `14:16` **You**

lol


**757.** `14:16` **Meredith Lamb (+14169386001)**

>
What do you mean?

*💬 Reply*

**758.** `14:16` **You**

She will already be hating me\.


**759.** `14:17` **Meredith Lamb (+14169386001)**

But it is someone she knows


**760.** `14:17` **You**

Hey Scott didnt you hire my wife yeah and the\. She worked for you\.\. a little inappropriate lol


**761.** `14:17` **Meredith Lamb (+14169386001)**

Oh right lol


**762.** `14:17` **Meredith Lamb (+14169386001)**

Forgot


**763.** `14:18` **You**

To which I respond with something about a cost room after a meeting for a quick stop I\. Heaven where …… and apparently you told me where\.


**764.** `14:18` **You**

Coat room


**765.** `14:18` **You**

And the\. He throws a knife or a fork at me


**766.** `14:18` **You**

Or both


**767.** `14:18` **Meredith Lamb (+14169386001)**

lol omg


**768.** `14:18` **You**

because in this scenario I assume we are eating


**769.** `14:19` **You**

Orrrrrrrrrrr


**770.** `14:19` **You**

We double date\.\. he gets mean and I say something to his fake girlfriend


**771.** `14:19` **You**

That could happen too


**772.** `14:19` **You**

lol


**773.** `14:19` **Meredith Lamb (+14169386001)**

>
No never happening

*💬 Reply*

**774.** `14:19` **You**

>
Who knows never say never

*💬 Reply*

**775.** `14:19` **Meredith Lamb (+14169386001)**

NEVER


**776.** `14:20` **You**

Can I make you a bet


**777.** `14:20` **You**

That he will ask


**778.** `14:20` **You**

Someday


**779.** `14:20` **You**

and you can record it right here that I called it


**780.** `14:20` **Meredith Lamb (+14169386001)**

Ask for a double date?


**781.** `14:20` **You**

Yep


**782.** `14:20` **Meredith Lamb (+14169386001)**

wtf no he would\. It


**783.** `14:20` **Meredith Lamb (+14169386001)**

\*not


**784.** `14:20` **You**

Kk let’s see if I know more about me\. And his particular psyche


**785.** `14:21` **You**

Me


**786.** `14:21` **You**

Men


**787.** `14:21` **Meredith Lamb (+14169386001)**

He won’t\. What do I win when I win lol


**788.** `14:21` **Meredith Lamb (+14169386001)**

Because I will be winning that one


**789.** `14:21` **You**

Whatever you want


**790.** `14:21` **Meredith Lamb (+14169386001)**

Done


**791.** `14:21` **You**

Reaction: 😂 from Meredith Lamb
Within my ability to give


**792.** `14:22` **Meredith Lamb (+14169386001)**

So Easter wasnt amazing lol


**793.** `14:23` **You**

Yeah not so much


**794.** `14:23` **You**

We watched it’s the Easter beagle Charlie Brown


**795.** `14:23` **You**

And then some SNL


**796.** `14:24` **You**

And later I promised I would sit and watch hoodwinked and or rise of the guardians\.


**797.** `14:25` **Meredith Lamb (+14169386001)**

Interesting choices


**798.** `14:25` **You**

Gracie was sad\.\. Jaimie was like you never watched movies when I asked , I mouthed I am doing it for them\.\. and then I got a not so nice look\.


**799.** `14:27` **Meredith Lamb (+14169386001)**

🫤


**800.** `14:30` **You**

I mean it is what it is\.  I am trying to be nice going g to look at rentals tonight


**801.** `14:30` **You**

I still have to finish some work and then put together financials I have taxes to do this week dinner Tuesday gym and gone I\. Friday man


**802.** `14:30` **You**

Busy week


**803.** `14:32` **Meredith Lamb (+14169386001)**

I’m looking online right now lol


**804.** `14:43` **Meredith Lamb (+14169386001)**

This place is actually a couple doors down from friends of mine \+ super close to our current home\. Check out this listing
https://realtor\.ca/real\-estate/28153677/109\-edith\-drive\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**805.** `14:57` **You**

Rofl I mean I cannot help it\.\. the price\.\. like Jesus… rofl


**806.** `14:57` **You**

Sorry just trying to help Gracie with something for university


**807.** `15:21` **You**

Beautiful but also just realized it is a semi right Fack


**808.** `15:30` **You**

https://www\.zumper\.com/apartments\-for\-rent/60876507/2\-bedroom\-port\-whitby\-whitby\-on?utm\_source=zumper\_ios&utm\_medium=share&utm\_campaign=detail\_url\_native


**809.** `15:36` **You**

only problem is these rentals are literally right by my house\.\. wouldn't be a lot of privacy\.\. might be challenging to have you over, without the risk of a kid literally just showing up lol\.


**810.** `16:30` **Meredith Lamb (+14169386001)**

That is going to be a big issue on both sides likely\.


**811.** `16:37` **Meredith Lamb (+14169386001)**

I mean except for Mac\. :P


**812.** `16:38` **You**

So basically we have 2 years or so of this\.\. 😰


**813.** `16:38` **Meredith Lamb (+14169386001)**

When I think of it, it makes me get ready for shit hitting the fan bc it doesn’t seem sustainable\.


**814.** `16:38` **Meredith Lamb (+14169386001)**

But hey what do I know lol


**815.** `16:39` **You**

>
sorry before I comment what did you mean?

*💬 Reply*

**816.** `16:39` **Meredith Lamb (+14169386001)**

It’s just like how do 2 ppl not fuck up for 2 yrs


**817.** `16:39` **Meredith Lamb (+14169386001)**

It takes such a small thing\.


**818.** `16:39` **Meredith Lamb (+14169386001)**

Like your ChatGPT experience with Gracie


**819.** `16:39` **Meredith Lamb (+14169386001)**

There are so many other small slips that could happen over such a prolonged time period


**820.** `16:39` **Meredith Lamb (+14169386001)**

It is worrying


**821.** `16:40` **You**

I am sorry\.\. just pausing for sec\.


**822.** `16:41` **You**

>
I just need to think and not sure what to say\.

*💬 Reply*

**823.** `16:42` **You**

I mean when I am out on my own \- this access to information thing becomes trivial\.\. my privacy will be paramount\.\. but before I go into how I think we can manage this \- do you want to?  It just sounded a bit like not so much\.


**824.** `16:43` **You**

>
sorry was a pretty quick shift in direction\.\. so I am a little uncertain\.\. this is the downside to text\.

*💬 Reply*

**825.** `16:45` **Meredith Lamb (+14169386001)**

Yes of course I want to\. But it doesn’t mean it isn’t a little worrying\.


**826.** `16:46` **You**

that was a little worrying\.  fuck man something is wrong with me\.  literally everything just stopped\.\.\.


**827.** `16:47` **You**

Sorry Mer, I would do anything, literally anything to make this work\.  As I said I am all in


**828.** `16:48` **Meredith Lamb (+14169386001)**

You are worth every little risk my brain sees and worries about\. But those thoughts are still there\. Like I super worry about Jaime or Gracie confronting me someday in a heated manner\.


**829.** `16:48` **Meredith Lamb (+14169386001)**

For example\.


**830.** `16:48` **Meredith Lamb (+14169386001)**

But it’s okay\.


**831.** `16:48` **Meredith Lamb (+14169386001)**

lol


**832.** `16:49` **You**

Sorry this sounds lame \- but just shook a bit here\.


**833.** `16:49` **Meredith Lamb (+14169386001)**

What did you think I meant?


**834.** `16:50` **You**

I thought you had second thoughts throughout the day, and were leading towards a conversation where you suggested perhaps we should call this off before going any further\.  Again \- everything stopped\.\. haven't felt that before\.


**835.** `16:50` **You**

It was\.\.\.\. unpleasant\.


**836.** `16:50` **Meredith Lamb (+14169386001)**

Omg no


**837.** `16:51` **Meredith Lamb (+14169386001)**

That said, you honestly we can hide this for 2 yrs


**838.** `16:51` **Meredith Lamb (+14169386001)**

Like we are that talented?


**839.** `16:51` **Meredith Lamb (+14169386001)**

lol


**840.** `16:52` **You**

Mer I would crash through walls to make this work\.\. my only milestone to shoot for right now\.\. is to get you off my team, or to get me somewhere else\.


**841.** `16:52` **You**

That sounds bad\.\. but honestly I feel like if that is out of the way\.\. everything else is easier\.


**842.** `16:53` **You**

uggh


**843.** `16:54` **Meredith Lamb (+14169386001)**

Maybe\.


**844.** `16:54` **Meredith Lamb (+14169386001)**

Not sure\.


**845.** `16:54` **Meredith Lamb (+14169386001)**

Our family situations are not going to be “easy” for a while


**846.** `16:55` **You**

I understand\.\.\. but I am still not having any second thoughts\.


**847.** `16:55` **You**

just me\.\. how I am\.


**848.** `16:55` **You**

will make it work somehow


**849.** `16:56` **Meredith Lamb (+14169386001)**

I am not either\. Just muddling through my head’s thoughts\.


**850.** `16:57` **You**

\.\.


**851.** `16:58` **Meredith Lamb (+14169386001)**

My head also is saying not enough kissing Scott time this weekend and it is angry at that\. lol


**852.** `16:59` **You**

Sorry my head is going a million miles a second\.\. trying to solve every potential problem that might come up\.\. and never really having experience this kind of feeling\.\. I am just trying to process\.  It's nothing you did this apparently goes with the territory\.\. I haven't had this experience before\.


**853.** `17:00` **You**

I have never truly been afraid of losing something\.\.\.\. how about that\.\. lol


**854.** `17:01` **You**

not even worried about my job\.\. lol


**855.** `17:02` **Meredith Lamb (+14169386001)**

You are not going to lose anything\. I don’t scare off that easily\.


**856.** `17:06` **You**

Sorry I have to go get dinner ready for everyone, I will ping you after\.\.\.


**857.** `17:08` **Meredith Lamb (+14169386001)**

k, maybe just consider during your prep that I love you just as much as you love me or maybe more…\. That that is a possibility and so I’m not going anywhere despite the shit that could potentially hit the fan in this messy situation \(lol\)


**858.** `17:09` **You**

Mer I am not sure\.\. maybe\.\. but honestly the fear that hit me\.\. was like nothing else\.\. I am not that insecure\.\. but I also have never felt like this\.\. it was like I went completely empty\.\.\.\. I am fairly certain I love you more than anything\.\. ever\.\.\.


**859.** `17:11` **You**

like you have known me for years\.\. this is not a version of me that even I am familiar with\.\.\. or maybe it has just been too long\.\. I don't know\.\. I just know the thought of not moving forward\.\. well it pretty much stopped me in my tracks lol\.


**860.** `17:11` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
You just need to know you are in a mutual situation here\.


**861.** `17:11` **You**

I think this is why I let logic rule most of my life


**862.** `17:12` **Meredith Lamb (+14169386001)**

But I think do need to anticipate some potential complications happening beyond our control


**863.** `17:12` **Meredith Lamb (+14169386001)**

But not today lol


**864.** `17:12` **Meredith Lamb (+14169386001)**

Go make dinner\! I’m walking dogs and then back to work


**865.** `17:12` **Meredith Lamb (+14169386001)**

Xoxo


**866.** `17:13` **You**

kk  have fun\.  chat in a bit\.


**867.** `17:13` **You**

xoxo


**868.** `18:27` **You**

Dinner was uneventful\.\. I am going to go focus on work, get my mind off of things\.\. gl with the rooms\.


**869.** `18:32` **Meredith Lamb (+14169386001)**

Are you feeling ok?


**870.** `18:33` **You**

honestly\.\. no\. that was the worst I have felt in a long time\.\. worse than telling Jaimie\.\. I don't know what that was\.\. but it felt terrible\.  Again not your problem I will work through it\.\. don't worry about it\.


**871.** `18:34` **Meredith Lamb (+14169386001)**

All triggered by my sustainability comment?


**872.** `18:37` **You**

This is the least attractive side of my intelligence\.\. it is the worst part of it\.\. what it does to me\.  I am afraid to say yes because my brain tells me if I do so \-she will be turned off, she will think this is too much trouble, she will suggest slowing down perhaps a lot, etc etc etc\.  Do you see what I mean\.\. stupid brain\.


**873.** `18:38` **You**

And you couple that with the say I feel about you\.\. and the emotional intensity\.\.


**874.** `18:38` **You**

not something I have ever had to cope with\.


**875.** `18:39` **You**

I think you just handle this better than I do\.\. much more in control, practical etc\.\. I envy that about you\.\. you are really put together\.


**876.** `18:39` **Meredith Lamb (+14169386001)**

Just to be crystal clear, my sustainability comment wasn’t about our relationship being sustainable… it was about keeping it secret for that long being sustainable\.


**877.** `18:39` **You**

like you have a really strong mind\.\. in a much different way from mine\.


**878.** `18:40` **Meredith Lamb (+14169386001)**

I think it was a major misunderstanding


**879.** `18:40` **You**

It probably was Mer\.\. don't worry about it\.\. I am just being stupid\.\. not used to this\.


**880.** `18:41` **You**

I am not worried about work\.


**881.** `18:41` **You**

I am not worried about my family\.\. I can manage that


**882.** `18:41` **You**

But I am worried about your family\.\. and how you feel about that\.


**883.** `18:42` **You**

oh\.\. hope you guys ended up having a good easter day btw\.\.


**884.** `18:44` **Meredith Lamb (+14169386001)**

We are basically ignoring Easter this year\. :P


**885.** `18:44` **Meredith Lamb (+14169386001)**

You are not being stupid btw\.


**886.** `18:45` **You**

I feel like I am\.\. big strong me\.\. broken down by a sentence\.\. how does that make any fucking sense\.


**887.** `18:45` **You**

I will sort it, just need to get control back\.


**888.** `18:47` **Meredith Lamb (+14169386001)**

Well I want you to not worry about us\. Just worry about other stuff\. Lol seriously


**889.** `18:47` **You**

I will try\.\. in a weird way you should be flattered lol\.\. this has to be real\.\. otherwise what I felt wouldn't have been possible\.


**890.** `18:48` **Meredith Lamb (+14169386001)**

I do kinda like that you feel you have no control over it\. Not because it is flattering but because I feel similarly\. I couldn’t pause this or walk away if I tried\.


**891.** `18:50` **You**

>
that is reassuring\.\. it really is\.\. but like you said really tough not being with you\.\.  Maybe if we get to a point where that can reasonably and safely become a more common thing\.\. everything else can get easier\.\. and I mean like when we can just go grab a bite or a coffee or whatever whenever we want\.

*💬 Reply*

**892.** `18:51` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Will be dreaming of that tonight\. :\)


**893.** `19:02` **Meredith Lamb (+14169386001)**

Ps\. One of my best friends growing up and in high school lives in Detroit so I have to see her at some point\. Wasn’t going to tell her but felt bad\.

*📎 1 attachment(s)*

**894.** `19:02` **Meredith Lamb (+14169386001)**

Turns out she lives near our hotel


**895.** `19:02` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
She wants to go out but I am going to try to get her to come to venue instead


**896.** `19:03` **Meredith Lamb (+14169386001)**

\(She went to the u\.s\. on a volleyball scholarship\)


**897.** `19:03` **You**

>
impressive\.\. competitive\.

*💬 Reply*

**898.** `19:03` **You**

Don't worry about me anyways\.\. I will be good chilling out\.


**899.** `19:08` **Meredith Lamb (+14169386001)**

I won’t let it cut into our time don’t worry


**900.** `19:09` **You**

Mer it is ok any time I get will be appreciated\.  I don't want to be that guy that I feel like I am turning into\.


**901.** `19:09` **You**

Reaction: 😂 from Meredith Lamb
lol I have made fun of that guy


**902.** `19:09` **You**

repeatedly


**903.** `19:10` **Meredith Lamb (+14169386001)**

>
She’s also an iron woman\. She’s a bit nuts\. Never married\. No kids by choice\. She lives basically sex in the city downtown Detroit

*💬 Reply*

**904.** `19:16` **Meredith Lamb (+14169386001)**

I keep getting in trouble for texting\. Doing another coat of paint


**905.** `19:17` **Meredith Lamb (+14169386001)**

lol


**906.** `19:17` **You**

>
yeah pls don't get in trouble\.\. I don't want you getting in trouble with Andrew or caught by anyone else\.

*💬 Reply*

**907.** `19:26` **Meredith Lamb (+14169386001)**

Andrew is doing other work so not around us but Mac might give u trouble if she meets u\.  Kidding


**908.** `20:07` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**909.** `20:11` **You**

I could take an ice dunk no problem\.\.


**910.** `20:18` **Meredith Lamb (+14169386001)**

No thank you\! It is cold up here lol


**911.** `20:19` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**912.** `20:20` **You**

eesh still I like the cold plunge\.


**913.** `20:20` **You**

brave of the kids though


**914.** `20:22` **Meredith Lamb (+14169386001)**

That girl is Mac’s is named Marlowe Andrew\. People in the lake find it very confusing


**915.** `20:22` **Meredith Lamb (+14169386001)**

\*on the lake


**916.** `20:22` **You**

oh yeah the friend you mentioned yesterday\.


**917.** `20:23` **Meredith Lamb (+14169386001)**

Yep that video was at her place


**918.** `20:26` **Meredith Lamb (+14169386001)**

Are you going into office tomorrow


**919.** `20:28` **You**

I think so\.\.\. I don't really feel like it\.\. I probably should I think you and Carolyn are on SDO\.


**920.** `20:29` **Meredith Lamb (+14169386001)**

Yep we are\. I will be doing wallpaper lol


**921.** `20:29` **You**

So probably going in\.\. I don't have a lot of meetings, but short week, not on Friday, and I will probably still be working on this next gen content\.


**922.** `20:39` **Meredith Lamb (+14169386001)**

Yaye fun


**923.** `20:47` **You**

Jaimie talked to Gracie about moving back to Moncton tonight\.\. I think Jaimie would do it now if Gracie would go\.\. Maddie would stay with me for a year then likely go to University in Moncton as my old University has a great educations program there\.


**924.** `20:47` **You**

But Gracie is having none of it\.\.


**925.** `20:48` **You**

House coming on the market for 670k in Moncton basically same as our house today less one bedroom\.\. beautiful house\.\. pool gazeebo almost still too much\.  I still suggested to Jaimie that she consider my idea of moving in with her sister into a 750k plus house\.\. have no mortgage\.\. and save on utilities and property taxes\.


**926.** `20:48` **You**

She lived with them prior to meeting me\.


**927.** `20:49` **You**

Still I am not sure it will be a go\.\. J doesn't want to leave this house\.\. I told her I could keep the house for now\.\. remortgage it for about 500k\.\. give her the 300 or so on top of what we already have to pay for her share of the equity in the new house to have no mortgage


**928.** `20:49` **You**

And then the extra 200 k


**929.** `20:49` **You**

would be 100 for each of us as a cash contingency fund\.


**930.** `20:49` **You**

I would still provide additional support or I would lump sum her with whatever else I have


**931.** `20:50` **Meredith Lamb (+14169386001)**

Oh wow, that his shit is so complicated eh…


**932.** `20:50` **You**

then just pay down the 500k mortgage over time


**933.** `20:50` **Meredith Lamb (+14169386001)**

\*this


**934.** `20:50` **You**

Or eventually sell it depending on us\.


**935.** `20:50` **You**

that is


**936.** `20:51` **Meredith Lamb (+14169386001)**

Do you feel it is a little crazy to say that? “Depending on us” :\)


**937.** `20:51` **Meredith Lamb (+14169386001)**

Like how did we get here lol


**938.** `20:51` **You**

No\.\. more hopeful\.


**939.** `20:52` **Meredith Lamb (+14169386001)**

Same but it is still crazy to me


**940.** `20:52` **You**

It is absolutely crazy mer\.\. but it is a crazy I NEVER thought I would experience, or even existed\.


**941.** `20:53` **You**

the more I think about it\.\. the more it floors me\.


**942.** `20:53` **Meredith Lamb (+14169386001)**

It is hard to go so long without seeing you though\.


**943.** `20:53` **Meredith Lamb (+14169386001)**

Don’t like it


**944.** `20:53` **Meredith Lamb (+14169386001)**

What if we did not get together on Thursday night?\!?


**945.** `20:53` **You**

hm?? omg


**946.** `20:53` **You**

yeah I would be hurting right now\.


**947.** `20:53` **Meredith Lamb (+14169386001)**

Like it would be even HARDWR


**948.** `20:53` **You**

well more than this


**949.** `20:53` **Meredith Lamb (+14169386001)**

HARDER


**950.** `20:54` **Meredith Lamb (+14169386001)**

yeah


**951.** `20:54` **Meredith Lamb (+14169386001)**

Gah


**952.** `20:57` **You**

I think the thing is if there is a future for us\.\. and we are each bought in\.\. I can deal with it\.\. I can deal with anything\.\. my worry is that I have kind of went from cold dispassionate logical Scott\.\. to the Pre 18 all in lovemonkey Scott\. And this version of me, at least personally\.\.\. I guess I am out of balance swinging so hard and so fast and so truthfully the other way \- I am afraid of getting hurt\.\. tbh\.  Again lame as shit\.\. but I have tried to be honest about anything to a fault\.


**953.** `20:58` **Meredith Lamb (+14169386001)**

What if you decide to return to that guy?


**954.** `20:58` **Meredith Lamb (+14169386001)**

I upset you or something


**955.** `20:59` **You**

I mean that is who you liked in the first place\.\. you didn't know this guy\.\. this was a\. bonus I guess?


**956.** `20:59` **You**

lol


**957.** `20:59` **Meredith Lamb (+14169386001)**

Touché


**958.** `20:59` **You**

not what you expected I am sure


**959.** `21:00` **You**

You might like the other guy better even\.\. much more chill\.\. easy going\.\. but more wary\.\. you remember our early conversations\.\. where I would be really careful of the words I used etc


**960.** `21:00` **You**

Reaction: 🙂 from Meredith Lamb
and then I just turned it off completely\.\.


**961.** `21:00` **Meredith Lamb (+14169386001)**

You have definitely turned into Scott \+ bonus\. I really wouldn’t have imagined\. Although it has always been obvious that you are a caring person\.


**962.** `21:01` **You**

If we ended I would probably need to put the monkey away for a long time\.\. it's not like I wasn't capable of being fine as my old self\.  But beyond that\.\. there is nothing you could do\.


**963.** `21:01` **You**

Defense mechanism and all


**964.** `21:01` **You**

But nothing I haven't done before\.\.


**965.** `21:02` **Meredith Lamb (+14169386001)**

I just didn’t think you would be so expressive of your emotions\. Did not see that coming\. I’m not that great at it honestly\. I may be too flat expressive wise for you


**966.** `21:02` **Meredith Lamb (+14169386001)**

>
Stop, we are not ending\.

*💬 Reply*

**967.** `21:02` **You**

>
I didn't either\.

*💬 Reply*

**968.** `21:03` **You**

All of those things\.\. I would have said those about me 6 weeks ago


**969.** `21:03` **You**

100%


**970.** `21:03` **You**

When did you go to universal?


**971.** `21:04` **Meredith Lamb (+14169386001)**

Um February …


**972.** `21:04` **Meredith Lamb (+14169386001)**

Like second week


**973.** `21:04` **Meredith Lamb (+14169386001)**

Ish


**974.** `21:04` **Meredith Lamb (+14169386001)**

Around there


**975.** `21:04` **You**

And we had started kind of chatting at that point right?  But very safe


**976.** `21:04` **Meredith Lamb (+14169386001)**

Teeny tiny bit


**977.** `21:04` **You**

I had started thinking about this then\.\. with any degree of seriousness\.


**978.** `21:05` **You**

I can remember\.


**979.** `21:05` **Meredith Lamb (+14169386001)**

You had or hadn’t?


**980.** `21:05` **You**

I had


**981.** `21:05` **Meredith Lamb (+14169386001)**

Yeah I kind of did also tbh


**982.** `21:05` **You**

But it was light\.\. more of a day dream kind of thing\.


**983.** `21:06` **Meredith Lamb (+14169386001)**

Never in a million years would I have thought anything would happen tho


**984.** `21:07` **You**

anyhow the expressiveness can be chalked up to my writing \- it is my trade \- so I do tend to be a little descriptive / articulate\.  But the rest the opening up\.\. was unexpected\.\. I think I wanted to prove to you how much you meant to me\.\. and felt like I need to take the jump first\.


**985.** `21:07` **You**

and then the jump just kept falling\.


**986.** `21:08` **You**

still is


**987.** `21:09` **Meredith Lamb (+14169386001)**

I know…\.\. it is the strangest thing with all the chaos going on in the background for both of us\. It doesn’t seem to affect my feelings for you at all and that seems odd to me\.


**988.** `21:10` **You**

Nothing touches this \- but listen I don't need you to do the things I do, say the things I say, write notes or shit like that\.\. that is just me\.\. well apparently is me now\.\. just be you\.\. again as long as I know we are all in together I think I can hack this\.


**989.** `21:11` **Meredith Lamb (+14169386001)**

I do want to more and more but I do still worry about it making things harder\. Like after Detroit/chatham for instance\. We go from that to NOTHING again\.


**990.** `21:12` **Meredith Lamb (+14169386001)**

It’s like constant whiplash


**991.** `21:12` **You**

then we make it really good\.\. :\)


**992.** `21:12` **Meredith Lamb (+14169386001)**

:\)


**993.** `21:12` **You**

I talked to J about renting tonight\.


**994.** `21:13` **Meredith Lamb (+14169386001)**

How’d that go?


**995.** `21:13` **You**

so the thing is\.\. if you are renting and I am renting\.\. there will be times when we can just drive and meet somewhere\.\. visiting your parents in oshawa will be easier


**996.** `21:13` **You**

the basement may be available


**997.** `21:13` **You**

lol


**998.** `21:13` **You**

I have thought a lot about it\.\. I really think we can make a go of this\.  But yeah it isn't going to be the easiest\.\. it is just worth it to me\.


**999.** `21:13` **Meredith Lamb (+14169386001)**

I’ve been looking at some condos


**1000.** `21:14` **Meredith Lamb (+14169386001)**

Can’t decide


**1001.** `21:14` **You**

for me it is more rent until I can decide long term plans


**1002.** `21:14` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/28153881/2902s\-127\-broadway\-avenue\-toronto\-mount\-pleasant\-west\-mount\-pleasant\-west?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**1003.** `21:14` **You**

or she goes to Moncton


**1004.** `21:15` **Meredith Lamb (+14169386001)**

What did she say about the idea?


**1005.** `21:15` **Meredith Lamb (+14169386001)**

The renting


**1006.** `21:15` **Meredith Lamb (+14169386001)**

Not Moncton


**1007.** `21:15` **You**

She doesn't like the idea of renting \- waste of money


**1008.** `21:15` **You**

but she understands\.


**1009.** `21:15` **You**

the one you showed is nice\.


**1010.** `21:15` **Meredith Lamb (+14169386001)**

Andrew sent it to me


**1011.** `21:16` **You**

Ironically if I wanted something similar out here\.\. it wouldn't be a lot less\.


**1012.** `21:16` **You**

But I won't do 3 bedroom\.  I am shooting 2 bed 2 bath \+ den


**1013.** `21:16` **You**

Reaction: 😂 from Meredith Lamb
around 2,500 a month \+ utilities \+ who the fuck knows what else


**1014.** `21:17` **Meredith Lamb (+14169386001)**

That condo is very close to girls high school


**1015.** `21:17` **You**

yeah the only decent places for me are within walking distance of here\.


**1016.** `21:17` **You**

I kind of hope the option to keep the house and stay in it with maddie for a year is possible\.\. at least\. if J goes to Moncton\.


**1017.** `21:18` **Meredith Lamb (+14169386001)**

But if Gracie won’t do it


**1018.** `21:18` **You**

Then I need to rent\.\. and bring on whatever we can manage for however long until I feel we can let others know\.\. again that cannot happen until you don't work for me anymore or I am not your boss and I move on\.


**1019.** `21:19` **You**

that to me is still the kicker\.


**1020.** `21:19` **You**

and I need to figure out how to make that happen I feel\.


**1021.** `21:19` **Meredith Lamb (+14169386001)**

Yah that one is going to be a bit of a challenge


**1022.** `21:19` **Meredith Lamb (+14169386001)**

Just timing


**1023.** `21:19` **You**

naw\.\. I think with the right job opp\.\. under say Cara \- she'd take me


**1024.** `21:20` **Meredith Lamb (+14169386001)**

If Geoff goes to baileys group I could go back to my old role lol


**1025.** `21:20` **You**

no please don't do that\.


**1026.** `21:20` **You**

you would take a pay cut\.


**1027.** `21:20` **Meredith Lamb (+14169386001)**

Ppl would be like wtf


**1028.** `21:21` **Meredith Lamb (+14169386001)**

lol


**1029.** `21:21` **You**

yeah no\.\.


**1030.** `21:21` **You**

now if it was a lateral somewhere else\.\. that might work\.\. you could just say I am an ass to work for\.


**1031.** `21:21` **Meredith Lamb (+14169386001)**

We will figure it out\. I’d prefer not to rush the work thing and rush my living situation first


**1032.** `21:22` **Meredith Lamb (+14169386001)**

Doing both at once feels so massive


**1033.** `21:22` **You**

I just keep on the lookout to see what is available\.\. that is all I am doing\.\. nothing more than that for the time being\.


**1034.** `21:22` **Meredith Lamb (+14169386001)**

k, good


**1035.** `21:23` **Meredith Lamb (+14169386001)**

I think it is manageable in the short term… if you don’t do anything stupid


**1036.** `21:23` **Meredith Lamb (+14169386001)**

lol


**1037.** `21:23` **You**

I cannot see me doing anything stupid\.  Not at work\.\. and I have been pretty careful\.\. everything is locked down now\.\. literally\.\. no one can get into anything of mine anymore\.


**1038.** `21:24` **You**

I am slowly transfering all of my passwords into a new LastPass account etc\.\.


**1039.** `21:24` **Meredith Lamb (+14169386001)**

No one has mentioned the find my thing?


**1040.** `21:24` **You**

they gave up


**1041.** `21:24` **You**

see this is where our situations are a bit different\.


**1042.** `21:25` **You**

You have your kids\.\. and their support whether it be mac and what she knows or the others\.\. I don't have that\.\.


**1043.** `21:25` **You**

So like the time apart thing\.\. might hit me a bit harder\.


**1044.** `21:25` **Meredith Lamb (+14169386001)**

I thought maddie was supportive? Did that turn?


**1045.** `21:25` **You**

yep


**1046.** `21:26` **You**

maybe not completely\.\. but it didn't go how I thought it would\.


**1047.** `21:26` **Meredith Lamb (+14169386001)**

:\(


**1048.** `21:26` **Meredith Lamb (+14169386001)**

Things will keep adjusting


**1049.** `21:26` **You**

yep\.\. it's all good\.  i just keep moving forward\.


**1050.** `21:27` **Meredith Lamb (+14169386001)**

Well you have me fully and completely


**1051.** `21:27` **You**

>
I hope so\. :\)

*💬 Reply*

**1052.** `21:27` **Meredith Lamb (+14169386001)**

So next Saturday…\.\.


**1053.** `21:28` **You**

yep\.\. was hoping to see one of Mac's games\.


**1054.** `21:28` **Meredith Lamb (+14169386001)**

Only a gazillion days to go


**1055.** `21:28` **You**

quietly


**1056.** `21:28` **You**

in the back of no where


**1057.** `21:28` **You**

but if not possible


**1058.** `21:28` **You**

I wont go


**1059.** `21:28` **Meredith Lamb (+14169386001)**

Possible but we would not sit together


**1060.** `21:28` **You**

oh I know


**1061.** `21:29` **Meredith Lamb (+14169386001)**

I’m not sure what parents are going but someone would mention to Andrew or take a video with us in background or whatever


**1062.** `21:29` **You**

Reaction: 👍 from Meredith Lamb
no you don't know me I don't know you\.\. I get it\.


**1063.** `21:30` **You**

I don't have to come\.\. if you are worried\.\. Mac might not even want me to for that matter\.  It's all good\.\. I can find things to keep me busy


**1064.** `21:31` **Meredith Lamb (+14169386001)**

She wouldn’t likely notice\. It is at a venue with 80 courts


**1065.** `21:31` **You**

well she doesn't know what I look like so there is that


**1066.** `21:31` **Meredith Lamb (+14169386001)**

Well she saw Brett’s cartoon


**1067.** `21:32` **Meredith Lamb (+14169386001)**

lol


**1068.** `21:32` **You**

I think I can pull off not looking like that


**1069.** `21:32` **Meredith Lamb (+14169386001)**

Yeah would be fine


**1070.** `21:33` **You**

will play it by ear\.\. again\.\. you have commitments and friends\.\. they come first\.


**1071.** `21:33` **Meredith Lamb (+14169386001)**

No they don’t lol


**1072.** `21:33` **Meredith Lamb (+14169386001)**

Let’s be real


**1073.** `21:33` **Meredith Lamb (+14169386001)**

Haha


**1074.** `21:34` **You**

Yeah they do mer\.\. I don't expect to come first\.\. honestly\.\. I know and I hope this is going to be an epic few days with you, whenever I can get a chance\.\. but I don't expect to come first\.\. and that is fine with me\. :\)


**1075.** `21:35` **Meredith Lamb (+14169386001)**

Well I am a little obsessed right now so you might just have to expect it


**1076.** `21:35` **Meredith Lamb (+14169386001)**

Mac is pretty self sufficient


**1077.** `21:35` **Meredith Lamb (+14169386001)**

When at vball tournament


**1078.** `21:35` **Meredith Lamb (+14169386001)**

I just have to get her lunch all the time


**1079.** `21:35` **Meredith Lamb (+14169386001)**

I get this very specific order :P


**1080.** `21:36` **You**

>
of course you do\.\. all measured out\.

*💬 Reply*

**1081.** `21:36` **Meredith Lamb (+14169386001)**

And then I get barked at when to leave and go get it etc etc


**1082.** `21:36` **You**

>
Whatever i can get\.\. :\)

*💬 Reply*

**1083.** `21:36` **Meredith Lamb (+14169386001)**

She’s super annoying about it


**1084.** `21:38` **Meredith Lamb (+14169386001)**

All of your reports want to have dinner on Sunday\. Did you know that


**1085.** `21:39` **You**

Including you I guess lol


**1086.** `21:39` **You**

I still have to book Sunday and Monday night\.\. haven't done that yet


**1087.** `21:40` **Meredith Lamb (+14169386001)**

>
They told me to bring Mac

*💬 Reply*

**1088.** `21:40` **Meredith Lamb (+14169386001)**

lol


**1089.** `21:40` **You**

Oh for fuck sakes


**1090.** `21:40` **You**

I am not going


**1091.** `21:40` **Meredith Lamb (+14169386001)**

Haha I am not


**1092.** `21:40` **Meredith Lamb (+14169386001)**

LOL


**1093.** `21:40` **Meredith Lamb (+14169386001)**

She wouldn’t go anyway


**1094.** `21:40` **You**

You guys go I will make up an excuse


**1095.** `21:41` **You**

Reaction: 😂 from Meredith Lamb
she would smirk at me whole time


**1096.** `21:41` **Meredith Lamb (+14169386001)**

Your reaction … so funny


**1097.** `21:41` **You**

and I wouldn't be able to keep a straight face


**1098.** `21:41` **Meredith Lamb (+14169386001)**

She would never go don’t worry


**1099.** `21:42` **Meredith Lamb (+14169386001)**

>
I cannot even imagine that situation\. Louise and Carolyn were like “omg bring her”

*💬 Reply*

**1100.** `21:42` **You**

yeah\.\. :\(


**1101.** `21:42` **You**

oh did you decide on Tuesday yet\.\. chatham not sales dinner\.


**1102.** `21:43` **Meredith Lamb (+14169386001)**

No


**1103.** `21:43` **Meredith Lamb (+14169386001)**

Mac wants to stay


**1104.** `21:43` **Meredith Lamb (+14169386001)**

I honestly have nothing WORK RELATED to stay for


**1105.** `21:43` **You**

get creative


**1106.** `21:43` **You**

that's what I do


**1107.** `21:44` **Meredith Lamb (+14169386001)**

My Oshawa visits have been pretty creative


**1108.** `21:44` **You**

true\.\. yes very much appreciated


**1109.** `21:44` **Meredith Lamb (+14169386001)**

I save my creativity for my parents lol


**1110.** `21:46` **Meredith Lamb (+14169386001)**

Hurt my neck painting\. Too much edging ceilings


**1111.** `21:46` **You**

painting is no fun\.


**1112.** `21:46` **Meredith Lamb (+14169386001)**

Ugh feels so crappy


**1113.** `21:46` **You**

go take a bath or a long shower\.


**1114.** `21:46` **Meredith Lamb (+14169386001)**

Like I am done for the night I think


**1115.** `21:46` **Meredith Lamb (+14169386001)**

Mac is still going


**1116.** `21:59` **Meredith Lamb (+14169386001)**

I forgot to tell you that I talked to Andrew about how he thinks sharing the cottage would work if we ended up dating other ppl\. I asked if he would be really nasty or angry with me\. Just because he never let me even say my ex’s name and was very dramatic about it all\. He goes “I don’t think I was dramatic”\. lol I said, ok extreme then\. Then: “I thought you said you weren’t going to date anyone?”


**1117.** `22:00` **You**

how did that progress from there\.


**1118.** `22:00` **You**

btw tell me your ex's name so we can get this out of the way


**1119.** `22:00` **You**

since I give zero shits


**1120.** `22:00` **Meredith Lamb (+14169386001)**

I just explained that I don’t we should be naive and we should plan for any potential scenarios that could cause strife


**1121.** `22:01` **Meredith Lamb (+14169386001)**

>
lol Jeremy

*💬 Reply*

**1122.** `22:01` **You**

Strife \- now who is using the words\.


**1123.** `22:01` **You**

>
I have had a few Jeremy friends :\)

*💬 Reply*

**1124.** `22:01` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
I actually used that word


**1125.** `22:02` **Meredith Lamb (+14169386001)**

Anyway he said he thinks it would be fine\. He said he’s more concerned about a new guy being around the kids and not as much around me or cottage


**1126.** `22:02` **Meredith Lamb (+14169386001)**

😬


**1127.** `22:02` **Meredith Lamb (+14169386001)**

The\. I thought about Detroit


**1128.** `22:02` **Meredith Lamb (+14169386001)**

lol


**1129.** `22:02` **Meredith Lamb (+14169386001)**

\*Then


**1130.** `22:02` **You**

well I shouldn't meet Mac then


**1131.** `22:02` **You**

It is fair that he is concerned\.  We should meet before anything like that happens\.


**1132.** `22:03` **You**

above board and all\.\. might make it much easier in the long run\.


**1133.** `22:03` **You**

Like I said\.\. I can play it so I come accross the right amount of non\-threatening and humble\.


**1134.** `22:04` **You**

The mother of every girlfriend I have ever had would attest to my ability to charm :\)


**1135.** `22:04` **You**

The dads \.\.\.\. well 90% success rate


**1136.** `22:04` **Meredith Lamb (+14169386001)**

Haha I have nothing doubt


**1137.** `22:04` **You**

never tried with Ex's though


**1138.** `22:05` **Meredith Lamb (+14169386001)**

It will be super awkward


**1139.** `22:06` **You**

Kinda has to happen though\.


**1140.** `22:06` **Meredith Lamb (+14169386001)**

That’s a ways out lol


**1141.** `22:06` **You**

job change first


**1142.** `22:06` **You**

yep


**1143.** `22:06` **Meredith Lamb (+14169386001)**

I feel like it will be more awkward with Jaime and I if we have to see each other


**1144.** `22:07` **You**

Jaimie would never come up to our floor if she knew


**1145.** `22:07` **Meredith Lamb (+14169386001)**

At least you have never met Andrew


**1146.** `22:07` **You**

ever


**1147.** `22:07` **You**

she would never confront you


**1148.** `22:07` **You**

not even in the parking lot


**1149.** `22:07` **Meredith Lamb (+14169386001)**

But there may be a point in time where we come across each other


**1150.** `22:07` **Meredith Lamb (+14169386001)**

Inevitable


**1151.** `22:07` **You**

sure and she will be her typical cold self\.\. unless she grows up


**1152.** `22:08` **You**

nothing to be done there\.


**1153.** `22:08` **You**

same with Gracie who knows how she will react\.\.


**1154.** `22:08` **You**

Maddie I think will come around and eventually adore you


**1155.** `22:08` **You**

Katie will adore you for sure\!\!


**1156.** `22:08` **You**

I mean said thing is I have no more family\.


**1157.** `22:08` **You**

sad


**1158.** `22:09` **You**

Mum would have loved you Dad too\.\. I expect\.


**1159.** `22:10` **Meredith Lamb (+14169386001)**

What about aunts and uncles and cousins?


**1160.** `22:11` **You**

I have an uncle \- not close \- dad's half brother\.


**1161.** `22:11` **You**

remember I am n oit techincally related


**1162.** `22:11` **Meredith Lamb (+14169386001)**

And on mom’s side?


**1163.** `22:11` **Meredith Lamb (+14169386001)**

Only child?


**1164.** `22:12` **You**

only child


**1165.** `22:12` **You**

I have a 2nd cousin who was like an aunt\.


**1166.** `22:12` **Meredith Lamb (+14169386001)**

Wild


**1167.** `22:12` **Meredith Lamb (+14169386001)**

My parents each had 3 sisters


**1168.** `22:12` **You**

but she is pretty straight laced\.\. so unsure\.  I expect she would understand after an explanation\.


**1169.** `22:12` **You**

the generation before had like 40 relatives


**1170.** `22:12` **You**

between 2 families'


**1171.** `22:12` **Meredith Lamb (+14169386001)**

I have too many cousins to count


**1172.** `22:13` **Meredith Lamb (+14169386001)**

I can guarantee part of my family already knows


**1173.** `22:13` **Meredith Lamb (+14169386001)**

My mom told at least one of 3 sisters


**1174.** `22:13` **Meredith Lamb (+14169386001)**

Who probably told some of my cousins but maybe not


**1175.** `22:13` **Meredith Lamb (+14169386001)**

Not sure


**1176.** `22:14` **Meredith Lamb (+14169386001)**

I think there are 14 of us in my generation and then everyone has kids so not sure how many in my kids generation


**1177.** `22:14` **Meredith Lamb (+14169386001)**

So many cousins


**1178.** `22:15` **Meredith Lamb (+14169386001)**

Complete opposite of you


**1179.** `22:15` **Meredith Lamb (+14169386001)**

It’s exhausting


**1180.** `22:21` **You**

yeah\.\. but is she telling them good things or bad things\.


**1181.** `22:21` **You**

Just booked retro 2 nights\.\.


**1182.** `22:22` **You**

Reaction: 👍 from Meredith Lamb
all done that bit\.


**1183.** `22:43` **Meredith Lamb (+14169386001)**

Feeling super shitty\. Sore neck, tired\. I’m going to bed\. Love you and hope your day at work is good\. xoxo


**1184.** `22:44` **You**

Love you too\.\. sorry you are feeling bad\.\. hope you have a good night and day tomorrow\.\. xoxo


**1185.** `22:46` **You**

Sorry I got all messed up today\.  It sucked, I will do a better job of keeping it under wraps\.


