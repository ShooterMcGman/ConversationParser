# Daily Conversation: 2025-05-08 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-08 |
| **Day** | Thursday |
| **Week** | 4 |
| **Messages** | 237 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-08T00:02 - 2025-05-08T23:02 |

## 📝 Daily Summary

This day contains **237 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:02` **Meredith Lamb (+14169386001)**

k 😋


**002.** `00:14` **You**

https://www\.airbnb\.com/l/ELn7dQaA


**003.** `04:32` **You**

Kept me up too late with your musicians as sexual icon shenanigans… I will no better next time\.


**004.** `04:33` **You**

Love you…


**005.** `05:36` **You**

Oh and my ass hurts\.\. leg day was hard going to walk funny
Today\.


**006.** `06:20` **You**

Maybe pic this morning since you not coming in??


**007.** `06:20` **You**

Trade?


**008.** `06:23` **You**

Like a hungover pic of my love
For whatever I’ve got\.\. will trade\.


**009.** `06:33` **Meredith Lamb (+14169386001)**

>
This place is cool\. Who knew … the shwa…

*💬 Reply*

**010.** `06:34` **Meredith Lamb (+14169386001)**

>
lol back to sleep for a bit

*💬 Reply*

**011.** `06:34` **You**

Just give me the nod whenever and I will book\.\.


**012.** `06:34` **You**

Remember trade hungover pic I wasn’t it\.\.
lol


**013.** `06:36` **You**

Will make it worth it


**014.** `06:36` **You**

☺️


**015.** `09:33` **You**

Guessing you woke up late


**016.** `09:33` **You**

lol


**017.** `09:33` **Meredith Lamb (+14169386001)**

Sorry I didn’t respond to this\. There will be no hungover 47 yr old photos of me in existence online ever\.


**018.** `09:34` **You**

Ok then no fun stuff for you


**019.** `09:34` **Meredith Lamb (+14169386001)**

Erin called so talked to her for 45 min


**020.** `09:34` **Meredith Lamb (+14169386001)**

I told her I’m going to take Geoff’s role\. She freaked out\. Lol


**021.** `09:34` **You**

lol


**022.** `09:34` **Meredith Lamb (+14169386001)**

I said I was kidding …\. Kind of


**023.** `09:34` **Meredith Lamb (+14169386001)**

lol


**024.** `09:34` **You**

You do you


**025.** `09:34` **You**

I will supportive


**026.** `09:35` **Meredith Lamb (+14169386001)**

I’m honestly going to think about it\. I told her it might ruin my rep


**027.** `09:35` **Meredith Lamb (+14169386001)**

She didn’t think so


**028.** `09:45` **You**

It’s truly up to you there are different people that think different things\.\.


**029.** `09:45` **You**

I might wait


**030.** `09:45` **You**

I don’t want you moving out of some sense that I am going to lose my shit


**031.** `09:45` **You**

It needs to make sense


**032.** `09:45` **You**

I mean if they could bunp it to a 510 expand the role


**033.** `09:45` **You**

You could talk to Daniel


**034.** `09:45` **You**

Or I could


**035.** `09:46` **You**

It I think I would need to come clean on a few things, not that we are in a relationship but that one might develop down the road


**036.** `10:35` **Meredith Lamb (+14169386001)**

Hmmh


**037.** `10:36` **Meredith Lamb (+14169386001)**

Honestly I have so much going on in my life I wouldn’t even care if it is a 510


**038.** `10:36` **Meredith Lamb (+14169386001)**

It would bother me leaving the team tho … would feel bad


**039.** `10:37` **You**

I think you should speak to Daniel and I think we would need to tell him something


**040.** `10:38` **Meredith Lamb (+14169386001)**

Why would we need to?


**041.** `10:38` **You**

Because if and when it comes out later it will be obvious


**042.** `10:38` **You**

Or maybe\. Or I dunno


**043.** `10:38` **Meredith Lamb (+14169386001)**

But why would that matter?


**044.** `10:39` **You**

Optics


**045.** `10:39` **You**

I mean we could say clearly nothing g happened but it is about your motivations


**046.** `10:39` **You**

If you moved back so we could date the\. That would be Eesh


**047.** `10:40` **Meredith Lamb (+14169386001)**

I mean I enjoy policy more so that is a very real story\. I’m also overwhelmed with this team and my personal life\. So it is two fold\.


**048.** `10:42` **You**

Ok if that is what you want\.\. but again I would talk to Daniel we would need\. A story for Ian cause he will ask\.\. and we could keep everything quiet here for months easily


**049.** `10:42` **You**

I am not worried about that I am worried about you\.\.


**050.** `10:42` **You**

All I care about


**051.** `10:43` **Meredith Lamb (+14169386001)**

Isn’t my “story” \(which is real\) good for Ian?


**052.** `10:43` **You**

I can only get it one night so will have to find another place for the next night I think\.\. need to figure some shit out or I find another pls e


**053.** `10:43` **You**

It is\.\.


**054.** `10:43` **You**

Thinking long term


**055.** `10:43` **You**

But yeah


**056.** `10:43` **You**

Just let me know what and when o will end up having to speak with Daniel he will want to ask


**057.** `10:44` **Meredith Lamb (+14169386001)**

He will want to ask what?


**058.** `10:46` **Meredith Lamb (+14169386001)**

Ps\. Erin already knows\. We’ve talked about it a few times\.


**059.** `10:46` **You**

He will just want to talk to me mgr to mgr to ask if I am ok with this


**060.** `10:47` **You**

Ok I kinda need to know this how long on sat did you plan on hanging out


**061.** `10:47` **Meredith Lamb (+14169386001)**

Just tell him I can’t hack this job lol


**062.** `10:47` **You**

No


**063.** `10:48` **Meredith Lamb (+14169386001)**

Yes


**064.** `10:48` **You**

It will depend what I book


**065.** `10:48` **Meredith Lamb (+14169386001)**

>
Not beyond lunch for sure

*💬 Reply*

**066.** `10:48` **Meredith Lamb (+14169386001)**

I have to drive back to Toronto to get my girls


**067.** `10:48` **You**

Ok late checkout is lunch so that is fine


**068.** `10:49` **You**

Yep I get it\.  I will pick up and move somewhere else for the next night


**069.** `10:49` **You**

Sucks because both nights were open last night just bad luck


**070.** `10:50` **Meredith Lamb (+14169386001)**

Nowhere else?


**071.** `10:50` **You**

I mean I could look but it isn’t like you can come back anyways so not a huge deal


**072.** `10:51` **Meredith Lamb (+14169386001)**

k


**073.** `10:52` **You**

I will let you know where the second one I book is anyways just so you can keep tabs on me\.


**074.** `10:54` **Meredith Lamb (+14169386001)**

lol ok


**075.** `10:55` **You**

You know or for whatever other reasons\.\. 🥰


**076.** `10:55` **You**

Alright booking now


**077.** `10:55` **You**

I will need an image of if though


**078.** `12:00` **You**

Can you talk


**079.** `12:00` **You**

Nm you on a call


**080.** `12:37` **You**

Offer being submitted


**081.** `12:37` **You**

Reaction: 😬 from Meredith Lamb
Sick to my stomach


**082.** `12:39` **You**

Gah I wish we had 2 days\.\. who is a greedy boy\!?


**083.** `12:40` **Meredith Lamb (+14169386001)**

Yeah really holy


**084.** `12:42` **You**


*📎 1 attachment(s)*

**085.** `12:42` **You**

That is how close to your parents house


**086.** `12:43` **Meredith Lamb (+14169386001)**

Nice


**087.** `12:43` **Meredith Lamb (+14169386001)**

I won’t have to turn my find my off


**088.** `12:43` **Meredith Lamb (+14169386001)**

For my little shadow


**089.** `12:44` **You**

Checkin is 4 pm I will be finishing work early it seems


**090.** `12:44` **You**

Yay


**091.** `12:45` **Meredith Lamb (+14169386001)**

Debating working from my parents tomorrow\.


**092.** `12:45` **Meredith Lamb (+14169386001)**

Will see


**093.** `12:45` **Meredith Lamb (+14169386001)**

The drive is awful during rush hour


**094.** `12:48` **You**

Scott is sharing details of an upcoming trip\.
This invite expires in 7 days\.
https://expe\.app\.link/Nk4iu9pUcTb


**095.** `12:49` **You**

Prolly not a bad idea save a lot of time


**096.** `14:17` **You**

Love you cranky girl… ❤️


**097.** `14:20` **Meredith Lamb (+14169386001)**

I need a nap lol \(I am not a volt of lightning\) love you too


**098.** `14:32` **You**

You are something\.\. always something else to learn\.\. so many layers… and sexual fantasies to figure out… should make things interesting at least\.\. I am boring in comparison but hey I will
Try whatever you want me to \- drug or otherwise\.


**099.** `14:44` **Meredith Lamb (+14169386001)**

lol you are hardly boring\. Omg


**100.** `15:50` **You**

I feel like I am I so don’t want to lose you omg\.\. how bad does that sound lol…
I am the saddest person o\. Earth and never saw myself
Like this nor acted like this\.\. Jesus\.\. kk ignore everything I just said\.\. what have you done to me\!\!\! lol


**101.** `15:56` **You**

Doing seating will call you after if you can take a call


**102.** `15:57` **Meredith Lamb (+14169386001)**

>
Omg… lol

*💬 Reply*

**103.** `15:58` **Meredith Lamb (+14169386001)**

>
k, I’m around just reading IRP 😛

*💬 Reply*

**104.** `16:19` **You**

Yeah having a moment here all triggered by yku switching teams how does that even make any sense wtf seriously I am broken


**105.** `16:35` **Meredith Lamb (+14169386001)**

Our work situation is becoming untenable and I don’t really love this role anyway\. It’s a bit much especially going through separation and I will be living alone etc etc\. lots of adjustments \.\. youngest starting middle school, middle starting high school etc etc it is just a lot


**106.** `16:37` **Meredith Lamb (+14169386001)**

You are good in your role and everyone loves you\. You should stay\. Makes no sense for you to leave


**107.** `16:48` **You**

I am not having an issue with you doing this\.\. I just had some stupid triggered moment of you leaving the team and equating it to leaving me for some reason\.\.


**108.** `16:48` **You**

Stuck doing seating assignments so annoyed


**109.** `16:48` **You**

Just too much atm too much\.


**110.** `16:52` **Meredith Lamb (+14169386001)**

>
Definitely not the case\.

*💬 Reply*

**111.** `17:03` **You**

You can show me tomorrow\.


**112.** `17:20` **Meredith Lamb (+14169386001)**

Sure


**113.** `17:31` **You**

I know I am being crazy too much change today\.\.


**114.** `17:31` **You**

Cannot process


**115.** `17:31` **You**

We have been back and forth on house already once


**116.** `17:31` **You**

I suspect we close tonight


**117.** `17:42` **You**

Going to car jow


**118.** `17:50` **Meredith Lamb (+14169386001)**

>
That is overwhelming change for sure

*💬 Reply*

**119.** `20:26` **Meredith Lamb (+14169386001)**

So survived open house… it was the same the third time around\. Imagine that\. :p


**120.** `20:33` **You**

Omg shocking


**121.** `20:33` **You**

Out buying shoes


**122.** `20:39` **You**

So you are cranky again tonight 🙁


**123.** `20:40` **Meredith Lamb (+14169386001)**

Kinda\. Watching some tv


**124.** `20:40` **You**

I think you need a glass


**125.** `20:40` **Meredith Lamb (+14169386001)**

lol no


**126.** `20:40` **You**

Or 5


**127.** `20:40` **Meredith Lamb (+14169386001)**

I will stay up too late


**128.** `20:40` **You**

94 some edibles


**129.** `20:41` **Meredith Lamb (+14169386001)**

I want to go to sleep earlier


**130.** `20:41` **Meredith Lamb (+14169386001)**

I do have lots of gummies lol


**131.** `20:42` **You**

Kk I will be up late


**132.** `20:42` **You**

Going to try new shoes out


**133.** `20:43` **You**

Since I not getting up early


**134.** `20:43` **You**

And actually working from home


**135.** `20:44` **You**

Bout to drive home


**136.** `20:44` **You**

So out of touch for a few mins


**137.** `20:45` **Meredith Lamb (+14169386001)**

k ❤️


**138.** `21:09` **You**

Sorry I was a bit occupied unfortunately apologies ❤️❤️❤️


**139.** `21:10` **You**

Love you sorry you are having a bad night tomorrow night will be better


**140.** `21:12` **Meredith Lamb (+14169386001)**

Can’t wait\!


**141.** `21:12` **You**

Same\.\. watcha watching\.\. I am just getting ready to head out


**142.** `21:14` **Meredith Lamb (+14169386001)**

Four seasons


**143.** `21:14` **Meredith Lamb (+14169386001)**

Head out to gym?


**144.** `21:19` **You**

Yep


**145.** `21:20` **You**

Sorry had to
Get out to car


**146.** `21:20` **You**

Annoying tonight


**147.** `21:20` **You**

You have a quiet night till happy whatever is ice


**148.** `21:20` **You**

O we


**149.** `21:21` **You**

Over……


**150.** `21:21` **You**

Anyways here if you need me


**151.** `21:22` **Meredith Lamb (+14169386001)**

You had an annoying night?


**152.** `21:22` **You**

Yep


**153.** `21:22` **Meredith Lamb (+14169386001)**

Why?


**154.** `21:22` **You**

Fought all way to mall all way back


**155.** `21:22` **You**

Gracie


**156.** `21:22` **You**

About


**157.** `21:22` **Meredith Lamb (+14169386001)**

Ohh


**158.** `21:22` **You**

Bullshit


**159.** `21:23` **You**

Definition of insanity


**160.** `21:23` **Meredith Lamb (+14169386001)**

So no progress at all


**161.** `21:24` **You**

Not with Gracie\. It house is about 1 negotiation from done


**162.** `21:24` **You**

If she decides to close


**163.** `21:24` **You**

lol who knows


**164.** `21:24` **You**

I mean I think she will


**165.** `21:24` **Meredith Lamb (+14169386001)**

Oh wow


**166.** `21:24` **You**

Probably in morning tomorrow


**167.** `21:25` **Meredith Lamb (+14169386001)**

That’s wild…


**168.** `21:25` **Meredith Lamb (+14169386001)**

Seems fast considering where she was a short time ago


**169.** `21:25` **You**

Everything is wild


**170.** `21:25` **Meredith Lamb (+14169386001)**

True


**171.** `21:26` **Meredith Lamb (+14169386001)**

lol


**172.** `21:26` **You**

Not always in a good way


**173.** `21:26` **You**

Most of the time not\.\.


**174.** `21:26` **You**

Man


**175.** `21:26` **You**

Just want this over with


**176.** `21:26` **Meredith Lamb (+14169386001)**

Yeah same\.\.


**177.** `21:29` **Meredith Lamb (+14169386001)**

It will all be worth it \.\.


**178.** `21:30` **You**

I hope you always feel that way


**179.** `21:31` **Meredith Lamb (+14169386001)**

Same to you…


**180.** `21:32` **Meredith Lamb (+14169386001)**

Once I leave your team no replacing me and doing this all over again


**181.** `21:32` **You**

Oh I know I will lol\.\.


**182.** `21:32` **Meredith Lamb (+14169386001)**

😛


**183.** `21:32` **You**

Well I mean


**184.** `21:32` **You**

Soohear is kinda married\.\. so a little difficult and she would be in like Chatham or wherever\.


**185.** `21:32` **You**

Think you are safe


**186.** `21:32` **You**

lol


**187.** `21:33` **You**

I could always hire a dude


**188.** `21:33` **Meredith Lamb (+14169386001)**

You were married\.\. I was basically …


**189.** `21:33` **Meredith Lamb (+14169386001)**

I mean


**190.** `21:33` **You**

We were on the way out together\.\. besides only one soul mate\.


**191.** `21:34` **You**

Why would I ever look after I found you


**192.** `21:34` **Meredith Lamb (+14169386001)**

I was kidding, not serious\.


**193.** `21:34` **You**

Good


**194.** `21:35` **Meredith Lamb (+14169386001)**

I worry a bit that you are going to get tired of my lack of ability to bleed emotion like you do though…\.


**195.** `21:36` **You**

It’s not that you don’t\.  It’s that we don’t see each other


**196.** `21:37` **You**

When we are together I have never been happier ever


**197.** `21:37` **You**

You perfect the way you are\.\. The more we are together The more I get to know you the more you open up the more I love you even the crazy stuff lol


**198.** `21:39` **You**

I promise I am never leaving\.\.


**199.** `21:39` **Meredith Lamb (+14169386001)**

Crazy stuff lol …


**200.** `21:39` **You**

Easy promise to make and keep


**201.** `21:39` **Meredith Lamb (+14169386001)**

Ok well I am not either


**202.** `21:39` **You**

Reaction: 😂 from Meredith Lamb
Fan girl crazy stuff


**203.** `21:39` **Meredith Lamb (+14169386001)**

Whatever omg


**204.** `21:40` **You**

Since you were a bit pounded go read my goodnight message


**205.** `21:42` **Meredith Lamb (+14169386001)**

Morgan wallen vs Kane brown LOL forgot about that


**206.** `21:43` **You**

No the good night message \.\. lol I didn’t even know if you actually read it at the time


**207.** `21:45` **You**

Kk I am on treadmill will try to text or you can call whatever works for you\.\. just starting up now


**208.** `21:45` **Meredith Lamb (+14169386001)**

Can’t call\. Everyone around\.


**209.** `21:46` **Meredith Lamb (+14169386001)**

I’m on the last episode of four seasons


**210.** `21:46` **You**

Ah ok do your thing


**211.** `21:46` **Meredith Lamb (+14169386001)**

>
I read all of your messages\. I just maybe don’t remember them all the time lol

*💬 Reply*

**212.** `21:47` **You**

Yeah I am
Overly verbose i know it lol


**213.** `21:51` **You**

I forgot


**214.** `21:52` **You**



**215.** `21:52` **Meredith Lamb (+14169386001)**

\[shakes head\]


**216.** `21:53` **You**

All you had to give was one pic


**217.** `21:53` **You**

This one too


**218.** `21:53` **You**



**219.** `21:54` **You**

All I wanted was hungover pic


**220.** `21:54` **Meredith Lamb (+14169386001)**

Noooooo hungover photos


**221.** `21:55` **You**

Kk 😝


**222.** `22:12` **You**

Alright I am going sauna and shower will ping you o ce when I am out\.\. no answer will say nite\.


**223.** `22:13` **Meredith Lamb (+14169386001)**

k I have moved onto handmaids tale


**224.** `22:13` **Meredith Lamb (+14169386001)**

lol


**225.** `22:13` **You**

Glad you are relaxing


**226.** `22:41` **You**

I mean I think we should eat a full season of handsmaids tale tomorrow


**227.** `22:41` **You**

Watch


**228.** `22:51` **Meredith Lamb (+14169386001)**

lol ok


**229.** `22:51` **Meredith Lamb (+14169386001)**

I’m totally falling asleep so going to bed xoxox love you and can’t wait to see you tomorrow


**230.** `22:54` **You**

On my way home going to get some stuff ready for tomorrow and go to bed too\.\. really looking forward to seeing you\.\. probably heading over
Right around 4 ish need
To get
Away\.


**231.** `22:54` **You**

Reaction: 😂 from Meredith Lamb
We can go out and grab anything you want when you get there I will even let you stay in car so you aren’t seen with me


**232.** `22:54` **You**

Reaction: ❤️ from Meredith Lamb
Love you very much and thanks
For
Finding a way to make this happen


**233.** `22:54` **You**

❤️❤️❤️❤️😝


**234.** `22:55` **You**

I mean the last one


**235.** `22:55` **You**

Really typo lol


**236.** `22:55` **You**

Nite


**237.** `23:02` **You**

For the morning curious\.\. preference scruffy vs clean shaven think on it\.\. 😊


