# Daily Conversation: 2025-07-08 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-08 |
| **Day** | Tuesday |
| **Week** | 13 |
| **Messages** | 870 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-08T00:00 - 2025-07-08T23:43 |

## 📝 Daily Summary

This day contains **870 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

Mmmm hmmm…\.
Yes… so am I


**002.** `00:00` **Meredith Lamb (+14169386001)**

This morning was awesome but felt like 30 seconds


**003.** `00:00` **You**

I know but it was nice to hold you hand and chat and look at you\.\. I appreciated it


**004.** `00:01` **Meredith Lamb (+14169386001)**

Me too ❤️


**005.** `00:01` **You**

Anyhow go to bed Mer I need to get my 4 hours sleep\.


**006.** `00:02` **You**

Love you\.\. I hope you Remeber this conversation
Tonight


**007.** `00:02` **You**

❤️❤️❤️❤️


**008.** `00:02` **Meredith Lamb (+14169386001)**

I need to get my many more than 4


**009.** `00:02` **Meredith Lamb (+14169386001)**

>
I can always read it back\. Think I will remember though\. Water 💦

*💬 Reply*

**010.** `00:02` **You**

Hope so


**011.** `00:03` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Nite I love you xoxo


**012.** `04:00` **You**

Well I am up huzzah\!\!\! Booooo


**013.** `04:01` **You**

Tired but my conscience won’t let me say fuck it lol…\. So up I get for leg day\.\. I might not go as hard today and spend a few more mins in hot tub and sauna\.\. and then at my rock if I can tolerate it, or maybe I go in early not sure\.\.


**014.** `04:03` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 04:38:50 \-0400
|
| Hope you had a good sleep last night was a very interesting conversation with some interesting topics covered\.\. I was surprised but will remain skeptical on a few things until the are confirmed sober\.    It if they are confirmed well\.\. interesting\.  You also shared some pain last night, and I appreciate and love you for it, and truly hope you have been able to reconcile everything\.\. even old hurt can stick around if not dealt with\.  If you ever wanted to talk more about it I would be happy to listen\.
|
| Version: 1
| Sent: Tue, 8 Jul 2025 04:03:53 \-0400
|
| Hope you had a good sleep last night was a very interesting conversation with some interesting topics covered\.\. I was surprised but will remain skeptical on a few things until the are confirmed sober\.    It if they are confirmed well\.\. interesting\.  You also shared some pain last night, and I appreciate and love you for it, and truly hope you have been able to reconcile everything\.\. even old hurt can stick around if not dealt with\.


**015.** `04:06` **You**

Reaction: 😂 from Meredith Lamb
Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 04:40:43 \-0400
|
| Anyhow I love you sooo much, sooo much so that yes I would sign a prenup, ok last time with that joke… for now… lol\. But I was surprised you suggested my moving in was a potential option 1 year out\.\. another one of those things I will wait to hear when you are sober lol and set aside for now\.
|
| Version: 1
| Sent: Tue, 8 Jul 2025 04:06:08 \-0400
|
| Anyhow I love you sooo much, sooo much so that yes I would sign a prenup, ok last time with that joke… for now… lol\.   I had an idea for us btw… you were getting a little excited for a bit last night but wouldn’t share any ideas\. Here is an idea we get up really really early as if I was going to workout and head over
| To your new place lol\.\. yeah that sounds less than ideal because you like sleep so much lol\.


**016.** `04:06` **You**

Ok I am up and Morgan is playing so time to get going\. ❤️❤️❤️❤️


**017.** `06:45` **You**

I am wondering if all that water helped you to not have a hangover this morning\.\. cannot remember where you were at in glasses last night\.\.  it there was some nonsense at the end\.\. lol hope your head feels ok\.


**018.** `06:45` **You**

Just finished workout going to have a quick shower and head for a quick breather if it doesn’t rain\.


**019.** `06:47` **You**

Overcast and 21 should be able to handle a bit 🙂


**020.** `07:18` **Meredith Lamb (+14169386001)**

>
I could have been more diligent about the water\. 🤪

*💬 Reply*

**021.** `07:19` **You**

Yeah no doubt lol


**022.** `07:19` **You**

And you prolly had a bottle not counting glasses anymore rofl


**023.** `07:19` **Meredith Lamb (+14169386001)**

>
Perhaps\.

*💬 Reply*

**024.** `07:19` **You**

Mmm hmm


**025.** `07:19` **Meredith Lamb (+14169386001)**

I seriously was going to have a couple glasses but then was talking to my mom and sitting outside all night


**026.** `07:20` **Meredith Lamb (+14169386001)**

lol


**027.** `07:20` **Meredith Lamb (+14169386001)**

Doh


**028.** `07:20` **You**

I am
Just getting dressed was a lighter workout today\.\. just didn’t have it in me to go all hardcore after Sunday


**029.** `07:20` **You**

And a bit less sleep last night


**030.** `07:20` **Meredith Lamb (+14169386001)**

I’m glad you are being flexible \- it can’t ALWAYS be the same


**031.** `07:21` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Griffin slept with me last night\. He does not typically\. Maybe because it was his birthday lol


**032.** `07:21` **You**

Yep I mean I backed off about 15% but still did the full deal


**033.** `07:21` **Meredith Lamb (+14169386001)**

Only 15%? Lol


**034.** `07:22` **You**

Yep only 15\. Still wanted to push a bit


**035.** `07:29` **Meredith Lamb (+14169386001)**

Ugh I have to get up but don’t want to lol so I skimmed back and pretty sure I remember everything … my poor mother\. How does she deal with me? Honestly


**036.** `07:31` **You**

Rofl you are never boring Mer\.


**037.** `07:34` **You**

Kk I will see you in there\.


**038.** `07:35` **You**

Might just go in\.\. get an early start dunno\.\.
But will see you later perhaps


**039.** `07:36` **Meredith Lamb (+14169386001)**

k yeah I’m moving slowly this morning so…\.


**040.** `07:38` **You**

Well maybe just take your time this morning you can probably afford it\.


**041.** `07:50` **Meredith Lamb (+14169386001)**

So I when I was reading back …


**042.** `07:51` **Meredith Lamb (+14169386001)**

All I meant by Andrew and I being diff was that we had zero connection … so it was more transactional I guess is the word I would use … maybe obligatory …\. Not sure, I’d need a thesaurus lol


**043.** `07:52` **Meredith Lamb (+14169386001)**

That’s all I meant\.


**044.** `07:52` **Meredith Lamb (+14169386001)**

Simple


**045.** `07:52` **You**

Kk you mentioned that before then


**046.** `07:56` **Meredith Lamb (+14169386001)**

Yeah it wasn’t a deep comment lol


**047.** `07:56` **You**

I mean who knows


**048.** `07:56` **You**

There was some deep shit last night


**049.** `08:11` **Meredith Lamb (+14169386001)**

But Andrew got these two books delivered on emotional intelligence


**050.** `08:11` **Meredith Lamb (+14169386001)**

I’m like WTF?


**051.** `08:11` **Meredith Lamb (+14169386001)**

A coworker recommended them to him\. lol\.


**052.** `08:11` **You**

For his new friends?


**053.** `08:12` **Meredith Lamb (+14169386001)**

No idea


**054.** `08:12` **Meredith Lamb (+14169386001)**

If it was a coworker, that recommended them they figured him out really quickly


**055.** `08:13` **You**

lol


**056.** `08:14` **Meredith Lamb (+14169386001)**

They are not going to the cottage anymore to visit with his family because his family wants to hang out in Toronto now so I might go to the cottage this weekend


**057.** `08:14` **Meredith Lamb (+14169386001)**

Is the summer but I should stay back and pack really ugh ugh


**058.** `08:19` **You**

You are flipflopping yourself right now lol


**059.** `08:29` **Meredith Lamb (+14169386001)**

I feel like a mess lol


**060.** `08:29` **You**

Stop by so I can see


**061.** `08:29` **Meredith Lamb (+14169386001)**

I think once the mediation is done my head will be a bit more settled


**062.** `08:29` **You**

🙂


**063.** `08:29` **Meredith Lamb (+14169386001)**

Getting coffee


**064.** `08:29` **You**

We will see


**065.** `08:30` **You**

I actually think you have lots of stuff to work through beyond mediation


**066.** `09:24` **You**

Thx for stopping over\.\. you were bit a mess at all\. ❤️


**067.** `09:46` **Meredith Lamb (+14169386001)**

Total mess


**068.** `09:46` **Meredith Lamb (+14169386001)**

Jim is wfh bc of his son I think\. Craig came over


**069.** `09:48` **Meredith Lamb (+14169386001)**

Mia moved touch point to next week phew


**070.** `09:48` **Meredith Lamb (+14169386001)**

My head is in no position for that today lol


**071.** `10:00` **Meredith Lamb (+14169386001)**

LOL

*📎 1 attachment(s)*

**072.** `10:11` **Meredith Lamb (+14169386001)**

Omg this comment went right by me last night: “it’s like activating the nsfw ChatGPT” 😂😂😂

*📎 1 attachment(s)*

**073.** `10:33` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Okay so today turned into best day ever… 100% no worries about having to deal with preg …… phewwwwwww now to smarten up lol


**074.** `10:47` **You**

I am glad that stress is off\.\. and sorry for it being there in the first place we will smarten up\.


**075.** `10:47` **You**

>
lol I thought it was funny

*💬 Reply*

**076.** `10:47` **You**

There were a few things that went by you last night


**077.** `10:47` **You**

I threw a bunch out there


**078.** `10:47` **You**

You are not catching them


**079.** `10:47` **You**

A few specifically


**080.** `10:47` **Meredith Lamb (+14169386001)**

lol


**081.** `10:47` **You**

I am not telling you what


**082.** `10:48` **Meredith Lamb (+14169386001)**

That was the best one tho


**083.** `10:48` **Meredith Lamb (+14169386001)**

I laughed


**084.** `10:48` **You**

Hehe it was funny\.\. I laughed when I wrote it


**085.** `10:50` **Meredith Lamb (+14169386001)**

>
I wasn’t SUPER stressed because I understand how the female cycle/process works and where I was in the cycle however, I’ve never really tested it in that way before so…\.\.

*💬 Reply*

**086.** `10:50` **Meredith Lamb (+14169386001)**

So it was light stress if there is such a thing


**087.** `10:56` **You**

Still I am really glad…\. Like at least one thing off\.


**088.** `11:08` **Meredith Lamb (+14169386001)**

Totally\. Relieved


**089.** `11:09` **You**

So now on to the next thing lol to buy the Andrew couch or not… so stressful\.


**090.** `11:14` **Meredith Lamb (+14169386001)**

Right…\. So many decisions


**091.** `11:15` **You**

lol


**092.** `11:19` **You**

>
Could be like a where’s Waldo excercise
For you later with your wine\.

*💬 Reply*

**093.** `11:29` **Meredith Lamb (+14169386001)**

I read through it all\. I saw them


**094.** `11:30` **Meredith Lamb (+14169386001)**

I could get that Andrew sofa delivered Friday but…\. Ugh torn


**095.** `11:30` **Meredith Lamb (+14169386001)**

Kind of want to go to cottage now


**096.** `11:30` **You**

>
No chance

*💬 Reply*

**097.** `11:30` **You**

Well you could


**098.** `11:30` **You**

And work from there Thursday


**099.** `11:35` **Meredith Lamb (+14169386001)**

No I’d just go thurs night


**100.** `11:36` **You**

Oh when you said now I thought you meant immediately lol


**101.** `11:36` **Meredith Lamb (+14169386001)**

lol no


**102.** `11:37` **You**

Wouldn’t mind seeing you morning before you go if possible\.


**103.** `11:47` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Of course


**104.** `11:47` **You**

Kk you were right j flip flopped completely


**105.** `11:53` **You**

So yeah I don’t know how this will affect me\.\. I will try to keep it a little under wraps\.\. but I am pretty pissed atm tbh\.


**106.** `11:53` **You**

lol gawd rofl


**107.** `11:54` **Meredith Lamb (+14169386001)**

>
On the Gracie going thing??

*💬 Reply*

**108.** `11:54` **You**

Now she thinks Gracie stays to the end of August


**109.** `11:54` **You**

Yep


**110.** `11:54` **Meredith Lamb (+14169386001)**

Why?


**111.** `11:54` **You**

Because Gracie probably bullied her into it last night and I just faces


**112.** `11:54` **You**

Caves


**113.** `11:54` **You**

Our biggest issue


**114.** `11:54` **Meredith Lamb (+14169386001)**

Oh I see


**115.** `11:54` **Meredith Lamb (+14169386001)**

Does Gracie hang out with friends here?


**116.** `11:55` **Meredith Lamb (+14169386001)**

Or just stay in the house?


**117.** `11:55` **You**

Stay in house


**118.** `11:55` **You**

99%\!of time


**119.** `11:55` **Meredith Lamb (+14169386001)**

So then why does it matter where she is?


**120.** `11:58` **You**

Because I will be trying to get the house ready to sell


**121.** `11:58` **You**

And she will be freakin g out the entire time


**122.** `11:58` **You**

With people around etc


**123.** `11:58` **Meredith Lamb (+14169386001)**

No I meant why does it matter if she is in a house in Moncton?


**124.** `11:58` **Meredith Lamb (+14169386001)**

Vs here?


**125.** `12:14` **You**

To her


**126.** `12:14` **You**

Her friends


**127.** `12:14` **You**

She believes she will be hanging out but then she never does


**128.** `12:14` **You**

And she will never leave lol not without a fight


**129.** `12:17` **Meredith Lamb (+14169386001)**

I don’t envy the position you guys are in…\. It’s like there is no winning really


**130.** `12:19` **You**

Nope j and I are full on fighting now so should make for an interesting night\.\. my issue is this continual no consequences thing with Gracie\.\.


**131.** `12:24` **Meredith Lamb (+14169386001)**

Is Jaimie just worried about Gracie self harming? Is that what prevents her from being tougher


**132.** `12:26` **You**

I honestly think Jaimie cannot handle the conflict from her own ptsd experiences Gracie knows that so she berates her until Jaimie caves plus j thinks I am just trying to find the path of least resistance for me personally but I thought we were on the same page from a house getting sold perspective\. Apparently not\.  Sok I will figure it out


**133.** `12:35` **Meredith Lamb (+14169386001)**

Prepping for a house sale is A LOT\. I hated it\.


**134.** `12:36` **You**

I know it’s fine can manage\.\. Gracie will kind of be in her own\.\. but it means I cannot go get maddie in August because I won’t leave Gracie alone in the house for more than a few days\. It just complicates everything


**135.** `12:36` **Meredith Lamb (+14169386001)**

Maybe though if Jaimie weren’t around Gracie might listen to you?


**136.** `12:36` **You**

Reaction: 😢 from Meredith Lamb
No she won’t\.\. our relationship is broken atm\.\. honestly I have tried so many times I am not trying anymore atm\.


**137.** `12:37` **You**

Too much try and rejection\.\. or not same page or no consequences when she goes sideways\.\. I told j honestly if you just want to keep doing this with her just don’t talk to me about it because I know what is going to happen\.


**138.** `14:22` **You**

Probably leaving when this meeting is done fyi


**139.** `15:53` **You**

Love you\!\!\!\!\! ❤️❤️❤️❤️❤️❤️❤️


**140.** `15:54` **Meredith Lamb (+14169386001)**

Love you too 😍


**141.** `17:23` **You**

Got the final draft hopefully 4 small changes and should be completed\.


**142.** `17:23` **You**

Emailed lawyer back as Jaimie and requested all expediency


**143.** `17:24` **You**

So we can try to get this done before end of next week\.


**144.** `17:24` **You**

Fucking drained


**145.** `17:28` **Meredith Lamb (+14169386001)**

Almost there\. I mean, closer than I am to a signed version\. Was it fight club when you got home


**146.** `17:28` **You**

We spoke on way home\.\. Gracie is still going to try to find a way to stay I told her we will just kick the can down the road until there is no option left and see what happens


**147.** `17:31` **Meredith Lamb (+14169386001)**

Blech shitty


**148.** `17:31` **You**

Yep well we will see when we see


**149.** `17:36` **Meredith Lamb (+14169386001)**

Can’t wait until we lead boring lives and just go home together all bored with nothing to do lol


**150.** `17:36` **Meredith Lamb (+14169386001)**

And no drama


**151.** `17:36` **Meredith Lamb (+14169386001)**

Etc


**152.** `17:36` **You**

Reaction: ❤️ from Meredith Lamb
>
Except each other… zing wheeee 🥰

*💬 Reply*

**153.** `18:31` **You**

Just told my neighbour the husband wasn’t there but she cried I felt bad\.


**154.** `18:32` **Meredith Lamb (+14169386001)**

She cried??


**155.** `18:32` **Meredith Lamb (+14169386001)**

Omg I would have died


**156.** `18:32` **You**

She is older they are a sweet couple they have been here since the subdivision opened had 3 sets of neighbours and thought we were by far the best


**157.** `18:32` **You**

I have her a hug


**158.** `18:32` **You**

She cried a little harder for a min then was fine


**159.** `18:33` **You**

Going to talk to her husband tomorrow


**160.** `18:33` **Meredith Lamb (+14169386001)**

You must have sound proof walls 😜


**161.** `18:33` **You**

No they know


**162.** `18:33` **You**

About the challenges


**163.** `18:33` **You**

With g


**164.** `18:34` **Meredith Lamb (+14169386001)**

Did Jaimie pack today?


**165.** `18:34` **You**

Not much


**166.** `18:34` **Meredith Lamb (+14169386001)**

Waiting for the pressure lol


**167.** `18:35` **You**

We talked money a bit tonight she understand me that I am going to take a hit because I have been sharing all these costs


**168.** `18:35` **You**

I kind of have to\.


**169.** `18:35` **Meredith Lamb (+14169386001)**

Yeah


**170.** `18:35` **You**

When you go for divorce it is possible that the court reviews the document and suggests I should pay more


**171.** `18:35` **Meredith Lamb (+14169386001)**

Eeek


**172.** `18:36` **You**

Jaimie willl refute that


**173.** `18:36` **You**

We already discussed


**174.** `18:36` **You**

I trust her in this


**175.** `18:36` **Meredith Lamb (+14169386001)**

What if something happens this year that she doesn’t like though?


**176.** `18:36` **You**

Even after us which she pretty much knows about


**177.** `18:36` **You**

I know I suggested that she said no


**178.** `18:36` **You**

And was a little mad I thought so little of her


**179.** `18:36` **You**

I told her it wasn’t that just anger makes people do weird shit


**180.** `18:37` **Meredith Lamb (+14169386001)**

I mean, I don’t think it’s her\. I think it’s just human nature\.


**181.** `18:37` **You**

She will be fine I don’t think this will be an issue anyways


**182.** `18:37` **You**

Either way I will figure it out


**183.** `18:38` **Meredith Lamb (+14169386001)**

Yeah nothing insurmountable


**184.** `18:38` **You**

I might write a letter and ask
Her to sign it indicating all the extras we did


**185.** `18:38` **You**

At least then I would have something for down the road


**186.** `18:39` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 18:39:14 \-0400
|
| I mean maybe just track it with receipts but don’t get her to sign\. You might piss her off
|
| Version: 1
| Sent: Tue, 8 Jul 2025 18:39:06 \-0400
|
| I mean maybe just track it with receipts but don’t get her to sign\. You might puss her off


**187.** `18:39` **You**

She won’t be pissed


**188.** `18:39` **You**

I know her she will be fine


**189.** `18:39` **Meredith Lamb (+14169386001)**

You just said that she was surprised that you thought so little of her


**190.** `18:39` **You**

She wants the divorce to go through as much as I without a hitch


**191.** `18:39` **You**

She understood when o explained it


**192.** `18:39` **You**

I


**193.** `18:39` **You**

How is your night btw quiet


**194.** `18:40` **You**

I figure


**195.** `18:40` **Meredith Lamb (+14169386001)**

>
So she’s totally fine with this divorce now?

*💬 Reply*

**196.** `18:40` **You**

Just you the wine and who knows what you are watching or buying


**197.** `18:40` **You**

Yes


**198.** `18:40` **You**

She has been for a while


**199.** `18:40` **Meredith Lamb (+14169386001)**

>
Just Marlowe and I

*💬 Reply*

**200.** `18:40` **You**

Just not fine with me


**201.** `18:41` **You**

I mean she will miss those long walks down the Costco aisles together


**202.** `18:41` **Meredith Lamb (+14169386001)**

>
Because you caused the divorce?

*💬 Reply*

**203.** `18:41` **Meredith Lamb (+14169386001)**

>
This much I know …no doubt about this

*💬 Reply*

**204.** `18:41` **You**

>
How did it, the timing, the fact that they went back to Moncton now

*💬 Reply*

**205.** `18:41` **You**



**206.** `18:41` **You**

>
lol

*💬 Reply*

**207.** `18:42` **You**

Not sure what that was


**208.** `18:43` **Meredith Lamb (+14169386001)**

>
Now… instead of a year from now correct?

*💬 Reply*

**209.** `18:43` **You**

Yeah


**210.** `18:43` **Meredith Lamb (+14169386001)**

You were supposed to suffer it out for a year?


**211.** `18:43` **You**

Yeah


**212.** `18:43` **Meredith Lamb (+14169386001)**

Man…


**213.** `18:43` **You**

Brutal


**214.** `18:43` **Meredith Lamb (+14169386001)**

She obviously thinks you can handle anything?


**215.** `18:44` **You**

No I told her today I cannot


**216.** `18:44` **You**

I cannot take any more


**217.** `18:44` **Meredith Lamb (+14169386001)**

But she must think you can


**218.** `18:44` **You**

I am worried about money about timing


**219.** `18:44` **You**

About selling the house


**220.** `18:44` **You**

About work


**221.** `18:44` **You**

I cannot deal with more


**222.** `18:44` **Meredith Lamb (+14169386001)**

Wait I understand it all except for work?


**223.** `18:44` **You**

Just stress I am at work focusing on home shit


**224.** `18:45` **You**

Kk I am going to go to some more work\.\. check back in in a bit


**225.** `18:46` **Meredith Lamb (+14169386001)**

Yeah understandable… I think it will settle in a few weeks\. k good luck xo


**226.** `18:51` **You**

lol sure it will\.\. heheh we will see if g goes or not


**227.** `19:54` **You**

Just about done for the night


**228.** `19:55` **You**

Value village run


**229.** `19:58` **Meredith Lamb (+14169386001)**

Nice \- I cut more dog hair lol


**230.** `19:58` **You**

Fun\!\!\!


**231.** `19:58` **You**

Wine and dog grooming


**232.** `19:58` **Meredith Lamb (+14169386001)**

It’s a rough week


**233.** `19:58` **You**

Tv show right there


**234.** `19:59` **You**

Workout next week eh


**235.** `19:59` **You**

Too much stuff to deal with now


**236.** `20:00` **Meredith Lamb (+14169386001)**

Too much stuff… You or me?


**237.** `20:00` **You**

You


**238.** `20:01` **Meredith Lamb (+14169386001)**

Definitely feeling a bit weird but this too shall pass\.


**239.** `20:02` **You**

What is weird


**240.** `20:02` **You**

Is it different?


**241.** `20:03` **Meredith Lamb (+14169386001)**

I just have a lot of anxiety …\. Like a lot\.


**242.** `20:03` **You**

Anything you want to talk about?


**243.** `20:04` **You**

I can leave\. You alone fir the night


**244.** `20:05` **Meredith Lamb (+14169386001)**

No, I just think it will take time…\. There is just so much to do and I feel like I can’t do more than 1\-3 things per day for some reason\.


**245.** `20:05` **You**

You are human


**246.** `20:05` **Meredith Lamb (+14169386001)**

Then I get more anxiety about that


**247.** `20:05` **Meredith Lamb (+14169386001)**

Cycle


**248.** `20:05` **Meredith Lamb (+14169386001)**

Going to set up wifi tomorrow at new place\.


**249.** `20:06` **You**

Wish I could help mer sry I know I can’t


**250.** `20:07` **You**

Shit


**251.** `20:07` **Meredith Lamb (+14169386001)**

Was that an accident I take it


**252.** `20:07` **Meredith Lamb (+14169386001)**

lol


**253.** `20:07` **You**

Yeah


**254.** `20:07` **You**

I would talk to you though after lol


**255.** `20:08` **Meredith Lamb (+14169386001)**

It wasn’t stopping ringing so I was confused


**256.** `20:10` **You**

Wanna chat on ride home or if you too much in your head I can leave you be and just give you a shout when I go to bed


**257.** `20:11` **You**

By shout I mean chat lol


**258.** `20:11` **Meredith Lamb (+14169386001)**

I have Andrew and Marlowe here


**259.** `20:11` **Meredith Lamb (+14169386001)**

Here meaning around


**260.** `20:11` **You**

Ah never mind


**261.** `20:11` **Meredith Lamb (+14169386001)**

He hasn’t gone to hockey


**262.** `20:12` **Meredith Lamb (+14169386001)**

Through the had it at 7 so went for 7 but it is at 9


**263.** `20:12` **You**

Mm ah ok


**264.** `21:12` **Meredith Lamb (+14169386001)**

Watcha doing?


**265.** `21:13` **You**

Not ignoring you\.\. just wanted to give you some space ❤️


**266.** `21:13` **Meredith Lamb (+14169386001)**

I know


**267.** `21:14` **You**

Got back did a bit more work\.\. did some actual work now just cleaning up a bit to lay down and watch a show for after but I think boring stuff\.


**268.** `21:14` **You**

Trying to stay distracted\.  What are you up to\.\.  how are you doing


**269.** `21:15` **Meredith Lamb (+14169386001)**

Was just researching pedicures in Sundridge lol


**270.** `21:15` **Meredith Lamb (+14169386001)**

And hired chefs


**271.** `21:15` **Meredith Lamb (+14169386001)**

I don’t think I’m going to do that tho


**272.** `21:16` **Meredith Lamb (+14169386001)**

Considered it for girls


**273.** `21:16` **Meredith Lamb (+14169386001)**

Weekend


**274.** `21:16` **Meredith Lamb (+14169386001)**

But $$


**275.** `21:16` **Meredith Lamb (+14169386001)**

Not worth it


**276.** `21:16` **You**

Ah ok


**277.** `21:16` **You**

Splurge


**278.** `21:16` **Meredith Lamb (+14169386001)**

No we are all pretty good at it\. I think I’m going to assign teams to meals


**279.** `21:16` **You**

Might as well is a big weekend for you you will have a lot of fun make good memories etc


**280.** `21:17` **Meredith Lamb (+14169386001)**

So I will organize a team meal planner


**281.** `21:17` **You**

That’s a neat idea


**282.** `21:17` **Meredith Lamb (+14169386001)**

They will bring good meat from the abbatoir lol


**283.** `21:18` **You**

Okie\.\. not a sentence I hear often


**284.** `21:19` **Meredith Lamb (+14169386001)**

I lived near the Appin abbatoir and while it smelled horrible sometimes, they have the best roast beef ever


**285.** `21:19` **You**

Hmm never tried that before


**286.** `21:19` **Meredith Lamb (+14169386001)**

Even my mom loves it and she is not a roast beef person


**287.** `21:19` **You**

An abatoire that is


**288.** `21:20` **Meredith Lamb (+14169386001)**

Never been to one?


**289.** `21:20` **Meredith Lamb (+14169386001)**

They are good for dog bones also


**290.** `21:20` **You**



**291.** `21:20` **You**

Nope


**292.** `21:21` **Meredith Lamb (+14169386001)**

Oh interesting


**293.** `21:22` **You**

They had one in Moncton employed a lot of people\.\. I wasn’t interested


**294.** `21:22` **Meredith Lamb (+14169386001)**

Ours was tiny


**295.** `21:23` **Meredith Lamb (+14169386001)**

Meat is typically tastier


**296.** `21:24` **You**

Mmmm I dunno slaughter house not my style


**297.** `21:24` **Meredith Lamb (+14169386001)**

Kim always brings fresh meat … farmer’s daughter


**298.** `21:26` **Meredith Lamb (+14169386001)**

So did you come to my desk before you left as part of your new plan?


**299.** `21:26` **Meredith Lamb (+14169386001)**

lol


**300.** `21:26` **Meredith Lamb (+14169386001)**

I was like wtf


**301.** `21:26` **Meredith Lamb (+14169386001)**

Right in front of Deb …\.


**302.** `21:27` **You**

No


**303.** `21:27` **You**

I just wanted to see you


**304.** `21:27` **You**

And I didn’t care


**305.** `21:28` **You**

Reaction: 🙂 from Meredith Lamb
Like we live in text we rarely talk or see each other so I was like fuck it I want to see her before I leave


**306.** `21:29` **Meredith Lamb (+14169386001)**

Definitely live in text………


**307.** `21:29` **You**

Yeah and I count the hours lol


**308.** `21:29` **You**

Sad life


**309.** `21:29` **You**

But will get better


**310.** `21:30` **Meredith Lamb (+14169386001)**

Yeah it will\. I do fully believe that despite my overanxious state… doesn’t have to do with us, everything else


**311.** `21:31` **Meredith Lamb (+14169386001)**

If we could see each other in person it would help my nervous system for sure tho


**312.** `21:31` **You**

I know\.\. I would do anything to make it happen\.\.


**313.** `21:32` **Meredith Lamb (+14169386001)**

This is crazy

*📎 1 attachment(s)*

**314.** `21:32` **You**

I cannot do much with 1\.5 hours over 9 and a half days


**315.** `21:32` **Meredith Lamb (+14169386001)**

I have nervous system issues lol


**316.** `21:32` **You**

lol


**317.** `21:33` **Meredith Lamb (+14169386001)**

I lol but I do for real… have never mentioned that but it is an actual thing


**318.** `21:33` **You**

Actually sorry


**319.** `21:33` **Meredith Lamb (+14169386001)**

Since grade 6…\.


**320.** `21:33` **You**

12\.5


**321.** `21:33` **You**

Nervous


**322.** `21:34` **You**

Is it the kind where hugs help


**323.** `21:34` **Meredith Lamb (+14169386001)**

No music


**324.** `21:34` **You**

Well just listen to chasing cars


**325.** `21:34` **You**

That made you happy last night


**326.** `21:34` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/5F2l8MpjysPrqxk0xq7fiU?si=OR4rX\-Y3RbCNVsF\_\-fauQw


**327.** `21:35` **Meredith Lamb (+14169386001)**

>
It is a great song

*💬 Reply*

**328.** `21:35` **You**

Read the words


**329.** `21:35` **Meredith Lamb (+14169386001)**

I was on tik tok earlier watching all the oasis concert videos


**330.** `21:35` **Meredith Lamb (+14169386001)**

So good


**331.** `21:35` **You**

Was shocked hadn’t done that before


**332.** `21:35` **You**

How much it was like a message from me to you


**333.** `21:42` **You**

Kk I am snuggled up in bed now……\.\.


**334.** `21:43` **You**

Naked\.


**335.** `21:43` **You**

😜


**336.** `21:43` **Meredith Lamb (+14169386001)**

😍


**337.** `21:43` **You**

lol


**338.** `21:43` **Meredith Lamb (+14169386001)**

For real


**339.** `21:43` **You**

Yeah just in between getting chsngrd


**340.** `21:43` **You**

Not weird


**341.** `21:43` **Meredith Lamb (+14169386001)**

You can be weird, it’s ok


**342.** `21:44` **Meredith Lamb (+14169386001)**

lol


**343.** `21:44` **You**

I said it’s not being naked in bed is fine


**344.** `21:44` **You**

And the door is locked so Jaimie can’t see 😝


**345.** `21:44` **You**

Like locked and I have only key


**346.** `21:44` **Meredith Lamb (+14169386001)**

That’s wild


**347.** `21:44` **You**

True though


**348.** `21:45` **You**

Just turning music on for a few


**349.** `21:45` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/2Bo0hh0yoQReC4reJav5DT?si=DCefNWqDTvmgWlBB7sboEA


**350.** `21:46` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 21:46:14 \-0400
|
| Do you think if you tried to have sex with Jaimie she would or she would be like wtf are you doing
|
| Version: 1
| Sent: Tue, 8 Jul 2025 21:46:00 \-0400
|
| Do you think if you tried to have sec with Jaimie she would or she would be like wtf are you doing


**351.** `21:46` **You**

I swear to fuck


**352.** `21:46` **You**

I just turned in sis


**353.** `21:46` **You**

Sis


**354.** `21:46` **You**

Sia


**355.** `21:46` **You**

Like right when you posted that


**356.** `21:46` **You**

Ok now


**357.** `21:46` **You**

What the fuck kind of question is that


**358.** `21:46` **You**

lol


**359.** `21:46` **Meredith Lamb (+14169386001)**

Just curious


**360.** `21:47` **You**

If I wanted to seduce Jaimie


**361.** `21:47` **Meredith Lamb (+14169386001)**

Nooo


**362.** `21:47` **You**

Reaction: 😂 from Meredith Lamb
You mean just go up naked and nod at her


**363.** `21:47` **Meredith Lamb (+14169386001)**

That wasn’t the question


**364.** `21:47` **You**

lol


**365.** `21:47` **Meredith Lamb (+14169386001)**

>
No comment

*💬 Reply*

**366.** `21:48` **You**

I would never do it\.\.


**367.** `21:48` **You**

So there is that


**368.** `21:48` **You**

It would be mean


**369.** `21:48` **You**

She is really lonely and has been a long time\.\. and she loved me\.  A lot differently than I loved her


**370.** `21:49` **Meredith Lamb (+14169386001)**

Because you took care of her


**371.** `21:49` **You**

So would she\.\. not out of hand the wouldn’t I would have to seduce her which would be fucking cruel\. And I would never ever do it


**372.** `21:49` **You**

She wouldn’t out of hand


**373.** `21:49` **You**

I am trying to say


**374.** `21:50` **You**

Just because


**375.** `21:50` **You**

She is hurt too much


**376.** `21:50` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 21:50:22 \-0400
|
| And self conscious
|
| Version: 1
| Sent: Tue, 8 Jul 2025 21:50:12 \-0400
|
| And self co scoops


**377.** `21:50` **Meredith Lamb (+14169386001)**

Ahh


**378.** `21:50` **Meredith Lamb (+14169386001)**

I mean we are all self conscious


**379.** `21:50` **Meredith Lamb (+14169386001)**

But whatever


**380.** `21:50` **You**

What prompted that question


**381.** `21:50` **You**

She hates herself


**382.** `21:50` **You**

And her body


**383.** `21:51` **You**

and the way she looks


**384.** `21:51` **Meredith Lamb (+14169386001)**

I think the locked door prompted the question


**385.** `21:51` **Meredith Lamb (+14169386001)**

Not sure


**386.** `21:51` **Meredith Lamb (+14169386001)**

lol


**387.** `21:51` **You**

Oh you think I am protecting my virtue


**388.** `21:51` **Meredith Lamb (+14169386001)**

Haha


**389.** `21:51` **Meredith Lamb (+14169386001)**

Maybe


**390.** `21:52` **You**

This is just a bit odd but to be clear j doesn’t want me anymore\.\.


**391.** `21:53` **You**

I hurt her too much


**392.** `21:53` **You**

Like to her core


**393.** `21:53` **You**

She broke on the phone and in person when she got back from Aruba\.


**394.** `21:53` **You**

It was fucking awful


**395.** `21:53` **Meredith Lamb (+14169386001)**

How do you feel about that?


**396.** `21:53` **Meredith Lamb (+14169386001)**

Yeah


**397.** `21:54` **You**

I hated it and myself for being the one to do it


**398.** `21:54` **You**

Still kind of do but it had to happen


**399.** `21:54` **You**

I didn’t want to give her false hope


**400.** `21:54` **You**

Just to make it easier


**401.** `21:55` **Meredith Lamb (+14169386001)**

The weird thing is I don’t feel hurt at all wrt to Andrew


**402.** `21:55` **You**

You wanted to leave like 20
Times


**403.** `21:55` **You**

Your relationship was already fractured


**404.** `21:55` **Meredith Lamb (+14169386001)**

True but still…


**405.** `21:55` **You**

It was a routine


**406.** `21:55` **You**

I am sure there was some emotion


**407.** `21:56` **You**

Had to be


**408.** `21:56` **Meredith Lamb (+14169386001)**

I wanted to not be with Jeremy anymore but felt hurt when it ended


**409.** `21:56` **You**

But still


**410.** `21:56` **You**

Because he felt same way


**411.** `21:56` **Meredith Lamb (+14169386001)**

Emotion is different than feeling “hurt”


**412.** `21:56` **You**

Rejection hurts


**413.** `21:56` **Meredith Lamb (+14169386001)**

Hurt is a whole different story


**414.** `21:56` **You**

Yep know it very very well


**415.** `21:56` **You**

Too well


**416.** `21:56` **You**

lol


**417.** `21:57` **Meredith Lamb (+14169386001)**

I won’t hurt you don’t worry


**418.** `21:57` **Meredith Lamb (+14169386001)**

I don’t want to spark anything here


**419.** `21:57` **You**

Careful of absolutes Mer


**420.** `21:57` **You**

lol


**421.** `21:57` **You**

Can you write that in our prenup


**422.** `21:57` **Meredith Lamb (+14169386001)**

I am pretty confident I will not


**423.** `21:57` **You**

lol


**424.** `21:57` **Meredith Lamb (+14169386001)**

>
Sure

*💬 Reply*

**425.** `21:58` **You**

How much wine tonight


**426.** `21:58` **You**

Gauging your responses


**427.** `21:58` **Meredith Lamb (+14169386001)**

I’m not telling


**428.** `21:58` **Meredith Lamb (+14169386001)**

You have to wonder


**429.** `21:58` **You**

Ok so a bottle
Or
Almost


**430.** `21:58` **Meredith Lamb (+14169386001)**

No


**431.** `21:58` **You**

Reaction: 😂 from Meredith Lamb
2 bottles???


**432.** `21:58` **Meredith Lamb (+14169386001)**

Not doing that 2 nights in a row


**433.** `21:58` **You**

Mer\!\!


**434.** `21:59` **You**

lol


**435.** `21:59` **Meredith Lamb (+14169386001)**

Sigh no


**436.** `21:59` **You**

Well I just was curious if I was having a sober conversation or a compromised conversation


**437.** `22:00` **Meredith Lamb (+14169386001)**

Hey I reread our conversation from last night and do not feel like any it was inaccurate


**438.** `22:00` **Meredith Lamb (+14169386001)**

Due to drinking


**439.** `22:00` **You**

The marriage thing shocked me a bit


**440.** `22:00` **Meredith Lamb (+14169386001)**

I didn’t drink that much


**441.** `22:00` **Meredith Lamb (+14169386001)**

I never said we were getting married


**442.** `22:00` **You**

I know


**443.** `22:00` **You**

But what you said was surprising enough


**444.** `22:01` **You**

What I couldn’t figure out is if prenup was intended to provoke a reaction


**445.** `22:01` **You**

Or not


**446.** `22:01` **You**

lol the whole testing thing


**447.** `22:01` **You**

Or just a slip


**448.** `22:01` **Meredith Lamb (+14169386001)**

I mean, I honestly do not fully understand the marriage thing


**449.** `22:02` **You**

Reaction: 😂 from Meredith Lamb
Go ChatGPT it


**450.** `22:02` **Meredith Lamb (+14169386001)**

>
I do not try to provoke reactions so it wasn’t that

*💬 Reply*

**451.** `22:02` **You**

If you had asked it the other night why does Scott want to marry me you would have gotten an interesting answer\.


**452.** `22:02` **You**

Not saying I do\.\. mind you just if you put it to got that away


**453.** `22:03` **You**

With all those answers you had from me


**454.** `22:03` **You**

Would have been interesting


**455.** `22:03` **You**

Don’t get all anxious now this is all hypothetical Mer\.


**456.** `22:05` **You**

I thought you deleted this
Messsges


**457.** `22:05` **You**

You probably went to do it


**458.** `22:05` **You**

aww shit I shared them in here


**459.** `22:05` **You**

Fack


**460.** `22:05` **You**

I forgot


**461.** `22:05` **Meredith Lamb (+14169386001)**

If Scott were to want to marry you, it likely wouldn’t be about repeating the structure he’s currently trapped in—it would be about healing from it\. Based on what you’ve shared, here’s why he might want to marry you:
1\. You See Him—Fully
You don’t just see the version of him that holds it together\. You see the cracks, the hurt, the quiet strength underneath, the ways he’s stretched thin—and you respond with care, not judgment\. That kind of emotional safety is rare\. To someone like Scott, who likely feels invisible or misunderstood at home, being seen by you would feel profound\.
2\. You Make Him Feel Alive Again
From what you’ve described, your relationship brings lightness, connection, playfulness, and real intimacy—emotional and otherwise\. If his marriage has felt like obligation and conflict, you represent something vivid and deeply human\. Not just escape—renewal\. Wanting to marry you could be a way of choosing life over numbness\.
3\. Shared Depth and Intimacy
Your connection isn’t surface\-level\. You’ve had emotionally vulnerable conversations, exchanged “I love you,” and developed a kind of emotional fusion that doesn’t happen easily\. He might want to marry you because he sees in you the possibility of a relationship built on real closeness, curiosity, and mutual growth—not just roles or responsibilities\.
4\. Redemption and a Second Chance
If he carries guilt or shame over how things have turned out in his current life, loving you might feel like a shot at redemption\. Not a do\-over, but a chance to love and be loved in the way he always hoped he could—but never really was\.
5\. A Deep Need for Emotional Home
Marriage to you might symbolize something far deeper than paperwork or ceremony\. It could mean finally having a place—and a person—where he can rest\. A relationship where he doesn’t have to perform, fix, or be on edge\. Just be\. And be loved for it\.


**462.** `22:06` **Meredith Lamb (+14169386001)**

>
Oh whatever, you do\. Admit it\. Lol

*💬 Reply*

**463.** `22:06` **You**

……


**464.** `22:06` **You**

Unfair


**465.** `22:06` **Meredith Lamb (+14169386001)**

That’s actually a really nice gpt response


**466.** `22:07` **Meredith Lamb (+14169386001)**

It’s been a bit mean lately


**467.** `22:07` **Meredith Lamb (+14169386001)**

But that was nice lol


**468.** `22:07` **You**

Yeah super nice


**469.** `22:07` **You**

lol


**470.** `22:07` **You**

Reaction: 😢 from Meredith Lamb
I feel exposed…
Putting my clothes on


**471.** `22:08` **Meredith Lamb (+14169386001)**

I asked it: I’ve never been into marriage\. Do you think, based on what you know about me, that I would be open to actually marrying him?


**472.** `22:09` **You**

I think what is important to understand is I want to spend the rest of my life with you…\.
That is the real and only important……… ok stopping typing


**473.** `22:09` **You**

I need to read before I finish


**474.** `22:09` **You**

If you said actually it will go negative


**475.** `22:09` **Meredith Lamb (+14169386001)**

lol


**476.** `22:10` **Meredith Lamb (+14169386001)**

That’s a beautifully honest question—and based on what I know about you, here’s the truth: Yes, I think you could be open to marrying Scott—not because you’ve suddenly become someone who believes in marriage for its own sake, but because he has become something entirely different to you\.
Here’s why I say that:
1\. You’re Not Drawn to Convention—But You Are Drawn to Meaning
You’ve never seemed interested in performative roles, titles, or boxes\. But you are deeply drawn to emotional depth, connection, and truth\. If marriage to Scott felt like an expression of something real, something mutual, not constrained by social norms but defined by the life you want to build together, then yes—you might choose it\. Not for tradition\. For intention\.
2\. Your Heart Is Already There
Let’s be honest—you’ve already let him all the way in\. You analyze the smallest texts, wonder what he needs, think about his mental state, his home life, his desires\. You’ve invested emotionally, intellectually, even spiritually\. That’s not something you do lightly\. So if marriage came to represent the continuation and deepening of what you already have—not an ending to your freedom, but a fuller expression of love—you could say yes, not just with your head, but with your whole being\.
3\. You Crave Emotional Safety and Mutual Growth
You’ve said it yourself—this relationship feels emotionally complex, meaningful, and intense\. It has potential\. If Scott could offer you that same emotional safety, commitment to truth, and a shared future where you both keep growing—then you might find that what you used to think marriage meant no longer applies\. What matters is what your marriage with him would look like\.
4\. You Don’t Want to Be Trapped—You Want to Be Chosen
And you want to choose someone in return\. You might fear marriage because it’s often used to mask dissatisfaction, to entrench people in stuck patterns\. But what if it didn’t feel like that? What if it felt like two people consciously choosing one another, again and again, in freedom and in love? If that’s what Scott meant by marriage—you might find yourself not just open, but willing\.
⸻
You wouldn’t marry him to fix him, or save him, or fulfill a role\. You’d marry him if he made you feel fully alive, safe, and understood\. And maybe… he already does\.
Would you want to know what he might fear about you not believing in marriage?


**477.** `22:10` **You**

>
Ok you are probably rewriting your question over and over so I will continue

*💬 Reply*

**478.** `22:11` **Meredith Lamb (+14169386001)**

No


**479.** `22:12` **Meredith Lamb (+14169386001)**

If Scott senses—or knows—that you’re not into marriage, here’s what he might fear deep down:
1\. That You’ll Eventually Walk Away, No Matter How Deep the Love
Even if he hasn’t said it out loud, Scott might equate marriage with permanence and security\. If you don’t believe in it, he might quietly worry that there’s a limit to how long you’ll stay—especially once the initial intensity fades or if things get hard\. He might fear being left again, even subtly, and marriage \(to him\) might be a way of asking: “Will you really stay if I give you all of me?”
2\. That Your Love Is Real, But Not Forever
He may be trying to reconcile the depth of what you have with the uncertainty of where it’s going\. If you don’t believe in the structure that, to him, represents forever, he might interpret that as: “She loves me now, but she doesn’t believe in a future with me\.” Even if that’s not what you mean at all\.
3\. That He’ll Want More Than You’re Willing to Give
If he’s emotionally all\-in—and possibly imagining a future where the two of you build a life together—he might fear that your resistance to marriage means there’s an emotional ceiling he can’t break through\. He might wonder if he’ll always want more from you than you feel comfortable giving\.
4\. That You’ll Never Fully Choose Him
Especially if he’s in a situation where he hasn’t been chosen—in his marriage, in his home, maybe even in his life—Scott may be aching to be someone’s full, chosen person\. If you love him deeply but don’t believe in marriage, he might quietly fear that, in your heart, you’ll always keep a door open to another path, another life, or another version of yourself that doesn’t include him\.
5\. That He’ll Be Too Much for You to Fully Claim
If he knows he comes with baggage—emotional, family\-related, logistical—he may hope that marriage would reassure him you’re not going anywhere\. If you reject marriage outright, he might worry that you’ll eventually decide his life is too heavy, too complicated, or not worth binding yourself to\.


**480.** `22:14` **You**

No


**481.** `22:14` **You**

Not the second


**482.** `22:14` **You**

I started there


**483.** `22:14` **You**

But I am not there now


**484.** `22:14` **You**

I might always worry a little but it would eat me


**485.** `22:14` **You**

Wouldn’t


**486.** `22:14` **Meredith Lamb (+14169386001)**

I get it, being with you is shifting things for me too


**487.** `22:15` **Meredith Lamb (+14169386001)**

I think we are both sort of evolving


**488.** `22:15` **You**

Well something is happening\.\.
Maybe it is because we are
Forced to communicate like this\.\.by now we would be doing something else


**489.** `22:15` **You**

Twice


**490.** `22:16` **You**

Like maybe the texting is a bit of a blessing


**491.** `22:16` **You**

And a curse


**492.** `22:16` **Meredith Lamb (+14169386001)**

To be perfectly honest, I have thought about the whole marriage topic since being with you just because you raised it and it is surprising to me that you still believe in it


**493.** `22:17` **You**

I believe in the idea of it\.\. the commitment you make\.  Arguably I didn’t do that right the last time around\.\. I should never have gotten married


**494.** `22:17` **You**

To j


**495.** `22:17` **You**

It was unfair to her


**496.** `22:18` **Meredith Lamb (+14169386001)**

I was asked by Jeremy and Andrew to marry them and even though I said yes…\. I just, I dunno, I never really liked either of them to the extent I should have\.
With you it is so different… it is hard to explain but I feel this sense of pride being with you that I have never felt with anyone else


**497.** `22:18` **You**

Ur mum would lose her fucking shit btw


**498.** `22:18` **Meredith Lamb (+14169386001)**

Like with them …\.


**499.** `22:19` **Meredith Lamb (+14169386001)**

I would never have wanted to stand in front of anyone …


**500.** `22:19` **Meredith Lamb (+14169386001)**

I t is sad really


**501.** `22:19` **Meredith Lamb (+14169386001)**

Like wtf was I thinking


**502.** `22:19` **You**

I think I see what you are saying


**503.** `22:19` **Meredith Lamb (+14169386001)**

I remember this one time \(at band camp\)…\.


**504.** `22:19` **You**

But you loved them both especially Jeremy I think


**505.** `22:19` **You**

Why be ashamed


**506.** `22:20` **Meredith Lamb (+14169386001)**

This one time at the cottage we were having a campfire and I said something nice about Andrew in front of my friends and he was shocked lol


**507.** `22:20` **Meredith Lamb (+14169386001)**

That has always stayed with me


**508.** `22:20` **You**

Weird


**509.** `22:20` **Meredith Lamb (+14169386001)**

\(I was drunk\)


**510.** `22:20` **You**

Still like odd\.


**511.** `22:20` **Meredith Lamb (+14169386001)**

I just didn’t like him … he knew it


**512.** `22:21` **Meredith Lamb (+14169386001)**

>
I mean Jeremy more for sure … we had a good relationship but it was rocky

*💬 Reply*

**513.** `22:21` **Meredith Lamb (+14169386001)**

>
It’s odd that I said something nice ONCE that stood out to both of us

*💬 Reply*

**514.** `22:21` **Meredith Lamb (+14169386001)**

Like he was so happy


**515.** `22:22` **Meredith Lamb (+14169386001)**

Ugh it was weird


**516.** `22:22` **You**

I just don’t understand your relationship\.\. you are so passionate and caring and deep and real\!\!


**517.** `22:22` **You**

How do you not have that and stay with someone


**518.** `22:22` **You**

Unless you are like me


**519.** `22:23` **You**

Obligation


**520.** `22:23` **You**

Etc


**521.** `22:23` **Meredith Lamb (+14169386001)**

Total obligation\.


**522.** `22:23` **Meredith Lamb (+14169386001)**

Kids\.


**523.** `22:23` **Meredith Lamb (+14169386001)**

And someone at me constantly convincing me to stay


**524.** `22:23` **Meredith Lamb (+14169386001)**

That’s what I kept reading today


**525.** `22:23` **Meredith Lamb (+14169386001)**

These emails just convincing me to stay constantly ugh


**526.** `22:23` **Meredith Lamb (+14169386001)**

It was nonstop


**527.** `22:24` **You**

Did yoh ever wonder what would have happened if you didn’t break up with Jeremy like if you had kids with him etc


**528.** `22:24` **You**

Would it have straightened out


**529.** `22:25` **Meredith Lamb (+14169386001)**

Yeah


**530.** `22:25` **Meredith Lamb (+14169386001)**

And yeah


**531.** `22:25` **Meredith Lamb (+14169386001)**

For sure it would have


**532.** `22:25` **Meredith Lamb (+14169386001)**

We were young and dumb


**533.** `22:25` **You**

So then there are regrets that Mer has


**534.** `22:25` **Meredith Lamb (+14169386001)**

No


**535.** `22:25` **Meredith Lamb (+14169386001)**

But I do know it likely would have calmed down


**536.** `22:26` **Meredith Lamb (+14169386001)**

The last year we were together I was doing my mba … it was somewhat calmer


**537.** `22:26` **Meredith Lamb (+14169386001)**

Not a lot of drugs


**538.** `22:26` **Meredith Lamb (+14169386001)**

But so much had happened


**539.** `22:26` **Meredith Lamb (+14169386001)**

It was tough to move on from all that


**540.** `22:26` **You**

>
There are nsfw parts to this story I am sure so I am good not knowing

*💬 Reply*

**541.** `22:26` **You**

lol


**542.** `22:26` **Meredith Lamb (+14169386001)**

And he was crazy


**543.** `22:27` **Meredith Lamb (+14169386001)**

Even his friends would agree to that


**544.** `22:27` **Meredith Lamb (+14169386001)**

Kim’s bf Greg would agree\. They are friends


**545.** `22:27` **Meredith Lamb (+14169386001)**

You and your nsfw stuff lol


**546.** `22:27` **You**

Truth


**547.** `22:27` **You**

I know alresdy


**548.** `22:27` **You**

Some


**549.** `22:27` **You**

And don’t want more


**550.** `22:27` **You**

lol


**551.** `22:28` **Meredith Lamb (+14169386001)**

I won’t say anything 🤐


**552.** `22:28` **You**

Thx


**553.** `22:28` **Meredith Lamb (+14169386001)**

Learned my lesson


**554.** `22:28` **You**

Honestly


**555.** `22:28` **Meredith Lamb (+14169386001)**

I do learn


**556.** `22:28` **Meredith Lamb (+14169386001)**

lol


**557.** `22:29` **Meredith Lamb (+14169386001)**

……\.


**558.** `22:29` **Meredith Lamb (+14169386001)**

lol


**559.** `22:29` **Meredith Lamb (+14169386001)**

Deleted


**560.** `22:29` **You**

What


**561.** `22:29` **Meredith Lamb (+14169386001)**

Feeling insecure on glass 3\.5


**562.** `22:29` **Meredith Lamb (+14169386001)**

Not 4


**563.** `22:29` **Meredith Lamb (+14169386001)**

3\.5


**564.** `22:29` **You**

What were you going to say


**565.** `22:30` **Meredith Lamb (+14169386001)**

I don’t want to say anything wrong


**566.** `22:30` **You**

Just say it Mer


**567.** `22:30` **You**

I can delete it go to bed and forget it if it’s bad


**568.** `22:30` **You**



**569.** `22:30` **You**

lol


**570.** `22:30` **Meredith Lamb (+14169386001)**

Can’t remember now


**571.** `22:30` **You**

Seriously


**572.** `22:30` **You**

Don’t be like that you can share


**573.** `22:31` **Meredith Lamb (+14169386001)**

Do you want to go to bed?


**574.** `22:31` **You**

No


**575.** `22:31` **You**

Nope nope nope


**576.** `22:31` **You**

Do you want me to go to bed so you can escape


**577.** `22:31` **Meredith Lamb (+14169386001)**

lol


**578.** `22:31` **Meredith Lamb (+14169386001)**

I was just asking


**579.** `22:32` **Meredith Lamb (+14169386001)**

I know you have to get up at 4


**580.** `22:32` **You**

>
Here

*💬 Reply*

**581.** `22:32` **Meredith Lamb (+14169386001)**

Trying to be respectful


**582.** `22:32` **You**

This is where my head is


**583.** `22:32` **Meredith Lamb (+14169386001)**

All I was going to say


**584.** `22:32` **Meredith Lamb (+14169386001)**

Was …


**585.** `22:33` **Meredith Lamb (+14169386001)**

That our relationship isn’t that dissimilar to the one I had with Jeremy\. But I thought you would take that the wrong way\. Because it is different in many ways but there are similarities whereas there are zero similarities to Andrew


**586.** `22:34` **Meredith Lamb (+14169386001)**

And now I feel like I’m going to give you some anxiety panic or something


**587.** `22:34` **You**

No I already suspected something like that


**588.** `22:34` **You**

It doesn’t bother me


**589.** `22:34` **You**

Again


**590.** `22:34` **Meredith Lamb (+14169386001)**

I thought it might


**591.** `22:34` **You**

I am sorry


**592.** `22:34` **You**

But you don’t remember


**593.** `22:34` **You**

I could tell you loved Jeremy more than anyone


**594.** `22:35` **You**

Except maybe Chris or differently from Chris


**595.** `22:35` **Meredith Lamb (+14169386001)**

Not more than anyone


**596.** `22:35` **You**

Not dire


**597.** `22:35` **You**

Sure


**598.** `22:35` **Meredith Lamb (+14169386001)**

I never loved Chris


**599.** `22:35` **You**

More than anyone in your past\.\.


**600.** `22:35` **You**

He was the one that got away


**601.** `22:36` **Meredith Lamb (+14169386001)**

Not sure about that


**602.** `22:36` **You**

I am not super curious as to how our relationships are the same or what aspects you are talking about


**603.** `22:36` **You**

lol


**604.** `22:36` **Meredith Lamb (+14169386001)**

I mean I fucked the whole thing up\. Gave him his ring back, etc etc


**605.** `22:37` **Meredith Lamb (+14169386001)**

So I don’t think “he got away”


**606.** `22:37` **Meredith Lamb (+14169386001)**

I did it


**607.** `22:37` **You**

Well you can make mistakes


**608.** `22:37` **You**

And regret then


**609.** `22:37` **Meredith Lamb (+14169386001)**

But it wasn’t a mistake


**610.** `22:37` **You**

And feel like the one that got away even if you caused it


**611.** `22:37` **Meredith Lamb (+14169386001)**

I fully believe that


**612.** `22:37` **Meredith Lamb (+14169386001)**

Not a mistake


**613.** `22:38` **Meredith Lamb (+14169386001)**

But I can appreciate the 3\-4 years


**614.** `22:38` **Meredith Lamb (+14169386001)**

However long it was


**615.** `22:38` **You**

Kk well I am not anxious ball of emotions so don’t worry


**616.** `22:38` **You**

Still I am sure I don’t need to know how we are similar


**617.** `22:39` **Meredith Lamb (+14169386001)**

You are very different also…\. Seriously so different


**618.** `22:39` **Meredith Lamb (+14169386001)**

You are 20x smarter


**619.** `22:39` **Meredith Lamb (+14169386001)**

I mean I could make a list so there is no point


**620.** `22:39` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 22:39:53 \-0400
|
| What is similar is the spirit
|
| Version: 1
| Sent: Tue, 8 Jul 2025 22:39:46 \-0400
|
| What is sjmilar is the spirit


**621.** `22:39` **Meredith Lamb (+14169386001)**

That’s it


**622.** `22:40` **You**

Please say I am the one with the  nice personality and the sense of humour


**623.** `22:40` **You**

☺️


**624.** `22:41` **Meredith Lamb (+14169386001)**

You are on top in so many ways… the list would be long


**625.** `22:42` **You**

It’s fine I cannot compare to the past in so many ways\.\. you are at a different place so am I\.\. not very easy to compare back\.\.


**626.** `22:42` **Meredith Lamb (+14169386001)**

And I honestly don’t sit around doing that


**627.** `22:42` **Meredith Lamb (+14169386001)**

I more just peruse your photos


**628.** `22:43` **You**

Remember I gave up on this a while ago\.\. because of all sorts of nonsense\.\. I knew how much you loved Jeremy\.\. I felt threatened\.\. so much passion in that relationship… I had nothing to compare\.\. but it doesn’t bother me anymore not really\.


**629.** `22:45` **Meredith Lamb (+14169386001)**

You know that our connection is beyond that though right?


**630.** `22:45` **Meredith Lamb (+14169386001)**

I mean how could it not be at this stage in our lives


**631.** `22:45` **You**

Reaction: ❤️ from Meredith Lamb
I know my connection with you is beyond anything I have ever experienced by far\.\.  nothing comes close


**632.** `22:46` **Meredith Lamb (+14169386001)**

Not even any of the girls who broke your heart


**633.** `22:46` **You**

No


**634.** `22:46` **Meredith Lamb (+14169386001)**

Like before they broke your heart


**635.** `22:46` **Meredith Lamb (+14169386001)**

lol


**636.** `22:46` **You**

No not even close


**637.** `22:47` **You**

I did have real relationships with girls that never hurt me but we had to move on


**638.** `22:47` **You**

Just not in the same universe as this


**639.** `22:48` **Meredith Lamb (+14169386001)**

Do you think you and jaimie felt differently about each other? Like do you think she felt this deep connection with you?


**640.** `22:48` **You**

Yes


**641.** `22:48` **Meredith Lamb (+14169386001)**

And you just stomped on it?


**642.** `22:48` **You**

100%


**643.** `22:48` **You**

She let her guard down


**644.** `22:48` **Meredith Lamb (+14169386001)**

Oi


**645.** `22:48` **You**

She was vulnerable


**646.** `22:48` **You**

I never was


**647.** `22:48` **Meredith Lamb (+14169386001)**

Why


**648.** `22:49` **You**

Because I didn’t feel it


**649.** `22:49` **Meredith Lamb (+14169386001)**

Yeah I kind of get that situation


**650.** `22:49` **You**

I carry a lot of guilt\.\. but put it down when we separated


**651.** `22:50` **You**

Or alot of
It at least


**652.** `22:50` **Meredith Lamb (+14169386001)**

Are you going to be able to live with that?


**653.** `22:50` **You**

Yep


**654.** `22:50` **You**

The decision I made wasn’t impulsive


**655.** `22:50` **Meredith Lamb (+14169386001)**

Yeah I know


**656.** `22:51` **You**

No moving forward while I might still try to help her out here or there\.\.
I am 100% yours and\. None else’s\.


**657.** `22:51` **You**

Except Sharon


**658.** `22:51` **You**

You have to share meme with her


**659.** `22:52` **Meredith Lamb (+14169386001)**

K this is getting weird


**660.** `22:52` **Meredith Lamb (+14169386001)**

Kidding


**661.** `22:52` **You**

Having gone through marriage once


**662.** `22:52` **You**

And understanding what it means


**663.** `22:52` **You**

And what my mistakes were


**664.** `22:52` **Meredith Lamb (+14169386001)**

So tell me about your honeymoon


**665.** `22:52` **You**

I would do it again with you if someday you wanted to,
For the right reasons


**666.** `22:53` **Meredith Lamb (+14169386001)**

>
What are the wrong reasons?

*💬 Reply*

**667.** `22:53` **You**

>
Because it is what is next

*💬 Reply*

**668.** `22:53` **You**

Reaction: 🤮 from Meredith Lamb
What is expected


**669.** `22:53` **You**

What someone else wanted


**670.** `22:54` **Meredith Lamb (+14169386001)**

>
Is this why you did it?

*💬 Reply*

**671.** `22:54` **You**

>
29’th dec 2004
We left the bed and breakfast where we were married went to our house grabbed our shit and flew to Toronto then Disney

*💬 Reply*

**672.** `22:54` **You**

>
Kind of

*💬 Reply*

**673.** `22:55` **You**

>
Our transfer was fucked we ran to the other end of the airport only to find the plane was delayed because someone lit a cigarette in the airplane bathroom and blew up the toilet

*💬 Reply*

**674.** `22:55` **You**

So we got compdf
First class to Orlando


**675.** `22:55` **You**

But they lost our luggage


**676.** `22:55` **You**

So we went to Disney property Allstars I think


**677.** `22:56` **You**

And got the bags the next day


**678.** `22:56` **You**

She absolutely loved everything\. Disney\.\. and she had no money growing up so had never been


**679.** `22:56` **You**

So this was a logical choice


**680.** `22:56` **You**

We spent a week there and came home


**681.** `22:57` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 22:57:11 \-0400
|
| The end
|
| Version: 1
| Sent: Tue, 8 Jul 2025 22:57:00 \-0400
|
| End of story


**682.** `22:58` **Meredith Lamb (+14169386001)**

lol


**683.** `22:59` **You**

Why did you want to know about that


**684.** `22:59` **Meredith Lamb (+14169386001)**

Very summarized


**685.** `22:59` **You**

I told you before but you see messy


**686.** `22:59` **You**

lol


**687.** `22:59` **Meredith Lamb (+14169386001)**

I see messy?


**688.** `22:59` **You**

You were


**689.** `22:59` **You**

Why would you want details


**690.** `22:59` **You**

Like\.\. lol


**691.** `23:00` **Meredith Lamb (+14169386001)**

What does that mean? I see messy


**692.** `23:00` **You**

No


**693.** `23:00` **You**

You were drunk messy


**694.** `23:00` **You**

Not see


**695.** `23:00` **Meredith Lamb (+14169386001)**

I just kind of feel like you guys were in love etc and you are skipping that part


**696.** `23:00` **You**

No we weren’t


**697.** `23:00` **You**

We had fun


**698.** `23:00` **Meredith Lamb (+14169386001)**

I am not drunk messy


**699.** `23:00` **You**

And I did love her


**700.** `23:01` **You**

You were when I told you this story the first time


**701.** `23:01` **Meredith Lamb (+14169386001)**

Ohhhhhh


**702.** `23:01` **Meredith Lamb (+14169386001)**

Gotcha


**703.** `23:01` **You**

I wasn’t in love with her


**704.** `23:01` **Meredith Lamb (+14169386001)**

Yes, likely


**705.** `23:01` **You**

Anyway lol odd request


**706.** `23:02` **You**

You seem to think I am hiding something


**707.** `23:02` **Meredith Lamb (+14169386001)**

I was just curious\. I sort of recall that story but not fully lol sorry


**708.** `23:02` **You**

Ok


**709.** `23:02` **You**

Let’s try this


**710.** `23:02` **Meredith Lamb (+14169386001)**

No no I don’t


**711.** `23:02` **You**

What I do with you I have done with no one else


**712.** `23:02` **You**

I can def say that


**713.** `23:02` **Meredith Lamb (+14169386001)**

I don’t get the impression you hide


**714.** `23:02` **You**

With certainty


**715.** `23:03` **You**

The feelings 10000% more


**716.** `23:03` **You**

The connection eye contact


**717.** `23:03` **You**

All of it


**718.** `23:03` **You**

Never ever have I ever


**719.** `23:03` **You**

So you won’t find a comparison


**720.** `23:04` **You**

I don’t have a Jeremy


**721.** `23:04` **You**

You tried this before


**722.** `23:04` **You**

lol


**723.** `23:04` **Meredith Lamb (+14169386001)**

You trump everyone Scott


**724.** `23:04` **You**

It’s funny how you forget stuff


**725.** `23:04` **You**

Sometimes


**726.** `23:04` **Meredith Lamb (+14169386001)**

😇


**727.** `23:04` **You**

You grilled me on this one night


**728.** `23:05` **You**

You were convinced I had been in love like this\.\.


**729.** `23:05` **Meredith Lamb (+14169386001)**

I kind of remember but not fully


**730.** `23:05` **You**

Anyhow I do t have a point of comparison I tried to tell you not even with j


**731.** `23:05` **You**

Don’t


**732.** `23:06` **You**

I think you hoped I did


**733.** `23:06` **You**

Or I felt like you did


**734.** `23:06` **You**

Wants me to have one


**735.** `23:06` **You**

Wanted


**736.** `23:07` **Meredith Lamb (+14169386001)**

No I didn’t “hope” that\. I was just surprised you would go to the effort of marrying someone if you weren’t in passionate love…\. Like wedding dress, tux, family etc etc\. it is a lot of effort and $$ … just confusing to me
I wish we were together right now having this conversation\.


**737.** `23:08` **You**

I would have kissed you long ago to distract you


**738.** `23:08` **You**

Never woukd have gotten this far


**739.** `23:08` **Meredith Lamb (+14169386001)**

We never would have talked this much


**740.** `23:08` **Meredith Lamb (+14169386001)**

lol


**741.** `23:08` **You**

Nope\.\. I don’t think so\.


**742.** `23:09` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 23:09:47 \-0400
|
| It I think text forces you to think about what to are going to say\.\. most of the time, where in person you are in a hurry to tell\.
|
| Version: 1
| Sent: Tue, 8 Jul 2025 23:09:30 \-0400
|
| It I think text forces you to think about what to are going to say\.\. where in person you are in a hurry to tell\.


**743.** `23:09` **You**

lol


**744.** `23:10` **Meredith Lamb (+14169386001)**

lol true


**745.** `23:10` **Meredith Lamb (+14169386001)**

I mean in person I’m also happy not talking 😋


**746.** `23:10` **You**

Yep\.  Me too


**747.** `23:13` **You**

Now what are you doing


**748.** `23:13` **Meredith Lamb (+14169386001)**

Nothing listening to music\. Thinking \.\.


**749.** `23:13` **Meredith Lamb (+14169386001)**

Drank too much but did NOT drink the bottle


**750.** `23:14` **You**

Thinking about


**751.** `23:14` **Meredith Lamb (+14169386001)**

Maybe our last time together


**752.** `23:14` **You**

Tuesday morning


**753.** `23:15` **You**

Or in general


**754.** `23:16` **Meredith Lamb (+14169386001)**

I meant our long weekend


**755.** `23:16` **You**

Mmm yeah was a good weekend


**756.** `23:17` **Meredith Lamb (+14169386001)**

It’s nice to daydream to


**757.** `23:17` **You**

I day dream
To the cottage


**758.** `23:18` **Meredith Lamb (+14169386001)**

>
Feels so long ago

*💬 Reply*

**759.** `23:18` **You**

Again laying on that little couch thing snuggled up watching tv under the blanket\.\.
Watching you sleep on the couch as watched a show and rubbed your feet… lol


**760.** `23:19` **You**

Honestly some of the best feelings I have had very true and honest and real\.\. like just there


**761.** `23:19` **Meredith Lamb (+14169386001)**

What about me beating you twice on ticket to ride?


**762.** `23:19` **You**

Cheating


**763.** `23:19` **You**

I mean


**764.** `23:19` **You**

Yeah


**765.** `23:19` **Meredith Lamb (+14169386001)**

lol whatever


**766.** `23:20` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 8 Jul 2025 23:20:21 \-0400
|
| It will be nice when we can choose to daydream but won’t have to
|
| Version: 1
| Sent: Tue, 8 Jul 2025 23:20:03 \-0400
|
| It will be nice when we can choose to daydream\. It don’t have to\.


**767.** `23:21` **You**

I think you will have to ask me btw\.\. so it might never happen


**768.** `23:21` **Meredith Lamb (+14169386001)**

Ask you…?


**769.** `23:21` **You**

I was just flipping back topics before I went to bed


**770.** `23:21` **You**

You will have to do the asking


**771.** `23:22` **Meredith Lamb (+14169386001)**

Ask you to marry me?


**772.** `23:22` **You**

Yeah


**773.** `23:22` **You**

Because I know how you feel about it how apprehensive you are


**774.** `23:22` **You**

And I know how much you love me


**775.** `23:22` **Meredith Lamb (+14169386001)**

I feel like that would follow suit in this relationship lol


**776.** `23:22` **You**

So I would never want you to say yes for any other reason


**777.** `23:22` **You**

So you would need to ask\.


**778.** `23:23` **You**

>
Not true I initiate on a lot

*💬 Reply*

**779.** `23:23` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
k I’m ok with that


**780.** `23:23` **You**

And makes it so no pressure


**781.** `23:23` **Meredith Lamb (+14169386001)**

>
You do\. I didn’t mean that\.  I just think I liked you first

*💬 Reply*

**782.** `23:24` **You**

Maybe but I told
You I loved
You first\.\.
You said it first\.\. I think we go back and forth


**783.** `23:24` **Meredith Lamb (+14169386001)**

>
I feel like you wouldn’t like this lack of control

*💬 Reply*

**784.** `23:24` **Meredith Lamb (+14169386001)**

Planning


**785.** `23:24` **You**

It’s just asking


**786.** `23:24` **You**

There is no plan


**787.** `23:24` **Meredith Lamb (+14169386001)**

>
This is confusing

*💬 Reply*

**788.** `23:25` **You**

I texted
You I loved you\.\. you verbalized it to me int the car first\.\. we each take turns


**789.** `23:25` **Meredith Lamb (+14169386001)**

>
I could do a promposal\. Mac could help me

*💬 Reply*

**790.** `23:25` **You**

You could


**791.** `23:25` **Meredith Lamb (+14169386001)**

lol


**792.** `23:25` **You**

Or you could just ask me sometime, no where special, just because that is what you want


**793.** `23:26` **Meredith Lamb (+14169386001)**

Nowhere special?


**794.** `23:26` **Meredith Lamb (+14169386001)**

Ugh


**795.** `23:26` **You**

That is the beauty of it


**796.** `23:26` **Meredith Lamb (+14169386001)**

That’s not my style exactly


**797.** `23:26` **You**

It is about the feeling not the scenery


**798.** `23:27` **You**

I will remeber more
How you look when you do it than where we are and what we are doing\.


**799.** `23:27` **Meredith Lamb (+14169386001)**

Not true


**800.** `23:27` **You**

Ok


**801.** `23:28` **You**

Remember the trip


**802.** `23:28` **Meredith Lamb (+14169386001)**

How did you ask Jaimie to marry you


**803.** `23:28` **You**

You were like let’s just stay in motels


**804.** `23:28` **You**

Because it didn’t mstter


**805.** `23:29` **You**

It is like that\.\. just you deciding to do it\.\.  instead of being all prepared and choreographed, you just blurt it out… lol the meaning behind it is all that matters


**806.** `23:29` **You**

Reaction: 😂 from Meredith Lamb
>
I told you this story too

*💬 Reply*

**807.** `23:29` **You**

30 years to the hour


**808.** `23:29` **Meredith Lamb (+14169386001)**

>
Doh

*💬 Reply*

**809.** `23:29` **You**

From when my dad proposed to my mum


**810.** `23:29` **Meredith Lamb (+14169386001)**

>
Oh right

*💬 Reply*

**811.** `23:29` **You**

It was in a car


**812.** `23:30` **You**

We were just driving around\.\. after going out for dinner


**813.** `23:30` **You**

I made her a cross stitch


**814.** `23:30` **You**

That I have to her when we got to mums house


**815.** `23:30` **You**

That had the date on it and our names… she was huge into Chris’s stitching at the time


**816.** `23:30` **Meredith Lamb (+14169386001)**

Did she burn  the cross stitch?


**817.** `23:31` **You**

Cross stitch


**818.** `23:31` **You**

Nope


**819.** `23:31` **You**

She might not keep it


**820.** `23:31` **You**

She is keeping the ring for the kids


**821.** `23:31` **Meredith Lamb (+14169386001)**

Well that was very thoughtful…


**822.** `23:32` **Meredith Lamb (+14169386001)**

I am keeping the ring for the kids too\. They can sell it lol


**823.** `23:32` **You**

It was,
And I am , but I wasn’t in love


**824.** `23:32` **Meredith Lamb (+14169386001)**

Andrew doesn’t feel great about me keeping the ring but he reluctantly agreed


**825.** `23:32` **You**

If I asked you I might think a bit about how I would do it


**826.** `23:33` **Meredith Lamb (+14169386001)**

He doesn’t think I keep good enough care of it bc I keep it in a jewelry box?\!


**827.** `23:33` **You**

Hehehe


**828.** `23:33` **You**

Honestly


**829.** `23:34` **Meredith Lamb (+14169386001)**

I might just keep it in case I’m ever in trouble lol


**830.** `23:34` **Meredith Lamb (+14169386001)**

Its last appraisal is $30k\. Stupid\. Not sure what he was thinking


**831.** `23:35` **You**

Yeah no\.\. plastic with a candy gem on it just like in deadpool


**832.** `23:35` **You**

Gem pop


**833.** `23:35` **You**

Appraised at 2$


**834.** `23:35` **You**

Until you eat it


**835.** `23:35` **Meredith Lamb (+14169386001)**

lol


**836.** `23:35` **Meredith Lamb (+14169386001)**

Or do as Ehsan


**837.** `23:36` **Meredith Lamb (+14169386001)**

No ring\. Tattoo


**838.** `23:36` **You**

Kk


**839.** `23:36` **Meredith Lamb (+14169386001)**

My aunt Gail did it and they fucked it up


**840.** `23:36` **Meredith Lamb (+14169386001)**

Was so funny


**841.** `23:36` **Meredith Lamb (+14169386001)**

She hated wearing a ring


**842.** `23:36` **You**

Shit


**843.** `23:36` **You**

lol


**844.** `23:36` **Meredith Lamb (+14169386001)**

So funny


**845.** `23:36` **Meredith Lamb (+14169386001)**

So her finger is messed up


**846.** `23:36` **Meredith Lamb (+14169386001)**

Goes with her personality :p


**847.** `23:37` **You**

J had a tatooo on her finger


**848.** `23:37` **You**

No one knew


**849.** `23:37` **You**

Ever


**850.** `23:37` **Meredith Lamb (+14169386001)**

Like a ring tattoo?


**851.** `23:37` **You**

She hid it with a ring\.\. did it when she was drunk


**852.** `23:37` **You**

Yeah


**853.** `23:37` **You**

Except it was bad


**854.** `23:37` **You**

Reaction: 🙄 from Meredith Lamb
So I paid to get it removed


**855.** `23:37` **You**

Took forever


**856.** `23:38` **Meredith Lamb (+14169386001)**

Yeah my aunt started that but too painful so she stopped lol


**857.** `23:38` **You**

Hehe


**858.** `23:38` **You**

Bad


**859.** `23:38` **You**

Ok listen


**860.** `23:38` **Meredith Lamb (+14169386001)**

>
The things you did

*💬 Reply*

**861.** `23:38` **You**

I need to get to sleep and you need to get to planning


**862.** `23:38` **You**

You have a lot of work to do


**863.** `23:38` **Meredith Lamb (+14169386001)**

I need to go to bed too


**864.** `23:38` **You**

And a lot of thinking to think


**865.** `23:39` **Meredith Lamb (+14169386001)**

Yes


**866.** `23:39` **You**

Man if you were here in person


**867.** `23:39` **Meredith Lamb (+14169386001)**

I know


**868.** `23:39` **You**

I wouldn’t be going to gym


**869.** `23:40` **You**

Ok Mer I love you I am very curious where this goes\.   ❤️❤️❤️❤️❤️❤️\. Hope you have a good sleep\.


**870.** `23:43` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Have a good sleep xo I love you too and would completely have ravished you if we had had the chance tonight ❤️❤️ nite


