# Daily Conversation: 2025-06-05 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-05 |
| **Day** | Thursday |
| **Week** | 8 |
| **Messages** | 700 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-05T04:07 - 2025-06-05T23:59 |

## 📝 Daily Summary

This day contains **700 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:07` **You**

Reaction: ❤️ from Meredith Lamb
I love you so much Mer\. I just wish I was waking up next to you so I could make sure you are ok\.  You didn’t deserve any of that last night nor what came before\.  That is something you will never find with me\.  I might not always be able to give you what you need but I swear to god I will give you everything I have to give just to make you happy\.  Ok I have to scrape my ass outta bed and go to the airport\.  Then gym then home then maddie then water heater lol… then I will wait to hear from you\.  Or maybe you give me another shout\.  If you try push\-ups do them first thing\.  Lock your core flex glutes think about last night and give er\!


**002.** `04:08` **You**

Love you hun more than you know\.  Chat later❤️❤️❤️❤️🔥🔥🔥🔥


**003.** `04:34` **You**

and you know what… someday if you’ll have me, we will get a place together, and we will travel and we will support each other and love each other as we get older and as cheesy as it sounds we will live… you know… ever after\. Honestly I cannot think of anything I want more than to see you smile at me everyday for all the rest\.  Driving now\.\. thinking about you…\.


**004.** `05:54` **You**

Left house at 4:45 at gym at 5:50 I may have sped a bit\.\.


**005.** `07:23` **You**

I sincerely hope you are sleeping in and not fighting


**006.** `08:08` **You**

Kk bit worried


**007.** `08:10` **You**

So we don’t have to chat
Or talk or anything I just want to know you are ok\.\.


**008.** `08:13` **You**



**009.** `08:33` **You**



**010.** `09:00` **You**

??


**011.** `09:00` **Meredith Lamb (+14169386001)**

Slept in lol


**012.** `09:00` **Meredith Lamb (+14169386001)**

Snoozed the alarm a million times


**013.** `09:00` **You**

Kk


**014.** `09:01` **Meredith Lamb (+14169386001)**

Im so sore I think im taking a day off and will push my work outs to Saturday


**015.** `09:02` **Meredith Lamb (+14169386001)**

I was going to do mom to fri


**016.** `09:02` **Meredith Lamb (+14169386001)**

Mon to Fri


**017.** `09:03` **Meredith Lamb (+14169386001)**

But will take today off and do sat


**018.** `09:11` **Meredith Lamb (+14169386001)**

But I’m going to do push ups everyday x


**019.** `09:13` **Meredith Lamb (+14169386001)**

>
Yesterday was so horrible so thank you for this\. I honestly believe this too and I’m not the most optimistic person but I do think this\. It is a little hard coming downstairs to make my coffee and he’s on a call from home\. This is just getting annoying and draining\. I’m tired of it\.

*💬 Reply*

**020.** `09:16` **You**

I know I feel like shit
Today I am stuck here nothing I can do for you\.\. useless\.\. I was worried because I thought something happened because of how hard
You were both going at it\.  I hate this situation and I hate feeling like this all the time\.


**021.** `09:22` **Meredith Lamb (+14169386001)**

No I just went to sleep 💤 but I’m questioning a lot this morning


**022.** `09:22` **Meredith Lamb (+14169386001)**

Like maybe if I did the cottage he would be less nasty\. But I really think it is a bad idea\.


**023.** `09:23` **Meredith Lamb (+14169386001)**

I think we are just going to wait and see what the mediator says


**024.** `09:23` **Meredith Lamb (+14169386001)**

He uploaded stuff last night apparently


**025.** `09:23` **You**

>
Remember what I said\. 🙄

*💬 Reply*

**026.** `09:23` **Meredith Lamb (+14169386001)**

I know\.


**027.** `09:23` **You**

>
What else

*💬 Reply*

**028.** `09:24` **Meredith Lamb (+14169386001)**

The sad thing is that I don’t even want to tell my parents about the kids/weekend things bc it is so awful \(don’t want to stress them\) yet he doesn’t even think there is an issue with what he said


**029.** `09:24` **Meredith Lamb (+14169386001)**

I would like to tell them tho


**030.** `09:24` **You**

What he said was a threat and it was used to intimidate you


**031.** `09:24` **Meredith Lamb (+14169386001)**

I like them to know the whole situation


**032.** `09:25` **You**

Your mum would say get a fucking lawyer right now


**033.** `09:25` **You**

Bet


**034.** `09:25` **Meredith Lamb (+14169386001)**

Yeah maybe


**035.** `09:25` **You**

Consequences to actions


**036.** `09:25` **You**

That is how I live


**037.** `09:26` **Meredith Lamb (+14169386001)**

>
Nothing else really … def not us don’t worry about that

*💬 Reply*

**038.** `09:26` **You**

I always worry about that\.\. cannot help it\.


**039.** `09:27` **Meredith Lamb (+14169386001)**

FYI I just told Mus and Andres to do soft moves to be with team


**040.** `09:27` **Meredith Lamb (+14169386001)**

They want to


**041.** `09:27` **Meredith Lamb (+14169386001)**

And desks are there


**042.** `09:27` **Meredith Lamb (+14169386001)**

One is Anna’s


**043.** `09:27` **Meredith Lamb (+14169386001)**

Andres will go in Anna’s


**044.** `09:27` **You**

It’s fine again that is my problem to solve you have a mountain of
Your own to worry about\.\. as I said focus on you and your stuff this weekend\. I will focus on cleaning or something\.


**045.** `09:27` **You**

Sure
Moves are fine


**046.** `09:27` **You**

I honestly don’t care who does what


**047.** `09:28` **You**

As
Long as there is agreement


**048.** `09:28` **Meredith Lamb (+14169386001)**

>
Just let me recover today :\)

*💬 Reply*

**049.** `09:28` **Meredith Lamb (+14169386001)**

Then we will talk


**050.** `09:28` **Meredith Lamb (+14169386001)**

About weekend


**051.** `09:28` **You**

I am trying to take that off your plate if you will let me it just adds
Stress to you\.\. so just let me help how I can help ok\.


**052.** `09:29` **You**

Literally only thing
I can do\.


**053.** `09:29` **You**

Mistake


**054.** `09:32` **Meredith Lamb (+14169386001)**

You don’t just add stress to my life you know\. You are literally the best thing about my life right now\. I am so tired and couldn’t do anything today but weekend is a bit further out…


**055.** `09:34` **You**

Just worry about you pls I will sort myself out\.\. I have been doing it for a really really long time\.\. so I am used to it and can figure it out\.


**056.** `09:35` **Meredith Lamb (+14169386001)**

I know you can but I like being with you and seeing you\. :\)


**057.** `09:37` **Meredith Lamb (+14169386001)**

Cannot find this song on Spotify\. This post is a lie :\( not dropped yet

*📎 1 attachment(s)*

**058.** `09:38` **You**

Same of course but you have soo
Much happening I think your reaction to us being together is
More one of stress
Than one of relief\.  I just
Don’t think that is healthy for you\.  Anyhow I am sure you need to get ready for you doctors appt or
Your pedicure not sure which comes first


**059.** `09:38` **Meredith Lamb (+14169386001)**

Dr first :p


**060.** `09:39` **Meredith Lamb (+14169386001)**

Get to go back to Bay Street office building\. My dr is in that building


**061.** `09:39` **You**

https://youtu\.be/3HR2zpjl15U?si=S0jcIbIWSijUMAn\_


**062.** `09:44` **Meredith Lamb (+14169386001)**

Meh song\. Disappointing


**063.** `09:45` **You**

lol I didn’t liste


**064.** `09:45` **You**

Figured it would be


**065.** `10:07` **Meredith Lamb (+14169386001)**

Did you tell jim I had a stressful day yday? He checked in … in a way that maybe he knew lol


**066.** `10:07` **You**

I told him he may want to see how you are doing I feel like he can give you support I can’t and I wanted you to have it\.


**067.** `10:08` **Meredith Lamb (+14169386001)**

It was kind of obvious lol I think I know Jim too well


**068.** `10:08` **Meredith Lamb (+14169386001)**

I was talking to Erin at the time


**069.** `10:08` **You**

Probably still I was worried\.\. sorry\.


**070.** `10:08` **Meredith Lamb (+14169386001)**

I was like in my head… Scott said something


**071.** `10:08` **Meredith Lamb (+14169386001)**

Haha


**072.** `10:08` **Meredith Lamb (+14169386001)**

It’s fine


**073.** `10:09` **Meredith Lamb (+14169386001)**

k, I’m getting ready and then leaving


**074.** `10:09` **Meredith Lamb (+14169386001)**

❤️❤️


**075.** `10:09` **You**

Kk have a good day\.


**076.** `10:59` **Meredith Lamb (+14169386001)**

On my drive here I was like “too bad I didn’t have a driver to just drive me around bc I don’t like driving” lol is that mean? Ha


**077.** `11:03` **You**

It is inevitable\.


**078.** `11:03` **You**

And I would happily do it\.


**079.** `11:04` **You**

Would/will


**080.** `11:04` **Meredith Lamb (+14169386001)**

Lol whatever\. I’m in a bitchy mood\.


**081.** `11:04` **Meredith Lamb (+14169386001)**

I just drove to an appt\. Just a bitchy thought in my head


**082.** `11:04` **Meredith Lamb (+14169386001)**

lol


**083.** `11:04` **You**

🙁 sucks


**084.** `11:04` **You**

You will though\.\.


**085.** `11:04` **You**

There is that


**086.** `11:05` **Meredith Lamb (+14169386001)**

I will what?


**087.** `11:05` **You**

Have a driver


**088.** `11:05` **Meredith Lamb (+14169386001)**

Driving miss daisy?


**089.** `11:05` **Meredith Lamb (+14169386001)**

lol


**090.** `11:05` **Meredith Lamb (+14169386001)**

I do not need a driver


**091.** `11:05` **You**

I don’t mind driving around


**092.** `11:05` **Meredith Lamb (+14169386001)**

I think that is so weird


**093.** `11:05` **You**

It is common in many relationships


**094.** `11:05` **You**

For one to be the primary driver when they drove together


**095.** `11:05` **Meredith Lamb (+14169386001)**

>
Says who?

*💬 Reply*

**096.** `11:06` **You**

It just is I will got it


**097.** `11:06` **You**

Gpt


**098.** `11:06` **Meredith Lamb (+14169386001)**

There is a diff between primary driver and being required to be driven places though


**099.** `11:06` **You**

Mmm I could make her go if I wanted


**100.** `11:06` **Meredith Lamb (+14169386001)**

I don’t think primary thing is weird


**101.** `11:06` **You**

And sometimes I have


**102.** `11:06` **You**

But when I don’t mind doing it it isn’t really a chore


**103.** `11:06` **Meredith Lamb (+14169386001)**

I know …


**104.** `11:06` **Meredith Lamb (+14169386001)**

Funny


**105.** `11:06` **You**

I look at things differently than you


**106.** `11:07` **You**

And not necessarily better


**107.** `11:07` **You**

Most things I do I know why I am doing them\.\.


**108.** `11:08` **You**

The stuff I do for Jaimie now isn’t because I want to or want to spend time with her\.\. it is because kf
I do she will be just a bit happier and easier to get along with as
We
Continue to separate


**109.** `11:08` **You**

And so far I have had full transparency to all communications with lawyer and been able to structure my own responses etc\.\. I made decisions I\. How pensions would be dealt with and insurance etc\.


**110.** `11:09` **You**

Reaction: 😮 from Meredith Lamb
I told her about us essentially this morning\.\. not what you would want\.\. but enough so that she got the message and wouldn’t be surprised when it eventually comes out


**111.** `11:12` **Meredith Lamb (+14169386001)**

My Timehop\. Now I feel guilty for taking the day off\. Lol but my mom told me not to go “crazy like last time” when I told her I started working out again this week so that may have influenced my day off today a bit

*📎 1 attachment(s)*

**112.** `11:13` **You**

Eesh Lats and everything damn…


**113.** `11:15` **You**

I can’t wait to take you to the gym\.  Will be fun\.


**114.** `11:16` **Meredith Lamb (+14169386001)**

Look forward to that \(I mean, I have some work to do but will get there\)


**115.** `11:17` **Meredith Lamb (+14169386001)**

My time hop is full of ME doing kid shit and Andrew thinks it would be ok for them to be with me on weekends\. Like wtf\. Idiot\.


**116.** `11:18` **You**

Mer\.\. what he said wasn’t meant to make you think about whether it made sense or not\.\. it was meant to intimidate and hurt you\.\. nothing more\.  He doesn’t believe that even he isn’t that fucking stupid\.\. it was a ploy and a poorly thought out line\.


**117.** `11:18` **You**

One\.


**118.** `11:19` **You**

Btw you skipped over the I told Jaimie so I guess you are cool


**119.** `11:19` **Meredith Lamb (+14169386001)**

Oh didn’t see it … yikes just read that


**120.** `11:19` **Meredith Lamb (+14169386001)**

>
Maybe\. He is THAT stupid tho so probably believes it\. I feel like telling his mom on him\. Not going to

*💬 Reply*

**121.** `11:20` **Meredith Lamb (+14169386001)**

>
Um why?

*💬 Reply*

**122.** `11:21` **You**

She said something along the lines again on the drive in of being replaced and I will have a gf like a week after she leaves and I said yeah probably so she knows who\.\. I said I have been lonely for a long time and that isn’t a dig at
You\.\. but it is true\.\. and I don’t want to be\.\. I don’t think anyone should have to be\. No one replaces you\.\. but I do get to choose to keep
Moving forward with whoever I want\.


**123.** `11:21` **You**

>
I think it was said out of anger about the cottage he feeeks trapped and he wants
You to hurt and feel trapped
To\.

*💬 Reply*

**124.** `11:24` **Meredith Lamb (+14169386001)**

>
Yeah… will let things sit for a bit\.

*💬 Reply*

**125.** `11:24` **Meredith Lamb (+14169386001)**

>
What was the reaction

*💬 Reply*

**126.** `11:24` **You**

I mean doesnt change my position in my thoughts about what you should and likely will do lol


**127.** `11:24` **You**

>
I think resigned\.\. I don’t know how hard she is going to fight me on this any more

*💬 Reply*

**128.** `11:25` **You**

Like you she wants done


**129.** `11:26` **Meredith Lamb (+14169386001)**

Yeah the dragging on and on is probably the worst part of separation I’m learning\.


**130.** `11:26` **You**

It is\.\. especially when you continue to live together


**131.** `11:28` **You**

Anyhow there will still be covert operations\.\. cannot get around that\. But I don’t think I will need to wait that long now to let her know or at least respond honestly when asked


**132.** `11:31` **You**

Remember don’t worry about contraception or no any nonsense I am going to talk to my doc when he is back from vacation\.


**133.** `11:31` **You**

There might be side effects


**134.** `11:50` **Meredith Lamb (+14169386001)**

Still waiting\. She is very late today\!


**135.** `11:57` **You**

Mm reliance guy here was t water heater


**136.** `11:58` **You**

When they installed the water heater and attached the humidifier the installed it the wrong way and the humidifier cable melted in something hot from the water heater pin hole spraying water everywhere…
Gah


**137.** `11:58` **You**

Should be fixed shortly


**138.** `12:12` **You**

Still waiting?


**139.** `12:15` **Meredith Lamb (+14169386001)**

Nope done


**140.** `12:15` **You**

Hopefully uneventful


**141.** `12:16` **Meredith Lamb (+14169386001)**

Yep\. She thinks I should go in anything estrogen based so maybe iud\. She is going to email me\. I also go referred to dermatologist get checked for skin cancer lol


**142.** `12:16` **You**

Why


**143.** `12:17` **You**

wtf


**144.** `12:18` **Meredith Lamb (+14169386001)**

Because I’m blonde and have lots of moles and stuff\. It is important\. My bro does it regularly


**145.** `12:18` **Meredith Lamb (+14169386001)**

Proactive


**146.** `12:38` **You**

Mmmmmmm


**147.** `12:38` **You**

And what about this estrogen thing?


**148.** `12:38` **You**

Isn’t there side effects?


**149.** `12:38` **You**

You are probably driving again\.\. sorry Gracie exploded at me


**150.** `12:49` **Meredith Lamb (+14169386001)**

Just got home and he is not here\. Ahhhh :\) :\)


**151.** `12:50` **Meredith Lamb (+14169386001)**

Estrogen is bad for my clotting gene variant\.


**152.** `12:50` **Meredith Lamb (+14169386001)**

I have a gene variant that can cause blood clotting\. Found out about it during genetic dna testing while in fertility years ago


**153.** `12:51` **Meredith Lamb (+14169386001)**

That’s what I was testing girls for at sick kids\. Gets passed on from parent


**154.** `12:51` **Meredith Lamb (+14169386001)**

Relatively new gene discovered in the 80s


**155.** `12:51` **Meredith Lamb (+14169386001)**

Blood clots cause miscarriages so they test for it in fertility


**156.** `12:52` **Meredith Lamb (+14169386001)**

>
All ok there?

*💬 Reply*

**157.** `12:55` **You**

Nope


**158.** `13:12` **Meredith Lamb (+14169386001)**

What’s wrong\.


**159.** `13:13` **You**

Gracie again\.\.


**160.** `13:13` **You**

We just cannot
Live
Together


**161.** `13:14` **You**

>
Ok then why go on an estrogen solution

*💬 Reply*

**162.** `13:14` **You**

Let me get the surgery


**163.** `13:14` **Meredith Lamb (+14169386001)**

She said NOT to


**164.** `13:14` **Meredith Lamb (+14169386001)**

So she is going to email me re: an iud


**165.** `13:14` **You**

Oh your text
Didnt say that


**166.** `13:14` **Meredith Lamb (+14169386001)**

She said


**167.** `13:14` **You**

Ok


**168.** `13:14` **Meredith Lamb (+14169386001)**

Oh sorry typo\!


**169.** `13:14` **You**

But still that has side effects too I think


**170.** `13:15` **Meredith Lamb (+14169386001)**

One of my good friends loves it


**171.** `13:15` **Meredith Lamb (+14169386001)**

So depends probably


**172.** `13:15` **You**

I think it cancels your period


**173.** `13:16` **You**

Well the hormonal kids do


**174.** `13:16` **You**

Iuds


**175.** `13:16` **You**

I just don’t understand


**176.** `13:16` **You**

I am HAPPY to do this


**177.** `13:17` **You**

I am never having more children anyways


**178.** `13:18` **You**

I just don’t want you to have to go through something that puts you at risk or anything of side effects etc


**179.** `13:19` **You**

Worried


**180.** `13:19` **Meredith Lamb (+14169386001)**

She is going to email me\. We will see she doesn’t insert them so I’d go elsewhere anyway\. It isn’t a worry right now\. Nothing in motion\.


**181.** `13:19` **You**

Ok


**182.** `13:20` **You**

Well I am sure you are flad that is over and done with\.\. now just a pedicure to top your day off


**183.** `13:22` **You**

>
Again and still I don’t understand your reticence to allow me to address this on my side\.\.

*💬 Reply*

**184.** `13:37` **You**

ROFL


**185.** `13:38` **Meredith Lamb (+14169386001)**

So I was away on the weekend obviously and I have come home and had to clean up cat pee, like three times


**186.** `13:38` **You**

Fun


**187.** `13:38` **Meredith Lamb (+14169386001)**

The reason is because our two litter boxes were completely unuseable because I am the only one maintaining anything or taking care of the cats at all


**188.** `13:38` **You**

Yuck yeah


**189.** `13:38` **You**

I get that


**190.** `13:38` **Meredith Lamb (+14169386001)**

So I asked him today if we should surrender the cats to a rescue because with me leaving how are they gonna get taken care of?


**191.** `13:38` **Meredith Lamb (+14169386001)**

He says he’ll start taking care of them when I leave\. I said that’s not fair\. Help out now\.


**192.** `13:38` **Meredith Lamb (+14169386001)**

Then he tells me I’m bossing him around


**193.** `13:38` **You**

Jesus


**194.** `13:38` **You**

Ah so just flipping it


**195.** `13:39` **Meredith Lamb (+14169386001)**

So yeah, we’re just arguing about everything now


**196.** `13:39` **You**

Fantastic


**197.** `13:39` **Meredith Lamb (+14169386001)**

He thinks he’s helping to keep this house afloat because he does dishes occasionally


**198.** `13:39` **Meredith Lamb (+14169386001)**

Like honestly, you can’t even have a conversation with them\. I just need to stop engaging entirely so I just made a commitment to myself that I am going to do that from now on no matter what\.


**199.** `13:39` **Meredith Lamb (+14169386001)**

\*with him


**200.** `13:40` **You**

Well at least taxes are done and uploaded


**201.** `13:40` **You**

That is something


**202.** `13:42` **Meredith Lamb (+14169386001)**

Yeah omg


**203.** `14:02` **You**

I assume getting your feets done now or waiting


**204.** `14:02` **You**

just got back on computer and saw you typing something so just guessing


**205.** `14:03` **Meredith Lamb (+14169386001)**

>
I feel like guys generally are not happy to do this\. Women are most used to doing shit\. Lol babies and stuff\. Andrew resisted for a long time so I know it is a big deal :p

*💬 Reply*

**206.** `14:03` **Meredith Lamb (+14169386001)**

It’s okay


**207.** `14:03` **You**

It isn't


**208.** `14:03` **You**

I am not saying it just because


**209.** `14:04` **You**

Look I am just going to do it anyways\.\. so you do whatever you want to do lol\.


**210.** `14:04` **You**

I just have to wait for My dr to come back from vacation\.


**211.** `14:05` **Meredith Lamb (+14169386001)**

I feel like you have a lot going on medically that you don’t need anything else right now lol


**212.** `14:06` **You**

what do you mean\.\. "I" do


**213.** `14:06` **You**

you have more going on than me by far


**214.** `14:07` **Meredith Lamb (+14169386001)**

You take a lot of meds and stuff …\. I’ve been pretty consistently doing the same thing for years


**215.** `14:07` **You**

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


**216.** `14:07` **You**

I have gerd\.\. OMG\!\!\!


**217.** `14:08` **You**

I have high blood pressure \*barely\* and take the lowest dose possible\.  I take a voluntariy cholesteral drug which is more like a suppliment and I take an ED pill\.\. because why the fuck not\.


**218.** `14:08` **You**

I have sleep apnea which is treated\.\. and much much better\.


**219.** `14:08` **You**

so I think I am fine\.


**220.** `14:09` **Meredith Lamb (+14169386001)**

lol


**221.** `14:09` **You**

I can get snipped\.\. I would rather that then you get some kind of hormonal device or copper device shoved in you\.\. unfair


**222.** `14:09` **Meredith Lamb (+14169386001)**

Quite a summary


**223.** `14:09` **Meredith Lamb (+14169386001)**

Well I wouldn’t mind not having a period tbh


**224.** `14:09` **Meredith Lamb (+14169386001)**

So not all bad


**225.** `14:09` **You**

you are going to do whatever you want anyways\.\.\.\.\.\.\.  I already realize I won't be wearing shorts let alone pants in this relationship\.


**226.** `14:10` **Meredith Lamb (+14169386001)**

lol stop


**227.** `14:12` **You**

see\.\. you only say that when you know I am right


**228.** `14:12` **Meredith Lamb (+14169386001)**

Errr


**229.** `14:12` **You**

that's like "noooo stop it\.\. that's not true" \(as she thinks to herself\.\. totally is\!\!\)


**230.** `14:13` **Meredith Lamb (+14169386001)**

I do like to do what I want\. Not going to argue with that\.


**231.** `14:13` **Meredith Lamb (+14169386001)**

lol


**232.** `14:13` **Meredith Lamb (+14169386001)**

However, you are an adult and I won’t tell you what to do \(all the time\)


**233.** `14:14` **You**

just this and many more instances\.\.


**234.** `14:14` **You**

I still may not listen\.\. we'll see


**235.** `14:21` **Meredith Lamb (+14169386001)**

We have lots of “we’ll seeing” to do :\)


**236.** `14:21` **You**

whatever you say dear\.


**237.** `14:22` **Meredith Lamb (+14169386001)**

So what was Gracie’s beef today


**238.** `14:23` **You**

Reaction: 😮 from Meredith Lamb
Same shit\.\. she wanted wanted wanted\.\. and I said no\.\. she wants me to go spend a bunch of money on stuff\. and I refused\.\. she does nothing to add value\.\. she won't grow up\.\. it got heated\.\. she called Jaimie\.\. she freaked out started smashing something on the floor and we said if she continued she would be removed\.  Good times all around\.


**239.** `14:24` **You**

I mean trust me I don't just sit there meek and mild\.\. I engage and I shouldn't and in the real world I wouldn't  but there is sooooooo much history and shit here it is hard not to\.


**240.** `14:26` **Meredith Lamb (+14169386001)**

Yeah that is how I feel with Andrew\. Sooooo hard not to engage\. I get it\.


**241.** `14:26` **You**

This is just an impossible situation\.\. and I feel very much a bad father and husband\.\. and I wish I could have done a better job\.\.


**242.** `14:27` **You**

It is what it is though


**243.** `14:27` **Meredith Lamb (+14169386001)**

Her therapist doesn’t help at all??


**244.** `14:27` **You**

nope\.\. she doesn't tell her therapist the whole truth


**245.** `14:27` **Meredith Lamb (+14169386001)**

Ahhh ok yeah that’s a problem


**246.** `14:27` **You**

see gracie won't own up to it or face it\.\. she blames everyone els


**247.** `14:27` **Meredith Lamb (+14169386001)**

But the therapist must know she doesn’t go to school nor work?


**248.** `14:27` **You**

and until she does\.


**249.** `14:28` **You**

>
yes

*💬 Reply*

**250.** `14:28` **Meredith Lamb (+14169386001)**

Are they trying to address that


**251.** `14:28` **You**

we wouldn't know


**252.** `14:28` **Meredith Lamb (+14169386001)**

Gah


**253.** `14:28` **You**

she is 18 and even then we don't have contact with therapist


**254.** `14:29` **Meredith Lamb (+14169386001)**

Seems a little impossible


**255.** `14:32` **You**

it is J and I agree there is not likely to be any kind of reconciliation between Gracie and I for some time\.\. she needs to really get professional help\.\. I tried to explain that to her\.\. we aren't equipped for this\.\. and she just said she wants compassion\.\. and I said no\.\. that just empowers you to keep doing what you are doing\.\. you need a boot in the ass\.


**256.** `14:32` **You**

and then\.\. well you can guess


**257.** `14:33` **Meredith Lamb (+14169386001)**

I think I can guess…\. Smash


**258.** `14:33` **You**

yep


**259.** `14:33` **Meredith Lamb (+14169386001)**

Compassion


**260.** `14:33` **You**

thats what she says\.\.


**261.** `14:33` **You**

but tbh\.\.


**262.** `14:33` **You**

I don't have any\.\. it has been so bad for so long\.\.


**263.** `14:33` **You**

I tried to explain the empty glass concept to her


**264.** `14:34` **You**

but she just says you are my parent and I should be able to do anything\.


**265.** `14:34` **Meredith Lamb (+14169386001)**

Oh boy


**266.** `14:35` **Meredith Lamb (+14169386001)**

Maybe you should try family counselling??


**267.** `14:35` **You**

It would never work\.\. again\.\. she cannot face the truth


**268.** `14:35` **Meredith Lamb (+14169386001)**

Then you can hear what the counsellor says tho


**269.** `14:35` **You**

she has segmented it off, suppressed it\.


**270.** `14:36` **You**

We could\.\. maybe J and her could do it in Moncton


**271.** `14:36` **Meredith Lamb (+14169386001)**

It might be money better spent


**272.** `14:36` **You**

I am literally just trying to survive here\.


**273.** `14:41` **Meredith Lamb (+14169386001)**

Just had a hot stone leg and foot massage\. Feel better LOL


**274.** `14:41` **You**

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


**275.** `14:41` **You**

well after last night\.\. and in general


**276.** `14:41` **You**

you deserve it


**277.** `14:41` **You**

I didn't book my massage


**278.** `14:43` **You**

hmm I could go for an hour at 6:45 tonight


**279.** `14:43` **Meredith Lamb (+14169386001)**

Told Mac I was going today and she was like “get a facial too” … thinks I’m made of $ lol


**280.** `14:43` **Meredith Lamb (+14169386001)**

>
You should

*💬 Reply*

**281.** `14:43` **You**

you should come to lifetime\.\. they got this cool hydrafacial thing


**282.** `14:43` **You**

hydro


**283.** `14:44` **Meredith Lamb (+14169386001)**

I’m not a big facial person\. Sensitive skin


**284.** `14:44` **Meredith Lamb (+14169386001)**

I always come out looking red


**285.** `14:46` **You**

I have never had one\.


**286.** `14:46` **You**

hmm I think massage then sauna\.\. then shower then home maybe\.\. :\)


**287.** `14:49` **You**

Reaction: ❤️ from Meredith Lamb
booked


**288.** `14:52` **Meredith Lamb (+14169386001)**

I’m on my way home\. I have a brutal headache though like every day this week brutal week\.


**289.** `14:52` **You**

That sucks\.\. I hope he still isn't there


**290.** `14:52` **You**

do you have to drive tonight\.\.


**291.** `14:52` **You**

and stay off work comp pls\.


**292.** `14:57` **Meredith Lamb (+14169386001)**

He’s not here\. I only have to drive to Maelle’s bronze and back tonight\. Nothing too big\.


**293.** `15:02` **You**

Kk well that isn’t so bad


**294.** `15:13` **Meredith Lamb (+14169386001)**

Having protein shake and aleve for the head ache


**295.** `15:36` **Meredith Lamb (+14169386001)**

Deb, emailed me a welcome back today lol


**296.** `15:36` **You**

lol well isn’t that nice


**297.** `15:36` **Meredith Lamb (+14169386001)**

Have to admit it kind of made me feel special


**298.** `15:36` **Meredith Lamb (+14169386001)**

Hahahah


**299.** `15:36` **You**

Whatever


**300.** `15:36` **Meredith Lamb (+14169386001)**

LOL


**301.** `15:37` **You**

Reaction: 😂 from Meredith Lamb
Whenever I try to make you feel special you are like meh or w/e


**302.** `15:37` **You**

lol


**303.** `15:37` **You**

Jk


**304.** `15:37` **You**

Just to be clear because you never get them


**305.** `15:38` **Meredith Lamb (+14169386001)**

I just feel like she wouldn’t have done that for just anyone


**306.** `15:38` **Meredith Lamb (+14169386001)**

lol


**307.** `15:38` **You**

Nope you are right


**308.** `15:38` **You**

She does actually like you beyond just that
You are a good worker as I understand it


**309.** `15:38` **You**

Although that helps


**310.** `15:38` **You**

Sec driving f maddie


**311.** `15:40` **Meredith Lamb (+14169386001)**

I’m driving Mac lol


**312.** `16:08` **You**

Back


**313.** `16:11` **Meredith Lamb (+14169386001)**

I’m at park with dogs\. It is really nice out here…


**314.** `16:18` **You**

Draft sep agreement here haven’t opened yet


**315.** `16:18` **You**

Waiting for j permission


**316.** `16:22` **Meredith Lamb (+14169386001)**

What? Really?


**317.** `16:22` **Meredith Lamb (+14169386001)**

lol funny


**318.** `16:23` **Meredith Lamb (+14169386001)**

I’m so freaking jealous you are at this point


**319.** `16:26` **You**

Not really at any point yet\.


**320.** `16:27` **Meredith Lamb (+14169386001)**

I mean further than me


**321.** `16:51` **You**

it isn't looking pretty I need to do some math


**322.** `16:52` **Meredith Lamb (+14169386001)**

What seriously?


**323.** `16:52` **You**

yeah\.\. like really bad\.\.


**324.** `16:52` **Meredith Lamb (+14169386001)**

Holy crap


**325.** `17:08` **Meredith Lamb (+14169386001)**

You alright? Are you doing math?


**326.** `17:09` **You**

yeah


**327.** `17:16` **Meredith Lamb (+14169386001)**

Have you figured out how it is so much off of what you had?


**328.** `17:16` **You**

is andrew there\.


**329.** `17:16` **Meredith Lamb (+14169386001)**

No


**330.** `17:16` **Meredith Lamb (+14169386001)**

At vball with marmar


**331.** `17:16` **You**

ah nm


**332.** `17:16` **You**

I was going to teams you and share my screen\.


**333.** `17:17` **You**

are you in car waiting or watching


**334.** `17:17` **Meredith Lamb (+14169386001)**

I’m at my computer


**335.** `17:17` **You**

yeah but I cannot teams you it will be outloud


**336.** `17:17` **Meredith Lamb (+14169386001)**

I’m in the office with door shut


**337.** `17:17` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Andrew is at vball with Marlowe


**338.** `17:17` **You**

Oh shit nm


**339.** `17:17` **You**

I thought you were


**340.** `17:17` **You**

bah


**341.** `17:17` **Meredith Lamb (+14169386001)**

No


**342.** `17:17` **You**

ok one sec


**343.** `17:17` **Meredith Lamb (+14169386001)**

I do swimming later


**344.** `17:18` **You**

I already figured it out


**345.** `17:18` **Meredith Lamb (+14169386001)**

7\.30


**346.** `17:19` **You**


*📎 1 attachment(s)*

**347.** `18:22` **You**

A strategic withdrawal if I ever saw one


**348.** `18:22` **You**

Hope that wasn’t too obvious


**349.** `18:23` **Meredith Lamb (+14169386001)**

lol


**350.** `18:23` **Meredith Lamb (+14169386001)**

Been there


**351.** `18:25` **You**

No you didn’t get it


**352.** `18:25` **You**

That’s ok


**353.** `18:25` **You**

Next time maybe


**354.** `18:25` **You**

❤️


**355.** `18:26` **Meredith Lamb (+14169386001)**

Oh I get it now


**356.** `18:26` **Meredith Lamb (+14169386001)**

lol


**357.** `18:27` **You**

Yeah I was getting a bit anxious was like ok can’t have this discussion yet time to go\.


**358.** `18:28` **You**

All I Remeber was last time offering to meet him and you stuttering through a response\.\.
lol so yeah……


**359.** `18:29` **You**

Reaction: 👍 from Meredith Lamb
Maybe we just don’t talk about that for a really long time unless we have to\.\. my fault for bringing him up\.


**360.** `18:29` **You**

Clearly I cannot handle yet\.\.


**361.** `18:30` **Meredith Lamb (+14169386001)**

Noted\.


**362.** `18:31` **Meredith Lamb (+14169386001)**

:\)


**363.** `18:31` **You**

Noted sounds so bad\.\.


**364.** `18:31` **You**

But ok


**365.** `18:33` **Meredith Lamb (+14169386001)**

I mean, I’m just trying to articulate that I understand\.


**366.** `18:46` **Meredith Lamb (+14169386001)**

I’m talking to my parents\. Are you ok?


**367.** `18:48` **You**

Just going into session


**368.** `18:48` **Meredith Lamb (+14169386001)**

kk


**369.** `20:12` **You**

Reaction: ❤️ from Meredith Lamb
Going to jump in sauna then shower then head home\.


**370.** `20:13` **Meredith Lamb (+14169386001)**

I’m here


**371.** `20:36` **You**

Just have to run to get Gracie a cart……\.\.


**372.** `20:36` **You**

Fml


**373.** `20:36` **Meredith Lamb (+14169386001)**

lol


**374.** `20:41` **You**

Still want me to book I just wanted to make sure before I did…\.


**375.** `20:42` **Meredith Lamb (+14169386001)**

Sure if you are ok with it\.  What if I start talking?


**376.** `20:42` **You**

Hmm?  You mean if I get a phone call??


**377.** `20:43` **Meredith Lamb (+14169386001)**

I mean if I start talking about shit you don’t prefer to hear about…\.


**378.** `20:43` **You**

I don’t know we will have to find out\.


**379.** `20:44` **You**

Can you call or is Andrew home


**380.** `20:44` **Meredith Lamb (+14169386001)**

🙁


**381.** `20:44` **Meredith Lamb (+14169386001)**

I’m on the phone with my parents still


**382.** `20:44` **You**

Ah ok wel stay on with them


**383.** `20:44` **Meredith Lamb (+14169386001)**

Andrew is home :p


**384.** `20:44` **You**

Dunno what sad face is for


**385.** `20:45` **Meredith Lamb (+14169386001)**

Sad face is bc you think I will start talking about shit you don’t want to hear about\.


**386.** `20:45` **You**

I didn’t say that you said that


**387.** `20:45` **You**

And you asked what I would do


**388.** `20:45` **You**

And I said we will have to find out


**389.** `20:46` **You**

Glass number?


**390.** `20:46` **Meredith Lamb (+14169386001)**

>
And I responded with 😕

*💬 Reply*

**391.** `20:46` **You**

❤️


**392.** `20:46` **You**

I know but I didn’t say you would do it


**393.** `20:46` **Meredith Lamb (+14169386001)**

>
No comment\.

*💬 Reply*

**394.** `20:46` **You**

I yeah


**395.** `20:46` **You**

Yeah


**396.** `20:54` **Meredith Lamb (+14169386001)**

My mom has to have a ct scan tomorrow and doesn’t wan to drive herself


**397.** `20:54` **Meredith Lamb (+14169386001)**

I told her I’d go


**398.** `20:54` **Meredith Lamb (+14169386001)**

I’m like I have ONE meeting


**399.** `20:55` **Meredith Lamb (+14169386001)**

But my dad is going


**400.** `20:55` **You**

Nice of you\. Don’t book anything


**401.** `20:55` **You**

Just take it


**402.** `20:55` **Meredith Lamb (+14169386001)**

I was telling her about you driving Jaimie everywhere and she was like “uhhhhh I’m kind of the same way”


**403.** `20:55` **Meredith Lamb (+14169386001)**

I’m like “in my new job I can take you mom\!”


**404.** `20:55` **Meredith Lamb (+14169386001)**

lol


**405.** `20:57` **You**


*📎 2 attachment(s)*

**406.** `20:58` **You**

Hehe


**407.** `20:58` **Meredith Lamb (+14169386001)**

I do t see an actual address


**408.** `20:59` **You**


*📎 2 attachment(s)*

**409.** `20:59` **You**


*📎 1 attachment(s)*

**410.** `20:59` **You**

Address there


**411.** `21:02` **Meredith Lamb (+14169386001)**

k, I lived with my great aunt for a year while I was pregnant with Mackenzie on ellerslie right near there while I worked at union gas


**412.** `21:02` **Meredith Lamb (+14169386001)**

Think I know the area


**413.** `21:09` **You**

Sigh omw home now


**414.** `21:12` **Meredith Lamb (+14169386001)**

Still talking, still drinking\. Eeeeeek


**415.** `21:13` **Meredith Lamb (+14169386001)**

So you did a massage?


**416.** `21:13` **You**

Yeah ur not working out


**417.** `21:13` **You**

lol


**418.** `21:13` **Meredith Lamb (+14169386001)**

I am\!


**419.** `21:13` **You**

6 glasses


**420.** `21:13` **You**

Nope


**421.** `21:13` **You**

Nope nope nope


**422.** `21:14` **You**

No judgement after kast night you needed this


**423.** `21:14` **Meredith Lamb (+14169386001)**

My mom is giving my highlights okc vs Indiana bball game


**424.** `21:14` **Meredith Lamb (+14169386001)**

They are obsessed


**425.** `21:14` **You**

lol


**426.** `21:14` **You**

Go shae


**427.** `21:15` **Meredith Lamb (+14169386001)**

Shae is winning :\(


**428.** `21:15` **Meredith Lamb (+14169386001)**

We like pascal


**429.** `21:15` **You**

lol


**430.** `21:15` **You**

I used to make fun of the noise he made when the tried to draw a foul


**431.** `21:15` **Meredith Lamb (+14169386001)**

I’m getting the play by play


**432.** `21:15` **You**

It was like some baby animal crying


**433.** `21:16` **You**

But I love pascal too watched him since bench mob


**434.** `21:17` **Meredith Lamb (+14169386001)**

Yeah we like pascal and og and og lost :\(


**435.** `21:18` **Meredith Lamb (+14169386001)**

I don’t watch bball anymore


**436.** `21:18` **You**

I could dunk on your mom btw\.


**437.** `21:18` **Meredith Lamb (+14169386001)**

Yes she has shrunk


**438.** `21:18` **Meredith Lamb (+14169386001)**

lol


**439.** `21:18` **You**

Just saying


**440.** `21:18` **Meredith Lamb (+14169386001)**

She used to be 5’7”


**441.** `21:18` **Meredith Lamb (+14169386001)**

Of 5’6”


**442.** `21:19` **Meredith Lamb (+14169386001)**

Oh she said 5’6”


**443.** `21:19` **Meredith Lamb (+14169386001)**

So I’m taller than her


**444.** `21:19` **Meredith Lamb (+14169386001)**

She has shrunk


**445.** `21:19` **You**

lol


**446.** `21:34` **You**

Home with a crying kid omfg she never stops


**447.** `21:37` **Meredith Lamb (+14169386001)**

Why is she crying???


**448.** `21:38` **You**

Cause it is all she ever does about everything
It is like she regressed to like 10


**449.** `21:38` **You**

She projects her feelings onto the dog, she makes
Up memories that don’t exist


**450.** `21:38` **You**

It is messed up


**451.** `21:38` **Meredith Lamb (+14169386001)**

😢


**452.** `21:39` **You**

Omg soo annoying


**453.** `21:39` **You**

As you would say


**454.** `21:39` **You**

Did you tell your mum I chickened out


**455.** `21:40` **Meredith Lamb (+14169386001)**

Chickened out? No


**456.** `21:40` **Meredith Lamb (+14169386001)**

I haven’t told her anything


**457.** `21:40` **You**

I meant about meeting her


**458.** `21:40` **Meredith Lamb (+14169386001)**

We have been talking about anything


**459.** `21:40` **You**

Ok


**460.** `21:40` **You**

I meant this weekend


**461.** `21:40` **You**

Not sure if you are thinking about something else


**462.** `21:41` **Meredith Lamb (+14169386001)**

We are talking about how I would have been “Scott” if I was a boy


**463.** `21:41` **You**

Oh yeah the name


**464.** `21:41` **You**

You should tell her about the song…\. LAME


**465.** `21:42` **Meredith Lamb (+14169386001)**

I will leave that out for now unless you send it to me again


**466.** `21:42` **You**

No I figured you didn’t remember anyways


**467.** `21:42` **Meredith Lamb (+14169386001)**

Of course I remember


**468.** `21:42` **Meredith Lamb (+14169386001)**

Scott is generally a name in my family tho


**469.** `21:43` **Meredith Lamb (+14169386001)**

I have a second cousin who is younger than me … Scotty


**470.** `21:44` **You**

No shit from Andrew tonight seeing as
You are on phone\.\. did you share what he said


**471.** `21:47` **Meredith Lamb (+14169386001)**

Of course I did


**472.** `21:47` **Meredith Lamb (+14169386001)**

I sent screenshots


**473.** `21:47` **Meredith Lamb (+14169386001)**

And emails


**474.** `21:47` **Meredith Lamb (+14169386001)**

Etc


**475.** `21:47` **Meredith Lamb (+14169386001)**

lol


**476.** `21:48` **Meredith Lamb (+14169386001)**

My mom didn’t msg back and I was like WTF


**477.** `21:48` **Meredith Lamb (+14169386001)**

apparently she walked with my aunt and had a nap


**478.** `21:48` **Meredith Lamb (+14169386001)**

Andrew is in other room


**479.** `21:48` **Meredith Lamb (+14169386001)**

I am in office with door shut


**480.** `21:49` **You**

Wow so we will have to wait to see what your mum thinks


**481.** `21:49` **You**

It is 10 am not 9 am but I will
Meet you for breakfast if you want 🙂


**482.** `21:56` **Meredith Lamb (+14169386001)**

Wait tomorrow?


**483.** `21:56` **You**

Sat


**484.** `21:56` **You**

………


**485.** `21:56` **Meredith Lamb (+14169386001)**

k bc mar was just in here complaining that she needs to go grad dress shopping


**486.** `21:57` **You**

I can cancel Saturday it is free cancellation\.


**487.** `21:57` **Meredith Lamb (+14169386001)**

No


**488.** `21:57` **Meredith Lamb (+14169386001)**

She has fun fair sat


**489.** `21:58` **You**

Kk well you let me know about breakfast I feel like the conversation took an s turn lol


**490.** `21:59` **Meredith Lamb (+14169386001)**

S turn?


**491.** `21:59` **You**

I told you instead
Of 9\-5 it is 10\-5 on sat but we could still meet at 9’dor breakfast


**492.** `22:00` **You**

Then something happened lol and you thought it was tomorrow and then something about dress shopping


**493.** `22:00` **Meredith Lamb (+14169386001)**

9 means I leave at 8


**494.** `22:01` **You**

Kk no breakfast all good maybe I can pick something up on the way and bring it in\.


**495.** `22:01` **Meredith Lamb (+14169386001)**

Ok so what time do I need to be there


**496.** `22:02` **You**

We have from 10\-5


**497.** `22:03` **You**

But look if it is inconvenient again free to cancel no issues


**498.** `22:04` **Meredith Lamb (+14169386001)**

No it is good


**499.** `22:04` **Meredith Lamb (+14169386001)**

Seriously


**500.** `22:06` **You**

Not feeling it is lol sorry too difficult lol


**501.** `22:07` **Meredith Lamb (+14169386001)**

>
k wait not understanding

*💬 Reply*

**502.** `22:10` **Meredith Lamb (+14169386001)**

I think you need to be into’d to my parent ms


**503.** `22:10` **Meredith Lamb (+14169386001)**

I am going to take them on a trip


**504.** `22:11` **Meredith Lamb (+14169386001)**

Given this convo I’m on right now n


**505.** `22:11` **Meredith Lamb (+14169386001)**

You could come if you ever meet them


**506.** `22:12` **You**

Reaction: 😂 from Meredith Lamb
well as long as the trip isn't before the weekend of the 21


**507.** `22:12` **You**

or I could go Saturday after for an hour or so\.


**508.** `22:13` **You**

Sorry maybe it is the wine\.\. or the communicating by text\.\. it just didn't seem like you wanted to go\.\. you were busy etc\.\. and I get it\.  that is all I meant\.


**509.** `22:21` **Meredith Lamb (+14169386001)**

I do want to


**510.** `22:21` **Meredith Lamb (+14169386001)**

Still talking to my mom


**511.** `22:21` **Meredith Lamb (+14169386001)**

Trying to get her to drink kefir and fermented stuff


**512.** `22:21` **You**

I will meet her Sat after 5 if you want\.\. I just cannot stay too late\.


**513.** `22:21` **You**

>
lol why

*💬 Reply*

**514.** `22:23` **Meredith Lamb (+14169386001)**

>
Let’s just get together you and I and we can go from there there\. Good plan?

*💬 Reply*

**515.** `22:23` **Meredith Lamb (+14169386001)**

I’m a good planner


**516.** `22:23` **Meredith Lamb (+14169386001)**

;\)


**517.** `22:23` **You**

yeah you sure are\.\.


**518.** `22:23` **Meredith Lamb (+14169386001)**

😇


**519.** `22:25` **You**

well all I know is I will be there are 10 am


**520.** `22:26` **Meredith Lamb (+14169386001)**

Okay


**521.** `22:26` **You**

and I will be naked


**522.** `22:26` **You**

😛😛


**523.** `22:27` **You**

just wanted to see your reaction\.\.looks like you deleted


**524.** `22:27` **Meredith Lamb (+14169386001)**

My mom just said “you do realize you are 47, you are not supposed to be bringing ppl home at 47”


**525.** `22:27` **You**

>
what is the age that you are supposed to stop?

*💬 Reply*

**526.** `22:27` **Meredith Lamb (+14169386001)**

But then we discussed and she changed her kind


**527.** `22:27` **You**

ask her


**528.** `22:27` **Meredith Lamb (+14169386001)**

Mind


**529.** `22:27` **Meredith Lamb (+14169386001)**

lol


**530.** `22:28` **Meredith Lamb (+14169386001)**

My mom just turned 80\. Dad is 83


**531.** `22:28` **You**

It is all relative then


**532.** `22:28` **You**

you can share that too LOL


**533.** `22:28` **You**

I will act appropriately 19


**534.** `22:28` **You**

Mrs\. Lamb and all


**535.** `22:28` **Meredith Lamb (+14169386001)**

My mom is relatively young docent her age \(ppl tell me\)


**536.** `22:29` **Meredith Lamb (+14169386001)**

\*despite


**537.** `22:29` **You**

the weird thing is going to be that she knows a lot about me already\.\. including some things that she shouldn't know


**538.** `22:29` **You**

at least nothing a parent back when I was a teen would know


**539.** `22:29` **Meredith Lamb (+14169386001)**

She is fine\. I’m talking to her


**540.** `22:29` **Meredith Lamb (+14169386001)**

4th quarter for game


**541.** `22:30` **Meredith Lamb (+14169386001)**

>
Like what?

*💬 Reply*

**542.** `22:31` **You**

my trips to the cottage


**543.** `22:31` **You**

other naughty things we have done


**544.** `22:31` **You**

bnb


**545.** `22:31` **You**

the tryste\!\!


**546.** `22:36` **Meredith Lamb (+14169386001)**

lol yeah she knows about all that


**547.** `22:36` **Meredith Lamb (+14169386001)**

I’m not a good liar


**548.** `22:36` **Meredith Lamb (+14169386001)**

Sorry


**549.** `22:36` **You**

Yeah and I am worried about what other details she might know about


**550.** `22:36` **You**

since you are very open\.\. at least with her


**551.** `22:36` **You**

:\)


**552.** `22:37` **Meredith Lamb (+14169386001)**

Why would you be worried?


**553.** `22:37` **You**

based on what you shared I might not be\.\. but you have surprised me before lol


**554.** `22:37` **You**

I will give you a for example


**555.** `22:37` **Meredith Lamb (+14169386001)**

I’m fyi on speaker with my mom AND DAD all the time


**556.** `22:38` **You**

for example \- you told your 16 year old daughter\.\. you took a Plan B\.\. would you tell your parents that?


**557.** `22:38` **You**

lol


**558.** `22:38` **You**

pls say no


**559.** `22:38` **Meredith Lamb (+14169386001)**

I did not tell my parents that


**560.** `22:38` **Meredith Lamb (+14169386001)**

lol


**561.** `22:38` **You**

Reaction: 😂 from Meredith Lamb
just tell them I am a virgin\.


**562.** `22:38` **You**

there was a movie about me


**563.** `22:38` **You**

they can watch it


**564.** `22:38` **Meredith Lamb (+14169386001)**

But I told them stuff yday and my mom was pine TMI\!\!\!\!


**565.** `22:39` **You**

what stuff


**566.** `22:39` **You**

that you wished I had a mustache?


**567.** `22:41` **Meredith Lamb (+14169386001)**

>
No\. I love you the way you are\.

*💬 Reply*

**568.** `22:42` **Meredith Lamb (+14169386001)**

Apparently pascal is not going to win :\(


**569.** `22:42` **You**

ok what was the TMI


**570.** `22:51` **Meredith Lamb (+14169386001)**

Huh?


**571.** `22:51` **Meredith Lamb (+14169386001)**

Pascal just missed a 3


**572.** `22:51` **You**

>
this

*💬 Reply*

**573.** `22:51` **Meredith Lamb (+14169386001)**

Oh yeah


**574.** `22:51` **Meredith Lamb (+14169386001)**

lol


**575.** `22:52` **Meredith Lamb (+14169386001)**

I’m a bit too honest


**576.** `22:52` **You**

stark


**577.** `22:52` **You**

some might say


**578.** `22:52` **Meredith Lamb (+14169386001)**

Yeah


**579.** `22:52` **You**

ask your mum if that word works for you'


**580.** `22:52` **You**

she likes those words


**581.** `22:55` **Meredith Lamb (+14169386001)**

Pascal just missed 2 free shots


**582.** `22:55` **Meredith Lamb (+14169386001)**

Gah


**583.** `22:55` **You**

did he bleet?


**584.** `22:55` **Meredith Lamb (+14169386001)**

Bleet?


**585.** `22:58` **You**

Reaction: ❓ from Meredith Lamb
just ask your mom she would know\.\. every time he drives the lane\.\. he goes AHHHHHHHHHHHHHH whether he is touched or not lol\.


**586.** `22:58` **You**

i tried to make a drinking game out of it once


**587.** `22:59` **Meredith Lamb (+14169386001)**

Huh?


**588.** `23:01` **Meredith Lamb (+14169386001)**

I’m SO confused


**589.** `23:01` **Meredith Lamb (+14169386001)**

Is that fair?


**590.** `23:02` **You**

i mean it is kinda lame\.\. james harden does this stupid thing with his head to try to make it look like he gets hit every time he drives,\.


**591.** `23:05` **Meredith Lamb (+14169386001)**

Indiana won 111 to 110 with 110 seconds to go\!


**592.** `23:05` **You**

wow


**593.** `23:05` **Meredith Lamb (+14169386001)**

My mom is in shock


**594.** `23:05` **You**

lol


**595.** `23:05` **Meredith Lamb (+14169386001)**

I’m not watching lol


**596.** `23:05` **You**

bet she is excited


**597.** `23:05` **Meredith Lamb (+14169386001)**

Just getting the play by play


**598.** `23:05` **Meredith Lamb (+14169386001)**

Wait


**599.** `23:05` **Meredith Lamb (+14169386001)**

Game not done


**600.** `23:06` **Meredith Lamb (+14169386001)**

3 second to go\. My mom confused lol


**601.** `23:07` **You**

oh no\!\! lol


**602.** `23:08` **You**

https://www\.google\.com/search?q=pascal\+siakam\+makes\+a\+funny\+noise\+when\+trying\+to\+draw\+a\+foul&num=10&sca\_esv=d05be742535520f0&rlz=1C1ONGR\_enCA1104CA1104&tbas=0&sxsrf=AE3TifM5JKo6Uf0prY2e4d30\_17\-j9B6sQ:1749179185781&ei=MVtCaKq\_L\-CaptQP7LiomAI&start=10&sa=N&sstk=Ac65TH5hmEknQV\_AP7OvA8hbtwWATHkPUQZkc\_nfC8nUwtravcdqsj4cEqExL3xd4kF5iXwcOyITGZoLex8bS0A6H61zGsAkF\_\-TEA&ved=2ahUKEwjqm5Gg6NuNAxVgjYkEHWwcCiMQ8tMDegQIDRAG&biw=1920&bih=911&dpr=1\#fpstate=ive&vld=cid:e34516cc,vid:jUCK22X\_anM,st:0


**603.** `23:08` **You**

listen over and over between 2 and 3 seconds\.


**604.** `23:08` **You**

lol


**605.** `23:08` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Meredith Lamb
Indiana won


**606.** `23:08` **You**

and we all lived happily ever after


**607.** `23:09` **Meredith Lamb (+14169386001)**

lol


**608.** `23:09` **You**

hehe


**609.** `23:09` **You**

you hearted your own message


**610.** `23:09` **You**

LOL


**611.** `23:09` **Meredith Lamb (+14169386001)**

:\)


**612.** `23:09` **Meredith Lamb (+14169386001)**

I like 🏀


**613.** `23:09` **Meredith Lamb (+14169386001)**

But have no time to watch


**614.** `23:09` **You**

someday\.\.


**615.** `23:09` **You**

I enjoy it as well


**616.** `23:10` **Meredith Lamb (+14169386001)**

I made my grandpa a basketball cake   For his funeral at least :p


**617.** `23:10` **You**

eesh


**618.** `23:11` **You**

Holy Shit


**619.** `23:11` **You**

how did you pull that


**620.** `23:11` **Meredith Lamb (+14169386001)**

What do you mean eesh?


**621.** `23:11` **You**

>
This you were supposed to explain

*💬 Reply*

**622.** `23:11` **You**

I flew right by it


**623.** `23:11` **Meredith Lamb (+14169386001)**

My grandpa was a big ball coach in Oshawa


**624.** `23:12` **Meredith Lamb (+14169386001)**

One minute


**625.** `23:25` **Meredith Lamb (+14169386001)**

I cant find the cake I made for my grandpa’s
Funeral\. My mom ins yapping on and on about it now


**626.** `23:28` **Meredith Lamb (+14169386001)**

No response?


**627.** `23:29` **You**

I am waiting


**628.** `23:29` **Meredith Lamb (+14169386001)**

Or are you mean


**629.** `23:29` **Meredith Lamb (+14169386001)**

lol


**630.** `23:29` **You**

waiting


**631.** `23:29` **You**

patiently


**632.** `23:29` **You**

calmly


**633.** `23:29` **You**

Reaction: 😂 from Meredith Lamb
lovingly??? yeah


**634.** `23:29` **You**

but still waiting


**635.** `23:30` **Meredith Lamb (+14169386001)**

Off with my parent


**636.** `23:31` **Meredith Lamb (+14169386001)**

My mom goes “well if Scott comes I have a shrub I need dug up”


**637.** `23:31` **Meredith Lamb (+14169386001)**

lol


**638.** `23:31` **Meredith Lamb (+14169386001)**

I’ll like “I’ll talk to you tomorrow”


**639.** `23:31` **Meredith Lamb (+14169386001)**

LOL


**640.** `23:31` **Meredith Lamb (+14169386001)**

She is always all about the work


**641.** `23:33` **You**

I can dig up a shrub


**642.** `23:33` **You**

\.\.\.\. now DISH


**643.** `23:42` **You**

cmon MER\!\!


**644.** `23:42` **Meredith Lamb (+14169386001)**

I am do confused n


**645.** `23:42` **You**

don't do me like this\!\!


**646.** `23:42` **Meredith Lamb (+14169386001)**

And dealing with stupid teen s


**647.** `23:42` **Meredith Lamb (+14169386001)**

They don’t have enough towels after showers


**648.** `23:42` **Meredith Lamb (+14169386001)**

😱


**649.** `23:42` **You**

I have been waiting 15 minutes ROFL\!\!


**650.** `23:43` **Meredith Lamb (+14169386001)**

Fml


**651.** `23:43` **Meredith Lamb (+14169386001)**

Sorry towel emergency


**652.** `23:43` **Meredith Lamb (+14169386001)**

Mg


**653.** `23:43` **Meredith Lamb (+14169386001)**

Omg


**654.** `23:43` **Meredith Lamb (+14169386001)**

So annoyed


**655.** `23:44` **Meredith Lamb (+14169386001)**

So I can either 1\. Talk irl or 2\. Go to bed


**656.** `23:44` **Meredith Lamb (+14169386001)**

I’m like ……\.\.


**657.** `23:44` **Meredith Lamb (+14169386001)**

My mom wore me


**658.** `23:45` **Meredith Lamb (+14169386001)**

She is talented at that


**659.** `23:46` **You**

\.\.\.\.\. I am glad you got that sorted


**660.** `23:46` **Meredith Lamb (+14169386001)**

Soooooo


**661.** `23:47` **You**

So yeah\.\. I feel like you are messing with me\.\. and not going to tell me anything\.\.\.\.\. again\.\.\.\.\.


**662.** `23:48` **Meredith Lamb (+14169386001)**

What?


**663.** `23:48` **Meredith Lamb (+14169386001)**

No


**664.** `23:48` **Meredith Lamb (+14169386001)**

I just don’t know if you can talk


**665.** `23:48` **You**

what do you mean\.\. yeah it is safe


**666.** `23:48` **Meredith Lamb (+14169386001)**

If you willl be triggered


**667.** `23:48` **Meredith Lamb (+14169386001)**

lol


**668.** `23:49` **You**

:\(


**669.** `23:49` **You**

kk nm don't tell me


**670.** `23:50` **Meredith Lamb (+14169386001)**

Do you want to go to bed and tomorrow or talk tonight?


**671.** `23:50` **Meredith Lamb (+14169386001)**

I am good either way


**672.** `23:50` **Meredith Lamb (+14169386001)**

lol


**673.** `23:50` **You**

I am gonna go to bed I think\.


**674.** `23:50` **Meredith Lamb (+14169386001)**

Rosie is settled into bed


**675.** `23:50` **Meredith Lamb (+14169386001)**

lol


**676.** `23:51` **You**

I am just going to stop asking questions\.\. they are all dangerous\.


**677.** `23:51` **Meredith Lamb (+14169386001)**

>
Omg I am so confused

*💬 Reply*

**678.** `23:52` **You**

I asked about what you shared with your mom the TMI thinking it would be funny\.\. but you tell me I will be triggered\.\. like\.\.\.\.


**679.** `23:52` **Meredith Lamb (+14169386001)**

I was like we will talk tomorrow\. Everything is cool blah blah blah\.


**680.** `23:52` **You**

yeah bed time I think


**681.** `23:53` **Meredith Lamb (+14169386001)**

Oh my God say it’s kind of a in person conversation I mean OK on text\. How do I explain it?


**682.** `23:53` **You**

no


**683.** `23:53` **Meredith Lamb (+14169386001)**

I basically tell my mom a lot of the stuff to the extent where she is like OK too much


**684.** `23:53` **You**

you said if you explained it in person I would get triggered too\.\. no no\.\. pls\.\. don't explain\.


**685.** `23:53` **Meredith Lamb (+14169386001)**

So that is the baseline


**686.** `23:53` **You**

pls


**687.** `23:54` **Meredith Lamb (+14169386001)**

The baseline is TMI


**688.** `23:54` **Meredith Lamb (+14169386001)**

But I wouldn’t say I’ve told her everything obviously


**689.** `23:54` **Meredith Lamb (+14169386001)**

>
she is still my mother after all

*💬 Reply*

**690.** `23:55` **You**

ok honestly\.\. you don't need to explain\.\. again\.\. if you think I will be triggered I sincerely don't want to know\.\.


**691.** `23:55` **Meredith Lamb (+14169386001)**

>
I don’t want you to hav me anxiety or stress or over me

*💬 Reply*

**692.** `23:56` **Meredith Lamb (+14169386001)**

>
You won’t be at all\.

*💬 Reply*

**693.** `23:57` **You**

I am so afraid to just tell you to call me and tell me\.\. because first you said I would be triggered now you are saying I won't\.\.\.\.\.\.\.\.\.


**694.** `23:57` **You**

Reaction: 😂 from Meredith Lamb
🤮🤮🤮🤮


**695.** `23:57` **Meredith Lamb (+14169386001)**

Sorry lol


**696.** `23:58` **Meredith Lamb (+14169386001)**

\(My mom was a mean girl\. I wasn’t\.\)


**697.** `23:58` **You**

I don't understand what that means?


**698.** `23:59` **Meredith Lamb (+14169386001)**

I’m my


**699.** `23:59` **Meredith Lamb (+14169386001)**

Omg


**700.** `23:59` **Meredith Lamb (+14169386001)**

Typo


