# Daily Conversation: 2025-06-16 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-16 |
| **Day** | Monday |
| **Week** | 10 |
| **Messages** | 297 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-16T04:10 - 2025-06-16T22:07 |

## 📝 Daily Summary

This day contains **297 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:10` **You**

Reaction: ❤️ from Meredith Lamb
Morning mer\.\. well not for a bit yet for you\.  Hope you had a good sleep I know it was a busy day for you yesterday\.  ❤️❤️❤️


**002.** `04:12` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 16 Jun 2025 04:50:45 \-0400
|
| I will be doing the usual this week\.\. gym and then my rock by the water but will only be staying until 8:45 so as to get home to Maddie\.  I know you have busy days so would be happy to run into you but all good if not ☺️
|
| Version: 1
| Sent: Mon, 16 Jun 2025 04:12:53 \-0400
|
| I will be doing the usual this week\.\. gym and the\. My rock but will only be staying until 8:30 so as to get home to Maddie\.  I know you have busy days so would be happy to run into you but all good if not ☺️


**003.** `04:14` **You**

Looking forward to another milestone this week of meeting your mum\.\. have to say a lot more nervous than I initially expected\.\. really hope she can see a fraction of what you see in me\.


**004.** `04:15` **You**

Reaction: 😮 from Meredith Lamb
Last thing, I had like a mental break last night for real, forgot the code to my phone and iPad\.\. they almost both got erased, I was on my last password chance \(hour wait and then nothing\) if I got wrong and thankfully I guessed right\.\. guess life is just starting to wear me down a bit more than I thought\. lol\.


**005.** `04:19` **You**

Alright luv best of luck with your workout\.  Reading the ai stuff and based I how still feel and with an extremely high likelihood always will feel, I love you more than anything and feel so lucky that this isn’t a passing thing, but a real future we both seem to want to work together to make happen\. Not enough X’s and O’s to do this justice\.


**006.** `04:19` **You**

❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️


**007.** `05:42` **Meredith Lamb (+14169386001)**

>
I don’t think I got up early enough today\.  Tomorrow???

*💬 Reply*

**008.** `05:43` **You**

Perhaps i have to bring Maddies art project in tomorrow I learned this morning\.
Don’t worry bout it


**009.** `05:43` **You**

Have a good workout\!


**010.** `05:45` **Meredith Lamb (+14169386001)**

Reaction: 😟 from Scott Hicks
>
I’m nervous too but only because my mom is old and not really her true self anymore\. My dad is the same but my mom has a bit of dementia or Alzheimer’s for sure\. She was a bit odd at dinner\. Also, she had to take a walker throughout the mall\! She would never have done that in the past\. I’m glad she did but she is just different

*💬 Reply*

**011.** `05:47` **Meredith Lamb (+14169386001)**

>
K well let me see how long I take\.  I might take 6\-7, then get ready until 7\.30 so I could maybe be there at 8 but like no earlier\.

*💬 Reply*

**012.** `05:48` **You**

Don’t worry about it mer\.\. doesnt have to work out every time\.


**013.** `05:53` **Meredith Lamb (+14169386001)**

T might\.


**014.** `05:53` **Meredith Lamb (+14169386001)**

\*it


**015.** `05:54` **Meredith Lamb (+14169386001)**

I got new workout leggings yday from Victoria’s Secret without trying on\. Omg they are the most comfortable ones I’ve ever worn\.


**016.** `05:54` **Meredith Lamb (+14169386001)**

Not sure whether to tell Mac or she will make me buy her some


**017.** `05:54` **Meredith Lamb (+14169386001)**

10x better than lulu, etc etc


**018.** `05:55` **You**

lol glad you enjoy them\.\. I
Left my leggings at home\.\. leg day and I didn’t want to ruin them


**019.** `05:59` **Meredith Lamb (+14169386001)**

Har


**020.** `06:20` **You**

Leg status shots not nearly as satisfying\.\. still apparently Henry has em so I need to as well\.

*📎 1 attachment(s)*

**021.** `06:20` **You**


*📎 1 attachment(s)*

**022.** `06:20` **You**

Workout done have fun with the rest of yours


**023.** `06:24` **Meredith Lamb (+14169386001)**

Geez you are a machine\. I cannot keep up with YOU


**024.** `06:26` **You**

I just had a head start yku will blow by me\.


**025.** `06:26` **You**

And my situation motivates me to be out of the house and doing anything else\.\. ok shower shave etc cya\.


**026.** `07:02` **Meredith Lamb (+14169386001)**

Are you still going? If so I will get ready and out of here by 7\.30


**027.** `07:02` **You**

I am leaving in 5


**028.** `07:02` **You**

It you don’t have to


**029.** `07:02` **You**

But


**030.** `07:02` **You**

It’s fine take your morning don’t rush


**031.** `07:02` **Meredith Lamb (+14169386001)**

I know I don’t HAVE to


**032.** `07:02` **You**

We can see each other Saturday\.


**033.** `07:02` **Meredith Lamb (+14169386001)**

But I can so…


**034.** `07:03` **Meredith Lamb (+14169386001)**

If you are there I will


**035.** `07:03` **Meredith Lamb (+14169386001)**

If not I won’t


**036.** `07:03` **You**

Up to you\. I don’t want to pressure


**037.** `07:03` **You**

I will be there on my rock likely


**038.** `07:03` **Meredith Lamb (+14169386001)**

k getting ready then


**039.** `07:04` **You**

Ok cya soon


**040.** `07:26` **Meredith Lamb (+14169386001)**

Just did my make up in 3 minutes to get out of here lol


**041.** `07:28` **You**

lol who needs makeup\.\. you sure don’t


**042.** `08:57` **Meredith Lamb (+14169386001)**

How does it just get better seeing you?


**043.** `09:10` **Meredith Lamb (+14169386001)**

Definitely feeling stronger but can’t get my elbows back yet still\. Lol

*📎 1 attachment(s)*

**044.** `09:13` **You**

>
I don’t know but it always makes me feel better\.\. even if I know we won’t see each other till Sat this was worth it\.\.  thank you for figuring out a way to come today\.

*💬 Reply*

**045.** `09:13` **You**

>
The difference is real though you are def making progress\!

*💬 Reply*

**046.** `09:14` **You**

I basically let j know sat would be another me day\.\.


**047.** `09:14` **You**

She just wants the kids to be able to connect in case of energy I said they could but I am not responding to any bs\.


**048.** `09:15` **You**

Didnt get to doctor they were still closed will try
Tomorrow


**049.** `09:31` **Meredith Lamb (+14169386001)**

>
lol “to any bs”

*💬 Reply*

**050.** `09:36` **Meredith Lamb (+14169386001)**

Jim was telling me about all his upcoming weekends\. I was like “know what I’m doing next weekend?” Lol I think he was surprised I was introducing you to my parents


**051.** `09:41` **You**

>
bs like tv is too loud or stupid shit \- i told Jaimie they are fucking 16\-18 they can figure shit out\.

*💬 Reply*

**052.** `09:41` **You**

>
tbh Mer I don't think Jim actually approves of us\. Definitely not the pace\.

*💬 Reply*

**053.** `09:45` **You**

and i think he sees me as the problem lol just a feeling


**054.** `09:48` **Meredith Lamb (+14169386001)**

>
Yeah I know but I think it is partially because he doesn’t fully know me\. He knows work me\. And yeah, pace is definitely a thing\. I can tell\. Honestly don’t really care\. He is so respectful that he goes with it\. He knows not to overstep and just support and that is what true friends do even if they don’t fully agree with the approach

*💬 Reply*

**055.** `09:48` **Meredith Lamb (+14169386001)**

>
You are not a problem omg 😂

*💬 Reply*

**056.** `09:49` **You**

>
listen I am just making observations \- not internalizing any of this\.

*💬 Reply*

**057.** `09:52` **Meredith Lamb (+14169386001)**

I don’t think he is going to be the only one who won’t really understand this\. I mean we don’t really either so……\.\. natural I think


**058.** `09:53` **You**

>
I mean I think I understand this\.\. I have put a lot of effort into it though lol\.

*💬 Reply*

**059.** `09:54` **Meredith Lamb (+14169386001)**

Touché


**060.** `09:54` **Meredith Lamb (+14169386001)**

lol


**061.** `09:56` **You**

I actually understand what I want more now than I ever have\.\. I have a better sense of how to get there\.\. I am not putting in place any specific firm plans\.\. just directional\.\. my only problem is patience\.\. and wanting to see you\.\. which are kind of the same\.


**062.** `09:56` **You**

I am more comfortable with where stand in your life, and understand where you stand in mine and what you mean to me\.\. so yeah I feel like I "get it"\.


**063.** `09:57` **You**

🤔


**064.** `09:58` **Meredith Lamb (+14169386001)**

I guess I am the same…\.I get it so to speak but am “surprised” maybe is a better word at the pace of it all\. Surprised but not upset about it\. 😋


**065.** `10:01` **You**

Reaction: ❤️ from Meredith Lamb
I am too\.\. really surprised\.\. but I know why\.\. I think we are both smart, we were both unhappy, we both liked each other in general\.\. and both maybe a little more than liked\.  We did come together at a time when we could explore more about each other beyond just mutual support\.  We both don't have time for BS, we both have busy lives, we both are passionate and feel strongly even though we show it differently, we are both at a similar point in our lives, and we have both been wide open with everything because we had a feeling that something big was happening, and that to make sure it actually was what we thought, we kind had to dive in\.


**066.** `10:03` **You**

Since we became more than\.\. we have had ups and downs on both sides, we have supported each other and picked each other up, we have worked through shit together and on our own, and it is clear we are willing to put work in, and make sacrifices for each other\.  We each have a tremendous amount of respect, and affection for the other, we each see this lasting, and want it to last\.  And I feel something I have never felt before\.\. so I don't want to slow down\.\. but I am willing to try to pace a bit, as best I can\.


**067.** `10:08` **Meredith Lamb (+14169386001)**

I think we are doing well pace\-wise\. It feels like things have settled A LITTLE lol but I love everything about you and part of that is your lack of patience with us\. I have it too but am not as active about it planning wise as you lol you def make things happen 🙂


**068.** `10:09` **You**

>
I think everyone has a role to play in a relationship\.\. we all don't play all roles\.\. and really you have a lot more going on in your life than I do, it doesn't bother me to be the one to push\.

*💬 Reply*

**069.** `10:15` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Good 😊 once I get better at push ups I’ll push more 😜


**070.** `10:27` **Meredith Lamb (+14169386001)**

>
Just going back to this for a second\. You know that around work you have always been this reliable person who is unhappy with his life for the last few years\. Though people don’t want that to be your reality, it does make them feel better about their own lives by comparison\. It is going to be hard for some people to see you so happy and potentially moving into a happier situation than even they have\. Human nature\. I think there is an element of this there with Jim\.

*💬 Reply*

**071.** `10:28` **Meredith Lamb (+14169386001)**

And I think there will be once other people find out also\. People that are so used to you being the unhappy one in your relationship\.


**072.** `10:29` **You**

>
I mean that is an interesting way to look at it, I just figured people would like Happy Scott a whole lot more\.  Jim included\.  He might just be being cautious etc though\.

*💬 Reply*

**073.** `10:39` **Meredith Lamb (+14169386001)**

I know his relationship with Christine is solid but it is also old and long so they have a lot of staleness that they try to spark themselves right\. Common\. So regardless of whether someone says it or not, there is always a level of jealousy when people are in something “new”\. There is some of that with Jim so I honestly haven’t been telling him much about that side of things bc I don’t want to rub anything in anyone’s face\. When ai says this is rare, IT IS…\. people know that


**074.** `10:50` **You**

you mean the fact that we found each other is rare\.\. I think so\.\. I really hope he doesn't feel that way\.\. I like Jim\.\. I don't like feeling like he doesn't approve, I had hoped he would just be happy and supportive :\(  I think you know more than I because you talk to him more\.


**075.** `10:52` **Meredith Lamb (+14169386001)**

He IS happy and supportive\. But he is also human\. So he can feels more than those things


**076.** `10:54` **You**

yeah\.\.\. still I want to share things with him, but don't really feel comfortable anymore\.\. more like feel judged\.\. so I am quiet for the most part\.\. not what I expected or hoped for tbh\.\. he might judge me more harshly because I am a manager?? dunno


**077.** `10:57` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Just give him some time to adjust to the whole thing\. I think it was a lot for him to process and I think he is still processing it\.
He’s a judgey guy\. I hear him talk about his friends snd fam and it is always judgey\. But he is not ill intentioned\.


**078.** `10:58` **You**

Refer back to my patience meditation this morning lol


**079.** `11:24` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
My childhood home in Glencoe\. This is from the last day there when we were driving away\. Just came across it in my photos looking for something else\.

*📎 1 attachment(s)*

**080.** `11:24` **You**

bittersweet\.\. :\(


**081.** `11:25` **You**

I can remember when I sold our home while Dad was in the hospital, and had it cleaned out\.\.  had a bit of a moment\.\. when everything was out and I was locking up for the last time\.\. 18 years or so in that house for me\.\. was tough seeing it go to someone else\.


**082.** `11:31` **Meredith Lamb (+14169386001)**

Yeah same\. The last night I slept in my room on the floor with no mattress lol so uncomfortable… dumb


**083.** `11:32` **You**

>
did you cry when you left?

*💬 Reply*

**084.** `11:32` **Meredith Lamb (+14169386001)**

Omg no


**085.** `11:32` **You**

GAWD


**086.** `11:32` **Meredith Lamb (+14169386001)**

My dad and I drove back to Oshawa


**087.** `11:32` **You**

I am such a sensitive SAP\!\!


**088.** `11:32` **Meredith Lamb (+14169386001)**

I’m not going to cry in front of my dad


**089.** `11:32` **Meredith Lamb (+14169386001)**

We were both very quiet for a while tho


**090.** `11:32` **You**

oh I hate crying in front of people\.\.


**091.** `11:33` **You**

doesn't happen often


**092.** `11:33` **You**

so I go and hide


**093.** `11:33` **Meredith Lamb (+14169386001)**

lol


**094.** `11:33` **You**

true story\.\.


**095.** `11:33` **Meredith Lamb (+14169386001)**

I won’t make fun of you if u cry in front of me


**096.** `11:33` **Meredith Lamb (+14169386001)**

Promise


**097.** `11:33` **You**

Reaction: 😢 from Meredith Lamb
Locked myself in hospital bathroom when family members died \- all of them actually


**098.** `11:33` **You**

>
yes you will\.\. a little bit\.\. and with good nature\.\. I am sure of it

*💬 Reply*

**099.** `11:33` **You**

lol'


**100.** `11:34` **You**

that sad little voice you use\.\.


**101.** `11:34` **Meredith Lamb (+14169386001)**

lol I can be very insensitive


**102.** `11:35` **You**

chat gpt and notebook lm believe so\.\. :\)


**103.** `11:36` **You**

You are Tom Hanks in a league of their own\.\. "There's no crying in baseball\!"


**104.** `11:38` **Meredith Lamb (+14169386001)**

Good movie :\)


**105.** `11:38` **You**

yep great movie\.\.


**106.** `11:39` **You**

pretty sure I crushed on geena davis when I was younger\.


**107.** `11:45` **Meredith Lamb (+14169386001)**

Noooo Madonna


**108.** `11:54` **You**

Nope Geena……


**109.** `12:49` **You**

would rather be back on the rock this morning\.\.\. soooo bored\.\. catching up all training\.\. shoot me\.


**110.** `13:52` **Meredith Lamb (+14169386001)**

lol omg me too \- actually not on a rock, somewhere more comfy


**111.** `13:53` **You**

well I would take the rock right now\.  this week is going to be SOOOOO boring\.\. I am going to have to go back to building with AI to keep my sanity\.


**112.** `13:53` **Meredith Lamb (+14169386001)**

So when I was in the washroom I got freaked out by someone who looked like Jaimie


**113.** `13:53` **You**

rofl


**114.** `13:53` **Meredith Lamb (+14169386001)**

Not kidding


**115.** `13:53` **Meredith Lamb (+14169386001)**

I can hardly remember what she looks like so it was hard to tell


**116.** `13:53` **You**

run away\!\!


**117.** `13:54` **You**

that sucks honestly\.\. I can see how that might be a bit disconcerting\.


**118.** `13:56` **Meredith Lamb (+14169386001)**

lol I did not run away


**119.** `13:56` **Meredith Lamb (+14169386001)**

I figured it was not her bc she would have yelled at me \(or texted you\)


**120.** `13:56` **You**

yeah I heard nothing


**121.** `13:58` **You**

what are your plans tonight btw you got vball?


**122.** `13:58` **Meredith Lamb (+14169386001)**

I’m going to Fairview to get something to wear to graduations :p


**123.** `13:59` **Meredith Lamb (+14169386001)**

No volleyball


**124.** `13:59` **You**

oooh


**125.** `13:59` **You**

exciting


**126.** `13:59` **Meredith Lamb (+14169386001)**

Andrew taking Marlowe


**127.** `13:59` **Meredith Lamb (+14169386001)**

Not exciting no


**128.** `13:59` **Meredith Lamb (+14169386001)**

Hate


**129.** `13:59` **You**

do you try everything on in the store?


**130.** `13:59` **Meredith Lamb (+14169386001)**

Omg no


**131.** `13:59` **Meredith Lamb (+14169386001)**

I hate shopping


**132.** `13:59` **You**

LOL


**133.** `13:59` **Meredith Lamb (+14169386001)**

But I have TWO grads this week back to back\. Gahhh


**134.** `14:01` **You**

omg two outfits


**135.** `14:01` **You**

and an afterparty outfit for Thursday


**136.** `14:01` **You**

\!\!\!\!


**137.** `14:01` **Meredith Lamb (+14169386001)**

Unlikely


**138.** `14:01` **Meredith Lamb (+14169386001)**

I am not going to the after party lol


**139.** `14:02` **You**

rofl I bet there will be wine there\.\. and big hot single dad's\!\!


**140.** `14:03` **Meredith Lamb (+14169386001)**

:p Allenby dads\. No thanks\.


**141.** `14:03` **Meredith Lamb (+14169386001)**

It will be all couples\.


**142.** `14:03` **Meredith Lamb (+14169386001)**

Guaranteed


**143.** `14:03` **Meredith Lamb (+14169386001)**

And ones I don’t want to talk to


**144.** `14:04` **You**

You and Andrew then? You don't have to hold hands


**145.** `14:04` **Meredith Lamb (+14169386001)**

lol


**146.** `14:04` **You**

lol


**147.** `14:04` **Meredith Lamb (+14169386001)**

No


**148.** `14:04` **Meredith Lamb (+14169386001)**

I don’t want to talk to any of those ppl


**149.** `14:04` **You**

>
well I can relate\.\. :\)

*💬 Reply*

**150.** `14:04` **You**

I don'ty like talking to most people


**151.** `14:05` **Meredith Lamb (+14169386001)**

Well you have to find “your ppl” and I have 6 moms I talk to regularly from this group\. Don’t care about the other 85\.


**152.** `14:05` **Meredith Lamb (+14169386001)**

:p


**153.** `14:05` **Meredith Lamb (+14169386001)**

Snobby


**154.** `14:05` **You**

>
I don't even find people\.\. most people suck, so I just avoid\.\. unless I can't then I fake\.

*💬 Reply*

**155.** `14:06` **Meredith Lamb (+14169386001)**

I agree that most people suck but there are always exceptions


**156.** `14:07` **You**

>
I mean it is too easy Mer\.\. not even gonna\.\. ❤️

*💬 Reply*

**157.** `14:08` **Meredith Lamb (+14169386001)**

lol


**158.** `14:59` **You**

OMG it is DONE\!\!\!\! I am all up to date\!\!\!


**159.** `15:14` **Meredith Lamb (+14169386001)**

I’m not :\(


**160.** `15:44` **You**

Well I am\. Just have to run and take maddie to ortho appt and then dentist appointment fun times…\.\. might go back to gym tonight and do core\.\. really not much to do here and the days are fucking long\.\.


**161.** `15:59` **Meredith Lamb (+14169386001)**

Oh boy, the things we could do…… :\(


**162.** `16:07` **You**

Yeah stop I don’t need to think about that\.\. how you think that’ll work o\. Sat if that is all you or I think about\.\. prolly not good for either of us\.


**163.** `16:08` **You**

Think I am just going to do doubles all week ironically this week will be worse than the last just because of how boring it will be lol


**164.** `16:13` **Meredith Lamb (+14169386001)**

Nothing you can do to be less bored???


**165.** `16:25` **You**

nope not really\.\. honestly\.\. unless I just do chores and shit\.\. yeah I guess\.\.  clean the house repeatedly\.\.


**166.** `16:25` **You**

Reaction: 😂 from Meredith Lamb
that was dumn\.\. the appt wasn't until next year lol\.\. J read the sheet wrong\.


**167.** `16:25` **You**

meh


**168.** `16:32` **You**

maybe go out and just drive around\.\. find a pub get a drink and some food maybe\.\. then go to gym\.\. dunno\.\. anything to get out of here\.


**169.** `16:33` **You**

I will figure something out\.


**170.** `16:40` **Meredith Lamb (+14169386001)**

I’m at the mall lol


**171.** `16:40` **You**

Yeah I fugured you were shopping now


**172.** `16:48` **Meredith Lamb (+14169386001)**

I would go out to eat with you but I feel like I’d screw something up with the fam, suspicions


**173.** `17:08` **You**

I appreciate that but as much as I would love that you have your own stuff to do tonight\.\. there wouldn’t be sus here they know I hate being here right now


**174.** `17:08` **You**

No secret there


**175.** `17:12` **You**

Sok mer I will head out in a bit and find something


**176.** `17:27` **Meredith Lamb (+14169386001)**

I don’t like you being bored :\(


**177.** `17:27` **You**

that's my problem\.\. I will fix it shortly\.


**178.** `17:31` **You**

hmm there is a restaurant down right next to a pool hall\.\. that could keep me busy for a few hours\.


**179.** `17:32` **Meredith Lamb (+14169386001)**

I was going to say “or you can just drive here” but I would likely get into trouble lol


**180.** `17:32` **You**

I don't know where here is anyways\.\.  you mean you are still at the mall?


**181.** `17:33` **Meredith Lamb (+14169386001)**

Yup just looking around lol\. I have no kids and it is lovely


**182.** `17:34` **You**

Reaction: 😢 from Meredith Lamb
Yeah you probably would get into trouble \- not worth risking anything like that for you to get in shit\.


**183.** `17:35` **You**

ok well you have fun I am going to go figure something out\.\.\.


**184.** `17:35` **Meredith Lamb (+14169386001)**

Okay


**185.** `17:36` **You**

Mer I would come see you in a second\.\. obviously but not if it gets you in trouble\.\. you can't fix everything hun\.


**186.** `17:36` **Meredith Lamb (+14169386001)**

I know I know


**187.** `17:37` **You**

meh w/e left over steak\.\. will make some wraps\.\. eat down here in basement\.\. and then just go to gym and stay there until 10 or something\.


**188.** `17:37` **You**

go have fun


**189.** `17:38` **Meredith Lamb (+14169386001)**

This is EXACTLY why I don’t like that my family doesn’t know\. This exact situation\.


**190.** `17:39` **You**

Why


**191.** `17:39` **You**

I don’t see how that would help


**192.** `17:39` **Meredith Lamb (+14169386001)**

Bc if they knew I could do whatever I wanted


**193.** `17:40` **You**

Yeah but not a good idea at all


**194.** `17:40` **Meredith Lamb (+14169386001)**

But otherwise I have to come up with stories


**195.** `17:40` **You**

So just let it be it’s my problem


**196.** `17:40` **Meredith Lamb (+14169386001)**

And there is no story


**197.** `17:40` **You**

Saturday\.\. we got that at least just be a long way to get there


**198.** `17:44` **Meredith Lamb (+14169386001)**

Exactly\. So long and another story lol


**199.** `17:45` **You**

Yep it is what it is\.  Timing is shit


**200.** `17:45` **You**

I know don’t like the secrets I haven’t booked it yet we don’t have to do it


**201.** `17:49` **You**

just go soothe your sadness by spedning a bunch of money


**202.** `17:50` **Meredith Lamb (+14169386001)**

Buying new sandals for grad lol


**203.** `17:51` **You**

>
dont skip\.\. this is doable\.\.\. and won't bother me

*💬 Reply*

**204.** `17:51` **You**

I don't like how it makes you feel\.\.


**205.** `17:53` **Meredith Lamb (+14169386001)**

It’s okay I am okay with it\. Just looking forward to a world that is more honest


**206.** `17:54` **You**

>
yep I get it\.  Cya after Sept 15th lol

*💬 Reply*

**207.** `17:54` **Meredith Lamb (+14169386001)**

Grrrrrr


**208.** `17:54` **You**

here is something interesting


**209.** `17:54` **You**

I think I might have several weeks alone in late july through most of august


**210.** `17:56` **Meredith Lamb (+14169386001)**

Whoah


**211.** `17:56` **You**

anyhow that is so far away\.\. it doesn't matter much lol


**212.** `17:57` **Meredith Lamb (+14169386001)**

It is that far away really but kind of


**213.** `17:57` **You**

did you mean isn't


**214.** `17:58` **Meredith Lamb (+14169386001)**

Yes lol


**215.** `17:59` **You**

everything seems far away\.\. and I am going to start focusing back on work next week\. but I do need to find some filler I cannot just smash the gym twice a day\.\. and I can't sit here and watch tv\.\. I will get work sorted\.\. then I will have to figure out that next\.


**216.** `18:00` **Meredith Lamb (+14169386001)**

I know, I just wish we could do the filler thing together but whateverrrrerre


**217.** `18:01` **You**

I'm sorry I wish we could\.\. but I am not sure I can keep this up\.\.every night\.\. so I gotta get out and do something\.\. again\.\. I will figure something out\.\. and run it by you\.\. I know you worry\.


**218.** `18:03` **You**

gpt and notebooklm also said when you do this "whateverrrrerre " you are frustrated or mad\.


**219.** `18:03` **You**

just sharing


**220.** `18:03` **You**

lol


**221.** `18:03` **You**

I mean as long as I don't overdo it gym's not so bad plenty of people to talk to a lot more know me now\.


**222.** `18:05` **Meredith Lamb (+14169386001)**

I’m not mad\.


**223.** `18:06` **You**

so then the other thing


**224.** `18:07` **Meredith Lamb (+14169386001)**

lol of course\. So are you


**225.** `18:08` **You**

yeah\.\. it is just this fucking catch 22 thing\.\.


**226.** `18:08` **You**

nm\.\.  maybe I just need to meditate more\.\. or go to sleep earlier\.\.


**227.** `18:10` **Meredith Lamb (+14169386001)**

Mediator reached out to book a meeting\.


**228.** `18:10` **Meredith Lamb (+14169386001)**

Weird


**229.** `18:10` **Meredith Lamb (+14169386001)**

Why not send the docs first


**230.** `18:11` **Meredith Lamb (+14169386001)**

Ugh


**231.** `18:11` **You**

what docs\.\.


**232.** `18:11` **Meredith Lamb (+14169386001)**

Scenarios


**233.** `18:11` **You**

you mean the first draft?


**234.** `18:11` **You**

she probably wants to walk you through so you understand the nuances\.


**235.** `18:11` **You**

and it is likely that the scenarios would mostly mean that Andrew has to do something major


**236.** `18:12` **You**

so she won't want you reacting on your own


**237.** `18:13` **Meredith Lamb (+14169386001)**

Guess we will see


**238.** `18:13` **You**

how far out is it


**239.** `18:13` **You**

July? :P


**240.** `18:20` **You**

kk you probably driving or busy\.\. we can chat later\.\.


**241.** `18:25` **Meredith Lamb (+14169386001)**

I’m not home yet so we will likely have to book together unless he has already booked


**242.** `18:26` **Meredith Lamb (+14169386001)**

He requested this week


**243.** `18:27` **You**

Mmmm you both booking at same time I don’t want to even hear about that\.


**244.** `18:28` **Meredith Lamb (+14169386001)**

He’s going to see if he can move meetings on Thurs … if so, thurs


**245.** `18:30` **You**

Fack…


**246.** `18:30` **Meredith Lamb (+14169386001)**

Isn’t that a good thing?


**247.** `18:30` **Meredith Lamb (+14169386001)**

It is to me


**248.** `18:30` **You**

Well depends on how it goes


**249.** `18:30` **Meredith Lamb (+14169386001)**

It’s a two hour appointment though


**250.** `18:30` **Meredith Lamb (+14169386001)**

I have Thursday off so it works


**251.** `18:30` **You**

Yeah that is going to be a big discussion


**252.** `18:32` **Meredith Lamb (+14169386001)**

OK, I think I’m gonna go home getting tired lol


**253.** `18:32` **You**

Well good luck I am sure there are going to be many conversations between now and Thursday


**254.** `18:33` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**255.** `18:33` **Meredith Lamb (+14169386001)**

Spoke too soon\. Distracted


**256.** `18:33` **Meredith Lamb (+14169386001)**

lol


**257.** `18:33` **You**

Kk I am heading out shortly so maybe we connect later\.


**258.** `18:33` **Meredith Lamb (+14169386001)**

ok 👍


**259.** `19:21` **You**

Bah delayed getting out fucking Gracie and j got into it\.\. fak I need out of here I should have let her keep house not move and I would be gone by now\.


**260.** `19:21` **You**

Hope your drive home was uneventful


**261.** `19:23` **Meredith Lamb (+14169386001)**

>
Over living with you?

*💬 Reply*

**262.** `19:23` **Meredith Lamb (+14169386001)**

Just got home


**263.** `19:25` **You**

>
??

*💬 Reply*

**264.** `19:26` **You**

I would have at least been out in my own apt\.


**265.** `19:26` **You**

Could get some fucking peace\.


**266.** `19:27` **You**

>
Sorry didnt know what you meant

*💬 Reply*

**267.** `19:28` **Meredith Lamb (+14169386001)**

Like was the fight about you not letting her live with you


**268.** `19:28` **You**

No just Gracie being stupid


**269.** `19:29` **Meredith Lamb (+14169386001)**

lol oh


**270.** `19:30` **Meredith Lamb (+14169386001)**

Mac approves my new sandals\. Phew


**271.** `19:30` **You**

Gonna see how long I can stay in sauna to tonight


**272.** `19:30` **You**

>
Congrats

*💬 Reply*

**273.** `19:30` **Meredith Lamb (+14169386001)**

Big accomplishment


**274.** `20:33` **Meredith Lamb (+14169386001)**

Ugh Andrew is saying he may not be able to clear meetings so we may have to wait until Monday\. Godddddddd


**275.** `20:37` **You**

Rofl so surprised


**276.** `20:37` **You**

Sry to hear that sucks


**277.** `20:38` **You**

But not surprised at same time


**278.** `20:38` **Meredith Lamb (+14169386001)**

I’m not surprised either\. I told him to please try\. Sigh


**279.** `20:39` **Meredith Lamb (+14169386001)**

He said he’s been booking off too much personal time for volleyball so his doesn’t want his EA to see him booking off 2 hrs for personal reasons


**280.** `20:39` **Meredith Lamb (+14169386001)**

I’m like wtf


**281.** `20:39` **Meredith Lamb (+14169386001)**

So annoyed


**282.** `20:40` **You**

Priorities


**283.** `20:40` **You**

Complains it isn’t fast enough causes all delays


**284.** `20:40` **Meredith Lamb (+14169386001)**

I know


**285.** `20:40` **You**

Then when it comes time to make a decision he will pressure the fuck out of you to hurry up


**286.** `20:40` **You**

Sigh


**287.** `20:40` **Meredith Lamb (+14169386001)**

Yup


**288.** `20:41` **You**

Sept 15


**289.** `20:41` **You**

Reaction: 😢 from Meredith Lamb
Going home going to bed\.\. start of day amazing\.\. rest shit


**290.** `20:48` **Meredith Lamb (+14169386001)**

I’m sorry today was crappy\. I love you and wish you were coming home to me\. All would be better\. xo


**291.** `20:49` **You**

Every day is crappy when I am not doing that\.\.


**292.** `20:50` **You**

I love you too\.\. and me making friends isn’t going to help shit I just think it is\.\. I just want to be with you\.\. everything else after that is just secondary


**293.** `20:52` **Meredith Lamb (+14169386001)**

I know, same\. You probably don’t believe me but it is true\.


**294.** `20:55` **You**

No mer it isn’t that I don’t believe you but we express differently is all\.


**295.** `21:08` **Meredith Lamb (+14169386001)**

Sorry was looking back at your photo haha I’m going back to watching better sisters now\. Second last episode


**296.** `21:08` **You**

Kk have fun I am getting in bed\.\. night xo


**297.** `22:07` **Meredith Lamb (+14169386001)**

Nite ❤️❤️


