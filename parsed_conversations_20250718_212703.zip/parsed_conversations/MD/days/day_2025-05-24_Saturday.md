# Daily Conversation: 2025-05-24 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-24 |
| **Day** | Saturday |
| **Week** | 6 |
| **Messages** | 417 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-24T00:21 - 2025-05-24T23:24 |

## 📝 Daily Summary

This day contains **417 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:21` **You**

……\.


**002.** `04:20` **Meredith Lamb (+14169386001)**

…\.\. woke up on the sofa in the office … have zero recollection \(maybe 3%\) of falling asleep …\. Wow, Mac’s gummies \(a bite, literally\) are insane\.


**003.** `04:56` **You**

Getting up and going to gym\.


**004.** `05:09` **You**

Woke up on bed in basement \.\. 100% recollection of falling asleep\.\. and I can confirm the gummies are insane\.  I love you\. I hope you had an uneventful evening after you kind of flamed out\.


**005.** `05:44` **You**

While last night was quite messed I did appreciate you sending this\.\. looked at it most of the night ❤️

*💬 Reply*

**006.** `06:05` **You**

I wouldn’t mind having a conversation a bit later about a couple things that popped into my mind last night about us\.\. maybe talk about some things you need to get through this easier and some things I need\.  Not saying we cannot just suggesting we might be able to make it easier\.  I still love you to death I still see us growing old\-er together all of that I want it all\. But I feel the next two months will be brutal\.  And btw you don’t need to worry about Gracie I am certain nothing like what you are worried about has entered her mind ever\.


**007.** `06:09` **You**

Because I already feel we are in a relationship at least that is the way I am treating this\. I have already made a commitment to you, and that is all I want\. I am not looking for short cuts or easy paths, I will never back slide, or give up\. There is no alternative for me but moving forward with you\. I think once you the agreement is done you will be fine\.\. same here\.\. and until then please be patient with the constant reassurances because I think with no contact this is going to be like that for now at least\.\. perhaps on both our parts\.


**008.** `06:30` **You**

Sorry for all the deep thoughts I have a lot time on my hands at night and in the mornings\.  I will be distracted today\.\. so that should be fine\.  But again just a lot going through head to try to think about and try to resolve\.\. or just accept that it won’t be resolved\.


**009.** `06:35` **You**

So maybe just consider this a one way conversation that you can just take your time with throughout the day or whenever you feel like responding\.  And if you did want to engage on this later I can tell you you a bit more about what I am feeling\.  If not just don’t raise it and we can let it go\.


**010.** `06:41` **You**

Also read back through last night from the time you told me ur mom was going to whip
Me into shape\.\. worth a read over\.


**011.** `06:41` **You**

Lots
Of questions for
You some that mac might need to confirm


**012.** `06:51` **You**

https://open\.spotify\.com/track/1Cj2vqUwlJVG27gJrun92y?si=14uJcGkGTqGFv0zFR2KszA&context=spotify%3Asearch%3Asound%2Bof%2Bsilenxe


**013.** `06:57` **You**

Great morning mix coming in on
My favourites lol


**014.** `06:57` **You**

https://open\.spotify\.com/track/70LcF31zb1H0PyJoS1Sx1r?si=CeezVUQCRAWC\_dzRstkknw&context=spotify%3Asearch%3Acreep


**015.** `07:01` **You**

https://open\.spotify\.com/track/4RCWB3V8V0dignt99LZ8vH?si=Lcu9S7MhRD6NxHuhTO90mg&context=spotify%3Asearch%3Ahey%2Bthere%2Bs


**016.** `07:06` **You**

https://open\.spotify\.com/track/0BCPKOYdS2jbQ8iyB56Zns?si=Bpf\_dLEQQKajgZZQxocdFQ&context=spotify%3Asearch%3Ahey%2Bthere%2Bs


**017.** `07:12` **You**

https://open\.spotify\.com/track/7aNk0hjd9VCAoBirwg6aYZ?si=Z8zsA6TWTKebAtG0EBz96A&context=spotify%3Asearch%3Afaithfully


**018.** `07:15` **You**

I mean this is some really good workout music\.


**019.** `07:18` **You**

Anthem song for the morning g and grace 5/6 slow dance classic


**020.** `07:19` **You**

https://open\.spotify\.com/track/4LFwNJWoj74Yd71fIr1W8x?si=We4F\-YS9QbS7obm8Odiw2Q&context=spotify%3Asearch%3Aright%2Bhere%2Bwaiting


**021.** `07:24` **You**

https://open\.spotify\.com/track/3x2ksaXI6EZUWidE2BiLXy?si=vwqR1VbsTtCUYC41n\_BjsA&context=spotify%3Asearch%3Aright%2Bhere%2Bwaiting
For a few years out


**022.** `07:27` **You**

https://open\.spotify\.com/track/0xRP7uR86J4q9ZM2g4Fenv?si=vuUySSu\-TOyqf9XZ2IE8Wg&context=spotify%3Asearch%3Aset%2Bthe%2Bfire%2Bto%2Bthe%2Bthird%2Bbar
Never heard this one before


**023.** `07:37` **You**

https://open\.spotify\.com/track/4wLZ4zPM9c4oe1VV8ejdWV?si=DE9eAEY\_RJCGfNLndJPvvQ&context=spotify%3Asearch%3Ahome%2Bbuble
You\.


**024.** `07:44` **You**

https://open\.spotify\.com/track/3Bclyko7WmwM2oGmKj8sue?si=sH0yWDYtT2eZaqf8fxgMlQ&context=spotify%3Asearch%3Ai%2Bwill%2Bwait


**025.** `07:52` **You**

https://open\.spotify\.com/track/5QpaGzWp0hwB5faV8dkbAz?si=uhj6V1fXQ7KopGFPd2p1ag&context=spotify%3Asearch%3Awherever%2Byou%2Bwill%2Bgo


**026.** `07:55` **You**

Ok enough music for now\.\. well that last one was too sad will finish with one of yours


**027.** `07:55` **You**

https://open\.spotify\.com/track/0GVuLQtPXFaL18ijEOqoAa?si=3f8oc8ZZQY\-GJhKzX3\_usQ&context=spotify%3Asearch%3Atoghteope
Love this one ❤️❤️❤️❤️


**028.** `08:03` **You**

I think maybe this might be the new norm
For
Me\.\. if
You are open to it\.\. I know it isn’t the same as talking to you\.\. but I feel better when I share things\.\. no expectation back except for certain things I might want to discuss but I might just see how just leveraging this as a kind of journal works\.\.


**029.** `10:10` **Meredith Lamb (+14169386001)**

😴


**030.** `10:11` **Meredith Lamb (+14169386001)**

Omg think I might just sleep all day


**031.** `10:11` **Meredith Lamb (+14169386001)**

:p


**032.** `10:11` **Meredith Lamb (+14169386001)**

I saw like 26 signal msgs and was like wtf\. Thought something was majorly wrong lol


**033.** `10:32` **You**

Reaction: ❓ from Meredith Lamb
Nope just at Yorkdale


**034.** `10:33` **You**

Then outlets


**035.** `10:33` **You**

Then U\-Haul


**036.** `10:33` **You**

>
Not surprised you had a really rough night

*💬 Reply*

**037.** `10:34` **You**

Anyways will check in later when I can\.\. doubt you will even be up and through my messages by then\.


**038.** `10:34` **You**

Ciao


**039.** `10:38` **Meredith Lamb (+14169386001)**

I think I’m still stoned\. :p holy


**040.** `10:39` **Meredith Lamb (+14169386001)**

Those gummies were fucked up… never again\. Lol


**041.** `11:37` **You**

Yeah I don’t believe you


**042.** `11:38` **You**

You don’t believe in you don’t believe in absolutes


**043.** `11:38` **You**

Outlets now\.


**044.** `11:54` **Meredith Lamb (+14169386001)**

I’m not doing these ones ever again\. What was I thinking\. Lol My head, omg…\.

*📎 1 attachment(s)*

**045.** `11:56` **You**

I don’t know go back and read the stuff those gummies had yku saying


**046.** `11:57` **Meredith Lamb (+14169386001)**

Can’t read\. I have this weird head ache and dizziness that won’t go away\. Took an aleve\. Nothing\.


**047.** `11:57` **Meredith Lamb (+14169386001)**

Just watching tv and regretting all my life decisions\.


**048.** `12:21` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**049.** `12:35` **You**

>
Yeah I know\.\. I was def a wrong turn for you\.

*💬 Reply*

**050.** `12:36` **You**

I still feel kind of sick too\.


**051.** `12:39` **Meredith Lamb (+14169386001)**

I wasn’t referring to you\. You were not a wrong turn


**052.** `12:39` **Meredith Lamb (+14169386001)**

However, my anxiety is through the roof today … about so many things\.


**053.** `13:12` **Meredith Lamb (+14169386001)**

So I had half of a 50 gummy plus one of my own\. I’m so stupid lol no wonder… like 30thc last night at one time


**054.** `13:13` **Meredith Lamb (+14169386001)**

Paying the price today 😒


**055.** `14:23` **You**

Maybe anxiety from hardcore gummy consumption


**056.** `14:27` **Meredith Lamb (+14169386001)**

Yes ugh


**057.** `14:27` **Meredith Lamb (+14169386001)**

And the new situation


**058.** `14:33` **You**

Situation is fine


**059.** `14:35` **Meredith Lamb (+14169386001)**

It’s day 3\. Give it time\.


**060.** `15:40` **You**

Situation is FINE\.


**061.** `15:40` **You**

I sorted it with j\.  She just doesn’t want to be embarrassed at work


**062.** `15:41` **You**

So only tell him if you feel he will 100% keep it to himself


**063.** `15:41` **You**

>
I promise

*💬 Reply*

**064.** `15:42` **You**

I am literally doing everything I can to make everyone as happy as I can and except
Me so that I can keep this from becoming any kind of ongoing issue\.  J doesn’t want to talk about it and when we don’t she seems very fine


**065.** `15:42` **You**

Home now back from U\-Haul booked the move pickup


**066.** `15:44` **You**

Hope you are feeling better at least


**067.** `15:45` **You**

So I am home for the night unless I fuck off back to the gym which might happen\.\. the 2 a days might be coming back


**068.** `15:48` **You**

>
Kind of feels like it right now x

*💬 Reply*

**069.** `15:48` **You**

Not saying you feel like that\.\. but I kinda feel like I was/am\.  Anyways it is whatever now\.\. I am managing my end\.


**070.** `15:53` **You**

Maybe we missed each other today\.  I am around for the rest of the day if you want to chat or connect at all\.\. we can catch up 😝


**071.** `16:03` **Meredith Lamb (+14169386001)**

>
Omg I’m not telling him\! No way

*💬 Reply*

**072.** `16:04` **Meredith Lamb (+14169386001)**

>
I know you are\. I appreciate it ❤️ just still a little scary

*💬 Reply*

**073.** `16:05` **You**

Yeah I know\.


**074.** `16:09` **You**

Still Jaimie and I did discuss a bit today\.\. and she is 99% certain Gracie does absolutely nothing\.


**075.** `16:09` **You**

Reaction: ❤️ from Meredith Lamb
anyways, best I can do\.\. just going to focus on my own survival mode now, and keep everything calm around here\.


**076.** `16:14` **Meredith Lamb (+14169386001)**

99% is awfully high lol not sure I have that same confidence but it is ok, will manage regardless\. Was always a risk


**077.** `16:14` **You**

Gracie wouldn't know what to do\.\. J is going to talk to her though I think in general about backing down on all this\.\. nothing specific\.


**078.** `16:16` **Meredith Lamb (+14169386001)**

I think writing a nasty upset msg would be pretty easy if she got Andrew’s contact info somehow\. Seems like she is talented in the sleuthing dept\!


**079.** `16:17` **You**

the only way she gets that is through your linked in


**080.** `16:17` **You**

there is a setting where you can stop sharing your connections


**081.** `16:17` **You**

then it isn't suspicious


**082.** `16:17` **Meredith Lamb (+14169386001)**

But you can’t control it so it is fine


**083.** `16:17` **You**

I just told you how to mitigate what i can see as the only risk there is


**084.** `16:17` **Meredith Lamb (+14169386001)**

I’m doing it now


**085.** `16:20` **You**

worked


**086.** `16:21` **Meredith Lamb (+14169386001)**

Done\. Yup


**087.** `16:21` **You**

I can see mutual connectioons only


**088.** `16:28` **You**

kk well you probably have stuff going on\.\. so I am going to go focus on some work\.


**089.** `16:33` **Meredith Lamb (+14169386001)**

I am literally doing nothing\. Sad day\. Lol


**090.** `17:09` **You**

I mean sounds like you are enjoying relaxing so there is that\.


**091.** `17:25` **Meredith Lamb (+14169386001)**

What are you up to?


**092.** `17:25` **You**

Just some drama\.\. same shit different day\.


**093.** `17:26` **You**

hiding in basement beefing up security


**094.** `17:26` **Meredith Lamb (+14169386001)**

:\(


**095.** `17:26` **You**

Gracie still fighting about not leaving\.\. whatever\.\. over it


**096.** `17:26` **Meredith Lamb (+14169386001)**

I’m a little paranoid I may have said something that Andrew heard or something when I was a mess\. Mackenzie thinks she doesn’t think so\. We will see\.


**097.** `17:27` **You**

Did you go back and read the transcript yet\.\.\.\.\.\.\.\.\.


**098.** `17:27` **You**

starting from your mom whipping me into shape


**099.** `17:28` **Meredith Lamb (+14169386001)**

Omg no I will hate myself if I go back and read


**100.** `17:28` **You**

I would appreciate it if you would\.


**101.** `17:28` **Meredith Lamb (+14169386001)**

Whyyyyyyy


**102.** `17:28` **You**

because it was rough\.\. and I am cool if you want to do that\.\. and I love every version of Meredith, even that one\.\. but I cannot do that again\.


**103.** `17:29` **You**

I was really worried


**104.** `17:29` **You**

You won't understand if you don't read it\.


**105.** `17:29` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I’m sorry 😢


**106.** `17:34` **Meredith Lamb (+14169386001)**

Sorry talking to Andrew\. He is acting normal so I guess I didn’t do anything too weird last night


**107.** `17:35` **Meredith Lamb (+14169386001)**

He just got home


**108.** `17:35` **Meredith Lamb (+14169386001)**

I cannot read last night\. I know it was a mess\.


**109.** `17:35` **Meredith Lamb (+14169386001)**

Just by how I feel today


**110.** `17:37` **You**

>
k

*💬 Reply*

**111.** `17:41` **Meredith Lamb (+14169386001)**

I was stupid, live … learn\. Is there something specific you want me to read/ know?


**112.** `17:42` **Meredith Lamb (+14169386001)**

Because I know I was generally the hugest mess ever\.


**113.** `17:42` **You**

Mer it's fine I don't want to go back through it again\.\. I shared with you some notes this morning\.\. if you want to just to leave it\.\. that is fine\.


**114.** `17:48` **Meredith Lamb (+14169386001)**

>
I’m kind of scared to hear what you are feeling I think\.

*💬 Reply*

**115.** `17:49` **You**

Nothing for you to be scared of\.


**116.** `17:50` **You**

But you won't have context\.


**117.** `17:50` **Meredith Lamb (+14169386001)**

Wdym


**118.** `17:51` **You**

You have to go through the whole thing from last night to this morning\.\. then you can ask me questions\. Otherwise you will have no context\.


**119.** `17:52` **You**

And then there was the conversation lol\.\. that at least wasn't recorded\.\. rofl\.


**120.** `17:52` **Meredith Lamb (+14169386001)**

Phewwwww


**121.** `17:52` **You**

But you did mock me when I said I love you\.


**122.** `17:52` **Meredith Lamb (+14169386001)**

:\(


**123.** `17:52` **Meredith Lamb (+14169386001)**

I honestly have zero recollection\.


**124.** `17:53` **Meredith Lamb (+14169386001)**

Why did I mock u??


**125.** `17:53` **You**

You said something along the lines of "Anyone can say that and it can mean anything\.\. it's easy\."


**126.** `17:53` **Meredith Lamb (+14169386001)**

Oh


**127.** `17:53` **Meredith Lamb (+14169386001)**

Out of my mind obviously


**128.** `17:53` **Meredith Lamb (+14169386001)**

lol


**129.** `17:53` **Meredith Lamb (+14169386001)**

Why didn’t you block me?


**130.** `17:53` **You**

?


**131.** `17:53` **Meredith Lamb (+14169386001)**

Seriously…


**132.** `17:54` **You**

block you


**133.** `17:54` **Meredith Lamb (+14169386001)**

Because I was so annoying …


**134.** `17:54` **You**

that isn't how this works\.


**135.** `17:54` **You**

and by this I  mean us


**136.** `17:54` **Meredith Lamb (+14169386001)**

You could have unblocked me this morning lol


**137.** `17:54` **You**

I would never do that to you\.


**138.** `17:55` **Meredith Lamb (+14169386001)**

Very kind but you can if I’m super annoying


**139.** `17:56` **You**

It will never happen\. So not worth getting into tbh\.\. I would never do that for any reason\.


**140.** `17:57` **Meredith Lamb (+14169386001)**

Just running to pick up Maelle at work


**141.** `17:57` **You**

yup


**142.** `19:09` **You**

Hey not sure if you are still out or not\.\. I am going to head to the gym and plan on being there till probably 10\.\. so not sure if you will be up to chatting or not\.\. let me know\.


**143.** `19:15` **Meredith Lamb (+14169386001)**

I am around just watching tv\. I felt like I should leave you alone tonight cuz of last night\. 😔


**144.** `19:18` **You**

I mean I don’t think that will make me feel better\.\. I feel like it might be you would rather avoid talking to me tonight lol\.\. that might be more accurate\.\. I told you already if you don’t want to go back and take a look we don’t have to discuss my feelings and we can drop it\.


**145.** `19:19` **You**

Either way whatever you want meet


**146.** `19:19` **You**

Mer


**147.** `19:19` **Meredith Lamb (+14169386001)**

Not true\. Not trying to avoid you\.


**148.** `19:19` **You**

Sorry driving


**149.** `19:20` **Meredith Lamb (+14169386001)**

If there is something we should discuss, then we should\. Not trying to avoid… just feeling loser\-ish\. Lol


**150.** `19:23` **You**

Let’s just leave it I shared enough earlier and last night\.  Will just deal with rest\.


**151.** `19:24` **Meredith Lamb (+14169386001)**

I read what you shared this morning\. But you said you wanted to discuss, ask questions\.


**152.** `19:25` **You**

It was about what you said last night it doesn’t matter mer\.\. it’s all over now it’s fine\.


**153.** `19:26` **Meredith Lamb (+14169386001)**

But I don’t even remember so you need to refresh my memory\. I can’t exactly bring up much\. 🙁


**154.** `19:26` **Meredith Lamb (+14169386001)**

Did I say bad stuff?


**155.** `19:30` **You**

Mer I don’t even want to go back through it now\.  Let’s just say I was really really worried\.  You were so messed I thought anything could happen and saying something to Andrew was only one of the many many things that went through my head\.\. you cannot understand if you don’t read it and you don’t want to read it and I don’t want to go back through it\.  So I think this will just be on me to resolve my own issues here\.


**156.** `19:31` **You**

But one thing I did say and I am paraphrasing was if I got that messed up and J was around it would have drove you crazy\.


**157.** `19:32` **You**

Anyhow I am gonna head in to get changed and run my ass off\.


**158.** `19:32` **Meredith Lamb (+14169386001)**

Sigh, I’m really sorry\. Honestly\. I was not even near Andrew for 99% of the night\.


**159.** `19:33` **Meredith Lamb (+14169386001)**

But I completely understand, I do\.


**160.** `19:33` **Meredith Lamb (+14169386001)**

And you are correct\.


**161.** `19:33` **Meredith Lamb (+14169386001)**

I was planning to be like that though\. Just want to re\-iterate\.


**162.** `19:33` **Meredith Lamb (+14169386001)**

\*wasnt


**163.** `19:36` **You**

Like I said mer it is over\.\. it’s is fine\.\. like nothing you can do\. Don’t worry about it\.


**164.** `19:40` **Meredith Lamb (+14169386001)**

Do you worry I would do something with Andrew when I’m messed up?


**165.** `19:41` **You**

Yep I do\.


**166.** `19:41` **Meredith Lamb (+14169386001)**

But I would not\.


**167.** `19:41` **You**

I mean I always worrrt a bit


**168.** `19:41` **Meredith Lamb (+14169386001)**

I don’t even like him\.


**169.** `19:41` **You**

But last night was another level


**170.** `19:41` **You**

You didn’t know what you were saying or doing last night


**171.** `19:42` **Meredith Lamb (+14169386001)**

True\.


**172.** `19:42` **Meredith Lamb (+14169386001)**

Can’t argue with that\.


**173.** `19:43` **You**

And you said some interesting things\.


**174.** `19:43` **You**

Maybe I had a paranoid thought you were going to ruin me\.


**175.** `19:43` **You**

I usually find drunk people are pretty honest


**176.** `19:43` **You**

So yeah I was worried


**177.** `19:44` **Meredith Lamb (+14169386001)**

Do I even want to know what I said that was “interesting”?


**178.** `19:44` **Meredith Lamb (+14169386001)**

Gah


**179.** `19:44` **Meredith Lamb (+14169386001)**

>
Why would I ruin you? Omg

*💬 Reply*

**180.** `19:44` **You**

No I was going to ruin you mer


**181.** `19:44` **You**

You said that to me


**182.** `19:45` **You**

Again not going into the rest because I tried to but couldn’t understand a lot


**183.** `19:45` **Meredith Lamb (+14169386001)**

Oh that wasn’t obvious by the way you typed it\.


**184.** `19:45` **You**

Sorry was pasting what you said


**185.** `19:46` **Meredith Lamb (+14169386001)**

Ah


**186.** `19:46` **Meredith Lamb (+14169386001)**

Well I can’t say I feel that way so… not sure\.


**187.** `19:47` **Meredith Lamb (+14169386001)**

I doubt I was only drunk at that point\.


**188.** `19:47` **Meredith Lamb (+14169386001)**

But who knows\.


**189.** `19:47` **Meredith Lamb (+14169386001)**

The gummies were a bit much for me


**190.** `19:49` **You**

I doubt you could explain much of what happened last night anyways even if you did go back\.  Like I said it is over it is fine\.\.  but I cannot do that again\.\. I would rather not know\.


**191.** `19:49` **Meredith Lamb (+14169386001)**

Understood\. Is there something I said that is majorly bothering you?


**192.** `19:54` **You**

Other than the ruin me part which I hear a lot echoed around here it was the general concern for what could happen\.\. it’s fine like I said I don’t expect anything to change\. And you shouldn’t have to to deal\. I just think on those nights I will just tap out\.  I won’t like it will still know what is going on but maybe I will deal better\.  Uggh………\.\.


**193.** `19:55` **You**

This fucking sucks\.


**194.** `19:56` **You**

Shouldn’t bother me Mike this


**195.** `19:56` **You**

Like


**196.** `19:57` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I seriously don’t feel that way so I’m not sure why I was spouting off about that\. And I am genuinely sorry\.


**197.** `19:59` **You**

Doesn’t change anything between us mer\.\. just bad night for me and really hard to process\. Not sure what to do here but again that is my problem\.


**198.** `20:02` **You**

Does seem like problems are piling up lately lol\.


**199.** `20:02` **Meredith Lamb (+14169386001)**

😭


**200.** `20:02` **You**

So should be interesting


**201.** `20:03` **Meredith Lamb (+14169386001)**

What’s hard to process though? My irresponsibility? Poor decision making? Gah


**202.** `20:03` **You**

Upside though you only have to see me for 2 days out of the next 3 weeks


**203.** `20:04` **You**

Asking Ian for 2 weeks off on
Monday\.


**204.** `20:04` **You**

Probably take another 1 or 2 off in July\.


**205.** `20:04` **You**

So there is that too


**206.** `20:06` **Meredith Lamb (+14169386001)**

>
You realize this isn’t really an upside right

*💬 Reply*

**207.** `20:06` **You**

>
No you are just doing what you feel you need to\.

*💬 Reply*

**208.** `20:06` **You**

>
I think it is for you

*💬 Reply*

**209.** `20:06` **Meredith Lamb (+14169386001)**

>
But what is hard to process?

*💬 Reply*

**210.** `20:07` **Meredith Lamb (+14169386001)**

>
Nothing about this situation / reality feels “upside”

*💬 Reply*

**211.** `20:07` **You**

I just thought if I did that you would lose your mind\.\.


**212.** `20:07` **You**

Anyways when I started trying to warn you you just kind of blew me off\.


**213.** `20:07` **You**

Again you were messed so w/e


**214.** `20:07` **Meredith Lamb (+14169386001)**

Oh


**215.** `20:07` **You**

Like I said there is no point in re hashing\.\. not going to solve anything


**216.** `20:07` **Meredith Lamb (+14169386001)**

But what if you did it by accident? Poor decision making?


**217.** `20:08` **You**

We have 2 months to get through I cannot let this mess me up


**218.** `20:08` **Meredith Lamb (+14169386001)**

Maybe I would be more understanding


**219.** `20:08` **You**

I don’t drink around Jaimie


**220.** `20:09` **You**

Mer I am not holding this against you if that is your concern I told you I just need to be absent for future events\.


**221.** `20:09` **You**

It is what it is\.


**222.** `20:09` **Meredith Lamb (+14169386001)**

Okay, understood\.


**223.** `20:11` **You**

Look you don’t need to engage on this anymore\.  Why don’t you just do relax and do what you were doing\.  I am going to just walk and think for a while then shower and go home to bed\.


**224.** `20:14` **Meredith Lamb (+14169386001)**

Ok, but before that, do you trust that I never actually did anything with Andrew?


**225.** `20:16` **You**

I trust you mer\.\. but you don’t even Remeber what happened last night for like the last 2\-3 hours\.\.  and god I love you to death\.\. so I would just rather be ignorant in the future\.\. answer me this you might not want to but go read the exchanges then ask yourself if the roles were reversed would you be 100% certain?  I am not trying to be mean 😢 I believe in you and us\.\. but man last night you had absolutely no clue about anything mer I have never seen you like that\.  There is no way you could make thought out decisions\.


**226.** `20:17` **You**

Like I am just trying to survive the next 60 days\.


**227.** `20:18` **You**

I will do what I have to\.\. even if that is stick my head in the sand and pretend\.


**228.** `20:18` **Meredith Lamb (+14169386001)**

I know I don’t remember a lot but I know we didn’t do anything\. Nor would I have wanted to anyway\.


**229.** `20:19` **You**

Kk I believe you\.\. it’s ok\.  I know you wouldn’t have wanted to regardless\.


**230.** `20:19` **You**

Ok\.\.


**231.** `20:20` **You**

Mer it’s fine ok I believe you this is all my problem\.\. it’s just in my head\.


**232.** `20:21` **You**

… I don’t know what else to say…\.\.


**233.** `20:21` **Meredith Lamb (+14169386001)**

You don’t have to say anything else\. I will smarten up… need to for my damn kids anyway\. :p


**234.** `20:22` **You**

It what I asked\.  I need you to come through this as the mer I love


**235.** `20:22` **You**

I need you to do what you need to do


**236.** `20:22` **You**

But maybe just not that hard


**237.** `20:22` **Meredith Lamb (+14169386001)**

I try to escape this reality and obviously went overboard\. Johnnys gummies fault imo


**238.** `20:22` **You**

Yeah it wasn’t good


**239.** `20:22` **You**

Reaction: ❓ from Meredith Lamb
You wanted to meet Andrew


**240.** `20:23` **You**

And apparent mac was on my side


**241.** `20:23` **You**

Not sure what that meant


**242.** `20:23` **You**

You wanted me to meet Andrew


**243.** `20:23` **Meredith Lamb (+14169386001)**

Oh weird\. No don’t want that


**244.** `20:23` **You**

Something about a monologue


**245.** `20:23` **You**

You sent me half a voice chat


**246.** `20:24` **You**

Then deleted it


**247.** `20:24` **You**

So yeah


**248.** `20:24` **You**

Hard to follow


**249.** `20:24` **Meredith Lamb (+14169386001)**

Sorry I can even help to interpret that unfortunately


**250.** `20:24` **Meredith Lamb (+14169386001)**

Ughhhh


**251.** `20:24` **You**

Figured


**252.** `20:24` **Meredith Lamb (+14169386001)**

I’m a mess\.


**253.** `20:24` **Meredith Lamb (+14169386001)**

Shit\.


**254.** `20:25` **Meredith Lamb (+14169386001)**

Will turn it around\.


**255.** `20:26` **You**

I dunno\.\. this plus not seeing you for weeks\.\. hard


**256.** `20:26` **You**

It’s the plan though so gotta hold to it\.


**257.** `20:27` **You**

And I will be scarce Monday and Tuesday already decided


**258.** `20:27` **You**

Told you that last night too\.\. cannot remember what you said


**259.** `20:28` **Meredith Lamb (+14169386001)**

Things feel so bleak\. This feeling worries me\.


**260.** `20:28` **You**

Honestly hurts too much yku see it on my face


**261.** `20:28` **You**

And then you feel bad


**262.** `20:28` **You**

Reaction: 👎 from Meredith Lamb
Better I just go somewhere else


**263.** `20:29` **You**

The feeling is called resignation\.  As in we have no choice\.


**264.** `20:32` **You**

>
They feel that way because they are nothing to do but get through it\.\. I think you will have an easy 3 weeks ahead so that is goood for you

*💬 Reply*

**265.** `20:33` **Meredith Lamb (+14169386001)**

>
You can’t actually believe this?

*💬 Reply*

**266.** `20:34` **You**

I think that was your biggest problem the other day\.\. so it will be solved as of Monday\.


**267.** `20:35` **Meredith Lamb (+14169386001)**

Scott, there is no real solution here that is feasible so you just disappearing from view for 3 wks is not going to fix things


**268.** `20:35` **Meredith Lamb (+14169386001)**

Just saying


**269.** `20:35` **You**

We did talk about it that night after golf\.


**270.** `20:35` **Meredith Lamb (+14169386001)**

That is a very black and white approach


**271.** `20:35` **You**

I can only address the concerns you have as best I can and try to protect myself in the orocesss


**272.** `20:36` **Meredith Lamb (+14169386001)**

We cannot ignore what you need in this though\.


**273.** `20:36` **Meredith Lamb (+14169386001)**

That will just shut you down and you will start resenting me


**274.** `20:36` **You**

Well I am going to


**275.** `20:36` **Meredith Lamb (+14169386001)**

No


**276.** `20:37` **Meredith Lamb (+14169386001)**

We need a balance


**277.** `20:37` **You**

Yes and I won’t resent you but I will shit down more and more just again to protect myself


**278.** `20:37` **You**

There cannot be any balance mer


**279.** `20:37` **You**

We don’t work that way\.


**280.** `20:37` **You**

At least not now


**281.** `20:37` **Meredith Lamb (+14169386001)**

We can try


**282.** `20:37` **You**

I don’t think so mer trying caused you grief\.\. I do t want to do that again\.


**283.** `20:38` **You**

I really don’t


**284.** `20:39` **Meredith Lamb (+14169386001)**

Here’s what happened\. We talked about it and didn’t fully resolve it \(which was fine\. It was challenging\) and we had to just chill and go to bed\. Then I woke up to “problem, j knows”\.


**285.** `20:39` **Meredith Lamb (+14169386001)**

It was like 🤯


**286.** `20:39` **Meredith Lamb (+14169386001)**

So it was kind of like a tsunami


**287.** `20:40` **Meredith Lamb (+14169386001)**

That’s literally what it felt like


**288.** `20:40` **You**

I don’t think there is a resolution\.\. my resolution is to work next week and fuck off the two after that


**289.** `20:40` **You**

Then Chatham


**290.** `20:40` **You**

Then whatever\.\. too far out to know


**291.** `20:41` **Meredith Lamb (+14169386001)**

I know you don’t want this to be your next 3 weeks\. What would you want for real?


**292.** `20:43` **You**

That is what I want


**293.** `20:44` **You**

Of course that isn’t what I fucking want\.\. but it doesn’t matter mer\.\. we cannot have what we want\.


**294.** `20:44` **You**

So this solution at least makes it easier for one of us


**295.** `20:46` **You**

I am going to go jump in the sauna and then shower should be done in 30 mins\. Didnt feel like doing anymore gym tonight\.


**296.** `20:47` **Meredith Lamb (+14169386001)**

k, I’m feeling really upset, I don’t like this 😢 I will watch tv… I miss you irl


**297.** `20:49` **You**

Reaction: 😢 from Meredith Lamb
I will message
You when I am done if you want\.  I miss you to\.\. sorry I made you upset I love you\.  I do if nothing else mer I swear to god\.\. I swear o\. The memory of my mother\.\. I will never ever stop loving you for as long you will have me\.\. but right now  my heart hurts like it has never hurt before and I cannot do anything about it\.


**298.** `20:49` **You**

Will msg after\.\. if
You are still up\. But if you are exhausted mentally etc just don’t bother responding I will know and it will be fine


**299.** `20:50` **You**

If you want to call me if you can if it would make you feel better I will drive around for a bit\.


**300.** `20:52` **Meredith Lamb (+14169386001)**

Calling might be tricky tonight\. Quiet house with ppl everywhere


**301.** `21:10` **You**

Kk no worries\.\. I am just gonna get changed and go to car\.


**302.** `21:16` **You**

I mean probably better if we just don’t anyways\.\. we don’t have much to talk about honestly and that is the big problem\.\. we don’t have a future to discuss… yet\.\. so it just leads to kind of sad chats anyways right\.\.


**303.** `21:17` **Meredith Lamb (+14169386001)**

These msgs make me sadder\.


**304.** `21:18` **Meredith Lamb (+14169386001)**

How did we get here…\. Hoping this is a small blip\.


**305.** `21:19` **You**

I wouldn’t call it small\. But yeah it is a blip\.  We got here because we are different and need different things\. Together I think we are perfect but in this situation\.\. not so perfect at supporting each other unfortunately


**306.** `21:19` **You**

If we had have realized this in September for the first time I think it would have been epic


**307.** `21:22` **You**

But yeah we got moments of epic  to kick it off\.\. a clear realization this is real and I feel we are pretty awesome together\.\. very easy actually unlike this\.  And then reality hit us things got scary and anxious for you\.\. while I am still full steam ahead even despite people finding out\.\. so it doesn’t fit well here\.\. in this phase\.  But it is where we are now\. Nothing to be done\.  I am sorry I should have went way slower\.  Then maybe our expectations, well my expectations would be lower\.


**308.** `21:25` **Meredith Lamb (+14169386001)**

I just don’t know what I’m supposed to do anymore\. I don’t like that feeling\. I don’t like letting you down constantly\. I feel like I’m dragging you down\.


**309.** `21:25` **You**

In the car now \- feel like I should go to a bar find a stranger and share all mu troubles with them\.  That’s what happens in the movies and then get some kind of ahah moment\.


**310.** `21:26` **You**

>
It’s not you\.\. it is just the situation\.\. you can’t do anything but be yourself\.

*💬 Reply*

**311.** `21:27` **You**

>
I also feel the same way… I just want to see you all the time\.\. and that just puts way too much pressure on you\.\. so I think we are in the same boat like I said we need different things\.\. but I can give you what you want or at least most of it

*💬 Reply*

**312.** `21:31` **Meredith Lamb (+14169386001)**

I don’t know what to say\. Just wish we were together tonight\. That’s all\.


**313.** `21:34` **You**

Yeah you know what I don’t want this to come across the wrong way but maybe we should even think about dialling back chats??? I mean you are chill and happy at night with your rc and stuff and this does nothing but bring you down\.


**314.** `21:35` **You**

I mean I am just looking for ways to avoid more pain etc


**315.** `21:35` **You**

Just a thought don’t onerthinj it it doesn’t have a deeper meaning


**316.** `21:37` **Meredith Lamb (+14169386001)**

😞


**317.** `21:38` **You**

I mean I don’t know what to do\.  It bothers me just as
Much to see you\.  Can’t go to you flirt with you give you a hug\.\. then we try to talk like everything is fine at night\.\. welll last night was a whole other thing\.\. but most nights we don’t have anything to build towards or look forward to\.\. you get it right


**318.** `21:39` **You**

So this is where I pull you down because if I don’t call you


**319.** `21:40` **You**

You will just chill and lose yourself in your shows and just keep on keep in on


**320.** `21:41` **You**

Deleted\. No
Words
Anyways


**321.** `21:45` **Meredith Lamb (+14169386001)**

This is making me feel very f\*cked up\. Maybe tomorrow will be better\.


**322.** `21:47` **You**

home sweet home


**323.** `21:48` **You**



**324.** `21:50` **You**

>
yeah let's call it a night\.\. now one is going to end up happy regardless\.\. feel free to just do whatever tomorrow with this\.\. don't feel like you need to reach out if you don't want to\.\. likely ends up something like this anyways\.\.\. I won't dogpile any messages like this morning\.\. I thought about the idea of using this as a running journal and just sharing random things with your throughout the day\.\. but I think that is a kind of stupid idea too\.

*💬 Reply*

**325.** `21:53` **Meredith Lamb (+14169386001)**

What did you delete?


**326.** `21:53` **You**

just looking at schedules for Monday and Tuesday


**327.** `21:53` **You**

should be easy to fill and you and I don't have any meetings planned\.


**328.** `21:53` **You**

>
doesn't matter\.

*💬 Reply*

**329.** `21:54` **You**

at one point last night the topic of what do we do came up\.\. you were pretty drunk\.


**330.** `21:54` **You**

or drunk and stoned


**331.** `21:54` **You**

push pause was kind of raised\.


**332.** `21:54` **You**

not by me\.\.\.


**333.** `21:55` **You**

that was that last thing I was going to ask you about earlier\.\.


**334.** `21:55` **You**

but you said you didn't remember anything


**335.** `21:55` **You**

that was what I deleted


**336.** `21:55` **Meredith Lamb (+14169386001)**

Ugh k


**337.** `21:56` **Meredith Lamb (+14169386001)**

I don’t want to pause, seriously\.


**338.** `21:56` **You**

again I see people who are drunk to have no inhibitions\.\. and are usually honest\.\.


**339.** `21:56` **You**

which is why I am worried about this about you about andrew about all ofit


**340.** `21:57` **Meredith Lamb (+14169386001)**

Not true\. Lots of ppl say things they don’t mean with substance abuse\.


**341.** `21:57` **Meredith Lamb (+14169386001)**

It isn’t always truth


**342.** `21:57` **You**

you havent struck me that way so far though


**343.** `21:57` **Meredith Lamb (+14169386001)**

Did I say we SHOULD pause?


**344.** `21:57` **You**

could and then maybe should


**345.** `21:58` **Meredith Lamb (+14169386001)**

Listen, the whole “my family knows and thinks you are a home wrecker” thing kind of hit me like a tsunami\.


**346.** `21:58` **You**

look i don't want to anyways


**347.** `21:58` **Meredith Lamb (+14169386001)**

I was feeling a lot of scary stuff


**348.** `21:59` **Meredith Lamb (+14169386001)**

So likely that impacted the way I was acting last night\.


**349.** `21:59` **Meredith Lamb (+14169386001)**

I am not very resilient\.


**350.** `21:59` **You**

perhaps\.\. I think issues existed pre tsunami


**351.** `21:59` **Meredith Lamb (+14169386001)**

I like to escape when things are hard\.


**352.** `21:59` **You**

well maybe you need this then


**353.** `21:59` **Meredith Lamb (+14169386001)**

>
Absolutely but that threw me over the edge I think\.

*💬 Reply*

**354.** `22:01` **Meredith Lamb (+14169386001)**

>
No, I don’t think so but I obviously have some work to do mentally\.

*💬 Reply*

**355.** `22:01` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Honestly I am so sure about us, I would move in with you tomorrow if I could\.


**356.** `22:01` **Meredith Lamb (+14169386001)**

Like I don’t have uncertainties


**357.** `22:02` **Meredith Lamb (+14169386001)**

I’m just a little lost I guess\. This is very hard to navigate


**358.** `22:04` **You**

well again while it wont technically be a pause I think you will get some time and space in the next few weeks\.


**359.** `22:04` **You**

so maybe that will help you


**360.** `22:04` **You**

don't worry about me\.\. nothing you can do anyways


**361.** `22:06` **You**

>
for the record I don't either\.\. and I would move in with you now too and be all the happier for it\.

*💬 Reply*

**362.** `22:08` **Meredith Lamb (+14169386001)**

>
I will always worry about you\.

*💬 Reply*

**363.** `22:08` **You**

>
but it isn't worth it\.\. nothing can be done

*💬 Reply*

**364.** `22:08` **You**

so don't bother


**365.** `22:09` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
I think we would both be happier\. Not sure about everyone else but we would be

*💬 Reply*

**366.** `22:10` **Meredith Lamb (+14169386001)**

>
This isn’t true\. You are part of my world now… you are important to me\. So I want to help you just as much as you do for me\. But we don’t need to sort it tonight\.

*💬 Reply*

**367.** `22:11` **You**

>
mer I mean it won't get sorted for weeks and weeks etc etc etc\.\. so at least no point worrying now\.

*💬 Reply*

**368.** `22:13` **You**

>
I feel the same way about you\.\. but like I said\.\. I don't think you can help\.\. and I don't want to expect that help\.\.

*💬 Reply*

**369.** `22:27` **You**

>
also\.\. the we do not need to sort it tonight\.\. that is becoming a theme btw\.\. if you read back lol\.\. just saying

*💬 Reply*

**370.** `22:29` **Meredith Lamb (+14169386001)**

Well if we could sort it I would\.


**371.** `22:29` **You**

so why don't we "put a pin in it" "per se" and "as we don't need to sort it out tonight"


**372.** `22:29` **Meredith Lamb (+14169386001)**

If you were lying beside me it would be sorted\.


**373.** `22:29` **You**

Reaction: ❤️ from Scott Hicks
I wouldn't be lying beside you for one thing\.\. it is 10:30\.


**374.** `22:30` **You**

but yeah I am steering clear of those too


**375.** `22:30` **You**

lol


**376.** `22:30` **Meredith Lamb (+14169386001)**

?


**377.** `22:30` **You**

my entendres


**378.** `22:30` **Meredith Lamb (+14169386001)**

lol oh


**379.** `22:31` **Meredith Lamb (+14169386001)**

Sigh


**380.** `22:31` **You**

>
and it wouldn't  because we were lying beside each other all weekend\.\. lol

*💬 Reply*

**381.** `22:31` **You**

time and patience I guess\.\. and pain and sadness\.\. etc etc\.\. until I dunno\.\. September?


**382.** `22:32` **You**

anyways go to bed Mer\.\. I am not going to make anyone feel better tonight\.\. probably not for a while\.\. so again\.\. we can revisit chatting etc\.\. because you deserve to be happy\.\. you are a happy soul\.\.


**383.** `22:32` **You**

and right now\.\. I am stifling you and smothering you with all my sad shit\.


**384.** `22:33` **You**

you don't need it or me right now\.\. you just need to focus on getting through your stuff\.


**385.** `22:33` **You**

just know if I dial back the texts\.\. it isn't because I am not thinking about you\.


**386.** `22:35` **Meredith Lamb (+14169386001)**

Omg you have to stop saying all of that crap…\.


**387.** `22:35` **You**

>
it's not crap mer\.

*💬 Reply*

**388.** `22:36` **You**

😬


**389.** `22:37` **Meredith Lamb (+14169386001)**

They are difficult messages to read from the person I am in love with and just want to be with\.

*📎 1 attachment(s)*

**390.** `22:45` **You**

they are messages from someone who loves you and wants to be with you but knows that he cannot\.\. and he knows that wanting you as bad as he does\.\. being disappointed when opportunities pass by, making you feel bad because because you see and feel his disappointment\.\. it's not fair to anyone


**391.** `22:48` **You**

I mean the more I want, the more I love you, the more intensely I love you, which is still going btw\.\. makes no sense but it keeps growing\.\. it just causes you more pain, when I feel pain\.\. so why wouldn't it be better to block that off?


**392.** `22:49` **Meredith Lamb (+14169386001)**

You are allowed to be disappointed and express that\. It is fair\. So don’t say that


**393.** `22:50` **You**

but then you take it on yourself


**394.** `22:50` **You**

like it is your fault I am too needy


**395.** `22:51` **You**

I told you earlier\.\. we are great for each other down the road\.\. we are not great at supporting each other right now\.\. I don't know how to be different


**396.** `22:52` **Meredith Lamb (+14169386001)**

Listen, you are not needy\. You are just dealing with someone \(me\) who isn’t in a “normal” life situation right now\.


**397.** `22:53` **Meredith Lamb (+14169386001)**

And I love you more and more as time passes also… sucks 🙃


**398.** `22:58` **You**

>
listen I appreciate this\.\. and the effort\.\. but I don't want you to waste your energy on this seriously\.\. I know you love me\.\. but you cannot fix this\.  You not fixing it doesn't mean you aren't the love of my life or the only person I want to spend it with\.\. it just means right now and for the foreseeable future\.\. we are not going to have a lot of fun\.

*💬 Reply*

**399.** `23:00` **You**

So when you need to escape\.\. like last night \- I can do a little bit of that\.\. especially if Andrew isn't around\.\. but that much with him around\.\. yeah I cannot\.\. and neither could you\.\. so we know to avoid that\.   I don't know what to say beyond that\.  Hope for the best I guess\.\. right\.


**400.** `23:03` **Meredith Lamb (+14169386001)**

I honestly wasn’t really thinking\. I won’t do that again\. Seriously\.


**401.** `23:05` **You**

I didn't say that to shame you\.\. I just\.\.


**402.** `23:05` **You**

again\.\. you can do it


**403.** `23:05` **You**

or do whatever


**404.** `23:05` **You**

it is your life\.


**405.** `23:06` **You**

I just cannot be watching and listening and thinking and worrying\.  right\.\. that is all\.


**406.** `23:06` **You**

if I was there I would be in it with you and laughing away


**407.** `23:07` **You**

it is just different when we are apart and expect to be constantly apart for weeks\.\. gives me too much time to think\.\. without getting grounded with you again\.  I don't know how else to explain it\.\. but you should go to bed mer\.\. it is late\.\. and you were up late last night\.


**408.** `23:09` **Meredith Lamb (+14169386001)**

I get it completely…\. All of it\. You should go to bed too


**409.** `23:10` **You**

\.\. ok\.\. I love you\.\. get some sleep\.\. ❤️


**410.** `23:12` **You**

who knows\.\. like you said\.\. maybe tomorrow will be a better day\.\. rofl\.


**411.** `23:13` **Meredith Lamb (+14169386001)**

Maybe ❤️


**412.** `23:14` **You**

Reaction: ❤️ from Meredith Lamb
>
I am a realist\.\.\. forecast says cloudy with a chance of a thunderstorm, with tornadoes, rotating around an exploding volcano\.

*💬 Reply*

**413.** `23:15` **Meredith Lamb (+14169386001)**

LOL


**414.** `23:15` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Accurate


**415.** `23:16` **You**

yep my life\.\. ain't it fucking grand\.  Goodnight xo\.\. srlsy go to sleep and stop worrying or being upset or anything\.\. just focus on you\.\. that is enough\.


**416.** `23:22` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I cannot stop but goodnight \- love you


**417.** `23:24` **You**

>
You need to though there is no point for both of us suffering\.

*💬 Reply*

