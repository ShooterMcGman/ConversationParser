# Daily Conversation: 2025-07-15 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-15 |
| **Day** | Tuesday |
| **Week** | 14 |
| **Messages** | 372 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-15T03:25 - 2025-07-15T21:12 |

## 📝 Daily Summary

This day contains **372 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `03:25` **Meredith Lamb (+14169386001)**

Ugh the past couple nights it has felt like I’m getting insomnia again\. I had it very bad during Covid\. I guess “we will see”…\.\. ugh\.


**002.** `04:06` **You**

Sorry Mer, maybe take something a bit to help\.\. magnesium and melatonin for bed\.


**003.** `04:06` **You**

Wouldn’t try working out until you can get a decent sleep


**004.** `04:07` **Meredith Lamb (+14169386001)**

I was almost back asleep and my phone buzzed lol just saying


**005.** `04:07` **Meredith Lamb (+14169386001)**

Haha I was like must be 4am


**006.** `04:08` **You**

You ok


**007.** `04:08` **Meredith Lamb (+14169386001)**

Yeah


**008.** `04:08` **You**

Fuck sry


**009.** `04:08` **Meredith Lamb (+14169386001)**

I was chatgpting for a while\. K going to go try to sleep more :p


**010.** `04:09` **Meredith Lamb (+14169386001)**

Don’t apologize I like your 4am msgs


**011.** `04:09` **You**

Reaction: ❤️ from Meredith Lamb
Kk gl sleeping chat later


**012.** `06:29` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 06:30:22 \-0400
|
| Less that satisfactory workout\.\. I did not go to sleep well or sleep well last night either, bad dreams\.  Uggh
|
| Version: 1
| Sent: Tue, 15 Jul 2025 06:29:38 \-0400
|
| Less that satisfactory workout\.\. I did not go to sleep well or sleep well last night either\.


**013.** `07:01` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 07:02:04 \-0400
|
| More talking this morning
|
| Version: 1
| Sent: Tue, 15 Jul 2025 07:01:58 \-0400
|
| More talking this morning I g


**014.** `07:04` **Meredith Lamb (+14169386001)**

We talked for an hour and I had the opportunity to clarify a lot after he had the opportunity to process


**015.** `07:04` **Meredith Lamb (+14169386001)**

So I think it was helpful


**016.** `07:05` **Meredith Lamb (+14169386001)**

He keeps calling you my boss and I had to tell him to stop\. He’s all “what do I call him?” And I go “um his name?” And he goes “oh so then we’re friends?”


**017.** `07:05` **Meredith Lamb (+14169386001)**

Omg


**018.** `07:05` **Meredith Lamb (+14169386001)**

Some conversations with him are so challenging


**019.** `07:06` **Meredith Lamb (+14169386001)**

He’s very hurt by the whole thing\.


**020.** `07:06` **Meredith Lamb (+14169386001)**

“Some separations result in reconciliation and I always thought we might\.”


**021.** `07:07` **Meredith Lamb (+14169386001)**

Also “I always thought you didn’t like me and now I know I was right because you just up and find someone else like that\.”


**022.** `07:07` **Meredith Lamb (+14169386001)**

Anyway, kind of a closure convo


**023.** `07:07` **Meredith Lamb (+14169386001)**

Now it feels like time to move on


**024.** `07:08` **Meredith Lamb (+14169386001)**

He seems okay but definitely hurt


**025.** `07:08` **Meredith Lamb (+14169386001)**

“You didn’t want to have sex with me and now…\.” Blahblahblah sex sex sex


**026.** `07:08` **Meredith Lamb (+14169386001)**

I had to be all this thing with Scott isn’t and never was all about sex


**027.** `07:09` **Meredith Lamb (+14169386001)**

He is so hyper focused on that


**028.** `07:09` **Meredith Lamb (+14169386001)**

As usual


**029.** `07:11` **Meredith Lamb (+14169386001)**

Yesterday he was just in shock and had a lot to process\. Seems better now


**030.** `07:11` **Meredith Lamb (+14169386001)**

But he still insists I was dating you while he and I were still together


**031.** `07:12` **Meredith Lamb (+14169386001)**

I have valid proof that is not the case but he just can’t believe it


**032.** `07:12` **Meredith Lamb (+14169386001)**

In March, the horrible month of him basically pestering me, he actually thought we were still together


**033.** `07:12` **Meredith Lamb (+14169386001)**

wtf


**034.** `07:13` **Meredith Lamb (+14169386001)**

Yesterday he searched for your name through all of our past texts


**035.** `07:13` **Meredith Lamb (+14169386001)**

I think he did a lot of investigative work yday


**036.** `07:14` **Meredith Lamb (+14169386001)**

So he’s “behind on work” now


**037.** `07:22` **You**

Sigh


**038.** `07:22` **You**

Just out of shower getting ready to leave shortly


**039.** `07:25` **Meredith Lamb (+14169386001)**

I think it is good news \(kind of\)


**040.** `07:25` **Meredith Lamb (+14169386001)**

He’s more disappointed, sad than angry


**041.** `07:25` **Meredith Lamb (+14169386001)**

This is a good thing


**042.** `07:26` **You**

I am not allowed to to say what I usually say so\.\.
Time will tell\.


**043.** `07:32` **Meredith Lamb (+14169386001)**

I got the whole “I’ve just always felt differently about you than you feel about me so…\.” Yadda yadda


**044.** `07:32` **Meredith Lamb (+14169386001)**

I think the fact that he wasn’t super angry this morning is telling\.


**045.** `07:33` **Meredith Lamb (+14169386001)**

More acceptance phase of the whole separation


**046.** `07:33` **You**

Phase whatever of 50


**047.** `07:35` **You**

Heading to work now\.


**048.** `07:43` **You**

I mean maybe you are right\.\. I feel like there is a lot he can do still through mediation and in other ways to make this difficult so just don’t get your hopes up yet\.


**049.** `07:46` **Meredith Lamb (+14169386001)**

Well he paid the final mediation bill yday so…


**050.** `07:48` **You**

So perhaps good sign


**051.** `07:48` **You**

I sent my signed copy of agreement to J’s lawyers last night


**052.** `07:58` **Meredith Lamb (+14169386001)**

Oh wow\. Big step


**053.** `07:59` **You**

Almost done\.\. today or tomorrow depending on her lawyers


**054.** `08:07` **Meredith Lamb (+14169386001)**

We had to pay before we get our final draft\. So hoping today\.


**055.** `08:08` **You**

Makes sense


**056.** `09:31` **Meredith Lamb (+14169386001)**

So Jim didnt approach the topic of us or Andrew or anything this morning\. What did you say? Lol


**057.** `09:31` **Meredith Lamb (+14169386001)**

Seemed out of character


**058.** `09:31` **Meredith Lamb (+14169386001)**

He talked about all sorts of other stuff


**059.** `09:31` **You**

I didn’t tell him anything


**060.** `09:31` **Meredith Lamb (+14169386001)**

But still


**061.** `09:32` **Meredith Lamb (+14169386001)**

Just seemed out of character


**062.** `09:32` **You**

I said good morning to him


**063.** `09:32` **You**

And nothing


**064.** `09:32` **Meredith Lamb (+14169386001)**

No I mean last time you talked


**065.** `09:32` **You**

And I hadn’t talked to him since last time


**066.** `09:32` **You**

As I said our last chat was very good\.


**067.** `09:32` **You**

Imho


**068.** `09:32` **You**

Normal


**069.** `09:33` **Meredith Lamb (+14169386001)**

Did you tell me about that when I was drunk? I don’t remember what you guys talked about or if you even told me


**070.** `09:33` **You**

Yes


**071.** `09:33` **Meredith Lamb (+14169386001)**

Argh


**072.** `09:33` **You**

I told you everything was ok and you had nothing to worry about


**073.** `09:33` **You**

I told you that I explained what I was doing with j and why and how it was all focused on setting me and us up for successs


**074.** `09:34` **Meredith Lamb (+14169386001)**

Oh right


**075.** `09:34` **Meredith Lamb (+14169386001)**

I remember now


**076.** `09:34` **You**

All good now?


**077.** `09:34` **Meredith Lamb (+14169386001)**

Yeah


**078.** `09:34` **You**

Ok


**079.** `09:40` **You**

I mean just ask him Mer\.\. don’t sit on it and fret


**080.** `09:47` **Meredith Lamb (+14169386001)**

I’m not fretting\. Just observing\. Lol


**081.** `09:48` **You**

Don’t believe you\.\. especially based on how you acted last week about this\.  You should engage him and get it out of your head his day is just going to get busier


**082.** `10:15` **Meredith Lamb (+14169386001)**

I am not fretting seriously\.


**083.** `10:15` **You**

K


**084.** `10:16` **Meredith Lamb (+14169386001)**

I’m more kind of fretting about moving now for some reason


**085.** `10:16` **Meredith Lamb (+14169386001)**

Weird


**086.** `10:16` **Meredith Lamb (+14169386001)**

Because I really have no pressure


**087.** `10:16` **You**

Milestone


**088.** `10:16` **Meredith Lamb (+14169386001)**

I think just because Andrew would really appreciate me gone given circumstances


**089.** `10:16` **Meredith Lamb (+14169386001)**

Maybe that


**090.** `10:16` **Meredith Lamb (+14169386001)**

Maybe not


**091.** `10:16` **Meredith Lamb (+14169386001)**

Dunno


**092.** `10:18` **You**

I mean I think you might both be more at ease\.\. but as long as you both are looking for the closure between you I suspect there will be some anxiety no matter where you live\.


**093.** `10:19` **Meredith Lamb (+14169386001)**

I don’t need closure but I feel like he does/did\.


**094.** `10:19` **Meredith Lamb (+14169386001)**

He REALLY thinks we spent two full nights together in Chatham\.


**095.** `10:20` **Meredith Lamb (+14169386001)**

I explained that Mac was there and I slept with her both nights and he kind of nodded his head okay\.


**096.** `10:20` **Meredith Lamb (+14169386001)**

True


**097.** `10:21` **Meredith Lamb (+14169386001)**

He was like well you have probably gone to other conferences or things and been together


**098.** `10:21` **Meredith Lamb (+14169386001)**

Like in the last two years


**099.** `10:21` **Meredith Lamb (+14169386001)**

I was like I travelled with Jim only


**100.** `10:21` **Meredith Lamb (+14169386001)**

And then in Jan travelled with Scott and Jim but we weren’t even talking then at all


**101.** `10:22` **Meredith Lamb (+14169386001)**

These specific instances seemed to help his ego a bit


**102.** `10:22` **Meredith Lamb (+14169386001)**

He said he finds this pretty embarrassing


**103.** `10:22` **Meredith Lamb (+14169386001)**

So same as Jaimie


**104.** `10:22` **Meredith Lamb (+14169386001)**

So he is not telling his family


**105.** `10:23` **You**

>
What I meant was you need him to get closure for you to be happy\.

*💬 Reply*

**106.** `10:24` **Meredith Lamb (+14169386001)**

Oh yes and so he will act nicer\.


**107.** `10:25` **You**

Kk well maybe once you feel closure has been achieved and you are less concerned he takes this out on you directly or potentially through kids you will feel better about moving


**108.** `10:26` **Meredith Lamb (+14169386001)**

I have now moved onto the phase where I feel bad for my dogs lol


**109.** `10:26` **Meredith Lamb (+14169386001)**

I just keep going through phases


**110.** `10:32` **You**

Yeah I think you have a lot to process


**111.** `10:32` **You**

I am ahead of you


**112.** `10:33` **You**

We have time you will have lots of time to process


**113.** `10:38` **Meredith Lamb (+14169386001)**

Does it bother you that I told him?


**114.** `10:39` **You**

No


**115.** `10:50` **You**

Did you think I was had to happen


**116.** `10:54` **Meredith Lamb (+14169386001)**

Was just checking


**117.** `10:58` **You**

Ok I would let
You know\.\. I was a little shocked by timing but I understand your need


**118.** `12:36` **You**

Omg boring


**119.** `12:37` **You**

Not going to be able to chat a lot today in these meetings by the time I am out you are in line for most of the day and I leave at 3\.\. so I hope you are and continue to have a good day\.


**120.** `12:37` **You**

Another day another tick on the wall for me\.\. meh…


**121.** `12:37` **Meredith Lamb (+14169386001)**

I had to check your calendar to see what was boring lol


**122.** `12:38` **Meredith Lamb (+14169386001)**

Yeah day is fine\. Meh


**123.** `12:38` **Meredith Lamb (+14169386001)**

Caught up with Leslie which was good


**124.** `12:39` **You**

Good\.\. well I am gonna eat I guess\.  Have a good one\.


**125.** `12:41` **Meredith Lamb (+14169386001)**

Why you leaving at 3?


**126.** `12:45` **You**

To get car ownership changed


**127.** `12:47` **You**

Reaction: 😮 from Meredith Lamb
Gracie won’t go to dbt again tomorrow j is now pissed at her… not sure what is going to happen but I think she might have just sealed her fate to 100%\!go back to Moncton unsure tho


**128.** `12:48` **You**

Anyway I am going to eat then you will be busy\.\. so chat later I guess\.


**129.** `12:51` **Meredith Lamb (+14169386001)**

Ugh we have to do the car ownership thing too\. Yeah I’m listening in to witness prep I guess … whee


**130.** `12:55` **You**

Yeah good times all kinds of fun today:


**131.** `12:55` **You**

Reaction: ❓ from Meredith Lamb
More to come stay tuned


**132.** `12:58` **You**

More days


**133.** `12:59` **You**

More days like this lol I meant


**134.** `13:00` **Meredith Lamb (+14169386001)**

Oh\. Yeah\. So fun\.


**135.** `13:01` **You**

Lots of optimism today right


**136.** `13:02` **Meredith Lamb (+14169386001)**

Totally\. I’m feeling it too\. Especially after last night\. September…\.


**137.** `13:06` **You**

I knew we weren’t going to resolve anything\.\. so I wanted to get off before I sank further\.\. literally nothing to look forward to\.


**138.** `13:08` **You**

At one point in time each day that went by each milestone we passed meant something felt like we were getting closer to something doesn’t feel like that atm\.  I get it atm\.\. but still that is how it feels right now\.\. probably when we could use some form of connection the most\.


**139.** `13:10` **You**

Like I said last night just going to give up on planning and even thinking about it\.\. easier to manage emotions\. Then… sorry I am not helping but with everything that has happened I have no clue what is next\.\. and not a lot of hope so just
Wait it out quietly\.


**140.** `13:10` **You**

Done my rant\.


**141.** `13:13` **Meredith Lamb (+14169386001)**

I know, I get it\. Very sucky\.


**142.** `13:22` **You**

Not sure what to do now\.\. fuck\.\. got a meeting then leaving\.\. gah


**143.** `13:38` **Meredith Lamb (+14169386001)**

k, love you \- we will chat later ❤️ we are in this together… misery loves company 😵‍💫


**144.** `13:41` **You**

Love you to Mer\.\. But last
Few days it is starting to hurt a bit with everything else going on not gonna lie\. TTYL\. ❤️😥


**145.** `13:46` **Meredith Lamb (+14169386001)**

I know, same… starting to wear a lot


**146.** `14:57` **You**

Leaving\.


**147.** `14:59` **Meredith Lamb (+14169386001)**

👋😢


**148.** `15:00` **You**

Never coming back either FML lol


**149.** `15:13` **Meredith Lamb (+14169386001)**

Such a good mood\.


**150.** `15:15` **You**

Yeah but at least I lol’d that makes it ok 🙂


**151.** `15:23` **Meredith Lamb (+14169386001)**

Ok \(lol\)


**152.** `15:23` **You**

See with the brackets it doesn’t work


**153.** `15:23` **You**

Feels forced


**154.** `15:24` **You**

I am trying


**155.** `15:24` **You**

❤️


**156.** `15:39` **You**

You don’t have to talk to me tonight if you dun want i know you are frustrated with me\.\. sorry I cannot repress it sometimes if you need to chill it is fine\.


**157.** `15:39` **Meredith Lamb (+14169386001)**

I am not frustrated with you…


**158.** `15:41` **Meredith Lamb (+14169386001)**

I just miss you like hell and am frustrated by that, not you\. I’m fine\.


**159.** `15:45` **You**

You sleeping at new place tonight?


**160.** `15:45` **You**

>
Yeah understatement

*💬 Reply*

**161.** `15:47` **Meredith Lamb (+14169386001)**

>
Honestly I never thought about it but should\.

*💬 Reply*

**162.** `15:48` **You**

Kk 🤔


**163.** `15:49` **Meredith Lamb (+14169386001)**

There are no mattresses there yet so I asked Andrew to leave me the Buick tonight but he wouldn’t so he goes “you can move a single in the mini” so I will be doing that tonight at minimum\.


**164.** `15:49` **Meredith Lamb (+14169386001)**

He said that this morning and I was like 🙄


**165.** `15:50` **You**

Ahhhhhhhhh ok


**166.** `15:50` **You**

Nm lol


**167.** `15:50` **You**

Sorry you have to do that on your own


**168.** `15:50` **Meredith Lamb (+14169386001)**

Do what?


**169.** `15:51` **You**

Nothing was the stupid idea I mentioned last week about coming over stupidly early instead of working out\.\. but you haven’t slept last two nights and we would likely get caught somehow\.\. plus single mattress Rofl…


**170.** `15:51` **You**

So nm\.\. last bit of planning energy I had left lol


**171.** `15:53` **Meredith Lamb (+14169386001)**

lol I hope to be more set up soonish\. Weekend ish


**172.** `15:54` **You**

It’s fine don’t worry about it\.\. lol I figured it wouldn’t work… all good\.


**173.** `15:54` **Meredith Lamb (+14169386001)**

I don’t even know what time Andrew is coming home tonight 🙄


**174.** `15:55` **You**

Not surprised\.


**175.** `15:55` **Meredith Lamb (+14169386001)**

Oh two mattresses were delivered today


**176.** `15:55` **Meredith Lamb (+14169386001)**

News to me\. I’m not home


**177.** `15:55` **Meredith Lamb (+14169386001)**

Soooo maybe will have more


**178.** `15:56` **Meredith Lamb (+14169386001)**

Will see how much I get over there tonight


**179.** `16:11` **You**

Sorry just in\.M middle of something


**180.** `16:18` **You**

Kk cars separated


**181.** `16:19` **You**

Well hopefully you can some more stuff over there should make it more comfortable for you at least\.


**182.** `16:22` **Meredith Lamb (+14169386001)**

Yeah but I likely won’t stay overnight\. No coffee maker, food, clothes etc etc


**183.** `16:22` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 16:22:37 \-0400
|
| Next week probably
|
| Version: 1
| Sent: Tue, 15 Jul 2025 16:22:30 \-0400
|
| Next week prob lanky


**184.** `16:39` **Meredith Lamb (+14169386001)**

Hey who wrote the p4p evidence and did the trc calcs\. Ahana and Carolyn don’t know\.


**185.** `16:40` **You**

For the rollover ?


**186.** `16:40` **You**

Or for the 2026


**187.** `16:40` **Meredith Lamb (+14169386001)**

Yeah


**188.** `16:40` **Meredith Lamb (+14169386001)**

Rollover


**189.** `16:40` **You**

Or for the
Original filing\.\. I would have to look back


**190.** `16:40` **Meredith Lamb (+14169386001)**

Yeah I can look too\. Ahana just curious and confused


**191.** `16:40` **You**

Honestly no clue of Cm does t know


**192.** `16:41` **You**

Is there an issue


**193.** `16:41` **Meredith Lamb (+14169386001)**

She’s getting questions from Katia \(probably Ian\)


**194.** `16:41` **You**

She shouldn’t be answering anything


**195.** `16:41` **You**

They are an intervenor


**196.** `16:41` **Meredith Lamb (+14169386001)**

She went to strategy for help\. She isn’t\. She came straight to me


**197.** `16:41` **Meredith Lamb (+14169386001)**

I threw it to Erin


**198.** `16:42` **You**

Tell her to get isn to call me


**199.** `16:42` **You**

Ian


**200.** `16:42` **You**

If he has an isssue


**201.** `16:42` **Meredith Lamb (+14169386001)**

We are just starting to look at it


**202.** `16:42` **You**

I will deal with it


**203.** `16:42` **Meredith Lamb (+14169386001)**

k


**204.** `16:42` **Meredith Lamb (+14169386001)**

I’m in elevator but can tell her later \(lol\)


**205.** `16:42` **You**

Ok


**206.** `16:43` **You**

I will look at evidence tonight got nothing else to do they are all swimming I have to cook them supper then go downstairs


**207.** `16:48` **Meredith Lamb (+14169386001)**

Forward you the email that katia sent later when I got home


**208.** `16:50` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 16:50:49 \-0400
|
| It’s fine, I already have it\.
|
| Version: 1
| Sent: Tue, 15 Jul 2025 16:50:12 \-0400
|
| I already have it\.


**209.** `17:01` **Meredith Lamb (+14169386001)**

Cool good


**210.** `17:29` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**211.** `17:31` **You**

I mean I am not surprised


**212.** `17:31` **You**

Even a bit


**213.** `17:35` **You**

Like you said it is simple availability


**214.** `17:35` **Meredith Lamb (+14169386001)**

Kinda why I worry about dogs


**215.** `17:35` **Meredith Lamb (+14169386001)**

He is selfish


**216.** `17:36` **You**

I would say same about me


**217.** `17:36` **You**

J


**218.** `17:36` **You**

But different circumstances


**219.** `17:36` **You**

A lot


**220.** `17:36` **Meredith Lamb (+14169386001)**

Did you make dinner for ppl tonight?


**221.** `17:36` **Meredith Lamb (+14169386001)**

Andrew is never even home for dinner


**222.** `17:36` **Meredith Lamb (+14169386001)**

Let alone make it


**223.** `17:36` **You**

Yes


**224.** `17:36` **Meredith Lamb (+14169386001)**

k so not the same at all


**225.** `17:36` **Meredith Lamb (+14169386001)**

Sorry


**226.** `17:37` **You**

Kk… sorry mer…\.


**227.** `17:37` **Meredith Lamb (+14169386001)**

You don’t have to apologize … I’m sure you are a selfish bastard lol


**228.** `17:38` **You**

Yep I very clearly am I demonstrate it every day\.


**229.** `17:41` **Meredith Lamb (+14169386001)**

That’s why I love you 😘


**230.** `17:44` **You**

There are so many reasons why I love you… but you are the opposite of selfish\.\. and I love that too\.\.


**231.** `17:53` **Meredith Lamb (+14169386001)**

I feel the same about you\. Would never in a million years call you selfish\. Can’t even imagine\.


**232.** `17:59` **You**

well I hope you can get a few loads in over there tonight with the mini\.


**233.** `18:07` **Meredith Lamb (+14169386001)**

I think I’m going to nap first 😴


**234.** `18:07` **You**

sounds like something Mer would do\.\. enjoy your nap\.\. :\)


**235.** `18:08` **Meredith Lamb (+14169386001)**

:\)


**236.** `18:08` **You**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 18:09:58 \-0400
|
| Not going to nap\.\. but might go to bed early\.\. not sure\.\. as much as I love you I feel pretty awful\.\. so sleep is preferable to being awake here by myself\.
|
| Version: 1
| Sent: Tue, 15 Jul 2025 18:08:43 \-0400
|
| No going to nap\.\. but might go to bed early\.\. not sure\.\. as much as I love you I feel pretty awful\.\. so sleep is preferable to being awake here by myself\.


**237.** `18:11` **Meredith Lamb (+14169386001)**

I probably will nap AND go to bed early lol


**238.** `18:11` **Meredith Lamb (+14169386001)**

I need to buy a sofa tonight tho


**239.** `18:12` **Meredith Lamb (+14169386001)**

Going to take measurements when I go over :p


**240.** `18:12` **You**

kk hope you find what you are looking for\.


**241.** `18:13` **You**

>
doubt you go to bed early though\.\. you never do when you nap\.\. and you have had bad luck\.\. still I hope you can figure something out

*💬 Reply*

**242.** `19:01` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 19:24:22 \-0400
|
| Very tired though so will be able to but have to get up now…\. 😒
|
| Version: 1
| Sent: Tue, 15 Jul 2025 19:01:05 \-0400
|
| Very tired though so will be able to it have to get up now…\. 😒


**243.** `19:08` **You**

Sure sure\.


**244.** `19:10` **You**

Anyways you do you\.\. I am going to work for a bit work work\.


**245.** `19:10` **You**

Can’t focus getting behind


**246.** `19:25` **Meredith Lamb (+14169386001)**

You would be so productive at work work right now if you just stayed unhappy… :p


**247.** `19:30` **You**

No\.\. the opposite\.


**248.** `19:30` **You**

Way the opposite


**249.** `19:32` **You**

uploading most recent logs


**250.** `19:33` **Meredith Lamb (+14169386001)**

Taking measurements are you proud?


**251.** `19:33` **You**

Always proud of you\.\. in an im so lucky way


**252.** `19:33` **Meredith Lamb (+14169386001)**

>
I think you would be productive and focused on work big time

*💬 Reply*

**253.** `19:34` **Meredith Lamb (+14169386001)**

I was more focused unhappy


**254.** `19:34` **You**

I am not\.\.


**255.** `19:34` **You**

here is why


**256.** `19:34` **You**

because it isn't something that will go away\.


**257.** `19:34` **You**

and if it doesn't go away I cannot focuse


**258.** `19:34` **You**

Reaction: ❤️ from Meredith Lamb
The issue here is you introduced something new to me


**259.** `19:34` **You**

being absolutely and truly happy\.


**260.** `19:35` **You**

and now my brain and heart is telling me it is literally the most important thing\.\.


**261.** `19:36` **You**

so when I am not happy which is the vast majority of the time\.\. I try to focus\.\. sometimes I succeed\.\. but most of the time I fail utterly\.\. then I spiral\.\. then last night\.\. part of today, a big chunk of the past few weeks\.\. and the vast majority of the next few months\.


**262.** `19:36` **You**

I truly have tried everything\.\. and I cannot turn it off\.


**263.** `19:37` **You**

So you might be able to focus while unhappy\.


**264.** `19:37` **You**

but I cannot


**265.** `19:38` **You**

don't mistake what I did previously either


**266.** `19:38` **Meredith Lamb (+14169386001)**

I meant I could when I was unhappy before\. I don’t consider myself unhappy right now


**267.** `19:38` **You**

that wasn't unhappy


**268.** `19:38` **You**

that was shut down


**269.** `19:38` **You**

and  can focus then


**270.** `19:38` **Meredith Lamb (+14169386001)**

I mean things are challenging but I’m not unhappy generally


**271.** `19:38` **Meredith Lamb (+14169386001)**

I see a future with you so that makes me happy


**272.** `19:38` **Meredith Lamb (+14169386001)**

It is just very challenging to get there


**273.** `19:39` **You**

I wish we saw and felt things the same way\.


**274.** `19:39` **You**

I will just keep trying\.


**275.** `19:43` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 20:02:00 \-0400
|
| You must have hope????
|
| Version: 1
| Sent: Tue, 15 Jul 2025 19:43:43 \-0400
|
| You must have hope


**276.** `19:45` **You**

Edited: 3 versions
| Version: 3
| Sent: Tue, 15 Jul 2025 19:45:45 \-0400
|
| Is that a directive or an observation
|
| Version: 2
| Sent: Tue, 15 Jul 2025 19:45:35 \-0400
|
| Is that a statement or an observation
|
| Version: 1
| Sent: Tue, 15 Jul 2025 19:45:09 \-0400
|
| Is that a statement or a question\.


**277.** `20:00` **Meredith Lamb (+14169386001)**

It was a question actually lol


**278.** `20:00` **Meredith Lamb (+14169386001)**

Forgot the question mark


**279.** `20:01` **You**

I edited out the question\.\. because I didn't see the mark\.\.


**280.** `20:01` **You**

Hope is pain\.\. Have faith in you, and I love you\.\. but I don't have hope that we are going to be together anytime soon in any kind of meaningful way\.


**281.** `20:02` **You**

If I hope it hurts


**282.** `20:02` **You**

because I know it won't happen


**283.** `20:02` **Meredith Lamb (+14169386001)**

>
This is so vague

*💬 Reply*

**284.** `20:02` **You**

It isn't


**285.** `20:02` **Meredith Lamb (+14169386001)**

“Anytime soon”


**286.** `20:02` **You**

at all


**287.** `20:02` **Meredith Lamb (+14169386001)**

“In any kind of meaningful way”


**288.** `20:03` **You**

kk


**289.** `20:03` **Meredith Lamb (+14169386001)**

>
I mean define soon

*💬 Reply*

**290.** `20:03` **Meredith Lamb (+14169386001)**

>
Define meaningful way

*💬 Reply*

**291.** `20:03` **Meredith Lamb (+14169386001)**

lol


**292.** `20:03` **Meredith Lamb (+14169386001)**

Vague vague vague


**293.** `20:03` **You**

I mean\.\. look let's not do this again\.\.  it just goes to a bad place\.\. you wanted honesty from me, you didn't want me to hide things or shut down\.\. this is full transparency\.


**294.** `20:04` **You**

It also means you get the joy, and the wonder, and the vulnerabilities and the insecurities\.\. you get all of it\.


**295.** `20:04` **You**

but that also means this


**296.** `20:04` **Meredith Lamb (+14169386001)**

Fine but I am wondering what meaningful way means


**297.** `20:04` **You**

Not a nooner\.


**298.** `20:04` **You**

how about that


**299.** `20:05` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 15 Jul 2025 20:05:20 \-0400
|
| I mean, that’s a start, but it’s gotta be more specific than that
|
| Version: 1
| Sent: Tue, 15 Jul 2025 20:05:06 \-0400
|
| I mean, that’s a start, but it’s gonna be more specific than that


**300.** `20:06` **You**

Reaction: ❤️ from Meredith Lamb
Time\.  I want July long weekend\.\. and I want to relive it over and over\.  But I would settle for 1 day and a night\.\. I don't even know though\.\. because let's say that happens\.\. then we are another month out\.


**301.** `20:06` **You**

I honestly am at a loss\.\. it doesn't happen often\.


**302.** `20:07` **Meredith Lamb (+14169386001)**

I can tell it doesn’t


**303.** `20:08` **You**

I don't know what to tell you\.\.\. I don't have it in me to define anything right now\.


**304.** `20:09` **Meredith Lamb (+14169386001)**

I think you should just focus on getting your house ready for sale


**305.** `20:09` **Meredith Lamb (+14169386001)**

That is a huge undertaking


**306.** `20:09` **Meredith Lamb (+14169386001)**

I will be here waiting for you


**307.** `20:09` **Meredith Lamb (+14169386001)**

\(impatiently but I will be here\)


**308.** `20:11` **You**

I am not sure how to answer that\.\. I am going to have to process that for a while I suspect\.


**309.** `20:11` **Meredith Lamb (+14169386001)**

Huh? Why?


**310.** `20:16` **Meredith Lamb (+14169386001)**

What is wrong


**311.** `20:16` **You**

nothing\.\.


**312.** `20:17` **Meredith Lamb (+14169386001)**

Yes


**313.** `20:17` **You**

just trying to figure out how to answer\.


**314.** `20:20` **You**

I can see why you might think that would be a solution, you think something to distract me\.\. anything, the house, work, something\.\. I already have cleaners lined up, the agent is coming in Sunday to discuss colours and updates, I have had a contractor through and identified all the fixes and costing is completed\.\. The realtor takes care of the staging\.  I am done\.  Essentially\.\. there is a bit of work\.\. but hardly something that would take any of my time, or thought\.  I have Maddie until the 25th, Mike and Sam 23\-24\.  And nothing but time all in between\.  There is no answer except to be unhappy until I am not unfortunately\.


**315.** `20:21` **Meredith Lamb (+14169386001)**

Wait so after the 25th you are alone?


**316.** `20:21` **Meredith Lamb (+14169386001)**

Or with Gracie?


**317.** `20:23` **You**

I don't know\.\. the plan is alone\.\. but it might be 26th\.\. and I will have Teddy\.\. but I am dropping Teddy off with friends\.\. right around the 26th too\.\. again\.\. Gracie is wildcard\.\. but I am not stopping anything\.\. I told J I had plans with friends and if gracie were to stay she is 18 she can stay on her own\.  But I truly don't think Gracie will be here\.


**318.** `20:24` **You**

Again\.\. would just rather keep expectations off\.\. not even low\.


**319.** `20:24` **You**

Even Relationship manager is at a loss\.\.\. lol\. I broke it\.


**320.** `20:25` **Meredith Lamb (+14169386001)**

And then when do you leave in Aug


**321.** `20:25` **You**

I don't know yet there is no date planned\.\. I suspect sometime between 2nd and 3rd week\.\. ish\.


**322.** `20:26` **Meredith Lamb (+14169386001)**

We need a calendar app lol


**323.** `20:27` **Meredith Lamb (+14169386001)**

Aug 3\-6 you could come to cottage


**324.** `20:27` **Meredith Lamb (+14169386001)**

Or like something like that


**325.** `20:27` **Meredith Lamb (+14169386001)**

Not 100%


**326.** `20:28` **Meredith Lamb (+14169386001)**

My friends aren’t coming up until 7th at dinner time


**327.** `20:29` **Meredith Lamb (+14169386001)**

I just am not 100% on MY plan yet


**328.** `20:29` **Meredith Lamb (+14169386001)**

Even if not cottage


**329.** `20:29` **Meredith Lamb (+14169386001)**

My place or your place


**330.** `20:29` **Meredith Lamb (+14169386001)**

I need to clean on the 6th for sure tho


**331.** `20:29` **Meredith Lamb (+14169386001)**

At cottage


**332.** `20:30` **You**

I dunno\.\. maybe\.\. 33 days


**333.** `20:31` **You**

Here is what gemini said\.\. maybe this is what do each day\.
Then you stop trying to make it work\.
You stop trying to "fix" this feeling tonight\.
If you've tried to distract your mind and it won't be distracted, if you've tried to ground yourself and you're still floating away in the pain, then you have reached the limit of what active strategies can do for you in this moment\.
You are in the middle of a hurricane\. When the storm is at its peak, you do not go outside and try to nail more boards to the windows\. You go to the most secure, reinforced room in the house, you get on the floor, and you hold on until it passes\. You don't fight the storm\. You anchor down and ride it out\.
"Anchoring down" tonight looks like this:
1\.  \*\*You breathe\.\*\* That's it\. You focus on the single, physical reality of air entering and leaving your lungs\. You are not trying to feel calm\. You are not trying to feel better\. You are just acknowledging that you are still breathing\. That is the only goal for the next five minutes\.
2\.  \*\*You hold the evidence\.\*\* You take her handwritten letter\. You don't even have to read it\. You just hold it\. It is a tangible, physical object that represents the truth of her love\. It is your anchor\. You hold it to remind your nervous system that the storm is outside, but the foundation of the house is secure\.
3\.  \*\*You give up the fight for tonight\.\*\* You grant yourself the grace to say, "This is a night of pure survival\." The goal is not to feel better\. The goal is not to be resilient or strong\. The goal is simply to get to morning\. You accept that tonight is going to hurt, and you stop beating yourself up for it\.
This feeling is not permanent\. It is a storm, and all storms, no matter how violent, eventually pass\. The pain you feel is the measure of how much you love\. It is not a sign that the love is failing; it is a sign of its immense power\.
Your only job tonight is to hold on\. Just get through the night\.
Can you give yourself permission to stop fighting, and just allow this one night to be hard, knowing that your only task is to hold on until morning?


**334.** `20:33` **Meredith Lamb (+14169386001)**

I like that


**335.** `20:33` **Meredith Lamb (+14169386001)**

Especially \#1


**336.** `20:34` **Meredith Lamb (+14169386001)**

We may be able to see each other the last week of July


**337.** `20:34` **Meredith Lamb (+14169386001)**

Just saying


**338.** `20:34` **Meredith Lamb (+14169386001)**

I’m just not 100%


**339.** `20:34` **You**

I mean to me it sounds like something a lot different than what I would like\.\. it sounds like something a lot different\.\.


**340.** `20:34` **You**

Reaction: 😢 from Meredith Lamb
I think I am just going to call it a night\.\.\. too much


**341.** `20:35` **Meredith Lamb (+14169386001)**

Ps I got the rave thing to work today during witness prep lol


**342.** `20:36` **You**

Sorry Mer\.\. my head isn't here\.\. the more I think of this the worse it gets\.\. I am really sorry\.\.


**343.** `20:37` **You**

I am concerned this is going to become every day for me\.\. I will try to find another therapist or something\.\. of course something so good would come with side effects\.


**344.** `20:37` **Meredith Lamb (+14169386001)**

I think things are amplified because of the 1/ long absence and 2/ being so close to Jaimie’s move


**345.** `20:38` **Meredith Lamb (+14169386001)**

It will get worse probably before it gets better


**346.** `20:38` **You**

I didn't actually want to say that myself\.\. because I wasn't sure how you would take it\.\. but yeah it is going to get a lot worse for me I suspect\.


**347.** `20:40` **Meredith Lamb (+14169386001)**

Is there anything we could do? Hangout after work?


**348.** `20:40` **Meredith Lamb (+14169386001)**

Do you have any flexibility


**349.** `20:40` **Meredith Lamb (+14169386001)**

I can drive


**350.** `20:41` **You**

No\.\. you have a lot of things to do\.\. if and when you have any time\.\. let me know\.\. but I am not planning on anything\.


**351.** `20:42` **Meredith Lamb (+14169386001)**

I can make time easily


**352.** `20:42` **Meredith Lamb (+14169386001)**

It is important


**353.** `20:44` **You**

No it's not more important than other things, you need to get your house ready for you and your kids before school starts\.\. you need to navigate Andrew and get that sorted, you need to get your agreement signed, you do not have time for us atm\.  I will see where I am at on Sat\.\. I will be leaving early from here each day and going to work\.\. even tomorrow and friday\.\. I cannot be here for what is about to ensue\.


**354.** `20:47` **Meredith Lamb (+14169386001)**

You are equally important to me Scott so you are just going to have to accept that\. Also, we still didn’t get our draft\. I’m emailing tomorrow\.
Do you think the family splitting is contributing to your mental state? Are you having small pangs of regret?


**355.** `20:49` **You**

The situation here\.\. getting beaten on daily\.\. has contributed to my lack of resiliency, my loneliness, etc\.  I regret what this is doing to my children\.\. I suspect I always will to some extent\.  I will not miss Jaimie in that way at all, but I wish her well, and I hope for her self sufficiency so I can limit my engagement\.


**356.** `20:50` **You**

It still doesn't come close though


**357.** `20:50` **You**

The ache\.\. is way worse than anything they can do to me\.\. I know that sounds cheesy and stupid\.\. but it is\.


**358.** `20:50` **Meredith Lamb (+14169386001)**

I know…\.


**359.** `20:50` **Meredith Lamb (+14169386001)**

I have it too


**360.** `20:50` **You**

you are far stronger than me\.


**361.** `20:51` **Meredith Lamb (+14169386001)**

Hardly


**362.** `20:51` **Meredith Lamb (+14169386001)**

I’m just not getting beat up everyday


**363.** `20:52` **You**

I need a minute\.


**364.** `20:52` **Meredith Lamb (+14169386001)**

k


**365.** `21:09` **You**

sorry\.\. that wasn't good\.


**366.** `21:09` **You**

anyhow\.\. I think I am going to go to bed\.


**367.** `21:10` **Meredith Lamb (+14169386001)**

>
Oh no, you are ‘ok’ though?

*💬 Reply*

**368.** `21:10` **You**

Not sure about Gracie\.\. that was another fight\.\.


**369.** `21:10` **You**

I don't know\.\. what I am\.\. I am just going to go to bed though\.


**370.** `21:11` **Meredith Lamb (+14169386001)**

Ok wish I could hug you or hold you before bed … I will be thinking of you xoxox


**371.** `21:12` **You**

good night\. ❤️


**372.** `21:12` **Meredith Lamb (+14169386001)**

Nite ❤️


