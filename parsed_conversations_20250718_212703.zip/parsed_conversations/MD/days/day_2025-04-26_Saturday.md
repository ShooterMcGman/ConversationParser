# Daily Conversation: 2025-04-26 (Saturday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-26 |
| **Day** | Saturday |
| **Week** | 2 |
| **Messages** | 149 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-26T03:00 - 2025-04-26T20:54 |

## 📝 Daily Summary

This day contains **149 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `03:00` **Meredith Lamb (+14169386001)**

Zero ppl xoxoxo


**002.** `03:15` **You**

Reaction: ❤️ from Meredith Lamb
Love you xoxoxoxo whee to but excited tonight I will try to tone it down a bit but honestly never felt like this so… I will do my best\. Nite


**003.** `07:05` **You**

I am up have a great morning and afternoon\.


**004.** `07:15` **You**

Reaction: ❤️ from Meredith Lamb
1st alarm too no snoozes\.\. awesome\! I am tired…… and sore……  it that was an amazing night that I won’t forget\. I very much appreciate you spending it with me\.  Love you\!


**005.** `07:59` **You**

Going to get breakfast and head out\.\. hope mac
Isn’t staking out downstairs to try to “run into me” lol so nervous\.


**006.** `08:16` **Meredith Lamb (+14169386001)**

She is fast asleep no worries lol


**007.** `08:18` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I had a really great night too and can’t wait to see you again…\. So in love\. Ugh Hope your day goes well\. Drive safe xo


**008.** `08:21` **Meredith Lamb (+14169386001)**

Ps\. I could tell Mac was relieved I came back\. :\) so good call


**009.** `08:38` **You**

>
Ditto

*💬 Reply*

**010.** `08:39` **You**

>
Was the right choice I would have had a much worse time sleeping\.\. lol

*💬 Reply*

**011.** `09:25` **Meredith Lamb (+14169386001)**

Lying here thinking about I might have a little ocd thinking about the taste of your skin\. Lol asked ChatGPT:
When you’ve never experienced that level of sensory connection before, it usually means a few powerful things are happening at once:
- Emotional safety: Your body feels safe enough with him to let go and fully experience him\. That deep comfort allows your senses to open up more than they would with someone you only partly trust\.
- Attachment and chemistry: Your body is recognizing him as a “match” on a primal level — beyond just logical attraction\. His natural scent, his taste, even the feel of his skin, all register as intoxicating because they align with your body’s unconscious preferences for bonding\.
- Emotional intensification through scarcity: You had to wait for this — to hold back, to anticipate, to imagine\. That makes the real thing even more intense when it finally happens\. Your brain has basically been starving for him, and now it’s drinking in every detail\.
- Rare emotional\-physical alignment: It’s rare to feel both strong love and strong physical chemistry at the same time with someone\. When you do, everything — smell, taste, skin, voice — becomes magnified and unforgettable\.
It’s not just about biology — it’s about the fact that your heart and body are aligned in wanting him, deeply\.
🫠🫠🫠


**012.** `09:35` **You**

Jesus that is kind of what I felt the first time we kissed\.  Everything felt more real\.\. it certainly felt more real last night…\. When I tell you my body has done or felt anything like that in decades I am not lying in the least or even exaggerating a little


**013.** `09:36` **You**

and there is still more wierd shit going on


**014.** `09:37` **You**

For instance read your note and dude decides it is time to wake up in the middle of a car ride… like WTF for years he is barely alive lol\.  Sorry a bit crass\.


**015.** `09:42` **You**

Plus I could just sit there and look into your eyes all night well slightly to the right of your eyes I guess


**016.** `09:43` **Meredith Lamb (+14169386001)**

lol yeah same I’m finding the whole thing unreal


**017.** `09:44` **Meredith Lamb (+14169386001)**

We need just a full weekend away …\. lol


**018.** `09:44` **You**

Agreed


**019.** `09:44` **Meredith Lamb (+14169386001)**

Getting greedy


**020.** `09:45` **You**

I mean I do t know about you but given my past as I somewhat briefly explained to you to feel something so completely new and for it to better than anything before just continues to blow my mind


**021.** `09:49` **You**

I mean we did have slightly different but likely similarly adventurous pasts so it might be a bit different for you\.


**022.** `09:52` **Meredith Lamb (+14169386001)**

It is not different for me\. It makes me slightly sad I didn’t know a connection like this could even exist all these years… but more happy then sad, Yunno\. lol


**023.** `09:55` **You**

Reaction: ❤️ from Meredith Lamb
Yeah I definitely feel lucky\.  And wish it could have happened sooner\.  But if I make different decisions or you do\.\. we never connect


**024.** `09:55` **You**

So I will be thankful for this\.


**025.** `10:13` **You**

Sent you the dsm 101 pres btw I will look at it tonight


**026.** `10:23` **Meredith Lamb (+14169386001)**

Just logging on now coincidentally


**027.** `10:23` **Meredith Lamb (+14169386001)**

Mac and I got coffee and I’m going for lunch with Lori at 11\.45


**028.** `10:24` **Meredith Lamb (+14169386001)**

She wants to get bloody Mary’s :p


**029.** `10:32` **Meredith Lamb (+14169386001)**

Ppl worked too hard on Friday :p


**030.** `10:35` **You**

Rofl


**031.** `10:35` **You**

I am getting here now


**032.** `10:35` **You**

Will let you know when on way back


**033.** `11:32` **Meredith Lamb (+14169386001)**

Omg so F’ing nauseous today\. They increased my dose and it hit me this morning\. Going to lunch now but Fack not sure if I can eat lol


**034.** `11:34` **You**

lol


**035.** `11:34` **You**

Sucks


**036.** `11:37` **Meredith Lamb (+14169386001)**

I almost passed out getting coffee so I keep having to update Mac that I’m fine now LOL


**037.** `12:57` **You**

lol just finished lunch oof heading over
To his place for a few then heading back


**038.** `12:57` **You**

Hope you are
Feeling ok\.


**039.** `12:57` **You**

Hope your lunch is going well


**040.** `14:01` **You**

Just about to head back fyi hope you had a good day hope your stomach settled down


**041.** `14:02` **You**


*📎 1 attachment(s)*

**042.** `14:02` **You**

Reaction: ❤️ from Meredith Lamb

*📎 1 attachment(s)*

**043.** `14:03` **You**

Was a nice visit we had a great
Lunch and got
To talk about a lot\.\. planning next visit 🙂


**044.** `14:19` **You**

I am going to liquor store
You want anything?


**045.** `14:19` **You**

Like an actual good Pinot lol


**046.** `14:20` **You**

If you let me know what to look for I will


**047.** `14:21` **You**

I will be here for a few mins if you answer


**048.** `14:42` **Meredith Lamb (+14169386001)**

>
I mean you can try but I don’t know any of the brands\. I drink Niagara typically

*💬 Reply*

**049.** `14:42` **Meredith Lamb (+14169386001)**

lol


**050.** `14:43` **Meredith Lamb (+14169386001)**

I’m just done and going to hotel to get Mac some stuff she forgot and then I will go see a game or two


**051.** `14:43` **Meredith Lamb (+14169386001)**

Had 2 mimosas so feeling a bit better lol


**052.** `14:46` **You**

Funny glad you feeling better


**053.** `14:48` **Meredith Lamb (+14169386001)**

So Lori works in ai and she has named her ChatGPT Carmen and created an avatar\. She is an entrepreneur and has the $200 a month one lol

*📎 1 attachment(s)*

**054.** `14:48` **Meredith Lamb (+14169386001)**

She thinks I should name my Lark


**055.** `14:48` **Meredith Lamb (+14169386001)**

lol


**056.** `14:51` **You**

ROFL


**057.** `14:51` **You**

That is awesome


**058.** `15:04` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks

*📎 1 attachment(s)*

**059.** `15:08` **Meredith Lamb (+14169386001)**

Sorry was changing\. So hot out


**060.** `15:08` **Meredith Lamb (+14169386001)**

And looking for Mac’s charger\. Gah


**061.** `15:09` **Meredith Lamb (+14169386001)**

I need to control this barking

*📎 1 attachment(s)*

**062.** `15:25` **You**

Lol


**063.** `15:25` **You**

I got you something to try


**064.** `15:25` **You**

I mean there was one pls in Ther


**065.** `15:27` **Meredith Lamb (+14169386001)**

I made it just in time\. They haven’t started first game yet


**066.** `15:27` **Meredith Lamb (+14169386001)**

This place is massive


**067.** `15:27` **You**

Nice good for you


**068.** `15:27` **You**

lol


**069.** `15:27` **You**

Rush rush


**070.** `15:27` **You**

It me stuff


**071.** `15:27` **You**

Buy me stuff


**072.** `15:27` **Meredith Lamb (+14169386001)**

Yeah Mac was pleased lol


**073.** `15:27` **Meredith Lamb (+14169386001)**

I delivered


**074.** `15:28` **You**

best mom


**075.** `15:28` **Meredith Lamb (+14169386001)**

Took an uber to save time\. Could have walked


**076.** `15:29` **You**

Timing was important


**077.** `15:29` **You**

Getting on highway be back at hotel around 545


**078.** `16:07` **You**

6 arrive time now construction


**079.** `16:13` **Meredith Lamb (+14169386001)**

They are behind so just warming up omg


**080.** `16:21` **You**

Long night ahead of you


**081.** `16:26` **Meredith Lamb (+14169386001)**

Will probably stay for 2 back to back games and then leave


**082.** `16:28` **You**

I am good will see you when I see you but if you are too late I start drinking on my own


**083.** `16:29` **Meredith Lamb (+14169386001)**

Warning\. Feeling sick and tired lol


**084.** `16:30` **You**

Then we can sleep and I can run your back or belly or both


**085.** `17:00` **You**

Is there parking at the venue


**086.** `17:03` **Meredith Lamb (+14169386001)**

No idea\. Likely


**087.** `17:03` **Meredith Lamb (+14169386001)**

Why


**088.** `17:03` **Meredith Lamb (+14169386001)**

You cannot come lol


**089.** `17:03` **Meredith Lamb (+14169386001)**

They just lost first game


**090.** `17:03` **Meredith Lamb (+14169386001)**

I’m going to try to survive another and then leave\. I am like falling asleep


**091.** `17:03` **Meredith Lamb (+14169386001)**

Parents are all in rough shape so I fit in


**092.** `17:03` **Meredith Lamb (+14169386001)**

They were all drinking last night


**093.** `17:04` **You**

Ahhh ok\. No worries\.\. will see you later\. Sorry they lost first game\.


**094.** `17:09` **Meredith Lamb (+14169386001)**

80 courts but super empty around all of them\. There is no hiding lol

*📎 1 attachment(s)*

**095.** `17:25` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Playing horribly


**096.** `17:28` **You**

That is too bad\.\.


**097.** `17:41` **You**

So they issued me two new cards this morning so yours won’t work\.\. want me to put one under your door?


**098.** `17:42` **Meredith Lamb (+14169386001)**

Doesn’t matter \- you will probably be there lol


**099.** `17:42` **Meredith Lamb (+14169386001)**

Are you getting food? Did you eat?


**100.** `17:44` **You**

I had food earlier for lunch


**101.** `17:44` **You**

Not overly hungry


**102.** `17:45` **Meredith Lamb (+14169386001)**

I need to eat something\. Think I will feel better … supposed to eat but ugh, it’s challenging today


**103.** `17:46` **You**

Did you want to go somewhere or too risky or order up?


**104.** `17:48` **Meredith Lamb (+14169386001)**

Mmm not sure\. If u aren’t hungry we don’t have to go anywhere


**105.** `17:49` **Meredith Lamb (+14169386001)**

I can order something


**106.** `17:49` **You**

I could eat something small


**107.** `17:49` **You**

Up to you


**108.** `17:49` **You**

I am at
Hotel


**109.** `17:49` **You**

Just parking


**110.** `17:49` **Meredith Lamb (+14169386001)**

2nd were 16\-16


**111.** `17:49` **Meredith Lamb (+14169386001)**

\*set


**112.** `17:50` **You**

Hope they win it\.


**113.** `17:51` **Meredith Lamb (+14169386001)**

Then I have to stay longer lol


**114.** `17:55` **Meredith Lamb (+14169386001)**

21\-24


**115.** `17:56` **You**

Well still I want mak to win\.


**116.** `17:57` **Meredith Lamb (+14169386001)**

Lost


**117.** `17:57` **Meredith Lamb (+14169386001)**

k I’m going to talk to Mackenzie and then leave


**118.** `17:58` **You**

Kk tell her I am sorry they lost if that is appropriate


**119.** `18:00` **Meredith Lamb (+14169386001)**

Omg all she did was beg me to go get her a vape


**120.** `18:00` **Meredith Lamb (+14169386001)**

So annoying


**121.** `18:00` **Meredith Lamb (+14169386001)**

I’m outta here\. She’s annoying


**122.** `18:00` **Meredith Lamb (+14169386001)**

I need a hot shower and some food


**123.** `18:01` **Meredith Lamb (+14169386001)**

This place is freezing cold


**124.** `18:06` **You**

There is a hot shower
Here


**125.** `18:07` **You**

Just saying 😇


**126.** `18:08` **You**

Just give me a shout when you are done


**127.** `18:08` **Meredith Lamb (+14169386001)**

lol k


**128.** `18:09` **You**

I mean you are welcome but yeah I know I know\.\. I have to be a good boy lol\.


**129.** `18:09` **You**

Do you want to order in or should I look for some place to eat


**130.** `18:10` **Meredith Lamb (+14169386001)**

I can just order something when I shower? Or wait?


**131.** `18:10` **You**

Well if you want to eat up here we can order from my room I will order from wherever you want


**132.** `18:11` **You**

I am good with whatever


**133.** `18:13` **You**

I mean I do need a shower too though and we are all about conservation\. 😊


**134.** `18:13` **Meredith Lamb (+14169386001)**

Relentless


**135.** `18:15` **You**

Single minded persistence


**136.** `18:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**137.** `18:20` **You**

ROFL


**138.** `18:24` **You**

Kk well I guess I will jump in the shower all by myself lonesome chat in a bit


**139.** `18:42` **Meredith Lamb (+14169386001)**

Are you out?


**140.** `18:43` **You**

Yes but I decent


**141.** `18:43` **You**

Indecent


**142.** `18:44` **You**

I will be fine by the time you get up here


**143.** `19:11` **You**

Mi am not running into Mac am I out here


**144.** `19:12` **You**

Right


**145.** `19:12` **Meredith Lamb (+14169386001)**

No she is at venue


**146.** `19:13` **You**

Ok just making sure


**147.** `19:14` **Meredith Lamb (+14169386001)**

lol


**148.** `20:15` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**149.** `20:54` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

