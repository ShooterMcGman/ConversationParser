# Daily Conversation: 2025-05-09 (Friday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-09 |
| **Day** | Friday |
| **Week** | 4 |
| **Messages** | 162 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-09T06:25 - 2025-05-09T18:22 |

## 📝 Daily Summary

This day contains **162 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `06:25` **You**

Nah ignore you don’t have to answer that too personal 😝


**002.** `07:56` **Meredith Lamb (+14169386001)**

Not sure \- you will have to let me experience both\. Then I can tell you\. Scientific analysis


**003.** `07:56` **Meredith Lamb (+14169386001)**

So I woke up at 4am and couldn’t sleep


**004.** `07:56` **Meredith Lamb (+14169386001)**

Gahhhhhh


**005.** `07:56` **Meredith Lamb (+14169386001)**

Insomnia


**006.** `07:56` **You**

What is wrong


**007.** `07:57` **You**

What are you worried about


**008.** `07:57` **Meredith Lamb (+14169386001)**

So I took melatonin


**009.** `07:57` **You**

You are going to be tired tonight\.\. we can take it easy


**010.** `07:57` **Meredith Lamb (+14169386001)**

No I will be on


**011.** `07:57` **You**

Just cuddle me and handmaids take


**012.** `07:57` **You**

🙂


**013.** `07:57` **Meredith Lamb (+14169386001)**

I was thinking about switching roles


**014.** `07:58` **Meredith Lamb (+14169386001)**

Totally ok with it but thinking about explaining it to EVERYONE


**015.** `07:58` **You**

Worried


**016.** `07:58` **Meredith Lamb (+14169386001)**

just the explaining to 100 ppl


**017.** `07:58` **You**

You will need to explain the personal side


**018.** `07:58` **You**

Not 100


**019.** `07:58` **You**

Your team


**020.** `07:58` **You**

It will trickle around


**021.** `07:58` **Meredith Lamb (+14169386001)**

Sales


**022.** `07:58` **You**

But nothing you have to do behind that


**023.** `07:58` **Meredith Lamb (+14169386001)**

Marketing


**024.** `07:58` **Meredith Lamb (+14169386001)**

Bailey


**025.** `07:58` **You**

No you don’t have to explain


**026.** `07:58` **You**

But bailey yeah


**027.** `07:58` **You**

Still no biggy


**028.** `07:59` **Meredith Lamb (+14169386001)**

Shailley


**029.** `07:59` **Meredith Lamb (+14169386001)**

Everyone


**030.** `07:59` **You**

I think you are overthinking


**031.** `07:59` **Meredith Lamb (+14169386001)**

I am not overthinking\. It is just part of it


**032.** `07:59` **You**

But if you want to stay that is completely fine with me the team loves you


**033.** `07:59` **Meredith Lamb (+14169386001)**

No no


**034.** `07:59` **You**

And I think you are a great leader


**035.** `07:59` **Meredith Lamb (+14169386001)**

It is just part of the process


**036.** `08:00` **You**

Ok let me know what I can do to help\.\. for my part I have a convo with soohear in 5 mins to test the waters\.


**037.** `08:00` **You**

I figured you are all in on this and I need mon downtime


**038.** `08:00` **You**

Min


**039.** `08:00` **Meredith Lamb (+14169386001)**

It is just something my brain has to process and unfortunately sometimes that happens at 4am


**040.** `08:01` **You**

That sucks


**041.** `08:01` **Meredith Lamb (+14169386001)**

During Covid I had insomnia


**042.** `08:01` **You**

My brain went dead last night massive blow up with Gracie


**043.** `08:01` **You**

Then went to bed after
Midnight


**044.** `08:02` **Meredith Lamb (+14169386001)**

Same thing with her?


**045.** `08:06` **You**

Yep


**046.** `08:56` **You**

Wow we are literal at the finish line and she flipping again\.\. cannot believe it\.


**047.** `08:58` **Meredith Lamb (+14169386001)**

Jaime?


**048.** `08:58` **You**

Yah


**049.** `08:58` **Meredith Lamb (+14169386001)**

Last minute cold feet


**050.** `08:59` **You**

Yep


**051.** `08:59` **Meredith Lamb (+14169386001)**

It’s a huge change\. Not surprised really


**052.** `08:59` **You**

Says I am not giving her options


**053.** `08:59` **You**

I dunno what to do\.\. back to renting I think


**054.** `08:59` **You**

But it will be much much much sooner


**055.** `08:59` **Meredith Lamb (+14169386001)**

“Options”


**056.** `08:59` **Meredith Lamb (+14169386001)**

Hmm


**057.** `09:00` **Meredith Lamb (+14169386001)**

There aren’t TOO many options really


**058.** `09:00` **You**

I know


**059.** `09:00` **You**

Brb driving maddie


**060.** `10:19` **Meredith Lamb (+14169386001)**

Was sophear interested?


**061.** `11:01` **You**

Nope I mean yep but I think there might be a mgr role coming up on elder side she doesn’t want to miss out o \.


**062.** `11:11` **Meredith Lamb (+14169386001)**

Gah


**063.** `11:59` **You**

It’s fine Mia manyu is also interested


**064.** `11:59` **You**

And a few others I think


**065.** `12:03` **You**

Not saying this in teams but I am def not worth it\.\. too much driving


**066.** `12:07` **Meredith Lamb (+14169386001)**

Omg stop it


**067.** `12:07` **You**

Omg…\.\. just stop it\!\!


**068.** `12:09` **Meredith Lamb (+14169386001)**

Well seriously


**069.** `12:09` **Meredith Lamb (+14169386001)**

Not necessary


**070.** `12:10` **You**

lol I am just saying I appreciate it\.\. it is a lot of
Trouble


**071.** `12:13` **Meredith Lamb (+14169386001)**

Tell octo that bc I’m going to be late for his 1pm lol


**072.** `12:14` **You**

Ok


**073.** `12:14` **Meredith Lamb (+14169386001)**

I already warned him


**074.** `12:14` **You**

Then I won’t again or it would be weird


**075.** `12:14` **Meredith Lamb (+14169386001)**

I was kidding


**076.** `12:15` **You**

Now I am confused lol warn not warn\.\. go have a nap?


**077.** `12:15` **Meredith Lamb (+14169386001)**

Do not


**078.** `12:15` **Meredith Lamb (+14169386001)**

I did already


**079.** `12:16` **Meredith Lamb (+14169386001)**

Shit I forgot my gummies lol


**080.** `12:16` **You**

Rofl


**081.** `12:17` **Meredith Lamb (+14169386001)**

I knew I forgot something


**082.** `12:17` **You**

You can buy some dispensaries all over oshawa


**083.** `12:17` **Meredith Lamb (+14169386001)**

lol


**084.** `12:17` **Meredith Lamb (+14169386001)**

But they are specific


**085.** `12:17` **Meredith Lamb (+14169386001)**

But yeah


**086.** `12:17` **Meredith Lamb (+14169386001)**

I don’t need them lol


**087.** `12:19` **You**

Tell me what they are I will pick some up


**088.** `12:23` **Meredith Lamb (+14169386001)**

Nah I don’t need them


**089.** `12:24` **Meredith Lamb (+14169386001)**

I can get them tomorrow for tomorrow night lol


**090.** `12:24` **You**

lol ok


**091.** `12:25` **Meredith Lamb (+14169386001)**

I do want to have a couple \(?\) drinks tho\. And didn’t bring anything so will have to pick up\. Which is fine\. I have no meetings past 2\.30


**092.** `12:27` **You**

I can also stop I was going to get something for myself anyways and Pinot for yku if you weren’t grabbing g any\.


**093.** `12:47` **Meredith Lamb (+14169386001)**

What is with traffic at Salem rd omg


**094.** `12:53` **You**

Dunno been shit last few days


**095.** `13:09` **Meredith Lamb (+14169386001)**

Ugh forgot my power cord lol


**096.** `13:09` **Meredith Lamb (+14169386001)**

I have 3 hrs on my laptop and that’s it


**097.** `13:09` **Meredith Lamb (+14169386001)**

Should be fine


**098.** `13:10` **You**

I will bring my power cord to place
Tonight if you want to charge for weekend


**099.** `13:10` **You**

Well bringing laptop anyways for tomorrow


**100.** `13:25` **Meredith Lamb (+14169386001)**

I don’t need it


**101.** `13:25` **Meredith Lamb (+14169386001)**

I will just need a phone charger


**102.** `13:25` **Meredith Lamb (+14169386001)**

lol


**103.** `13:25` **You**

I know but I will because I will be working


**104.** `13:25` **Meredith Lamb (+14169386001)**

I basically forgot everything


**105.** `13:25` **You**

I have a phone charger


**106.** `13:25` **Meredith Lamb (+14169386001)**

Kidding


**107.** `13:26` **Meredith Lamb (+14169386001)**

K good


**108.** `13:26` **You**

In meetings for a bit then heading out after I meet with Ian\.\.


**109.** `13:40` **Meredith Lamb (+14169386001)**

k


**110.** `13:41` **Meredith Lamb (+14169386001)**

Keep me updated


**111.** `13:41` **You**

Will do


**112.** `15:15` **You**

Making progress


**113.** `15:15` **You**

Oh we got the house


**114.** `15:15` **You**

Fyi


**115.** `15:16` **Meredith Lamb (+14169386001)**

The mansion?


**116.** `15:16` **You**

Yep


**117.** `15:21` **Meredith Lamb (+14169386001)**

How are you feeling?


**118.** `15:48` **You**

Can I call


**119.** `15:53` **Meredith Lamb (+14169386001)**

Sure I’m cleaning my moms basement


**120.** `15:57` **You**

Sec just lcbo


**121.** `16:09` **You**

Holy fuck I want to leave just doing some shit for fam because that’s me \.\.


**122.** `16:10` **You**

I am very impatient atm
Ground it out all day to avoid this


**123.** `16:12` **You**

Morgan wallen came on radio at subway…\. lol


**124.** `16:12` **You**

Universe telling me to hurry up


**125.** `16:12` **Meredith Lamb (+14169386001)**

I’m cleaning for my mom lol


**126.** `16:12` **You**

She is probably happy to have you there anyways


**127.** `16:17` **Meredith Lamb (+14169386001)**

Yeah for sure\. What time are you thinking\. I’m good with whatever


**128.** `16:28` **You**

I am leaving now have to make a stop otw haven’t earn not sure what to do the


**129.** `16:35` **Meredith Lamb (+14169386001)**

I can’t interpret the end of that msg\. Grammar lol


**130.** `16:36` **You**

Sec


**131.** `16:37` **Meredith Lamb (+14169386001)**

Just talking to my parents


**132.** `16:44` **You**

Kk sorry getting blasted with teams calls


**133.** `16:45` **You**

I said I hadn’t eaten not sure what to do


**134.** `16:47` **Meredith Lamb (+14169386001)**

We can order?


**135.** `16:47` **Meredith Lamb (+14169386001)**

I haven’t eaten either


**136.** `17:04` **You**

Kk I am heading to location\. Now should be there in 10
Mins


**137.** `17:05` **You**

Want me to pick you up


**138.** `17:08` **Meredith Lamb (+14169386001)**

No I’ll drive myself


**139.** `17:08` **Meredith Lamb (+14169386001)**

lol


**140.** `17:10` **You**

I checked there were 2 spots


**141.** `17:10` **You**

For parking


**142.** `17:10` **Meredith Lamb (+14169386001)**

I have to vacuum the upper floor


**143.** `17:10` **Meredith Lamb (+14169386001)**

Will do that now


**144.** `17:10` **You**

lol


**145.** `17:10` **You**

Edited: 2 versions
| Version: 2
| Sent: Fri, 9 May 2025 17:39:56 \-0400
|
| K
|
| Version: 1
| Sent: Fri, 9 May 2025 17:10:56 \-0400
|
| Ok


**146.** `17:11` **Meredith Lamb (+14169386001)**

Have just been talking to me parents


**147.** `17:11` **Meredith Lamb (+14169386001)**

\*my


**148.** `17:11` **You**

All good


**149.** `17:11` **You**

Did you tell them j bought a house


**150.** `17:20` **You**

I am here it is literally straight ahead when you get to cedar point road my rental is in yard just park behind I think should be fine


**151.** `17:22` **You**

Cozy


**152.** `17:23` **You**

Walk around right side of house down the steps take a left second set of sliding doors and they are open


**153.** `17:23` **You**

I might grab a shower


**154.** `17:35` **You**

Sorry unintentional


**155.** `17:39` **Meredith Lamb (+14169386001)**

K I will probably leave in like 10
Min or so


**156.** `17:40` **You**

K


**157.** `17:45` **Meredith Lamb (+14169386001)**

What is the address


**158.** `17:46` **You**

264 Cedar Valley Blvd, Oshawa, ON, L1G 3W1 Canada


**159.** `18:21` **You**

You ok lol?


**160.** `18:22` **Meredith Lamb (+14169386001)**

On my way sorry


**161.** `18:22` **You**

Sok take your time if you want to hang with parents


**162.** `18:22` **You**

Totally understand


