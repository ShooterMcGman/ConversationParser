# Daily Conversation: 2025-06-08 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-08 |
| **Day** | Sunday |
| **Week** | 9 |
| **Messages** | 1016 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-08T00:00 - 2025-06-08T22:24 |

## 📝 Daily Summary

This day contains **1016 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

There is a game called "I Never"  we will never play that game together or with others\.\. or at least I won't and I won't watch you\.


**002.** `00:00` **Meredith Lamb (+14169386001)**

Why?


**003.** `00:00` **Meredith Lamb (+14169386001)**

Maybe it is online


**004.** `00:00` **You**

the game is a drinking game


**005.** `00:00` **Meredith Lamb (+14169386001)**

I feel like that is a Corrie Morton game


**006.** `00:00` **You**

it is


**007.** `00:00` **Meredith Lamb (+14169386001)**

lol


**008.** `00:01` **You**

I never had sex at work \- take a drink\.


**009.** `00:01` **You**

stuff like that


**010.** `00:01` **Meredith Lamb (+14169386001)**

We could play it


**011.** `00:01` **You**

no


**012.** `00:01` **Meredith Lamb (+14169386001)**

Why


**013.** `00:01` **Meredith Lamb (+14169386001)**

I never have had sex at work


**014.** `00:01` **You**

because too much detail\.\. and it could get kinda sketchy


**015.** `00:01` **You**

I have


**016.** `00:01` **Meredith Lamb (+14169386001)**

I have not


**017.** `00:01` **Meredith Lamb (+14169386001)**

See?


**018.** `00:01` **Meredith Lamb (+14169386001)**

We good


**019.** `00:01` **You**

so I would drink in that case


**020.** `00:02` **You**

kk you don't have the same imagination I have\.\. It could go to some fucked up places and I know you don't care about my answers


**021.** `00:02` **You**

but I might have a hard time with yours\.\. maybe someday I won't mer\.\. god I hope so\.


**022.** `00:02` **Meredith Lamb (+14169386001)**

I do care


**023.** `00:02` **You**

lol


**024.** `00:02` **Meredith Lamb (+14169386001)**

I like to learn


**025.** `00:03` **You**

if this is what you meant by open\.\. I am really going to have to try hard\.\. and maybe do some serious drugs


**026.** `00:03` **Meredith Lamb (+14169386001)**

In the App Store there are a lot of never have I ever games


**027.** `00:03` **You**

ok\.\. I have a game


**028.** `00:04` **You**

you can ask me whatever questions you want\.\. and I will tell you the truth


**029.** `00:04` **Meredith Lamb (+14169386001)**

>
I mean kind of…\. Like, you do not need to feel threatened\. I choose you\. 100%

*💬 Reply*

**030.** `00:04` **You**

that's the game


**031.** `00:04` **You**

lol


**032.** `00:04` **Meredith Lamb (+14169386001)**

I think we play a real game instead


**033.** `00:04` **Meredith Lamb (+14169386001)**

I won’t be able to think up as good of questions


**034.** `00:05` **Meredith Lamb (+14169386001)**

As an app


**035.** `00:05` **You**

I am a little aftaid now I have to download it


**036.** `00:05` **Meredith Lamb (+14169386001)**

>
It isn’t 100% obviously\. I don’t just want to live my life talking about the past\. I want to experience new things with you

*💬 Reply*

**037.** `00:06` **Meredith Lamb (+14169386001)**

My last 16 years has been…\. Meh… but I do have 3 great kids\. :\.o


**038.** `00:09` **Meredith Lamb (+14169386001)**

I don’t want to put pressure on the whole “open” thing\. I think you put too much pressure on that and thought into it honestly


**039.** `00:09` **You**

no the forward looking stuff is the easy part


**040.** `00:09` **You**

I have zero problem there


**041.** `00:11` **Meredith Lamb (+14169386001)**

So we are good


**042.** `00:11` **Meredith Lamb (+14169386001)**

lol


**043.** `00:12` **You**

Sexy Never Have I Ever questions
Never have I ever used food during sex
Never have I ever faked an orgasm
Never have I ever been skinny dipping
Never have I ever had sex with someone in public
Never have I ever had sex with someone in a car
Never have I ever kissed someone in public
Never have I ever kissed more than 1 person in 24 hours
Never have I ever sent a dirty text
Never have I ever sent a dirty text to the wrong person
Never have I ever watched porn
Never have I ever gone down on someone in a cinema
Never have I ever flashed someone
Never have I ever given a lap dance
Never have I ever received a lap dance
Never have I ever slept with a co\-worker
Never have I ever been nude in public
Never have I ever had a threesome
Never have I ever had a friends\-with\-benefits arrangement
Never have I ever done a sexy roleplay
Never have I ever worn someone else’s underwear
Never have I ever sent a stranger a drink
Never have I ever been to a strip club
Never have I ever gone commando
Never have I ever played strip poker
Never have I ever been given a hickey
Never have I ever used handcuffs or toys
Never have I ever had sex with someone more than 10 years older than me
Never have I ever had sex with someone more than 5 years younger than me


**044.** `00:13` **You**

Be careful with these Never Have I Ever questions
Never have I ever cheated on someone
Never have I ever slept with a friend’s ex
Never have I ever been the alibi for a lying friend
Never have I ever told someone I love them without meaning it
Never have I ever convinced a friend to dump someone
Never have I ever seen someone die
Never have I ever regretted getting married
Never have I ever wished I didn’t have kids
Never have I ever run for my life


**045.** `00:13` **You**

1\. Never have I ever skinny\-dipped\.
2\. Never have I ever had a one\-night stand\.
3\. Never have I ever sexted someone\.
4\. Never have I ever sent a nude\.
5\. Never have I ever sent a sexy text or sexy pic to the wrong person\.
6\. Never have I ever kissed someone of the same gender\.
7\. Never have I ever role\-played in the bedroom\.
8\. Never have I ever used a sex toy\.
9\. Never have I ever had a threesome\.
10\. Never have I ever had a sex dream about someone I shouldn't have\.
11\. Never have I ever had sex in the car\.
12\. Never have I ever had a friend with benefits\.
13\. Never have I ever been walked in on during sex\.
14\. Never have I ever had sex in public\.
15\. Never have I ever faked an orgasm\.
16\. Never have I ever had or given a lap dance\.
17\. Never have I ever slept with someone on the first date\.
18\. Never have I ever used handcuffs in the bedroom\.
19\. Never have I ever gotten hot with someone in a hot tub\.
20\. Never have I ever been to a lingerie/naked party\.
21\. Never have I ever hooked up with a boss or supervisor\.
22\. Never have I ever been part of the mile high club\.
23\. Never have I ever had sex in a public bathroom\.
24\. Never have I ever used food in the bedroom\.
25\. Never have I ever gone skinny dipping with a group\.
26\. Never have I ever gotten hot with someone in a pool\.
27\. Never have I ever fantasized about a school teacher\.
28\. Never have I ever kissed someone on New Years Eve\.
29\. Never have I ever gotten hot with someone on a balcony\.
30\. Never have I ever made an at home porno\.
31\. Never have I ever hooked up with someone at a party\.
32\. Never have I ever had sex on a boat\.
33\. Never have I ever booked a hotel room just to go and have sex\.
34\. Never have I ever hooked up with a coworker\.
35\. Never have I ever gotten hot with someone in a sauna\.
36\. Never have I ever hooked up with someone in a photo booth\.
37\. Never have I ever had phone or facetime sex\.
38\. Never have I ever tried a sensual massage with someone\.
39\. Never have I ever sent someone a naked pic while in company\.
40\. Never have I ever used a blindfold during intimate moments\.
41\. Never have I ever written or received a sexy love letter\.
42\. Never have I ever used ice cubes during sex\.
43\. Never have I ever watched porn with someone\.
44\. Never have I ever given someone a sexy dance\.
45\. Never have I ever had sex more than 3 times in one night\.
46\. Never have I ever had sex in the shower\.
47\. Never have I ever gotten intimate with someone in front of a mirror\.
48\. Never have I ever tried flavored massage oil\.
49\. Never have I ever played strip poker\.
50\. Never have I ever tried aphrodisiac foods with someone\.
51\. Never have I ever tried a flavored lubricant\.
52\. Never have I ever had sex on the floor\.
53\. Never have I ever gotten intimate in front of a fireplace\.
54\. Never have I ever made a sex spotify playlist\.
55\. Never have I ever tried a new sex position suggested by someone else\.
56\. Never have I ever tried a new intimate activity that I saw in a movie\.
57\. Never have I ever written or received a sexy poem\.
58\. Never have I ever slept naked\.
59\. Never have I ever flashed someone\.
60\. Never have I ever been to a nude beach\.
61\. Never have I ever been to an adult store\.
62\. Never have i ever played dirty truth or dare
63\. Never have I ever taken nudes in the shower\.
64\. Never have I ever been to a strip club\.
65\. Never have I ever had sex in someone else's bed\.
66\. Never have I ever done a nude streak in public\.
67\. Never have I ever had sex with someone who's name I did not know\.
68\. Never have I ever sucked my partners toes\.
69\. Never have I ever acted out my sex fantasy\.
‍
19 Extremely Dirty Never Have I Ever Questions:
If the above questions are too tame and you really want to find out the dirtiest details about your partner then try these\!
‍
Never have I ever had anal sex\.
Never have I ever had a facial\.
Never have I ever stuck my finger in someone's ass\.
Never have I ever had period sex\.
Never have I ever tried oral sex while driving\.
Never have I ever tried anilingus\.
Never have I ever tried 69ing someone\.
Never have I ever had sex in front of someone else\.
Never have I ever had sex with someone over 10 years older than me\.
Never have I ever woken someone else because I was too loud during sex\.
Never have I ever caught an STD\.
Never have I ever been paid for sex\.
Never have I ever paid for sex\.
Never have I ever masterbated 3 times in one day\.
Never have I ever given or received a pearl necklace\.
Never have I ever had a wet dream
Never have I ever had sex with someone who was married\.
Never have I ever used a household item as a sex toy\.
Never have I ever indulged in some BDSM


**046.** `00:14` **You**

see now these questions\.\. not super safe


**047.** `00:14` **You**

for me


**048.** `00:14` **You**

not you I am sure you are fine answering all of these and hearing my answers


**049.** `00:14` **Meredith Lamb (+14169386001)**

lol


**050.** `00:14` **Meredith Lamb (+14169386001)**

That’s a lot


**051.** `00:15` **Meredith Lamb (+14169386001)**

I mean they are yes or no questions so simple


**052.** `00:15` **Meredith Lamb (+14169386001)**

The thing I find funny\.


**053.** `00:15` **Meredith Lamb (+14169386001)**

Andrew and I have owned a cottage for 10 years and never skinny dipped\. Relationship just gah, meh, blah\.


**054.** `00:15` **You**

hmmm


**055.** `00:16` **Meredith Lamb (+14169386001)**

Zero emotional connection but he never saw that


**056.** `00:16` **Meredith Lamb (+14169386001)**

Ah well\.


**057.** `00:16` **Meredith Lamb (+14169386001)**

lol


**058.** `00:16` **You**

well I would and have


**059.** `00:16` **Meredith Lamb (+14169386001)**

Same I grew up in the country


**060.** `00:17` **Meredith Lamb (+14169386001)**

lol


**061.** `00:17` **You**

I answered the first set\.\. do you want to know or not\.


**062.** `00:17` **Meredith Lamb (+14169386001)**

Why are these not “super safe” for you?


**063.** `00:17` **You**

it will be easier this way\.\. this way you get to know and I don't have to\.


**064.** `00:17` **You**

lol


**065.** `00:18` **Meredith Lamb (+14169386001)**

Wait where did you answer them?


**066.** `00:18` **You**

In word I just have to copy it in


**067.** `00:18` **Meredith Lamb (+14169386001)**

Ok


**068.** `00:18` **You**

you want me to


**069.** `00:18` **Meredith Lamb (+14169386001)**

Sure


**070.** `00:18` **You**

Never have I ever used food during sex \- NO
Never have I ever faked an orgasm \- YES
Never have I ever been skinny dipping \- YES
Never have I ever had sex with someone in public \- YES
Never have I ever had sex with someone in a car \- YES
Never have I ever kissed someone in public \- YES
Never have I ever kissed more than 1 person in 24 hours \- YES
Never have I ever sent a dirty text \- NO
Never have I ever sent a dirty text to the wrong person \- NO
Never have I ever watched porn \- YES
Never have I ever gone down on someone in a cinema \- NO
Never have I ever flashed someone \- YES
Never have I ever given a lap dance \- YES
Never have I ever received a lap dance \- YES
Never have I ever slept with a co\-worker \- YES
Never have I ever been nude in public \- NO
Never have I ever had a threesome \- ?
Never have I ever had a friends\-with\-benefits arrangement \- YES
Never have I ever done a sexy roleplay \-YESish
Never have I ever worn someone else’s underwear \- NO
Never have I ever sent a stranger a drink \- YES
Never have I ever been to a strip club \- NO
Never have I ever gone commando \- YES
Never have I ever played strip poker \- YES
Never have I ever been given a hickey \- YES
Never have I ever used handcuffs or toys \- NO
Never have I ever had sex with someone more than 10 years older than me \- YES
Never have I ever had sex with someone more than 5 years younger than me \- NO


**071.** `00:19` **Meredith Lamb (+14169386001)**

I’m going upstairs bc my wine is done :\(


**072.** `00:19` **Meredith Lamb (+14169386001)**

Actually I have some left of another bottle hrrrm


**073.** `00:20` **You**

do it


**074.** `00:20` **You**

I will stay up with you


**075.** `00:20` **You**

and answer the next set now


**076.** `00:21` **Meredith Lamb (+14169386001)**

K wait need to read


**077.** `00:21` **Meredith Lamb (+14169386001)**

I go in kitchen and Mac is eating fruit at table


**078.** `00:21` **Meredith Lamb (+14169386001)**

Me: I thought you were going to amalie’s tonight?


**079.** `00:21` **Meredith Lamb (+14169386001)**

Her: I did, I just got back


**080.** `00:21` **Meredith Lamb (+14169386001)**

DOH\!


**081.** `00:24` **Meredith Lamb (+14169386001)**

So what is the?


**082.** `00:24` **You**

well uncertain


**083.** `00:24` **Meredith Lamb (+14169386001)**

Huh?


**084.** `00:24` **Meredith Lamb (+14169386001)**

lol


**085.** `00:24` **Meredith Lamb (+14169386001)**

Omg


**086.** `00:24` **You**

it was sketchy I can remember it\.\. and it was weird\.


**087.** `00:24` **Meredith Lamb (+14169386001)**

I am not uncertain on that one


**088.** `00:24` **Meredith Lamb (+14169386001)**

Haha


**089.** `00:24` **You**

I figured yes\.


**090.** `00:25` **Meredith Lamb (+14169386001)**

My answers are like mostly the same


**091.** `00:25` **Meredith Lamb (+14169386001)**

I mean minus the lap dance


**092.** `00:25` **Meredith Lamb (+14169386001)**

lol


**093.** `00:25` **You**

that was a joke


**094.** `00:26` **Meredith Lamb (+14169386001)**

🧐


**095.** `00:26` **Meredith Lamb (+14169386001)**

No, you can’t say that now


**096.** `00:26` **You**

sure I can\.\. it was\.


**097.** `00:26` **Meredith Lamb (+14169386001)**

Huh?


**098.** `00:26` **You**

see


**099.** `00:26` **You**

fuck


**100.** `00:26` **You**

I almost asked which answers were different\.\. but I don't want to know lol


**101.** `00:26` **Meredith Lamb (+14169386001)**

How is it a joke?


**102.** `00:26` **You**

and ignore the threesome question


**103.** `00:27` **Meredith Lamb (+14169386001)**

I have never had a threesome


**104.** `00:27` **You**

I was goofing around with someone\.


**105.** `00:27` **Meredith Lamb (+14169386001)**

Ok


**106.** `00:27` **You**

ok I think a threesome requires sex right\.


**107.** `00:27` **You**

and the three people have to be engaged at the time\.\.


**108.** `00:27` **Meredith Lamb (+14169386001)**

>
OK, well you should never have said that because now you’re gonna have to do that to me

*💬 Reply*

**109.** `00:28` **You**

>
so drunk\.\. that is what I will need to be\.\.

*💬 Reply*

**110.** `00:28` **Meredith Lamb (+14169386001)**

>
I mean, I think so? Not sure\.

*💬 Reply*

**111.** `00:28` **You**

either that or I will learn the PONY dance\.


**112.** `00:28` **You**

>
then not a threesome

*💬 Reply*

**113.** `00:28` **Meredith Lamb (+14169386001)**

>
That’s OK

*💬 Reply*

**114.** `00:28` **You**

Bishops was a bad university


**115.** `00:28` **Meredith Lamb (+14169386001)**

I don’t fake orgasms


**116.** `00:29` **You**

I don't know when you have orgasms\.\. lol so I couldn't tell anyways rofl\.


**117.** `00:29` **Meredith Lamb (+14169386001)**

But I did with highschool bf initially but we got over that\. Young


**118.** `00:29` **You**

There are stories to all of these\.\. but you don't need them all


**119.** `00:30` **Meredith Lamb (+14169386001)**

Ever since I started cipralex mine are more “challenging” but I can’t go off cipralex right now


**120.** `00:30` **Meredith Lamb (+14169386001)**

I started it a year ago


**121.** `00:30` **You**

>
heard about that being a side effect

*💬 Reply*

**122.** `00:31` **Meredith Lamb (+14169386001)**

Before that I was very “easy” which is why the emotional relationship thing didn’t matter as much


**123.** `00:31` **You**

I mean I guess that is something\.


**124.** `00:31` **You**

I think you explained that to me once\.\. using other words re Andrew


**125.** `00:31` **Meredith Lamb (+14169386001)**

I’m too stressed right now\. I think I need to stay on for 6 months


**126.** `00:31` **You**

another one of those\.\. "yeah I didn't necessarily need that one"


**127.** `00:32` **Meredith Lamb (+14169386001)**

My body has always been very good to me\. I know not all women can say the same


**128.** `00:32` **You**

>
you definitely need to take care of yourself first

*💬 Reply*

**129.** `00:33` **Meredith Lamb (+14169386001)**

TMI maybe? \(Not sure\) ……\.\. trigger warning …………\.\.
Andrew never thought I loved him but my body always worked so he was like well, maybe\.


**130.** `00:33` **You**

I am disregarding the 19 Extremely Dirty Never Have I Ever questions\.\. not answering those\.


**131.** `00:33` **You**

>
>
>
>
not triggering you already said that to me\.\. lol

*💬 Reply*

**132.** `00:33` **Meredith Lamb (+14169386001)**

>
Omg funny

*💬 Reply*

**133.** `00:33` **You**

it was the three days a week conversation


**134.** `00:34` **Meredith Lamb (+14169386001)**

lol


**135.** `00:34` **You**

memory


**136.** `00:34` **Meredith Lamb (+14169386001)**

Literally laughing


**137.** `00:34` **You**

I hate it so fucking much sometimes


**138.** `00:34` **Meredith Lamb (+14169386001)**

Yeah really


**139.** `00:34` **Meredith Lamb (+14169386001)**

Andrew has zero memory


**140.** `00:34` **You**

1\. Never have I ever skinny\-dipped\. \- YES
2\. Never have I ever had a one\-night stand\. \- YES
3\. Never have I ever sexted someone\. – NO \(well you were close – but it wasn’t sexting\)
4\. Never have I ever sent a nude\. \- NO
5\. Never have I ever sent a sexy text or sexy pic to the wrong person\. \- NO
6\. Never have I ever kissed someone of the same gender\. \- YES
7\. Never have I ever role\-played in the bedroom\. \- YES
8\. Never have I ever used a sex toy\. \- YES
9\. Never have I ever had a threesome\. \- ?
10\. Never have I ever had a sex dream about someone I shouldn't have\. \- YES
11\. Never have I ever had sex in the car\. \- YES
12\. Never have I ever had a friend with benefits\. \- YES
13\. Never have I ever been walked in on during sex\. \- YES
14\. Never have I ever had sex in public\. \- YES
15\. Never have I ever faked an orgasm\. \- YES
16\. Never have I ever had or given a lap dance\. \- YES
17\. Never have I ever slept with someone on the first date\. \- YES
18\. Never have I ever used handcuffs in the bedroom\. \- NO
19\. Never have I ever gotten hot with someone in a hot tub\. \- YES
20\. Never have I ever been to a lingerie/naked party\. \- NO
21\. Never have I ever hooked up with a boss or supervisor\. \- NO
22\. Never have I ever been part of the mile high club\. \- NO
23\. Never have I ever had sex in a public bathroom\. \- ?
24\. Never have I ever used food in the bedroom\. \- NO
25\. Never have I ever gone skinny dipping with a group\. \- YES
26\. Never have I ever gotten hot with someone in a pool\. \- YES
27\. Never have I ever fantasized about a school teacher\. \- YES
28\. Never have I ever kissed someone on New Years Eve\. \- YES
29\. Never have I ever gotten hot with someone on a balcony\. – Define Hot\.
30\. Never have I ever made an at home porno\. \- NO
31\. Never have I ever hooked up with someone at a party\. \- YES
32\. Never have I ever had sex on a boat\. \- NO
33\. Never have I ever booked a hotel room just to go and have sex\. – NO \(not just\)
34\. Never have I ever hooked up with a coworker\. \- YES
35\. Never have I ever gotten hot with someone in a sauna\. \- NO
36\. Never have I ever hooked up with someone in a photo booth\. \- NO
37\. Never have I ever had phone or facetime sex\. \- NO
38\. Never have I ever tried a sensual massage with someone\. \- YES
39\. Never have I ever sent someone a naked pic while in company\. \- NO
40\. Never have I ever used a blindfold during intimate moments\. \- NO
41\. Never have I ever written or received a sexy love letter\. \- NO
42\. Never have I ever used ice cubes during sex\. \- YES
43\. Never have I ever watched porn with someone\. \- NO
44\. Never have I ever given someone a sexy dance\. \- YES
45\. Never have I ever had sex more than 3 times in one night\. \- YES
46\. Never have I ever had sex in the shower\. \- YES
47\. Never have I ever gotten intimate with someone in front of a mirror\. \- YES
48\. Never have I ever tried flavored massage oil\. \- NO
49\. Never have I ever played strip poker\. \- YES
50\. Never have I ever tried aphrodisiac foods with someone\. \- NO
51\. Never have I ever tried a flavored lubricant\. \- NO
52\. Never have I ever had sex on the floor\. \- YES
53\. Never have I ever gotten intimate in front of a fireplace\. \- YES
54\. Never have I ever made a sex spotify playlist\. \- NO
55\. Never have I ever tried a new sex position suggested by someone else\. \- YES
56\. Never have I ever tried a new intimate activity that I saw in a movie\. \- NO
57\. Never have I ever written or received a sexy poem\. \- NO
58\. Never have I ever slept naked\. \- YES
59\. Never have I ever flashed someone\. \- YES
60\. Never have I ever been to a nude beach\. \- NO
61\. Never have I ever been to an adult store\. \- YES
62\. Never have i ever played dirty truth or dare \- NO
63\. Never have I ever taken nudes in the shower\. \- NO
64\. Never have I ever been to a strip club\. \- NO
65\. Never have I ever had sex in someone else's bed\. \- YES
66\. Never have I ever done a nude streak in public\. \- NO
67\. Never have I ever had sex with someone who's name I did not know\. \- YES
68\. Never have I ever sucked my partners toes\. – Probably\.\.
69\. Never have I ever acted out my sex fantasy\. \- Probably
‍
19 Extremely Dirty Never Have I Ever Questions:
If the above questions are too tame and you really want to find out the dirtiest details about your partner then try these\!
‍
Never have I ever had anal sex\.
Never have I ever had a facial\.
Never have I ever stuck my finger in someone's ass\.
Never have I ever had period sex\.
Never have I ever tried oral sex while driving\.
Never have I ever tried anilingus\.
Never have I ever tried 69ing someone\.
Never have I ever had sex in front of someone else\.
Never have I ever had sex with someone over 10 years older than me\.
Never have I ever woken someone else because I was too loud during sex\.
Never have I ever caught an STD\.
Never have I ever been paid for sex\.
Never have I ever paid for sex\.
Never have I ever masterbated 3 times in one day\.
Never have I ever given or received a pearl necklace\.
Never have I ever had a wet dream
Never have I ever had sex with someone who was married\.
Never have I ever used a household item as a sex toy\.
Never have I ever indulged in some BDSM


**141.** `00:34` **Meredith Lamb (+14169386001)**

You are the opposite


**142.** `00:35` **You**

I wish I had zero memory sometimes


**143.** `00:35` **You**

there I think that is enough knowledge about me\.


**144.** `00:38` **You**

>
>
>
>
yeah being horny and loving are 2 very very different things\.\. I have had relationships\.\. both willing partners lots of fun no love\.  very different feeling\.

*💬 Reply*

**145.** `00:39` **Meredith Lamb (+14169386001)**

>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
This was LONG\!

*💬 Reply*

**146.** `00:39` **Meredith Lamb (+14169386001)**

\(I have a boat\.\)


**147.** `00:40` **You**

\-\-\-\-\-\-check


**148.** `00:40` **Meredith Lamb (+14169386001)**

lol


**149.** `00:40` **Meredith Lamb (+14169386001)**

Who’s the sex dream you shouldn’t have had?


**150.** `00:41` **You**

I mean probably a friend or something\.\. I am just certain I have woken feeling guilty so just checking that one knowling it likely has happened


**151.** `00:43` **Meredith Lamb (+14169386001)**

I can’t think of anything\. However, at work one day at infinity this coworker of Chris’\. His name was Scott \(LOL\)\. Scott Shelby\. He came up to me and told me about this dream he had where I was a police officer in his dream … I’m like, okkkkkk lol


**152.** `00:43` **Meredith Lamb (+14169386001)**

So awkward


**153.** `00:43` **Meredith Lamb (+14169386001)**

\*infinet


**154.** `00:43` **Meredith Lamb (+14169386001)**

Not infinity lol


**155.** `00:43` **You**

was it a dream


**156.** `00:44` **Meredith Lamb (+14169386001)**

Yeah


**157.** `00:44` **You**

or was it a drug induced hallucination


**158.** `00:44` **Meredith Lamb (+14169386001)**

He told me that morning


**159.** `00:44` **Meredith Lamb (+14169386001)**

So odd


**160.** `00:44` **Meredith Lamb (+14169386001)**

He was a lot older than me too


**161.** `00:44` **You**

hitting on yo


**162.** `00:44` **Meredith Lamb (+14169386001)**

No super nice guy


**163.** `00:44` **Meredith Lamb (+14169386001)**

Just awkward


**164.** `00:44` **Meredith Lamb (+14169386001)**

I still see him online and laugh about it


**165.** `00:44` **Meredith Lamb (+14169386001)**

No harm done


**166.** `00:45` **Meredith Lamb (+14169386001)**

Chris LAUGHED\. We laughed\.


**167.** `00:45` **Meredith Lamb (+14169386001)**

We liked Scott


**168.** `00:45` **Meredith Lamb (+14169386001)**

Just was kinda weird\. Ppl don’t do that at work usually


**169.** `00:45` **You**

Scott's are good guys


**170.** `00:45` **Meredith Lamb (+14169386001)**

I love Scott’s


**171.** `00:45` **Meredith Lamb (+14169386001)**

Haven’t met a Scott I don’t like


**172.** `00:46` **Meredith Lamb (+14169386001)**

Omg this is him now\. SO OLD\. like 20 years later

*📎 1 attachment(s)*

**173.** `00:47` **Meredith Lamb (+14169386001)**

There are some super weird ppl in tech


**174.** `00:48` **Meredith Lamb (+14169386001)**

All the mutual connections we have are from our dot com days


**175.** `00:48` **Meredith Lamb (+14169386001)**

Different time\.


**176.** `00:48` **Meredith Lamb (+14169386001)**

He looked different lol


**177.** `00:49` **You**

hehe


**178.** `00:49` **You**

we all looked different


**179.** `00:49` **Meredith Lamb (+14169386001)**

Sigh… I know\.


**180.** `00:50` **Meredith Lamb (+14169386001)**

So let me ask you a question


**181.** `00:50` **Meredith Lamb (+14169386001)**

What do you think about what you’ve learned about my relationship with Andrew today?


**182.** `00:51` **You**

which part


**183.** `00:52` **Meredith Lamb (+14169386001)**

https://flic\.kr/p/fZXnf
So this guy Joe used to tell me so much tmi about all his gay relationships\. It used to make me so uncomfortable, but he was a good friend so we hung out all the time but I used to have to hear about like oh my God I can’t even tell you ughhhh gay guys they are so explicit


**184.** `00:52` **Meredith Lamb (+14169386001)**

>
Like the not getting drunk part or telling him shit

*💬 Reply*

**185.** `00:53` **You**

It kind of surprised me to be honest


**186.** `00:53` **You**

Let me say this\.


**187.** `00:54` **Meredith Lamb (+14169386001)**

https://flic\.kr/p/6jGmn
This is the girl I used to go to raves with\.


**188.** `00:54` **You**

I think there are multiple versions of Meredith\.\.


**189.** `00:57` **You**

There is high school\.\. there is university \- let's have fun with whoever because I give zero fucks\.  There is Chris pre Jeremy \- Meredith gone wild and experimenting with everything, there is Jeremy \(I don't have a ton of info on this one\.\. except you were the boss, so not sure except it went for a while you were engaged\), the Meredith Gavin, Jeremy, Chris\.  I am not quite sure if you had fun with Chris again post Jeremy pre Andrew\.\. Steve was in there somewhere\.  And then andrew and then me\.


**190.** `00:57` **You**

I think you had to give up almost all of who you were with Andrew\.\. to become someone else\.\. still an awesome person, super fun, and amazing\.\. but you left some stuff behind\.


**191.** `00:57` **You**

Reaction: ❤️ from Meredith Lamb
I think you want to try to maybe find the best of both worlds with me\.\.\. maybe\.\.


**192.** `00:58` **You**

I mean I think you truly want to be able to tell me anything at all\.\. and for me to be \- cool shit\.\. guess what I did\.


**193.** `00:58` **You**

and I very much want that\.\. I am trying\.


**194.** `01:01` **Meredith Lamb (+14169386001)**

That was a very stellar analysis given we have been talking all of 2 longs


**195.** `01:01` **Meredith Lamb (+14169386001)**

\*months


**196.** `01:01` **Meredith Lamb (+14169386001)**

You are a fast learner


**197.** `01:02` **You**

I pay attention


**198.** `01:02` **You**

I really am trying mer


**199.** `01:02` **Meredith Lamb (+14169386001)**

Obviously


**200.** `01:02` **You**

but it is easier to give than receive atm\.\. certain things\. getting better\.


**201.** `01:03` **Meredith Lamb (+14169386001)**

>
I don’t get this\. Elaborate\.

*💬 Reply*

**202.** `01:04` **You**

Like answering those questions tonight \- not the super dirty ones\.\. \- but the rest\. that is easy


**203.** `01:04` **You**

hearing back sometimes is not\.


**204.** `01:04` **You**

i dont know why


**205.** `01:04` **Meredith Lamb (+14169386001)**

Do you want me to answer them? I will be don’t have a word doc …


**206.** `01:04` **You**

nope I am good\.


**207.** `01:04` **Meredith Lamb (+14169386001)**

Actually I have Google docs bc of my fucking kids


**208.** `01:04` **You**

lol


**209.** `01:05` **Meredith Lamb (+14169386001)**

Sure? I will answer all of them


**210.** `01:05` **Meredith Lamb (+14169386001)**

Just hard on my phone


**211.** `01:05` **You**

I feel like you want to so go ahead\.


**212.** `01:05` **Meredith Lamb (+14169386001)**

Email me the doc at work … KIDDING


**213.** `01:05` **You**

I will force myself to pass out after anyways\.


**214.** `01:06` **You**

certainly is better than talking directly


**215.** `01:06` **Meredith Lamb (+14169386001)**

If you don’t care I won’t\. I don’t care


**216.** `01:06` **You**

No answer them pls\.


**217.** `01:07` **Meredith Lamb (+14169386001)**

For real?


**218.** `01:06` **You**

yeah


**219.** `01:07` **Meredith Lamb (+14169386001)**

K so from the beginning?


**220.** `01:07` **Meredith Lamb (+14169386001)**

There were so many


**221.** `01:07` **You**

just copy paste one into google docs and put y / n


**222.** `01:11` **Meredith Lamb (+14169386001)**

Never have I ever used food during sex \- yes
Never have I ever faked an orgasm \- no \(I think \- I try to be genuine\)
Never have I ever been skinny dipping \- YES
Never have I ever had sex with someone in public \- YES
Never have I ever had sex with someone in a car \- YES \(I mean I grew up in the country\. Dirt roads\)
Never have I ever kissed someone in public \- YES
Never have I ever kissed more than 1 person in 24 hours \- YES \(but only once at nye\. The brothers\. Joe and tim\. lol\)
Never have I ever sent a dirty text \- NO
Never have I ever sent a dirty text to the wrong person \- NO
Never have I ever watched porn \- YES
Never have I ever gone down on someone in a cinema \- yes
Never have I ever flashed someone \- no
Never have I ever given a lap dance \- no
Never have I ever received a lap dance \- no
Never have I ever slept with a co\-worker \- YES
Never have I ever been nude in public \- NO
Never have I ever had a threesome \- no
Never have I ever had a friends\-with\-benefits arrangement \-  it really but maybe
Never have I ever done a sexy roleplay \-no
Never have I ever worn someone else’s underwear \- NO
Never have I ever sent a stranger a drink \- no
Never have I ever been to a strip club \- no
Never have I ever gone commando \- no
Never have I ever played strip poker \- no
Never have I ever been given a hickey \- YES
Never have I ever used handcuffs or toys \- yes
Never have I ever had sex with someone more than 10 years older than me \- no
Never have I ever had sex with someone more than 5 years younger than me \- NO


**223.** `01:11` **You**

And perhaps not the uber dirty
Ones that I avoided


**224.** `01:11` **Meredith Lamb (+14169386001)**

Ther you go


**225.** `01:12` **Meredith Lamb (+14169386001)**

I just cut and paste yours


**226.** `01:12` **You**

Those were in the second set


**227.** `01:12` **You**

Oh Steve was 9 years older


**228.** `01:12` **You**

lol


**229.** `01:12` **Meredith Lamb (+14169386001)**

What that was first set


**230.** `01:13` **You**

You just did first set


**231.** `01:13` **You**

There were another long list I answered


**232.** `01:13` **You**

Then some really sketchy ones at the end of the second list I was like eeeeeeeeeee


**233.** `01:13` **Meredith Lamb (+14169386001)**

K cut and paste and I will answer


**234.** `01:13` **Meredith Lamb (+14169386001)**

It’s hard to scroll back


**235.** `01:15` **Meredith Lamb (+14169386001)**

So the faking an orgasm like MAYBE in high school but doesn’t count in my opinion


**236.** `01:15` **You**

1\. Never have I ever skinny\-dipped\. \- YES
2\. Never have I ever had a one\-night stand\. \- YES
3\. Never have I ever sexted someone\. – NO \(well you were close – but it wasn’t sexting\)
4\. Never have I ever sent a nude\. \- NO
5\. Never have I ever sent a sexy text or sexy pic to the wrong person\. \- NO
6\. Never have I ever kissed someone of the same gender\. \- YES
7\. Never have I ever role\-played in the bedroom\. \- YES
8\. Never have I ever used a sex toy\. \- YES
9\. Never have I ever had a threesome\. \- ?
10\. Never have I ever had a sex dream about someone I shouldn't have\. \- YES
11\. Never have I ever had sex in the car\. \- YES
12\. Never have I ever had a friend with benefits\. \- YES
13\. Never have I ever been walked in on during sex\. \- YES
14\. Never have I ever had sex in public\. \- YES
15\. Never have I ever faked an orgasm\. \- YES
16\. Never have I ever had or given a lap dance\. \- YES
17\. Never have I ever slept with someone on the first date\. \- YES
18\. Never have I ever used handcuffs in the bedroom\. \- NO
19\. Never have I ever gotten hot with someone in a hot tub\. \- YES
20\. Never have I ever been to a lingerie/naked party\. \- NO
21\. Never have I ever hooked up with a boss or supervisor\. \- NO
22\. Never have I ever been part of the mile high club\. \- NO
23\. Never have I ever had sex in a public bathroom\. \- ?
24\. Never have I ever used food in the bedroom\. \- NO
25\. Never have I ever gone skinny dipping with a group\. \- YES
26\. Never have I ever gotten hot with someone in a pool\. \- YES
27\. Never have I ever fantasized about a school teacher\. \- YES
28\. Never have I ever kissed someone on New Years Eve\. \- YES
29\. Never have I ever gotten hot with someone on a balcony\. – Define Hot\.
30\. Never have I ever made an at home porno\. \- NO
31\. Never have I ever hooked up with someone at a party\. \- YES
32\. Never have I ever had sex on a boat\. \- NO
33\. Never have I ever booked a hotel room just to go and have sex\. – NO \(not just\)
34\. Never have I ever hooked up with a coworker\. \- YES
35\. Never have I ever gotten hot with someone in a sauna\. \- NO
36\. Never have I ever hooked up with someone in a photo booth\. \- NO
37\. Never have I ever had phone or facetime sex\. \- NO
38\. Never have I ever tried a sensual massage with someone\. \- YES
39\. Never have I ever sent someone a naked pic while in company\. \- NO
40\. Never have I ever used a blindfold during intimate moments\. \- NO
41\. Never have I ever written or received a sexy love letter\. \- NO
42\. Never have I ever used ice cubes during sex\. \- YES
43\. Never have I ever watched porn with someone\. \- NO
44\. Never have I ever given someone a sexy dance\. \- YES
45\. Never have I ever had sex more than 3 times in one night\. \- YES
46\. Never have I ever had sex in the shower\. \- YES
47\. Never have I ever gotten intimate with someone in front of a mirror\. \- YES
48\. Never have I ever tried flavored massage oil\. \- NO
49\. Never have I ever played strip poker\. \- YES
50\. Never have I ever tried aphrodisiac foods with someone\. \- NO
51\. Never have I ever tried a flavored lubricant\. \- NO
52\. Never have I ever had sex on the floor\. \- YES
53\. Never have I ever gotten intimate in front of a fireplace\. \- YES
54\. Never have I ever made a sex spotify playlist\. \- NO
55\. Never have I ever tried a new sex position suggested by someone else\. \- YES
56\. Never have I ever tried a new intimate activity that I saw in a movie\. \- NO
57\. Never have I ever written or received a sexy poem\. \- NO
58\. Never have I ever slept naked\. \- YES
59\. Never have I ever flashed someone\. \- YES
60\. Never have I ever been to a nude beach\. \- NO
61\. Never have I ever been to an adult store\. \- YES
62\. Never have i ever played dirty truth or dare \- NO
63\. Never have I ever taken nudes in the shower\. \- NO
64\. Never have I ever been to a strip club\. \- NO
65\. Never have I ever had sex in someone else's bed\. \- YES
66\. Never have I ever done a nude streak in public\. \- NO
67\. Never have I ever had sex with someone who's name I did not know\. \- YES
68\. Never have I ever sucked my partners toes\. – Probably\.\.
69\. Never have I ever acted out my sex fantasy\. \- Probably
‍
19 Extremely Dirty Never Have I Ever Questions:
If the above questions are too tame and you really want to find out the dirtiest details about your partner then try these\!
‍
Never have I ever had anal sex\.
Never have I ever had a facial\.
Never have I ever stuck my finger in someone's ass\.
Never have I ever had period sex\.
Never have I ever tried oral sex while driving\.
Never have I ever tried anilingus\.
Never have I ever tried 69ing someone\.
Never have I ever had sex in front of someone else\.
Never have I ever had sex with someone over 10 years older than me\.
Never have I ever woken someone else because I was too loud during sex\.
Never have I ever caught an STD\.
Never have I ever been paid for sex\.
Never have I ever paid for sex\.
Never have I ever masterbated 3 times in one day\.
Never have I ever given or received a pearl necklace\.
Never have I ever had a wet dream
Never have I ever had sex with someone who was married\.
Never have I ever used a household item as a sex toy\.
Never have I ever indulged in some BDSM


**237.** `01:17` **You**

Remeber feel free to disregard kast 19


**238.** `01:24` **Meredith Lamb (+14169386001)**

1\. Never have I ever skinny\-dipped\. \- YES
2\. Never have I ever had a one\-night stand\. \- YES
3\. Never have I ever sexted someone\. – No
4\. Never have I ever sent a nude\. \- NO but close because I had a ton of pressure from a couple ppl
5\. Never have I ever sent a sexy text or sexy pic to the wrong person\. \- NO
6\. Never have I ever kissed someone of the same gender\. \- YES
7\. Never have I ever role\-played in the bedroom\. \- no
8\. Never have I ever used a sex toy\. \- YES
9\. Never have I ever had a threesome\. \- no
10\. Never have I ever had a sex dream about someone I shouldn't have\. \- no
11\. Never have I ever had sex in the car\. \- YES
12\. Never have I ever had a friend with benefits\. \- maybe not really
13\. Never have I ever been walked in on during sex\. \- YES
14\. Never have I ever had sex in public\. \- YES
15\. Never have I ever faked an orgasm\. \- sigh high school shouldn’t count
16\. Never have I ever had or given a lap dance\. \- no
17\. Never have I ever slept with someone on the first date\. \- YES \(eek\)
18\. Never have I ever used handcuffs in the bedroom\. \- maybe
19\. Never have I ever gotten hot with someone in a hot tub\. \- don’t think so but not 100%
20\. Never have I ever been to a lingerie/naked party\. \- NO
21\. Never have I ever hooked up with a boss or supervisor\. \- erm?
22\. Never have I ever been part of the mile high club\. \- NO
23\. Never have I ever had sex in a public bathroom\. \- maybe
24\. Never have I ever used food in the bedroom\. \- maybe but really only condiments and I was young
25\. Never have I ever gone skinny dipping with a group\. \- no
26\. Never have I ever gotten hot with someone in a pool\. \- honestly not sure, lake yes, pool maybe making out only
27\. Never have I ever fantasized about a school teacher\. \- nope
28\. Never have I ever kissed someone on New Years Eve\. \- YES
29\. Never have I ever gotten hot with someone on a balcony\. – not sure
30\. Never have I ever made an at home porno\. \- NO
31\. Never have I ever hooked up with someone at a party\. \- YES
32\. Never have I ever had sex on a boat\. \- no actually
33\. Never have I ever booked a hotel room just to go and have sex\. – NO \(not just\) SURE
34\. Never have I ever hooked up with a coworker\. \- YES
35\. Never have I ever gotten hot with someone in a sauna\. \- NO
36\. Never have I ever hooked up with someone in a photo booth\. \- NO
37\. Never have I ever had phone or facetime sex\. \- NO
38\. Never have I ever tried a sensual massage with someone\. \- YES
39\. Never have I ever sent someone a naked pic while in company\. \- NO
40\. Never have I ever used a blindfold during intimate moments\. \- MAYBE
41\. Never have I ever written or received a sexy love letter\. \- mmm this is tricky
42\. Never have I ever used ice cubes during sex\. \- YES
43\. Never have I ever watched porn with someone\. \- maybe
44\. Never have I ever given someone a sexy dance\. \- no
45\. Never have I ever had sex more than 3 times in one night\. \- YES
46\. Never have I ever had sex in the shower\. \- YES
47\. Never have I ever gotten intimate with someone in front of a mirror\. \- YES
48\. Never have I ever tried flavored massage oil\. \- yes
49\. Never have I ever played strip poker\. \- no
50\. Never have I ever tried aphrodisiac foods with someone\. \- NO
51\. Never have I ever tried a flavored lubricant\. \- yes
52\. Never have I ever had sex on the floor\. \- YES
53\. Never have I ever gotten intimate in front of a fireplace\. \- YES
54\. Never have I ever made a sex spotify playlist\. \- NO
55\. Never have I ever tried a new sex position suggested by someone else\. \- no
56\. Never have I ever tried a new intimate activity that I saw in a movie\. \- NO
57\. Never have I ever written or received a sexy poem\. \- yes
58\. Never have I ever slept naked\. \- YES
59\. Never have I ever flashed someone\. \- YES
60\. Never have I ever been to a nude beach\. \- NO
61\. Never have I ever been to an adult store\. \- YES
62\. Never have i ever played dirty truth or dare \- NO
63\. Never have I ever taken nudes in the shower\. \- NO
64\. Never have I ever been to a strip club\. \- NO
65\. Never have I ever had sex in someone else's bed\. \- YES
66\. Never have I ever done a nude streak in public\. \- NO
67\. Never have I ever had sex with someone who's name I did not know\. \- YES
68\. Never have I ever sucked my partners toes\. – Probably\.\.
69\. Never have I ever acted out my sex fantasy\. \- Probably
‍
19 Extremely Dirty Never Have I Ever Questions:
If the above questions are too tame and you really want to find out the dirtiest details about your partner then try these\!
‍
Never have I ever had anal sex\.
Never have I ever had a facial\.
Never have I ever stuck my finger in someone's ass\.
Never have I ever had period sex\.
Never have I ever tried oral sex while driving\.
Never have I ever tried anilingus\.
Never have I ever tried 69ing someone\.
Never have I ever had sex in front of someone else\.
Never have I ever had sex with someone over 10 years older than me\.
Never have I ever woken someone else because I was too loud during sex\.
Never have I ever caught an STD\.
Never have I ever been paid for sex\.
Never have I ever paid for sex\.
Never have I ever masterbated 3 times in one day\.
Never have I ever given or received a pearl necklace\.
Never have I ever had a wet dream
Never have I ever had sex with someone who was married\.
Never have I ever used a household item as a sex toy\.
Never have I ever indulged in some BDSM


**239.** `01:25` **Meredith Lamb (+14169386001)**

K, I didn’t answer the super ones at the end\. I mean I could …\. But awkward some of them


**240.** `01:26` **You**

I think best left unsaid\.


**241.** `01:26` **Meredith Lamb (+14169386001)**

lol


**242.** `01:27` **You**

Very much so


**243.** `01:28` **Meredith Lamb (+14169386001)**

I don’t think either of us have too many surprises tho?


**244.** `01:28` **You**

Reaction: 😂 from Meredith Lamb
I don’t think so\.\. I flew past
Yours
Really fast and squinted and looked
Away lol


**245.** `01:28` **Meredith Lamb (+14169386001)**

Or am I speaking for u


**246.** `01:29` **Meredith Lamb (+14169386001)**

Omg lol


**247.** `01:30` **You**

I think it is enough\.\.  I don’t think we are that different\.


**248.** `01:30` **Meredith Lamb (+14169386001)**

I agree


**249.** `01:30` **Meredith Lamb (+14169386001)**

Feeling pretty confident


**250.** `01:30` **You**

You are?


**251.** `01:30` **Meredith Lamb (+14169386001)**

Yeah that we aren’t that much different


**252.** `01:30` **You**

Oh you mean about our similar experiences


**253.** `01:31` **Meredith Lamb (+14169386001)**

Yeah


**254.** `01:31` **You**

Yeah I mean mine happened ins very condensed insane period of time\.


**255.** `01:31` **Meredith Lamb (+14169386001)**

But whatever same diff


**256.** `01:31` **Meredith Lamb (+14169386001)**

lol


**257.** `01:32` **You**

Mm hm yeah\.  Now we don’t ever have to talk about them again right\!\!\!lol


**258.** `01:32` **Meredith Lamb (+14169386001)**

Reaction: 🤨 from Scott Hicks
Deal 🤝


**259.** `01:32` **You**

Glass 6?


**260.** `01:33` **Meredith Lamb (+14169386001)**

I won’t bring it up\. But if you do all bets are off\.


**261.** `01:33` **You**

I am not bringing shit up ever


**262.** `01:33` **You**

Never ever


**263.** `01:33` **Meredith Lamb (+14169386001)**

k


**264.** `01:33` **You**

I don’t want to know any details no stories


**265.** `01:34` **You**

This wa enough of a stretch for me\.


**266.** `01:34` **Meredith Lamb (+14169386001)**

I have none left anyway


**267.** `01:34` **You**

Naw you do\. I know you do


**268.** `01:34` **You**

Reaction: 👍 from Meredith Lamb
But I don’t need to hear em


**269.** `01:34` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Meredith Lamb
>
Was it really?

*💬 Reply*

**270.** `01:34` **You**

A little


**271.** `01:34` **You**

Sometimes not knowing is nice


**272.** `01:34` **You**

You can fantacise


**273.** `01:35` **Meredith Lamb (+14169386001)**

About what? A virgin?


**274.** `01:36` **You**

No about thinking this one thing this moment this act is special and unique\.\. whatever it is\.  At least not knowing you can pretend\.\. knowing you cannot


**275.** `01:36` **You**

Sometimes ignorance is bliss is all


**276.** `01:37` **Meredith Lamb (+14169386001)**

But everything is unique … and meaningful … and full of electricity… it really is\. Just because a past exists doesn’t mean a present doesn’t trump it\.


**277.** `01:38` **You**

Yeah perhaps\.\. it is hard to tell so far removed\.  And when someone loves you this much it shouldn’t matter and in reality it doesn’t but sometimes yku cannot help but think\.  🤔 which is why not knowing always best imho\. lol


**278.** `01:43` **Meredith Lamb (+14169386001)**

You trump everyone\.
I cant be more clear\.
It is for multiple reasons but there is something that trumps everything and I think it comes down to you being my would mate but I couldn’t possibly say that to anyone except for you\. Not really my style\.


**279.** `01:43` **You**

I am surprised you haven’t passed out yet


**280.** `01:44` **Meredith Lamb (+14169386001)**

No the


**281.** `01:44` **Meredith Lamb (+14169386001)**

Thc


**282.** `01:44` **You**

Soul mate


**283.** `01:45` **You**

I am just guessing not sure what would mate is


**284.** `01:45` **You**

lol


**285.** `01:45` **Meredith Lamb (+14169386001)**

Yeah typo


**286.** `01:45` **You**

Yeah it does trump it mer\.\. I know\.\. but in my head is in my head


**287.** `01:45` **Meredith Lamb (+14169386001)**

I’m not sure how or why this happened between you and I but I’m not going to argue it\.


**288.** `01:46` **You**

>
I am not either\.\. just grateful\.

*💬 Reply*

**289.** `01:46` **You**

And just think about this for a second


**290.** `01:46` **Meredith Lamb (+14169386001)**

>
In your head should be smooth sailing between us\.

*💬 Reply*

**291.** `01:47` **You**

The way you go extra on everything that is kind of how I want to be with you morn but like for everything\.  I cannot help it just like you couldn’t help going all out for mac snd your kids\. And your parents and the school etc etc


**292.** `01:48` **Meredith Lamb (+14169386001)**

I used to bug my best friend so much by my extra that she stopped being best friends with me :\( lol


**293.** `01:48` **Meredith Lamb (+14169386001)**

I had 2 besties\. One stopped\.


**294.** `01:49` **Meredith Lamb (+14169386001)**

Some ppl hate it


**295.** `01:49` **Meredith Lamb (+14169386001)**

I’m glad you don’t


**296.** `01:49` **You**

I don’t I admire it


**297.** `01:50` **Meredith Lamb (+14169386001)**

I feel like you are more extra than me which concerns me a tad\.


**298.** `01:51` **Meredith Lamb (+14169386001)**

Can we be together? Lol


**299.** `01:51` **You**

What do you mean


**300.** `01:51` **You**

I am not extra


**301.** `01:52` **You**

I mean I have less demands on me


**302.** `01:52` **Meredith Lamb (+14169386001)**

I just mean if we are both extra will it be too extra/intense


**303.** `01:52` **Meredith Lamb (+14169386001)**

You are not extra?


**304.** `01:52` **Meredith Lamb (+14169386001)**

Hmmmm


**305.** `01:52` **You**

With you I am


**306.** `01:52` **You**

And with some other things


**307.** `01:53` **You**

I don’t think it will be a problem


**308.** `01:53` **Meredith Lamb (+14169386001)**

Okay I don’t actually either


**309.** `01:53` **Meredith Lamb (+14169386001)**

Just haven’t thought about it much


**310.** `01:54` **You**

Again I have more time


**311.** `01:54` **You**

So I think about everything alot


**312.** `01:54` **Meredith Lamb (+14169386001)**

And…\.


**313.** `01:54` **You**

And it is a lot


**314.** `01:55` **You**

I do t see any issues with us with compatibility with how we feel


**315.** `01:55` **You**

With our personalities


**316.** `01:55` **Meredith Lamb (+14169386001)**

Maybe you need a little extra in your life 😇


**317.** `01:55` **You**

The history is noise just sometimes can cause insecurities in addition to this that exist


**318.** `01:55` **You**

So I am not worried


**319.** `01:56` **You**

I mean I am being a little light on history


**320.** `01:56` **You**

But lol it should be like that


**321.** `01:56` **You**

>
Def I do

*💬 Reply*

**322.** `01:57` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Good\. Please don’t be worried\. I haven’t felt this intense of a connection ever\. Not sure if it is age, or a multitude of other things I could list :\) but I am being honest


**323.** `01:57` **You**

Same like i said earlier today nothing has come close for me\.\.
It any part of it\.


**324.** `01:58` **Meredith Lamb (+14169386001)**

So you are not insecure about Chris?


**325.** `01:59` **Meredith Lamb (+14169386001)**

Because honestly NOTHING compare


**326.** `01:59` **Meredith Lamb (+14169386001)**

Compares


**327.** `02:00` **You**

I don’t know what it is like with girls\.\. but I think in general psychologically guys are wired a bit differently and insecurities come with the territory


**328.** `02:02` **Meredith Lamb (+14169386001)**

k I will accept that HOWEVER I really need you to know that even if this didn’t happen, the Chris
Thing would have only ever been platonic if at all\.


**329.** `02:02` **Meredith Lamb (+14169386001)**

For various reasons that are probably TMI\. Or maybe I already told you 😝


**330.** `02:03` **You**

Hmm


**331.** `02:03` **You**

No I don’t think so unless I misunderstood


**332.** `02:06` **Meredith Lamb (+14169386001)**

I almost passed out sorry lol


**333.** `02:06` **Meredith Lamb (+14169386001)**

“What time do you have to work tomorrow?”


**334.** `02:06` **You**

Yeah I figured you are pretty much done


**335.** `02:06` **You**

lol


**336.** `02:06` **You**

Go to bed


**337.** `02:07` **Meredith Lamb (+14169386001)**

I think I have to 🙈


**338.** `02:07` **You**

Kk get some sleep then mer


**339.** `02:07` **Meredith Lamb (+14169386001)**

Any big questions before I go? Lol


**340.** `02:07` **Meredith Lamb (+14169386001)**

Have I been sleeping on anything


**341.** `02:08` **You**

Reaction: 😂 from Meredith Lamb
No absofuckinglutely not\.


**342.** `02:08` **You**

You didn’t explain the last thing


**343.** `02:08` **You**

But I think the tmi


**344.** `02:08` **You**

Is warning enough


**345.** `02:08` **You**

So no


**346.** `02:08` **Meredith Lamb (+14169386001)**

Last thing?


**347.** `02:08` **You**

Chris


**348.** `02:09` **Meredith Lamb (+14169386001)**

Oh so in non tmi speak\. He is just GAY but thinks he is not\. Thinks he is bi but he isn’t\. Poor guy :\(


**349.** `02:09` **Meredith Lamb (+14169386001)**

Helpful?


**350.** `02:10` **You**

lol not really but honestly doesn’t matter if you say what you said then I believe you


**351.** `02:11` **Meredith Lamb (+14169386001)**

k, slowly passing out


**352.** `02:11` **Meredith Lamb (+14169386001)**

Or quickly?


**353.** `02:11` **Meredith Lamb (+14169386001)**

lol


**354.** `02:12` **You**

Kk love you mer\.\. will wait for you to ask\.\. Remeber… love you more than anything ❤️ night


**355.** `02:13` **Meredith Lamb (+14169386001)**

Love you ❤️❤️ nite … wait for me to ask what? That caught me off guard


**356.** `02:14` **Meredith Lamb (+14169386001)**

Why do you have to confuse me all the time like


**357.** `02:14` **Meredith Lamb (+14169386001)**

lol


**358.** `02:14` **You**

You will have to think about that one not helping


**359.** `02:14` **Meredith Lamb (+14169386001)**

To marry you?


**360.** `02:14` **Meredith Lamb (+14169386001)**

Noooo


**361.** `02:14` **Meredith Lamb (+14169386001)**

The hat is not what you meant


**362.** `02:14` **Meredith Lamb (+14169386001)**

\*that


**363.** `02:15` **You**

I cannot remember now just sometimes can mocking voice in my head


**364.** `02:15` **You**

Just some mocking


**365.** `02:15` **Meredith Lamb (+14169386001)**

Good


**366.** `02:15` **Meredith Lamb (+14169386001)**

Goof


**367.** `02:15` **Meredith Lamb (+14169386001)**

I love you lol


**368.** `02:16` **Meredith Lamb (+14169386001)**

Nite xoxoxoxox


**369.** `02:16` **You**

Love you going to sleep


**370.** `07:57` **You**

As much sleeping in as I can afford\.\. luv you and good morning\.


**371.** `09:08` **Meredith Lamb (+14169386001)**

Not bad\!


**372.** `09:08` **Meredith Lamb (+14169386001)**

\(For you\)


**373.** `09:09` **Meredith Lamb (+14169386001)**

Griffin woke me up whining to let him out so I’m up\. Coffee brewing\. :p


**374.** `09:10` **You**

lol no coffee yet woke up dealt with dogs, scrapped with j a bit over $$ she goes to talk to her lawyer tomorrow at noon so we will
Find out more then\.


**375.** `09:10` **You**

Coffee soon though then cleanup


**376.** `09:10` **You**

And then get ready for trainer


**377.** `09:12` **You**

She was frustrated she kept saying I will advance and I said no I won’t I don’t want to and there is risk everywhere anyways\.  Then she said well you are just going to move in with someone and get married I said absolutely not getting married\.\.   she was even worried I would move in with someone while I still had maddie\.\. I was like nope\.\. anyhow was a fun chat


**378.** `09:19` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
“absolutely not getting married” LOL


**379.** `09:19` **Meredith Lamb (+14169386001)**

No inside story there\.


**380.** `09:20` **Meredith Lamb (+14169386001)**

I bet Andrew advances but not what I’m focused on\. Why is she focused on that?


**381.** `09:23` **You**

She is focused on that so she asks for more now putting me under more risk because instead of moving down she thinks I move up\.


**382.** `09:25` **You**

My doc is back btw going to see him this week


**383.** `09:27` **Meredith Lamb (+14169386001)**

>
Hmmh Andrew and I do not have the moving up conversations… yet\. Maybe mediation might go there?

*💬 Reply*

**384.** `09:28` **Meredith Lamb (+14169386001)**

Do you HAVE to give more up front?


**385.** `09:28` **You**

Again I suggested yesterday but not sure you Remeber 16 years time away from work broken pension


**386.** `09:28` **You**

>
No I could do monthly

*💬 Reply*

**387.** `09:28` **Meredith Lamb (+14169386001)**

Can you determine the amount you are comfortable with up front?


**388.** `09:28` **You**

And she would get a\. Lot less over time


**389.** `09:29` **You**

It is possible I just wish I was free of it


**390.** `09:29` **Meredith Lamb (+14169386001)**

Yeah I know


**391.** `09:29` **You**

I am almost willing to say fuck it


**392.** `09:29` **You**

Take it all leave me alone


**393.** `09:30` **Meredith Lamb (+14169386001)**

No dont don’t do that


**394.** `09:30` **Meredith Lamb (+14169386001)**

You will regret it


**395.** `09:31` **Meredith Lamb (+14169386001)**

I know that feeling and it passes


**396.** `09:31` **You**

Yeah not realistic\.\. but feel
That way


**397.** `09:31` **You**

She is not
Good
With math


**398.** `09:32` **You**

I explained to her if I have a 3000 mortgage a month and 3000 in expenses and other costs\.\. it would take me more Than the career time I have left to build a bank account\. Like what you will start with


**399.** `09:32` **You**

Unless I advance and unless I am extremely frugal\.


**400.** `09:33` **Meredith Lamb (+14169386001)**

Well she is mad so likely doesn’t care?


**401.** `09:33` **You**

Anyways I will figure it out


**402.** `09:33` **You**

No she does care


**403.** `09:33` **You**

She is just afraid


**404.** `09:33` **You**

She also doesn’t want me going to lawyer for anything other than validating the agreement


**405.** `09:33` **Meredith Lamb (+14169386001)**

Well that sucks\. Maybe she needs a therapist to discuss her fears and anxieties


**406.** `09:33` **You**

Cause then costs add up it gets contentious etc


**407.** `09:34` **You**

>
She hates therapy

*💬 Reply*

**408.** `09:34` **Meredith Lamb (+14169386001)**

I know


**409.** `09:34` **Meredith Lamb (+14169386001)**

Unfortunate


**410.** `09:34` **You**

Maybe she needs 6 glasses of wine


**411.** `09:34` **You**

That seems to make all kinds of interesting things happen


**412.** `09:35` **You**

Have fun re reading last nights transcript kf you don’t Remeber lol


**413.** `09:35` **Meredith Lamb (+14169386001)**

Honestly, I feel better today so I’m wondering if I need to stop drinking Pinot Noir and start drinking cab or maybe I just can’t drink more than a bottle


**414.** `09:35` **Meredith Lamb (+14169386001)**

I honestly remember a lot of it, which is weird


**415.** `09:35` **Meredith Lamb (+14169386001)**

I was drinking a lot of water too, which helped and drinking slower


**416.** `09:36` **You**

You were fine last night nothing crazy


**417.** `09:36` **Meredith Lamb (+14169386001)**

Yeah, maybe Pinot Noir’s out for a while or something I have no idea\. I’m really confused today\.


**418.** `09:36` **You**

Although there was some stuff yku were willing to share and I was like nope\.z


**419.** `09:36` **Meredith Lamb (+14169386001)**

lol


**420.** `09:36` **Meredith Lamb (+14169386001)**

Well, I was still drunk


**421.** `09:36` **Meredith Lamb (+14169386001)**

Just a different drunk


**422.** `09:36` **You**

Nope nope nope


**423.** `09:37` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**424.** `09:37` **Meredith Lamb (+14169386001)**

That’s the wine I drank


**425.** `09:38` **Meredith Lamb (+14169386001)**

I am a big fan Trius wine … for a couple years it is all I drank mainly


**426.** `09:38` **You**

I know you sent me a pick at the lcbo


**427.** `09:38` **You**

An “old friend”


**428.** `09:38` **Meredith Lamb (+14169386001)**

No that was a diff pic


**429.** `09:38` **You**

Oh was it


**430.** `09:39` **Meredith Lamb (+14169386001)**

That other pic was what one of Mac’s friends parents sent as a gift to the cottage


**431.** `09:39` **Meredith Lamb (+14169386001)**

I sent it bc of the price


**432.** `09:39` **Meredith Lamb (+14169386001)**

I was shocked


**433.** `09:39` **Meredith Lamb (+14169386001)**

$$


**434.** `09:39` **Meredith Lamb (+14169386001)**

I had no idea


**435.** `09:39` **Meredith Lamb (+14169386001)**

I don’t gift wine that pricey\.


**436.** `09:40` **Meredith Lamb (+14169386001)**

So when Jamie meets with the lawyer tomorrow, what happens exactly?


**437.** `09:40` **You**

Noon


**438.** `09:40` **Meredith Lamb (+14169386001)**

Did she say yes I agree or no I don’t agree or like what?


**439.** `09:40` **Meredith Lamb (+14169386001)**

\*does she say


**440.** `09:40` **You**

She said she wants to understand more


**441.** `09:40` **You**

She said we only ever agree if she agrees with me\.\. I said you need to take a position I will take a position and we will negotiate


**442.** `09:41` **You**

Problem is she never puts forward a position\.


**443.** `09:41` **Meredith Lamb (+14169386001)**

Well, hopefully she has some like pointed questions because is the lawyer’s time really expensive? How much do they charge an hour?


**444.** `09:41` **You**

300 and she doesn’t


**445.** `09:41` **Meredith Lamb (+14169386001)**

Yikes


**446.** `09:41` **You**

So it will be them just filling her head with shit


**447.** `09:42` **Meredith Lamb (+14169386001)**

Does she ever use ChatGPT?


**448.** `09:42` **You**

Fuck no


**449.** `09:42` **Meredith Lamb (+14169386001)**

Could she put the draft that she got to ChatGPT and like ask some questions?


**450.** `09:42` **You**

I can give her some stuff


**451.** `09:42` **Meredith Lamb (+14169386001)**

No, like why can’t she do it?


**452.** `09:42` **Meredith Lamb (+14169386001)**

I think if she does it, she’ll feel better about it


**453.** `09:42` **You**

Because that is who she is


**454.** `09:42` **You**

Honestly


**455.** `09:42` **You**

She is not a go getter a doer


**456.** `09:42` **You**

She isn’t prosctive


**457.** `09:43` **Meredith Lamb (+14169386001)**

Like she can just chat with with AI casually


**458.** `09:43` **You**

Proactive


**459.** `09:43` **You**

No


**460.** `09:43` **You**

She wouldn’t


**461.** `09:43` **Meredith Lamb (+14169386001)**

But it would be so much easier than spending 300 and going and blind she’d be more prepared and then that 300 would be better spent


**462.** `09:43` **You**

The more you learn about her the more you will question my judgement


**463.** `09:43` **You**

Or lackthereof


**464.** `09:43` **Meredith Lamb (+14169386001)**

But have you asked her to use ChatGPT like just to try it?


**465.** `09:44` **You**

Yes


**466.** `09:44` **Meredith Lamb (+14169386001)**

And she won’t?


**467.** `09:44` **You**

Offered to show her how


**468.** `09:44` **You**

No


**469.** `09:44` **Meredith Lamb (+14169386001)**

Sigh


**470.** `09:44` **Meredith Lamb (+14169386001)**

Unfortunate


**471.** `09:44` **Meredith Lamb (+14169386001)**

And I don’t question your judgement lol


**472.** `09:45` **You**

I think my judgement back then was flawed for sure


**473.** `09:48` **Meredith Lamb (+14169386001)**

I think everyone’s is in their 20s to some extent


**474.** `09:48` **Meredith Lamb (+14169386001)**

People are weird


**475.** `09:48` **You**

Some more than others


**476.** `09:49` **Meredith Lamb (+14169386001)**

Plus you said yourself that your judgement was impacted by so many negative experiences in a short timeframe\.


**477.** `09:49` **Meredith Lamb (+14169386001)**

So, there is that\.


**478.** `09:49` **You**

Yep that definitely fed into it\.


**479.** `09:50` **Meredith Lamb (+14169386001)**

So be gentle on yourself\. There were legit factors at play


**480.** `09:51` **You**

Yeah well I am here now and I am in the shit now\.\. gotta deal with what is in front of me\.


**481.** `09:54` **Meredith Lamb (+14169386001)**

Well hopefully after tomorrow things look a bit more up\.


**482.** `09:54` **Meredith Lamb (+14169386001)**

For you


**483.** `09:55` **You**

Yep we will see\.  I am going to get to cleaning and stop bothering you so you can get onto whatever you have going on today\. Love you lots mer\. ❤️


**484.** `09:57` **Meredith Lamb (+14169386001)**

Love you too ❤️ ttyl


**485.** `10:47` **You**

Reaction: 😮 from Meredith Lamb
Actually training at 11 lucky I checked at gym now will check in later\.


**486.** `11:41` **You**

Omg he is literally killing me


**487.** `11:41` **You**

You might not see me again


**488.** `11:55` **Meredith Lamb (+14169386001)**

lol 😭


**489.** `12:06` **You**

Holy fuck


**490.** `12:07` **Meredith Lamb (+14169386001)**

Still going?


**491.** `12:08` **You**

Just finished


**492.** `12:08` **You**

I could barely make it down the stairs


**493.** `12:09` **You**

Can’t even flex for status shot on legs Jessy’s


**494.** `12:09` **Meredith Lamb (+14169386001)**

Yikes lol


**495.** `12:09` **You**

Jesus


**496.** `12:09` **You**

We had a bit of a laugh mid workout


**497.** `12:09` **Meredith Lamb (+14169386001)**

I am just leaving to drive Maelle to volleyball in Markham\. 1\-3pm :p


**498.** `12:11` **You**

Reaction: ❤️ from Meredith Lamb
He knows you are my gf and asked if she would appreciate this whole Henry caville goal\.\. I said she is more of a Morgan wallen fan\.\. he feels I can convert you\.\.


**499.** `12:11` **You**

>
Kk have fun say hello to your mom for me\.

*💬 Reply*

**500.** `12:11` **You**

❤️


**501.** `12:15` **Meredith Lamb (+14169386001)**

My mom is at Marlowe’s vball


**502.** `12:18` **You**

Ah ok well have fun anyways


**503.** `14:25` **Meredith Lamb (+14169386001)**

So I napped for an hour in the parking lot and am now just chatting to my SIL online\. So fun …


**504.** `14:25` **You**

lol I am doing this


**505.** `14:25` **You**


*📎 1 attachment(s)*

**506.** `14:25` **You**

And got some stuff from butcher shop


**507.** `14:27` **Meredith Lamb (+14169386001)**

I used to love the chocolate raspberry simply protein bars


**508.** `14:28` **You**

I will have some at my desk if you want to steak


**509.** `14:30` **You**

Steal


**510.** `14:30` **Meredith Lamb (+14169386001)**

I figured lol


**511.** `14:30` **You**

Gonna try to make eggs I can eat tonight


**512.** `14:30` **Meredith Lamb (+14169386001)**

Really\! Can’t wait to see how that goes


**513.** `14:31` **You**

They will be eaten


**514.** `14:31` **You**

Reaction: 😂 from Meredith Lamb
That is how it will go


**515.** `14:31` **You**

lol


**516.** `14:31` **You**

Also making a chicken thing I can show you later


**517.** `15:43` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**518.** `15:43` **Meredith Lamb (+14169386001)**

My mom sent me that


**519.** `16:05` **You**

Cool nice serves


**520.** `16:05` **You**

I just got off with Mike we talked a loooooong time about you\.


**521.** `16:06` **You**

Like let’s say he is COMPLETELY brought up to current lol


**522.** `16:07` **Meredith Lamb (+14169386001)**

Oh god\. Lol


**523.** `16:07` **You**

Literally lol


**524.** `16:07` **Meredith Lamb (+14169386001)**

If I know you as I do I’m sure he is very up to speed


**525.** `16:07` **You**

It was good to get
Someone else’s perspective


**526.** `16:07` **You**

All the details yes


**527.** `16:07` **You**

Details are important


**528.** `16:08` **You**

Btw read the end of our discussion from last night I told you i was going to follow up on that


**529.** `16:08` **Meredith Lamb (+14169386001)**

>
Perspective on……

*💬 Reply*

**530.** `16:08` **Meredith Lamb (+14169386001)**

Still driving


**531.** `16:09` **You**

On everything


**532.** `16:09` **You**

Perspective on literally everything


**533.** `16:10` **You**

You drive we can chat later


**534.** `16:11` **Meredith Lamb (+14169386001)**

Home now but I think I have to go get Mac a gym membership


**535.** `16:11` **Meredith Lamb (+14169386001)**

Have to sign some form “in person”


**536.** `16:14` **You**

Cool have fun\.\. 🙂


**537.** `16:14` **You**

Mowing lawn


**538.** `16:14` **You**

Been pretty much going all day\.\. bah


**539.** `16:21` **Meredith Lamb (+14169386001)**

Energizer bunny


**540.** `16:23` **You**

No choice…\.\. no help sucks


**541.** `16:23` **Meredith Lamb (+14169386001)**

>
Hmmh not seeing what you are going to follow up on\. Seriously

*💬 Reply*

**542.** `16:25` **Meredith Lamb (+14169386001)**

Not helpful


**543.** `16:25` **Meredith Lamb (+14169386001)**

>
Do you feel better or worse after talking to him? Lol

*💬 Reply*

**544.** `16:24` **You**

TMI


**545.** `16:24` **You**

Just look for that


**546.** `16:31` **You**

You mention tmi in one of your responses to me near the bed of the night I tried to get you to engage but you wouldn’t \.\. should be easy to spot


**547.** `16:31` **You**

>
I don’t feel worse\.

*💬 Reply*

**548.** `16:32` **Meredith Lamb (+14169386001)**

>
Omg

*💬 Reply*

**549.** `16:33` **Meredith Lamb (+14169386001)**

What a response lol


**550.** `16:34` **You**

Well I don’t\.\. lol


**551.** `16:34` **You**

This is a lot
Of uncharted territory


**552.** `16:34` **Meredith Lamb (+14169386001)**

Ohh the tmi was about why Chris was clearly gay\. You are talking about that?


**553.** `16:34` **You**

Mike was frankly shocked that I did any of this with you\.


**554.** `16:34` **You**

Since he knows me so well


**555.** `16:35` **You**

>
Yeah perhaps leave it alone\.\.  now that I think about it my brain is already spinning\.  Regrets already\.

*💬 Reply*

**556.** `16:35` **You**

See I try and I really want to because I want it to be done


**557.** `16:36` **Meredith Lamb (+14169386001)**

>
Want what to be done?

*💬 Reply*

**558.** `16:36` **You**

And in my head there are answers and I am like …………\.\.


**559.** `16:36` **You**

I want all the tmi to be done


**560.** `16:36` **Meredith Lamb (+14169386001)**

You have me worried


**561.** `16:36` **You**

Just done


**562.** `16:36` **Meredith Lamb (+14169386001)**

lol


**563.** `16:36` **Meredith Lamb (+14169386001)**

Today I was like “he is totally going to change his mind”


**564.** `16:37` **You**

Change my mind?


**565.** `16:37` **Meredith Lamb (+14169386001)**

On all of this\.


**566.** `16:38` **You**

All of what is?


**567.** `16:38` **You**

Us?


**568.** `16:39` **Meredith Lamb (+14169386001)**

Yes\. You seem to be struggling with all my talking lol


**569.** `16:40` **You**

Seriously I have been trying to get through to the other side not run away\.\.


**570.** `16:40` **You**

Jesus


**571.** `16:40` **You**

Soul mates are that mer you don’t walk away


**572.** `16:41` **You**

This IS hard for me but I told
You I would rather be uncomfortable
Knowing than comfortable not and always wondering


**573.** `16:41` **You**

So therefore I think tmi needs to be put to bed get it out and be done with it\.


**574.** `16:41` **You**

If you have questions I can give you my answers


**575.** `16:42` **You**

When Mike asked about our respective histories he asked what I have shared\.\. and he laughed…


**576.** `16:45` **You**

I am kind of surprised you would think I would walk away from this considering the gpt you shared yesterday\.\. you think I am faking my feelings for you?


**577.** `16:46` **You**

I am looking right at you and don’t have to say anything but I think you should know how i feel\.


**578.** `16:48` **Meredith Lamb (+14169386001)**

One sec


**579.** `16:55` **Meredith Lamb (+14169386001)**

Sorry had to chat\. Just got home


**580.** `16:56` **Meredith Lamb (+14169386001)**

I don’t think you would change your mind\. My stupid head just goes there


**581.** `16:56` **Meredith Lamb (+14169386001)**

Logically I don’t think you would


**582.** `16:56` **Meredith Lamb (+14169386001)**

>
How did you answer this?

*💬 Reply*

**583.** `16:58` **You**

I laughed


**584.** `16:58` **You**

While you are willing to share openly\.  I am willing to share but I don’t love telling the stories\.


**585.** `16:58` **You**

He just couldn’t believe I was completely open


**586.** `16:59` **You**

Cause that isn’t me


**587.** `16:59` **Meredith Lamb (+14169386001)**

Really


**588.** `16:59` **You**

No


**589.** `16:59` **You**

Not even a bit


**590.** `16:59` **You**

Opposite


**591.** `16:59` **Meredith Lamb (+14169386001)**

And what did he think about your tmi struggles? I’m crazy?


**592.** `16:59` **You**

I hold my cards close and don’t let people know anything that could hurt me


**593.** `16:59` **You**

No he agreed with my conclusion


**594.** `17:00` **You**

And kind of what I decide


**595.** `17:00` **You**

Decided


**596.** `17:01` **You**

He knows why i struggle he also
Knows why I am pushing through it


**597.** `17:01` **Meredith Lamb (+14169386001)**

He didn’t think you should run away lol


**598.** `17:01` **You**

No


**599.** `17:01` **Meredith Lamb (+14169386001)**

Get out while you can?


**600.** `17:01` **You**

You are basically me


**601.** `17:02` **You**

Your level
Of intensity and crazy took you somewhere else\.\. well a lot
Of the same places
But let’s say I have visited quite a few more times\.\. and there were a lot
Of things in that I never that weren’t asked so I didn’t have to answer


**602.** `17:02` **You**

So if I can look back at
My own life\.\. and not cringe too much\.


**603.** `17:03` **You**

I should be able to handle yours


**604.** `17:03` **You**

Therefore no more
TMI\.\. if
You want to share you share\. Without worry I still might react I might say ok done for the night


**605.** `17:03` **You**

But I am not going anywhere mer


**606.** `17:05` **Meredith Lamb (+14169386001)**

k I appreciate that\. I don’t want to make things hard for you though\. This shouldn’t be hard\! So I will do my best to act like an actual adult \(80% of the time\)


**607.** `17:06` **You**

>
Still cannot believe this Jesus\.  I woke up this morning still messing with you in the marry me thing and you think I am running away?

*💬 Reply*

**608.** `17:06` **You**

Or maybe that was last night


**609.** `17:06` **You**

Either way


**610.** `17:07` **You**

So share
Or don’t share about jay chris Steve Jeremy Gavin Andrew or anyone in between\.\.  your call I will still tell you if and when I have
Had enough but I\. Will process
It\.


**611.** `17:09` **Meredith Lamb (+14169386001)**

>
My head is stupid sometimes\.

*💬 Reply*

**612.** `17:11` **Meredith Lamb (+14169386001)**

It was when I was driving… I dunno\. Honestly… I just get these conflicting thoughts sometimes


**613.** `17:12` **Meredith Lamb (+14169386001)**

>
Curious of these “things that weren’t asked”

*💬 Reply*

**614.** `17:09` **You**

No it’s not\.\. But I don’t understand\.\. what do you think you shared that would make me think that\.


**615.** `17:12` **You**

Is this Chris tmi thing a really bad
One?  I promise I have done worse
That I have not sharedd


**616.** `17:12` **You**

>
Like what

*💬 Reply*

**617.** `17:13` **You**

Like you don’t actually think we are\.\.
Meant to be or not


**618.** `17:13` **You**

That kind of stuff


**619.** `17:13` **Meredith Lamb (+14169386001)**

No the Chris thing is not a situation\. It is just the reasons I know he is gay and not bi whereas he doesn’t know\. It’s not deep\. But also, it isn’t significant\. And totally not relevant to anything right now\.


**620.** `17:13` **You**

>
Just things I have done adventures
I have had

*💬 Reply*

**621.** `17:14` **You**

So why the tmi?


**622.** `17:14` **Meredith Lamb (+14169386001)**

>
No I think we are but I was just wondering if I was too much for you\.

*💬 Reply*

**623.** `17:14` **You**

See that will
Always be like a big flashing light now


**624.** `17:14` **You**

>
Like i said I was worried you were like back in march april\.

*💬 Reply*

**625.** `17:16` **Meredith Lamb (+14169386001)**

>
Because I don’t think that conversation is for you\. Lol

*💬 Reply*

**626.** `17:16` **Meredith Lamb (+14169386001)**

>
Wait what will be?

*💬 Reply*

**627.** `17:16` **You**

>
I am going to take a wild guess that in those 19 questions we chose not to respond to the answer
Is there\.\.
It’s fine\.

*💬 Reply*

**628.** `17:17` **You**

>
When you call out tmu

*💬 Reply*

**629.** `17:17` **You**

TMI I am going to want to know now because


**630.** `17:17` **You**

I think that kind of connection is what you are looking for


**631.** `17:17` **Meredith Lamb (+14169386001)**

>
No that is not what I’m talking about at all\. Get your head out of the gutter\. I’m talking about really basic things\.

*💬 Reply*

**632.** `17:18` **You**

Hmm deleted\.\.
I guess
lol


**633.** `17:18` **Meredith Lamb (+14169386001)**

It’s not tmi in general but it is for you because it involves Chris …


**634.** `17:19` **Meredith Lamb (+14169386001)**

That’s basically it\. Wasn’t going there


**635.** `17:19` **You**

I thought we
We’re
Going to close the book
In him know everything so we never have to worry about it again\.\. but your being worried to tell me after
All the other stuff\.\.
lol


**636.** `17:20` **Meredith Lamb (+14169386001)**

I’m not “afraid”\. I just feel like I need to manage my communication style better lol


**637.** `17:20` **Meredith Lamb (+14169386001)**

You literally told me that


**638.** `17:20` **You**

Mm hmm


**639.** `17:21` **Meredith Lamb (+14169386001)**

I want to know how you framed your convo to Mike


**640.** `17:21` **You**

Kk let’s drop it\.


**641.** `17:21` **Meredith Lamb (+14169386001)**

I’m interested in how you frame this


**642.** `17:22` **You**

I will try to forget\. Not sure how well that will work but will try


**643.** `17:22` **You**

Reaction: ❤️ from Meredith Lamb
I told him I love you you are my soul mate\.  I told him I have never felt like this with anyone\.  I told him about how I feel
When I am with you and when I am not


**644.** `17:22` **You**

I told him about the convo at the cottage and how that made me feel


**645.** `17:23` **You**

I was brutally honest… because I can be with him


**646.** `17:23` **You**

Because he knows EVERYTHING about me\.
Closer than a brother


**647.** `17:24` **You**

I told him about our progression\.\.
About the ChatGPT about how I feel when we just sit and talk\.
About how I feel on the Friday,
The other night,
Last night


**648.** `17:24` **You**

The decisions I made


**649.** `17:25` **Meredith Lamb (+14169386001)**

Omg ok, so the reason I know Chris is gay and not bi is because I was obviously with him … he did everything different\. Very gay\. Hard to explain\. And was just completely out of his element with me whenever we were doing anything beyond hanging out and drugs\. That’s really all I was going to say\. Maybe if I was drunk I would have been more detailed like wrt how he touches vs a straight/bi person etc etc but not sure bc I ain’t drunk right now\. 😇 But it was pretty simple but I didn’t want to go there because it is all baes on he and I being together and I know that is bothersome\.


**650.** `17:25` **You**

My thought process,
Logic and conclusions


**651.** `17:25` **You**

>
No that is not bothersome it makes sense\.

*💬 Reply*

**652.** `17:28` **You**

>
I still don’t get this honestly the whole thing and your resistance to calling it friends with benefits\.\. it kind of either is or it was a true relationship\. That was always confusing to me

*💬 Reply*

**653.** `17:28` **You**

Are you going to get wine now?


**654.** `17:29` **Meredith Lamb (+14169386001)**

No more wine for a while lol


**655.** `17:29` **You**

Mi actually feel you are conflicted
About it


**656.** `17:30` **Meredith Lamb (+14169386001)**

>
So maybe it was friends with benefits in the beginning but it moved to friends only after that\.

*💬 Reply*

**657.** `17:30` **Meredith Lamb (+14169386001)**

>
About wine?

*💬 Reply*

**658.** `17:30` **You**

And I think your other boyfriends might have as well\. The trend


**659.** `17:30` **You**

lol


**660.** `17:30` **You**

Chris and what he was to you


**661.** `17:30` **You**

Not wine


**662.** `17:30` **You**

No conflict there


**663.** `17:30` **Meredith Lamb (+14169386001)**

lol


**664.** `17:31` **Meredith Lamb (+14169386001)**

>
We were friends only for longer than friends that do other shit\. Lol

*💬 Reply*

**665.** `17:31` **Meredith Lamb (+14169386001)**

That’s why I’m reluctant to label him as that


**666.** `17:32` **You**

I have had those relationships


**667.** `17:32` **Meredith Lamb (+14169386001)**

Because he wasn’t for the full time period


**668.** `17:32` **You**

But not in reverse


**669.** `17:32` **You**

That part is weird


**670.** `17:32` **Meredith Lamb (+14169386001)**

Not when someone is gay


**671.** `17:32` **You**

And again had I been someone back then I would have had a hard
Time to believe it


**672.** `17:32` **Meredith Lamb (+14169386001)**

He went through a huge boy craze phase


**673.** `17:32` **You**

Sone things transcend that shit


**674.** `17:33` **You**

He could have been pan mer\. It wasn’t defined yet


**675.** `17:33` **Meredith Lamb (+14169386001)**

No


**676.** `17:33` **You**

It wasn’t that he liked girls he just liked you


**677.** `17:34` **Meredith Lamb (+14169386001)**

Meh maybe \.\. but whatever doesn’t matter now


**678.** `17:34` **You**

I feel like either you already are or are about to get uncomfortable


**679.** `17:34` **You**

And start dodging so we can change topic


**680.** `17:34` **Meredith Lamb (+14169386001)**

lol win not uncomfortable


**681.** `17:34` **Meredith Lamb (+14169386001)**

It was just a long time ago


**682.** `17:34` **Meredith Lamb (+14169386001)**

I’m not


**683.** `17:35` **You**

Ok


**684.** `17:36` **Meredith Lamb (+14169386001)**

I just really love you and would like to focus on that \(and not ruining it\)


**685.** `17:36` **You**

You aren’t ruining it Mer\.  You can’t


**686.** `17:37` **You**

I swear I have told you this\.\. however much you think I love you\.\. you are lowballing it by a factor of 100


**687.** `17:37` **You**

Edited: 2 versions
| Version: 2
| Sent: Sun, 8 Jun 2025 17:37:50 \-0400
|
| Bursting would not do it justice
|
| Version: 1
| Sent: Sun, 8 Jun 2025 17:37:35 \-0400
|
| Bursting would be a euphemism\.


**688.** `17:40` **You**

Like you just don’t get it


**689.** `17:40` **Meredith Lamb (+14169386001)**

So we are fine on all of this crap?


**690.** `17:40` **You**

Yeah


**691.** `17:40` **You**

We are absolutely fine


**692.** `17:40` **Meredith Lamb (+14169386001)**

🥳


**693.** `17:40` **Meredith Lamb (+14169386001)**

What was mikes advice


**694.** `17:40` **Meredith Lamb (+14169386001)**

Did he have any


**695.** `17:40` **Meredith Lamb (+14169386001)**

Did you ask him for any or no


**696.** `17:41` **Meredith Lamb (+14169386001)**

Just talked


**697.** `17:41` **You**

See now you don’t really have to worry about this anymore\.\. sorry if it was painful to get through\.\. but I think we are done now\.


**698.** `17:41` **You**

He didn’t have any advice he told
Me to be careful


**699.** `17:41` **You**

He was there when I put myself
Out there


**700.** `17:42` **You**

And he realizes how much more so I have done with you


**701.** `17:42` **Meredith Lamb (+14169386001)**

Everyone tells you to be careful lol


**702.** `17:42` **You**

He actually understands how much I love
You even if you don’t


**703.** `17:42` **Meredith Lamb (+14169386001)**

I do, really ❤️


**704.** `17:43` **You**

No you don’t you love me a lot\. But you don’t understand my feelings\.  I am not sure I do\.\. again I can only attribute it to I was only supposed to feel this way about one person\.


**705.** `17:43` **You**

People telling me to be careful has more to do with me and my history than anything about you


**706.** `17:44` **You**

He got what you were looking for being open\.


**707.** `17:47` **Meredith Lamb (+14169386001)**

>
He got it, you didn’t\. Lol

*💬 Reply*

**708.** `17:48` **You**

He got it when I explained it


**709.** `17:48` **You**

I basically walked him through your history


**710.** `17:49` **Meredith Lamb (+14169386001)**

Ohhh


**711.** `17:49` **You**

From high school \- jay
University \- insert number lol
Steve
Chris
Jeremy
Gavin
Andrew


**712.** `17:49` **Meredith Lamb (+14169386001)**

I wish I never said that now lol


**713.** `17:50` **You**

What?


**714.** `17:51` **Meredith Lamb (+14169386001)**

>
Insert \#\. How about 3\.

*💬 Reply*

**715.** `17:51` **You**

No that is the point


**716.** `17:51` **You**

How about 25


**717.** `17:51` **You**

Feel better?


**718.** `17:52` **Meredith Lamb (+14169386001)**

Yes\. I actually am not sure of a number but it isn’t high


**719.** `17:52` **You**

Reaction: 😂 from Meredith Lamb
Consider the drugs you have done and just convert that relationally to people for my side


**720.** `17:52` **You**

Only way to give you a sense


**721.** `17:52` **You**

I don’t like talking about it but I do not want to make
You feel bad


**722.** `17:52` **Meredith Lamb (+14169386001)**

Does Jamie know that?


**723.** `17:52` **You**

She knows the number is north of 30 well north


**724.** `17:53` **You**

She knew that before we became serious


**725.** `17:53` **You**

I didn’t want to lie and she asked


**726.** `17:53` **Meredith Lamb (+14169386001)**

Ah ok that’s good


**727.** `17:54` **You**

Why is that good lol


**728.** `17:54` **You**

She wasn’t happy


**729.** `17:54` **You**

I was \# 3


**730.** `17:54` **You**

For her


**731.** `17:55` **Meredith Lamb (+14169386001)**

It is good that you didn’t lie


**732.** `17:55` **Meredith Lamb (+14169386001)**

I certainly omitted much of who I was when Andrew and that was probably a big mistake


**733.** `17:55` **You**

I still couldn’t tell her the exact number


**734.** `17:56` **You**

>
Do you think the relationship would have proceeded

*💬 Reply*

**735.** `17:57` **Meredith Lamb (+14169386001)**

Not sure honestly\.


**736.** `17:58` **You**

I mean he seems a bit twisted if he got over his issues he might not have had a problem


**737.** `17:58` **Meredith Lamb (+14169386001)**

Yeah, probably wait\. Are you saying I’m twisted?


**738.** `17:58` **Meredith Lamb (+14169386001)**

lol


**739.** `17:59` **You**

No\!\! ROFL


**740.** `17:59` **You**

But if you are I M


**741.** `17:59` **You**

Am


**742.** `17:59` **Meredith Lamb (+14169386001)**

I’m not even sure why I did such a drastic switch\. I don’t even know it was like rebound and I don’t know\. I didn’t even have time to think after Jeremy and then all of a sudden I was just in another relationship\.


**743.** `17:59` **You**

And well I am


**744.** `17:59` **You**

lol


**745.** `17:59` **Meredith Lamb (+14169386001)**

>
You totally are calling me that\!

*💬 Reply*

**746.** `17:59` **Meredith Lamb (+14169386001)**

I mean, as long as you are too then that’s fine\. I’m OK with it\.


**747.** `18:00` **You**

Are you denying it?


**748.** `18:00` **You**

lol


**749.** `18:00` **Meredith Lamb (+14169386001)**

Not really


**750.** `18:00` **Meredith Lamb (+14169386001)**

But no one’s ever been so blunt before geez


**751.** `18:00` **You**

Reaction: 😂 from Meredith Lamb
I mean brothers same night snow bank and you are like “
What??\!\!”


**752.** `18:01` **You**

I thought you might appreciate some stark honesty


**753.** `18:01` **Meredith Lamb (+14169386001)**

>
I’m not sure I would’ve told you this sober\. lol maybe not sure

*💬 Reply*

**754.** `18:02` **Meredith Lamb (+14169386001)**

>
I do actually

*💬 Reply*

**755.** `18:04` **You**

I mean I am\. Not sure if you had sex with both same night


**756.** `18:04` **You**

That would be spicy\.\. but I can relate\.


**757.** `18:07` **Meredith Lamb (+14169386001)**

The answer is no but I am not going into details\.


**758.** `18:07` **Meredith Lamb (+14169386001)**

Not sure if I mentioned they were HALF brothers so


**759.** `18:07` **You**

Doesn’t matter


**760.** `18:08` **Meredith Lamb (+14169386001)**

In my head it does


**761.** `18:09` **Meredith Lamb (+14169386001)**

It actually really bothered one of them :p


**762.** `18:09` **You**

I know it did you did naughty things with both


**763.** `18:09` **You**

And they were like who was better… guaran fucking teed


**764.** `18:10` **You**

Cause that is guys\.


**765.** `18:11` **You**

And maybe some stark honesty came out


**766.** `18:11` **You**

lol


**767.** `18:11` **Meredith Lamb (+14169386001)**

Well it was complex\. Anyway, twisted eh? Does Mike now think I’m twisted? Am I ever going to meet this person? Is it going to be weird? So many questions


**768.** `18:12` **You**

Reaction: ❤️ from Meredith Lamb
Complex rofl
Honestly I bet you wish you changed open to slightly ajar\.


**769.** `18:12` **You**

I don’t think you are comfortable with this unless
You are drunk


**770.** `18:12` **You**

He doesn’t you will and no


**771.** `18:12` **You**

He will love you because I do


**772.** `18:12` **You**

And because he loves me


**773.** `18:14` **Meredith Lamb (+14169386001)**

It was complex bc I had a bit of a thing \(again, complex\) with Tim and then Joe just showed up on new years\. But Tim and I weren’t “together” … hence the complex


**774.** `18:14` **Meredith Lamb (+14169386001)**

Tim was upset by the whole thing\. Anyway… see I can when I’m not drunk\.


**775.** `18:14` **Meredith Lamb (+14169386001)**

Probably makes better sense also


**776.** `18:15` **Meredith Lamb (+14169386001)**

>
He probably so does\.

*💬 Reply*

**777.** `18:15` **Meredith Lamb (+14169386001)**

>
This was university\. You probably were with 10 people in this timeframe alone lol

*💬 Reply*

**778.** `18:16` **Meredith Lamb (+14169386001)**

It was my final year


**779.** `18:16` **You**

>
No I didn’t tell him details

*💬 Reply*

**780.** `18:16` **You**

I think my number I have you was
25


**781.** `18:16` **You**

And I wasn’t joking


**782.** `18:16` **Meredith Lamb (+14169386001)**

It’s ok, I trust you


**783.** `18:17` **Meredith Lamb (+14169386001)**

That number doesn’t scare me but yeah it is a lot lol


**784.** `18:18` **You**

That is undergrad


**785.** `18:19` **You**

I mean I am pretty sure my history is quite a bit more torrid than yours\.\. I should be more worried about how you will feel about me


**786.** `18:19` **Meredith Lamb (+14169386001)**

Torrid?


**787.** `18:20` **You**

full of passionate or highly charged emotions arising from sexual love\.


**788.** `18:20` **You**

Definition


**789.** `18:21` **Meredith Lamb (+14169386001)**

>
How do I feel about you? I mean, I just feel like I’m glad I have you all to myself\. That’s basically it lol

*💬 Reply*

**790.** `18:22` **You**

Reaction: ❤️ from Meredith Lamb
Good because you do there are no more adventures\.\. I honestly thought I would be alone\.\. but you are the only adventure left the only one I want\.\. and the best I am sure\.\.


**791.** `18:23` **You**

I will keep the rest of my stuff to myself unless
You ask\.


**792.** `18:24` **You**

Mike will
Like you a lot\.\.
He
Was a lot more tame than me\.\. but he was a player first\.


**793.** `18:24` **You**

Good looking smooth and he knew it lol\.\. was funny
To watch


**794.** `18:25` **Meredith Lamb (+14169386001)**

>
We will save it for some entertainment one night\. Lol I will just start asking\. Haha

*💬 Reply*

**795.** `18:26` **You**

Fair enough I will answer


**796.** `18:26` **You**

This feel
Like a bit of a relief to me\.\. you shouldn’t need to worry either anymore about your drunk shares either lol


**797.** `18:26` **You**

Even if they sting a bit it will go away fast


**798.** `18:27` **Meredith Lamb (+14169386001)**

I do not want to sting you in anyway\. Like not at all\. Owwwww


**799.** `18:29` **You**

I mean mer it just is\. It is more like a reaction\.\.
Like the your mine reaction


**800.** `18:29` **You**

Or a fleeting fuck some other thing that I will never be able to share


**801.** `18:29` **You**

It’s like that


**802.** `18:30` **You**

I told you I look back and wish I could have been there to make you happy all along


**803.** `18:30` **You**

Stupid


**804.** `18:30` **You**

But how I feel


**805.** `18:30` **You**

And again I can only attribute it to you and what this thing is


**806.** `18:31` **Meredith Lamb (+14169386001)**

I wish things were different in the past also but I’m happy with where they are now


**807.** `18:31` **You**

Yeah same


**808.** `18:31` **You**

Not saying I am not


**809.** `18:31` **You**

Just a reaction knee jerk


**810.** `18:32` **You**

Like if cote or cm flirted with me\.\. your reaction would be like that\.\. btw if someone flirted with you I would react exactly the same fyi


**811.** `18:32` **Meredith Lamb (+14169386001)**

That’s allowed\. It’s ok lol


**812.** `18:32` **You**

Just so you know


**813.** `18:33` **Meredith Lamb (+14169386001)**

>
Ok but I’ve explained before\. This is PRESENT not PAST\.

*💬 Reply*

**814.** `18:33` **Meredith Lamb (+14169386001)**

I’m not bothered by past\. It is done\.


**815.** `18:33` **Meredith Lamb (+14169386001)**

Now present…\.


**816.** `18:33` **Meredith Lamb (+14169386001)**

Different story


**817.** `18:34` **You**

I know and I would react the same but wanted to to understand the reactive nature\.\. it just happens


**818.** `18:35` **You**

I feel relief honestly there is a resolution and it is all good 😊


**819.** `18:35` **You**

It just took me a bit but I am not surprised\. Took much emotion I am not used to dealing


**820.** `18:36` **Meredith Lamb (+14169386001)**

Ok I’m glad you are feeling better about this\. That makes me feel better honestly


**821.** `18:38` **You**

Good so no more nonsense about me walking away never going to happen


**822.** `18:38` **You**

Certainly not from your past


**823.** `18:43` **Meredith Lamb (+14169386001)**

Okay 🙂


**824.** `18:46` **You**

So now what are we going to do\.\. lol this was so consuming we won’t have amything to match it


**825.** `18:47` **You**

I think you need a break anyways


**826.** `18:49` **Meredith Lamb (+14169386001)**

We will focus on us and moving forward \- so much fun to be had\. I think we can keep busy :\)


**827.** `18:50` **Meredith Lamb (+14169386001)**

I think today I no longer report to you


**828.** `18:50` **Meredith Lamb (+14169386001)**

Btw


**829.** `18:50` **You**

We will see\.\. hard to talk about a moving target lol\.


**830.** `18:50` **You**

You don’t


**831.** `18:52` **Meredith Lamb (+14169386001)**

>
What’s the moving target

*💬 Reply*

**832.** `18:52` **You**

Anything and everything lol


**833.** `18:54` **You**

Separation agreements, living in new arrangements\. Us in the future
lol it is difficult to discuss in abstracts we
Will have to find other topics\.


**834.** `18:55` **Meredith Lamb (+14169386001)**

Oh THAT\. Yeah lol


**835.** `18:55` **You**

Oh yeah that\.\. rofl


**836.** `18:56` **You**

Anyways relax take a few days rest start your new job\.  Stop worrying about me\.


**837.** `18:56` **You**

We don’t need to stay so intense\.\. you can relax\.\. I would rather be a refuge that’s another challenge to deal with


**838.** `19:01` **You**

I mean intense talking it has to wear you out\.


**839.** `19:01` **You**

The other intense stuff yeah that isn’t stopping


**840.** `19:02` **You**

Reaction: ❤️ from Meredith Lamb
Not on my part 😈


**841.** `19:02` **Meredith Lamb (+14169386001)**

I don’t think you wear me out oddly\. But despite how well we know each other we are still getting to know each other so I’m trying to learn as I go too\.


**842.** `19:03` **You**

Well you have learned a lot and fast\.\. so have i\.


**843.** `19:06` **You**

Like I said take a break Mer\.\.  I love you and I know this was ALOT and I appreciate your supporting me through this\.


**844.** `19:10` **Meredith Lamb (+14169386001)**

Well I’m glad you came through unscathed …\. Is that accurate? Probably not lol


**845.** `19:10` **You**

Meredith I love you even more\.\.  because not despite\.


**846.** `19:11` **You**

And I want to explore our own future and am happy and open to trying whatever you want


**847.** `19:16` **You**

We just need some space and time\.\. I think the rest will take care of it\. I am unscathed\.\.  I just had to go through this in order to process it\.\. it is better this way\.


**848.** `19:18` **Meredith Lamb (+14169386001)**

Yeah I understand it a bit more now\. I do really wish we could spend more time together like at the cottage \(like not drinking per se but just more extended time but we will just waaaait\. :\)


**849.** `19:19` **Meredith Lamb (+14169386001)**

I think you would have processed better if we spent more time together \(sober\)


**850.** `19:19` **Meredith Lamb (+14169386001)**

lol


**851.** `19:24` **You**

Mmm


**852.** `19:24` **You**

Probably not


**853.** `19:25` **You**

My head was where it was


**854.** `19:25` **You**

The only thing that would be different


**855.** `19:26` **You**

Would be perhaps that you wouldn’t have spoken so passionately about the Chris situation\.


**856.** `19:29` **Meredith Lamb (+14169386001)**

Passionately


**857.** `19:29` **Meredith Lamb (+14169386001)**

Hmm


**858.** `19:29` **Meredith Lamb (+14169386001)**

Man


**859.** `19:29` **You**

Hey listen, I am not rehashing it is accurate mer not accusatory\.\. I feel like you had some guilt
To work through some regret him not getting g back to you


**860.** `19:30` **You**

Nd you had a lot of fun that you were forced to kind of set aside


**861.** `19:30` **You**

>
What is wrong with what I said\.\.

*💬 Reply*

**862.** `19:30` **You**

If
You were sober you never would have admitted any of that to me\.


**863.** `19:33` **Meredith Lamb (+14169386001)**

I probably would have but in a different way\.


**864.** `19:33` **Meredith Lamb (+14169386001)**

Not “passionately” lol


**865.** `19:35` **You**

You wouldn’t have because you cannot Remeber lol\.\.


**866.** `19:35` **You**

Wistfully, emotionally,


**867.** `19:36` **You**

Forlornly


**868.** `19:36` **Meredith Lamb (+14169386001)**

lol omg stop


**869.** `19:36` **You**

Longing


**870.** `19:36` **You**

Plaintive


**871.** `19:36` **You**

I got lot


**872.** `19:36` **You**

More


**873.** `19:36` **Meredith Lamb (+14169386001)**

We’re good


**874.** `19:36` **Meredith Lamb (+14169386001)**

Got plenty


**875.** `19:36` **You**

Kk figured


**876.** `19:38` **You**

>
I think you wish in general you didn’t tell me half of what you did but in all honesty this is a good outcome\.\. despite how we got here\. We
Will be more resilient\.\. and you don’t have to worry as
Much\.

*💬 Reply*

**877.** `19:39` **Meredith Lamb (+14169386001)**

Honestly, I don’t really really have regret about telling you but I have regret in the manner\. Drunk, can’t remember etc so I wasn’t very thoughtful about it all\. That’s more regretful than actually telling you stuff… Yunno\.


**878.** `19:40` **You**

Yah fair enough\.\. but we are good so\.\. like you said just need to find time\.


**879.** `19:43` **Meredith Lamb (+14169386001)**

When do you have to do your airport pick up


**880.** `19:44` **You**

Late


**881.** `19:44` **You**

Like really late


**882.** `19:44` **You**

Why


**883.** `19:44` **Meredith Lamb (+14169386001)**

Was just curious


**884.** `19:44` **Meredith Lamb (+14169386001)**

No reason


**885.** `19:44` **You**

Ok


**886.** `19:45` **You**

Her flight arrives 12:39


**887.** `19:46` **You**

12:30


**888.** `19:48` **Meredith Lamb (+14169386001)**

Yikes


**889.** `19:49` **You**

It is what it is


**890.** `19:49` **You**

Reaction: 😮 from Meredith Lamb
I am getting up to workoutnstill


**891.** `19:53` **You**

Same tomorrow back into my morning routine looking forward to its


**892.** `19:53` **You**

Not to work


**893.** `19:53` **You**

Reaction: 👎 from Meredith Lamb
Oh you should call your parents soon game comes in at 8


**894.** `19:56` **Meredith Lamb (+14169386001)**

>
Not looking forward to work for real?

*💬 Reply*

**895.** `19:56` **You**

Nope


**896.** `19:56` **You**

>
You seemed to have fun last time

*💬 Reply*

**897.** `19:57` **You**

A little sad you will be gone tbh I know it is best thing for you and us still cannot help feeling is is a bit of a loss\. Stupid I know\.


**898.** `19:57` **You**

I think that is how we started and I very much liked it then and now


**899.** `19:57` **You**

Probably is what got us to here\.


**900.** `19:59` **Meredith Lamb (+14169386001)**

Yeah same\. I just could not work for you while in a relationship though\. Sooooooooo challenging\. Probably would have stuck it out if this never happened\.


**901.** `20:01` **You**

Yeah probably you were good at it


**902.** `20:02` **Meredith Lamb (+14169386001)**

Meh not really\. Didn’t love it tbh\. Like all the people but the role \- meh


**903.** `20:03` **Meredith Lamb (+14169386001)**

lol


**904.** `20:03` **You**

😢


**905.** `20:03` **Meredith Lamb (+14169386001)**

Highly recommend the Manager\.


**906.** `20:04` **You**

I suck right now


**907.** `20:04` **You**

I am doubly distracted


**908.** `20:04` **You**

Likely to continue


**909.** `20:04` **You**

For a while


**910.** `20:06` **Meredith Lamb (+14169386001)**

I think you can get your head back in the game now\. And once the agreement moves along…\.


**911.** `20:06` **You**

Mmmmm I dunno


**912.** `20:06` **You**

We will see


**913.** `20:08` **Meredith Lamb (+14169386001)**

We will\. I don’t think you should workout tho tomorrow in morning good lord


**914.** `20:12` **You**

Why


**915.** `20:12` **You**

I am not going to airport tonight


**916.** `20:12` **You**

I am doing that tomorrow night


**917.** `20:12` **You**

So Tuesday morning will be hard


**918.** `20:12` **You**

But yeah I am going\. Tomorrow


**919.** `20:14` **Meredith Lamb (+14169386001)**

Oh I thought tonight


**920.** `20:15` **You**

Nope tomorrow night


**921.** `20:27` **Meredith Lamb (+14169386001)**

Time hop… walking in the field … thought you might lol at this one

*📎 1 attachment(s)*

**922.** `20:29` **You**

Why would I lol I love every single picture you send me


**923.** `20:29` **Meredith Lamb (+14169386001)**

Walking in the field with wine


**924.** `20:29` **You**

I am going to gotmhow I feel tonight


**925.** `20:29` **Meredith Lamb (+14169386001)**

It’s kind of lol


**926.** `20:30` **You**

Gpt how I feel and send it


**927.** `20:30` **Meredith Lamb (+14169386001)**

Oh I was wondering that typo


**928.** `20:30` **Meredith Lamb (+14169386001)**

lol


**929.** `20:31` **You**

It is going to heavy and detailed


**930.** `20:32` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Mac’s leopard phase\.

*📎 1 attachment(s)*

**931.** `20:33` **You**

Are you feeling regret


**932.** `20:33` **You**

It is a lot to walk away from


**933.** `20:33` **You**

A lot of memories etc


**934.** `20:34` **Meredith Lamb (+14169386001)**

I got this shirt for her bday leopard party lol

*📎 1 attachment(s)*

**935.** `20:34` **Meredith Lamb (+14169386001)**

Nope no regret\. I am not walking away from my kids at all\.


**936.** `20:34` **You**

>
Do you still have it?

*💬 Reply*

**937.** `20:34` **Meredith Lamb (+14169386001)**

lol no I do not


**938.** `20:34` **You**

:\(


**939.** `20:43` **You**

Reaction: ❤️ from Meredith Lamb
When you first met me\.

*📎 1 attachment(s)*

**940.** `20:44` **You**


*📎 1 attachment(s)*

**941.** `20:45` **Meredith Lamb (+14169386001)**

>
You seemed like a happy person\. I think you were then\.

*💬 Reply*

**942.** `20:46` **You**

Used to be good…

*📎 1 attachment(s)*

**943.** `20:46` **You**

I was happy with the kids\.


**944.** `20:48` **You**

I feel like that is the only me you will ever see\.\. maybe a bit sad sometimes or a bit anxious or maybe insecure\.\. but I think you get happy me forever


**945.** `20:50` **Meredith Lamb (+14169386001)**

I’m ok if you aren’t always happy\. Life isn’t always happy\. I just won’t like if you are unhappy because of ME\.


**946.** `20:51` **You**

I don’t see that as being a problem


**947.** `20:51` **You**

Per se


**948.** `20:51` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**949.** `20:52` **You**

Are Mac and I going to be friends?


**950.** `20:53` **You**

I need to do the Facebook block friends thing


**951.** `20:54` **Meredith Lamb (+14169386001)**

No she won’t add you don’t worry lol


**952.** `20:54` **You**

Still doing it anyways


**953.** `20:56` **You**

I actually have you access to my friends list and that is it


**954.** `21:14` **Meredith Lamb (+14169386001)**

I thought you were doing gpt?


**955.** `21:18` **You**

I will


**956.** `21:18` **You**

lol


**957.** `21:18` **You**

Inpatient much


**958.** `21:18` **You**

Cleaning the kitchen


**959.** `21:19` **You**

Doing my job


**960.** `21:19` **You**

Going downstairs in 5
Mins to crush that got


**961.** `21:19` **You**

I am kind of curious where it lands


**962.** `21:20` **You**

Mistake


**963.** `21:21` **You**

Sry


**964.** `21:27` **You**

Ok gpt time


**965.** `21:38` **Meredith Lamb (+14169386001)**

lol I was just curious


**966.** `21:38` **You**

working on it dear


**967.** `21:39` **You**

wine?


**968.** `21:39` **You**

amd tv?


**969.** `21:45` **Meredith Lamb (+14169386001)**

No getting ready for bed


**970.** `21:45` **Meredith Lamb (+14169386001)**

Working out in morning


**971.** `21:45` **You**

nice


**972.** `21:46` **Meredith Lamb (+14169386001)**

No more wine for a while … can’t workout


**973.** `21:46` **You**

phew GPT is spicy


**974.** `21:47` **You**

I ran the query through a few different gpt'


**975.** `21:47` **You**

curious


**976.** `21:47` **Meredith Lamb (+14169386001)**

🧐


**977.** `21:49` **You**

Holy fuck\.


**978.** `21:49` **You**

I am going to paste them\.\. give me a min a few more to read


**979.** `21:50` **Meredith Lamb (+14169386001)**

This reaction has me very curious now


**980.** `21:56` **Meredith Lamb (+14169386001)**

Are you adjusting it bc it is too much


**981.** `21:56` **You**

no


**982.** `21:56` **You**

no you will get it raw


**983.** `22:00` **You**

ok you ready?


**984.** `22:00` **You**

the prompt is pretty long too\.\. maybe a bit\.\.


**985.** `22:01` **Meredith Lamb (+14169386001)**

I’m not sure\. Am I ready? Lol


**986.** `22:01` **You**

Reaction: ❤️ from Meredith Lamb
Are you familiar with the movie Roxeanne?? I need you to play the role of steve martin for me\.\. I am going to share some information with you and a request\.\. come back to me with your thoughts\.
I am trying to put into words for Meredith how I feel about her\.\. we have talked about being soul mates\.\. and while I never believed in that before, I do now\.\. we have talked about being home to each other\.\. which is real and meaningful\.  We have gone through a fast paced gauntlet of getting to know one another across time and space\.\. looking backwards and talking about what comes next\.
There have been amazing high's and heartbreaking low's  in a really short period of time\.  Personally, I felt I needed to step outside of my comfort zone\.\. I needed her to know "me" not who she thought I was at work, but who I am really\.\. and fast\.\. because I love her so much that I had to make sure she saw the whole truth about me\.\. so if she really did mean what she said about feeling the same way I do, she could do so with the knowledge of who I am\.
I am imperfect\.\. she was in a bit of a vulnerable position \(inebriated\) and shared some information very openly and emotionally that put me on my heels, and put a vice around my heart\.  It is the kind of thing you worry about\.\. someone looking backwards at what they had and wishing it could be true again\.  Through a few weeks, and a lot of tough conversations, I realized that this kind of open relationship, something she wasn't able to have with her husband who she is separating from , is what she wanted for us\.  But it wasn't something I was prepared for because I had difficulties not being jealous of the past, as irrational as that is\.  She pushed with me\.\. as worried as she was that I might run away, and we got through it\.\. and I think we are better and stronger for it\.  But for her to still worry at this point that I would walk away is concerning\.
More than soul mate, more than home, I need her to understand the absoluteness of my love for her\.\. how much she means to me as a friend, as a lover, and as a partner \(see a recent gpt in the transcript I shared that describes this\)\.  How much grief I have at only having met her at 47 is shocking to me, thinking about all of the things she has done, how amazing she is as a mom, and as a daughter and as a friend to so many others, and how I can never be a part of that\.  How much I long for us to move past our current situation \- which still might take years until we can actually live together\.\. and spend every day waking up to her and thinking about how I can make her happy today\.
I don't know what else to add here\.\. you have the transcript you can see how I feel in there as well\.  all of the things I have said\.\.  I still haven't figured out how to express that she cannot possibly know how much I love her\.  I need your help with this\.


**987.** `22:01` **You**

Reaction: 😂 from Meredith Lamb
this is just the prompt


**988.** `22:01` **You**

I also fed it transcript


**989.** `22:01` **You**

This is the first one\.\.
This is deeply heartfelt, and your vulnerability is profound\. Based on your message and the tone of your exchanges with Meredith, here’s a letter that captures your emotions—anchored in the themes of soulmates, home, honesty, and enduring love:
Meredith,
I’ve tried more than once to put this into words—but nothing I write ever feels big enough\. Because what I feel for you isn't just love\. It’s not just attraction or connection or even timing, though those things are all undeniably there\. It’s beyond\.
When we first started talking, everything happened so fast—like we were thrown into some cosmic gauntlet, colliding across time, past lives, and missed chances\. It felt like something out of a story, too much to be real\. And yet, here we are\.
I’ve never believed in soulmates\. Not really\. But I do now\. Because of you\.
We talked about being home to one another\. And that word—it means something different when it’s real\. You feel like home to me in a way nothing else ever has\. Not because it's perfect or easy\. But because it’s truthful, grounding, and full of light\.
I stepped so far outside my comfort zone for you, not because I was trying to impress you—but because I needed you to see the whole of me\. Not the version you saw at work\. Not the filtered one\. But the one with flaws, scars, stupid jokes, anxieties, and tenderness\. I needed to give you the full truth because I love you\. Desperately\. Deeply\. And if you were going to feel the same, I wanted it to be with eyes wide open\.
We’ve gone through amazing highs and heartbreaking lows\. In such a short time\. We’ve fought for something that matters\. And still—still—I sometimes hear in your voice the fear that I might walk away\. I need you to know this:
I am not going anywhere\.
More than a soul mate\. More than home\. You are it for me\. My person\. My friend\. My lover\. My partner\. And if there’s grief in knowing I met you at 47, it’s only because I wish I’d had more time with you\. I wish I’d been there to see the moments that shaped you—because you are extraordinary\. As a mother\. As a daughter\. As someone people trust and rely on\. And because I missed those years, I want every year we do have to matter\.
I dream of the day we can fall asleep beside each other without needing to plan or sneak around or count hours\. Of mornings where I wake up beside you and my only thought is, “What can I do to make her smile today?”
There are no perfect words for how much I love you, Meredith\. But if there were, they would sound like this: You don’t have to worry anymore\. I’m already yours\. In spirit, in heart, and every part of me\.
Let’s keep building this, even through the chaos\. Because what we have? It’s rare\. And it’s real\.
Yours,
Scott


**990.** `22:02` **You**

I will hold off pasting more until you get through


**991.** `22:04` **You**

laughing at my heartfelt prompt\.\. :\(


**992.** `22:04` **You**

I should take my responses back


**993.** `22:05` **You**

😝


**994.** `22:07` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I honestly think the prompt was enough ❤️


**995.** `22:07` **Meredith Lamb (+14169386001)**

Gpt was kind of repetitive


**996.** `22:07` **You**

It is a bit\.\. but it frames it better\.


**997.** `22:07` **You**

each one is slightly different\.\. or focuses on different things\.


**998.** `22:07` **Meredith Lamb (+14169386001)**

I like yours better 🙂


**999.** `22:08` **You**

I can just share the one I like the best if you want


**1000.** `22:08` **Meredith Lamb (+14169386001)**

k


**1001.** `22:08` **Meredith Lamb (+14169386001)**

How many did you do


**1002.** `22:08` **Meredith Lamb (+14169386001)**

lol


**1003.** `22:10` **You**

Meredith,
I've started this letter countless times, searching for words strong enough to hold everything I feel\. We've spoken of soulmates and finding home in one another, terms I once brushed aside as romantic fiction—but with you, they're profoundly real\. You're not merely someone I’ve fallen in love with; you’re someone who’s become integral to the very core of who I am\.
Everything between us unfolded rapidly, as if life itself couldn’t bear to waste more time keeping us apart\. It felt improbable—two souls colliding in the middle of chaos, past experiences, and guarded hearts\. Yet, amidst that storm, something rare took root, something that defies logic and convention\.
With you, I made a deliberate choice to step far beyond comfort zones\. I showed you every part of myself—the imperfections, insecurities, the anxieties I've always hidden—because I needed you to see the complete, unfiltered truth of who I am\. My intent was never to impress but to offer absolute honesty, allowing you the space to truly choose me\. And you did, even when confronted with my jealousies and vulnerabilities\.
When you shared your past with such open\-hearted honesty, it stunned me\. It shook me deeply because it revealed how fiercely I care, how desperately I wish I had been there to witness every chapter of your life firsthand—your journey as a mother, a daughter, a friend, and the remarkable woman you've become\. The grief of having missed out on your past is real, but it pales next to the overwhelming gratitude I feel now, knowing I can be part of your present and future\.
Meredith, this isn't a cautious or careful love\. It's a fierce, unequivocal commitment rooted in the absolute certainty that I've found my person\. My friend\. My partner\. My lover\. It’s a love that keeps expanding, becoming clearer and stronger every day\. I wish you could see yourself through my eyes—the kindness, intelligence, humor, and strength that define you in ways you might not fully realize\.
I dream of the day when waking up beside you isn't a rare joy but our everyday reality\. When my first thought each morning will always be: "How can I make her smile today?" I long for the simple intimacy of daily life, shared routines, whispered conversations late at night, and waking moments filled with nothing but us\.
We’ve faced challenges already, yet each has brought us closer, teaching me what absolute trust truly means\. I know waiting and navigating our complex circumstances isn’t easy\. But our connection isn’t fragile; it's resilient\. It’s been tested quickly and thoroughly, and each test has solidified rather than weakened what we share\.
If you ever doubt my commitment, let these words reassure you unequivocally: I'm not going anywhere\. Not today, not tomorrow, not ever\. You’re my truth, my future, and my only exception\. You’ve changed everything I thought I knew about love, about relationships, about myself\.
So here I am, Meredith—yours fully, completely, and irrevocably\. Let’s build this life together, slowly if we must, boldly whenever we can\. Because what we have is rare, precious, and entirely real\.
Always yours,
Scott


**1004.** `22:10` **You**

I did 4\-5


**1005.** `22:10` **You**

This is the one\.\.


**1006.** `22:11` **You**

runner up below
Meredith,
I never truly understood words like "soulmate" or "home" until you walked into my life\. Now, they make perfect sense—because they mean you\. We've built something extraordinary, defying odds, logic, and common sense\. It's been wild, messy, magical, and profoundly real—rare enough that even ChatGPT calls it unbelievable\.
I’ve spent my life guarded, reserved, keeping my truth carefully hidden\. But with you, every wall crumbled so easily it scared me\. I had to risk showing you the real me, flaws and fears, because loving you completely meant being completely myself—no pretending, no filters\. Just pure, honest vulnerability\.
When you opened your heart to me, when you shared your past, I felt that sharp pang—jealousy mixed with fear—that I wasn’t enough or might never be\. It was irrational, yes, but love isn't rational\. It’s raw, it’s messy, and it’s true\. But you, Meredith, you didn’t let me retreat\. You fought for our openness, and in doing so, you taught me to trust in something I've never fully believed before: absolute love\.
I see clearly now\. The past shaped you, but it's not where you live\. You live here, with me, in this moment we’re bravely creating\. Yes, it hurts knowing I wasn't there to witness you becoming the incredible mother, friend, daughter, and partner you are today\. I grieve those missed years deeply\. But this grief proves how profoundly I cherish you\.
Meredith, I want you to understand that my love isn't conditional\. It isn’t cautious\. It’s an unstoppable force, rooted so deeply that no insecurity, fear, or circumstance can weaken it\. You're not just my soulmate or my home—you're my truth, my future, and my reason\.
Every day away from you feels like wasted time, because all I dream of is waking up beside you, figuring out new ways to make you smile\. Whatever we face—distance, waiting, or life's complexity—I promise it will be worth it\. You are irreplaceable, and I intend to spend the rest of my life proving it to you\.
So, here’s my truth, Meredith, plain and clear: I love you with a completeness I can't fully express—but I'll spend my life trying\. You're my rare, my once\-in\-a\-lifetime, my only exception\.
Yours, absolutely,
Scott


**1007.** `22:11` **You**

this was fun\.\.


**1008.** `22:12` **You**

writing the prompt took some time\.\. but the letter was worth it\. I actually think it comes close to describing how I actually feel\.\.


**1009.** `22:17` **You**

I actually saved my fav letter in a word doc\.\. liked it\.\.


**1010.** `22:17` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Whoah 🫠🫠🫠 thats a lot to take in\. I think my heart literally skipped a beat\. Everyday say from you feels like wasted time for me for sure\.


**1011.** `22:17` **Meredith Lamb (+14169386001)**

Thanks for those ❤️❤️


**1012.** `22:17` **You**

I think you should keep it and read it again if you ever get anxious\.


**1013.** `22:18` **Meredith Lamb (+14169386001)**

k, will email it to myself


**1014.** `22:19` **You**

kk you should go to bed so you can get up and do your thing\.\. I am going to do the same get back to my usual routine\.


**1015.** `22:23` **Meredith Lamb (+14169386001)**

Ok, good night, I love you so much and will be thinking of you xox


**1016.** `22:24` **You**

Love you too Mer\.\. as much as the letter says and more ❤️❤️❤️ will cya when I cya\. Sleep well\.


