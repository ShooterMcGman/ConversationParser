# Daily Conversation: 2025-04-14 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-14 |
| **Day** | Monday |
| **Week** | 1 |
| **Messages** | 280 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-14T00:00 - 2025-04-14T23:55 |

## 📝 Daily Summary

This day contains **280 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:00` **You**

I swear there is literally nothing left and there hasn’t been for a really long time… I am choosing for me\.\.


**002.** `00:01` **You**

Kk let
Me
Go get this over with and get to sleep so I can wake up and see you tomorrow\.  Will be moved
To the basement tomorrow night and make it more permanent this week getting all my clothes etc


**003.** `00:01` **You**

Ok you good??  ❤️❤️❤️❤️


**004.** `00:01` **Meredith Lamb (+14169386001)**

I guess just an emotional day with the return from Aruba\.


**005.** `00:01` **Meredith Lamb (+14169386001)**

I am good


**006.** `00:02` **Meredith Lamb (+14169386001)**

I swear


**007.** `00:02` **You**

Me too I wasn’t looking forward
To it\.


**008.** `00:02` **Meredith Lamb (+14169386001)**

I know, complicated


**009.** `00:02` **You**

But I will get through this… and we will find some time
… soooon…\.


**010.** `00:02` **You**

Somehow


**011.** `00:03` **You**

I have more ideas
But I am keeping them
To
Myself


**012.** `00:03` **You**

😝


**013.** `00:03` **Meredith Lamb (+14169386001)**

Same :\)


**014.** `00:03` **You**

Reaction: ❤️ from Meredith Lamb
But I think another night at your parents might be in order


**015.** `00:04` **You**

Kk ❤️❤️❤️ nite xoxoxoxo


**016.** `00:04` **Meredith Lamb (+14169386001)**

My mom said we are 2 lost souls


**017.** `00:04` **Meredith Lamb (+14169386001)**

She wasn’t surprised


**018.** `00:04` **You**

lol


**019.** `00:04` **You**

Poetic


**020.** `00:04` **Meredith Lamb (+14169386001)**

Yah she’s an artist


**021.** `00:04` **Meredith Lamb (+14169386001)**

Weird one


**022.** `00:04` **You**

We very well
Might be


**023.** `00:04` **Meredith Lamb (+14169386001)**

lol


**024.** `00:05` **You**

Good thing is we got time…
But I want to hurry up and get
To using it\.


**025.** `00:05` **Meredith Lamb (+14169386001)**

Same\. :\(  I will see you tomorrow \(thank god\) xo \(I won’t say more than that but am thinking more than that\)


**026.** `00:06` **You**

Kk same nite xoxo


**027.** `06:08` **You**

All is well will see you at work\.


**028.** `06:39` **Meredith Lamb (+14169386001)**

k good to hear


**029.** `06:47` **You**

I figured it might be that’s why I messaged
You first thing


**030.** `06:47` **You**

Hope you slept
Ok I slept
Like shit


**031.** `06:57` **Meredith Lamb (+14169386001)**

Slept OK, nothing like Saturday night\.


**032.** `06:58` **You**

:\( sleeping at home always gave me good sleeps


**033.** `06:59` **Meredith Lamb (+14169386001)**

My parents isn’t my home tho and I normally sleep awful there… I think it was the company prior to sleeping\. Lol


**034.** `07:01` **You**

Well I would be happy to
Oblige on that whenever you would like\.  And by that whenever we can\.
lol


**035.** `07:06` **You**

On my way\! In


**036.** `07:20` **Meredith Lamb (+14169386001)**

Wow you are early


**037.** `07:50` **You**

I felt leaving early made sense


**038.** `08:57` **You**

Reaction: 👍 from Meredith Lamb
As an aside since I am looking into this too\.\. whatever ongoing support Andrew provides is tax deductible so he gets
Have back while you will pay tax on t you receive from him\.  In case you were unaware\.
You will also need to negotiate term etc\.  have fun I am sure I will\.


**039.** `08:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**040.** `08:58` **Meredith Lamb (+14169386001)**

Get ready for this


**041.** `08:58` **Meredith Lamb (+14169386001)**

Ugh


**042.** `09:06` **Meredith Lamb (+14169386001)**

>
He has a whole starting proposal for term\. 4 years at this, additional 4 years at that\. :p

*💬 Reply*

**043.** `09:53` **You**

>
See I told you I should be worried\!\!\! Gah…………

*💬 Reply*

**044.** `10:31` **Meredith Lamb (+14169386001)**

Just told Jim FINALLY


**045.** `10:50` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**046.** `10:50` **Meredith Lamb (+14169386001)**

>
No\.

*💬 Reply*

**047.** `12:18` **You**

I saw looking 😜


**048.** `12:24` **Meredith Lamb (+14169386001)**

lol


**049.** `12:25` **You**

Do you want to come in here for the 1 pm meeting?


**050.** `12:28` **Meredith Lamb (+14169386001)**

Is that a test? Kidding\.


**051.** `12:28` **Meredith Lamb (+14169386001)**

Maybe


**052.** `12:33` **You**

No if we in the meeting together


**053.** `12:33` **You**

Makes sense


**054.** `12:33` **You**

Nothing bad can possibly happen


**055.** `12:34` **You**

>
He is still not done I know it\! You are too awesome…\.

*💬 Reply*

**056.** `12:35` **Meredith Lamb (+14169386001)**

I’m thinking maybe I was just too nice at volleyball yesterday\.


**057.** `12:36` **Meredith Lamb (+14169386001)**

I was trying to be normal because Marlowe doesn’t know nor teammates and other parents\. Yunno


**058.** `12:36` **Meredith Lamb (+14169386001)**

Annoying situation\.


**059.** `13:55` **You**

Meh going to try to stay focused on long term cause short term is just icky\.\. lol so much going on so much to sort through\.  Etc


**060.** `14:01` **Meredith Lamb (+14169386001)**

Short term is so bad\. Omg\. 😳


**061.** `14:02` **Meredith Lamb (+14169386001)**

You saw my msg that I finally told Jim?


**062.** `14:32` **You**

Yeah I did\. Price that what did he say??  Are you and Scott
Finally hooking up?


**063.** `14:32` **You**

To which you responded well first base 🔥


**064.** `14:36` **You**

But in all honesty what did he say because I know it isn’t that\. Hehe


**065.** `14:39` **Meredith Lamb (+14169386001)**

He definitely DID NOT say that\. Lol


**066.** `14:39` **Meredith Lamb (+14169386001)**

He did the typical sorry to hear that etc\. Very supportive


**067.** `14:40` **Meredith Lamb (+14169386001)**

If he only knew\. Omg


**068.** `14:40` **You**

Well we should lay bets whether he is happy for us or he scolds us


**069.** `14:41` **Meredith Lamb (+14169386001)**

Hmmmh I honestly am not sure 🤔


**070.** `14:41` **Meredith Lamb (+14169386001)**

He is 9 yrs older and dad\-ish soooooo…\. Maybe scolding\.


**071.** `14:42` **You**

I am hoping for a high five and a “score\!\!\!”


**072.** `14:42` **You**

Reaction: 👎 from Meredith Lamb
Again when one of us are somewhere else I started looking today\.


**073.** `14:42` **Meredith Lamb (+14169386001)**

I dunno\. He might think you’re being stupid lol


**074.** `14:43` **You**

I mean it could be both


**075.** `14:43` **Meredith Lamb (+14169386001)**

True actually\.


**076.** `14:44` **You**

Nothing worth pursuing right now


**077.** `14:45` **Meredith Lamb (+14169386001)**

k good\.


**078.** `14:45` **You**

Yeah I know you don’t want me to go but the upside is we can be a bit more open\.


**079.** `14:45` **Meredith Lamb (+14169386001)**

But I could go easier


**080.** `14:46` **You**

I think unless it is really interesting and you would have an amazing boss you might be better here


**081.** `14:46` **You**

But I mean if something came up in Cara’s group might be a good opportunity and she likes you a lot I think\.


**082.** `14:47` **You**

All you would need to do is give her a heads up that you might be looking\. Or something like that


**083.** `14:48` **Meredith Lamb (+14169386001)**

I will say I can’t stand working for Scott\. He’s driving me nuts\. Lol


**084.** `14:48` **Meredith Lamb (+14169386001)**

Kidding


**085.** `14:52` **You**

lol I am ok with that if it is said in the right context\. ❤️


**086.** `15:10` **You**

Implementing: Mission Detroit\!\!


**087.** `15:14` **Meredith Lamb (+14169386001)**

Seems risky on your end\. I mean it would be nice to not behave but…\.\. also, find my, credit card, etc etc etc\!


**088.** `15:15` **Meredith Lamb (+14169386001)**

There is always Chatham


**089.** `15:38` **You**

Reaction: 😂 from Meredith Lamb
No way… I got this\!\! I have reached out to my friend in Ionia he is gonna get back to me later I am expecting good things\.\. i would likely take a last
Minute sdo at work and make something up and not put it in my calendar trust me best way to avoid suspicion send not out to team y expected family shot tomorrow won’t be in\.  I will drive up to Ionia Friday morning spend time with Jon and family soend night there come back mid day to Detroit chill out for the night go to Chatham Sunday\. Whenever I decide to check out which could be late…\.\. I already told Jaimie I might be doing this and she knows about John and the Chatham trip etc and I bought Jon’s book to get it signed… I think as long as I hear good things back from Jon we golden\.  We shall see though\.


**090.** `15:38` **You**

Virgo for the win\!\!\!


**091.** `15:40` **Meredith Lamb (+14169386001)**

Check out this listing \- looks out onto my girls’ high school football field\. Lol
https://realtor\.ca/real\-estate/28134003/609\-39\-roehampton\-avenue\-toronto\-mount\-pleasant\-west\-mount\-pleasant\-west?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**092.** `15:42` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
>
I forgot about this Jon plan\.

*💬 Reply*

**093.** `15:43` **You**

>
>
Looks great\!\! Soooo spacious\!\! ROFL just not what I am used to but it looks really sharp\.

*💬 Reply*

**094.** `15:59` **Meredith Lamb (+14169386001)**

Shoebox\.


**095.** `15:59` **Meredith Lamb (+14169386001)**

lol


**096.** `16:08` **Meredith Lamb (+14169386001)**

I had to run\. 4\.30 appt


**097.** `16:11` **You**

That’s fine\.\. j asked to come downtown with me tonight to main walk around I was like errr I planned on working… man I need her to accept this so I don’t feel like I will keep on hurting her\.  Plus 3\.5 hours of being grilled no thanks\.


**098.** `16:15` **Meredith Lamb (+14169386001)**

But maybe you need to have that conversation to get her through it\.


**099.** `16:20` **You**

Not in a car in parking garage where I have no exit strategy


**100.** `16:27` **Meredith Lamb (+14169386001)**

Well you could walk around eaton centre


**101.** `16:37` **You**

Eesh


**102.** `16:47` **Meredith Lamb (+14169386001)**

There’s a food court lol


**103.** `16:49` **You**

She cannot come anyways we couldn’t push forward her car pickup time


**104.** `16:58` **Meredith Lamb (+14169386001)**

I mean I would love to come see you but it would be so suspicious to my family


**105.** `17:04` **You**

Don’t you have anything to do at Easton centre


**106.** `17:04` **You**

lol


**107.** `17:04` **You**

I wasn’t going to suggest
It you raised it


**108.** `17:04` **You**

ROFL


**109.** `17:04` **You**

Don’t come if it is going to draw
Suspicion


**110.** `17:05` **You**

Don’t want to make your life more difficult


**111.** `17:05` **You**

On the other hand stairwell\.


**112.** `17:08` **Meredith Lamb (+14169386001)**

What time are you there until


**113.** `17:08` **Meredith Lamb (+14169386001)**

I’m not saying I’m going\. Just curious


**114.** `17:08` **You**

9:30 show gets out ish


**115.** `17:09` **You**

>
lol

*💬 Reply*

**116.** `17:09` **Meredith Lamb (+14169386001)**

I am “literally” in the car driving Marlowe 8\.10\-8\.25/8\.30ish home from volleyball soooo…\.


**117.** `17:10` **Meredith Lamb (+14169386001)**

Timing isn’t great


**118.** `17:10` **Meredith Lamb (+14169386001)**

What time do you arrive


**119.** `17:11` **You**

7:30


**120.** `17:11` **You**

Ish


**121.** `17:12` **You**

Just let me check it might be 2
Hours


**122.** `17:16` **You**

Nothing exact
60’to 90’mins


**123.** `17:16` **You**

lol


**124.** `17:26` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**125.** `17:26` **Meredith Lamb (+14169386001)**

It is difficult not ‘seeing’ you after that exchange


**126.** `18:15` **You**

lol I know I want to see you whenever I can tbh


**127.** `18:18` **You**

Meant every word\.\. I have to go for a drive will reach out when I am settled downtown\.


**128.** `19:03` **You**

I mean I particularly love the I do t get it at all part\.  You are weird totally not my type etc etc and despite all of
That…\.\. lol


**129.** `19:04` **You**

Just getting gas not there yet


**130.** `19:22` **Meredith Lamb (+14169386001)**

>
Not what I meant\!

*💬 Reply*

**131.** `19:35` **Meredith Lamb (+14169386001)**

To be clear, when I said “I don’t get it at all” I wasn’t referring to you… I was referring to how fast I am craving you\. You are completely my type so stop\.


**132.** `19:47` **You**

I am here


**133.** `19:47` **You**

Oh really how many bald 46
Year olds have you went out with


**134.** `19:50` **Meredith Lamb (+14169386001)**

I am on my way to go get marmar


**135.** `19:51` **Meredith Lamb (+14169386001)**

>
I was waiting for the perfect one\.

*💬 Reply*

**136.** `19:55` **You**

Hahaha


**137.** `19:55` **You**

I was right no baldies


**138.** `19:58` **Meredith Lamb (+14169386001)**

I mean it’s not like I’ve been out dating\. lol


**139.** `19:58` **You**

How many bald people have you dated ever 0


**140.** `19:59` **Meredith Lamb (+14169386001)**

I haven’t dated since I was 27\!


**141.** `19:59` **You**

Balding doesn’t count


**142.** `19:59` **Meredith Lamb (+14169386001)**

You can’t seriously be insecure about that can you?


**143.** `19:59` **You**

lol you still
Could have went out with bald
Guys in their 20s
I was bald at 20 or 21


**144.** `19:59` **You**

I am messing with you


**145.** `19:59` **You**

Just saying


**146.** `20:00` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**147.** `20:00` **You**

Oh I know that


**148.** `20:00` **Meredith Lamb (+14169386001)**

lol


**149.** `20:00` **Meredith Lamb (+14169386001)**

That counts


**150.** `20:00` **Meredith Lamb (+14169386001)**

I mean we didn’t date


**151.** `20:00` **Meredith Lamb (+14169386001)**

But we talk all the time


**152.** `20:00` **Meredith Lamb (+14169386001)**

Haha


**153.** `20:01` **Meredith Lamb (+14169386001)**

>
It’s not like I avoided them\. Just never happened\.

*💬 Reply*

**154.** `20:03` **Meredith Lamb (+14169386001)**

I don’t think you understand how attracted I am to you\. I will show you sometime\.


**155.** `20:05` **You**

I mean I feel so\. It attractive
Mer\.\.
lol\. Sorry is your eyesight ok?


**156.** `20:05` **You**

Unattractive


**157.** `20:06` **Meredith Lamb (+14169386001)**

I mean I’m sure your wife married you for a reason\.


**158.** `20:07` **You**

Well I made it to eaton centre parking lot… now I can relax


**159.** `20:07` **Meredith Lamb (+14169386001)**

It’s sad you feel that way though\. I am confident I can fix that


**160.** `20:07` **Meredith Lamb (+14169386001)**

>
I’m sitting in bishop Strachan parking lot

*💬 Reply*

**161.** `20:07` **Meredith Lamb (+14169386001)**

Marlowe takes forever to come out everytime\. I give her trouble and she doesn’t care\. Talks to friends comes out last


**162.** `20:07` **You**

Good times


**163.** `20:07` **You**

lol


**164.** `20:11` **You**

I mean mer I think it is going to take really a lot of practice because man I have been out of the game for a really really long time\.  I am just saying you have your work cut out for you\.  But I take direction well\.  Something for you to think about\.


**165.** `20:11` **Meredith Lamb (+14169386001)**

Do you though? Lol


**166.** `20:15` **Meredith Lamb (+14169386001)**

I feel like you are scared of me all of a sudden\.


**167.** `20:16` **You**

Reaction: ❤️ from Meredith Lamb
Quite the opposite


**168.** `20:16` **You**

Reaction: 😂 from Meredith Lamb
Just managing expectations\.


**169.** `20:16` **You**

And suggesting that a whole bunch of whatever you are suggesting would be well
Received lol


**170.** `20:16` **You**

You just have to read it the right way


**171.** `20:38` **Meredith Lamb (+14169386001)**

I hope you aren’t upset that I didn’t venture down there :\(


**172.** `20:38` **You**

Reaction: 😢 from Meredith Lamb
Just a bit sad and lonely


**173.** `20:38` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**174.** `20:38` **You**

I’m told
You jot to risk anything lol not worth the stress it would cause you


**175.** `20:39` **Meredith Lamb (+14169386001)**

I know\. I feel bad though


**176.** `20:39` **You**

It’s fine I will just relax and listen to music


**177.** `20:39` **You**

I should go get something to eat


**178.** `20:40` **Meredith Lamb (+14169386001)**

You should


**179.** `20:40` **Meredith Lamb (+14169386001)**

Maybe you’re hungry and that’s why you started spouting off about being unattractive:p


**180.** `20:40` **You**

I keep
Trying
To think of another chance to see
You before you go away this weekend


**181.** `20:41` **Meredith Lamb (+14169386001)**

I know


**182.** `20:41` **Meredith Lamb (+14169386001)**

Same


**183.** `20:41` **You**

No even j\. The pic I sent I didn’t feel it\.


**184.** `20:41` **You**

Always been like that


**185.** `20:41` **Meredith Lamb (+14169386001)**

>
Huh?

*💬 Reply*

**186.** `20:43` **You**

Ya know the one you snagged before I could delete it


**187.** `20:44` **Meredith Lamb (+14169386001)**

🙄


**188.** `20:44` **Meredith Lamb (+14169386001)**

I hope I don’t make you feel that way


**189.** `20:45` **Meredith Lamb (+14169386001)**

You know I could stare at you all day


**190.** `21:00` **You**

Sec I wanna say something nice but talking to Jonny


**191.** `21:00` **You**

Reaction: 😂 from Meredith Lamb
My Jonny not yours


**192.** `21:07` **You**

lol it’s all
Good I am
Old if you like me for who I am and take me as I am
What more can I ask for 🙂


**193.** `21:08` **You**

Btw closed the deal
With Johnny


**194.** `21:08` **You**

Staying with him Friday night the 25th in grand rapids


**195.** `21:09` **You**

What was that hotel you are at again?


**196.** `21:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**197.** `21:10` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**198.** `21:12` **Meredith Lamb (+14169386001)**

>
Pretty sure I’m older than you\.

*💬 Reply*

**199.** `21:25` **You**


*📎 1 attachment(s)*

**200.** `21:26` **You**

See you soon\.


**201.** `21:27` **Meredith Lamb (+14169386001)**

You are crazy


**202.** `21:27` **You**

☺️


**203.** `21:27` **You**

A little


**204.** `21:28` **You**

I keep feeling like you don’t think I am serious\.


**205.** `21:30` **Meredith Lamb (+14169386001)**

I think you are serious\. I just know you have a lot to sort through\.


**206.** `21:30` **Meredith Lamb (+14169386001)**

\(As do I\.\)


**207.** `21:30` **You**

Separate
For me\.
That and you  separate\.


**208.** `21:31` **You**

I know I have to get through everything else and I don’t want to jinx us but I don’t want to wait to spend time with you\.  Willing to be flexible lol\.


**209.** `21:33` **Meredith Lamb (+14169386001)**

Do you think the weekend made things easier or more challenging?


**210.** `21:38` **You**

This weekend?  Just made more aware of stuff that I have already shared\.


**211.** `21:39` **You**

I mean I don’t know what easy or challenging means\.  Not being with you is challenging\.


**212.** `21:42` **You**

Going to pickup kiddos and head home if you are still up will text
You and you can answer
Your own question for me\.


**213.** `21:43` **Meredith Lamb (+14169386001)**

>
This is what I mean\. The more we connect the more challenging it gets?

*💬 Reply*

**214.** `21:44` **Meredith Lamb (+14169386001)**

>
k, talking to Andrew about his $4,500 …\.\. 🫤

*💬 Reply*

**215.** `21:59` **Meredith Lamb (+14169386001)**

He literally just admitted that according to the guidelines it is probably $9k\. Anyway…


**216.** `22:01` **Meredith Lamb (+14169386001)**

He is still stuck on his $200k also\. I mentioned I brought 3 children in via 3 c sections but whatever\.


**217.** `22:58` **You**

If


**218.** `22:58` **You**

Oooof


**219.** `22:59` **You**

>
I do t think connecting is challenging I think finding the time to connect is\.  lol

*💬 Reply*

**220.** `23:03` **You**

I just got shit on for refusing to sleep in bed\.  So more fun here… she is sad I get it I am trying not to be mean but I think sleeping in bed as platonic as that is doesn’t help her adjust to the reality\.


**221.** `23:07` **Meredith Lamb (+14169386001)**

Yeah sounds sucky…\. we just had a big financial talk …\. it made my stomach sore so I said let’s continue later bc I need time to process\. I got “I’d give you a kiss good night but I’m not allowed to do that anymore\.” 😐


**222.** `23:08` **You**

lol


**223.** `23:08` **You**

The guilt


**224.** `23:08` **Meredith Lamb (+14169386001)**

This is brutal


**225.** `23:08` **You**

I got it too


**226.** `23:08` **You**

I just want a bit of comfort\.\. I said look that isn’t what you want you don’t want change but that is what is happening\.  I apologized then Gracie came down and yelled at me\.  Sall good
I M hiding in washroom
Again


**227.** `23:09` **Meredith Lamb (+14169386001)**

What did she yell at you for?


**228.** `23:09` **You**

Because I made mum cry and a bunch of other things


**229.** `23:10` **Meredith Lamb (+14169386001)**

Oh man…\.\.


**230.** `23:11` **You**

Reaction: 😤 from Meredith Lamb
Deleted


**231.** `23:11` **You**

Bleh


**232.** `23:11` **You**

Just paranoid shit mer\.\. not worthy of you\.


**233.** `23:12` **You**

Just trying to shut it down in my head


**234.** `23:12` **Meredith Lamb (+14169386001)**

You can say it


**235.** `23:13` **You**

If I weren’t in this picture would you give him another shot?  Because I wouldn’t give Jaimie one but I keep feeling like maybe if I wasn’t here initially to support and later go more you might have stuck around eventually\.


**236.** `23:13` **You**

Go = for


**237.** `23:14` **Meredith Lamb (+14169386001)**

I feel the same about you honestly\.


**238.** `23:14` **Meredith Lamb (+14169386001)**

I tried\.


**239.** `23:14` **Meredith Lamb (+14169386001)**

Did therapy etc


**240.** `23:15` **Meredith Lamb (+14169386001)**

I mean you made/make life easier through all this for sure


**241.** `23:15` **Meredith Lamb (+14169386001)**

But I think I would have done it


**242.** `23:15` **Meredith Lamb (+14169386001)**

He and I have zero connection\.


**243.** `23:15` **Meredith Lamb (+14169386001)**

It sucks


**244.** `23:15` **You**

I know but I still feel bad\.


**245.** `23:15` **Meredith Lamb (+14169386001)**

And I don’t respect him anymore


**246.** `23:16` **Meredith Lamb (+14169386001)**

What? No


**247.** `23:16` **Meredith Lamb (+14169386001)**

This is not on you at all but I get the feeling bc I feel the same way about you… really wonder


**248.** `23:17` **Meredith Lamb (+14169386001)**

Sometimes it is easy to stay put


**249.** `23:18` **You**

I mean I was saying no, no matter what, just timing,  but does make it easier to stay the course\.\. still I am 100% certain I would have continued on with maddie anyways\.


**250.** `23:18` **Meredith Lamb (+14169386001)**

A piece of me worries you are going to find out something about me you can’t stand and regret it


**251.** `23:19` **You**

Likewise\.  But I am not 20\. Everyone has flaws you love them all
The more for those\.


**252.** `23:19` **You**

Being an adult and
Going through this is very different


**253.** `23:19` **Meredith Lamb (+14169386001)**

True


**254.** `23:20` **You**

I mean we get that nothing is all
Roses , and nothing is perfect and that is fine, it would be boring if it was, but again never had a connection like I have with you\.\. it will get better I think the further away from this we get\.


**255.** `23:21` **You**

We already agreed if either was having second thoughts we would share immediately out of respect for the other


**256.** `23:21` **Meredith Lamb (+14169386001)**

I am having no such thing\.


**257.** `23:22` **You**

Me neither even through all the shit I can admit honestly I haven’t even wavered once,  not a bit always on message


**258.** `23:22` **Meredith Lamb (+14169386001)**

I just wish things were a little easier


**259.** `23:22` **You**

It is just time and opportunity


**260.** `23:23` **Meredith Lamb (+14169386001)**

But the next opportunity is so far away\. It is like a long distance relationship yet you are super close everyday in proximity lol


**261.** `23:23` **Meredith Lamb (+14169386001)**

Weirdest feeling ever


**262.** `23:24` **You**

Yeah same it feels like long distance even though you are sitting accross from me in morning


**263.** `23:25` **You**

I mean I am not complaining I will take whatever I can get


**264.** `23:25` **You**

lol


**265.** `23:45` **You**

Well you passed out lol night luv xoxoxoxo


**266.** `23:47` **Meredith Lamb (+14169386001)**

Sorry was watching the first episode of season 6 of handmaids tale … ending was so good


**267.** `23:48` **You**

lol no worries lol I just figured you passed out


**268.** `23:51` **Meredith Lamb (+14169386001)**

It’s distracting me from thinking… 😵‍💫


**269.** `23:51` **You**

Well I fled to the basement and am in bed now\.\. she was kind of bugging me again\.


**270.** `23:52` **Meredith Lamb (+14169386001)**

So you don’t think the bugging would work if I wasn’t around? Lol


**271.** `23:52` **You**

Nope not a chance


**272.** `23:53` **Meredith Lamb (+14169386001)**

I secretly wish I could just tell Andrew and be done with it\. But I will not be doing that


**273.** `23:54` **You**

It
Would be a bad
Choice yah


**274.** `23:54` **Meredith Lamb (+14169386001)**

Very bad


**275.** `23:54` **You**

I won’t be telling Jaimie
For
A good
Fucking
Long time


**276.** `23:54` **You**

2 years


**277.** `23:54` **You**

😝


**278.** `23:54` **Meredith Lamb (+14169386001)**

lol


**279.** `23:55` **Meredith Lamb (+14169386001)**

That’s so long


**280.** `23:55` **You**

Shit one
Sec


