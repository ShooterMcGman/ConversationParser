# Daily Conversation: 2025-06-22 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-22 |
| **Day** | Sunday |
| **Week** | 11 |
| **Messages** | 184 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-22T00:51 - 2025-06-22T21:40 |

## 📝 Daily Summary

This day contains **184 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:51` **Meredith Lamb (+14169386001)**

Talking to my mom\. I think she thinks we are “very compatible and communicate well together”
And I was like wtf?\!?\!


**002.** `00:51` **Meredith Lamb (+14169386001)**

My mom never says shit like that


**003.** `00:51` **Meredith Lamb (+14169386001)**

She’s 80


**004.** `00:53` **You**

Don’t look for reasons to doubt


**005.** `00:59` **You**

That seems good


**006.** `01:03` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Sun, 22 Jun 2025 01:03:17 \-0400
|
| Still talking to her but want to go to bed omg
|
| Version: 1
| Sent: Sun, 22 Jun 2025 01:03:09 \-0400
|
| Still talking to her but want to go to bed omf


**007.** `01:03` **You**

lol well I love you and this was a good day\.\. one I will Remeber for a while\.  Drink lots of water lol\.


**008.** `01:11` **Meredith Lamb (+14169386001)**

lol


**009.** `01:11` **Meredith Lamb (+14169386001)**

Water


**010.** `01:12` **Meredith Lamb (+14169386001)**

I just collapsed in my nephews bed


**011.** `01:12` **You**

ROFL


**012.** `01:12` **Meredith Lamb (+14169386001)**

It is sooo comfortable


**013.** `01:12` **You**

Yeah you will pass out momentarily


**014.** `01:12` **You**

Felt like you had fun tonight I hope


**015.** `01:12` **Meredith Lamb (+14169386001)**

lol


**016.** `01:13` **Meredith Lamb (+14169386001)**

My mom just went “Meredith \- do you want your water?”


**017.** `01:13` **You**

I enjoyed talking to your dad too\.


**018.** `01:13` **Meredith Lamb (+14169386001)**

lol


**019.** `01:13` **You**

Hehe


**020.** `01:14` **Meredith Lamb (+14169386001)**

>
It was good but honestly I was hoping for my mom to feel more awkward lol

*💬 Reply*

**021.** `01:14` **You**

Why


**022.** `01:14` **You**

I was glad it went well


**023.** `01:14` **You**

That was the point


**024.** `01:14` **Meredith Lamb (+14169386001)**

lol I dunno I like to see her in pain


**025.** `01:14` **You**

I like to be the boyfriend she likes


**026.** `01:14` **Meredith Lamb (+14169386001)**

Meh


**027.** `01:15` **You**

Matters to me even if not to you\.\. lol


**028.** `01:15` **Meredith Lamb (+14169386001)**

She is so critical of me I like to see her suffer a bit sometimes\. Lol


**029.** `01:16` **Meredith Lamb (+14169386001)**

It went a little TOO easy 🤪


**030.** `01:16` **You**

Reaction: 😂 from Meredith Lamb
Well next time I will try to be less something lol


**031.** `01:16` **Meredith Lamb (+14169386001)**

She said something about how she can tell you work out


**032.** `01:17` **Meredith Lamb (+14169386001)**

\(Mom = vain\)


**033.** `01:18` **You**

Whatever


**034.** `01:18` **You**

It’s like you wanted it to go bad LOL


**035.** `01:19` **Meredith Lamb (+14169386001)**

Nooooo


**036.** `01:19` **Meredith Lamb (+14169386001)**

lol


**037.** `01:22` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Before I pass out I will say, because I didn’t get a chance before you left, that you were amazing today and I had the best time even if only a few hours\.  It’s different because it just IS… you feel so home to me, so good to me, the feeling is like nothing I’ve ever experienced…\.
Dinner was fine 🙂


**038.** `01:23` **You**

lol dinner was fine


**039.** `01:24` **You**

Today was perfect for me\.\. I wanted it to be for you too\.\. you deserve it\.


**040.** `01:25` **Meredith Lamb (+14169386001)**

I mean I know my parents liked you a lot but not sure if it is bc they are in their 80/s\. Lol doesn’t matter\. My mom talked about all her “problems with andrew” lol and then I think I started yawning\. Heard it all before\. They very much liked you though so I feel good going to sleep\. :\)


**041.** `01:30` **You**

Kk go to sleep love you thanks for making me happy again\.


**042.** `01:32` **You**

>
>
>
You are home to me as well I have never been this open or comfortable with anyone in my life\.\. just being patient until this can become a more natural and regular thing

*💬 Reply*

**043.** `01:35` **You**

>
And btw everything about you is amazing to me\.\. we could have done nothing but lied there and talked and watched movies nd I would have been a happy and lucky man\.  Ok I am going to bed love you night❤️

*💬 Reply*

**044.** `09:18` **You**

Morning\.\. bet you are hungover lol\.\. ❤️\.  Hope you had a half decent sleep at least\.\. I really liked the dynamic between you and your parents, especially you and your dad\.\. he was really funny last night\.\. 😇\.\. soo many stories he could tell me rofl\.


**045.** `09:29` **You**

Reaction: 😂 from Meredith Lamb
And btw told you I was going to hug your mom\.\. 🙂


**046.** `09:46` **Meredith Lamb (+14169386001)**

>
lol yes so hungover but yeah slept well Jacob’s bed is the bomb\. :\)

*💬 Reply*

**047.** `09:47` **You**

ROFL glad
You slept well\.\.


**048.** `09:48` **Meredith Lamb (+14169386001)**

I need a tylonol tho and they are all the way upstairs so I’ve just been suffering to stay in bed\. Head ache


**049.** `09:49` **Meredith Lamb (+14169386001)**

lol


**050.** `09:49` **You**

Yeah that sucks\.\. hehe you need to get some food into you as well


**051.** `10:54` **You**

You know I have realized the more I am with you, the more time I spend with you, the more I think about you, the more I want to be with you\. 🙂\.  Thought I would share\.\. i continue to be surprised\.\. lol


**052.** `10:57` **You**

I am glad we are
Getting closer
To the end of this crappy process\.\.


**053.** `11:09` **Meredith Lamb (+14169386001)**

>
I know, I am the same which is why I think it is weird when you say I will get sick of you if we lived together

*💬 Reply*

**054.** `11:12` **You**

I dunno lol I never had a lot of self confidence heh probably chalk it up to that\.


**055.** `11:13` **You**

Plus we are from very different backgrounds\.\. I guess as long as I can keep up lol


**056.** `11:18` **You**

Ya know listening to the discussion too really made me appreciate all the more the time you have prioritized for me\.  With so much going on in your life that you have to keep track off\.\. honestly makes me appreciate it all the more\.\. I never realized\.


**057.** `11:19` **Meredith Lamb (+14169386001)**

>
Keep up with what?

*💬 Reply*

**058.** `11:23` **You**

Read below lol you lead an insanely busy life already full honestly and then some\.


**059.** `11:25` **Meredith Lamb (+14169386001)**

I mean it is all relative\. It doesn’t feel busy to me\. It is just life\. lol


**060.** `11:28` **You**

Reaction: ❤️ from Meredith Lamb
Anyhow it doesn’t matter it is what I want and I will figure out how to fit ☺️


**061.** `11:31` **Meredith Lamb (+14169386001)**

I’m still talking to my parents so that is why I’m not super chatty\.


**062.** `11:34` **You**

No no I am cooking and watching a show chat with your parents we can connect later ❤️❤️❤️❤️


**063.** `12:04` **You**

The other thing
I noticed and it was while you and your mother were discussing something else\.\. your dad and I were talking about Australia and the adventure\.\. again you have had them your parents have\.\. and my choices have led me to very few adventures, and I am only realizing now how much I missed lol\.\. it’s fine it isn’t affecting me like it did just making me think more about what I want next\.


**064.** `12:08` **You**

It was a really self reflective conversation\.\. for me\.\. learned a lot,  your mum is sweet btw very much like mine\.\. like in many ways scarily alike\.


**065.** `12:09` **You**

She used words like interesting, annoying etc\.\. liked that to\.


**066.** `12:09` **You**

>
Would have been interesting seeing them meet\.\. unstoppable force vs immovable object
lol

*💬 Reply*

**067.** `12:12` **Meredith Lamb (+14169386001)**

My parents have had many travel adventures\. They love to talk about them\. Travelling has always been their favourite thing\.


**068.** `12:28` **You**

I think I would have loved it too give the tight company


**069.** `12:28` **You**

Right


**070.** `12:32` **You**

>
I think I will enjoy hearing their stories\.

*💬 Reply*

**071.** `12:37` **Meredith Lamb (+14169386001)**

My mom really liked you but I think she feels bad for Jaimie and thinks that is going to be “an issue” for many years


**072.** `12:40` **You**

An issue how\.\. because of me\.\.?


**073.** `12:42` **You**

I mean because I feel a sense of obligation?


**074.** `12:42` **You**

That doesn’t change how I feel about you in the slightest bit what I want for our future\.


**075.** `12:43` **Meredith Lamb (+14169386001)**

I think just stress wise maybe\. She didn’t elaborate\.


**076.** `12:45` **You**

It will get easier as j settles in gets a job and resumes her life separately


**077.** `12:45` **You**

Gracie will be challenging


**078.** `12:47` **You**

I mean there are some awkward expectations\.\. both kids expect me there for Christmas for instance\.\. and while I want to be with them\.\. I am not going to be comfortable spending time with j going forward I think\.


**079.** `12:49` **Meredith Lamb (+14169386001)**

Yeah figuring out holidays is going to be interesting on our end also


**080.** `12:50` **You**

I am not worried\. Honestly I can figure out my side\.\. and I feel like there is between us we can figure us out\.\.


**081.** `12:51` **You**

The stuff between us not there\.\.


**082.** `12:52` **You**

While the not seeing you ache doesn’t change\.\. I am feeling much better in general\.  I hate leaving you every time even last night\.\. but I am not worrying as much about what comes next as much anymore\.


**083.** `12:52` **You**

It just feels like some things are kind of coming together in my head finally so it makes it easier\.


**084.** `12:53` **You**

Maybe I will tone back the intensity a bit though\.\. coming on pretty strong I think\.\. 🤔 lol


**085.** `12:54` **Meredith Lamb (+14169386001)**

Coming on to me pretty strong?


**086.** `12:55` **You**

Yeah I worry a little bit sometimes\.\.


**087.** `12:55` **You**

Not a lot


**088.** `12:55` **You**

Just a bit lol


**089.** `12:57` **Meredith Lamb (+14169386001)**

I do know what you mean about feeling better and things coming together in your head\. I have that same feeling\. Things don’t feel as complicated and overwhelming anymore\.


**090.** `12:58` **You**

No they don’t and I think we understand each other better as well\. Just have to be vigilant with the patience I am a little less than 4 weeks from a big change\.\. it will be sad but I will be able
To breathe too\.


**091.** `12:59` **You**

Anyhow go enjoy your parents\.\. going to eat and then get some work around house done\. ❤️


**092.** `13:02` **Meredith Lamb (+14169386001)**

>
Yes, this summer is going to be a little cray cray for sure\. But we will get through it ❤️

*💬 Reply*

**093.** `13:12` **You**

Yep 🥰


**094.** `13:44` **Meredith Lamb (+14169386001)**

FaceTimed with Mac


**095.** `13:44` **Meredith Lamb (+14169386001)**

She asked how it went with the intro lol


**096.** `13:44` **Meredith Lamb (+14169386001)**

She goes “was nan weird?”


**097.** `13:44` **You**

Hehe nice of her to ask


**098.** `13:44` **Meredith Lamb (+14169386001)**

Then she asked my mom if she was weird and my mom goes “oh I dunno probably” lol


**099.** `13:45` **Meredith Lamb (+14169386001)**

I said “she was not\!”


**100.** `13:45` **You**

Haha ur mom wasn’t


**101.** `13:45` **Meredith Lamb (+14169386001)**

lol


**102.** `13:45` **You**

The hug was funny as hell though


**103.** `13:45` **You**

She looked terrified\!


**104.** `13:45` **Meredith Lamb (+14169386001)**

I forgot to tell her that


**105.** `13:46` **You**

I was commited to making it happen one way or another


**106.** `13:46` **You**

I couldn’t say goodbye though not properly as yku hustled my ass out of there


**107.** `13:50` **Meredith Lamb (+14169386001)**

lol


**108.** `14:05` **You**

You probably need to get
On road soon\.\. so maybe chat
Later on tonight?  Or just
Drop me a note whenever will be around cleaning etc\. getting ready to be back at office\.\. need to change offices first thing tomorrow\.


**109.** `14:15` **Meredith Lamb (+14169386001)**

Just leaving to go get Maelle in Pickering\.


**110.** `14:16` **You**

Kk drive safe have a good day\.


**111.** `14:21` **Meredith Lamb (+14169386001)**

In my drunken and hung over state I forgot to thank you for meeting my parents even though you were very nervous\. I can tell they feel a lot better now about my whole situation so I think it was really valuable for them\. ❤️


**112.** `14:27` **You**

lol you don’t need to thank me


**113.** `14:29` **You**

Reaction: 😢 from Meredith Lamb
I enjoyed meeting them thoroughly\.
Made me miss my own parents a bit and sad that you wouldn’t get to meet them same way\.


**114.** `14:30` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I don’t like them worrying about me and I knew when they met you they would feel better\. I told my mom that she would understand when she met you\. Today I could clearly tell I was right\.


**115.** `14:31` **You**

I very much look forward
To spending more time with them\.\. and eventually rest of your family\.


**116.** `14:55` **Meredith Lamb (+14169386001)**

Rest of my family sucks lol


**117.** `14:55` **You**

No that’s not true… I am sure I will like them\.


**118.** `15:22` **You**

>
>
>
I wanted to say again appreciated what you said but I am a bit of bull in a china shop atm no flattery necessary, I am just trying to figure “this” all out again, and it feels like the first time all over\.  Btw the look of shock on my face yesterday was at how beautiful you were in that moment and how I felt like you are so absolutely out of my league lol… was like a reaction I couldn’t control\.\. I am sure it will happen again lol\.   Contrary
To what you might think this hasn’t been me in 25 years and I am not lying\.\. but I do want to know what makes you happy\.\. maybe we can talk about that on this trip coming up\.\.  maybe you could learn to appreciate some of my OCD qualities??  I forgot to mention this earlier meant to but just popped into my head right now\.

*💬 Reply*

**119.** `15:53` **Meredith Lamb (+14169386001)**

I do appreciate your OCD\. I have a little of it also \- my mom always loves to remind me\. 😜 please please please stop saying that I am out of your league\. It is so far from the truth… like completely\. I think we are perfectly matched and 100% playing in the same league\. Being with you makes me extremely happy so talking about what makes me happy when I’m already happy … lol ok 🙂


**120.** `15:53` **Meredith Lamb (+14169386001)**

And when you said yesterday…


**121.** `15:55` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
That if j knew what we were doing and she’d hate me lol Andrew would feel the same way\. We have never done that and it hasn’t ever been like that\. There is some extra with you and I\.


**122.** `15:56` **You**

We can still talk about it though\. ☺️ I


**123.** `16:01` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
Just got the little shadow and have to drive her home from beach


**124.** `16:34` **Meredith Lamb (+14169386001)**

Home and time to chill\!


**125.** `16:37` **You**

Nice


**126.** `16:38` **You**

Reaction: 🙂 from Meredith Lamb
Still cleaning\.\. talking to my Cousin\.


**127.** `16:54` **You**

what are you up to tonight\.\. watching tv??


**128.** `16:55` **Meredith Lamb (+14169386001)**

Not sure actually\. Just looking at stuff online now\. Might nap\. lol


**129.** `16:56` **You**

Nap lol\.\.


**130.** `16:56` **You**

I am just trying to get out of this conversation\.


**131.** `16:57` **You**

he never stops talking


**132.** `16:57` **Meredith Lamb (+14169386001)**

lol been there


**133.** `17:01` **You**

HOLY FUCK HE NEVER STOPS\!\!\!


**134.** `17:01` **You**

he just kinda drags on


**135.** `17:02` **You**

but I had to tell him because I told his dad and his brother


**136.** `17:02` **Meredith Lamb (+14169386001)**

Haha well you have time


**137.** `17:02` **You**

no I am going back to cleaning\.\. and trying on clothes


**138.** `17:02` **You**

I have a bunch of stuff I need to sort through\.\. stuff that didn't fit for quite some time\.\. or that i bought and then it never fit\.\. need to get organized som\.


**139.** `17:02` **You**

some\.


**140.** `17:03` **You**

then plan my workouts for the week because 4 am starts again tomorrow\.\. and I might run in tonight for a 30 min run sauna and shower\.


**141.** `17:04` **Meredith Lamb (+14169386001)**

Omg


**142.** `17:05` **Meredith Lamb (+14169386001)**

The thought of all that makes me tired lol


**143.** `17:07` **You**

Naw I am good will keep me busy


**144.** `18:25` **Meredith Lamb (+14169386001)**

Nap time done 🙂


**145.** `18:25` **Meredith Lamb (+14169386001)**

lol


**146.** `18:34` **You**

Tough life


**147.** `18:37` **Meredith Lamb (+14169386001)**

I’m still hungover lol


**148.** `18:37` **Meredith Lamb (+14169386001)**

So pathetic


**149.** `18:37` **You**

lol so sad


**150.** `18:37` **You**

Reaction: 😂 from Meredith Lamb
I mean it was a rough day yesterday and all


**151.** `18:38` **You**

I am a little tired and sore too\.\. but not hungover


**152.** `18:55` **Meredith Lamb (+14169386001)**

At shoppers for Mac\. She had her last exam tomorrow so trying to do what she wants\. :p


**153.** `18:56` **You**

lol heading to gym Gracie is driving me crazy so going to do a push set tonight and a pull set tomorrow morning…
Fml sometimes\.


**154.** `18:57` **You**

I feel like such a bad dad I cannot
Stand to deal with her anymore when she is so toxic\.


**155.** `19:16` **Meredith Lamb (+14169386001)**

That is so sucky\. Sorry


**156.** `19:17` **Meredith Lamb (+14169386001)**

I have to talk to Andrew about when we are scheduling our next mediation appt


**157.** `19:24` **You**

Kk good luck just walking into gym\.\. sorry you have to deal with that as well\.


**158.** `19:33` **Meredith Lamb (+14169386001)**

Actually wasn’t a big thing\. Think he’s tired from beach today so that’s good


**159.** `19:33` **You**

Good hope you got a date that works


**160.** `19:35` **Meredith Lamb (+14169386001)**

I have to email her to schedule\. Hoping for this week if we can


**161.** `19:35` **You**

Maybe get lucky


**162.** `21:06` **You**

Got asked if I was law enforcement tonight in sauna\. ROFL


**163.** `21:08` **Meredith Lamb (+14169386001)**

lol I get that actually


**164.** `21:09` **You**

I literally laughed out loud was funniest thing I ever heard


**165.** `21:09` **You**

Anyways was a first\.\.


**166.** `21:10` **Meredith Lamb (+14169386001)**

Are you still at the gym?


**167.** `21:11` **You**

Just going to get in car now


**168.** `21:13` **You**

What are you up to


**169.** `21:13` **Meredith Lamb (+14169386001)**

Tik tok lol


**170.** `21:14` **You**

Pahhh


**171.** `21:14` **You**

Meh


**172.** `21:19` **Meredith Lamb (+14169386001)**

I get caught up every now and again lol


**173.** `21:21` **You**

It’s like mind crack


**174.** `21:25` **Meredith Lamb (+14169386001)**

Maybe if you use it all the time\. I don’t\.


**175.** `21:25` **Meredith Lamb (+14169386001)**

It’s educational


**176.** `21:25` **Meredith Lamb (+14169386001)**

😇


**177.** `21:27` **You**

Mmmhmm ok\.\. well you do that I need to go iron clothes and get
My shit ready for tomorrow\.


**178.** `21:30` **Meredith Lamb (+14169386001)**

Yeah I’m going to bed soon\. Tired\.


**179.** `21:30` **Meredith Lamb (+14169386001)**

And our house is hot


**180.** `21:31` **Meredith Lamb (+14169386001)**

Gahhh


**181.** `21:31` **You**

Yeah no fun…


**182.** `21:32` **You**

We’ll have a good sleep\.\. I want to go to bed but I am sure I will have to deal with shit before I get there\.


**183.** `21:34` **Meredith Lamb (+14169386001)**

Hopefully you don’t\. xo I love you and have been missing you today


**184.** `21:40` **You**

Reaction: ❤️ from Meredith Lamb
Already fought with Gracie right after I unblocked her fml\.  So fucking stupid\.\. yeah been missing you today too\.\. like I said the more I am with you the more I want to be with you……\. Love you too have a good night\. Xoxo ❤️❤️❤️❤️❤️


