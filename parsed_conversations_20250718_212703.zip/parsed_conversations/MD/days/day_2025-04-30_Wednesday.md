# Daily Conversation: 2025-04-30 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-30 |
| **Day** | Wednesday |
| **Week** | 3 |
| **Messages** | 280 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-30T00:01 - 2025-04-30T23:47 |

## 📝 Daily Summary

This day contains **280 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:01` **You**

Well I am hoping I didn’t hear from you because you went to sleep early and got a good night sleep\.  Love you\. Xoxo


**002.** `02:58` **Meredith Lamb (+14169386001)**

Yes, sorry xoxoxo


**003.** `04:46` **You**

Kk


**004.** `09:03` **Meredith Lamb (+14169386001)**

Ugh busy talky morning\. Everything is “fine” tho\. My heart really hurts tho\.


**005.** `09:05` **You**

Yeah I tried to give you space,
Had a really bad night in my head but didn’t want to burden you\.  Figured you would reach out when you can\.


**006.** `09:07` **You**

And yeah I was in a lot of pain too\.


**007.** `13:03` **Meredith Lamb (+14169386001)**

Listen, Andrew worked from home today so he can take Mac to orthodontist so I had to be careful\. But I love you and am not changing my mind so chill those thoughts…\. Unnecessary stress\. ❤️❤️


**008.** `13:05` **You**

I am trying and I love you too\. But this is not what I expected it is all new and I don’t know how to adjust,  but I am trying\.  And there is no alternative anyways, so I just need to figure it out\. ❤️❤️


**009.** `13:07` **You**

It’s like I have all of……\. “This” that I want to share with you and I cannot and I have no other outlet\.  If you were on your own it would be different\.\. so maybe when that happens I won’t be as kind of messed up or broken as I am now\.\.


**010.** `13:08` **You**

Anyhow again feel like a fool\.\. not sure what else to do


**011.** `13:08` **Meredith Lamb (+14169386001)**

You are hardly messed up… you are navigating an immense amount of conflict and other “stuff” all at once\.


**012.** `13:12` **Meredith Lamb (+14169386001)**

Check out this listing
https://realtor\.ca/real\-estate/27885098/5\-crestview\-road\-toronto\-lawrence\-park\-south\-lawrence\-park\-south?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**013.** `13:12` **Meredith Lamb (+14169386001)**

I’m frustrated\. I want to rent that place but can’t inquire until we get our financials organized\.


**014.** `13:13` **You**

It’s a very nice place, real fireplaces I bet was a draw 2 of them


**015.** `13:14` **You**

Who is I\. Charge of securing a mediator since that is your next step


**016.** `13:15` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**017.** `13:16` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**018.** `13:16` **Meredith Lamb (+14169386001)**

Literally for those texts when we were talking


**019.** `13:17` **Meredith Lamb (+14169386001)**

Life is exhausting right now\. I hope you ranked me LAST\. I can’t keep up\.


**020.** `13:17` **Meredith Lamb (+14169386001)**

Also planning 3 birthdays, Maelle, my moms 80th and Mac’s 16


**021.** `13:17` **Meredith Lamb (+14169386001)**

Lord ……\.


**022.** `13:18` **You**

See I mean I wish I had your problem because it would keep my mind occupied


**023.** `13:19` **You**

You are always ranked at the top mer\.\. even if I was busy\.


**024.** `13:19` **You**

My situation is different though


**025.** `13:20` **Meredith Lamb (+14169386001)**

Yours involves more conflict and trauma for sure


**026.** `13:20` **Meredith Lamb (+14169386001)**

It’s heavier maybe


**027.** `13:24` **You**

But nothing to focus on to keep my mind off of what I cannot have or feel I could lose if I make a mistake or don’t go fast enough or something beyond my control happens on your side\.  I know you said not to worry, and I appreciate it, but as I have said I have never had something work out like this\.  Well nothing like this has happened\.\. it’s like hoping for a happily ever after but always getting screwed\. Not your fault or your problem I just have to figure out a way to get some kind of mental control over my emotions\.


**028.** `13:26` **Meredith Lamb (+14169386001)**

Maybe don’t go cold turkey off your anxiety meds\. :p


**029.** `13:26` **Meredith Lamb (+14169386001)**

No but for real…


**030.** `13:28` **Meredith Lamb (+14169386001)**

If your brain needs reassurance I can give that to you anytime\. It will not bother me \(unless you ask multiple times a day\)\. I don’t struggle with needing reassurance so much and more so with feeling stuck and like that will last too long\. I get in my head about that\. This current state dragging on and on and on…\.\.


**031.** `13:30` **You**

Doctor confirmed there was nothing left I\. My system so no anxiety from that\. I won’t ask for reassurance\.  I will just try to take it on faith\.   It I cannot help the scenarios that play out\.\. I will just have to suffer through those\.


**032.** `13:31` **Meredith Lamb (+14169386001)**

I can guarantee you that your scenarios \(without having any details of them\) are likely all very ridiculous for one reason or another…


**033.** `13:33` **You**

Maybe\. I don’t know\.  Anyhow it’s fine I have to get ready for a long haul, no choice in the matter\.  So I either figure it out or well I need to figure it out\.


**034.** `13:34` **Meredith Lamb (+14169386001)**

Maybe? Come on… after this past weekend you truly think one of those made up scenarios plays out for real?


**035.** `13:37` **You**

You don’t understand\.  I cannot read certain things in people\.  For someone that can read almost anything, genuine happiness satisfaction anything like that I cannot read\.\. I just hope for it\.  And then my head suggests I am mistaken etc etc enter scenarios as a result\.  It is the most illogical part
Of me\.\. but I have never had self confidence in this area because I have been burned so many times in the past and none of them held a candle to how I feel about you so a bit more worried than usual\.


**036.** `14:14` **You**

It sounds so childish\.\. and again weak\.\. not how I saw myself\.  But I guess in certain situations this is me unfortunately\.


**037.** `14:16` **Meredith Lamb (+14169386001)**

You have been burned because you haven’t met the right person\. Like so many of us other people\. You are not unlike the rest of us\. You just think you are\. :\)


**038.** `14:17` **You**

Reaction: 🙂 from Meredith Lamb
You are so much more wise than me\.\. maybe I will get that too when I hit 47\.


**039.** `14:18` **You**

But it is more than what you are saying my issues are internal\.\. so I will have to reconcile or rationalize them somehow\.  While your logic is solid it still doesn’t change how I feel\.


**040.** `14:19` **Meredith Lamb (+14169386001)**

You know when I wrote the LSAT I scored highest on logic\.


**041.** `14:19` **Meredith Lamb (+14169386001)**

lol


**042.** `14:19` **You**

Someone used to being in control, being able to read situation and people\.  To put them into something where the opposite is true they cannot read anything and feel slightly helpless and out of control would be an apt comparison \.


**043.** `14:20` **You**

When I wrote gmat I scored in the 99th % on writing, comprehension and articulation


**044.** `14:20` **Meredith Lamb (+14169386001)**

I don’t think our situation is that hard to read\.


**045.** `14:21` **You**

It is you that are hard to read but it will come in time I think\.


**046.** `14:21` **Meredith Lamb (+14169386001)**

>
Not shocking\.

*💬 Reply*

**047.** `14:21` **You**

I mean logic is my go to\.  Which is why I am so fucked right now


**048.** `14:21` **You**

lol


**049.** `14:22` **Meredith Lamb (+14169386001)**

>
If I was easy to read you’d be bored with me anyway

*💬 Reply*

**050.** `14:23` **You**

Reached a point where I cannot articulate further\.


**051.** `14:23` **You**

Suffice to say you wouldn’t bore me ever


**052.** `14:33` **Meredith Lamb (+14169386001)**

I’m watching a holocaust documentary right now… I could bore you easily


**053.** `14:33` **Meredith Lamb (+14169386001)**

lol


**054.** `14:34` **Meredith Lamb (+14169386001)**

Sigh Andrew doesn’t want to do mediation


**055.** `14:34` **Meredith Lamb (+14169386001)**

He thinks it will drag on too long


**056.** `14:35` **You**

I think you just take it a lawyer to get some advice if it is close take it\.


**057.** `14:40` **Meredith Lamb (+14169386001)**

He seems very worried about the financial disclosure aspect which is concerning me 🚩🚩🚩🚩🚩


**058.** `14:40` **You**

I am not sure what the concerns there are\.\. has he not paid his taxes? lol


**059.** `14:41` **Meredith Lamb (+14169386001)**

Maybe he has more pension or rrsps that he is not disclosing to me\. No idea


**060.** `14:43` **You**

Checking something


**061.** `14:44` **Meredith Lamb (+14169386001)**

He’s like “if we don’t go do that we can just go now” and I’m all “hardly because you haven’t allowed me to tell the kids\!”


**062.** `14:45` **Meredith Lamb (+14169386001)**

Like as if I can just move out next week\. They need a bit of time to process\.


**063.** `14:45` **Meredith Lamb (+14169386001)**

So frustrating


**064.** `15:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**065.** `15:59` **Meredith Lamb (+14169386001)**

I might be having a drink tonight\. Lol


**066.** `15:59` **Meredith Lamb (+14169386001)**

I hate being accused of taking advantage of anyone\.


**067.** `15:59` **Meredith Lamb (+14169386001)**

I get it constantly


**068.** `15:59` **Meredith Lamb (+14169386001)**

So annoying


**069.** `15:59` **You**

Does he understand that the house rennovations is not an expense


**070.** `15:59` **You**

It is an ivestment


**071.** `15:59` **You**

Rrsp is an asset


**072.** `16:00` **You**

He is transferring value from one asset to another


**073.** `16:00` **You**

And that is his choice


**074.** `16:00` **Meredith Lamb (+14169386001)**

Yes but he think I’m an idiot


**075.** `16:00` **You**

Hmm


**076.** `16:01` **You**

Again that is his choice in that last paragraph


**077.** `16:01` **You**

Your choice is to not sacrifice your own independent ability to live comfortably where the girls currently go to school


**078.** `16:01` **You**

For the sake of his dream


**079.** `16:02` **You**

If he sold the cottage or properly bought you out then he could provide you that he doesn’t want to\.


**080.** `16:02` **You**

Again the only thing that is different here is the value of assets\.\.


**081.** `16:02` **You**

And equalization


**082.** `16:03` **You**

In common law you don’t have as many rights Ther


**083.** `16:03` **You**

But he is low balling you on spousal


**084.** `16:03` **You**

So that is all he has to play with


**085.** `16:03` **Meredith Lamb (+14169386001)**

Yeah he uses the kids to excuse his selfishness sometimes\.


**086.** `16:03` **You**

Yeah I can read that lol


**087.** `16:03` **Meredith Lamb (+14169386001)**

Then blames me for


**088.** `16:03` **Meredith Lamb (+14169386001)**

Everything is always my fault


**089.** `16:03` **You**

I mean at the end of the day this was his decision


**090.** `16:04` **You**

He decided to send the text


**091.** `16:04` **You**

To blow up the trust


**092.** `16:04` **You**

And the relationship


**093.** `16:04` **You**

Period full stop


**094.** `16:04` **You**

And there is no justification ever for it’s


**095.** `16:05` **You**

Again I think going back to my example you got well over a million in a lumps in that considered everything I a very reasonable fashion


**096.** `16:05` **You**

If you have what I provided to a lawyer they could tell you more


**097.** `16:06` **Meredith Lamb (+14169386001)**

If I didn’t have kids I would address this differently but trying to think of them also so I get conflicted\.


**098.** `16:06` **You**

You are thinking of them


**099.** `16:06` **You**

How will it work with you struggling but hey the kids have a cottage and a house all that belong to him


**100.** `16:06` **You**

That is not in their best interests


**101.** `16:30` **You**

Alright I am heading home, hoping we can chat a bit later\.\. always helps me end my day on a high note\. Honestly the thing I look forward to most every day\.


**102.** `17:19` **Meredith Lamb (+14169386001)**

He fucking cried on me this afternoon\. Sooo annoyed


**103.** `17:24` **You**

Probably because I cried on you too


**104.** `17:25` **You**

What was it now cottage or reverse course


**105.** `17:29` **Meredith Lamb (+14169386001)**

Just telling the kids… and he hates all of this


**106.** `17:29` **Meredith Lamb (+14169386001)**

I said not to cry when we tell the kids


**107.** `17:29` **Meredith Lamb (+14169386001)**

He said he will


**108.** `17:29` **Meredith Lamb (+14169386001)**

Ughhhhhhhhhhh


**109.** `17:30` **You**

Eesh


**110.** `17:30` **You**

I get feeling sad


**111.** `17:31` **You**

But not crying over that


**112.** `17:31` **Meredith Lamb (+14169386001)**

I find it manipulative\. But that might be the Dexter in me talking


**113.** `17:31` **Meredith Lamb (+14169386001)**

:p


**114.** `17:31` **You**

I literally just thought that


**115.** `17:31` **You**

I swear


**116.** `17:32` **You**

Apparently I have a little dexter in my brain too\.


**117.** `17:32` **You**

Like look kids I care more


**118.** `17:32` **You**

Was that what you were thinking


**119.** `17:32` **Meredith Lamb (+14169386001)**

Exactly


**120.** `17:32` **You**

Rofl


**121.** `17:33` **You**

I mean I cannot see what it would accomplish otherwise\.


**122.** `17:34` **Meredith Lamb (+14169386001)**

Sigh


**123.** `17:35` **You**

Sry I cannot help with that\.   Doing it next week I assume should give him time to prepare


**124.** `17:37` **Meredith Lamb (+14169386001)**

In the next breath he was being an asshole\. Hilarious


**125.** `17:39` **You**

Honestly I don’t understand where he feels he has the right?


**126.** `17:48` **Meredith Lamb (+14169386001)**

Oh he is pissed I got the dog walker to come today $$


**127.** `17:48` **Meredith Lamb (+14169386001)**

🙄


**128.** `17:49` **Meredith Lamb (+14169386001)**

So then he acts assholish


**129.** `17:51` **You**

Oh ffs


**130.** `17:52` **You**

The drama of it all


**131.** `17:53` **Meredith Lamb (+14169386001)**

Life is hard


**132.** `17:54` **You**

I mean I think it is hard filled with really shitty problems\.\. dog walkers for people that make 500 gs or whatever shouldn’t rank in the top 1000


**133.** `17:54` **Meredith Lamb (+14169386001)**

Well especially when I’m the one that walks the dogs lol


**134.** `17:55` **You**

Well I guess yeah that should make it your prerogative


**135.** `17:55` **You**

More important things to sort out for sure


**136.** `21:25` **You**

Hope your night better than mi e


**137.** `21:25` **Meredith Lamb (+14169386001)**

Talking to my bro :\)


**138.** `21:26` **You**

Another fight with j and Gracie no further now I think they want to stay in the house a year and anyways it is all messed up I am going to have to drag this through to completion\. On my own\.


**139.** `21:28` **Meredith Lamb (+14169386001)**

Omg whip lash


**140.** `21:28` **Meredith Lamb (+14169386001)**

Wait were j and Gracie ganging up


**141.** `21:36` **You**

Yeah a bit and I was being mean in response which I shouldn’t have


**142.** `21:38` **You**

I apologized again I just want out I do t care what I give up or who lives where I will do whatever at this point\.


**143.** `21:39` **Meredith Lamb (+14169386001)**

I’m at that point too


**144.** `21:42` **Meredith Lamb (+14169386001)**

I kind of want to see you being mean


**145.** `21:42` **Meredith Lamb (+14169386001)**

Is that bad


**146.** `21:46` **You**

No you don’t mer


**147.** `21:46` **Meredith Lamb (+14169386001)**

I dooooooo


**148.** `21:46` **Meredith Lamb (+14169386001)**

Is it worse than damir mad


**149.** `21:46` **Meredith Lamb (+14169386001)**

lol


**150.** `21:46` **You**

Mer it is an awful version of myself and yes it is worse than damir


**151.** `21:46` **You**

It gets there i should say


**152.** `21:46` **You**

Reaction: 😢 from Meredith Lamb
Over a long time of being constantly abused and berated


**153.** `21:47` **You**

I think everyone ahead a
Limit I just reached mine in this family


**154.** `21:47` **You**

And now when you get mad you just go all the way to the angry place


**155.** `21:47` **You**

Why wait a sec


**156.** `21:47` **You**

Don’t tell me you liked the damir conversation


**157.** `21:47` **Meredith Lamb (+14169386001)**

No


**158.** `21:47` **Meredith Lamb (+14169386001)**

Painful


**159.** `21:47` **You**

Ok


**160.** `21:47` **You**

Was checking


**161.** `21:47` **You**

lol


**162.** `21:47` **You**

Was like why do you want to see me mad


**163.** `21:48` **Meredith Lamb (+14169386001)**

I dunno\. I want to see all sides of u I guess


**164.** `21:48` **You**

Well you saw some anger today it exists


**165.** `21:48` **You**

More frustration
Though


**166.** `21:49` **You**

It yeah I am not a wimpy ball of emotions all the time lol there are other dynamics


**167.** `21:49` **Meredith Lamb (+14169386001)**

Thank god


**168.** `21:49` **Meredith Lamb (+14169386001)**

lol


**169.** `21:51` **You**

Ouch


**170.** `21:51` **You**

You know the big ball of emotions is the one that does all the romantic stuff too\.


**171.** `21:51` **Meredith Lamb (+14169386001)**

True true


**172.** `21:51` **Meredith Lamb (+14169386001)**

Touché


**173.** `21:52` **Meredith Lamb (+14169386001)**

I’m okay with that … I guess\.


**174.** `21:53` **You**

lol well I hope so because you are the reason the emotional ball even exists right now\.


**175.** `21:53` **You**

That is a compliment in case you are unsure


**176.** `21:53` **Meredith Lamb (+14169386001)**

Are you sure?


**177.** `21:54` **Meredith Lamb (+14169386001)**

I feel like if you are emotional you are emotional


**178.** `21:55` **You**

I feel like I was in a cozey loner ice prison and then we
Smashed into each other


**179.** `21:58` **Meredith Lamb (+14169386001)**

Ice prison …\. Wow\. …\. Quite a vision


**180.** `21:58` **You**

I was safe and secure\.


**181.** `21:59` **You**

Btw\. No fam at gym


**182.** `21:59` **You**

But I saw Sharon last night


**183.** `21:59` **Meredith Lamb (+14169386001)**

>
??

*💬 Reply*

**184.** `21:59` **You**

She was running on a treadmill across from me and she kept smiling at me was a bit awkward


**185.** `21:59` **Meredith Lamb (+14169386001)**

Omg


**186.** `21:59` **You**

😛


**187.** `21:59` **You**

True story\. Mishaps


**188.** `21:59` **Meredith Lamb (+14169386001)**

Making me angry


**189.** `22:00` **You**

That was muahaha


**190.** `22:00` **You**

Not mishaps


**191.** `22:00` **You**

lol


**192.** `22:00` **You**

Whatever I am yours what are angry about


**193.** `22:00` **You**

We established that


**194.** `22:00` **You**

A few times


**195.** `22:00` **Meredith Lamb (+14169386001)**

Uh huh


**196.** `22:01` **You**

Ok come on now\.\. you know I am messing with you\.\. not about the me being yours part


**197.** `22:02` **You**

🙁 ok no more joking……


**198.** `22:02` **Meredith Lamb (+14169386001)**

Yah maybe stop


**199.** `22:02` **Meredith Lamb (+14169386001)**

lol


**200.** `22:03` **You**

Ok just learning some boundaries is all\.


**201.** `22:05` **You**

Don’t be mad at me pls… wasn’t my intent was just playing around\.


**202.** `22:05` **You**

No more jokes\.


**203.** `22:06` **You**

Sigh


**204.** `22:07` **Meredith Lamb (+14169386001)**

So I got you something small


**205.** `22:07` **Meredith Lamb (+14169386001)**

I’m going to leave it on your chair tomorrow


**206.** `22:07` **You**

Why you didn’t need to do that\.


**207.** `22:08` **Meredith Lamb (+14169386001)**

Very small


**208.** `22:08` **You**

Is it a note that indicates when and where we can find a few minutes together for a hug because I would take that\.


**209.** `22:09` **You**

Like a park\!\!


**210.** `22:09` **You**

lol


**211.** `22:09` **Meredith Lamb (+14169386001)**

Um, no sorry :\(


**212.** `22:10` **You**

Ah well unfortunate… well I might be there before you\.\. so we’ll see


**213.** `22:10` **Meredith Lamb (+14169386001)**

Yah right


**214.** `22:10` **You**

I was in there around 7:39’today


**215.** `22:10` **You**

7:30


**216.** `22:10` **Meredith Lamb (+14169386001)**

Why?\!


**217.** `22:10` **You**

Because I couldn’t sleep I couldn’t get out of my head and I could t stay home


**218.** `22:10` **Meredith Lamb (+14169386001)**

Ok well if you are in earlier I will just give it to you :\)


**219.** `22:10` **You**

So I went in


**220.** `22:10` **Meredith Lamb (+14169386001)**

It is very small


**221.** `22:11` **Meredith Lamb (+14169386001)**

>
Out of your head about us or your family?

*💬 Reply*

**222.** `22:11` **You**

Us this morning


**223.** `22:12` **You**

I thought I mentioned that earlier


**224.** `22:12` **You**

Not rehashing


**225.** `22:12` **Meredith Lamb (+14169386001)**

Yah just wasn’t sure if fam played a role\.


**226.** `22:14` **You**

Reaction: ❤️ from Meredith Lamb
Nope I mean k have two major concerns and I feel like I have little control over both\.  So it varies\.\. but you are usually my happy place
Except when my brain wants to have a go at me\.\. like i said won’t always be like that\.


**227.** `22:14` **You**

Like you said I think the whole thing is just a bit overwhelming so it makes
Everything a bit more intense


**228.** `22:15` **You**

For
Me
That is\.  You are a vault


**229.** `22:18` **Meredith Lamb (+14169386001)**

I’m a vault?


**230.** `22:18` **You**

Like super controlled


**231.** `22:18` **You**

Way better than me\.\.


**232.** `22:19` **You**

But that being said


**233.** `22:19` **You**

I am not suggesting it doesn’t affect you either


**234.** `22:19` **You**

Maybe I just feel like shit because I look more needy


**235.** `22:19` **You**

lol


**236.** `22:19` **Meredith Lamb (+14169386001)**

I kind of like your intensity


**237.** `22:19` **You**

And I am not used to that


**238.** `22:19` **Meredith Lamb (+14169386001)**

Are you needy?


**239.** `22:19` **You**

I dunno I think you like certain kinds of intensify


**240.** `22:20` **You**

I worry I might seem that way


**241.** `22:20` **Meredith Lamb (+14169386001)**

Would your family describe you that way?


**242.** `22:20` **You**

Absolutely not


**243.** `22:20` **You**

But again that is defined a lot by the situation


**244.** `22:20` **You**

Jaimie would never but I never opened to Jaimie like this


**245.** `22:20` **You**

And she want the right fit


**246.** `22:20` **You**

For me to want to tegardless


**247.** `22:20` **You**

Wasn’t


**248.** `22:22` **You**

I mean as I said to j tonight I don’t like the person I have become I this situation this isn’t who i really am or am supposed to be\.


**249.** `22:23` **Meredith Lamb (+14169386001)**

>
Why???

*💬 Reply*

**250.** `22:23` **You**

She wasn’t you\.  I mean the answer sounds like it sounds but it is the only answer I have\.


**251.** `22:23` **Meredith Lamb (+14169386001)**

>
I agree\.

*💬 Reply*

**252.** `22:29` **Meredith Lamb (+14169386001)**

“The answer sounds like it sounds but it is the only answer I have\.” ???


**253.** `22:29` **You**

It sounds like a line or something cheesy


**254.** `22:30` **You**

Reaction: ❤️ from Meredith Lamb
But based on the way I feel and that I haven’t felt like this before you\.\. the the answer to your question is she wasn’t you


**255.** `22:30` **You**

See logic and emotion\.\.


**256.** `22:30` **You**

lol


**257.** `22:31` **You**

I could have thrown an ergo in there if that works better


**258.** `22:32` **You**

I think it goes to when something clicks and fits together right we are who we are meant to be\.


**259.** `22:32` **You**

I don’t think we can be that with anyone


**260.** `22:32` **You**

Granted I wouldn’t have said that before now but I have had to reassess


**261.** `22:35` **Meredith Lamb (+14169386001)**

You wouldn’t have said before?


**262.** `22:35` **You**

No I didn’t believe


**263.** `22:36` **You**

I had no previous basis\.\. so it didn’t seem to exist


**264.** `22:36` **You**

I knew though that what I felt for Jaimie wasn’t being in love though\. Not that I knew what that really felt like just not that loving someone and being I love aren’t same thing


**265.** `22:37` **You**

I just didn’t realize how different it was


**266.** `22:37` **You**

Hmm can I ask a question now you mentioned you were going to have some wine tonight\.


**267.** `22:37` **You**

Did you partake?


**268.** `22:38` **You**

Cause you are doing the open ended question thing again\.


**269.** `22:39` **You**

lol


**270.** `22:39` **You**

Do you want to FaceTime me and tell me\.\.


**271.** `22:40` **Meredith Lamb (+14169386001)**

One sec


**272.** `22:44` **You**

Kk


**273.** `22:56` **You**

lol and she went to sleep ROFL


**274.** `23:07` **You**

Kk hun wel it is 10
After and I have to have my shower and shave before this place closes
Down tried to wait sorry\.  I will ping you when I get to car but if you aren’t asleep now I am sure you will be by then\.


**275.** `23:16` **Meredith Lamb (+14169386001)**

I am not asleep\. Talking finances :p


**276.** `23:34` **You**

Oh I thought the one sec meant call me in a sec my mistake lol\.


**277.** `23:34` **You**

Getting dressed and heading to car but you probably still occupied\.


**278.** `23:42` **You**

Omw home if we don’t chat have a good night\.


**279.** `23:43` **Meredith Lamb (+14169386001)**

Just in an argument :p


**280.** `23:47` **You**

Ah well then kick him in the teeth mer\.


