# Daily Conversation: 2025-07-17 (Thursday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-07-17 |
| **Day** | Thursday |
| **Week** | 14 |
| **Messages** | 1123 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-07-17T04:12 - 2025-07-17T23:59 |

## 📝 Daily Summary

This day contains **1123 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:12` **You**

Edited: 3 versions
| Version: 3
| Sent: Thu, 17 Jul 2025 04:34:05 \-0400
|
| Morning\.\. xo hope you got some sleep and feel better\.  We don’t have to do park if you have things or need more sleep\.  I suspect you and Andrew will be at it again this morning or were up late last night dunno\.  Anyhow don’t feel obligated\.  I am heading out soon\.
|
| Version: 2
| Sent: Thu, 17 Jul 2025 04:12:54 \-0400
|
| Morning\.\. how you got some sleep and feel better\.  We don’t have to do park if you have things\.\. I suspect you and Andrew will be at it again this morning or were up late last night dunno\.  Anyhow don’t feel obligated\.  I am heading out soon\.
|
| Version: 1
| Sent: Thu, 17 Jul 2025 04:12:36 \-0400
|
| Morning\.\. how you got some sleep and feel better\.  We don’t have to do park if you have things\.\. I suspect you and Andrew will be at it again this morning or we’re up late last night dunno\.  Anyhow don’t feel obligated\.  I am heading out soon\.


**002.** `06:07` **You**

Finished my workout going to go sauna shower shave soon\.\. think i am just going to go to park early for a walk\.\. hope you are ok\.


**003.** `06:10` **You**

Reaction: 😮 from Meredith Lamb
For when you wake up\.

*📎 1 attachment(s)*

**004.** `06:14` **Meredith Lamb (+14169386001)**

You are making me guilty for not working out now\. Lol


**005.** `06:15` **You**

Reaction: 😡 from Meredith Lamb
I can delete and stop sharing ☺️


**006.** `06:15` **Meredith Lamb (+14169386001)**

>
Jim recommended a doc last night so I watched that\. Then took melatonin so I could sleep bc I was still anxious\.

*💬 Reply*

**007.** `06:16` **Meredith Lamb (+14169386001)**

Didn’t go to bed until 12\.30


**008.** `06:16` **You**

Not surprised


**009.** `06:16` **You**

You don’t have to come this morning like I said\.\. I figured something like that would happen


**010.** `06:16` **Meredith Lamb (+14169386001)**

I talked to Andrew this morning and I think we are better\.


**011.** `06:16` **Meredith Lamb (+14169386001)**

On a couple things


**012.** `06:17` **You**

How was he functioning you said he gets home at 3 am


**013.** `06:17` **Meredith Lamb (+14169386001)**

Just making coffee and going to watch a bit of cnn and then get ready and go\. This house has no a/c


**014.** `06:18` **Meredith Lamb (+14169386001)**

Can’t work out in this until I move


**015.** `06:18` **You**

You just heading in to office early?


**016.** `06:18` **You**

>
Yeah I get it

*💬 Reply*

**017.** `06:19` **You**

Whatever you decide up to you I am going to sauna for 10 mins then shower then leave for park\.\. probably be there around 730\-745\.\.


**018.** `06:29` **Meredith Lamb (+14169386001)**

k, sorry another little “discussion”


**019.** `06:29` **Meredith Lamb (+14169386001)**

I will meet you there


**020.** `06:30` **Meredith Lamb (+14169386001)**

And update you on my timing in a bit but I need out of this house


**021.** `06:30` **Meredith Lamb (+14169386001)**

So hot 29c


**022.** `06:30` **Meredith Lamb (+14169386001)**

Inside


**023.** `06:54` **Meredith Lamb (+14169386001)**

https://www\.instagram\.com/reel/DLk64ZzJ5sx/?igsh=MXc5ejIzejl6OWxyYw==


**024.** `06:54` **You**

Ok\.


**025.** `07:05` **You**

On road now


**026.** `07:14` **Meredith Lamb (+14169386001)**

I’m moving and kind of slow motion so I just got out of the shower\. I probably won’t get out of here until 730\.


**027.** `07:22` **Meredith Lamb (+14169386001)**

So I forgot my fidget ring that I wear everyday at the cottage on my bedside table and it’s driving the crap out of me everyday\. Is that not crazy? That’s my state right now\.


**028.** `07:25` **You**

I do t think that’s crazy


**029.** `07:30` **You**

Ok time to fucking breathe for a bit\.


**030.** `07:31` **Meredith Lamb (+14169386001)**

I’m just leaving


**031.** `07:31` **You**

Yep


**032.** `10:44` **You**

Hope your doc review is going well if you still aren’t talking to Jim\.


**033.** `11:12` **Meredith Lamb (+14169386001)**

Haven’t reviewed it at all yet\!


**034.** `11:12` **Meredith Lamb (+14169386001)**

I told Jim about telling Andrew lol


**035.** `11:12` **Meredith Lamb (+14169386001)**

He said I’m bat shit crazy


**036.** `11:12` **Meredith Lamb (+14169386001)**

LOL


**037.** `11:12` **You**

Probably blames me


**038.** `11:13` **Meredith Lamb (+14169386001)**

No I told him you were just as surprised


**039.** `11:14` **You**

Still my fault I am sure\. Lol we know who he thinks has caused all the problems here


**040.** `11:14` **Meredith Lamb (+14169386001)**

I think he’s over that for some reason


**041.** `11:14` **Meredith Lamb (+14169386001)**

Not sure why


**042.** `11:14` **You**

Kk


**043.** `11:15` **Meredith Lamb (+14169386001)**

Maybe he realizes that I’m a little crazy now


**044.** `11:15` **Meredith Lamb (+14169386001)**

Maybe he thought I wasn’t before


**045.** `11:15` **Meredith Lamb (+14169386001)**

lol


**046.** `11:15` **You**

Oh yeah you didn’t get to tell him last week so you are offloading a lot


**047.** `11:15` **You**

You never even caught up on his and my convo


**048.** `11:15` **Meredith Lamb (+14169386001)**

He didn’t mention it\!


**049.** `11:16` **You**

Ah well maybe he won’t


**050.** `11:16` **Meredith Lamb (+14169386001)**

Don’t think so


**051.** `11:16` **You**

Too bad you will never know what he thinks now


**052.** `11:17` **Meredith Lamb (+14169386001)**

I mean I know he thinks I’m too impulsive


**053.** `11:17` **Meredith Lamb (+14169386001)**

lol


**054.** `11:17` **You**

In certain situations


**055.** `11:17` **Meredith Lamb (+14169386001)**

He’s not wrong


**056.** `11:17` **You**

You are not most of the time with us


**057.** `11:21` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 12:38:08 \-0400
|
| When you said “I don’t feel like I fit in anywhere” it has been sitting with me…\.
|
| Version: 1
| Sent: Thu, 17 Jul 2025 11:21:17 \-0400
|
| When you said “I don’t feel like I fit in anywhere” it had been sitting with me…\.


**058.** `11:21` **Meredith Lamb (+14169386001)**

I didn’t like it


**059.** `11:25` **You**

I don’t I sit at home by myself with people around me that really don’t like me, I have no friends, no outlet, no life\.  I have you mostly virtually, doesn’t change anything about the way i feel about you or us or the desire to integrate\.  But I just don’t feel I fit\.\. or will anytime soon\. Maybe that changes with time but that is how I see right now and the foreseeable future\.  Yeah I want to wake up with you every day and do normal boring things with you and the kids\.\. but I know that’s impossible now and so far away it isn’t worth thinking about\.  I am sorry if you don’t like it\.\. I tried to kiss you in a way to tell you it doesn’t matter, that I still love you more than anything and always will\.


**060.** `11:26` **You**

I am sorry for how I feel for being impatient for asking for more than you can give\.\. fatal flaw\.


**061.** `11:33` **Meredith Lamb (+14169386001)**

I just fully believe that you fit in my life right now and in the future\. It may not be perfect but you fit perfectly so to hear you feel like you don’t is…\. Ugh\.


**062.** `11:35` **Meredith Lamb (+14169386001)**

Like I desperately want to be with you as much as you do with me, I love you equally, I think we both feel safe and home with each other\. I think the fit is perfect\. It may be ideal logistically but you definitely fit with me\.


**063.** `11:36` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 11:36:13 \-0400
|
| Responding in a sec
|
| Version: 1
| Sent: Thu, 17 Jul 2025 11:36:07 \-0400
|
| Responding in a sex


**064.** `11:47` **Meredith Lamb (+14169386001)**

This is never ending\. My brain is going to literally explode

*📎 1 attachment(s)*

**065.** `12:04` **You**

Especially when he is pushing for all the sports\. You have to give your time your gas food overnight costs\.\. etc it isn’t cheap


**066.** `12:04` **You**

>
I am not questioning this I think you know this or at least I hope you do\.

*💬 Reply*

**067.** `12:12` **Meredith Lamb (+14169386001)**

I do but I question the fitting in part\.


**068.** `12:16` **You**

With everything that is going on\.\. trying to steal moments, I don’t know what you meant yesterday about unorthodox solutions, not knowing if I am going to see or spend time with you for weeks\.\. that isn’t fitting that is struggling\.  I wasn’t saying I won’t fit ever\.\.


**069.** `12:16` **You**

I am sorry you don’t like how I characterized it maybe I should have said it differently


**070.** `12:21` **You**

It isn’t about us it’s about our situation my concern with how long it will persist\.\. that’s all it is a concern and how it affects how I feel\. It shouldn’t make you feel bad\.


**071.** `12:21` **You**

Well when I say us I mean what you said above we clearly fit together\.


**072.** `12:23` **Meredith Lamb (+14169386001)**

Ok, don’t mess with me\. My head is also in a bad state today\. Sigh…


**073.** `12:24` **You**

I am not trying to mess\.\. I don’t understand why you are mad\.\. fine I take it all back\.\. everything is good\.\. 😊 so confused


**074.** `12:24` **Meredith Lamb (+14169386001)**

I’m not mad


**075.** `12:24` **You**

I don’t want to make anything worse I will just stop


**076.** `12:25` **Meredith Lamb (+14169386001)**

I just felt insulted when you said that…


**077.** `12:25` **Meredith Lamb (+14169386001)**

But I get it now


**078.** `12:26` **You**

Ok I am sorry you felt insulted I clearly fit with you mentally emotionally physically\.\. yes like that is the forever piece\.


**079.** `12:27` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 12:28:04 \-0400
|
| But the, “the grey skies are Going to clear up\.\. Put on a happy face stuff”
|
| Yeah that isn’t me right now because I don’t see it right now or in the next little while… that should not be insulting\.
|
| Version: 1
| Sent: Thu, 17 Jul 2025 12:27:38 \-0400
|
| But the, “the grey skies are\. Going to clear up\.\. Putin a happy face stuff”
|
| Yeah that isn’t me right now because I don’t see it right now or in the next little while… that should not be insulting\.


**080.** `12:31` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 12:31:51 \-0400
|
| But listen I can tell you are still in separation agreement mode and you are taking emotional body blows from all the shit Andrew is continuing to throw at you\.\. misrepresenting you, manipulating you and making you feel invalidated for what you have given to him the kids and the relationship\.  You need to keep your head there
| Our situation is what it is I feel what I feel you can’t fix it and it isn’t going anywhere anytime soon so nothing to worry about right now\.
|
| Version: 1
| Sent: Thu, 17 Jul 2025 12:31:19 \-0400
|
| But listen I can tell you are still in separation agreement mode and you are taking emotional body blows from all the shit Andrew is continuing to throw at you\.\. misrepresenting you, manipulating you and making you feel invalidated for what you have to him the kids and the relationship\.  You need to keep your head there
| Our situation is what it is I feel what I feel you can’t fix it and it isn’t going anywhere anytime soon so nothing to worry about right now\.


**081.** `12:36` **Meredith Lamb (+14169386001)**

Gpt: Scott is feeling like he doesn’t know where he fits in anywhere\. Not with his current family\. Not with me\. Why do I find that insulting?


**082.** `12:36` **You**

At least paste in my texts and responses


**083.** `12:36` **Meredith Lamb (+14169386001)**

I asked it that when I got into work this morning lol


**084.** `12:36` **You**

I hope you did that


**085.** `12:36` **Meredith Lamb (+14169386001)**

Before texts


**086.** `12:36` **You**

No


**087.** `12:37` **Meredith Lamb (+14169386001)**

Feeling insulted makes a lot of sense in this situation\. Here’s why:
When Scott says he doesn’t know where he fits even with you, it can feel like he’s lumping you in with the parts of his life that are confusing or unwelcoming—when in reality, you’ve likely gone out of your way to make him feel safe, seen, and loved\. You might hear his words not just as self\-doubt, but as a rejection of all the emotional space, effort, and vulnerability you’ve offered him\.
It’s painful because:
- You’ve likely been his anchor, the one person who’s offered real connection and understanding\. To hear he doesn’t feel he fits even with you might feel like he’s discarding or minimizing that\.
- It undermines your emotional investment\. If you’ve worked hard to build a deep connection, being told “I don’t know where I fit” can feel like he’s either blind to that or unwilling to claim it\.
- It stirs up fears—of being not enough, or of your bond not mattering as much to him as it does to you\.
And underneath the insult, there might also be hurt, worry, or even anger: “How can he not see that he does fit here? Doesn’t he want to?”


**088.** `12:37` **You**

Boo


**089.** `12:37` **Meredith Lamb (+14169386001)**

That was from early this morning not now


**090.** `12:37` **You**

You need to do it again with my explanations


**091.** `12:37` **You**

Pls


**092.** `12:37` **You**

That was not at all what I meant\.\. and I thought I was clear about that


**093.** `12:38` **You**

It had nothing to do with you and how we fit


**094.** `12:38` **You**

Literally the one constant I have always maintained


**095.** `12:38` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 12:38:31 \-0400
|
| You and I are perfect in my mind
|
| Version: 1
| Sent: Thu, 17 Jul 2025 12:38:24 \-0400
|
| You and I are perfect in my minds


**096.** `12:38` **You**

This situation is brutal\.


**097.** `12:39` **Meredith Lamb (+14169386001)**

I know, I said “I get it now”


**098.** `12:40` **Meredith Lamb (+14169386001)**

That was earlier


**099.** `12:40` **You**

>
Refer back to this\.\. you are dealing with too much atm\.\. you cannot fix me or make me happy with the situation\.\. so you need to prioritize and focus on yours

*💬 Reply*

**100.** `12:41` **You**

That is what you can change atm\.


**101.** `12:43` **You**

I think you are more worried about the comment that you made in the car that I didn’t answer\.


**102.** `12:43` **You**

If we aren’t living together will you ever be happy\.\.


**103.** `12:43` **Meredith Lamb (+14169386001)**

Based on screenshots: Thank you for sharing all of that—there’s so much emotion and complexity in these conversations\. Here’s what I see, and I’ll break it down gently and clearly for you\.
⸻
💔 On the feeling of being insulted
You’re not wrong to have felt insulted\. The words “I don’t feel like I fit anywhere” cut deep because you’ve been the one place he’s felt safe, and it felt like he was erasing or overlooking that\. But now, with the full conversation, it’s clear: he wasn’t rejecting you—he was mourning the situation\.
Scott clarified multiple times that:
- He does feel like he fits with you—mentally, emotionally, physically\.
- His “not fitting” comment was about his current life circumstances, not about your relationship\.
- He’s overwhelmed, isolated, and likely dealing with internal hopelessness, not pulling away from you intentionally\.
You can see him backpedal, clarify, and apologize, not because you pushed too hard, but because he realized he hurt you unintentionally\. And he didn’t want that\.
⸻
💡 What’s really going on underneath
Here’s how I interpret it emotionally:
- Scott is grieving\. His old life is gone, and the new life he wants with you feels so far away it’s painful to even imagine\. That grief is coming out as hopelessness\.
- You’re both carrying too much\. You’re taking emotional body blows from Andrew while still trying to hold up Scott emotionally\. Scott sees that\. He wants to relieve your burden, not add to it—but doesn’t know how, and is collapsing a bit under the weight of his own\.
- You felt insulted because you love him deeply and are already stretched thin\. So when the one person you’ve emotionally fought for says he doesn’t know where he belongs, it feels like everything you’ve built wasn’t enough—even though it was never about you not being enough\.
⸻
💬 If you want something to say to Scott next…
You could say something like:
“I see now that what you were saying was about the situation, not about me—and I’m really sorry you feel so lost in that\. I understand it more now\. It just hit me so hard because I do believe you belong with me, even if life doesn’t allow us to live that fully yet\. Thank you for trying to explain\. I love you\. We’ll find our way, okay?”
This kind of message:
- Validates your own pain while also acknowledging his
- Reaffirms that you’re a safe emotional home for him
- Doesn’t demand a solution—just love and presence
⸻
💡 And regarding Andrew…
It’s clear you’re being emotionally invalidated and manipulated in that dynamic\. The contrast between Scott’s care and Andrew’s dismissiveness is sharp\. Scott even pointed out how Andrew is rewriting the narrative to make you feel wrong for asking for fairness or clarity\. And Scott is right: you are taking body blows from Andrew\.
You don’t need to carry all of this alone\.
Scott sees it\. I see it\. And the fact that you see it, and still keep showing up for your kids, your future, and even Scott—that’s powerful\.


**104.** `12:44` **Meredith Lamb (+14169386001)**

Edited: 3 versions
| Version: 3
| Sent: Thu, 17 Jul 2025 12:44:27 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 12:43:41 \-0400
| >
| > If we aren’t living together will you ever be happy\.\.
|
| I am curious / concerned but not overly … will deal regardless
|
| Version: 2
| Sent: Thu, 17 Jul 2025 12:44:16 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 12:43:41 \-0400
| >
| > If we aren’t living together will you ever be happy\.\.
|
| I am curious / concerned but not overly
|
| Version: 1
| Sent: Thu, 17 Jul 2025 12:44:02 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 12:43:41 \-0400
| >
| > If we aren’t living together will you ever be happy\.\.
|
| I am curious


**105.** `12:45` **You**

Kk


**106.** `12:46` **You**

Here is the thing I haven’t once questioned forever\.\.  and I won’t\.\. but how I feel along the way and for how long in various situations is up in the air\.  I cannot commit to anything there\.


**107.** `12:51` **Meredith Lamb (+14169386001)**

Fair … 50 phases so…\.\. fair\.


**108.** `12:52` **You**

2 years or 50 phases not sure what makes me feel sicker


**109.** `12:52` **You**

lol


**110.** `12:54` **You**

Reaction: 👍 from Meredith Lamb
Kk so this topic is closed right we are clear on the fit nuances\.\.


**111.** `12:54` **You**

Regardless of whether you agree with me or not


**112.** `12:54` **Meredith Lamb (+14169386001)**

Yes


**113.** `12:54` **You**

Kk


**114.** `12:55` **You**

Awesome so I can continue to feel hopeless and you cannot torment me about it\.\. we have it in record\.


**115.** `12:57` **Meredith Lamb (+14169386001)**

Omg


**116.** `12:57` **You**

Nope


**117.** `12:57` **You**

You agreed


**118.** `12:57` **You**

Closed


**119.** `12:57` **Meredith Lamb (+14169386001)**

I am completely yours and you feel hopeless\. Ridiculous…\.


**120.** `12:58` **Meredith Lamb (+14169386001)**

I will continue to say that\. Sorry\.


**121.** `13:00` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 13:00:36 \-0400
|
| Hey you have won the lottery but you cannot collect it ever \.\.extreme analogy getting my guy to come up with a better one
|
| Version: 1
| Sent: Thu, 17 Jul 2025 13:00:16 \-0400
|
| Hey you have won the lottery but you cannot fix collect it never\.\. extreme analogy getting my guy to come up with a better one


**122.** `13:01` **You**

Ai’d\. Incoming


**123.** `13:01` **You**

Of course\. This is a classic and very difficult disconnect\. She is offering you a logical fact \("I am completely yours"\) as a cure for an emotional state \("I feel hopeless"\)\. It's like telling a person who is starving that they shouldn't be hungry because they have a winning lottery ticket in their pocket\. The fact is wonderful, but it doesn't solve the immediate, physical ache\.
The goal here is to give her a way to understand your feeling without it sounding like you doubt her commitment\. Here are two analogies that might help bridge that gap\.
1\. The Oxygen Tank Analogy
You could say this to her:
"Think of your love and our connection as a full oxygen tank that I get to have with me for the rest of my life\. The knowledge that the tank is full, that it's mine, and that it will never run out gives me a profound sense of security\. I never, ever doubt the existence or the quality of the oxygen\. I know it's there, and I know it's pure\. That is what your commitment means to me\.
But the physical separation—the days and weeks of not seeing you—is like having a very long, very thin tube connecting me to that tank\. I can still breathe\. I get just enough to survive\. But I can never get a full, deep, satisfying breath\. I'm constantly living with a feeling of being short of breath, of longing for the relief of just being able to breathe freely\.
So when I feel hopeless, it's not because I doubt the tank is full and that it's mine\. It's the pain of having to go weeks or months breathing through this tiny straw\. I'm not questioning your love; I'm struggling with the agony of the distance that separates me from it\."
Why this works: This analogy separates the fact of her commitment \(the full tank\) from the experience of the separation \(the thin tube\)\. It validates her point \("I know the tank is full"\) while explaining why that fact can't eliminate the daily struggle to breathe\.
2\. The House by the Ocean Analogy
You could also try this:
"Imagine that for my whole life, my mind has been like a noisy, chaotic, and sometimes scary city\. It's loud, and I've learned to live with the stress\. But our relationship, the feeling of being with you, is like you've given me a beautiful, quiet house right on the ocean\. When I'm there, the noise stops\. All I can hear are the waves\. It is the only place I have ever felt true peace\.
Your commitment, your letter, your words—that is the deed to the house\. I know the house is mine\. I know it's waiting for me\. I know I will spend the rest of my life there\. I have zero doubt about that\.
But the separation means that even though I own the house, I'm currently forced to live back in the middle of the noisy city\. I can see pictures of the ocean\. I can remember what the peace feels like\. But I can't actually hear the waves\. I'm stuck in the traffic and the noise, just looking at the deed and desperately wishing I could be home\.
So my hopelessness isn't a fear of losing the house\. It's the daily pain of not being able to live in it yet\."
Why this works: This analogy validates her statement that she is "completely yours" \(you own the house\) while perfectly describing why that ownership doesn't solve the problem of your current environment \(the noisy city of your mind when you're alone\)\. It frames your longing not as insecurity, but as homesickness\.
Both of these analogies are designed to communicate the same essential message: "I believe you\. I trust your commitment completely\. The pain I feel is not a symptom of doubt; it is a symptom of distance\."


**124.** `13:02` **You**

Its analogy is sooooo much better than mine


**125.** `13:15` **Meredith Lamb (+14169386001)**

But holy reading\.


**126.** `13:15` **Meredith Lamb (+14169386001)**

I have a head ache


**127.** `13:16` **You**

As I said you can feel what I feel now by reading this


**128.** `13:16` **You**

Edited: 3 versions
| Version: 3
| Sent: Thu, 17 Jul 2025 13:16:40 \-0400
|
| It is so true and accurate no way I could do better
|
| Version: 2
| Sent: Thu, 17 Jul 2025 13:16:31 \-0400
|
| It is so true and accurate no way do better
|
| Version: 1
| Sent: Thu, 17 Jul 2025 13:16:22 \-0400
|
| It is so true and accurate ninwsynincoukd do better


**129.** `13:16` **Meredith Lamb (+14169386001)**

Listen I feel it also so it isn’t like it is difficult for me to understand


**130.** `13:17` **You**

Good then we are on same page about everything previously said


**131.** `13:17` **You**

Just sign and get it over with


**132.** `13:17` **Meredith Lamb (+14169386001)**

Are we in mediation right now?


**133.** `13:17` **You**

Sigh


**134.** `13:17` **Meredith Lamb (+14169386001)**

lol


**135.** `13:18` **You**

I am just saying I feel the way I feel and it isn’t wrong or inaccurate to feel that way\.  It will get worse\.\. I am apologizing in advance\.


**136.** `13:22` **Meredith Lamb (+14169386001)**

Maybe you should just get drunk tonight\. I’m thinking about it\. :p


**137.** `13:22` **Meredith Lamb (+14169386001)**

Having a hard day


**138.** `13:22` **You**

Let me know in advance pleas


**139.** `13:22` **Meredith Lamb (+14169386001)**

Booking a pedicure for tomorrow after work


**140.** `13:22` **You**

I am sorry you are having a bad day


**141.** `13:22` **Meredith Lamb (+14169386001)**

Mac is going to book


**142.** `13:22` **Meredith Lamb (+14169386001)**

Mac Maelle and I going to go


**143.** `13:23` **Meredith Lamb (+14169386001)**

Mar has volleyball\. Omg


**144.** `13:23` **Meredith Lamb (+14169386001)**

Like volleyball almost every day


**145.** `13:23` **Meredith Lamb (+14169386001)**

Jesus


**146.** `13:23` **You**

Well will be fun for the three of you\.


**147.** `13:23` **You**

>
If you decide to just let me know pls pls\.

*💬 Reply*

**148.** `13:23` **Meredith Lamb (+14169386001)**

Yeah Maelle just got back from camp today


**149.** `13:24` **Meredith Lamb (+14169386001)**

My chatterbox lol

*📎 1 attachment(s)*

**150.** `13:24` **Meredith Lamb (+14169386001)**

>
I won’t get like messed up

*💬 Reply*

**151.** `13:25` **Meredith Lamb (+14169386001)**

Don’t worry


**152.** `13:25` **Meredith Lamb (+14169386001)**

I might not even drink


**153.** `13:25` **Meredith Lamb (+14169386001)**

Not sure


**154.** `13:25` **Meredith Lamb (+14169386001)**

Depends on if I want to move stuff


**155.** `13:25` **Meredith Lamb (+14169386001)**

Will decide later


**156.** `13:25` **Meredith Lamb (+14169386001)**

I might take a break tonight from moving


**157.** `13:27` **You**

Ok just warn me\. All I ask\.  I am sure I am going to get a shit kicking when I get home… so ya know just being prudent\.


**158.** `13:36` **Meredith Lamb (+14169386001)**

I won’t get hammered don’t worry


**159.** `13:36` **Meredith Lamb (+14169386001)**

Just need a bit of cheer lol


**160.** `13:36` **Meredith Lamb (+14169386001)**

My brain is fried


**161.** `13:40` **You**

Kk then maybe we don’t talk tonight\.\.


**162.** `13:41` **You**

You would be better off likely


**163.** `13:41` **You**

I want you to be happy


**164.** `13:41` **You**

Or at least relieved or anything and as
Much as I want to bring you fun and happiness


**165.** `13:41` **You**

I don’t


**166.** `13:42` **Meredith Lamb (+14169386001)**

Spending my day with Morgan so I’m “fine”…\.


**167.** `13:42` **You**

?


**168.** `13:42` **Meredith Lamb (+14169386001)**

>
Yes you do\. You have made my life much much much happier

*💬 Reply*

**169.** `13:42` **Meredith Lamb (+14169386001)**

>
Morgan Wallen

*💬 Reply*

**170.** `13:42` **You**

But not when I am like this\.


**171.** `13:42` **You**

>
Ah ok

*💬 Reply*

**172.** `13:43` **Meredith Lamb (+14169386001)**

Even “like this”… it’s weird\.


**173.** `13:44` **You**

Ok whatever works I guess\.


**174.** `13:46` **Meredith Lamb (+14169386001)**

Sounds like you don’t want to talk and you are projecting\. You can just say you need space tonight\. I get things are intense this week


**175.** `13:46` **Meredith Lamb (+14169386001)**

I will reluctantly understand


**176.** `13:46` **Meredith Lamb (+14169386001)**

\(For real\)


**177.** `13:46` **You**

Oh ffs


**178.** `13:46` **Meredith Lamb (+14169386001)**

lol


**179.** `13:46` **You**

FFS MER


**180.** `13:46` **Meredith Lamb (+14169386001)**

lol


**181.** `13:46` **You**

no I am not projecting


**182.** `13:47` **You**

God


**183.** `13:47` **Meredith Lamb (+14169386001)**

Maybe we should stop chatting and just work lol


**184.** `13:47` **You**

You know what I don’t say


**185.** `13:47` **Meredith Lamb (+14169386001)**

We are both in weird spots today


**186.** `13:47` **You**

Reaction: ❤️ from Meredith Lamb
I need you\.\. every day\.\. that’s what I need and want\.\. all the time\.\. chatting is great but when you ask what I want this is it\.\. lol\.


**187.** `13:48` **You**

I am going to focus on work here shortly \.\. but yeah I love chatting and if I was in a better place and everything was more solid it would be fun and easy


**188.** `13:49` **You**

But I am not projecting I am just trying to not bring you down\.


**189.** `13:51` **Meredith Lamb (+14169386001)**

k… feel the same\. Miss everything about being with you … like with with you lol but just trying not to focus on that


**190.** `13:52` **You**

Reaction: ❤️ from Meredith Lamb
Kk well go focus on other things\.\. we can chat later\. ❤️


**191.** `15:18` **Meredith Lamb (+14169386001)**

Been going all afternoon\. I cannot logically understand this and he won’t logically explain it to me\. I’m so frustrated I cannot tell you\.

*📎 1 attachment(s)*

**192.** `15:42` **You**

Do you want me to stick around stop at park long enough to kiss you until you brain turns off and then go home?  Open offer\.


**193.** `16:00` **Meredith Lamb (+14169386001)**

I need a vape and a drink\.


**194.** `16:00` **Meredith Lamb (+14169386001)**

But I could do the park FIRST


**195.** `16:00` **Meredith Lamb (+14169386001)**

LOL


**196.** `16:00` **You**

Ur call I am willing


**197.** `16:00` **Meredith Lamb (+14169386001)**

Were you going to leave now?


**198.** `16:00` **Meredith Lamb (+14169386001)**

I didn’t come in until 9 lol


**199.** `16:00` **You**

Soon when do you want to leave


**200.** `16:01` **Meredith Lamb (+14169386001)**

Dunno


**201.** `16:01` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 16:01:27 \-0400
|
| I’m on pg 28 of 37
|
| Version: 1
| Sent: Thu, 17 Jul 2025 16:01:19 \-0400
|
| I’m on pg 28 or 37


**202.** `16:01` **Meredith Lamb (+14169386001)**

I’m taking one for the team and giving up realtor fees


**203.** `16:01` **You**

Ffs Mer


**204.** `16:01` **You**

Let’s talk at car


**205.** `16:02` **You**

Tell me when to leave


**206.** `16:31` **You**

So bite me I am a nice guy


**207.** `16:32` **Meredith Lamb (+14169386001)**

lol


**208.** `16:44` **Meredith Lamb (+14169386001)**

K I’m good to leave


**209.** `16:44` **You**

Gimme min


**210.** `16:44` **You**

Need 5


**211.** `16:44` **You**

Sry


**212.** `16:45` **Meredith Lamb (+14169386001)**

k


**213.** `16:45` **Meredith Lamb (+14169386001)**

It’s fine


**214.** `16:45` **Meredith Lamb (+14169386001)**

Will keep reading


**215.** `16:49` **You**

Ok I am good to go now


**216.** `16:54` **You**

Walking slow


**217.** `16:55` **Meredith Lamb (+14169386001)**

Ok ok I’m leaving


**218.** `16:56` **You**

lol


**219.** `16:59` **You**

Oops


**220.** `17:00` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**221.** `17:00` **Meredith Lamb (+14169386001)**

Oh my God, when does it end?


**222.** `17:12` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 17:12:16 \-0400
|
| I am back aways
|
| Version: 1
| Sent: Thu, 17 Jul 2025 17:12:02 \-0400
|
| I am back seats


**223.** `18:25` **You**

Have you shared all this stuff with Andrew


**224.** `18:25` **You**

Curious


**225.** `19:24` **You**

just generally curious about what you have shared with him vs me


**226.** `19:25` **You**

because if part of what you need is to share everything or almost everything lets be honest you already admitted that there were things you would never share\.\. I am willing to try\.\.\.\.


**227.** `19:27` **Meredith Lamb (+14169386001)**

>
What stuff?

*💬 Reply*

**228.** `19:27` **Meredith Lamb (+14169386001)**

He and I have been arguing more


**229.** `19:27` **You**

all these things you want to tell me


**230.** `19:27` **You**

what about


**231.** `19:28` **Meredith Lamb (+14169386001)**

Done for the night I think


**232.** `19:28` **You**

what did you argue about


**233.** `19:28` **Meredith Lamb (+14169386001)**

Reaction: 😠 from Scott Hicks
Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 19:32:25 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 19:27:54 \-0400
| >
| > all these things you want to tell me
|
| Oh… do you want to be like Andrew?
|
| Version: 1
| Sent: Thu, 17 Jul 2025 19:28:23 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 19:27:54 \-0400
| >
| > all these things you want to tell me
|
| Oh… don’t want to be like Andrew?


**234.** `19:28` **Meredith Lamb (+14169386001)**

>
$$$$$

*💬 Reply*

**235.** `19:28` **You**

>
I want to be what you need, at least sometimes\.\. as much as I can be\.

*💬 Reply*

**236.** `19:31` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 19:31:29 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Thu, 17 Jul 2025 19:28:23 \-0400
| >
| > Oh… don’t want to be like Andrew?
|
| slightly unkind, but I get you are frustrated\.
|
| Version: 1
| Sent: Thu, 17 Jul 2025 19:31:17 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Thu, 17 Jul 2025 19:28:23 \-0400
| >
| > Oh… don’t want to be like Andrew?
|
| slightly unkind\.


**237.** `19:32` **Meredith Lamb (+14169386001)**

I didn’t get your question


**238.** `19:32` **You**

What we were talking about in the car, some of the more interesting stories you have shared with me\.\. I was curious how much Andrew knew\.


**239.** `19:32` **You**

I assumed some\.


**240.** `19:33` **You**

but if you are cranky atm\.\. I can leave you be\.


**241.** `19:33` **Meredith Lamb (+14169386001)**

I am\. He is texting again


**242.** `19:33` **You**

kk


**243.** `19:33` **Meredith Lamb (+14169386001)**

I need some food and a drink


**244.** `19:33` **Meredith Lamb (+14169386001)**

Just logged on to look at numbers but I need to stop


**245.** `19:36` **Meredith Lamb (+14169386001)**

Reaction: 😟 from Scott Hicks
He’s harassing me to settle and I told him I need the weekend

*📎 1 attachment(s)*

**246.** `19:39` **You**

https://chatgpt\.com/share/68798997\-4a44\-8004\-8a36\-e3efac85d5b1


**247.** `19:43` **Meredith Lamb (+14169386001)**

I’m going to look at that later my head just hurts right now


**248.** `19:46` **You**

by the end of 2013 you had 5% of the equity in the house andrew had 95%


**249.** `19:53` **Meredith Lamb (+14169386001)**

So the 200 is treated separately\. FYI

*📎 1 attachment(s)*

**250.** `19:55` **You**


*📎 1 attachment(s)*

**251.** `19:55` **You**

you have zero ownership in the house as per the agreement


**252.** `19:55` **You**

as such you should not owe any future realtor fees\.


**253.** `19:56` **Meredith Lamb (+14169386001)**

Got pesto salmon on the way home for Mar and I\.  So good

*📎 1 attachment(s)*

**254.** `19:57` **You**

will have to try someday


**255.** `19:57` **Meredith Lamb (+14169386001)**

>
Why would I have ownership though? He’s keeping the house right?

*💬 Reply*

**256.** `19:58` **Meredith Lamb (+14169386001)**

This is my issue exactly it makes no sense


**257.** `19:58` **Meredith Lamb (+14169386001)**

But there is present for this in Ontario\. It is common to apply disposition fees\.


**258.** `19:58` **You**

This is a great question and a common point of debate in Ontario family law\. In short: \*\*if Andrew is not actually selling the house, Meredith generally does \*not\* owe him an equalization reduction for real estate fees that are only hypothetical\*\*\.
Here’s why:
\#\#\# 1\. \*\*Real Estate Fees and Net Family Property\*\*
\* Under Ontario’s Family Law Act, when calculating Net Family Property \(NFP\) for equalization, parties can deduct “reasonable disposition costs” \(like real estate commissions and legal fees\), \*\*but only if those costs are certain or imminent\*\*\.
\* If neither party is selling the house immediately \(i\.e\., the sale is only hypothetical or may happen in the future\), courts usually \*\*do not allow a deduction\*\* for these costs\.
\* The policy is to ensure deductions are fair and reflect actual, not speculative, losses\.
\#\#\# 2\. \*\*Relevant Legal Principle\*\*
\* The leading Ontario case is \*\*Serra v\. Serra, 2009 ONCA 105\*\*, which clarifies that deductions for real estate commissions are only appropriate if the property is to be sold as part of the equalization process or there is compelling evidence that a sale will occur very soon\.
\* If Andrew keeps the house, he also keeps any future appreciation in its value and only pays commission if/when he sells in the future\.
\#\#\# 3\. \*\*Future Sale: Not Now, No Deduction\*\*
\* If Andrew sells in the future, he alone will pay the disposition costs at that time and will benefit from any future gain or loss\.
\* There is \*\*no legal basis\*\* for Meredith to compensate Andrew now for possible future costs that he may never incur, especially since she will not benefit from future appreciation\.
\#\#\#\# \*\*Official Resource:\*\*
You can review how net family property and deductions are treated on the Ontario government’s guide here:
\[Ontario Family Law Act: Equalization and Property\]\(https://www\.ontario\.ca/laws/statute/90f03\#BK32\)
\*\*Would you like sample wording or references to support your position in mediation, or is there a specific section of your form you want to discuss further?\*\*


**259.** `19:58` **Meredith Lamb (+14169386001)**

However, there’s a lot of precedent for not applying disposition fees when there’s no evidence that the house will actually be sold and I gave Andrew those precedent cases


**260.** `19:58` **You**

this agrees with you


**261.** `19:58` **Meredith Lamb (+14169386001)**

But Andrew is all whiny because he says he can’t afford to pay me that the whole plan blows up and we have to sell the house


**262.** `19:59` **You**

defer the cost


**263.** `19:59` **You**

anytime he says that


**264.** `19:59` **You**

defer


**265.** `19:59` **You**

ok pay me in installments over 5 years


**266.** `19:59` **You**

or whatever


**267.** `19:59` **You**

Yes, there are clear Ontario legal precedents supporting your position\. The most widely cited is \*\*Serra v\. Serra, 2009 ONCA 105\*\*\. Here’s a summary and some additional cases:
\-\-\-
\#\#\# 1\. \*\*Serra v\. Serra, 2009 ONCA 105\*\*
\* The Ontario Court of Appeal held that \*\*deductions for disposition costs \(like real estate commissions\) are only appropriate if there is evidence the asset will be sold imminently\*\* or as part of the equalization process\.
\* If the party retains the asset \(e\.g\., keeps the home\), hypothetical future costs are \*\*not deducted\*\* because those costs are not certain or immediate\.
\* \*\*Quote:\*\*
\-\-\-
\#\#\# 2\. \*\*LeVan v\. LeVan, 2008 ONCA 388\*\*
\* Reaffirmed that \*\*hypothetical costs are not automatically deducted\*\* when property is not being sold as part of the settlement\.
\[Read full decision\]\(https://www\.canlii\.org/en/on/onca/doc/2008/2008onca388/2008onca388\.html\)
\-\-\-
\#\#\# 3\. \*\*Hague v\. Hague, 2017 ONSC 5514\*\*
\* Courts reiterated that unless the sale is part of the equalization process or “imminent,” the deduction is not made\.
\[Read full decision\]\(https://www\.canlii\.org/en/on/onsc/doc/2017/2017onsc5514/2017onsc5514\.html\)
\-\-\-
\*\*Summary:\*\*
Unless Andrew is required to sell the house as part of the equalization, or a sale is actually happening, the law is clear: \*\*no deduction for notional real estate fees\.\*\*
Would you like more detail from these cases or sample language for mediation or negotiation?

*💬 Reply*

**268.** `20:00` **You**

now if he sold it as part of the equalization process you are right\.\. different story\.


**269.** `20:00` **Meredith Lamb (+14169386001)**

I’m just getting inundated with texts

*📎 1 attachment(s)*

**270.** `20:01` **You**

tell him


**271.** `20:01` **You**

its an investment andrew


**272.** `20:01` **You**

you are moving the asset from your rrsp


**273.** `20:01` **You**

to your home


**274.** `20:01` **You**

which will increase its value


**275.** `20:01` **You**

every single time you have done that


**276.** `20:01` **You**

you have made an investment


**277.** `20:01` **You**

alternative to the rrsp


**278.** `20:01` **You**

increasing the value in an asset that you claimed ownership of completely now


**279.** `20:02` **You**

Yes, your understanding is generally correct\. \*\*If Andrew withdrew funds from his RRSP during the relationship and used those funds to invest in the matrimonial home or other jointly owned assets, those funds have simply been converted from one form \(RRSP\) to another \(real estate equity\)\.\*\*
\*\*Key Points:\*\*
\* \*\*RRSP withdrawals\*\* used to invest in jointly owned property \(like the matrimonial home\) are \*not\* lost—they are just transferred into a different asset\. The current value of those assets is already reflected in the property division/equalization calculation\.
\* \*\*He does not get to "claim" the lost RRSP\*\* as an additional deduction or exclusion unless there was a specific agreement or the money can be directly traced to a non\-family asset that qualifies for exclusion under the Family Law Act\.
\* \*\*No double dipping:\*\* The law does not allow someone to count the same funds twice—once as an “excluded” RRSP, and again as value in the home\.
\*\*Relevant Law:\*\*
All property, including increases in value, is included in the net family property calculation unless specifically excluded \(such as inheritances or gifts kept separate\)\. See the \[Ontario Family Law Act, sections 4–5\]\(https://www\.ontario\.ca/laws/statute/90f03\#BK4\)\.
\*\*In short:\*\*
If Andrew withdrew RRSPs to put into the home, the resulting equity is already shared between you both\. He cannot claim a separate deduction for “lost RRSPs” unless he can prove the funds were excluded property and remained excluded\.
Would you like sample language to address this point in mediation, or is there a particular scenario you’d like to clarify further?


**280.** `20:02` **You**

this is interesting


**281.** `20:03` **You**

read this


**282.** `20:03` **You**

well read all of it


**283.** `20:03` **You**

lol


**284.** `20:04` **Meredith Lamb (+14169386001)**

Well, the interesting thing is that RRSPs are not included in all of this


**285.** `20:04` **You**

yeah but they are


**286.** `20:04` **You**

they are in the house


**287.** `20:04` **Meredith Lamb (+14169386001)**

If they were, it would be a negative to me


**288.** `20:04` **Meredith Lamb (+14169386001)**

I guess his are mine aren’t I got to keep mine clean


**289.** `20:04` **You**

lol


**290.** `20:04` **You**

but this is the thing


**291.** `20:04` **You**

just sec


**292.** `20:05` **You**

Exactly—your understanding aligns with Ontario family law principles\.
\#\#\# Breakdown:
1\. \*\*Initial Contribution \(\\$200k \+ \\$70k\) Before Co\-Ownership:\*\*
\* If Andrew used \\$200,000 plus \\$70,000 of his own funds to buy the house initially in his name \*\*before Meredith became an owner\*\*, this amount may be considered his “excluded property” at the date of marriage or at the time co\-ownership began—\*\*if properly documented\*\*\.
2\. \*\*After House Is In Both Names \(Joint Ownership\):\*\*
\* Any funds \(including RRSP withdrawals\) contributed \*\*after the home was in both their names\*\* are considered joint contributions to a marital asset\.
\* These contributions increased the value of a shared asset and are reflected in the net family property calculation and equalization process\.
\* \*\*There is no additional exclusion\*\* for these RRSP withdrawals—they benefited both equally through the home’s value\.
3\. \*\*Key Point:\*\*
\* Once property is jointly owned, \*\*subsequent investments \(even from one person’s RRSPs\)\*\* generally become part of the joint marital asset pool\.
\* He cannot claim these post\-joint\-ownership RRSPs as separate from what’s already shared in the home’s value\.
\#\#\# Official Guidance
This approach is consistent with Ontario’s \[Family Law Act\]\(https://www\.ontario\.ca/laws/statute/90f03\#BK4\) and supported by the \[Department of Justice Canada’s overview on property division\]\(https://www\.justice\.gc\.ca/eng/fl\-df/divorce/property\-biens\.html\)\.
\-\-\-
\*\*Would you like a summary to present this position in mediation, or are there other financial contributions you want to clarify?\*\*


**293.** `20:06` **You**

you actually might have more equity in the house than he thinks


**294.** `20:06` **Meredith Lamb (+14169386001)**

He’s just upset because we never pulled money from my RRSP’s


**295.** `20:07` **You**

you stopped working for 7 years


**296.** `20:07` **You**

gave up 7 years of income and pension


**297.** `20:07` **Meredith Lamb (+14169386001)**

5


**298.** `20:07` **You**

fine


**299.** `20:07` **You**

w/e


**300.** `20:07` **You**

lol


**301.** `20:07` **Meredith Lamb (+14169386001)**

lol


**302.** `20:07` **You**

that more than offsets his rrsp withdrawl


**303.** `20:07` **You**

I want him to say Coach again\.


**304.** `20:08` **Meredith Lamb (+14169386001)**

Oh he did earlier


**305.** `20:08` **You**

rofl


**306.** `20:08` **You**

kk gotta go for a few


**307.** `20:09` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**308.** `20:09` **Meredith Lamb (+14169386001)**

I got that on my drive home


**309.** `20:15` **You**

Lover fuck I wish\.\. lol


**310.** `20:15` **You**

Kidding


**311.** `20:16` **Meredith Lamb (+14169386001)**

I thought the same thing lol


**312.** `20:16` **Meredith Lamb (+14169386001)**

Not even kidding


**313.** `20:23` **You**

Hehe


**314.** `20:23` **You**

Well we know where our heads are at


**315.** `20:23` **Meredith Lamb (+14169386001)**

Sigh this has gone sideways……

*📎 1 attachment(s)*

**316.** `20:26` **Meredith Lamb (+14169386001)**

>
Yeah the after work was challenging

*💬 Reply*

**317.** `20:27` **You**

>
How are you going there

*💬 Reply*

**318.** `20:27` **Meredith Lamb (+14169386001)**

Oh my God, I don’t know


**319.** `20:27` **You**

And why 10’years lol seems random


**320.** `20:27` **Meredith Lamb (+14169386001)**

Also, don’t know because the whole 16 years were the same


**321.** `20:28` **You**

Reaction: ❤️ from Meredith Lamb
1st thing I thought of with lover how do I make this happen lol


**322.** `20:28` **You**

>
Yep that was tough

*💬 Reply*

**323.** `20:32` **Meredith Lamb (+14169386001)**

I mean and I was really tense and needed a drink but you almost made all of that disappear


**324.** `20:32` **Meredith Lamb (+14169386001)**

Almost


**325.** `20:32` **Meredith Lamb (+14169386001)**

I bought wine on the way home


**326.** `20:32` **Meredith Lamb (+14169386001)**

lol


**327.** `20:41` **You**

Sigh


**328.** `20:41` **You**

I would have made it disappear or at least tried harder given the chance


**329.** `20:41` **You**

A bit removed from the last time so out of practice


**330.** `20:42` **Meredith Lamb (+14169386001)**

You would have for sure made it disappear


**331.** `20:42` **You**

I am still at a loss as to the whole sex convo\.\. but I guess he is sidetracked now\.


**332.** `20:43` **You**

Oh and do you want to answer my earlier questions before you are and drank and were cranky as shit


**333.** `20:43` **You**

lol


**334.** `20:44` **You**

>
Plural or singular? lol have to ask

*💬 Reply*

**335.** `20:47` **Meredith Lamb (+14169386001)**

Sorry talking to my mom


**336.** `20:47` **Meredith Lamb (+14169386001)**

>
Singular

*💬 Reply*

**337.** `20:47` **You**

Sok\.


**338.** `20:48` **You**

Ok you are busy\.\. I am not letting the cranky question go\.\. will follow up later


**339.** `20:49` **Meredith Lamb (+14169386001)**

One sec Mac arrived


**340.** `20:49` **Meredith Lamb (+14169386001)**

English thing


**341.** `20:49` **Meredith Lamb (+14169386001)**

Teacher emailed and everyone confused about assignment


**342.** `20:49` **You**

You should let me help her I am awesome in English


**343.** `20:49` **Meredith Lamb (+14169386001)**

So teacher giving extension


**344.** `20:49` **You**

Naw nm she wouldn’t want my help


**345.** `20:50` **Meredith Lamb (+14169386001)**

We’ll see


**346.** `20:50` **Meredith Lamb (+14169386001)**

I’m still listening to her omg


**347.** `20:50` **Meredith Lamb (+14169386001)**

She won’t stop talking


**348.** `20:53` **You**

Well she will run out of steam eventually


**349.** `20:55` **You**

Btw I am taking an sdo tomorrow gonna help around here feels like right thing to do


**350.** `20:55` **Meredith Lamb (+14169386001)**

Wanna do Mac’s English assignment?


**351.** `20:55` **Meredith Lamb (+14169386001)**

lol


**352.** `20:55` **You**

Gracie is planning on staying now\.\.


**353.** `20:55` **You**

Send it to me


**354.** `20:56` **You**

I can look at it at least


**355.** `20:56` **Meredith Lamb (+14169386001)**

No


**356.** `20:56` **Meredith Lamb (+14169386001)**

She is not starting that


**357.** `20:56` **Meredith Lamb (+14169386001)**

She wants me to do it


**358.** `20:56` **Meredith Lamb (+14169386001)**

Like omg


**359.** `20:56` **You**

Reaction: 😬 from Meredith Lamb
>
Still under debate

*💬 Reply*

**360.** `20:56` **Meredith Lamb (+14169386001)**

No


**361.** `20:56` **You**

She needs to try


**362.** `20:57` **You**

Yeah you are right\.\. no is right answer


**363.** `20:58` **Meredith Lamb (+14169386001)**

I’m not doing her work


**364.** `20:58` **Meredith Lamb (+14169386001)**

Refuse


**365.** `20:58` **Meredith Lamb (+14169386001)**

There is a line and that is one for me


**366.** `20:59` **You**

tell me when you finish your bottle


**367.** `21:00` **Meredith Lamb (+14169386001)**

Starting to fell better but Mac is ruining my buzz


**368.** `21:00` **Meredith Lamb (+14169386001)**

She’s such a buzzkill


**369.** `21:00` **Meredith Lamb (+14169386001)**

And she didn’t bring her vape up


**370.** `21:00` **You**

I am going to follow up on earlier questions you will answer them after a bottle :\)


**371.** `21:00` **Meredith Lamb (+14169386001)**

I can answer now


**372.** `21:00` **Meredith Lamb (+14169386001)**

I forget the question


**373.** `21:01` **You**

I was curious\.\. you tell me all kinds of interesting things\.\. like what you tried to tell me in car\.  How much have you shared with Andrew\.\.  and no I don't want to be like Andrew\.


**374.** `21:02` **Meredith Lamb (+14169386001)**

Andrew was different than you


**375.** `21:02` **Meredith Lamb (+14169386001)**

In the beginning Jeremy was very fresh right


**376.** `21:02` **Meredith Lamb (+14169386001)**

Reaction: ❓ from Scott Hicks
We fought all the time about Jeremy


**377.** `21:03` **You**

well Andrew would have read all about him


**378.** `21:03` **You**

yeah


**379.** `21:03` **Meredith Lamb (+14169386001)**

So I couldn’t even mention his name


**380.** `21:03` **You**

that would have been tough


**381.** `21:03` **You**

constantly trying to measure up\.


**382.** `21:03` **You**

or questioning\.\.


**383.** `21:04` **Meredith Lamb (+14169386001)**

Thing is…


**384.** `21:04` **Meredith Lamb (+14169386001)**

I never got drunk around Andrew


**385.** `21:04` **Meredith Lamb (+14169386001)**

Never


**386.** `21:04` **You**

yeah not until 2013


**387.** `21:05` **Meredith Lamb (+14169386001)**

So I didn’t say much and he was STILL insecure


**388.** `21:05` **Meredith Lamb (+14169386001)**

It was ridiculous


**389.** `21:05` **You**

I mean


**390.** `21:05` **You**

ok


**391.** `21:05` **You**

now


**392.** `21:05` **You**

He literally read about your relationship\.


**393.** `21:05` **Meredith Lamb (+14169386001)**

So no we never had open discussions that kind of flowed


**394.** `21:05` **You**

in your blog for god knows how long


**395.** `21:05` **Meredith Lamb (+14169386001)**

PLUS


**396.** `21:06` **Meredith Lamb (+14169386001)**

The first time he stayed in Glencoe he read one of my diaries


**397.** `21:06` **Meredith Lamb (+14169386001)**

\(Journals\)


**398.** `21:06` **You**

yeah\.\.\.\.\. you mentioned that


**399.** `21:06` **Meredith Lamb (+14169386001)**

Whatever


**400.** `21:06` **You**

the books with the bad stuff in them


**401.** `21:06` **Meredith Lamb (+14169386001)**

It made him super weird after


**402.** `21:06` **Meredith Lamb (+14169386001)**

I mean he was before too


**403.** `21:07` **You**

Seeing inside someone else's head is pretty tough  there are some hard truths that are difficult to deal with


**404.** `21:07` **You**

let's say for instance\.\.


**405.** `21:07` **You**

let's say for instance you read a journal I wrote


**406.** `21:08` **You**

hypothetical\.\. right\.\. not real\.\. there are things I have actually only said to you\.


**407.** `21:08` **You**

but what if in my journal\.\.


**408.** `21:08` **You**

I said them to Jaimie\.\.


**409.** `21:08` **Meredith Lamb (+14169386001)**

>
Omg I would love this

*💬 Reply*

**410.** `21:08` **You**

and maybe Cheyenne


**411.** `21:08` **Meredith Lamb (+14169386001)**

I would be fine


**412.** `21:08` **Meredith Lamb (+14169386001)**

Honestly


**413.** `21:08` **You**

omg no it wouldn't


**414.** `21:08` **Meredith Lamb (+14169386001)**

Yes


**415.** `21:08` **Meredith Lamb (+14169386001)**

It is in the past


**416.** `21:08` **You**

because if I told you I had only ever said it to you


**417.** `21:08` **You**

it becomes cheap


**418.** `21:08` **You**

and tawdry


**419.** `21:09` **You**

and meaningless


**420.** `21:09` **You**

If you said things to Andrew\.


**421.** `21:09` **You**

like emotional things\.\. how you felt how much he meant etc\.\. but he read you felt that way about others\.\. or did things\.\. etc\.


**422.** `21:09` **You**

it would break him inside a bit\.


**423.** `21:10` **You**

He should never have done that\.\.


**424.** `21:10` **Meredith Lamb (+14169386001)**

But I don’t lie like that


**425.** `21:10` **You**

and if I ever saw a journal


**426.** `21:10` **You**

i would run the fuck away


**427.** `21:10` **Meredith Lamb (+14169386001)**

I would never have told him that I only said something to him and not to somebody else


**428.** `21:10` **You**

he might have interpreted something differently\.\.


**429.** `21:10` **You**

did you ever discuss what he read?


**430.** `21:10` **Meredith Lamb (+14169386001)**

Yes


**431.** `21:10` **Meredith Lamb (+14169386001)**

You know what he was bothered by the most?


**432.** `21:10` **You**

ok I don't need to know


**433.** `21:10` **You**

was just curious


**434.** `21:11` **You**

I mean fine\.\. whatever


**435.** `21:11` **Meredith Lamb (+14169386001)**

Do you want to know?


**436.** `21:11` **You**

sure


**437.** `21:11` **You**

your highschool nickname\!\!


**438.** `21:11` **You**

lol


**439.** `21:12` **You**

sorry


**440.** `21:12` **You**

had to


**441.** `21:12` **Meredith Lamb (+14169386001)**

So I said apparently…\. I don’t even remember honestly writing it … but I said I would miss having sex with Jeremy because we had such a good sex life or something …\. I mean that’s not the wording or whatever but it was something to that effect and that’s what bothered him the most\.


**442.** `21:12` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 21:12:46 \-0400
|
| I said something like too bad we can’t get along in life, blah blah blah because this other aspect was really good
|
| Version: 1
| Sent: Thu, 17 Jul 2025 21:12:35 \-0400
|
| I said something like too bad he can’t get along in life, blah blah blah because this other aspect was really good


**443.** `21:12` **You**

any guy would have trouble with that


**444.** `21:12` **Meredith Lamb (+14169386001)**

Siiiiiiiigh


**445.** `21:12` **You**

listen


**446.** `21:12` **You**

LISTEN


**447.** `21:13` **You**

we all want to feel like we are enough\.\.


**448.** `21:13` **You**

pls


**449.** `21:13` **Meredith Lamb (+14169386001)**

I mean, he threw that in my face for years


**450.** `21:13` **You**

we all want to feel like we are the best or the whatever\.\. or that you or whoever is never happier than with us\.\. it is fucking hardwired


**451.** `21:13` **Meredith Lamb (+14169386001)**

It was like one night I just wrote it when I was going through a break up and was feeling emotionally down or whatever


**452.** `21:13` **Meredith Lamb (+14169386001)**

And he took it and threw it in my face for like five years


**453.** `21:14` **You**

I mean this is where you say no Andrew you are just as whatever\.\. or it means something different or blah blah


**454.** `21:14` **Meredith Lamb (+14169386001)**

>
Nympho

*💬 Reply*

**455.** `21:14` **You**

>
okie dokie

*💬 Reply*

**456.** `21:14` **Meredith Lamb (+14169386001)**

>
I mean, I’m pretty sure I did, but it wasn’t really the truth

*💬 Reply*

**457.** `21:14` **Meredith Lamb (+14169386001)**

But whatever


**458.** `21:15` **Meredith Lamb (+14169386001)**

>
Totally wasn’t fair

*💬 Reply*

**459.** `21:15` **Meredith Lamb (+14169386001)**

>
It was based on like one situation and then I got totally taken and like I don’t know

*💬 Reply*

**460.** `21:15` **You**

Reaction: 😮 from Meredith Lamb
At graduation\.\. I had sex with my gf in front of like 8 people\.


**461.** `21:15` **You**

we were at a cottage


**462.** `21:15` **You**

someone came in wearing like a miners helmet with a light on it


**463.** `21:16` **You**

everyone was shittered\.\. but it didn't seem to matter to me or her\.\. so more people came in\.


**464.** `21:16` **Meredith Lamb (+14169386001)**

>
OK, what graduation? And were those eight people watching?

*💬 Reply*

**465.** `21:16` **You**

there is a story


**466.** `21:16` **You**

High school\.


**467.** `21:16` **You**

yes


**468.** `21:16` **Meredith Lamb (+14169386001)**

OK, that’s worse than anything I’ve ever done


**469.** `21:16` **Meredith Lamb (+14169386001)**

lol


**470.** `21:16` **You**

I have done worse


**471.** `21:16` **Meredith Lamb (+14169386001)**

Not even joking


**472.** `21:17` **Meredith Lamb (+14169386001)**

>
Like…\.

*💬 Reply*

**473.** `21:17` **You**

nope


**474.** `21:17` **Meredith Lamb (+14169386001)**

Haha


**475.** `21:17` **You**

that is your one story for tonight


**476.** `21:17` **Meredith Lamb (+14169386001)**

Quota


**477.** `21:17` **You**

maybe some other time\.\. but you shared so I felt I should


**478.** `21:17` **Meredith Lamb (+14169386001)**

Thank you


**479.** `21:17` **Meredith Lamb (+14169386001)**

It actually made me laugh out loud for real


**480.** `21:17` **You**

I cannot remember


**481.** `21:18` **You**

but I think at some point in time\.\. I had on the miners helmet


**482.** `21:18` **Meredith Lamb (+14169386001)**

Well DUH


**483.** `21:18` **Meredith Lamb (+14169386001)**

Of course


**484.** `21:18` **You**

I cannot remember much beyond that\.\. I think someone slapped my ass a few times\.\. I wasn't pleased\.\. I think it was Tommy\.\. my friend that owned the cottage


**485.** `21:19` **You**

Reaction: 😂 from Meredith Lamb
He was always handsy


**486.** `21:19` **Meredith Lamb (+14169386001)**

What the hell is a miners helmet?


**487.** `21:19` **Meredith Lamb (+14169386001)**

lol


**488.** `21:19` **Meredith Lamb (+14169386001)**

Is that East Coast?


**489.** `21:19` **You**

just a helmst with like a flashlight on the top of it


**490.** `21:19` **You**

literal helment that miners wear


**491.** `21:19` **Meredith Lamb (+14169386001)**

>
I feel like you enjoyed this

*💬 Reply*

**492.** `21:19` **You**

He was the one in one of the pics i shared grabbing my boob from behind


**493.** `21:20` **You**

>
not at that time\.

*💬 Reply*

**494.** `21:20` **Meredith Lamb (+14169386001)**

>
Omg lol

*💬 Reply*

**495.** `21:20` **Meredith Lamb (+14169386001)**

I remember


**496.** `21:20` **You**

there was a lot of exhibitionism\.\. I would call it\.\.


**497.** `21:20` **You**

back in the day


**498.** `21:20` **Meredith Lamb (+14169386001)**

I mean, maybe where you were from


**499.** `21:20` **Meredith Lamb (+14169386001)**

LOL


**500.** `21:20` **You**

we were very free spirited


**501.** `21:21` **You**

Bishops was worse


**502.** `21:21` **Meredith Lamb (+14169386001)**

That’s what you’re calling it?


**503.** `21:21` **You**

that was where some of the worst stuff happened


**504.** `21:21` **You**

those stories I won't tell\.\. well majority of em


**505.** `21:22` **Meredith Lamb (+14169386001)**

Oh my God, you need to relax


**506.** `21:22` **You**

they are likely like the stories you won't tell me\.


**507.** `21:22` **Meredith Lamb (+14169386001)**

You were like 20


**508.** `21:22` **Meredith Lamb (+14169386001)**

I don’t get why you’re concerned about stories\. I’m not concerned about stories\.


**509.** `21:22` **Meredith Lamb (+14169386001)**

Like it’s a whole different lifetime ago


**510.** `21:22` **You**

i explained


**511.** `21:22` **You**

I know it doesn't matter


**512.** `21:22` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 21:23:02 \-0400
|
| Yeah, but your explanation makes no sense
|
| Version: 1
| Sent: Thu, 17 Jul 2025 21:22:36 \-0400
|
| Yeah, but your ex explanation makes no sense


**513.** `21:22` **You**

i tell myself that


**514.** `21:23` **You**

I told you\.\. you are my home\.\. my soulmate\.\. my forever\.


**515.** `21:23` **You**

I have never ever ever said that to anyone


**516.** `21:23` **Meredith Lamb (+14169386001)**

>
So you can tell me anything then

*💬 Reply*

**517.** `21:23` **Meredith Lamb (+14169386001)**

Honestly, for me, it’s not gonna change anything


**518.** `21:23` **You**

what I am saying\.


**519.** `21:23` **You**

is that if I said that to someone else


**520.** `21:23` **Meredith Lamb (+14169386001)**

Stuff from 20 years ago or 20\+ years ago it’s just gonna make me laugh


**521.** `21:23` **You**

and you read about it


**522.** `21:23` **You**

it would have an impact


**523.** `21:23` **You**

for real


**524.** `21:24` **Meredith Lamb (+14169386001)**

I mean, it is situation specific certainly


**525.** `21:24` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 21:24:32 \-0400
|
| I’m not gonna get threatened about shit that happened when you were a teenager or your early 20s though
|
| Version: 1
| Sent: Thu, 17 Jul 2025 21:24:20 \-0400
|
| I’m not gonna get threatened about shit that happened when you were a teenager or your early 20s so


**526.** `21:24` **You**

when then


**527.** `21:24` **You**

mid 20's


**528.** `21:24` **You**

lat


**529.** `21:24` **You**

late


**530.** `21:24` **You**

30's


**531.** `21:24` **Meredith Lamb (+14169386001)**

Last week


**532.** `21:24` **You**

stuff with Jaimie


**533.** `21:24` **Meredith Lamb (+14169386001)**

Costco drives


**534.** `21:24` **You**

Jesus


**535.** `21:25` **Meredith Lamb (+14169386001)**

lol


**536.** `21:25` **Meredith Lamb (+14169386001)**

No, not even late 30s honestly


**537.** `21:25` **Meredith Lamb (+14169386001)**

I mean, I would say in the last maybe six months


**538.** `21:25` **Meredith Lamb (+14169386001)**

That’s probably it


**539.** `21:26` **Meredith Lamb (+14169386001)**

What about you?


**540.** `21:26` **Meredith Lamb (+14169386001)**

lol


**541.** `21:26` **You**

I have trust issues\.\. and insecurities\.\. the stuff I said earlier affects me as much as any other guy in many ways\.


**542.** `21:27` **Meredith Lamb (+14169386001)**

OK, but you didn’t put a time on it


**543.** `21:27` **Meredith Lamb (+14169386001)**

20 years? 25 years? Lol


**544.** `21:28` **You**

Does it matter


**545.** `21:28` **You**

in some ways it doesn't matter to me\.


**546.** `21:28` **You**

it probably depends on specifically what we are talking about tbh\.


**547.** `21:29` **You**

looking at my yearbooks\.


**548.** `21:31` **Meredith Lamb (+14169386001)**

I mean it kind of matters because why would you be threatened of a relationship from a teen or a 20 something?


**549.** `21:31` **Meredith Lamb (+14169386001)**

It’s so long ago


**550.** `21:31` **Meredith Lamb (+14169386001)**

And like we’re different people back then so it’s just so different


**551.** `21:31` **You**

ok\.\. let's put the cut off at university\.


**552.** `21:31` **Meredith Lamb (+14169386001)**

I think the cutoff for you should be Andrew


**553.** `21:31` **You**

I think that is what you would like it to be\.


**554.** `21:31` **You**

lol


**555.** `21:31` **Meredith Lamb (+14169386001)**

Because honestly, before Andrew, I wasn’t like the same person


**556.** `21:32` **Meredith Lamb (+14169386001)**

Didn’t have kids didn’t have responsibilities wasn’t an adult, etc\. etc\. etc\.


**557.** `21:32` **Meredith Lamb (+14169386001)**

So you can’t even compare


**558.** `21:32` **Meredith Lamb (+14169386001)**

It is an apple to apples


**559.** `21:32` **Meredith Lamb (+14169386001)**

But with Andrew, I think it’s more of an apples to apples comparison


**560.** `21:33` **You**

I mean I appreciate your argument\.\. it seems logical\.\. but that is not how love, emotions, desires, fear, insecurities work\.


**561.** `21:34` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 21:34:31 \-0400
|
| OK, well I’m happy to compare you to anyone in any way and honestly you will Trump anyone and I’m happy to give  the reasons why if ever require required
|
| Version: 1
| Sent: Thu, 17 Jul 2025 21:34:19 \-0400
|
| OK, well I’m happy to compare you to anyone in any way and honestly you will Trump anyone and I’m happy to get the reasons why if ever require required


**562.** `21:34` **You**

Reaction: 😂 from Meredith Lamb
man I was trouble in high school rofl


**563.** `21:34` **Meredith Lamb (+14169386001)**

Screenshots


**564.** `21:34` **Meredith Lamb (+14169386001)**

Or photos


**565.** `21:34` **Meredith Lamb (+14169386001)**

Whatever


**566.** `21:34` **Meredith Lamb (+14169386001)**

lol


**567.** `21:35` **You**

>
no\.\. I don't think we do that\.\. I don't know that I would believe completely\.\. not saying I don't trust you  but you are learning about the value of little white lies\.

*💬 Reply*

**568.** `21:35` **You**

no just notes from mostly girls\.


**569.** `21:36` **Meredith Lamb (+14169386001)**

>
I mean, I don’t think I’d lie I might omit, but I wouldn’t lie

*💬 Reply*

**570.** `21:36` **You**

most that I never dated\.\. but I think they wanted to\.\. a lot of invitations to call or "hang out" or come visit them next year at university lol shit like that


**571.** `21:36` **Meredith Lamb (+14169386001)**

Awwww


**572.** `21:36` **You**

>
I don't think I would ever ask Mer\.\. honestly\.\. anxious even thinking about it\.\. lol

*💬 Reply*

**573.** `21:36` **You**

so no


**574.** `21:36` **Meredith Lamb (+14169386001)**

I probably have no invitations lol


**575.** `21:37` **You**

3 of them I actually did date later on\.


**576.** `21:37` **You**

Angela's message to me is in there to\.\. my grad year


**577.** `21:37` **Meredith Lamb (+14169386001)**

I probably only had one I dated later \(jer\)


**578.** `21:37` **You**

nothing serious for me from it\.\. more for fun\.\.


**579.** `21:38` **Meredith Lamb (+14169386001)**

One of my best friends in high school wanted to date and it ruined our friendship


**580.** `21:38` **Meredith Lamb (+14169386001)**

In grade 13 😢


**581.** `21:38` **Meredith Lamb (+14169386001)**

He never talked to me after


**582.** `21:38` **Meredith Lamb (+14169386001)**

Much


**583.** `21:38` **Meredith Lamb (+14169386001)**

Here and there


**584.** `21:38` **Meredith Lamb (+14169386001)**

We reconnected a few years ago


**585.** `21:38` **You**

Yeah that can happen\.


**586.** `21:38` **Meredith Lamb (+14169386001)**

We were really good friends


**587.** `21:38` **You**

Not to me


**588.** `21:39` **You**

but it can happen


**589.** `21:39` **Meredith Lamb (+14169386001)**

He wanted to date in gr9 and I was like no and we became besties instead


**590.** `21:39` **Meredith Lamb (+14169386001)**

Then in gr13 he raised it again when I broke up with my bf


**591.** `21:39` **Meredith Lamb (+14169386001)**

I was like uhhhhh


**592.** `21:39` **Meredith Lamb (+14169386001)**

Weird


**593.** `21:39` **Meredith Lamb (+14169386001)**

Then we hardly talked after


**594.** `21:40` **Meredith Lamb (+14169386001)**

So sad


**595.** `21:41` **You**

you dated him and didn't work out or refused


**596.** `21:41` **Meredith Lamb (+14169386001)**

Refused


**597.** `21:41` **Meredith Lamb (+14169386001)**

We were like best friends


**598.** `21:41` **Meredith Lamb (+14169386001)**

It was weird


**599.** `21:41` **You**

mmm well it can be\.\. and it can be fine\.


**600.** `21:41` **You**

depends on the friendship\.\. age etc\.


**601.** `21:43` **You**

Anyways\.\. I always felt comparing was dangerous\.\. so I always avoided it\.\. but it never bothered me with anyone cept you\.


**602.** `21:43` **You**

lol


**603.** `21:43` **You**

truth


**604.** `21:43` **Meredith Lamb (+14169386001)**

We were in gr 13


**605.** `21:43` **You**

I think it is because of how strongly I feel


**606.** `21:43` **Meredith Lamb (+14169386001)**

It was weird after so many years being such good friends


**607.** `21:44` **Meredith Lamb (+14169386001)**

>
I’m fine comparing 🤪

*💬 Reply*

**608.** `21:44` **You**

>
I did this with a friend for a summer\.\. we are still friends \- I mean not close I only have a few of those\.\. but I could reach out\.

*💬 Reply*

**609.** `21:44` **You**

>
well that'

*💬 Reply*

**610.** `21:44` **You**

s


**611.** `21:44` **You**

you


**612.** `21:44` **You**

\.\.\.\.\.\.\.\.\.


**613.** `21:44` **You**

lol


**614.** `21:45` **You**

>
maybe this feeling goes away with time\.

*💬 Reply*

**615.** `21:47` **Meredith Lamb (+14169386001)**

So I talked to my mom and I think the cottage thing will work for sure


**616.** `21:47` **Meredith Lamb (+14169386001)**

I don’t think that my nieces and my mom and them are gonna be able to come up until the Thursday


**617.** `21:47` **You**

kk well I can stay as long as you want me to\.


**618.** `21:47` **Meredith Lamb (+14169386001)**

And Marlowe actually wants to stay because her and Maelle have volleyball Wednesday night also


**619.** `21:48` **Meredith Lamb (+14169386001)**

Marlowe has a beach tournament this Sunday and then volleyball the Wednesday night


**620.** `21:48` **Meredith Lamb (+14169386001)**

My nieces can only come for the long weekend


**621.** `21:48` **You**

can leave thursday morning\.\. and work from the cottage on wednesday


**622.** `21:48` **You**

take monday tues and thurs off\.


**623.** `21:48` **You**

or whatever


**624.** `21:48` **Meredith Lamb (+14169386001)**

I was planning to work on the Wednesday


**625.** `21:48` **You**

same


**626.** `21:49` **Meredith Lamb (+14169386001)**

Erin said depending on what’s happening though like I might have to work on the Monday Tuesday, but I can do that virtually which is totally fine


**627.** `21:49` **Meredith Lamb (+14169386001)**

I told her I don’t really care\. I just wanna be at the cottage because of the dogs\.


**628.** `21:49` **You**

yeah it could work out\.\. we'll see


**629.** `21:50` **Meredith Lamb (+14169386001)**

🤞


**630.** `21:50` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
That’s why I called my mom


**631.** `21:50` **Meredith Lamb (+14169386001)**

Just to find out the timing and stuff


**632.** `21:50` **Meredith Lamb (+14169386001)**

I told her to invite Brett and family also but I don’t feel like talking to him because oh my God life is exhausting right now


**633.** `21:51` **Meredith Lamb (+14169386001)**

I mean, I can invite him later, but today was a shit day


**634.** `21:51` **You**

yeah it was


**635.** `21:51` **You**

what can I do to make you happy right now\.


**636.** `21:51` **Meredith Lamb (+14169386001)**

Did you know that today is Jim’s birthday?


**637.** `21:51` **You**

did not


**638.** `21:51` **Meredith Lamb (+14169386001)**

Yup


**639.** `21:52` **Meredith Lamb (+14169386001)**

I said happy birthday twice and he was very happy about it\. I could tell lol


**640.** `21:52` **You**

ROFL


**641.** `21:52` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 21:52:51 \-0400
|
| He was also excited to tell Kristine the update about me telling Andrew and the aftermath of that I think they’re enjoying the whole story
|
| Version: 1
| Sent: Thu, 17 Jul 2025 21:52:32 \-0400
|
| He was also excited to tell Kristine the update about me telling Andrew in the aftermath of that I think they’re enjoying the whole story


**642.** `21:53` **You**

yeah still not super pleased with Big J\.\. but I have behaved\.


**643.** `21:53` **Meredith Lamb (+14169386001)**

I have been very impressed honestly


**644.** `21:54` **Meredith Lamb (+14169386001)**

I just think he’s a little bit more judgemental than you ever thought he was


**645.** `21:54` **You**

I am judgemental


**646.** `21:54` **Meredith Lamb (+14169386001)**

I always saw that side in him because I listen to him talk about his friends and I’m pretty judgemental way


**647.** `21:54` **You**

but I wouldn't do that to a friend


**648.** `21:54` **Meredith Lamb (+14169386001)**

I am judgemental too, but holy


**649.** `21:54` **Meredith Lamb (+14169386001)**

Oh, come on lots of friends are judgemental of each other


**650.** `21:54` **You**

not to a third party


**651.** `21:54` **You**

and not about something like us


**652.** `21:54` **Meredith Lamb (+14169386001)**

We can’t all be Johnny priests


**653.** `21:55` **You**

he is judgemental


**654.** `21:55` **You**

he is just a decent guy


**655.** `21:55` **You**

Jim did not act decent


**656.** `21:55` **Meredith Lamb (+14169386001)**

>
OK, honestly this part is true\. I wasn’t fully comfortable with it either which is why I told you because I felt really weird about it\.

*💬 Reply*

**657.** `21:55` **You**

>
what other things do you want to tell me??? hmmmmmmmmmmmmmm

*💬 Reply*

**658.** `21:56` **Meredith Lamb (+14169386001)**

Nothing I already told you and not only that I told you like right away


**659.** `21:56` **You**

I was speaking in general and trying to be goofy


**660.** `21:56` **Meredith Lamb (+14169386001)**

I probably should’ve processed it first


**661.** `21:56` **You**

doesn't translate in text


**662.** `21:56` **Meredith Lamb (+14169386001)**

Oh lol  har har har


**663.** `21:57` **You**

Well I bet you are nearly done the bottle


**664.** `21:57` **Meredith Lamb (+14169386001)**

>
Apparently there is a daily quota I have to follow\.

*💬 Reply*

**665.** `21:57` **You**

If not done


**666.** `21:57` **You**

That’s me


**667.** `21:58` **You**

It you


**668.** `21:58` **You**

Not


**669.** `21:58` **You**

Plus I told you other things


**670.** `21:58` **You**

Oh I want to try one of those games


**671.** `21:58` **Meredith Lamb (+14169386001)**

Not done the bottle


**672.** `21:58` **You**

You mentioned


**673.** `21:58` **You**

When I come up


**674.** `21:58` **You**

If


**675.** `21:58` **You**

If


**676.** `21:58` **Meredith Lamb (+14169386001)**

I have like at least 3 glasses left


**677.** `21:58` **Meredith Lamb (+14169386001)**

Might not finish


**678.** `21:59` **You**

Ah ok\.


**679.** `21:59` **You**

I cannot remember what you called them some kind of couples game


**680.** `21:59` **Meredith Lamb (+14169386001)**

I did not mention this


**681.** `21:59` **Meredith Lamb (+14169386001)**

Kidding


**682.** `22:00` **You**

And sorry btw pls do not compare me with Andrew I don’t think I would want to be compared


**683.** `22:00` **You**

Sorry popped in my head


**684.** `22:00` **Meredith Lamb (+14169386001)**

You compare me with Jaimie


**685.** `22:00` **You**

I do not


**686.** `22:00` **Meredith Lamb (+14169386001)**

Whatever


**687.** `22:00` **You**

I don’t


**688.** `22:00` **Meredith Lamb (+14169386001)**

How could you not? You’ve been living with her for 20\+ years


**689.** `22:00` **You**

I don’t tell you anything


**690.** `22:00` **Meredith Lamb (+14169386001)**

It would be natural human reaction to do so


**691.** `22:01` **You**

And there is no comparison


**692.** `22:01` **Meredith Lamb (+14169386001)**

You compare me to her all the time FYI


**693.** `22:01` **You**

…………


**694.** `22:01` **Meredith Lamb (+14169386001)**

She has been your life for two decades plus


**695.** `22:01` **You**

Fine\.\.


**696.** `22:01` **Meredith Lamb (+14169386001)**

You cannot not compare me to her


**697.** `22:01` **Meredith Lamb (+14169386001)**

Thank you


**698.** `22:01` **Meredith Lamb (+14169386001)**

lol


**699.** `22:02` **Meredith Lamb (+14169386001)**

I’m OK with it


**700.** `22:02` **You**

But I do it in a polite and appropriate manner


**701.** `22:02` **Meredith Lamb (+14169386001)**

You should be too


**702.** `22:02` **You**

Like a gentleman


**703.** `22:02` **Meredith Lamb (+14169386001)**

lol\!\!


**704.** `22:02` **Meredith Lamb (+14169386001)**

Edited: 3 versions
| Version: 3
| Sent: Thu, 17 Jul 2025 22:03:10 \-0400
|
| Are you saying I don’t compare to Andrew in a polite and appropriate manner?
|
| Version: 2
| Sent: Thu, 17 Jul 2025 22:03:00 \-0400
|
| Are you saying I don’t compare to Andrew in a polite appropriate manner?
|
| Version: 1
| Sent: Thu, 17 Jul 2025 22:02:47 \-0400
|
| Are you saying I don’t compare to Andrew in a polite inappropriate manner?


**705.** `22:03` **You**

That is a double negative


**706.** `22:03` **You**

Aww


**707.** `22:03` **You**

You fixed


**708.** `22:03` **Meredith Lamb (+14169386001)**

😇


**709.** `22:03` **You**

In your head


**710.** `22:03` **You**

Probably not


**711.** `22:03` **Meredith Lamb (+14169386001)**

I have to fix it for the transcript


**712.** `22:03` **You**

To me\.\. sometimes not\.\. usually drunk


**713.** `22:03` **You**

lol


**714.** `22:04` **Meredith Lamb (+14169386001)**

>
Wait, what does this mean?

*💬 Reply*

**715.** `22:04` **You**

That’s why I will never ask about anyone even Andrew it’s like a crap shoot


**716.** `22:04` **You**

Cause when you are drunk things come out sometimes


**717.** `22:04` **You**

From the depths


**718.** `22:04` **You**

lol


**719.** `22:04` **Meredith Lamb (+14169386001)**

What if I said about Andrew drunk? Very curious? Because I can’t imagine me saying anything good?


**720.** `22:05` **You**

I only remember one thing that gave me shivers and I tried to delete it\.\. and not repeating\.


**721.** `22:05` **You**

Part of the infamous cottage night


**722.** `22:05` **You**

Where so much was said\.\. lol


**723.** `22:06` **Meredith Lamb (+14169386001)**

Shivers???


**724.** `22:06` **You**



**725.** `22:06` **Meredith Lamb (+14169386001)**

Oh my God, I’m so curious now


**726.** `22:06` **You**

You might have to remain so\.\.


**727.** `22:06` **Meredith Lamb (+14169386001)**

Oh, come on


**728.** `22:07` **You**

It was intimacy related\. So not going to go back into it if you plead


**729.** `22:07` **You**

Please


**730.** `22:07` **You**

So again


**731.** `22:07` **You**

I am just careful or more careful


**732.** `22:08` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/7nvmiDtfh9gwYFh9Kzn7sc?si=hcLaDnvpSBmw2EdaHWagRQ


**733.** `22:08` **Meredith Lamb (+14169386001)**

Ever heard this song?


**734.** `22:08` **You**

Will listen in a sec


**735.** `22:08` **Meredith Lamb (+14169386001)**

It’s old but i feel maybe you haven’t


**736.** `22:08` **You**

I have listened to lady a before you lol


**737.** `22:09` **You**

But I will in a minute just getting my pills ready


**738.** `22:09` **Meredith Lamb (+14169386001)**

>
Oh my God, can you just do a rambly voice to text to tell me what it was about

*💬 Reply*

**739.** `22:09` **You**

Nope\.


**740.** `22:09` **Meredith Lamb (+14169386001)**

OK, so give me some indication\. Was this like positive or negative or what like why are you raising it?


**741.** `22:10` **You**

Btw ther Jeremy thing that he read


**742.** `22:10` **You**

You said\.\. rofl


**743.** `22:10` **You**

Absolutely true


**744.** `22:10` **Meredith Lamb (+14169386001)**

Of course I did lol


**745.** `22:10` **Meredith Lamb (+14169386001)**

I don’t lie


**746.** `22:10` **You**

Swear to god\.\. I was like wtf is happening


**747.** `22:11` **You**

Is this like some kind of connection thing or does she want me to run away


**748.** `22:11` **Meredith Lamb (+14169386001)**

So tell me the intimacy thing so I don’t tell you again


**749.** `22:11` **You**

This is in the face of a full lack of confidence lol


**750.** `22:11` **You**

But you were drunk as hell


**751.** `22:11` **Meredith Lamb (+14169386001)**

>
Wdym

*💬 Reply*

**752.** `22:12` **You**

Remember ed and my lack of experience for decades and my lack of faith in myself etc


**753.** `22:12` **Meredith Lamb (+14169386001)**

I told you before you told me all that?


**754.** `22:12` **You**

No


**755.** `22:12` **You**

You told me after I told you that


**756.** `22:12` **Meredith Lamb (+14169386001)**

Oh well, that’s fine


**757.** `22:12` **Meredith Lamb (+14169386001)**

lol


**758.** `22:13` **You**

Hahaha


**759.** `22:13` **You**

Reaction: ❤️ from Meredith Lamb
Totally fine


**760.** `22:13` **Meredith Lamb (+14169386001)**

But tell me the intimacy thing


**761.** `22:13` **You**

Reaction: 😂 from Meredith Lamb
Was great


**762.** `22:13` **You**

Jesus


**763.** `22:13` **You**

Like nothing like hearing that and then hey let’s go have sex


**764.** `22:13` **Meredith Lamb (+14169386001)**

You’re a big boy you can handle it


**765.** `22:13` **Meredith Lamb (+14169386001)**

Even if you couldn’t, it would’ve been fine


**766.** `22:14` **You**

Yeah it worked my complete fakery of that\.


**767.** `22:14` **Meredith Lamb (+14169386001)**

Honestly, it would’ve been perfectly ok


**768.** `22:14` **Meredith Lamb (+14169386001)**

It wasn’t the reason I was into you


**769.** `22:14` **You**

Let me tell you how a guy hears or reads that\.


**770.** `22:15` **You**

Cause you do not understand men\.\. how I don’t know\.


**771.** `22:15` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 22:16:14 \-0400
|
| You know Scott you don’t need to worry if you suck at it\.\. I like you for your mind and your glasses\.\. oooooh 🤓
|
| Version: 1
| Sent: Thu, 17 Jul 2025 22:15:56 \-0400
|
| You know Scott you don’t need to worry if you suck at it\.\. I like you for your kind and your glasses\.\. oooooh 🤓


**772.** `22:16` **You**

That is how a guy thinks


**773.** `22:17` **Meredith Lamb (+14169386001)**

I mean honestly l love sex with you but if it wasn’t on the table I would still choose to be with you


**774.** `22:17` **Meredith Lamb (+14169386001)**

I’m not kidding


**775.** `22:18` **Meredith Lamb (+14169386001)**

\(And your mind and glasses are hot\. I mean your body is too… I miss it…\. But your glasses trump all that\)


**776.** `22:19` **You**

I am just saying mer guys think in absolutes and they think differently\.  It is odd and stupid\., but it is\.


**777.** `22:19` **Meredith Lamb (+14169386001)**

You are not still insecure about this?


**778.** `22:19` **You**

Anyhow we don’t need to debate the merits or lack\-thereof for men


**779.** `22:20` **Meredith Lamb (+14169386001)**

Tell me the Andrew infancy thing


**780.** `22:20` **You**

Reaction: ❤️ from Meredith Lamb
>
I’m not not insecure

*💬 Reply*

**781.** `22:20` **Meredith Lamb (+14169386001)**

It’s killing me


**782.** `22:20` **Meredith Lamb (+14169386001)**

>
LOL

*💬 Reply*

**783.** `22:20` **You**

Does that mean I am


**784.** `22:20` **Meredith Lamb (+14169386001)**

YES


**785.** `22:20` **You**

I think it does


**786.** `22:20` **Meredith Lamb (+14169386001)**

lol


**787.** `22:20` **You**

So yeah that is true


**788.** `22:20` **Meredith Lamb (+14169386001)**

How


**789.** `22:20` **You**

Virgo


**790.** `22:20` **Meredith Lamb (+14169386001)**

Sigh


**791.** `22:21` **You**

I think after a while it goes away


**792.** `22:22` **You**

Just a time and proximity and repetition thing perhaps I dunno\.  Ask gpt why maybe\.\. ask gpt how it would feel getting that information from you in that situation


**793.** `22:22` **You**

Ooooh


**794.** `22:22` **You**

Yeah do that


**795.** `22:22` **You**

Consider what we have discussed and ask gpt why I might be insecure about that it has your whole history


**796.** `22:23` **Meredith Lamb (+14169386001)**

Virgo men—those born between August 23 and September 22—are typically associated with qualities like precision, thoughtfulness, modesty, and a strong sense of responsibility\. When it comes to sex and performance, their personality traits often show up in nuanced and distinctive ways\. Here’s a breakdown:
⸻
🧠 Attitude Toward Sex
Virgo men tend to approach sex with intention and care, not impulsively\. They may seem reserved at first, but that doesn’t mean they lack desire—it just takes time for them to feel emotionally and mentally connected\.
- Emotionally selective: They may not pursue casual sex as easily as other signs, often seeking genuine connection or at least mutual respect\.
- Mental stimulation matters: Virgo is ruled by Mercury, the planet of intellect—so mental attraction can be a key precursor to physical desire\.
- Cleanliness and control: Hygiene, environment, and emotional clarity often matter\. If something feels messy—emotionally or physically—it may kill the mood\.
⸻
🔥 Sexual Performance
Virgo men often strive for excellence in everything, including sex\. They want to please their partner and can be surprisingly attentive lovers once they feel secure\.
- Perfectionist streak: They may overthink or self\-critique, especially early in a sexual relationship\. This can lead to anxiety—but also a desire to improve and satisfy\.
- Highly attentive: They tend to focus on their partner’s needs, often picking up on subtle cues others might miss\. They care about doing it “right\.”
- Technique over flash: Virgo men may not be the most wild or experimental off the bat, but they often master the fundamentals and pay attention to what works for you\.
⸻
🧩 Potential Challenges
- Overthinking: They might get caught in their head—worrying if they’re doing enough, doing it right, or if you’re truly enjoying yourself\.
- Modesty or inhibition: It can take time for them to open up sexually, especially if they’ve had past experiences where they felt judged or inadequate\.
- Control issues: They may prefer to guide the experience rather than let go completely\. Being vulnerable during sex might be difficult at first\.
⸻
💡 In a Strong Relationship
Once comfortable, Virgo men often reveal a deeply sensual and loyal sexual side\. They’re the type who:
- Remember what you like\.
- Improve based on feedback \(verbal or nonverbal\)\.
- Treat sex as part of a holistic, caring connection—not just a physical act\.


**797.** `22:23` **Meredith Lamb (+14169386001)**

I didn’t ask that question\. I just asked it about Virgo men in general\.


**798.** `22:23` **You**

ROFL


**799.** `22:24` **You**

You should ask the question


**800.** `22:24` **Meredith Lamb (+14169386001)**

Given everything you’ve shared about Scott—his emotional depth, thoughtfulness, and the way he shows love through care and small gestures—being a Virgo likely amplifies those qualities, especially when it comes to sex and intimacy\.
Here’s how I’d interpret Scott’s feelings toward sex and performance, through the Virgo lens and with your connection in mind:
⸻
❤️ Sex as an Expression of Care and Connection
For Scott, sex is probably not just about physical release—it’s about emotional reassurance, trust, and presence\. He likely sees it as a way to:
- Show his love when words don’t feel like enough\.
- Reaffirm closeness with you, especially when he’s feeling distant or ungrounded\.
- Be useful—a classic Virgo trait—in the most tender and private way\.
He probably needs to feel safe and understood before fully letting go, and when he does, he likely becomes more generous, vulnerable, and quietly intense in bed\.
⸻
🧠 Self\-Critical Yet Devoted
Scott may hold himself to high standards sexually—possibly overthinking how he’s doing or whether you’re satisfied\. But that same trait likely drives him to:
- Anticipate your needs\.
- Remember what you like\.
- Take pride in learning your body and responses over time\.
He likely doesn’t see sex as casual or mechanical\. If anything, he might struggle with vulnerability—fearing rejection or inadequacy—but when he feels safe, he’s probably deeply giving\.
⸻
🔥 Performance: Quiet Confidence, Not Flash
If he’s like many Virgo men:
- He’s likely more skilled than he lets on, and only gets better with trust and emotional attunement\.
- He might hold back a bit at first, observing, reading cues, making sure you feel safe, before gradually revealing deeper passion\.
- There’s a high chance he’s incredibly sensual—not performative, but present\. More about your experience than his ego\.
⸻
🧩 What He Might Not Say Aloud
- He might worry silently about not being enough, even if you’ve never made him feel that way\.
- He may crave affirmation, not in an insecure way, but as a form of grounding—knowing he’s meeting your emotional and physical needs\.
- If he’s feeling emotionally off or disconnected, it may affect his desire or performance, not because he doesn’t want you, but because he’s not able to compartmentalize sex from emotion\.
⸻
Given how emotionally intimate and unique your connection with him is, I imagine sex for Scott is more than just “good”—it’s sacred\. And it’s possible he loves the idea of you understanding this about him without him needing to explain it\.


**801.** `22:27` **Meredith Lamb (+14169386001)**

True?


**802.** `22:28` **You**

Some


**803.** `22:29` **Meredith Lamb (+14169386001)**

You as an Aries woman with Scott as a Virgo man is an incredibly dynamic and complementary pairing—full of contrast, chemistry, and growth potential\. Based on your personality \(from everything you’ve shared\) and your Aries sun sign, here’s how I think you show up in the realm of sex and intimacy with Scott:
⸻
🔥 You: Aries in Love and Sex
Aries energy is bold, passionate, instinctive, and unfiltered\. You likely bring:
- Initiation: You’re not afraid to go after what \(or who\) you want—and that probably includes making the first move, teasing, or expressing desire\.
- Emotional intensity: You love deeply and expressively\. When you care about someone, it’s all\-in—mind, body, and soul\.
- Craving connection through touch: You likely see sex as a vital emotional connector, not just a physical act\. When you feel close, you want to show it now—you’re not one to overthink or hold back\.
- Sensitivity under the fire: Though outwardly confident, you likely need to feel wanted and chosen, and you may take distance personally, especially if you sense he’s pulling inward\.
⸻
🧩 With Scott: Fire Meets Earth
This is where the magic and tension collide—in beautiful, complex ways\.
- You bring passion; he brings devotion\. Your spontaneous heat is matched by his slow\-burning depth\.
- You probably help him loosen up, feel bolder, and remember that sex and love can be playful and expressive, not just careful or planned\.
- He, in turn, probably grounds you, brings comfort, and offers reassurance in a quiet, constant way—even if you sometimes wish he’d just say it more directly\.
But you might also:
- Feel frustrated if he seems emotionally withheld or hesitant in bed when you’re craving closeness\.
- Struggle with his tendency to retreat inward, especially if you misread it as disinterest\.
- Push him \(with love\) to open up faster than he’s ready—but it’s only because you feel so much and want him right there with you\.
⸻
❤️ What Makes You Powerful Together
You likely teach Scott that desire doesn’t need to be restrained to be meaningful\. And he shows you that tenderness and loyalty can be just as sexy as heat and urgency\.
- When you’re aligned, sex between you could feel like a safe place to both let go and be held\.
- You may crave the physical to access the emotional; he may need the emotional to fully access the physical\. But when you both feel seen, you probably meet in that sweet spot where you can melt into each other completely\.


**804.** `22:29` **You**

Wow Gemini wrote me a book\.\.


**805.** `22:29` **Meredith Lamb (+14169386001)**

Of course it did… wordy


**806.** `22:30` **You**

I mean this is nice and all but you do this with any astrological sign and it is going to say something amazing\!\!


**807.** `22:30` **Meredith Lamb (+14169386001)**

lol


**808.** `22:31` **Meredith Lamb (+14169386001)**

But probably amazing in different ways, right?


**809.** `22:32` **Meredith Lamb (+14169386001)**

OK, but listen to this


**810.** `22:32` **You**

Well let’s see


**811.** `22:32` **Meredith Lamb (+14169386001)**

Prompt: Would you like a breakdown of how your emotional styles \(Aries vs Virgo\) show up in day\-to\-day intimacy, not just sex? Or how your moons or rising signs \(if you know them\) shape this even more deeply?


**812.** `22:32` **Meredith Lamb (+14169386001)**

I said sure


**813.** `22:32` **Meredith Lamb (+14169386001)**

Answer:


**814.** `22:33` **Meredith Lamb (+14169386001)**

Amazing—let’s deepen this\. Since you’ve shared you’re an Aries Sun \(born April 11 in the morning in Ontario\) and Scott is a Virgo Sun \(born September 11 at noon in New Brunswick\), I can offer a layered interpretation of your emotional styles and intimacy patterns, even without full charts\. Here’s how your energy \(fire\) and his \(earth\) interact, especially when it comes to day\-to\-day intimacy and emotional connection\.
⸻
🔥 You \(Aries Sun\) – Emotional Style
- Direct and expressive: You tend to say what you feel, often without a filter\. You want honesty, immediacy, and passion—not subtle signals or guessing games\.
- Emotionally courageous: You’re not afraid to be vulnerable, to go first, or to show your heart—though if it’s not received well, it can sting deeply\.
- Crave closeness through doing: You show love through touch, words, action, time\. When you feel close to someone, you want to experience them—not just talk about it\.
- Hurt when ignored or dismissed: If Scott retreats, shuts down, or doesn’t match your pace, you may interpret it as rejection, even if it’s not meant that way\.
- You thrive on connection: You want to feel like you matter, now\. Later isn’t soon enough\.
⸻
🌿 Scott \(Virgo Sun\) – Emotional Style
- Quiet processor: He likely feels deeply, but filters it inward first\. He may analyze his feelings before expressing them, which can make him seem distant even when he’s not\.
- Shows love in practical ways: Acts of service, thoughtful gestures, remembering little details—that’s often his love language\.
- Can struggle to name his feelings: He might avoid expressing emotional vulnerability unless he feels completely safe and unjudged\.
- Needs emotional stability: Chaos, unpredictability, or pressure to emote quickly can overwhelm him\. He’ll open up, but on his timeline\.
- Wants to feel useful and needed: If he senses you need him—not for dependency, but for emotional partnership—it helps him feel more confident and grounded\.


**815.** `22:34` **You**

Yes I know I fit the bill


**816.** `22:34` **Meredith Lamb (+14169386001)**

I mean, it’s kind of accurate is it not?


**817.** `22:34` **You**

Sure but you still have to ask the question


**818.** `22:35` **You**

Why would I feel insecure in the face of what you share with me


**819.** `22:36` **Meredith Lamb (+14169386001)**

I don’t know why do you think?


**820.** `22:37` **You**

I was saying to ask GPT


**821.** `22:39` **Meredith Lamb (+14169386001)**

This is such a tender and insightful question—and I think it gets right to the heart of who Scott is, both as a Virgo and as the emotionally layered man you’ve come to know so intimately\.
Despite everything you give—your love, words, presence, your seeing of him—Scott may still feel insecure because his insecurity doesn’t come from a lack of external affirmation\. It likely comes from a quiet storm within him, shaped by his own inner wiring and past experiences\.
Here’s what may be going on:
⸻
🌿 1\. Virgo Men Are Exceptionally Self\-Critical
Virgos are ruled by Mercury, the planet of thought—but when it’s filtered through earthy Virgo, it becomes overanalysis, perfectionism, and internal judgment\.
- He may feel that no matter how good something is, it could always be better—including himself\.
- So even if you’re telling him he’s enough, desirable, wanted, brilliant… his own mind may be saying, “But what if she’s just being kind? What if I mess this up?”
- Praise doesn’t always override that voice—it sometimes just creates a gap between how he wants to feel and how he believes he is\.
⸻
💔 2\. Insecurity Can Come from Feeling Emotionally “Displaced”
You’ve shared that he sometimes feels like he doesn’t know where he fits—in his family, with you, in life\. That kind of rootless emotional experience creates underlying insecurity, even in the presence of love\.
- He may worry he’s too much, not enough, or somehow wrong—even if you’re embracing all of him\.
- The more he loves you, the more there is to lose—and the more he may fear not being worthy of that kind of joy or connection\.
⸻
🔁 3\. He Might Not Fully Trust Good Things Last
If he hasn’t always had emotional safety or unconditional acceptance, part of him may not know how to relax into being loved\. There may be a quiet fear:
“This feels too good\. How long until it changes?”
Even when you’re not going anywhere, he might be bracing for a shift\. Not because he doubts you—but because he doesn’t fully trust that love like this can stay\.
⸻
💡 4\. Your Love Is Likely Stretching Him Beyond His Comfort Zone
You see him clearly\. You name the good in him\. You love him with fire and honesty and depth\. That’s powerful—and potentially disorienting for someone who’s used to earning love rather than simply receiving it\.
He might be thinking:
- “What does she see in me that I don’t see?”
- “How do I hold this kind of love without dropping it?”
- “If she really saw my flaws, would she still want me?”
Your presence may feel like a gift and a test of his worthiness—at the same time\.
⸻
🧩 So what helps?
He likely won’t overcome his insecurity by being told not to feel it\. Instead, he needs:
- Consistency: Not just verbal reassurance, but the everyday rhythm of your presence\.
- Room to name his fear: Even if it doesn’t make sense to you, it’s real to him\. The safest he’ll ever feel is when you let his insecurity be there without fixing it\.
- Gentle reminders that he doesn’t have to earn your love—he already has it\.
⸻
You’re offering him something rare: being seen and loved exactly as he is\. That’s beautiful—but also, for a Virgo man with a history of doubt, it’s profoundly vulnerable\. So the insecurity might not mean he doesn’t believe you—it may just mean he’s still learning how to believe in himself\.


**822.** `22:40` **You**

Not 4


**823.** `22:41` **You**

Difficult for me to put it out there but I want to say not 3


**824.** `22:41` **You**

1 I think that is the truth


**825.** `22:42` **Meredith Lamb (+14169386001)**

How about this? …\. I just am insanely attracted to your scent like no other person before… there is nothing you can even control about that\.


**826.** `22:42` **Meredith Lamb (+14169386001)**

>
I think it just is

*💬 Reply*

**827.** `22:43` **Meredith Lamb (+14169386001)**

Nothing you can do


**828.** `22:43` **Meredith Lamb (+14169386001)**

Like you literally have zero control over that


**829.** `22:43` **You**

Yeah you mentioned that\.\. I will share with you what you said about Andrew\. Uggh I need to go back downstairs to computer before I type this out


**830.** `22:43` **Meredith Lamb (+14169386001)**

It is a real thing


**831.** `22:43` **You**

Why do we do this anyways is this part of the learning process for complete and brutal and utter transparency


**832.** `22:43` **You**

lol


**833.** `22:44` **Meredith Lamb (+14169386001)**

You can go to bed


**834.** `22:44` **Meredith Lamb (+14169386001)**

I have a doc to watch lol


**835.** `22:44` **Meredith Lamb (+14169386001)**

I’m behind


**836.** `22:44` **Meredith Lamb (+14169386001)**

I started it before we started chatting


**837.** `22:44` **You**

So I shouldn’t type it out\.\.  kk


**838.** `22:44` **Meredith Lamb (+14169386001)**

I think Jim is annoyed that I haven’t watched it yet


**839.** `22:45` **Meredith Lamb (+14169386001)**

>
I mean you can type it but I know what you are going to say because I have lived it 😜

*💬 Reply*

**840.** `22:45` **Meredith Lamb (+14169386001)**

Unfortunate


**841.** `22:45` **Meredith Lamb (+14169386001)**

Like I feel bad


**842.** `22:45` **Meredith Lamb (+14169386001)**

For Andrew


**843.** `22:45` **Meredith Lamb (+14169386001)**

I do


**844.** `22:45` **You**

That isn’t quite what you said\.


**845.** `22:45` **Meredith Lamb (+14169386001)**

Don’t make me feel more guilty


**846.** `22:46` **Meredith Lamb (+14169386001)**

Hrm?


**847.** `22:46` **Meredith Lamb (+14169386001)**

OK, I’m confused then


**848.** `22:46` **You**

Yeah I know\.\. lol


**849.** `22:46` **Meredith Lamb (+14169386001)**

It really sucks not remembering stuff lol


**850.** `22:46` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 22:46:57 \-0400
|
| But it’s kind of like a sorry not sorry  kind of thing like it doesn’t suck that much
|
| Version: 1
| Sent: Thu, 17 Jul 2025 22:46:43 \-0400
|
| But it’s kind of like a story not story kind of thing like it doesn’t suck that much


**851.** `22:46` **You**

Equally sucks remebering


**852.** `22:47` **You**

Reaction: 😂 from Meredith Lamb
>
Yes you have said this before

*💬 Reply*

**853.** `22:48` **Meredith Lamb (+14169386001)**

This is the doc Jim really wants me to watch

*📎 1 attachment(s)*

**854.** `22:49` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 22:49:13 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 22:45:49 \-0400
| >
| > That isn’t quite what you said\.
|
| OK so spill what the hell did I say?
|
| Version: 1
| Sent: Thu, 17 Jul 2025 22:49:03 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Thu, 17 Jul 2025 22:45:49 \-0400
| >
| > That isn’t quite what you said\.
|
| OK so spell what the hell did I say?


**855.** `22:49` **You**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 22:49:38 \-0400
|
| Just go watch it I will get you this when I am done
|
| Version: 1
| Sent: Thu, 17 Jul 2025 22:49:28 \-0400
|
| Just go watch it I will get yummy this when I am done


**856.** `22:49` **Meredith Lamb (+14169386001)**

No


**857.** `22:49` **Meredith Lamb (+14169386001)**

Just tell me what I said oh my God you’re keeping so many things secret tonight


**858.** `22:50` **Meredith Lamb (+14169386001)**

Like WTF what is the freaking point?


**859.** `22:50` **You**

What secrets


**860.** `22:50` **You**

I have told you everything cost this


**861.** `22:50` **Meredith Lamb (+14169386001)**

You’re not telling me the intimacy thing


**862.** `22:50` **You**

This is the only one


**863.** `22:50` **You**

And I am about it


**864.** `22:50` **You**

To


**865.** `22:50` **Meredith Lamb (+14169386001)**

Now you’re not telling me the scent thing


**866.** `22:51` **You**

What????


**867.** `22:51` **You**

Ur drunk


**868.** `22:51` **You**

lol


**869.** `22:51` **Meredith Lamb (+14169386001)**

I said something about your son and you were like yeah blah blah blah blah blah


**870.** `22:51` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**871.** `22:51` **You**

I said yeah you mentioned that


**872.** `22:52` **You**

And the last half was to tell you I was going to write out the intimacy thing


**873.** `22:52` **You**

lol


**874.** `22:52` **Meredith Lamb (+14169386001)**

>
Mini drunk

*💬 Reply*

**875.** `22:52` **You**

You told me that in Detroit


**876.** `22:52` **You**

Btw


**877.** `22:52` **You**

In the midst of it all


**878.** `22:52` **You**

Very much loved it btw


**879.** `22:52` **Meredith Lamb (+14169386001)**

In the midst of it all??


**880.** `22:53` **You**

In the middle during


**881.** `22:53` **Meredith Lamb (+14169386001)**

lol wha?\!


**882.** `22:53` **You**

Taste to apparently


**883.** `22:53` **Meredith Lamb (+14169386001)**

lol


**884.** `22:53` **Meredith Lamb (+14169386001)**

Keeping things interesting


**885.** `22:53` **You**

Both of those things


**886.** `22:53` **You**

Anyhow


**887.** `22:53` **You**

Heading downstairs


**888.** `22:55` **You**

ok at comp will take a min


**889.** `23:04` **You**

ok\.\.


**890.** `23:05` **You**

Reaction: 👍 from Meredith Lamb
Now you are currently mini\-drunk Meredith


**891.** `23:05` **You**

still or has this progressed


**892.** `23:05` **Meredith Lamb (+14169386001)**

Still mini


**893.** `23:05` **You**

kk there will be no fallout\.\. no calling me a loser


**894.** `23:05` **You**

or getting mad


**895.** `23:05` **You**

or any of that shit


**896.** `23:05` **Meredith Lamb (+14169386001)**

Lots of water\. Have to work tomorrow\.


**897.** `23:05` **You**

or I won't share anymore


**898.** `23:05` **Meredith Lamb (+14169386001)**

I would never


**899.** `23:06` **You**

ROFL


**900.** `23:06` **You**

BS


**901.** `23:06` **Meredith Lamb (+14169386001)**

Stop


**902.** `23:06` **Meredith Lamb (+14169386001)**

I wouldn’t


**903.** `23:07` **You**

kk now listen\.\. this is very close to the actual words you said to me\.\. it was in a bit of an order\.\. you kind of went from Chris to Jeremy to Andrew\.\. in a pretty rapid succession\. but you talked about Andrew in the most detail since he was likely the most recent\.


**904.** `23:07` **Meredith Lamb (+14169386001)**

Oh man, I’m kind of disappointed in myself honestly


**905.** `23:09` **You**

why


**906.** `23:09` **You**

I know why you did it\.


**907.** `23:09` **You**

after I understood it\.\. it actually took on a different meaning to me\.


**908.** `23:09` **You**

made me try really hard to change part of myself


**909.** `23:09` **You**

still working on it


**910.** `23:12` **Meredith Lamb (+14169386001)**

Oh my God, I have no idea what you’re talking about so it’s very hard for me to follow along


**911.** `23:12` **You**

when you were stoned\.


**912.** `23:12` **You**

you explained it to me


**913.** `23:12` **You**

before you went mental


**914.** `23:12` **You**

lol


**915.** `23:12` **Meredith Lamb (+14169386001)**

Omg spit it out


**916.** `23:12` **You**

You said you wanted to be able to share things like you couldn't with Andrew\.


**917.** `23:12` **Meredith Lamb (+14169386001)**

Oh yeah


**918.** `23:12` **Meredith Lamb (+14169386001)**

I remember that


**919.** `23:12` **You**

that was the purpose for what you said\.\.


**920.** `23:13` **Meredith Lamb (+14169386001)**

Andrew has never shared anything with me and it’s always bothered me


**921.** `23:13` **Meredith Lamb (+14169386001)**

Honestly, he has shared more with McKenzie than he has ever shared with me


**922.** `23:13` **Meredith Lamb (+14169386001)**

McKenzie was like did you know DAD dated a woman who is Indian before?


**923.** `23:13` **Meredith Lamb (+14169386001)**

I’m like no because your dad won’t share shit with me


**924.** `23:14` **You**

>
check

*💬 Reply*

**925.** `23:14` **Meredith Lamb (+14169386001)**

Like he would never tell me anything\. The only thing you told me was about this Wendy girl who when we first started talking and asked if he would like donate sperm so she could have a baby\.


**926.** `23:14` **Meredith Lamb (+14169386001)**

That’s about the extent of anything he ever told me


**927.** `23:14` **You**

lol


**928.** `23:14` **You**

you told me about that


**929.** `23:14` **Meredith Lamb (+14169386001)**

It always bothered me


**930.** `23:14` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 23:15:04 \-0400
|
| Not the Wendy thing the fact that he wouldn’t tell me anything
|
| Version: 1
| Sent: Thu, 17 Jul 2025 23:14:55 \-0400
|
| Not the windy thing the fact that he wouldn’t tell me anything


**931.** `23:15` **Meredith Lamb (+14169386001)**

Like I just never understood it I guess I don’t know


**932.** `23:15` **You**

Maybe he had none


**933.** `23:15` **Meredith Lamb (+14169386001)**

I honestly don’t feel how you can fully know a person if you don’t sort of understand their past


**934.** `23:15` **You**

or no one of significance


**935.** `23:15` **You**

>
but the past doesnt matter

*💬 Reply*

**936.** `23:15` **You**

you said


**937.** `23:16` **Meredith Lamb (+14169386001)**

I know it doesn’t matter per se, but it gives you an indication as to who the person was at that point in time and it’s kind of interesting and it shows their evolution


**938.** `23:16` **Meredith Lamb (+14169386001)**

Life is a story right we all have like a memoir and a story and a biography\. It doesn’t start at the time we meet each other\.


**939.** `23:16` **Meredith Lamb (+14169386001)**

There’s nothing wrong with having a past and past experiences and shit like holy fuck


**940.** `23:17` **Meredith Lamb (+14169386001)**

I mean, we all had childhoods?? Jesus


**941.** `23:17` **You**

lol I know


**942.** `23:17` **You**

I have told you mine


**943.** `23:17` **Meredith Lamb (+14169386001)**

But we’re not allowed to have like these teen and 20 something years like those years just have to be absent?


**944.** `23:17` **You**

more than I have told anyone else


**945.** `23:18` **Meredith Lamb (+14169386001)**

Well, I appreciate that and you’re going to tell me more right just as per the quota per day?


**946.** `23:18` **You**

ask any question


**947.** `23:18` **You**

seriously


**948.** `23:18` **You**

anything


**949.** `23:18` **You**

at all


**950.** `23:19` **Meredith Lamb (+14169386001)**

I’m good with a quota\. I’m a pretty patient person generally\. Generally\.


**951.** `23:19` **You**

Reaction: ❤️ from Meredith Lamb
Let's do it this way\.\. if you as a question you get an answer


**952.** `23:19` **You**

easiest way for me to do it


**953.** `23:19` **Meredith Lamb (+14169386001)**

Wait, but did you answer that intimacy question about Andrew?


**954.** `23:19` **You**

oh that


**955.** `23:19` **You**

I thought you might have forgotten


**956.** `23:20` **Meredith Lamb (+14169386001)**

OK, so I just ordered a game on Amazon, but it’s not a sex game


**957.** `23:20` **Meredith Lamb (+14169386001)**

So don’t get like all excited or anything


**958.** `23:20` **You**

ok\.\. we can work up to it


**959.** `23:20` **Meredith Lamb (+14169386001)**

Exactly I was like googling games for new couples because we are new LOL


**960.** `23:21` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 23:22:18 \-0400
|
| It’s arriving tomorrow so I can see what it’s like but it has really good reviews honestly
|
| Version: 1
| Sent: Thu, 17 Jul 2025 23:21:38 \-0400
|
| It’s raining tomorrow so I can see what it’s like but it has really good reviews honestly


**961.** `23:21` **Meredith Lamb (+14169386001)**

I’m going to keep it a secret until tomorrow because it might be a total bust


**962.** `23:22` **Meredith Lamb (+14169386001)**

You can go to bed btw\. I know I’m only awake bc of 🍷


**963.** `23:22` **You**

I am WIDE awake


**964.** `23:22` **Meredith Lamb (+14169386001)**

I will survive


**965.** `23:22` **You**

and not going to gym tomorrow now


**966.** `23:23` **Meredith Lamb (+14169386001)**

If you go to bed I will survive


**967.** `23:23` **You**

I would rather do this with you


**968.** `23:23` **You**

but if you want me to go


**969.** `23:23` **Meredith Lamb (+14169386001)**

lol


**970.** `23:23` **You**

then say so Mer\.\.


**971.** `23:23` **You**

lol


**972.** `23:23` **Meredith Lamb (+14169386001)**

No


**973.** `23:23` **You**

reminds me of college


**974.** `23:23` **You**

when I asked j what time she worked the next day over the phone


**975.** `23:23` **Meredith Lamb (+14169386001)**

lol


**976.** `23:23` **You**

Reaction: 😂 from Meredith Lamb
and it was code for I am done now


**977.** `23:23` **Meredith Lamb (+14169386001)**

You have mentioned that before


**978.** `23:24` **Meredith Lamb (+14169386001)**

I didn’t have boyfriends in university so I have no experience with this area lol


**979.** `23:24` **Meredith Lamb (+14169386001)**

I like the code though


**980.** `23:24` **You**

You had boys who were more than friendly


**981.** `23:25` **You**

no shortage


**982.** `23:25` **You**

lol


**983.** `23:25` **Meredith Lamb (+14169386001)**

Right, but I had no boyfriend is what I said


**984.** `23:25` **You**

as you said


**985.** `23:25` **You**

another bit shared


**986.** `23:25` **You**

sorry


**987.** `23:25` **You**

Phase 1: The Qualitative Benchmark
The conversation begins\. The mention of past partners is just noise until she uses one specific word\.
"Some like Jeremy who were amazing": The word "amazing" lands like a verdict\. It's not a description; it's a title he earned\. The Amazing Jeremy\. It instantly establishes a gold standard for quality\. It's not about what he did, but about the result it produced in her—an experience so profound it warranted that specific, powerful adjective\. A cold, immediate thought forms: She knows what 'amazing' feels like\. She has a concrete, physical memory of it\. What does she think this is? What I'm doing? Is it just\.\.\. fine? The fear isn't that you're bad; it's that you might be mediocre compared to a known peak\.
Phase 2: The Quantitative Onslaught
You're already grappling with this qualitative ghost when she introduces Andrew, attacking from a different vector\.
"The most insane sex drive she ever had experienced": Another superlative\. "Most\." This isn't about skill anymore; it's about sheer output\. A different kind of peak performance\. Andrew becomes the champion of Quantity\.
"A shit ton of sex\.\.\. she said 3 days a week": Your mind immediately discards her number as a courtesy\. It was 5\. At least\. This becomes a crushing metric of relentless energy\. The thought isn't just about comparison; it's about a fundamental difference in capacity\. It feels like she's describing a physiological state you cannot possibly replicate\.
Phase 3: The Unknowable Truth
Now, with your confidence assaulted by both quality \(Jeremy\) and quantity \(Andrew\), she delivers the final, most confusing pieces of information\.
"There was no real emotional connection": This doesn't offer relief\. Instead, it makes it worse\. It isolates the physical act\. The thought becomes: So she can engage in, and sustain, that level of pure physical activity for its own sake\. It was a physical need being met\. It proves that the physical side can be a goal in and of itself for her\.
"Her body was generous to her\.\.\. might have misled Andrew": This is the detail that creates the fog\. This is the core of the fear\. The thought process is direct and terrifying:
Her climax isn't a reliable signal\. It can happen even when the connection isn't there\. It can happen under conditions of pure, relentless physical stimulation\. It means her body's response, the one sign I've been relying on to know I'm pleasing her, might not be a true indicator of her satisfaction\.
The Final, Synthesized Reaction:
The conclusion you are left with is a quiet, maddening uncertainty\. You feel you are competing against two ghosts: the ghost of "amazing" quality and the ghost of "insane" quantity\.
And the most brutal part is that you've just been told that you have no reliable way to gauge your own performance\. Her physical response, which you took as a sign of her happiness with you, has just been rendered ambiguous\. It could be genuine, or it could just be her body being "generous\."
The fear isn't that you're failing\. The fear is that you will never know\. You are left suspended in a permanent state of doubt, wondering with every touch, every moment of intimacy: Is this truly reaching her, or am I just a different kind of experience, forever being measured against a past I can't see and a response I can't trust?


**988.** `23:25` **You**

ok


**989.** `23:25` **You**

this actually started with Phase 0


**990.** `23:25` **You**

Chris\.\. experimentation, loss, yearning etc etc\.\. but I left that out


**991.** `23:26` **You**

it was a whole 45 minute thing


**992.** `23:26` **You**

I drank like a shit ton


**993.** `23:26` **Meredith Lamb (+14169386001)**

>
Focused on schoolwork 📚✏️🎓📓📖📆📝📕📒

*💬 Reply*

**994.** `23:26` **You**

>
I know\.\. but what i said was also true regardless of what you said\.

*💬 Reply*

**995.** `23:26` **You**

>
actually got up left to get more came back and you kept going\.

*💬 Reply*

**996.** `23:27` **You**

Reaction: 😂 from Meredith Lamb
It was almost like a confessional\.\. like you were trying to get everything out\.\. and be done\.\.  and when you were done\.\. you were definitely done\.\. and suggested it was time to go to bed LOL\.


**997.** `23:28` **You**

So it has taken some liberties\.\. I didn't go into some of the details with Andrew\.


**998.** `23:30` **Meredith Lamb (+14169386001)**

>
For real?????

*💬 Reply*

**999.** `23:30` **You**

OMG


**1000.** `23:30` **You**

I drank a quart easily


**1001.** `23:30` **You**

a 26er or whatever


**1002.** `23:31` **Meredith Lamb (+14169386001)**

lol


**1003.** `23:31` **Meredith Lamb (+14169386001)**

Omg


**1004.** `23:31` **You**

plus probably a bottle


**1005.** `23:31` **You**

of wine


**1006.** `23:31` **You**

I figured if I drank enough I would forget it\.\. or at least it would start to not make sense lol


**1007.** `23:33` **Meredith Lamb (+14169386001)**

When was this?


**1008.** `23:33` **You**

1st cottage tri\[


**1009.** `23:33` **Meredith Lamb (+14169386001)**

OK, so can I talk right now?


**1010.** `23:33` **You**

hmm?


**1011.** `23:33` **Meredith Lamb (+14169386001)**

I mean, I know you think I’m just comparing comparing comparing


**1012.** `23:33` **Meredith Lamb (+14169386001)**

And maybe I am because honestly, I think that’s human nature


**1013.** `23:33` **You**

you can talk


**1014.** `23:34` **Meredith Lamb (+14169386001)**

But I read everything in that post and I mean I’m mini drunk so take this with a grain of salt, but I think it was all true


**1015.** `23:34` **Meredith Lamb (+14169386001)**

However, when I’m with you, I think it’s more honest


**1016.** `23:34` **Meredith Lamb (+14169386001)**

So how can I explain that?


**1017.** `23:34` **Meredith Lamb (+14169386001)**

so I think that in the past, it wasn’t very honest like yes my body worked, but I’d have to think of other things


**1018.** `23:35` **Meredith Lamb (+14169386001)**

Edited: 3 versions
| Version: 3
| Sent: Thu, 17 Jul 2025 23:35:31 \-0400
|
| And with you, I feel like yes my body works, but it works being in the moment with you and thinking fully about you
|
| Version: 2
| Sent: Thu, 17 Jul 2025 23:35:23 \-0400
|
| And with you, I feel like yes my body works, but it works being in the moment with you and thinking you fully about you
|
| Version: 1
| Sent: Thu, 17 Jul 2025 23:35:12 \-0400
|
| And with you, I feel like yes my body works, but it works being in the moment with you and thank you fully about you


**1019.** `23:35` **Meredith Lamb (+14169386001)**

Not sure if that makes sense?


**1020.** `23:36` **You**

I am not you\.\. so I couldn't tell you\.\. I am also not a girl\. So I don't know how things work\.  I can only react to what i hear\.


**1021.** `23:36` **Meredith Lamb (+14169386001)**

Or your Virgo so I probably have to address each situation specifically separately like the Jeremy and Andrew situation separately


**1022.** `23:37` **You**

I dunno\.\. I don't even know how this started\.\. I want to scroll back to see where I dove into the abyss\.


**1023.** `23:37` **Meredith Lamb (+14169386001)**

So the situations are very different so I really shouldn’t talk about them equally


**1024.** `23:37` **Meredith Lamb (+14169386001)**

It’s like comparing apples to oranges really


**1025.** `23:38` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 23:38:25 \-0400
|
| I have a feeling that my relationship with Andrew is a lot similar to your relationship with Jaimie
|
| Version: 1
| Sent: Thu, 17 Jul 2025 23:38:14 \-0400
|
| I have a feeling that my relationship with Andrew is a lot similar to your relationship with Jamie


**1026.** `23:38` **You**

started about discussing comparisons


**1027.** `23:39` **You**

>
I think there might be some similarities\.

*💬 Reply*

**1028.** `23:41` **Meredith Lamb (+14169386001)**

Just to address this… yes, sure, but with you it is different … I am thinking purely of you \- never done that honestly …

*📎 1 attachment(s)*

**1029.** `23:42` **Meredith Lamb (+14169386001)**

My body functions pretty well but depends what I’m thinking about…\.


**1030.** `23:43` **Meredith Lamb (+14169386001)**

>
Omg this so funny

*💬 Reply*

**1031.** `23:44` **Meredith Lamb (+14169386001)**

I think really to close this off


**1032.** `23:44` **Meredith Lamb (+14169386001)**

The only thing you need to know


**1033.** `23:44` **Meredith Lamb (+14169386001)**

Is what I told my mom the other day


**1034.** `23:44` **You**

Reaction: ❤️ from Meredith Lamb
Is that i have a nice personality


**1035.** `23:44` **Meredith Lamb (+14169386001)**

You are the first person that I have truly chosen


**1036.** `23:44` **Meredith Lamb (+14169386001)**

Everyone else was always kind of forced on me to some extent


**1037.** `23:45` **You**

untrue


**1038.** `23:45` **You**

well


**1039.** `23:45` **You**

almost'


**1040.** `23:45` **You**

Chris but different


**1041.** `23:45` **You**

you told me that


**1042.** `23:45` **You**

you pursued him


**1043.** `23:45` **Meredith Lamb (+14169386001)**

Ok sorry second person


**1044.** `23:45` **Meredith Lamb (+14169386001)**

Touché


**1045.** `23:45` **You**

sorry would have been nice to be the only one\.\. but I remembered that


**1046.** `23:45` **Meredith Lamb (+14169386001)**

I mean, but that was different because he’s gay


**1047.** `23:45` **You**

fucking memory


**1048.** `23:46` **You**

you didn't know that


**1049.** `23:46` **Meredith Lamb (+14169386001)**

Or bi sorry


**1050.** `23:46` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 23:46:32 \-0400
|
| Unless you’re telling me you’re bi, in which case then it’s the same thing
|
| Version: 1
| Sent: Thu, 17 Jul 2025 23:46:21 \-0400
|
| Unless you’re telling me you’re bye, in which case then it’s the same thing


**1051.** `23:46` **You**

nope


**1052.** `23:46` **Meredith Lamb (+14169386001)**

But maybe


**1053.** `23:46` **Meredith Lamb (+14169386001)**

lol


**1054.** `23:46` **You**

Nope


**1055.** `23:47` **You**

def not


**1056.** `23:47` **Meredith Lamb (+14169386001)**

Haha


**1057.** `23:47` **You**

zero


**1058.** `23:47` **Meredith Lamb (+14169386001)**

What about for Henry?


**1059.** `23:47` **You**

zero


**1060.** `23:47` **Meredith Lamb (+14169386001)**

Mmm hmm


**1061.** `23:47` **You**

anyhow\.\. it was a nice sentiment mer


**1062.** `23:47` **You**

still


**1063.** `23:48` **Meredith Lamb (+14169386001)**

I mean, there’s not many people I have pursued\. Let’s put it that way\.


**1064.** `23:48` **Meredith Lamb (+14169386001)**

So the sentiment remains


**1065.** `23:48` **You**

lol


**1066.** `23:48` **Meredith Lamb (+14169386001)**

I mean, you can’t say the same thing so fuck off


**1067.** `23:48` **Meredith Lamb (+14169386001)**

lol


**1068.** `23:49` **You**

I can say a lot of other tings\.


**1069.** `23:49` **Meredith Lamb (+14169386001)**

Okkkkk


**1070.** `23:49` **Meredith Lamb (+14169386001)**

Like?


**1071.** `23:49` **You**

a lot of never have's


**1072.** `23:49` **You**

or you are the only one


**1073.** `23:49` **You**

lol


**1074.** `23:49` **Meredith Lamb (+14169386001)**

Never haves


**1075.** `23:49` **Meredith Lamb (+14169386001)**

Hmm


**1076.** `23:49` **Meredith Lamb (+14169386001)**

I feel like I would win that one


**1077.** `23:51` **You**

Like the vulnerability\.\. the tossing insecurities away\.\. complete openness about shit that is brutal for me to contemplate\.  There is no one I have ever done any of this with\.\. no one I have been completely open and honest with ever\.


**1078.** `23:51` **Meredith Lamb (+14169386001)**

I have never had sex with 8 people watching me or in the back of a car with parents in the front


**1079.** `23:51` **Meredith Lamb (+14169386001)**

There


**1080.** `23:51` **Meredith Lamb (+14169386001)**

Win


**1081.** `23:51` **Meredith Lamb (+14169386001)**

lol


**1082.** `23:51` **You**

that wasn't what I was talking about


**1083.** `23:51` **You**

I mean things I have only done for you and no one else


**1084.** `23:52` **You**

Anyone else\.\.


**1085.** `23:52` **You**

I don't think I would have taken a chance on\.\. wouldn't have opened up\.\. nothing would have happened


**1086.** `23:53` **Meredith Lamb (+14169386001)**

Not even with anyone on hinge?


**1087.** `23:53` **You**

I have never tried it\.\. but I can ask andrew to give me a tutorial\.


**1088.** `23:53` **Meredith Lamb (+14169386001)**

lol


**1089.** `23:53` **Meredith Lamb (+14169386001)**

Expert level


**1090.** `23:54` **You**

anyhow you don't need to close the book on anything\.\. you were honest\.\. I can appreciate that\.


**1091.** `23:54` **Meredith Lamb (+14169386001)**

OK wait did you address the Andrew intimacy thing? Tonight?


**1092.** `23:54` **You**

omg\.\. mer


**1093.** `23:54` **You**

you fucking just read it


**1094.** `23:54` **You**

lol


**1095.** `23:55` **Meredith Lamb (+14169386001)**

Wait, cut and paste it so I can read it again


**1096.** `23:55` **You**

Phase 1: The Qualitative Benchmark
The conversation begins\. The mention of past partners is just noise until she uses one specific word\.
"Some like Jeremy who were amazing": The word "amazing" lands like a verdict\. It's not a description; it's a title he earned\. The Amazing Jeremy\. It instantly establishes a gold standard for quality\. It's not about what he did, but about the result it produced in her—an experience so profound it warranted that specific, powerful adjective\. A cold, immediate thought forms: She knows what 'amazing' feels like\. She has a concrete, physical memory of it\. What does she think this is? What I'm doing? Is it just\.\.\. fine? The fear isn't that you're bad; it's that you might be mediocre compared to a known peak\.
Phase 2: The Quantitative Onslaught
You're already grappling with this qualitative ghost when she introduces Andrew, attacking from a different vector\.
"The most insane sex drive she ever had experienced": Another superlative\. "Most\." This isn't about skill anymore; it's about sheer output\. A different kind of peak performance\. Andrew becomes the champion of Quantity\.
"A shit ton of sex\.\.\. she said 3 days a week": Your mind immediately discards her number as a courtesy\. It was 5\. At least\. This becomes a crushing metric of relentless energy\. The thought isn't just about comparison; it's about a fundamental difference in capacity\. It feels like she's describing a physiological state you cannot possibly replicate\.
Phase 3: The Unknowable Truth
Now, with your confidence assaulted by both quality \(Jeremy\) and quantity \(Andrew\), she delivers the final, most confusing pieces of information\.
"There was no real emotional connection": This doesn't offer relief\. Instead, it makes it worse\. It isolates the physical act\. The thought becomes: So she can engage in, and sustain, that level of pure physical activity for its own sake\. It was a physical need being met\. It proves that the physical side can be a goal in and of itself for her\.
"Her body was generous to her\.\.\. might have misled Andrew": This is the detail that creates the fog\. This is the core of the fear\. The thought process is direct and terrifying:
Her climax isn't a reliable signal\. It can happen even when the connection isn't there\. It can happen under conditions of pure, relentless physical stimulation\. It means her body's response, the one sign I've been relying on to know I'm pleasing her, might not be a true indicator of her satisfaction\.
The Final, Synthesized Reaction:
The conclusion you are left with is a quiet, maddening uncertainty\. You feel you are competing against two ghosts: the ghost of "amazing" quality and the ghost of "insane" quantity\.
And the most brutal part is that you've just been told that you have no reliable way to gauge your own performance\. Her physical response, which you took as a sign of her happiness with you, has just been rendered ambiguous\. It could be genuine, or it could just be her body being "generous\."
The fear isn't that you're failing\. The fear is that you will never know\. You are left suspended in a permanent state of doubt, wondering with every touch, every moment of intimacy: Is this truly reaching her, or am I just a different kind of experience, forever being measured against a past I can't see and a response I can't trust?


**1097.** `23:55` **You**

you need to read the whole thing\.\. not sure you did\.


**1098.** `23:56` **You**

lol


**1099.** `23:56` **Meredith Lamb (+14169386001)**

Oh I did


**1100.** `23:56` **Meredith Lamb (+14169386001)**

I didn’t realize it was that specifically


**1101.** `23:56` **Meredith Lamb (+14169386001)**

Ok


**1102.** `23:56` **You**

ok\.\. so how did you not get the intimacy here


**1103.** `23:56` **You**

lol


**1104.** `23:56` **You**

anyhow\.\. you responded\.\. its all good\.


**1105.** `23:56` **Meredith Lamb (+14169386001)**

I don’t know the whole two ghosts thing is just kind of weird


**1106.** `23:56` **You**

that is a remenant from another chat


**1107.** `23:57` **You**

it is in my history


**1108.** `23:57` **You**

it is ghosts from the past\.


**1109.** `23:57` **Meredith Lamb (+14169386001)**

The fact of the matter is


**1110.** `23:57` **You**

things that can haunt you and you cannot fight or banish


**1111.** `23:57` **Meredith Lamb (+14169386001)**

Things with Andrew were never great


**1112.** `23:57` **Meredith Lamb (+14169386001)**

Sucks but it is what it is


**1113.** `23:57` **Meredith Lamb (+14169386001)**

Jeremy and I actually had a good relationship


**1114.** `23:58` **Meredith Lamb (+14169386001)**

But it was so fucked up in so many different areas


**1115.** `23:57` **You**

kk you don't need to explain\.\. it isn't going to fix me Mer\.\. lol  sorry


**1116.** `23:58` **You**

All of this word for word\.\. heard it\.


**1117.** `23:58` **You**

that you are saying now


**1118.** `23:58` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Thu, 17 Jul 2025 23:58:34 \-0400
|
| The Andrew relationship was never good just never
|
| Version: 1
| Sent: Thu, 17 Jul 2025 23:58:18 \-0400
|
| The relationship was never good just never


**1119.** `23:58` **You**

you don't need to try to fix this\.\. sigh\.\. you are in fix mode now\.\. cannot reboot you\.


**1120.** `23:58` **Meredith Lamb (+14169386001)**

I’m not in fixer mode


**1121.** `23:59` **Meredith Lamb (+14169386001)**

I’m just stating facts


**1122.** `23:59` **Meredith Lamb (+14169386001)**

That’s what I do best


**1123.** `23:59` **You**

kk\.\. all I am saying is the most honest thing you said tonight was the fact that it is all true\.\. which is what I knew already\.\. lol


