# Daily Conversation: 2025-05-25 (Sunday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-25 |
| **Day** | Sunday |
| **Week** | 7 |
| **Messages** | 775 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-25T00:25 - 2025-05-25T23:26 |

## 📝 Daily Summary

This day contains **775 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `00:25` **You**

Jesus another Gracie meltdown j almost called cops\.


**002.** `00:26` **You**

So tired cannot get this sorted fast enough


**003.** `00:26` **Meredith Lamb (+14169386001)**

Oh no


**004.** `00:26` **You**

Why are you still awake


**005.** `00:26` **You**

This wax for tomorrow morning


**006.** `00:26` **Meredith Lamb (+14169386001)**

Not sure\. Probably because I did nothing today


**007.** `00:27` **Meredith Lamb (+14169386001)**

I am lying trying to sleep but no sleeping happening\.


**008.** `00:27` **You**

Sigh I didn’t want to wake you up\.\. was just sharing


**009.** `00:27` **Meredith Lamb (+14169386001)**

Was Gracie out and came home?


**010.** `00:27` **You**

No


**011.** `00:27` **You**

are you ok


**012.** `00:27` **Meredith Lamb (+14169386001)**

Yeah I’m fine


**013.** `00:27` **Meredith Lamb (+14169386001)**

Why’d the cops almost get called?


**014.** `00:27` **Meredith Lamb (+14169386001)**

What’d she do


**015.** `00:28` **You**

Hurting herself


**016.** `00:28` **You**

Smashing shit


**017.** `00:28` **Meredith Lamb (+14169386001)**

Oh man


**018.** `00:28` **Meredith Lamb (+14169386001)**

How did it get resolved


**019.** `00:29` **You**

Tired herself out


**020.** `00:29` **You**

I think


**021.** `00:29` **Meredith Lamb (+14169386001)**

Yikes


**022.** `00:30` **Meredith Lamb (+14169386001)**

That sucks but she is probably really struggling extra with the separation and “stuff”


**023.** `00:30` **Meredith Lamb (+14169386001)**

Just piles on


**024.** `00:31` **You**

It is hard to see where nasty stops and mental health starts,, this fight started from not being able to get j give up her kindle


**025.** `00:31` **Meredith Lamb (+14169386001)**

😵‍💫 doh \- that’s bad


**026.** `00:32` **You**

Yep


**027.** `00:36` **You**



**028.** `00:37` **You**


*📎 1 attachment(s)*

**029.** `00:48` **You**


*📎 1 attachment(s)*

**030.** `08:29` **Meredith Lamb (+14169386001)**

Just got those now 🫠


**031.** `09:27` **Meredith Lamb (+14169386001)**

So just for your mental peace of mind, I asked Andrew this morning if we talked a lot while I was messed up on fri night\. He said we talked about Maelle when we got home from work and I was already drunk\. He said we talked a bit later but he doesn’t even remember about what \(and he wasn’t drinking\)\. So it was very inconsequential…\.


**032.** `09:53` **You**

I am glad you can put that to bed\.   At least you don’t have to wonder and worry\.


**033.** `10:03` **Meredith Lamb (+14169386001)**

I mean I was 99% sure but I know you weren’t so thought I should ask\.


**034.** `10:35` **You**

So I knew about the heart to heart with Andrew about maelle you mentioned that to me and explained  it\.  I knew maelle got home and you said something about the ring\. Then you said something about your mother thinking you were messed up\.  I told you a bunch of times to be careful, that people as
Messed up as you were then could make some really stupid decisions and not know it or remember it\.  When maelle got home you said “you need some of that” to me honestly I don’t think you actually thought you were talking to me at that point that was the last thing you said\.   So if Andrew suggests\. I nothing of consequence I guess you are good\.  I think as long as nothing he perceived as bad happened he should be fine\.


**035.** `10:40` **Meredith Lamb (+14169386001)**

I think he is used to me\. If I said anything he isn’t sharing\. Also, he is not acting weird\.


**036.** `10:41` **Meredith Lamb (+14169386001)**

You need some of that\. No idea what that meant\.


**037.** `10:41` **You**

Yep no clue\.


**038.** `10:49` **Meredith Lamb (+14169386001)**

Sorry talking to Mackenzie about her birthday


**039.** `10:49` **Meredith Lamb (+14169386001)**

She wants to invite 2 more girls


**040.** `10:49` **You**

Alright we can both remain clueless about that mysterious statement\. I am getting ready to go to gym\.\. maybe chat later\. Have fun with Mac\.


**041.** `10:53` **Meredith Lamb (+14169386001)**

I tried to look back \(horrified\) and didn’t see it so can’t even speculate honestly\.


**042.** `10:54` **You**

Doesn’t matter anyways\. Probably nothing\.


**043.** `10:54` **Meredith Lamb (+14169386001)**

I feel like you think it was something\. I can guarantee you it was not\.


**044.** `10:55` **You**

I don’t Mer all good\.  Just forget I mentioned anything not bringing anything up from that night again don’t worry\.


**045.** `10:57` **You**



**046.** `10:57` **You**

Just going to head out\.


**047.** `10:59` **Meredith Lamb (+14169386001)**

Omg Marlowe says she took a video of me\. Gah\. She said bc Andrew was asleep she took it to show him\. She’s like “you were speaking gibberish” omg……\. Such a bad parent\.


**048.** `11:01` **Meredith Lamb (+14169386001)**

Think I will take a break for a month or two 🙈


**049.** `11:02` **You**

Don’t be too hard on yourself mer you are doing the best that you can\.  I am just going to drop all of this and not bring it up again\.\. I think you need to put it behind you but don’t let it change what you need to do to get by\.


**050.** `11:04` **You**

I think not discussing it further might be helpful to you\.\. I don’t think you process
Stuff like this well anyways\. Kk so just move past it\.


**051.** `11:05` **You**

I love you no matter what you know that right no matter what you do, silly stupid mistakes, any mistakes and all\.\. it is a package deal\.


**052.** `11:06` **You**

My dealing with my own stuff is my own problem\.  Again I keep trying to tell you it is in my head and there is nothing that can be done about that except getting through this situation which will just take time, and my ability to deal with more of this as it comes up\.  So just relax ok\.


**053.** `11:07` **You**

If we are in fact soul mates as I feel this shouldn’t be a problem right?


**054.** `11:07` **You**



**055.** `11:21` **Meredith Lamb (+14169386001)**

>
Right, but I do need to get my shit together\. I think it is time\. I’ve f\*cked off long enough probably\. Time to be an adult\.

*💬 Reply*

**056.** `11:23` **You**

I will support however you need me to\.


**057.** `11:25` **Meredith Lamb (+14169386001)**

I know you will :\)


**058.** `11:25` **You**

I don’t want you getting your shit together mean yku are miserable… what if the part of this that connected us was the carefree irresponsible side of you and the adult in you is more like what in the fuck am I doing right now\.  Anyhow I can’t worry about that already too much lol


**059.** `11:26` **Meredith Lamb (+14169386001)**

Scott, I liked you even when I was responsible\.


**060.** `11:26` **Meredith Lamb (+14169386001)**

lol


**061.** `11:27` **You**

You liked the other me\.  But that’s fine will see how this goes\.\. like is said it might be better for me to bring the other me back for the next few months\.  I am looking for a therapist this afternoon that can help me disassociate\.\. specifically\.\. I think that would be hugely beneficial to be able to turn everything off for a bit\.


**062.** `11:28` **You**

There has to be a way for me to do that\.


**063.** `11:28` **You**

Maybe hypnosis or something


**064.** `11:28` **You**

Open to trying anything at this point\.


**065.** `11:29` **Meredith Lamb (+14169386001)**

Mac has some gummies that might do the trick\. 😜


**066.** `11:30` **Meredith Lamb (+14169386001)**

>
There is no “other me”\. You are you with maybe different sides but it is still you\.

*💬 Reply*

**067.** `11:31` **Meredith Lamb (+14169386001)**

I think once I smarten up things might get easier\. My brain won’t be so fried and anxious\.


**068.** `11:32` **Meredith Lamb (+14169386001)**

Going to plan my workouts for this week today based on my 2016 old stuff\.


**069.** `11:32` **Meredith Lamb (+14169386001)**

No more gummies/thc\.


**070.** `11:33` **Meredith Lamb (+14169386001)**

I missed marlowe’s beach vball tourn yday bc I was so sick


**071.** `11:33` **Meredith Lamb (+14169386001)**

And didn’t go shopping with Mac\. Doing that shortly\.


**072.** `11:33` **Meredith Lamb (+14169386001)**

Just let EVERYONE down including you…


**073.** `11:33` **Meredith Lamb (+14169386001)**

Time to change


**074.** `11:35` **Meredith Lamb (+14169386001)**

They won a silver in the premiere league and I missed it and it was pretty exciting and shocking I guess

*📎 1 attachment(s)*

**075.** `11:35` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**076.** `11:38` **You**

Mer honestly you haven’t let me down\.  And I am not lying\.\. it might be scary to hear but I already know I want to spend the rest of my life with you\.  It scares the fuck out of me\.\. but I am 100% certain more than I have ever been of anything else\.  So yeah these are some shitty bumps along the way and yeah I am not going to lie it is going to hurt a lot over the next few weeks or months\. That is why I want to shit stuff down\.\. I have dreamt about this, thought about this\.\. and it makes me feel so happy\.\. bit the road
To get there will be like walking on glass barefoot I think\.\. totally worth it but going to suck a lot\.


**077.** `11:40` **Meredith Lamb (+14169386001)**

Friday night did not give you A LITTLE pause on that feeling?


**078.** `11:41` **You**

I was scared made a mistake\.\. but I think even if you had have, while it would have crushed me I was already relegated to never giving up on you\.


**079.** `11:41` **You**

That is how strongly I feel\.


**080.** `11:42` **Meredith Lamb (+14169386001)**

You know I don’t like Andrew right? No matter how messed I am, we are not going back there\.


**081.** `11:42` **Meredith Lamb (+14169386001)**

>
Why does it scare you? Just because of our respective situations?

*💬 Reply*

**082.** `11:44` **You**

Reaction: ❤️ from Meredith Lamb
It scares me because I have never done this, even the pre version of me\.\. I have never loved this hard this much this unconditionally\.  I have never opened myself up this much\.  The risk is HUGE\.  And yes our respective situations are different and the potential outcomes terrify me\.


**083.** `11:47` **Meredith Lamb (+14169386001)**

You don’t need to be scared\. I’m not going anywhere\. I’m in this just as deep as you are\.


**084.** `11:47` **You**

>
It’s not that you go back it’s that you won’t have a choice\.  You will need to choose
Your children because you won’t be able to afford
To separate and not choose them\.

*💬 Reply*

**085.** `11:48` **You**

That is the nightmare scenario\. Mine is done\. Nothing for you to worry about we booked the moving pods downpaymebt on the house\. Closing date\. J and I had what I expect was our last shopping day tomorrow\.  And found some closure on a few things\.


**086.** `11:49` **You**

Like this part is happening no matter what\.\. I feel there is still a ton of risk on your side\. Can’t help it\.\.


**087.** `11:49` **You**

>
I am not sure mer\.  I know that isn’t fair to say\.\. but it is just a feeling\.\. not a judgement\. An insecurity\.

*💬 Reply*

**088.** `11:52` **You**

>
I also think that loneliness over a long period of time can have weird
Effects on people\.  Why you don’t need to worry is Jaimie hates me lol\.\. so at least there is that\.

*💬 Reply*

**089.** `11:57` **Meredith Lamb (+14169386001)**

>
ZERO chance of this happening\. Zero\.

*💬 Reply*

**090.** `11:58` **Meredith Lamb (+14169386001)**

Honestly I cannot emphasize that anymore\. Zero chance\.


**091.** `11:59` **Meredith Lamb (+14169386001)**

We operate now as separated\. Talked about getting our bank accounts separated this morning\.


**092.** `12:00` **Meredith Lamb (+14169386001)**

We are 100% done\. I did mention the cottage thing again this morning\. He doesn’t care if I can’t contribute as much\. Does not want that plan changing\.


**093.** `12:01` **Meredith Lamb (+14169386001)**

>
And equally, I am no big fan of Andrew\.

*💬 Reply*

**094.** `12:14` **You**

Kk hope for the best 🤞


**095.** `12:15` **Meredith Lamb (+14169386001)**

So j isnt going to come up to your office right?


**096.** `12:21` **You**

No


**097.** `12:22` **You**

Either you or I won’t be there for like 4 weeks\.


**098.** `12:22` **You**

So nothing to worry about


**099.** `12:22` **You**

Regardless


**100.** `12:22` **Meredith Lamb (+14169386001)**

You are not going Monday Tuesday?


**101.** `12:22` **You**

Not sure and even if I do


**102.** `12:22` **You**

I am going to be somewhere else


**103.** `12:22` **Meredith Lamb (+14169386001)**

Somewhere else? Huh?


**104.** `12:23` **You**

I will find someplace else
To work out of\. And a valid reason for it


**105.** `12:23` **Meredith Lamb (+14169386001)**

You do not need to do that\. Unnecessary


**106.** `12:23` **You**

But I want to


**107.** `12:24` **You**

I am going in early again will figure something out doing the early morning workout maybe go for a wall outside for a bit to cool off and then find a place to go\.


**108.** `12:24` **You**

Same Tuesday


**109.** `12:25` **You**

Or again I might just work from home not sure


**110.** `12:25` **You**

Thinking about it today, among other things\.


**111.** `12:27` **Meredith Lamb (+14169386001)**

I feel like we should consider getting together in the morning Monday or tuesday … I want to try because I know for sure it would help you a lot and maybe me too\. Don’t say no immediately right now\. Just let that sit for a while


**112.** `12:28` **You**

I don’t need to let it sit\.\. we have talked about this and I know how you actually feel about it\.\. this is you trying to come to the rescue\.\. so I don’t think it is a good idea\.\. have tried this a number of times
Before\. I know what the honest feeling is here mer\.


**113.** `12:29` **Meredith Lamb (+14169386001)**

I am not trying to come to the rescue\. I am thinking about what is best leading into a long absence\.


**114.** `12:29` **Meredith Lamb (+14169386001)**

It is also called listening to you


**115.** `12:29` **You**

I don’t think that would be good for you\.\. possibly not me either at this point\. Not sure


**116.** `12:29` **Meredith Lamb (+14169386001)**

And caring about you too


**117.** `12:30` **Meredith Lamb (+14169386001)**

Sometimes you make it feel like I am not allowed to care about what you need\.


**118.** `12:32` **You**

I put your needs above mine\.  And honestly it is going to hurt like fuck\. It seeing you for so long\.\. like I don’t know if this makes it worse or not\.\. I am pretty emotional right now\.\. not sure I want you to see any of that\.


**119.** `12:34` **Meredith Lamb (+14169386001)**

I am okay with that\. You don’t have to hide anything from me\. But I think we need to think about each other equally so you have to allow me to sometimes\.


**120.** `12:35` **You**

Again not sure I decide to go tomorrow or not\.\. we’ll see\.  Again might be better to just stay home\.\. then no contact


**121.** `12:36` **Meredith Lamb (+14169386001)**

I think we need to see each other\. This weekend was a mess\.


**122.** `12:37` **You**

If I thought it might make shit better for both of us\.\. but yeah a 15 minute connect before going on to ignore each other at work for two days then 3\-4 weeks math not great there


**123.** `12:37` **Meredith Lamb (+14169386001)**

Just think it over this afternoon\.


**124.** `12:37` **You**

It’s fine mer just leave it\. Easier that way\.


**125.** `12:38` **Meredith Lamb (+14169386001)**

I highly doubt we don’t see each other for 3\-4 wks


**126.** `12:38` **You**

We won’t


**127.** `12:38` **Meredith Lamb (+14169386001)**

You are talking a little extreme


**128.** `12:38` **You**

I’m not


**129.** `12:38` **Meredith Lamb (+14169386001)**

I don’t believe that


**130.** `12:38` **You**

Ok I mean I think that works for you\.\.
It doesn’t for me\.


**131.** `12:38` **You**

I just expect the worst plan for it\.\. and out hope in a box


**132.** `12:39` **Meredith Lamb (+14169386001)**

We have been seeing each other pretty regularly no?


**133.** `12:39` **You**

Put hope in a box


**134.** `12:39` **Meredith Lamb (+14169386001)**

Making it happen?


**135.** `12:39` **You**

That kind of changed golf day and the days that followed\.


**136.** `12:40` **Meredith Lamb (+14169386001)**

Not necessarily…\. Things are changing at lightning speed\. Your family knows now, I will be in a new role soon, I need to move out, it is like living in fast forward\. S


**137.** `12:40` **Meredith Lamb (+14169386001)**

All of the changes shift things and change things


**138.** `12:41` **You**

Mer I love you and I am sorry but I cannot work that way\.\. it leads to expectation and disappointment\.\. the not necessarily or per se or solve it tomorrow\.\. it’s not me\. This situation crushes me I am not built for it\. Just trying to survive\.


**139.** `12:42` **You**

Every time I am disappointed it hurts more


**140.** `12:42` **You**



**141.** `12:43` **Meredith Lamb (+14169386001)**

Did you tell your family that we have never hung out outside of work?


**142.** `12:44` **You**

They don’t believe me


**143.** `12:44` **You**

Chatham


**144.** `12:45` **You**

Maybe I will just go tomorrow or not the park mon/tues morning you show up fine you don’t whatever that is fine to\.


**145.** `12:45` **You**

Will think and see\. Just not sure I mean going to get run over one way or other\.


**146.** `12:46` **Meredith Lamb (+14169386001)**

>
They only think Chatham tho?

*💬 Reply*

**147.** `12:47` **You**

Cottage


**148.** `12:47` **You**

Yeah Jaimie pretty much does t trust anything


**149.** `12:47` **You**

But she told me this morning she is going to put the mer thing away and compartmentalize I think she just hopes\. It to see you at the office


**150.** `12:47` **You**

Just go in main door ms and leave main doors and she never will’s


**151.** `12:48` **You**

She is taking the first week I am taking off as well


**152.** `12:48` **You**

And then another in July


**153.** `12:49` **You**

So I might not take the second week off unless
There is a lot of work I can do on my own


**154.** `12:49` **You**

She is also gone to Moncton a few times twice in June


**155.** `12:53` **Meredith Lamb (+14169386001)**

Sigh, yeah the work thing is going to be super awkward but tbh it has been for me for months


**156.** `12:53` **Meredith Lamb (+14169386001)**

So not that much different


**157.** `12:53` **Meredith Lamb (+14169386001)**

I’m sure we will be able to get together at some point in there somehow


**158.** `12:55` **You**

Again\.\. I am just going to assume not mer\.


**159.** `12:59` **You**

So yeah just going to do what I said earlier workout park work\.\. no expectations… and then will figure out work from there\.


**160.** `13:00` **You**

And Wednesday forward\.\.  I don’t know… shit down and close off completely\.\.
Will have to see\.


**161.** `13:00` **You**

Sit down\.


**162.** `13:03` **You**

Maybe shut signal down for a bit\.\. I dunno been thinking about a lot of different options\.


**163.** `13:04` **You**

But yeah might not be as long as I had planned if there isn’t enough work to take second week off ☹️


**164.** `13:04` **You**

Will deal with that when it comes


**165.** `13:05` **Meredith Lamb (+14169386001)**

That’s fine\. We need to turn this mood around though\. Gahhhh


**166.** `13:06` **You**

You go turn your mood around\.


**167.** `13:07` **You**

You can do that I know you can\.  Just avoid thinking about me\.\. I will leave you alone for the rest of the day and whatever happens tomorrow right\.\. probably best choice for you,


**168.** `13:07` **Meredith Lamb (+14169386001)**

Shopping with Mac


**169.** `13:07` **You**

Have fun


**170.** `13:08` **You**

Just going to shut this down\. Finish my workout and go home\.  Enjoy your time out with her\. Cya


**171.** `13:08` **You**



**172.** `13:12` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I love you and will get you out of your funk\. ❤️❤️


**173.** `13:13` **You**

I love you too mer\.\. no one else\. Not like you\. ❤️❤️


**174.** `13:13` **You**

Reaction: ❤️ from Meredith Lamb
I wouldn’t go through this for anyone else for sure\.


**175.** `14:58` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**176.** `14:58` **You**

I can relate to the part in brackets


**177.** `14:59` **Meredith Lamb (+14169386001)**

Same look


**178.** `14:59` **Meredith Lamb (+14169386001)**

lol


**179.** `15:19` **You**

I do have one topic we can talk about that isn't fucked up and depressing\.\. will have to wait for later\.  I have another Half Sister\.  Found out 2 days ago\.


**180.** `15:21` **You**

I have just been pretty preoccupied with us and my head\.\.


**181.** `15:35` **Meredith Lamb (+14169386001)**

Oh wow \- how’d you find out?


**182.** `15:48` **You**

She reached out to me\.


**183.** `15:48` **You**

Found me on ancestry\.ca


**184.** `15:53` **Meredith Lamb (+14169386001)**

That’s cool \- maybe it will turn into something interesting


**185.** `15:55` **You**

She lived in Dieppe\.\. she went to Mathieu Martin High School\.\. I went to HTHS in Moncton \- Rivals\.\. it will def turn into something interesting\.\. I probably new her friends\. could have run into her ffs\.  This will def be interesting\.


**186.** `15:55` **You**

we grew up minutes from each other


**187.** `15:56` **Meredith Lamb (+14169386001)**

Small world\. Wonder how many others?


**188.** `15:56` **You**

Only one other I know of I mentioned her to you


**189.** `15:56` **You**

no brothers :\(


**190.** `15:58` **Meredith Lamb (+14169386001)**

I mean not yet


**191.** `16:01` **You**

we shall see\.


**192.** `16:01` **You**

There are a number of other curiosities lol I will tell you about those later\.


**193.** `16:02` **Meredith Lamb (+14169386001)**

k


**194.** `20:05` **Meredith Lamb (+14169386001)**

How are you?


**195.** `20:08` **You**

Just doing a bit of work\.\. doing some calendar stuff\.\. planning next few days etc\.


**196.** `20:09` **You**

hope you had a good day


**197.** `20:09` **Meredith Lamb (+14169386001)**

Not what are you doing, HOW are you doing?


**198.** `20:09` **You**

Why don't you tell me about your day\.


**199.** `20:10` **Meredith Lamb (+14169386001)**

Mac and I went shopping and spent too much money\. But all useful stuff\. Lol


**200.** `20:10` **You**

Good I am sure this is setup to be an awesome B\-day weekend\.


**201.** `20:10` **Meredith Lamb (+14169386001)**

I got a rug for one of the rooms and your voice “but do you need it?” rang in my ear\. Lol


**202.** `20:10` **Meredith Lamb (+14169386001)**

Mac said yes we need it\. I agreed


**203.** `20:10` **You**

Of course you did\.\. no doubt about it\.


**204.** `20:11` **You**

Good purchase


**205.** `20:11` **Meredith Lamb (+14169386001)**

I honestly still felt hungover today tho


**206.** `20:11` **Meredith Lamb (+14169386001)**

😵


**207.** `20:11` **Meredith Lamb (+14169386001)**

Not alc hungover


**208.** `20:11` **Meredith Lamb (+14169386001)**

Something different


**209.** `20:12` **Meredith Lamb (+14169386001)**

So have been doing laundry, tv, not much


**210.** `20:12` **You**

>
what is wrong

*💬 Reply*

**211.** `20:12` **Meredith Lamb (+14169386001)**

I think it is that stupid gummy\. Just after effect\.


**212.** `20:12` **Meredith Lamb (+14169386001)**

Never doing that again


**213.** `20:12` **You**

>
sure sure

*💬 Reply*

**214.** `20:12` **Meredith Lamb (+14169386001)**

No idea what the heck is in it


**215.** `20:13` **Meredith Lamb (+14169386001)**

It said extra strength\. wtf


**216.** `20:13` **Meredith Lamb (+14169386001)**

Jim’s are so tame by comparison


**217.** `20:13` **Meredith Lamb (+14169386001)**

Like sooooooooooo tame


**218.** `20:13` **Meredith Lamb (+14169386001)**

>
For real\. It’s like I had food poisoning\.

*💬 Reply*

**219.** `20:13` **You**

honestly if I could take something that would send me off into a black void I would\.\. man sign me up\.\. sounds like a vacation\.


**220.** `20:13` **You**

anyways


**221.** `20:14` **You**

my day consisted of some dfriving maddie to a baday party


**222.** `20:14` **You**

and pickup\.\. then out to buy some moving boxes\.


**223.** `20:14` **You**

but no one wanted to work\.\. so I am back in the basement for 2 hours then going to bed\.


**224.** `20:14` **Meredith Lamb (+14169386001)**

And how is your head?


**225.** `20:14` **You**

same


**226.** `20:14` **Meredith Lamb (+14169386001)**

What time do I meet you tomorrow


**227.** `20:15` **You**

You could ask me that question tomorrow next week next month


**228.** `20:15` **You**

same answer


**229.** `20:15` **Meredith Lamb (+14169386001)**

Stop thinking so far ahead


**230.** `20:15` **You**

if I don't


**231.** `20:15` **You**

it is worse


**232.** `20:15` **You**

Far ahead is the only thing I can focus on


**233.** `20:16` **Meredith Lamb (+14169386001)**

>
…\.

*💬 Reply*

**234.** `20:16` **You**

I don't know\.


**235.** `20:16` **You**

I go early so it might not work for you anyways


**236.** `20:16` **Meredith Lamb (+14169386001)**

I will get up early\. One day lol


**237.** `20:17` **You**

I still don't know\.\. I still don't feel right about it\.\. let me think a bit more\.


**238.** `20:18` **Meredith Lamb (+14169386001)**

No, you don’t have a choice on this\. Not after this weekend\.


**239.** `20:18` **You**

Sure I do\.\. if this just hurts me more\.\.\.\.\.\. how is that gonna help?


**240.** `20:19` **You**

I need to close an earlier conversation \- and I am good with everything that you said\.\. but listen\.\. if anything did happen \- even though you say it won't \- but if it did\.\. even if it was a mistake\.\. you would tell me right, I would never need to wonder\.


**241.** `20:20` **You**

Like if it did or has already or whatever\.\. you get what I am saying\.


**242.** `20:21` **You**

>
btw\.\. Is this "K"  would this do this?

*💬 Reply*

**243.** `20:21` **You**

sorry couple of stacked messages


**244.** `20:23` **Meredith Lamb (+14169386001)**

Omg Scott…


**245.** `20:23` **Meredith Lamb (+14169386001)**

First, I would never\.


**246.** `20:23` **Meredith Lamb (+14169386001)**

Second, yes of course I would tell you\.


**247.** `20:23` **Meredith Lamb (+14169386001)**

But I honestly would never\.


**248.** `20:24` **Meredith Lamb (+14169386001)**

I could not even bring myself close\.


**249.** `20:24` **You**

>
I just needed this\.\. I am good\.

*💬 Reply*

**250.** `20:24` **Meredith Lamb (+14169386001)**

We have not even touched or brushed by each other since the fall\.


**251.** `20:25` **Meredith Lamb (+14169386001)**

This is a 100% truth\.


**252.** `20:25` **Meredith Lamb (+14169386001)**

After that text happened in sept/oct, we did and I felt horrible\.


**253.** `20:25` **Meredith Lamb (+14169386001)**

That was it for me\.


**254.** `20:25` **Meredith Lamb (+14169386001)**

That was probably September


**255.** `20:25` **Meredith Lamb (+14169386001)**

Maybe early October


**256.** `20:26` **Meredith Lamb (+14169386001)**

I have no interest in being with someone who betrayed me\.


**257.** `20:26` **You**

I understand Mer\. you don't need to go back into that\.\.


**258.** `20:26` **Meredith Lamb (+14169386001)**

>
We are not doing k so not discussing\.

*💬 Reply*

**259.** `20:27` **You**

We aren't agreed


**260.** `20:27` **You**

But I did a bit of research


**261.** `20:27` **You**

There is Ketamine therapy


**262.** `20:27` **Meredith Lamb (+14169386001)**

And…


**263.** `20:27` **Meredith Lamb (+14169386001)**

Yeah


**264.** `20:27` **Meredith Lamb (+14169386001)**

It is a dissociative


**265.** `20:27` **You**

I was just thinking of what it does\.\. and how I want to dissasociate\.


**266.** `20:28` **You**

I don't do drugs\.\. I don't like them\.\. but I have tried a number of different things to get my mind right\.


**267.** `20:28` **Meredith Lamb (+14169386001)**

I started doing it after my friend killed herself\. Was a very emotional time\. A lot of ppl do it with e \(mdma\) also


**268.** `20:29` **You**

and nothing is working\.\.


**269.** `20:29` **Meredith Lamb (+14169386001)**

K is addictive\. Problem\.


**270.** `20:29` **You**

well scratch that then\.\. I won't do that\.


**271.** `20:30` **Meredith Lamb (+14169386001)**

Honestly everyone talks about how addictive cocaine is\. I did not find that\. K, yes\. But I like disassociatives bc my brain doesn’t shut off\.


**272.** `20:30` **You**

well\.\. i do get addicted\.\. so while it probably is the perfect thing for me based on my brain


**273.** `20:31` **Meredith Lamb (+14169386001)**

Why don’t we just plan a trip and have that to look forward to instead?


**274.** `20:31` **You**

can't do it


**275.** `20:31` **You**

>
too far out to consider planning\.\.\. and too soon puts you at risk so I won't

*💬 Reply*

**276.** `20:32` **Meredith Lamb (+14169386001)**

k, so medium term then :p


**277.** `20:33` **You**

no I am sorry Mer\.\. I don't think that is a good idea\.


**278.** `20:35` **Meredith Lamb (+14169386001)**

This new approach of yours is not working\. Your words are cutting and I know they are hurting you too\.


**279.** `20:36` **You**

I am not trying to be that way\.\. but it feels like\.\.\.\.\. like a mirage\.


**280.** `20:36` **You**

Ok mer\.\. let's do it your way\.


**281.** `20:37` **Meredith Lamb (+14169386001)**

A mirage?


**282.** `20:37` **You**

the closer I get I feel it will just fade away\.


**283.** `20:37` **You**

and it is likely so far out into the future it won't really matter\.


**284.** `20:38` **You**

but again\.\. let's try it\.\.


**285.** `20:38` **You**

i cannot be like this again\.\. it just hurts you\.\. I will try to find some way to at least present as happy\.


**286.** `20:39` **Meredith Lamb (+14169386001)**

You do not need to be happy\. Just be honest\. Don’t do things you don’t want to\. I do not need protecting\. If I’m uncomfortable with something I just won’t do it\.


**287.** `20:40` **You**

I have been honest\.\. lol\.\.


**288.** `20:41` **Meredith Lamb (+14169386001)**

So you really just want to cut off contact\. That is your truth?


**289.** `20:43` **You**

I don't want\.\.\. I just don't know what to do\.  I don't know what will help\.\. when I did that GPT analysis of us after golf\.\. it made sense\.\. while we are great together\.\. we are not great in this situation \- we are fundamental opposites\.\. I just realized this was going to be really really horrible, as I wanted to respect your needs\.  I just don't want hurt\.\. these fucking emotions suck\.\. i wish they would turn off again, just for a little while ffs\.


**290.** `20:45` **Meredith Lamb (+14169386001)**

I think we need to be able to talk about stuff without you going full blast on me in the other direction\.


**291.** `20:45` **Meredith Lamb (+14169386001)**

I didn’t think of if I told you about how I was feeling you were just going to run in the opposite direction


**292.** `20:50` **You**

You know\.\. I like puzzles\.\. I always have\.\. there is a logic to solving them\.\. an order a structure\.\. one\.\. or many solutions\.  I have come at this situation we are in both from a logical perspective\.\. and from a pure brute force passion perspective\.  I don't have an answer\.\. I am distracted, I am distraught, and I don't think there is a fix for this, not one that works for both of us, and certainly not one that will work for the long absences we are facing over the next few months\.  So I think not talking about it all is probably a good solution\.\. because then you won't hate or resent me for being a fucking shitty downer all the time\.\. and I don't have to feel bad about pushing back on your good intentions\.  I know you care\.\. I know you love me, but I just think our constant triyng to fix it won't I tried for a few weeks to figure out some shit\.\. none of it really took hold\.\. and I think we are at different places in what we need\.\. so that is why I kind of am withdrawing\.\. you are very casual about things\.\. I am very very intentional\.\. sometimes that doesn't mix well\.


**293.** `20:52` **You**

Sometimes your honesty is "stark"\.\. don't get me wrong, I love it, and I love you\.  But sometimes when you drop some knowledge it lands with a thud\.\. lol if you get my meaning\.  Sometimes it lands on me with a thud\.  That was golf\.


**294.** `20:53` **Meredith Lamb (+14169386001)**

This doesn’t feel casual to me\.


**295.** `20:53` **You**

I didn't say that\.


**296.** `20:53` **You**

Think about how you state things\.


**297.** `20:53` **You**

From your perspective \- you will say something that is to you not a big deal\.


**298.** `20:53` **You**

so you just kind of throw it out that way\.


**299.** `20:53` **Meredith Lamb (+14169386001)**

Like…\.\.


**300.** `20:53` **You**

But you don't know that it is a big deal to me


**301.** `20:53` **You**

that I think about things differently


**302.** `20:54` **You**

I don't want to get into examples\.\. The only reason this is a problem between us is because of how raw this situation is making things\.\. that is the only problem


**303.** `20:54` **You**

give me 60 days


**304.** `20:54` **You**

I will be a new man


**305.** `20:55` **You**

or you can take me back for a full refund


**306.** `20:55` **Meredith Lamb (+14169386001)**

lol


**307.** `20:55` **Meredith Lamb (+14169386001)**

I wish I could just kiss you right now\. Everything would be fine\.


**308.** `20:56` **You**

Reaction: ❤️ from Meredith Lamb
From my perspective It would be amazing\.\. every time you have kissed me has been amazing\.\. from the first time to the last\.


**309.** `20:57` **You**

I told you I think we will look back on this and I will feel like an idiot\.  But I have to deal with how I am feeling now and what is in front of me\.


**310.** `21:01` **Meredith Lamb (+14169386001)**

So how have the conversations gone with your family in terms of how you are moving forward or not with us\.


**311.** `21:01` **Meredith Lamb (+14169386001)**

Like that must have been discussed or asked


**312.** `21:02` **You**

Reaction: ❓ from Meredith Lamb
I told them we haven't really talked very much since and that no plans have been made\.  essentially accurate\.


**313.** `21:02` **You**

Jaimie seems to have calmed down a lot on you since day 1


**314.** `21:03` **You**

I shared with her 2 texts from Gracie \- to me which suggested she didn't care if I went out with you as long as she could stay here\.  That changed J's perspective on Gracie in this\.


**315.** `21:03` **You**

Yesterday morning \- we had a bit of a fight on the way to yorkdale\.\.


**316.** `21:04` **Meredith Lamb (+14169386001)**

>
Hardly\. We talk all the time\.

*💬 Reply*

**317.** `21:04` **You**

>
we don't TALK\.\. we have been circling around this painful conversation since Thursday\.

*💬 Reply*

**318.** `21:04` **You**

which is what I want to get away from


**319.** `21:04` **You**

because a\) it won'


**320.** `21:04` **You**

wont be solved


**321.** `21:04` **You**

and b\) it will keep dragging us down\.


**322.** `21:05` **You**

If you can live through the next little while with what you have right now\.\.


**323.** `21:05` **Meredith Lamb (+14169386001)**

>
About…\.

*💬 Reply*

**324.** `21:05` **You**

we shold just focus on that


**325.** `21:05` **You**

we fought about you


**326.** `21:05` **You**

I was trying to explain how the discussions began innocently\.\. there was no intent\.\.


**327.** `21:05` **You**

it was just support\.


**328.** `21:06` **You**

shit kind of happened\.\. but nothing "happened" until we separated


**329.** `21:06` **You**

I wanted to confirm she was going to let this be\.


**330.** `21:06` **You**

Which she has confirmed several times already


**331.** `21:06` **You**

And she has told Gracie to fuck right off


**332.** `21:06` **You**

So that was the morning\.\.


**333.** `21:06` **You**

after that\.\. things were easy\.\. almost a little sad


**334.** `21:07` **Meredith Lamb (+14169386001)**

Does she think this is not continuing?


**335.** `21:07` **You**

No


**336.** `21:07` **You**

She doesn't think that\.\.


**337.** `21:07` **You**

She doesn't think I am going to be stupid enough to do something in front of her face\.


**338.** `21:07` **You**

she isn't accepting of it\.\.


**339.** `21:07` **You**

if that is what you are getting at\.


**340.** `21:07` **You**

she doesn't want it to come out at work until after she has quit and gone\.


**341.** `21:07` **Meredith Lamb (+14169386001)**

No I was just curious on your narrative


**342.** `21:08` **You**

I said you were a wench\.\. and I didn't like you much anyways


**343.** `21:08` **Meredith Lamb (+14169386001)**

lol


**344.** `21:08` **You**

I tried to humanize you


**345.** `21:08` **Meredith Lamb (+14169386001)**

By calling me a wench


**346.** `21:08` **Meredith Lamb (+14169386001)**

lol


**347.** `21:08` **You**

no not that


**348.** `21:08` **Meredith Lamb (+14169386001)**

Kidding


**349.** `21:08` **You**

she is the youngest of 3 \- oopsie baby\.


**350.** `21:09` **You**

country kid


**351.** `21:09` **You**

did not have the same parents or the same opportunities


**352.** `21:09` **You**

but the situations in many ways were similar\.


**353.** `21:09` **You**

She was introverted and quiet


**354.** `21:09` **You**

most of her life


**355.** `21:09` **You**

She grew up in a very small town\.\. smaller than Glencoe


**356.** `21:09` **You**

Miscouche


**357.** `21:10` **Meredith Lamb (+14169386001)**

Wait you didn’t try to tell her that I’m like her


**358.** `21:10` **Meredith Lamb (+14169386001)**

That would drive her insane


**359.** `21:10` **Meredith Lamb (+14169386001)**

I hope you didn’t do that


**360.** `21:10` **You**

She didn't have a lot of boyfriends growing up or a lot of friends\.\. she turned to drugs in grade 12


**361.** `21:10` **You**

and went hard for a few years


**362.** `21:10` **You**

then hard again\.\. then hard on drinking and drugs


**363.** `21:10` **You**

then just hard on drinking by the time I met her\.


**364.** `21:11` **Meredith Lamb (+14169386001)**

Your type is troubled souls


**365.** `21:11` **You**

She was engaged\.\. her fiance cheated on her\.\. before me there were 2 people the fiance\.\. and her best friend\.\. one night, and regretted it forever\.


**366.** `21:11` **You**

She was scared of me\.\.  I was not her type\.


**367.** `21:12` **You**

I was smart, educated, fast, confident\.\. and COLD \- well cold still in a welcoming , polite, and slightly charming way\.


**368.** `21:12` **You**

She fell I didn't\.  To put it simply\.  We broke up because I didn't feel the connection\.


**369.** `21:13` **Meredith Lamb (+14169386001)**

That is the reason?


**370.** `21:13` **You**

Yeah\.\. I didn't but I didn't realize I couldn't


**371.** `21:13` **You**

Not with her\.


**372.** `21:13` **Meredith Lamb (+14169386001)**

Have you two ever talked about this?


**373.** `21:13` **You**

Yeah\.


**374.** `21:13` **You**

not always great conversations


**375.** `21:14` **Meredith Lamb (+14169386001)**

Phew I bet


**376.** `21:14` **You**

she resents me\.\. thinks I ruined her life\.


**377.** `21:14` **You**

wishes we never met or got back together\.


**378.** `21:14` **You**

and she means it


**379.** `21:14` **You**

This hurt her badly\.\.


**380.** `21:14` **You**

not this you and i


**381.** `21:14` **You**

this me separating


**382.** `21:15` **You**

She feels like I am the last in a long line of people that has found her unworthy and kicked her to the curb\.


**383.** `21:15` **Meredith Lamb (+14169386001)**

Omg ouch ouch ouch 🤕


**384.** `21:16` **You**

anyhow\.\. there are some similarities in your back stories\.\. she lost close friends\.\. turned to drugs\.\. etc etc\.


**385.** `21:16` **Meredith Lamb (+14169386001)**

Does she get therapy?


**386.** `21:16` **You**

She hates therapy


**387.** `21:16` **Meredith Lamb (+14169386001)**

Oh that sucks


**388.** `21:16` **You**

anyhow\.\. I tried to make some connections\.


**389.** `21:16` **You**

Outwardly she was like are you fucking kidding me\.


**390.** `21:17` **You**

but I think a lot got through\.\. she will never like you\.\. and I mean ever ever ever\.  But I think she has calmed down a lot and is more reasonable\.


**391.** `21:17` **You**

still follow the instructions I gave you earlier lol


**392.** `21:17` **Meredith Lamb (+14169386001)**

lol you had typos in your instructions


**393.** `21:18` **You**

whatever you know what I meantr


**394.** `21:18` **Meredith Lamb (+14169386001)**

I don’t think you need to make connections between us


**395.** `21:18` **Meredith Lamb (+14169386001)**

Probably not helpful really


**396.** `21:18` **You**

I wasn't doing it for you\.\.


**397.** `21:18` **You**

She could relate to you I think a bit better though\.


**398.** `21:18` **Meredith Lamb (+14169386001)**

Probably not helpful to HER I meant


**399.** `21:18` **You**

again\.\. she was super calm today


**400.** `21:18` **You**

anyhow


**401.** `21:19` **You**

after yorkdale we went to outlets


**402.** `21:19` **Meredith Lamb (+14169386001)**

It’s probably really hard to understand for her because we don’t even really understand it


**403.** `21:19` **You**

walked around\.\. chatted like normal\.\. she bought a bunch of shit\.\. I bought nothing\.\. had a chuckle because that is always how it was\.


**404.** `21:20` **You**

>
I think I understand it\.\. and if it happened in September\.\. we would be having an epic time right now I think\.

*💬 Reply*

**405.** `21:20` **Meredith Lamb (+14169386001)**

Wdym why?


**406.** `21:20` **You**

Because I do believe we were meant to connect\.\. and if it had just happened a bit later\.\. so much easier\.


**407.** `21:21` **You**

but I cannot have it both ways\.


**408.** `21:21` **Meredith Lamb (+14169386001)**

Oh I thought you meant last September


**409.** `21:21` **Meredith Lamb (+14169386001)**

I’m confused


**410.** `21:21` **You**

If I believe we were meant to connect\.\. perhaps we were meant to connect when we did\.\. so that us going through all this shit would just show us how important we are to each other\.\.\. I dunno\.


**411.** `21:22` **You**

fate and predestination are always annoying topics to think about\.


**412.** `21:22` **You**

anyhow\. I don't need to "understand us"


**413.** `21:23` **Meredith Lamb (+14169386001)**

Do you think part of your mood is grieving your marriage loss also?


**414.** `21:23` **Meredith Lamb (+14169386001)**

Does that come in sometimes?


**415.** `21:23` **You**

ok


**416.** `21:23` **You**

so next


**417.** `21:23` **Meredith Lamb (+14169386001)**

Maybe there is a lot going on and it isn’t just us


**418.** `21:23` **You**

there is\.


**419.** `21:23` **You**

don't get me wrong\.


**420.** `21:23` **You**

but what I am feeling re: you and our situation is just that\.\. I keep those things separate\.\. they don't cross over\.


**421.** `21:24` **You**

So we left the outlet mall\.


**422.** `21:24` **You**

And I suggested we go to this little puzzle store up in georgetown that she found a few years ago that she loved\.\. and wouldn't be getting back there again\.


**423.** `21:24` **You**

Everything was fine until we left\.


**424.** `21:25` **You**

And then you are right\.\. I grieved right then and there\.


**425.** `21:25` **You**

out of the blue\.


**426.** `21:25` **You**

You cannot spend more than half your life with someone and not grieve that it is coming to an end\.


**427.** `21:25` **Meredith Lamb (+14169386001)**

Not surprising


**428.** `21:25` **Meredith Lamb (+14169386001)**

I have had my moments


**429.** `21:25` **You**

especially when she didn't do anything horrible to bring it on\.


**430.** `21:26` **Meredith Lamb (+14169386001)**

I know…


**431.** `21:26` **You**

Like don't get me wrong\.\. it isn't me regretting my decision\.


**432.** `21:26` **You**

or looking to flip\.\.


**433.** `21:26` **You**

just realizing


**434.** `21:26` **You**

ya know\.\. that this is over\.\. 25 years\.


**435.** `21:26` **Meredith Lamb (+14169386001)**

Would it be easier to flip now?


**436.** `21:26` **You**

no\.


**437.** `21:26` **You**

No\.\. even if there was no you\.


**438.** `21:27` **You**

I will still move forward\.\. I feel it is the right decisions for me ultimately\.\. and for her too\.\. even though she doesn't realize it\.


**439.** `21:27` **You**

There wasn't a millisecond


**440.** `21:27` **You**

meredith


**441.** `21:27` **Meredith Lamb (+14169386001)**

Yeah, I understand… I get it really\.


**442.** `21:28` **You**

She doesn't want to leave in july she wants to stay until september\.\. I told her we cannot wait that long with gracie here\.\. other than that if gracie wasn't here I wouldn't care if she stayed\.  It would cramp us a bit more\.\. but it would make maddie happy\.


**443.** `21:29` **You**

But yeah\.\. I was really shocked when that happened\.\. I think she was too\.


**444.** `21:29` **You**

anyhow I got sorted\.\. and we just went to uhaul


**445.** `21:29` **You**

booked her pickup


**446.** `21:29` **You**

Reaction: 😢 from Meredith Lamb
and came home to a Gracie fight,\.


**447.** `21:30` **Meredith Lamb (+14169386001)**

>
I’m sure it won’t be the last time\.

*💬 Reply*

**448.** `21:30` **You**

It will not\.


**449.** `21:30` **You**

I am sure of that too


**450.** `21:30` **Meredith Lamb (+14169386001)**

I’m getting weird moments of knowing I’m leaving my kids alone here without me\.


**451.** `21:30` **You**

Reaction: 😢 from Meredith Lamb
I am saying goodbye to my oldest\.\. and to my dog, who I might not see again,\.


**452.** `21:30` **You**

I will definitely be a mess\.


**453.** `21:30` **Meredith Lamb (+14169386001)**

I will be looking at the fucking hand soap and think “who is going to replace this now?”


**454.** `21:31` **You**

yeah I can see


**455.** `21:31` **You**

that happening


**456.** `21:31` **You**

for you


**457.** `21:31` **Meredith Lamb (+14169386001)**

Even though I will be close by


**458.** `21:31` **Meredith Lamb (+14169386001)**

It’s weird


**459.** `21:33` **You**

yeah that is where our situations are different\.  I tried to explain to her\.\. because she was being a bit harsh\.\. because she is hurt of course\.\. just because I made this choice doesn't mean I don't want her to be happy\.\. doesn't mean we won't stay in contact\.\. and doesn't mean I won't miss her\.  She said you will replace me with someone else fast enough, if not Meredith, then someone else\.  I explained again\.\. Mer and I were not planned, just happened\.\. I was fully ready to be alone\.\.


**460.** `21:33` **You**

Regardless\.\. I feel like there is still a lot of stuff there\.\. but she is calmer now


**461.** `21:33` **You**

and no she didn't ask if there was a chance\.\. or if I was having second thoughts\.


**462.** `21:34` **You**

She doesn't want a chance, and she is not having second thoughts either\.


**463.** `21:35` **You**

I am waiting for you to respond\.\. I am curious as to what you are thinking right now\.


**464.** `21:35` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Just a lot


**465.** `21:35` **You**

ok\.\. break out what you can\.


**466.** `21:35` **You**

you just got a firehose of honesty


**467.** `21:36` **You**

but I feel like you want that\.\. even if it makes you think\.\. you would rather know than not\.


**468.** `21:38` **Meredith Lamb (+14169386001)**

This is just a lot on both sides\. Yours and mine\. It is so much to process\. I appreciate hearing about how it went between you two because I’ve been worrying about when Andrew finds out so it helps me a bit\. But reading that you will miss her, while I know that is natural and totally ok, it still stings a little\. But I don’t blame you or think it isn’t normal… just a lot\. This situation is weird\.


**469.** `21:39` **You**

>
Look\.\. I am not naive\.\. Andrew will be a part of my life going forward\.\. or at least I hope he is\.\. because I want to be apart of your life, and your kids\.  Just like I hope somehow you can become a part of my kids' lives\.

*💬 Reply*

**470.** `21:40` **You**

Jaimie and I went through a lot of shit together\. We supported each other for a long time\.  But that relationships time has passed\.  It is done\.\. it doesn't mean I don't have feelings\.\.


**471.** `21:40` **You**

But Meredith\.


**472.** `21:41` **You**

Again\.\. the feelings I have for you aren't like anything I have experienced\.


**473.** `21:41` **You**

Please take hope in that\.\. I have never loved anyone like you\.\. I have said it over and over again\.\. I believe it\.\. I want what I told you last night\.  I don't have doubts\.


**474.** `21:42` **You**

and anyone like you is how much I love you\.\. not who you are\.\. lol


**475.** `21:42` **You**

I just re read what I wrote\.\. and was like\.\. err


**476.** `21:42` **Meredith Lamb (+14169386001)**

Errr lol why?


**477.** `21:43` **You**

Reaction: 😂 from Meredith Lamb
well it can be read I have never loved anyone like you\.\. like you the person\.\. or someone like you\.\. not "loved" anyone like you\.\. as in the degree of love\.\.


**478.** `21:43` **You**

ok that sounded geeky\.


**479.** `21:43` **You**

whatever\.


**480.** `21:43` **Meredith Lamb (+14169386001)**

Thanks for the clarification


**481.** `21:43` **Meredith Lamb (+14169386001)**

lol


**482.** `21:43` **You**

so yeah there is some residual after 25 years\.


**483.** `21:43` **You**

I want more than 25 with you,\.


**484.** `21:44` **Meredith Lamb (+14169386001)**

We are old\.


**485.** `21:44` **Meredith Lamb (+14169386001)**

Boo :\(


**486.** `21:44` **You**

It won't change how I feel\.


**487.** `21:44` **You**

or how I behave


**488.** `21:44` **You**

:\)


**489.** `21:45` **You**

Reaction: ❤️ from Meredith Lamb
I have gotten 20 years younger\.\. since we have been together\.\. maybe more\.


**490.** `21:46` **Meredith Lamb (+14169386001)**

Think it will last?


**491.** `21:46` **Meredith Lamb (+14169386001)**

I worry you will get bored of me


**492.** `21:46` **Meredith Lamb (+14169386001)**

lol


**493.** `21:46` **Meredith Lamb (+14169386001)**

Not kidding


**494.** `21:49` **You**

Every single kiss has been Amazing\.\. Everything we have "done" has been and felt Amazing\.\. and felt like an emotional explosion\.  Sitting with you watching TV, helping you clean, watching you from across the room\.\. because why not I can\.  Every time I look at you I feel nothing but love, or sadness\.\. when we cannot be together\.  I would be the one to lose you Mer not the other way around \- not kidding\.


**495.** `21:50` **You**

I don't know even what there would be to get bored of\.  I don't think I could\.  I cannot stop thinking about you even if I want to\.\. even when I was with you\.


**496.** `21:50` **You**

Now that needs to get under control\.\. lol but I cannot see me ever getting bored\.


**497.** `21:51` **Meredith Lamb (+14169386001)**

Get bored of me beating you\.

*📎 1 attachment(s)*

**498.** `21:51` **You**

>
As much as I hate these next few months\.\. and I do\.\. I told you\.\. I don't doubt that I will spend the rest of my days with you if you will have me\.

*💬 Reply*

**499.** `21:52` **You**

>
mmmm\.\.\. I want you to enjoy these wins\.\.

*💬 Reply*

**500.** `21:52` **Meredith Lamb (+14169386001)**

>
lol

*💬 Reply*

**501.** `21:52` **Meredith Lamb (+14169386001)**

They won’t last long?


**502.** `21:52` **You**

nope


**503.** `21:52` **You**

nope nope nope


**504.** `21:53` **You**

What do you think\.


**505.** `21:53` **You**

btw


**506.** `21:53` **You**

Think it will last?
I worry you will get bored of me
lol
Not kidding
6m


**507.** `21:53` **You**

let me throw it back


**508.** `21:54` **You**

I don't think you are as confident or as certain as I am\.\. you are more hope I am more I will make my own future\.


**509.** `21:54` **Meredith Lamb (+14169386001)**

I find it incredibly odd that we had bath resigned ourselves to living alone and then all of a sudden


**510.** `21:54` **Meredith Lamb (+14169386001)**

It causes me to worry at times


**511.** `21:55` **Meredith Lamb (+14169386001)**

However I don’t when I’m with you


**512.** `21:55` **You**

>
why\.

*💬 Reply*

**513.** `21:55` **You**

it proves the point


**514.** `21:55` **Meredith Lamb (+14169386001)**

I just wonder if it is some reaction to separation/divorce\. It doesn’t feel like it but maybe we are naive\.


**515.** `21:56` **You**

ok\.\. so you have dodged the questions again\.\. I think given this clarification\.\. my statement is accurate \- "don't think you are as confident or as certain as I am\.\. you are more hope I am more I will make my own future\." \.\. unless you want to provide a different answer\.\.


**516.** `21:57` **You**

You are thinking too much\.\. which is usually my problem\.\. and it is usually how all my relationships worked\.\. when I changed\.\. I am being led by my heart here\.\. and I am going to just let it ride\.


**517.** `21:57` **You**

well after the next few months\.\. right now I want to put it in a box


**518.** `21:58` **You**

and step on the box


**519.** `21:58` **You**

repeatedly


**520.** `21:59` **Meredith Lamb (+14169386001)**

>
I am confident in how I feel about you and my attraction to you\. Was never this attracted to Andrew\. I’m not lying and there are various ways I know that as true\. I worry a bit more about you than me lol

*💬 Reply*

**521.** `21:59` **Meredith Lamb (+14169386001)**

Just because maybe you are rebounding hard


**522.** `21:59` **You**

>
you think once this is all done and cleaned up\.\. you think I'll feel different\.\.\. I won't  but I think you will\.  I already told you that the other night\.\. I am just hoping it doesnt happen\.

*💬 Reply*

**523.** `22:00` **You**

This isn't a rebound\.\. it is a revelation\.


**524.** `22:00` **You**

I think craig says this "It is like a come to jesus moment"  like I never realized\.\. A rebound is me feeling lonely and looking to fill a hole\.


**525.** `22:01` **You**

The only\.\. yeah ok\.\. not saying that\.\. The loneliness I am trying to alleviate is my loneliness from you\.  I was fine before you came along and blew up my world\.


**526.** `22:01` **You**

I wasn't looking to rebound or to meet anyone\.


**527.** `22:02` **Meredith Lamb (+14169386001)**

Same…\. That’s for damn sure\.


**528.** `22:02` **Meredith Lamb (+14169386001)**

I was getting ready to throw a “to hell with men” party


**529.** `22:02` **Meredith Lamb (+14169386001)**

lol


**530.** `22:02` **You**

well I wasn't there\.\.


**531.** `22:02` **Meredith Lamb (+14169386001)**

Not sure what happened


**532.** `22:02` **You**

but I sure as hell was not in a hurry


**533.** `22:02` **You**

and I had zero confidence


**534.** `22:03` **You**

so wasn't planning on looking anytime soon


**535.** `22:04` **Meredith Lamb (+14169386001)**

Just looking at my calendar


**536.** `22:04` **You**

Listen\.\. I am not worried about 4 months from now, or next year, or whenever\.\. at least not for me\.\. Again I cannot predict where you go or what you feel\.\. only that I want to do the best I can to be the only one you ever want to be with\.


**537.** `22:04` **Meredith Lamb (+14169386001)**

I’m having a catch up with Haris g at 1pm to tell him \(not about you\)


**538.** `22:04` **You**

I am worried about 2 weeks from now lol\.


**539.** `22:04` **You**

well that should be an interesting conversation


**540.** `22:05` **Meredith Lamb (+14169386001)**

Yeah…\.


**541.** `22:05` **You**

I blocked my calendar\.


**542.** `22:05` **You**

except for a few time slots this aft\.\. but you are opposite those so it works out well\.


**543.** `22:06` **Meredith Lamb (+14169386001)**

So when you called me honesty “stark” or whatever, what did you mean?


**544.** `22:07` **Meredith Lamb (+14169386001)**

I think you are more honest than me really


**545.** `22:07` **You**

It isn't more or less


**546.** `22:07` **You**

it is the delivery


**547.** `22:07` **Meredith Lamb (+14169386001)**

I would say you are more that than me


**548.** `22:07` **You**

it is very matter of factly\.


**549.** `22:07` **Meredith Lamb (+14169386001)**

Oh I see, yeah I guess lol


**550.** `22:07` **You**

You will say something that is true\.\. but I might frame it differently depending on who I am saying it to\.


**551.** `22:08` **You**

or how I think they will receive it\.


**552.** `22:08` **Meredith Lamb (+14169386001)**

\(Pauline\)


**553.** `22:08` **You**

everyone


**554.** `22:08` **Meredith Lamb (+14169386001)**

lol


**555.** `22:08` **You**

That is how I deal with everyone


**556.** `22:08` **You**

give me a second\.


**557.** `22:15` **You**

just doing a little analysis


**558.** `22:15` **Meredith Lamb (+14169386001)**

Looks like I’m on my own next weekend with the 8 girls


**559.** `22:16` **Meredith Lamb (+14169386001)**

Just learned\. It’s ok


**560.** `22:16` **You**

why I thought you were getting help


**561.** `22:16` **Meredith Lamb (+14169386001)**

I just won’t be able to drink bc I will need to drive if there is an emergency… so it is actually a good thing\. I need to smarten up for a bit\.


**562.** `22:17` **Meredith Lamb (+14169386001)**

>
Marlowe has another beach volleyball tourn, Maelle has work…

*💬 Reply*

**563.** `22:17` **Meredith Lamb (+14169386001)**

It’s good \- I’d rather be by myself honestly


**564.** `22:17` **Meredith Lamb (+14169386001)**

I will have fun with the girls


**565.** `22:18` **You**

I am sure you will\.


**566.** `22:19` **You**

>
ROFL

*💬 Reply*

**567.** `22:19` **You**

>
I can't lol \.\.

*💬 Reply*

**568.** `22:20` **Meredith Lamb (+14169386001)**

What


**569.** `22:20` **Meredith Lamb (+14169386001)**

Stop


**570.** `22:20` **Meredith Lamb (+14169386001)**

lol


**571.** `22:20` **Meredith Lamb (+14169386001)**

You don’t believe in me?


**572.** `22:20` **You**

HAHAHAH


**573.** `22:20` **You**

are you kidding me\.


**574.** `22:21` **Meredith Lamb (+14169386001)**

LOL


**575.** `22:20` **You**

that is what you think


**576.** `22:21` **You**

Ok\.\. rewind\.\.


**577.** `22:21` **You**

earlier today\.\. I gotta get my shit together\.\. etc etc \.\.\.


**578.** `22:21` **Meredith Lamb (+14169386001)**

If something happens to one of the girls I have to drive to hospital in Huntsville\. I cannot be drunk


**579.** `22:21` **You**

first thing you observe about the situation\.


**580.** `22:21` **You**

damn I can't drink


**581.** `22:21` **Meredith Lamb (+14169386001)**

lol


**582.** `22:21` **You**

ROFLROFL RO


**583.** `22:21` **You**

fbjvsdvbsjlb


**584.** `22:22` **Meredith Lamb (+14169386001)**

Well no more thc is getting my shit together FIRST


**585.** `22:22` **Meredith Lamb (+14169386001)**

Primarily


**586.** `22:22` **You**

AHHH\.\.


**587.** `22:22` **You**

so clarity


**588.** `22:22` **You**

this is a step by step process


**589.** `22:22` **Meredith Lamb (+14169386001)**

Now you are getting it


**590.** `22:22` **You**

I mean\.\. it would be like too much to just go clean right away\.\. I get it\.


**591.** `22:23` **Meredith Lamb (+14169386001)**

I will be next weekend\!


**592.** `22:23` **You**

10$ says a shit ton of thc this weekend\.


**593.** `22:23` **Meredith Lamb (+14169386001)**

What? No not even bringing any


**594.** `22:23` **You**

it will be there\.


**595.** `22:23` **You**

lol


**596.** `22:23` **Meredith Lamb (+14169386001)**

I need to be ready to drive


**597.** `22:23` **Meredith Lamb (+14169386001)**

I will be responsible for 8 girls


**598.** `22:23` **Meredith Lamb (+14169386001)**

It’s stressing me out


**599.** `22:24` **You**

there will be 9 girls there that weekend


**600.** `22:24` **Meredith Lamb (+14169386001)**

Mac says 8


**601.** `22:24` **Meredith Lamb (+14169386001)**

I thought 9


**602.** `22:24` **You**

9


**603.** `22:24` **Meredith Lamb (+14169386001)**

She says 8


**604.** `22:24` **You**

I say 9


**605.** `22:24` **You**

You\.\.


**606.** `22:24` **You**

gawd


**607.** `22:24` **Meredith Lamb (+14169386001)**

😜


**608.** `22:24` **You**

eesh


**609.** `22:25` **Meredith Lamb (+14169386001)**

I am not a girl, ADULT


**610.** `22:25` **You**

mmmmmmhmmmmm


**611.** `22:25` **Meredith Lamb (+14169386001)**

RESPONSIBLE ADULT IN CHARGE


**612.** `22:25` **Meredith Lamb (+14169386001)**

😇


**613.** `22:25` **You**

kk I stand by my statement\.\. and keeping expectations right where I think they should be\.


**614.** `22:25` **Meredith Lamb (+14169386001)**

You could come up and help me


**615.** `22:25` **You**

no


**616.** `22:25` **Meredith Lamb (+14169386001)**

Haha


**617.** `22:26` **Meredith Lamb (+14169386001)**

That was a quick no


**618.** `22:26` **You**

stark wasn't the word I should have used\.\. but the analysis did suggest that when faced with challenges or constraints\.\. your communication style and well\.\. behaviour\.\. can be very direct, abrupt, and practical\.


**619.** `22:26` **You**

your suggestion was a joke\.\. so the no was easy


**620.** `22:28` **You**

Reaction: 😂 from Meredith Lamb
anyhow I will monitor this shift to adulthood with interest\.  Like I said\.\. you shouldn't make promises\.


**621.** `22:28` **Meredith Lamb (+14169386001)**

It was a joke only because it would be risky\. Andrew feels guilty not going bc Mac wanted him there so might show up


**622.** `22:29` **You**

risky because there are 8 girls there\.\. Meredith\.\. I wasn't thinking about Andrew jesus\.


**623.** `22:29` **You**

you gonna keep me hidden in the boathouse?


**624.** `22:29` **You**

lol


**625.** `22:29` **Meredith Lamb (+14169386001)**

>
They wouldn’t care\.

*💬 Reply*

**626.** `22:29` **You**

holy shit\.\. no\.\. I wouldn't do that\.


**627.** `22:30` **You**

Someday yeah


**628.** `22:30` **You**

Reaction: 🙄 from Meredith Lamb
now \.\. absolutely not\.\.


**629.** `22:30` **Meredith Lamb (+14169386001)**

>
I think I communicate this way even when not challenged\.

*💬 Reply*

**630.** `22:31` **Meredith Lamb (+14169386001)**

Direct, abrupt and practical


**631.** `22:31` **Meredith Lamb (+14169386001)**

Wow


**632.** `22:31` **Meredith Lamb (+14169386001)**

lol


**633.** `22:31` **You**

well\.\. when you dismissed my attempts to connect\.\. a couple of times\.\. that was what I was trying to say earlier\.\. they don't mean anything to you\.\. or at least that is how it comes accross\.\. whereas they do for me\.


**634.** `22:31` **You**

you had asked for an example earlier\.


**635.** `22:31` **You**

it is why I said I was going to stop


**636.** `22:31` **You**

it is why I still think tomorrow  or tuesday is a bad idea


**637.** `22:31` **Meredith Lamb (+14169386001)**

It’s not that it doesn’t MEAN anything to me\. The logistics are more challenging for me than you\. You are up and awake and feeling great\. I’m asleep and in a fog\.


**638.** `22:32` **Meredith Lamb (+14169386001)**

Nope tomorrow I am getting up early and making my coffee


**639.** `22:32` **Meredith Lamb (+14169386001)**

lol


**640.** `22:32` **Meredith Lamb (+14169386001)**

Committed


**641.** `22:32` **You**

I think it feels like I want it more meredith\.\. I guess that is me being completely honest\.  kk\.\. nothing held back\.


**642.** `22:33` **Meredith Lamb (+14169386001)**

Want “it” more…


**643.** `22:33` **Meredith Lamb (+14169386001)**

Like this relationship?


**644.** `22:33` **You**

no no'


**645.** `22:33` **You**

fack


**646.** `22:33` **Meredith Lamb (+14169386001)**

You can’t make that assumption


**647.** `22:33` **Meredith Lamb (+14169386001)**

K good


**648.** `22:33` **You**

no no


**649.** `22:33` **You**

to be with you\.\. any way any time that I can\.


**650.** `22:33` **You**

anywhere lol


**651.** `22:33` **You**

even


**652.** `22:33` **You**

just that\.\. not the relationship


**653.** `22:34` **Meredith Lamb (+14169386001)**

Maybe, just maybe you have more morning energy than me and it is that simple\.


**654.** `22:34` **Meredith Lamb (+14169386001)**

But I am going to turn back into a morning person


**655.** `22:34` **You**

anyways\.\. I didn't want to dig into this\.\. not morning meredith\.\. morning\.\. after work\.\. anywhere any time\.


**656.** `22:34` **Meredith Lamb (+14169386001)**

It will take some time tho


**657.** `22:34` **You**

its fine\.\. I just want to be clear\.\. that is why I was pulling back\.


**658.** `22:35` **Meredith Lamb (+14169386001)**

I know…


**659.** `22:35` **Meredith Lamb (+14169386001)**

So what was your most recent analysis


**660.** `22:35` **You**

It isn't top of mind for you\.\. you don't have the same need I do\.\. or it affects you negatively\. as I learned\.\. it isn't just the morning thing\.\. it is feeling like I am desprate or begging etc


**661.** `22:35` **Meredith Lamb (+14169386001)**

🤔


**662.** `22:36` **Meredith Lamb (+14169386001)**

>
I absolutely have the same need\. You don’t realize the time spent thinking about you/us before bed, in the morning, watching tv, driving etc etc

*💬 Reply*

**663.** `22:36` **Meredith Lamb (+14169386001)**

It’s constant


**664.** `22:37` **Meredith Lamb (+14169386001)**

I just would prefer extended time


**665.** `22:37` **Meredith Lamb (+14169386001)**

But beggars can’t be choosers\. I know


**666.** `22:38` **You**

I get it\.\. I am not trying to make you feel anything or defend\.\. etc\.\. I just wanted to be completely honest\.\. there is nothing left to tell there now\.\. it is all out\.


**667.** `22:39` **Meredith Lamb (+14169386001)**

Well I’m glad you were honest\. Next time just be more abrupt, direct and practical 🙃


**668.** `22:40` **You**

If I were to do that\.\. it would come across as pushy and demanding\.


**669.** `22:40` **You**

so I will just try to give you everything early on\.\.


**670.** `22:41` **Meredith Lamb (+14169386001)**

I honestly don’t care if you are pushy and demanding sometimes\. Just not all the time\. You are allowed to be sometimes you know\.


**671.** `22:41` **Meredith Lamb (+14169386001)**

Just means I might be occasionally


**672.** `22:41` **Meredith Lamb (+14169386001)**

lol


**673.** `22:42` **You**

Yeah no\.\. I think I will stick with being cautious\.\. and hesitant\.\. I tried to explain to you how it feels to me earlier\.\. it isn't your fault\.\. but right now that is how I feel\.


**674.** `22:48` **Meredith Lamb (+14169386001)**

Cautious and hesitant is how you have to speak to me? 🙁


**675.** `22:48` **Meredith Lamb (+14169386001)**

Stoooooop


**676.** `22:51` **You**

it is\.\. I always think about what I say\.\. but I do that anyways\.\. I mean I am not just gonna throw out there


**677.** `22:51` **You**

hey let's do this and this maybe later\.\.


**678.** `22:52` **You**

lol


**679.** `22:52` **You**

the No's pile up I told you\.\. better to not hope, not ask, not expect


**680.** `22:52` **Meredith Lamb (+14169386001)**

But in terms of just speaking to me in general…\.


**681.** `22:53` **Meredith Lamb (+14169386001)**

Like not asking stuff


**682.** `22:53` **Meredith Lamb (+14169386001)**

The no’s have NOT piled up


**683.** `22:53` **Meredith Lamb (+14169386001)**

Btw


**684.** `22:53` **Meredith Lamb (+14169386001)**

They have not


**685.** `22:53` **Meredith Lamb (+14169386001)**

We have done a lot


**686.** `22:53` **Meredith Lamb (+14169386001)**

There have been a couple of no’s


**687.** `22:54` **You**

see\.\. this is why I don't do this\.\. lol I don't want to fight\.\. I wasn't talking about our weekends\.\. that have been magical\.\. but have happened out of suggestions you have made right\.


**688.** `22:54` **You**

all of them


**689.** `22:54` **You**

Our dates\.\. happened at your suggestion\.


**690.** `22:54` **You**

lol


**691.** `22:54` **Meredith Lamb (+14169386001)**

I’m not fighting\. Just saying practically


**692.** `22:54` **You**

I am not sure if you remember


**693.** `22:54` **Meredith Lamb (+14169386001)**

And they were all good suggestions


**694.** `22:55` **You**

I had a bigger hand in Detroit\.\. but when I say knows\.\. I say things I suggest or ask for Mer\.


**695.** `22:55` **You**

lol


**696.** `22:55` **Meredith Lamb (+14169386001)**

Rc show wasn’t me


**697.** `22:55` **You**

no's


**698.** `22:55` **You**

not knows


**699.** `22:55` **You**

like I am ok if you disagree\.\. it is all good\.\. I am overly sensitive we have established this


**700.** `22:56` **You**

I was just trying to explain what I mean by cautious and hesitant


**701.** `22:56` **Meredith Lamb (+14169386001)**

Just to be clear you are talking about g about the park stuff only right?


**702.** `22:56` **You**

yeah park or after work\.\. I think there were a few more things\.\. not sure\.\.


**703.** `22:57` **Meredith Lamb (+14169386001)**

k…


**704.** `22:57` **Meredith Lamb (+14169386001)**

I deleted some of that lol


**705.** `22:57` **You**

>
uh oh\.

*💬 Reply*

**706.** `22:57` **Meredith Lamb (+14169386001)**

Didn’t want to be too abrupt


**707.** `22:57` **Meredith Lamb (+14169386001)**

Haha


**708.** `22:57` **You**

yeah figured\.\.


**709.** `22:57` **You**

felt like a delete


**710.** `22:57` **You**

just be abrupt


**711.** `22:57` **You**

pls


**712.** `22:57` **You**

in this situation it won't bother me\.


**713.** `22:58` **Meredith Lamb (+14169386001)**

I was just going to give an excuse and I’d rather not\. I think your feelings on this are completely normal


**714.** `22:58` **Meredith Lamb (+14169386001)**

And you aren’t being overly sensitive


**715.** `22:58` **You**

why not the excuse


**716.** `22:59` **Meredith Lamb (+14169386001)**

I’m actually happy that you want to spend time together


**717.** `22:59` **Meredith Lamb (+14169386001)**

Would suck if you didn’t


**718.** `23:00` **You**

I know\.\. and I will continue to want to\.\. but I am not going to ask anymore\.\. I told you that Thursday\.\. or at least tried to tell you\.\. you were in a mode on Thursday\.


**719.** `23:00` **Meredith Lamb (+14169386001)**

My brother is an ass\.

*📎 1 attachment(s)*

**720.** `23:01` **Meredith Lamb (+14169386001)**

I was…


**721.** `23:02` **Meredith Lamb (+14169386001)**

I felt something building, coming and then bam, woke up the next morning to it


**722.** `23:03` **You**

kk well like I said\.\. don't take my lack of asking the wrong way\.\. my cautious and hesitant approach continues\.


**723.** `23:03` **You**

glad we are in agreement


**724.** `23:03` **You**

:\)


**725.** `23:03` **Meredith Lamb (+14169386001)**

>
I was going to say after work is near impossible for me bc of kids and driving etc\. and then it felt like an excuse\. Because it probably is…

*💬 Reply*

**726.** `23:03` **You**

that was easy


**727.** `23:03` **You**

oh shit\.\. the analysis


**728.** `23:04` **Meredith Lamb (+14169386001)**

Andrew keeps packing our schedule with more volleyball


**729.** `23:04` **You**

wait I have to cross reference


**730.** `23:04` **Meredith Lamb (+14169386001)**

He comes in and is like Marlowe has some vball thing thurs


**731.** `23:04` **Meredith Lamb (+14169386001)**

Why tell me?\!


**732.** `23:04` **Meredith Lamb (+14169386001)**

I will be at cottage


**733.** `23:05` **Meredith Lamb (+14169386001)**

I was all “why do you commit to things when you don’t even know if YOU can go?” He thinks I can do everything and just jump when told


**734.** `23:05` **Meredith Lamb (+14169386001)**

So my after work nights are a mess right now


**735.** `23:05` **Meredith Lamb (+14169386001)**

So unpredictable and I get told to just drive here and there


**736.** `23:06` **Meredith Lamb (+14169386001)**

Tonight I get told Maelle is on some team in June now and I’m like “why can’t we have a break?\!”


**737.** `23:06` **Meredith Lamb (+14169386001)**

Omg


**738.** `23:06` **Meredith Lamb (+14169386001)**

It’s so annoying


**739.** `23:06` **Meredith Lamb (+14169386001)**

>
Cross reference what?

*💬 Reply*

**740.** `23:06` **You**

kk I can appreciate that\.\.


**741.** `23:07` **You**

just something I was looking into\.


**742.** `23:11` **You**

kk I think it is bed time\.


**743.** `23:10` **Meredith Lamb (+14169386001)**

Which was…\.


**744.** `23:13` **You**

I was looking at our back and forth engagements over the last few months\.


**745.** `23:14` **Meredith Lamb (+14169386001)**

k you can tell me about it in the morning :\) message me time and address\.


**746.** `23:14` **Meredith Lamb (+14169386001)**

I should go to bed too


**747.** `23:14` **You**

Okay, I've gone through your conversation with Meredith to identify and count the instances where you suggested connecting \(meeting, talking, etc\.\) and her response could be categorized as a rebuff \(a "no" to your immediate request, even if with a reason\) or non\-committal \(vague, deflecting, or an indefinite postponement\)\.
Here are the instances documented in chronological order:
Monday, April 14, 2025 \(\[snippet\_3\]\)
Your Suggestion: You asked if she was busy tomorrow and stated, "I want to see you\."
Meredith's Initial Response: "Depends," and then "You do? Why\."
Analysis: Her initial responses were probing and could be perceived as non\-committal or making you justify your desire before she eventually said, "I want to see you too\. No plans yet\." While this ultimately led to a positive indication for meeting, the initial replies were not a straightforward affirmation\.
Tuesday, April 15, 2025 \(\[snippet\_4\]\)
Your Suggestion: After she expressed it was hard not to see you, you offered, "I can come see you if you like\."
Meredith's Response: "No it’s okay\. I’m with my parents and they are asking questions\. Lol\."
Wednesday, April 30, 2025 \(\[snippet\_35\]\)
Your Suggestion: "So do you think there is any chance we can see each other anytime soon for any length of time at all?"
Meredith's Response: "Ugh I don’t know\. This week is bad for me\. But maybe next week?\.\.\. I will try\."
Saturday, May 3, 2025 \(\[snippet\_36\]\)
Your Suggestion: "I was hoping we could go for dinner tonight\.\.\."
Meredith's Response: She confirmed it wasn't possible as she was attending a family event with Andrew, her estranged partner\.
Saturday, May 3, 2025 \(\[snippet\_36\]\)
Your Suggestion: "Maybe chat later\."
Meredith's Response: She sent pictures of her niece and a Spotify link, changing the subject without confirming a chat\.
Friday, May 9, 2025 \(\[snippet\_31\]\)
Your Suggestion: "Any chance I can see you tonight? Even for a little while\."
Meredith's Response: "I don’t think so\. I have Mac\. And I’m super tired\. Maybe tomorrow?"
Monday, May 12, 2025 \(\[snippet\_38\]\)
Your Suggestion: "I need to see you in person\."
Meredith's Response: "I know\. This week is bad though… I’m not going into the office at all\. Andrew has the kids\.\.\. Maybe \[next week\]\."
Wednesday, May 14, 2025 \(morning\) \(\[snippet\_33\]\)
Your Suggestion: "Can I see you today"
Meredith's Response: "I don’t know\. Today is crazy for me\. Maybe after work for a bit?\.\.\. K lemme see how today goes\."
Wednesday, May 14, 2025 \(afternoon\) \(\[snippet\_33\]\)
Your Suggestion: \(Following up on the morning's non\-committal response\) "So did you want to try to meet up briefly or are you too tired\."
Meredith's Response: "I’m at my parents\. And I have Mackenzie\."
Sunday, May 18, 2025 \(\[snippet\_28\]\)
Your Suggestion: "Are you sure you don't want to see me tonight?"
Meredith's Response: "I can’t\. I have my kids\."
Monday, May 19, 2025 \(\[snippet\_40\]\)
Your Suggestion: After a tough day for you, you asked, "\.\.\.Feel like talking or seeing me?"
Meredith's Response: She replied, "I’m okay\. Just tired\. You?" but didn't directly address the "talking or seeing me" part of your question\.
Saturday, May 24, 2025 \(\[snippet\_43\]\)
Your Suggestion: "Did you want to talk this morning"
Meredith's Response: "Yes\. But I feel like death\."
Count:
Based on this documentation, there are 12 distinct instances where you suggested connecting and her response was either a rebuff for the requested time or non\-committal\.
It's important to note that in many of the "rebuff" instances, Meredith provided clear reasons related to her children, prior commitments, or logistics\. The "non\-committal" responses often involved vague future possibilities or deflections\.


**748.** `23:14` **You**

you can read it\.\. I am going to bed too\.\.


**749.** `23:14` **You**

it isn't super accurate I think\.\.


**750.** `23:16` **You**

Terraview Park Park on side of road after bridge near Caevhill Crescent\.


**751.** `23:16` **You**

I will likely be there before 8 am not sure how much\.\. but you can just get there whenever\.


**752.** `23:18` **You**

This is when I run away


**753.** `23:18` **You**

zzzzzzzzzz


**754.** `23:18` **Meredith Lamb (+14169386001)**

Wow I don’t even remember some of those


**755.** `23:18` **You**

I remember all of them


**756.** `23:18` **You**

lol


**757.** `23:18` **Meredith Lamb (+14169386001)**

k, we can address this later\. Lol


**758.** `23:18` **You**

sure we can


**759.** `23:18` **You**

you know


**760.** `23:18` **You**

the next time I do this analysis\.\. it is going to pick up on your response as another deflection


**761.** `23:18` **You**

Reaction: 😂 from Meredith Lamb
just saying lol


**762.** `23:19` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**763.** `23:19` **Meredith Lamb (+14169386001)**

Mon may 12 you asked this?\!


**764.** `23:20` **Meredith Lamb (+14169386001)**

That confuses me and it isn’t the only one


**765.** `23:20` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**766.** `23:20` **Meredith Lamb (+14169386001)**

Another confusing one


**767.** `23:21` **You**



**768.** `23:21` **You**

read that\.\. it is an actual


**769.** `23:21` **You**

chat


**770.** `23:22` **Meredith Lamb (+14169386001)**

k, will go to bed and talk later\. I need to look at my calendar and reconcile some of this lol


**771.** `23:23` **Meredith Lamb (+14169386001)**

>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
I do remember this one

*💬 Reply*

**772.** `23:24` **Meredith Lamb (+14169386001)**

I get your point now…\.


**773.** `23:26` **Meredith Lamb (+14169386001)**

k go to bed now \- you have to get up early


**774.** `23:26` **You**

I love you Mer\.\. I wish I wasn't like this\.\. have a good night


**775.** `23:26` **Meredith Lamb (+14169386001)**

I love you too and I like you the way you are xoxoxo


