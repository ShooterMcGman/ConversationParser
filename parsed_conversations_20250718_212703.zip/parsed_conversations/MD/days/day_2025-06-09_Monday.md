# Daily Conversation: 2025-06-09 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-09 |
| **Day** | Monday |
| **Week** | 9 |
| **Messages** | 295 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-09T04:12 - 2025-06-09T23:07 |

## 📝 Daily Summary

This day contains **295 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:12` **You**

Edited: 2 versions
| Version: 2
| Sent: Mon, 9 Jun 2025 04:12:24 \-0400
|
| Morning luv xoxoxoxo hope you enjoy your workout this morning kick the shit out of it eh\.
|
| Version: 1
| Sent: Mon, 9 Jun 2025 04:12:06 \-0400
|
| Morning luv xoxoxoxo hope you enjoy your workout this morningzz kick the shit out of it eh\.


**002.** `04:13` **You**

Reaction: ❤️ from Meredith Lamb
Oh my legs feel like they were hit by a bus that is how I know it was good yesterday lol\. 😂


**003.** `04:14` **You**

Even though you don’t work for me and I cannot really talk to you I am very much looking forward to just seeing you at work\.  Just know that while I will be as
Professional as ever
I will still be thinking unprofessional things…\. 😇\.


**004.** `05:45` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
Same, very much the same\. 😋

*💬 Reply*

**005.** `05:46` **You**

Morning\.\. have a good one\!


**006.** `06:10` **Meredith Lamb (+14169386001)**

>
Going to try\. Working with “more regular” weight once my coffee sets in\. Lol

*💬 Reply*

**007.** `06:10` **Meredith Lamb (+14169386001)**

Hope you had a good morning:\)


**008.** `06:10` **You**

Reaction: ❤️ from Meredith Lamb
Still going\.\. heavy today fun\.


**009.** `06:13` **Meredith Lamb (+14169386001)**

I can’t find 10s… only 15s and up\. 😬


**010.** `06:13` **You**

Uh oh


**011.** `06:13` **You**

lol


**012.** `06:13` **You**

Maybe drop reps to 25% fewer at higher weight


**013.** `06:14` **You**

😛


**014.** `06:14` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
We will see\. Lol


**015.** `06:20` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
It’s going to take me about 3 weeks to get used to mornings again\. Lol this shirt helps and I got head bands again to keep my glasses on for burpees so today will be less annoying\. :p

*📎 1 attachment(s)*

**016.** `06:21` **You**

lol


**017.** `06:21` **You**

I will give you a photo at end


**018.** `06:22` **You**

Have I told you you are awesome enough yet?  You are gonna crush it just positive attitude


**019.** `06:29` **You**

Reaction: 😮 from Meredith Lamb
Pushing this fucker back and forth for 14 mins to finish\.

*📎 1 attachment(s)*

**020.** `06:44` **You**

Done that push sucked at the end

*📎 1 attachment(s)*

**021.** `06:45` **You**

Sauna shower time then a nice walk chat
Later


**022.** `06:45` **You**

Cya at work


**023.** `06:48` **Meredith Lamb (+14169386001)**

Trying, struggling and really horrible form until I get stronger tris\. Probably take 4 weeks … sigh\. Mine is going to take longer this morning bc of heavier weight\.

*📎 1 attachment(s)*

**024.** `06:48` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/6Aq8FRLvUNzBNCgCQ3PsXT?si=mNZQariFTSm4wVlhTgF\-Gg
Never heard this one until this morning\.


**025.** `06:49` **You**

>
Just do the best you can don’t get discouraged\.  You are
Coming back after a long time\.\. it will take some time hon\.\. but you are doing it\!\! Trying\! Al that matters\.

*💬 Reply*

**026.** `06:49` **You**

>
>
I heard this I like it\.

*💬 Reply*

**027.** `06:51` **You**

https://open\.spotify\.com/track/0EKBV6GybPtALXUgWqWrym?si=evLdKcBBStiQW9bVZ5ae0g
This song rings a lot more true to me now after the past few weeks\.


**028.** `06:51` **You**

❤️


**029.** `06:57` **Meredith Lamb (+14169386001)**

These are the tris I need\. You look at Henry\. I’m just going to look at myself lol

*📎 1 attachment(s)*

**030.** `06:57` **You**

Shiiiiiit


**031.** `06:58` **You**

Yeah those are some tris…


**032.** `06:58` **You**

And the don’t fuck with me look/stance 😀


**033.** `07:00` **You**

I will ☺️

*📎 1 attachment(s)*

**034.** `07:02` **You**

I mean I can get here for sure\.

*📎 1 attachment(s)*

**035.** `07:02` **Meredith Lamb (+14169386001)**

>
Um, whoah

*💬 Reply*

**036.** `07:02` **You**

That was pre super man


**037.** `07:03` **You**

The immortals


**038.** `07:03` **You**

Reaction: 👍 from Meredith Lamb
We can watch it together will see if you can get through it


**039.** `07:27` **Meredith Lamb (+14169386001)**

Took me an hour lol


**040.** `07:33` **You**

Worth you finished


**041.** `07:43` **You**

Kk heading in see you when you get in


**042.** `07:44` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
>
Baby steps :\)

*💬 Reply*

**043.** `08:29` **Meredith Lamb (+14169386001)**

This morning, I’m gonna try to start taking half of the Ciprolex so like 5 mg then I don’t feel so bleh for working out too


**044.** `08:29` **You**

Just be careful


**045.** `08:30` **Meredith Lamb (+14169386001)**

My dr said not to go off bc of the separation so I will just try half\.


**046.** `08:30` **Meredith Lamb (+14169386001)**

I won’t go off


**047.** `08:31` **Meredith Lamb (+14169386001)**

I don’t think I’ll be able to get back to how I was on it\. It is very meh


**048.** `08:31` **You**

Kk


**049.** `08:36` **You**

Well I mean once the separation agreement is done you could try to ween yourself off\.\. I am going to be working to go half on my blood pressure meds


**050.** `08:48` **You**

Jim was mad at me I cannot do that again…


**051.** `09:01` **Meredith Lamb (+14169386001)**

Mad at you??


**052.** `09:01` **You**

Yeah because I pinged him on the weekend it went off too early any ways it’s on me I said I wouldn’t do it again\.\.


**053.** `09:02` **You**

Honestly wasn’t thinking\.\.


**054.** `09:03` **Meredith Lamb (+14169386001)**

lol what time was it?


**055.** `10:08` **You**

6:15 am


**056.** `10:08` **You**

Oops


**057.** `10:08` **You**

I thought he would have on silent for some reason


**058.** `10:09` **You**

Trying to move offices today btw


**059.** `11:28` **Meredith Lamb (+14169386001)**

Yeah I’m surprised he didn’t have it on silent either lol


**060.** `11:28` **Meredith Lamb (+14169386001)**

>
Honestly for work purposes it probably makes sense

*💬 Reply*

**061.** `11:33` **You**

For all purposes


**062.** `11:33` **Meredith Lamb (+14169386001)**

Oh stop


**063.** `11:34` **You**

Dead serious


**064.** `11:36` **Meredith Lamb (+14169386001)**

Not working together should be enough I think\. You will see in time


**065.** `11:38` **You**

Nope I would go to other building if I could


**066.** `11:38` **Meredith Lamb (+14169386001)**

Ps\. Ahana is feeling very lost today so you might need to do a bit extra for her going forward until a new supe in place\. She keeps coming to me for stuff and I told her she can continue to but just be aware\. She is feeling diff than the others\.


**067.** `11:39` **Meredith Lamb (+14169386001)**

I told her I’m not going anywhere and she can always talk to me but still, just realize she is a bit insecure\.


**068.** `11:45` **You**

Kk but you still got this until the end of next week right\.\. lol


**069.** `11:45` **You**

You do remember lol


**070.** `11:46` **You**

But I will talk to her


**071.** `11:46` **Meredith Lamb (+14169386001)**

Yes of course\. I told the team that


**072.** `11:46` **You**

Kk thx\!


**073.** `11:46` **Meredith Lamb (+14169386001)**

Just a little heads up


**074.** `11:46` **Meredith Lamb (+14169386001)**

She is much more insecure than the rest of the team


**075.** `11:46` **You**

Yeah I will give her some reassurance I have noticed that in the past


**076.** `11:46` **You**

She reminds me of me


**077.** `13:06` **You**

Hey looked a bit down at the end of
Our chat\.\. you know I am willing to wait if you are right\.\. for whenever we can evolve or whatever you want to call it\.  You just looked a bit dismayed\.


**078.** `13:23` **Meredith Lamb (+14169386001)**

I wasn’t dismayed\. It is always just a reality check whenever we mention the “when” in terms of being together finally\. That’s all\. Not a big deal\.


**079.** `13:24` **Meredith Lamb (+14169386001)**

It’s the reality which is ok\.


**080.** `13:24` **Meredith Lamb (+14169386001)**

❤️


**081.** `13:25` **You**

Ok as long as you are ok\.\. you just looked a bit overwhelmed or disappointed or based on yesterday I thought maybe worried that I wouldn’t stick around that long\.\. just wanted to provide
Reassurance\.


**082.** `13:26` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
No, I’m good\. 🙂


**083.** `16:48` **Meredith Lamb (+14169386001)**


*📎 4 attachment(s)*

**084.** `16:50` **You**

Wow


**085.** `16:50` **You**

That interesting


**086.** `16:52` **Meredith Lamb (+14169386001)**

Where is that email re: Erin?


**087.** `16:53` **You**

Check your teams yah good


**088.** `16:53` **You**



**089.** `16:53` **You**

Goof


**090.** `16:54` **You**

Feel free to mock me here


**091.** `16:57` **You**

https://open\.spotify\.com/track/0uRrG2jRR5tuifsYIJHEao?si=C2vK888mQdWV\_Pip3jfn2g&context=spotify%3Aplaylist%3A37i9dQZF1DZ06evO2zJOi2


**092.** `16:57` **You**

Like this one


**093.** `17:00` **Meredith Lamb (+14169386001)**

So talked to rod about the role\. He is going to talk to you\. Man he loves you


**094.** `17:00` **Meredith Lamb (+14169386001)**

lol sick


**095.** `17:00` **You**

Why does it bother you that people like me so much


**096.** `17:00` **You**

I am a nice guy


**097.** `17:00` **Meredith Lamb (+14169386001)**

So after you talked to caraolyn this afternoon at her desk and left, she looked at me and goes “does he seem narrower?”


**098.** `17:00` **Meredith Lamb (+14169386001)**

LOL


**099.** `17:00` **You**

ROFL


**100.** `17:00` **You**

Honestly


**101.** `17:01` **You**

Took 32
Lbs


**102.** `17:01` **You**

Packing up to head out\.\. not sure what you doing but I guess we’ll chat later as per usual 🙄


**103.** `17:02` **Meredith Lamb (+14169386001)**

>
I KNOW\!

*💬 Reply*

**104.** `17:02` **Meredith Lamb (+14169386001)**

Why do you want to do something?


**105.** `17:03` **You**

I would but what I don’t have to go home yet\.


**106.** `17:04` **You**

1st time you asked that\.\. had no response\.\.


**107.** `17:07` **Meredith Lamb (+14169386001)**

Talking to Carolyn


**108.** `17:08` **You**

Kk only thing I could think of is stop at park on way home if you want to sit for a few\.\. sry no other ideas


**109.** `17:08` **Meredith Lamb (+14169386001)**

She goes “am I making him nervous? I was in talking to him and he just starts eating bars”


**110.** `17:09` **Meredith Lamb (+14169386001)**

I’m like “no you are not\. He’s just working out a lot\.”


**111.** `17:09` **Meredith Lamb (+14169386001)**

She goes “I’m not? Ok good”


**112.** `17:09` **You**

lol it was a protein bar omg


**113.** `17:09` **Meredith Lamb (+14169386001)**

LOL


**114.** `17:09` **Meredith Lamb (+14169386001)**

>
k, if we go now I can\. Otherwise too late

*💬 Reply*

**115.** `17:09` **You**

I can go now


**116.** `17:10` **Meredith Lamb (+14169386001)**

Sorry just checking if I have vball driving


**117.** `17:10` **Meredith Lamb (+14169386001)**

I don’t think I do but better check


**118.** `17:14` **Meredith Lamb (+14169386001)**

K I have nothing


**119.** `17:14` **You**

Kk


**120.** `19:21` **You**

Shadow ok?


**121.** `19:26` **Meredith Lamb (+14169386001)**

Didn’t say a word \(bc I’m making her dinner\)


**122.** `19:26` **You**

lol


**123.** `19:27` **You**

Sorry


**124.** `19:27` **You**

I keep putting you in these dangerous situations\.\. I will be happy when everyone knows too\.


**125.** `19:28` **Meredith Lamb (+14169386001)**

Me toooooooooooooo omg


**126.** `19:31` **You**

It isn’t far off now


**127.** `19:31` **You**

Honestly


**128.** `19:31` **You**

Will fly by


**129.** `19:44` **Meredith Lamb (+14169386001)**

“Fly by” lol mm hmm


**130.** `19:45` **You**

Comeon… I am trying to be optimistic


**131.** `19:45` **You**

I thought you wanted me to be happy and positive


**132.** `19:45` **You**

lol


**133.** `19:49` **Meredith Lamb (+14169386001)**

Well it is nice for a change tbh :\)


**134.** `19:51` **You**

So let me happy and optimistic\.\.  I very much enjoyed sitting with you\.\. honestly I very much enjoy everything with you\.\. 🥰


**135.** `19:54` **Meredith Lamb (+14169386001)**

Me too which is why it sucks to be apart right now\. But I will turn happy and optimistic too… maybe\. lol


**136.** `19:56` **You**

Mer it does suck\.\. but honestly when we are together it is so good\.\. I mean as long as it takes\.\. it won’t be years I feel like it won’t be we can figure something out\.


**137.** `19:59` **Meredith Lamb (+14169386001)**

I know, I honestly am confident that we will figure it out\. Just a little annoying in the meantime\. I think I will feel better when mediation actually starts\. Gahhh


**138.** `19:59` **Meredith Lamb (+14169386001)**

Feel in purgatory


**139.** `20:00` **You**

Yeah does feel I like that\.\. but it will come faster than you think\.


**140.** `20:01` **You**

I will be doing everything I can in the meantime to accelerate my own situation, talked to Jaimie about it tonight\.


**141.** `20:02` **Meredith Lamb (+14169386001)**

How can you possibly accelerate?


**142.** `20:02` **Meredith Lamb (+14169386001)**

Yours seems set in motion


**143.** `20:02` **You**

The day that she leaves


**144.** `20:02` **You**

I will likely take another week off


**145.** `20:03` **You**

And work with renovators to smash through the house fixes that needs to be done and get it staged and in the market by august if possible


**146.** `20:03` **You**

Will get a better price if I can


**147.** `20:03` **Meredith Lamb (+14169386001)**

Before school yeah


**148.** `20:04` **You**

So that is my goal\.\.


**149.** `20:04` **You**

I get there even more freedom\.


**150.** `20:05` **Meredith Lamb (+14169386001)**

When I read “freedom” I thought of Braveheart lol


**151.** `20:06` **You**

ROFL


**152.** `20:06` **You**

Grew ending


**153.** `20:07` **You**

Great


**154.** `20:15` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**155.** `20:16` **You**

Omfg


**156.** `20:17` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**157.** `20:19` **You**

Are you considering?


**158.** `20:19` **Meredith Lamb (+14169386001)**

No


**159.** `20:20` **You**

She will likely figure out how to get one


**160.** `20:20` **Meredith Lamb (+14169386001)**

The guy at the gym last night asked if she was 18\. I’m like “wtf would i be here if she was 18?”


**161.** `20:20` **Meredith Lamb (+14169386001)**

🙄


**162.** `20:20` **You**

Hahaha


**163.** `20:20` **You**

Bet she loved that


**164.** `22:03` **You**

I am going to be up for quite a while I assume you are likely going to bed soon eh


**165.** `22:08` **Meredith Lamb (+14169386001)**

I watched a little tv and yeah will likely go to bed soon\. Going to try to get up earlier tomorrow


**166.** `22:08` **Meredith Lamb (+14169386001)**

Also I’m tiiiired\. Feel bad you have to stay up so late :\(


**167.** `22:09` **You**

Yeah it sucks\.\. wish I didn't have to pick her up\.\. booo\.\.


**168.** `22:10` **You**

Well I won't belabour it, I am sure you want to go to bed\.\. so I will just tell you I love you and will be thinking of you tonight\.  Going to still get up early tomorrow and hit it\.\. no choice\.


**169.** `22:11` **Meredith Lamb (+14169386001)**

Oh my \.\. you are going to be so 😴


**170.** `22:11` **You**

nah will be fine


**171.** `22:11` **Meredith Lamb (+14169386001)**

I just read over our April 12 texts bc I was curious


**172.** `22:11` **Meredith Lamb (+14169386001)**

Funny


**173.** `22:11` **You**

whyat is funny


**174.** `22:11` **Meredith Lamb (+14169386001)**

Well, not funny


**175.** `22:12` **You**

I don't have those\. only you do


**176.** `22:12` **Meredith Lamb (+14169386001)**

Just seems like so long ago, but it isn’t so long ago


**177.** `22:12` **You**

yeah this relationship has advanced into something more like years in months\.


**178.** `22:16` **You**

wish there was an easy way to export all of those texts\.


**179.** `22:18` **Meredith Lamb (+14169386001)**

Hm I just tried and it didn’t work


**180.** `22:18` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**181.** `22:19` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**182.** `22:19` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**183.** `22:19` **You**

fyi there were suspicions


**184.** `22:19` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**185.** `22:20` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**186.** `22:20` **Meredith Lamb (+14169386001)**

So that is all the after part\. The before stuff is long and logistical related


**187.** `22:20` **Meredith Lamb (+14169386001)**

>
Really?

*💬 Reply*

**188.** `22:21` **You**

Maddie


**189.** `22:21` **You**

Reaction: 😂 from Meredith Lamb
She was actually suspicious about sharon


**190.** `22:21` **You**

LOL


**191.** `22:22` **You**

>
I mean you could tell even then the feelings were pretty crazy for only having gone out once\.\.\. they were there before\.\. this whole thing is NUTS\.

*💬 Reply*

**192.** `22:23` **Meredith Lamb (+14169386001)**

I know, wild reading that back\.


**193.** `22:23` **You**

I fell so hard so fast\.


**194.** `22:23` **You**

still falling tbh\.\. no bottom


**195.** `22:23` **Meredith Lamb (+14169386001)**

Me too 🤯


**196.** `22:23` **You**

a few months\.\. that is what we have\.


**197.** `22:25` **You**

any plans 27th?


**198.** `22:25` **You**

or that weekend?


**199.** `22:25` **You**

just curious right now\.\. nothing specific\.\. but might have an opportunity\.\.


**200.** `22:26` **Meredith Lamb (+14169386001)**

What day of the week is the 27th


**201.** `22:26` **You**

friday


**202.** `22:30` **Meredith Lamb (+14169386001)**

So just checked calendar\. Maelle gets dropped off at GBC on Sat the 28th but we haven’t discussed who is taking her yet\. We never both go\. Her camp is on our lake


**203.** `22:30` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Mon, 9 Jun 2025 22:32:17 \-0400
|
| Road trip like to cottage or different one lol
|
| Version: 1
| Sent: Mon, 9 Jun 2025 22:30:56 \-0400
|
| Otherwise nothing on our calendar


**204.** `22:31` **You**

So\.\. maybe roadtrip?


**205.** `22:32` **Meredith Lamb (+14169386001)**

Weird I edited that by accident lol


**206.** `22:32` **You**

I mean we have some options\.


**207.** `22:32` **You**

We could do that\.


**208.** `22:33` **You**

Go up Friday come back Sunday if possible on your end


**209.** `22:33` **Meredith Lamb (+14169386001)**

I will see if Andrew is thinking of taking her


**210.** `22:33` **Meredith Lamb (+14169386001)**

If so I’m not going up


**211.** `22:33` **You**

So the other option


**212.** `22:33` **You**

Roadtrip


**213.** `22:33` **Meredith Lamb (+14169386001)**

Don’t feel like hanging out with him :p lol


**214.** `22:33` **You**

Well yeah I don't think the three of us would get along


**215.** `22:34` **Meredith Lamb (+14169386001)**

Unlikely


**216.** `22:34` **You**

So Haris invited me to Windsor end of June to visit clients\.


**217.** `22:34` **You**

26th/27th\. one or both days


**218.** `22:34` **Meredith Lamb (+14169386001)**

“Visit clients”


**219.** `22:34` **You**

no for real


**220.** `22:34` **You**

he did


**221.** `22:34` **Meredith Lamb (+14169386001)**

lol k


**222.** `22:35` **You**

28th I have been invited back to see John as he is getting ordained in Grand Rapids\.


**223.** `22:35` **You**

But we could skip the customer visits


**224.** `22:35` **You**

Haris would cover for me anyways


**225.** `22:35` **Meredith Lamb (+14169386001)**

lol


**226.** `22:36` **Meredith Lamb (+14169386001)**

>
Haris would do anything for you

*💬 Reply*

**227.** `22:37` **Meredith Lamb (+14169386001)**

Ok so obviously yes I would want to do something\. Just need to figure it out\.


**228.** `22:37` **Meredith Lamb (+14169386001)**

Will see what Andrew is thinking re: Maelle


**229.** `22:38` **Meredith Lamb (+14169386001)**

I normally take her so we will see


**230.** `22:38` **Meredith Lamb (+14169386001)**

She won’t care who takes her tho


**231.** `22:38` **You**

I mean if Andrew isn't well then that would put a crimp in it\.


**232.** `22:39` **You**

but again none of this is set in stone\.\. and it is no biggy if it doesn't work out honestly\.\. just an idea\.


**233.** `22:40` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**234.** `22:41` **You**

Ominous\.\.\.


**235.** `22:41` **You**

lol


**236.** `22:42` **Meredith Lamb (+14169386001)**

lol ominous?


**237.** `22:42` **You**

I mean\.\. I have never kept a weekend clear\.\. so I guess I don't understand


**238.** `22:42` **Meredith Lamb (+14169386001)**

Is it a long weekend?


**239.** `22:43` **You**

July 1st


**240.** `22:43` **You**

so yeah I guess


**241.** `22:43` **Meredith Lamb (+14169386001)**

Ah that’s why


**242.** `22:43` **Meredith Lamb (+14169386001)**

He will want to go


**243.** `22:43` **Meredith Lamb (+14169386001)**

He just means he kept it clear of volleyball


**244.** `22:43` **Meredith Lamb (+14169386001)**

Like beach and stuff


**245.** `22:44` **You**

ah ok\.\. well you might want to go with kids too if it is long weekend\./


**246.** `22:46` **You**

Ok listen I am keeping you up\.\. shit


**247.** `22:46` **You**

not my intent\.\.


**248.** `22:46` **You**

you should go to bed\.


**249.** `22:47` **Meredith Lamb (+14169386001)**

Funny I looked back to last year


**250.** `22:47` **Meredith Lamb (+14169386001)**

They all went up and I stayed home for some reason


**251.** `22:47` **Meredith Lamb (+14169386001)**

No idea why


**252.** `22:47` **You**

Again you might want to go with them\.\. wouldn't blame you if you did\.\.


**253.** `22:47` **You**

all good


**254.** `22:48` **Meredith Lamb (+14169386001)**

I stayed home and cleaned the house that weekend


**255.** `22:48` **Meredith Lamb (+14169386001)**

I wonder if I was mad at Andrew


**256.** `22:48` **You**

>
fun

*💬 Reply*

**257.** `22:48` **Meredith Lamb (+14169386001)**

Totally don’t remember


**258.** `22:48` **Meredith Lamb (+14169386001)**

So odd


**259.** `22:49` **Meredith Lamb (+14169386001)**

Was just going through photos


**260.** `22:50` **Meredith Lamb (+14169386001)**

>
I don’t want to hang out with Andrew for a whole weekend\. Good lord\.

*💬 Reply*

**261.** `22:50` **You**

yeah but you will want to hang out with your kids\.


**262.** `22:50` **You**

I didn't realize it was the long weekend


**263.** `22:50` **You**

my bad


**264.** `22:51` **Meredith Lamb (+14169386001)**

Maelle will be at camp\. Mac won’t want to be there\. Marlowe … she seemed fine in the photos from last year without me lol


**265.** `22:51` **Meredith Lamb (+14169386001)**

My main problem will be Mac not wanting to go\.


**266.** `22:53` **You**

>
how so?  just don't want her home alone LOL don't blame you

*💬 Reply*

**267.** `22:54` **Meredith Lamb (+14169386001)**

Exactly\. If Andrew is going I will need a story and not “I’m staying home”


**268.** `22:54` **Meredith Lamb (+14169386001)**

Because Mac will want to stay with me\.


**269.** `22:54` **Meredith Lamb (+14169386001)**

I could go visit friends back home or something … I dunno


**270.** `22:54` **Meredith Lamb (+14169386001)**

Could figure it out


**271.** `22:54` **You**

I would go visit friends back home\.


**272.** `22:55` **You**

lol j/k


**273.** `22:55` **Meredith Lamb (+14169386001)**

Or maybe I just tell them :p


**274.** `22:55` **You**

not for a long time I am guessing\.\. hehe


**275.** `22:55` **You**

you cannot


**276.** `22:55` **You**

not until separation agreement is done


**277.** `22:55` **Meredith Lamb (+14169386001)**

I know…………


**278.** `22:58` **You**

KK I think I overly engaged you on this\.


**279.** `22:58` **Meredith Lamb (+14169386001)**

lol


**280.** `22:59` **Meredith Lamb (+14169386001)**

I need to go to bed and now my brain is thinking


**281.** `22:59` **Meredith Lamb (+14169386001)**

But honestly I’m tired


**282.** `22:59` **You**

yeah I am sorry


**283.** `22:59` **You**

bad timing


**284.** `22:59` **Meredith Lamb (+14169386001)**

I will be able to sleep


**285.** `22:59` **Meredith Lamb (+14169386001)**

Don’t worry


**286.** `22:59` **Meredith Lamb (+14169386001)**

Not used to getting up early still


**287.** `22:59` **You**

kk go to bed then\. I gotta pack up my shit for tomorrow\.


**288.** `22:59` **You**

then go for a drive


**289.** `22:59` **You**

fack


**290.** `22:59` **Meredith Lamb (+14169386001)**

:\(


**291.** `23:00` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
k, nite\. I love you and will be thinking of last Saturday xoxoxo


**292.** `23:01` **You**

Love you to Mer\.\. I think about all of em\.\. all the time\.\. even the park :\)  they are all perfect\.  XOXO sleep well ❤️


**293.** `23:01` **You**

even the cars\.\. lol


**294.** `23:02` **You**

Reaction: ❤️ from Meredith Lamb
and the food show


**295.** `23:07` **You**

Reaction: ❤️ from Meredith Lamb
>
you might not read this until morning \- but I will tell you everything about Saturday was amazing, however the thing that I remember the most is how beautiful your eyes are, because I don't even know how long I looked at them, but couldn't stop\. Cheesy but true\.\. now if you read this in the morning, I hope it makes you smile\.\. luv\.

*💬 Reply*

