# Daily Conversation: 2025-06-02 (Monday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-06-02 |
| **Day** | Monday |
| **Week** | 8 |
| **Messages** | 305 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-06-02T06:22 - 2025-06-02T22:28 |

## 📝 Daily Summary

This day contains **305 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `06:22` **Meredith Lamb (+14169386001)**

😢 no morning msg from Scott 😭❤️


**002.** `06:24` **You**

Sorry didn’t sleep well last night\. Kinda rushed out this morning\.\. a bit on autopilot\. just finished workout now\.


**003.** `06:24` **You**

Hope you slept ok\.


**004.** `06:25` **You**

Gonna sauna shower shave and go to my spot\.\. should feel better after that\.


**005.** `06:30` **Meredith Lamb (+14169386001)**

Feel like I messed your night and morning up\. Totally didn’t mean to\. I’m finishing coffee and doing the first day of an old 30daychallenge workout \(I used to do them all the time\) but I woke up and felt awful and knew you’d not be great


**006.** `06:32` **You**

Glad you trying out something new\.\. don’t go too hard you will be sore\.  Listen don’t worry this is just one more thing I need to process and put aside\.\. just like all the rest it will happen\.


**007.** `06:33` **Meredith Lamb (+14169386001)**

Oh I remember, I dialed it back a bit when I wrote it out


**008.** `06:33` **You**

Good call\.


**009.** `06:35` **You**

Ok well have fun chat later I am gonna put my phone in the locker in a sec and head in to clean up\.


**010.** `07:21` **You**

Sorry I meant to mention this to you last night\.\. I will now
And then I won’t raise the topic myself again\.\.   what really got me that night was after telling me everything\.\. especially about Chris\.\. you had told me you reached out to him\.\. I think in late march\.  But he hasn’t gotten back to you or something and you looked really really sad\.\. for like 5 minutes and didnt really say anything after that\.  I mean I know you were friends and whatever else not sure how that worked or what came first\.\. Ok sorry not trying to reopen I just forgot to mention you said you didn’t remember, so that was probably the worst of it\.  Anyhow just out of shower getting ready to head out\.\. again not trying to prolong this\.\. but forgot to mention and thought you would want to know\.


**011.** `07:27` **Meredith Lamb (+14169386001)**

I remember you mentioning that and I do remember saying it also\. Not the silent 5 min afterwards\. We were very good friends after the fucked up crazy stuff and we reconnect and chat every so often \(last time when his dad died\) but only as friends even tho he would probably do more but honestly he is GAY but thinks he is bi\. I wouldn’t ever do anything with him other than be friends\. I wasn’t the greatest friend to him after I had kids so when he didn’t respond it makes me feel like I did something wrong\. \(Because I did neglect our friendship\.\) That’s all


**012.** `07:27` **Meredith Lamb (+14169386001)**

No longing there AT ALL\.


**013.** `07:27` **Meredith Lamb (+14169386001)**

I gotta shower and get to work\.


**014.** `07:27` **Meredith Lamb (+14169386001)**

Had to deal with Andrew for a bit


**015.** `07:28` **Meredith Lamb (+14169386001)**

Will chat later ❤️


**016.** `07:29` **You**

Kk chat later I am just going to go home and get online and try to bang out some work early\.  Hope all is ok with Andrew, hope workout was ok\.


**017.** `07:37` **Meredith Lamb (+14169386001)**

He’s not impressed I started working out\.


**018.** `07:41` **Meredith Lamb (+14169386001)**

Workout was humbling\. Tried to just go through 3 circuits and get some muscle memory back basically\. Gahhh


**019.** `07:41` **You**

Why?


**020.** `07:41` **You**

Yeah it will come


**021.** `07:41` **You**

Give it time


**022.** `07:43` **You**

You gotta get
Ready you can tell me later heading home\.


**023.** `07:46` **Meredith Lamb (+14169386001)**

>
He associates the years of me being obsessed with working out as happy because I was happier when really I was just a doormat and then woke up\. So he has been  asking me to start working out for the last 3 yrs because he thought  it would fix everything\. A little clueless\. So the\. He was all \(for the last 3 yrs\) “you are going to leave me, start working out and then meet someone else”

*💬 Reply*

**024.** `07:47` **Meredith Lamb (+14169386001)**

So when I was working out his initial reaction was “interesting”


**025.** `07:47` **Meredith Lamb (+14169386001)**

One comment initially


**026.** `07:47` **Meredith Lamb (+14169386001)**

K getting ready for real now


**027.** `08:09` **Meredith Lamb (+14169386001)**

>
Was this too stark? I’m going to worry now lol

*💬 Reply*

**028.** `08:11` **You**

I mean come on the two conversations are miles apart\.\. you don’t need to worry about being sharing\.\. you have already told me a lot more graphic shit about you and andrew\. Doesnt bother me\.


**029.** `08:14` **Meredith Lamb (+14169386001)**

KK


**030.** `09:29` **Meredith Lamb (+14169386001)**

I feel like things are not ok\.


**031.** `09:30` **You**

Things are ok Meredith what’s wrong\.


**032.** `09:31` **You**

Teams me
If you want I am online go to a room if you want privacy whatever you want\. I have a meeting I\. 30
Mins\.


**033.** `09:48` **You**

Not really much time now maybe later\.


**034.** `09:49` **Meredith Lamb (+14169386001)**

Sorry things chaotic here bc of move


**035.** `09:50` **Meredith Lamb (+14169386001)**

I’m just not used to you being quiet


**036.** `09:50` **Meredith Lamb (+14169386001)**

Why are you working like normal?


**037.** `09:50` **You**

Hmm? Normal\.


**038.** `09:50` **You**

I just have stuff to do\.\.


**039.** `09:51` **Meredith Lamb (+14169386001)**

You are not showing ooto


**040.** `09:52` **You**

There


**041.** `09:52` **You**

Not sure why that didn’t trigger


**042.** `09:56` **You**

Listen l am having a hard time atm\. But let me assure you my being quiet isn’t shutting down\.  If we were together this would likely be sorted already\.  But I am here by myself with my head so it is a bit harder\. I love you\.\. I am not going anywhere unless you make it so\.\. I am here whatever comes next for as long as you will have me\. But while I haven’t had Thea experiences before you have and how you spoke about them in detail it is a lot to process and work through\.  I have to get my head right I don’t think you can do that for me\.


**043.** `09:57` **You**

I don’t know maybe if roles were reversed and I had a few strong and passionate relationships pre Jaimie and I said the same stuff to you that you shared with me in the way it was shared you might be good to go\.\. I just have a harder time\.  Sorry…😔


**044.** `10:00` **You**

Maybe that reassurance will be enough?


**045.** `10:03` **Meredith Lamb (+14169386001)**

Yeah it is all okay \- I understand and you do what you need to do\. Just mad at myself\.


**046.** `10:05` **You**

Sorry mer I don’t know what I need to do\.\. it usually just resolves\.\.
I am trying\.


**047.** `10:07` **Meredith Lamb (+14169386001)**

It’s okay really, you don’t need to do anything\. ❤️


**048.** `10:13` **You**

No I went down a fucking rabbit whole searched him out and now I feel stupid as fuck\.


**049.** `10:13` **You**

Like how was that going to help me lol\.\.


**050.** `10:13` **You**

Anyhow yeah so just trying to get out of the hole\.\. and then I don’t know what next\.


**051.** `10:15` **Meredith Lamb (+14169386001)**

Don’t feel stupid just move on maybe?


**052.** `10:15` **Meredith Lamb (+14169386001)**

:\(


**053.** `10:20` **Meredith Lamb (+14169386001)**

I’m the one that fucked up here not you\.


**054.** `10:20` **Meredith Lamb (+14169386001)**

So maybe we can just move past it?


**055.** `10:21` **You**

Of course we are going to move past it I don’t want to be stuck in this anymore…


**056.** `10:22` **You**

Soo hard wtf is wrong with me heart rate is up Jesus\.\.


**057.** `10:22` **You**

Kk maybe I am not going to share any more of this with you\.\.
It won’t make you feel better so it isn’t productive


**058.** `10:22` **You**

It shutting down just to emphasize


**059.** `10:22` **You**

Not


**060.** `10:22` **Meredith Lamb (+14169386001)**

But like is there anything I can do or say?


**061.** `10:23` **You**

I don’t think so\.


**062.** `10:23` **Meredith Lamb (+14169386001)**

What exactly is causing the increased heart rate?


**063.** `10:23` **You**

I don’t know\. Just stuck thinking in that moment over and over\.


**064.** `10:23` **You**

Like on replay\.


**065.** `10:24` **Meredith Lamb (+14169386001)**

😳


**066.** `10:24` **You**

I don’t want to\.\. I oromise


**067.** `10:26` **Meredith Lamb (+14169386001)**

Sigh, Scott, I am completely in love with YOU and really fucked up\. It will not happen again and it was so stupid\. But I’m in this with you, now\. I have zero desire for the past\. Honestly\.


**068.** `10:26` **You**

Same mer despite feeling like this atm, I NEVER even wavered a spec\.\. I need you to know that


**069.** `10:26` **You**

And I won’t


**070.** `10:26` **You**

I promise


**071.** `10:26` **You**

10000%


**072.** `10:27` **You**

You don’t need to worry about this impacting us in any way\.


**073.** `10:27` **Meredith Lamb (+14169386001)**

I honestly think I fucked up so bad because you make me feel so safe\. So when I was messy, I wasn’t thinking at all\.


**074.** `10:27` **Meredith Lamb (+14169386001)**

I think it is testament to what we have\. As weird as that sounds


**075.** `10:28` **You**

I am happy you had such a good life and adventures\.  I am sooooo jealous\.\. that I couldn’t be part of them\.\. feeling the way I do, feeling like you are the only one that matters to me\. An irrational part of me hates the fact that it took me this long to find you and I missed out on so much\.


**076.** `10:30` **You**

It is stupid\.\. and irrational and immature\. There is so much I want to share that just can’t happen we are past those years\.\. really breaks me a bit which is why I was sensitive to the stories\.   I don’t want to shut that part of your life off between us\.\.
I know Andrew have you a hard time for that you told me that as well\.\. I think you hoped I wasn’t him and when I reacted this way I was disgusted with myself\.


**077.** `10:31` **You**

Maybe if we were together like a normal
Couple this would be easier\.\. but we aren’t and it’s not\.\. so I will figure it out somehow


**078.** `10:32` **You**

It is true what I said the other night I don’t think you quite grasp how much I love you and how much feeling there is behind that\.  It is new and wonderful and fucking scary to me\.


**079.** `10:34` **You**

Jim told me I needed to slow down\.\. find balance\.\. I told him I was fine… maybe he was right\.\. maybe we just need to approach this differently?


**080.** `10:41` **Meredith Lamb (+14169386001)**

Not sure about that honestly\. Haven’t thought about it\. All I know is that I have to make some changes and smarten up\. Which is generally a point that I eventually get to\. Think I’m here\. I think you are struggling atm simply because of my behaviour and for no other reason\.


**081.** `10:42` **You**

I think you are at work\.\.
And shouldn’t be focused on this\.\. it isn’t fair to you\.


**082.** `10:45` **You**

There is too much I am throwing at you to process so just put it down mer\.  Forget about it\.  Compartmentalize or do whatever you do\.


**083.** `10:46` **Meredith Lamb (+14169386001)**

>
Noted\.

*💬 Reply*

**084.** `10:48` **You**

I am going to stop now\.\. and go read the filing then turn this off and go do some work elsewhere\.  Have a good day you don’t have to go to the sc meeting I am going\.


**085.** `10:51` **Meredith Lamb (+14169386001)**

k, I love you Scott … remember that


**086.** `10:53` **You**

Love you too\.


**087.** `13:19` **You**

Ok I have closed all my windows discontinued all my gpts putting this back in the box\.  Cannot
Guarantee as much as I would like that it will never pop
Up again\.  But I feel like it has been walled back off\.


**088.** `13:21` **You**

Thought you would want to know I know you were upset and I am really sorry that I worried you\.  There was one paragraph earlier that I had a really hard time writing because it was really at the Center of all of my feelings\.\.  and there is nothing I can do about it\.\. so just have to move forward and hope for the best\.


**089.** `13:21` **You**

Well 4 responses back to back\.\.


**090.** `13:46` **Meredith Lamb (+14169386001)**

One paragraph…\.


**091.** `13:46` **Meredith Lamb (+14169386001)**

How much gpt did you do on this?


**092.** `13:47` **You**

>
All of them in this group were hard this one was the worst

*💬 Reply*

**093.** `13:47` **You**

None


**094.** `13:47` **You**

Zero


**095.** `13:47` **You**

Was pretty raw\.\. I didn’t want to use gpt for it


**096.** `13:49` **Meredith Lamb (+14169386001)**

>
You are nothing like Andrew in this respect if that is what you are worried about\.  Seriously\. Andrew was over the top\.

*💬 Reply*

**097.** `13:51` **You**

I don’t want to feel like that\.\. and that is on me to control…\. Honestly I had to tone it down I was surprised how emotional I got at that point x


**098.** `13:51` **You**

There doesnt seem to be an end to it\.\.


**099.** `13:52` **You**

I mean these are good emotions and negative emotions but not relating to this particular instance I guess


**100.** `13:52` **You**

But overwhelming


**101.** `14:01` **Meredith Lamb (+14169386001)**

One sec


**102.** `14:04` **Meredith Lamb (+14169386001)**

Sry Carolyn


**103.** `14:05` **You**

Sok work is priority


**104.** `14:05` **Meredith Lamb (+14169386001)**

>
I’m not sure how to help this other than to act better on the weekends lol

*💬 Reply*

**105.** `14:05` **You**

Sorry you misunderstand\.


**106.** `14:06` **Meredith Lamb (+14169386001)**

Yes I probably do


**107.** `14:06` **Meredith Lamb (+14169386001)**

One on one with Musarrat


**108.** `14:08` **You**

What I am saying is that when I thought about what I missed what I can never have or never be a part of \.\. Andrew everything g before as irrational as it is\.\. I felt something like grief\.\. I think closest thing I can compare it to\.\. again I have never felt anywhere near as strong about anyone so this all new\.\. the good and the bad\.\. but let’s be clear th good outweighs the bad by miles and miles and miles…


**109.** `14:17` **You**

Once you read the above
Maybe consider if I shouldn’t just stop texting you on signal during business hours
I feel
It just distracts you and frustrates you\.


**110.** `15:37` **Meredith Lamb (+14169386001)**

>
I just don’t want you spiralling in this as we have had such amazing times together\. Like over the top amazing\. If you focus on that it discounts what we have had and will continue to have\. I know I started it … wish I didn’t\! Totally not intentional\.

*💬 Reply*

**111.** `15:39` **You**

I know and there is nothing i can do but try to make whatever time and adventures we have as amazing as I can\.\. and love you as much as I can\.\. please set it down and leave it behind I intend to life is to short and we get no time as it is I would rather not spend it stressing over shit from 20 years ago\.\. my insecurities suck\.


**112.** `15:41` **Meredith Lamb (+14169386001)**

Yeah this spiralled into a very dark place\.


**113.** `15:42` **You**

It did and I think despite what I just said you are now worried more than ever right ☹️


**114.** `15:43` **You**

Fack me\.


**115.** `15:48` **You**



**116.** `15:50` **Meredith Lamb (+14169386001)**

No I am not\. I know a lot of this is due to our distance\. I’m not naive\. If we could actually spend time together tonight we would sort this in like 5 minutes\.


**117.** `15:51` **You**

>
I just thought this statement was going to lead
To something else

*💬 Reply*

**118.** `15:51` **You**

>
Agreed

*💬 Reply*

**119.** `15:52` **Meredith Lamb (+14169386001)**

>
No not at all\. I just feel bad\.

*💬 Reply*

**120.** `15:54` **You**

Well stop feeling bad you can’t change that this happened it was a mistake not intentional\. You can’t change the distance, or seeing each other at least not on a reg basis\.\. we agreed this next few months was going to be shit\.\. right it is what it is\.


**121.** `15:55` **You**

I will likely not allow this to happen again\.  And perhaps if I see you going down this conversational road again\.\. I may gently nudge you away from it\.


**122.** `15:56` **You**

>
And honestly if I was a big boy instead of an insecure got this shouldn’t have bothered me…\. That is on me

*💬 Reply*

**123.** `15:56` **You**

Insecure git


**124.** `16:01` **Meredith Lamb (+14169386001)**

It is totally valid that it bothered you\. Seriously\.


**125.** `16:02` **You**

It's fine\.\. I am just not going to look back tbh\.\. there is nothing there for me other than to be happy that you at one point pre Andrew seemed to have a really great time\.\. and there is nothing wrong with that\.


**126.** `16:05` **Meredith Lamb (+14169386001)**

Ok but it wasn’t all good\. Just remember that\. If it was, I wouldn’t have left it\.


**127.** `16:06` **You**

Sure\.\. I get it\.


**128.** `16:35` **Meredith Lamb (+14169386001)**

Today has been exhausting\. I’ve had to explain my story 15x


**129.** `16:35` **Meredith Lamb (+14169386001)**

😵‍💫😵‍💫😵‍💫


**130.** `16:36` **You**

well


**131.** `16:36` **You**

maybe just go to bed early\.\.


**132.** `16:37` **Meredith Lamb (+14169386001)**

For sure bc I have to get up early to work out lol committed now


**133.** `16:38` **You**

same\.\.  kk well I might not get to talk to you much\.\. I am getting fed up with people around here doing fuck all\.\. so I might go for a run at the gym\.


**134.** `16:39` **You**

then get up tomorrow and do the same\.\. but I will go to my spot tomorrow\.\. I almost did today\.\. but traffic was bad\.\. and it was cold\.


**135.** `16:39` **You**

I think I will tomorrow\.\. listen to my playlist and chill


**136.** `16:39` **Meredith Lamb (+14169386001)**

I can meet you tomorrow


**137.** `16:39` **You**

no you have you workout to do


**138.** `16:39` **You**

I don't want to interrupt that


**139.** `16:39` **Meredith Lamb (+14169386001)**

I will do it a bit earlier


**140.** `16:39` **Meredith Lamb (+14169386001)**

First meeting is at 10


**141.** `16:40` **You**

I don't want you to feel obligated\. You come first\.


**142.** `16:40` **You**

Andrew will probably give you shit again as well


**143.** `16:40` **You**

so might be hard to get out


**144.** `16:42` **You**

>
yeah and I bet you and jim had some stuff to cover off lol\.

*💬 Reply*

**145.** `16:42` **You**

I started talking to him\.\. but I couldn't really do it\.


**146.** `16:42` **Meredith Lamb (+14169386001)**

I didn’t get shit per se\. Just spurred some suspicion I think\.


**147.** `16:43` **Meredith Lamb (+14169386001)**

>
We talked over lunch hour after our meeting\. :p

*💬 Reply*

**148.** `16:43` **You**

I kind of figured


**149.** `16:43` **You**

I wasn't comfortable going to him with issues\.\. was awkward\.\. and I sorted it anyways\.\. I don't think I will be able to use him like I hoped\.


**150.** `16:44` **Meredith Lamb (+14169386001)**

Maybe a therapist?


**151.** `16:44` **Meredith Lamb (+14169386001)**

Just pick one


**152.** `16:44` **You**

dunno\.\. doubt it would help to rehash shit I put in a box\./


**153.** `16:44` **You**

too risky\.


**154.** `16:52` **You**

well I messaged a therapist let's see what happens


**155.** `17:06` **Meredith Lamb (+14169386001)**

So you didn’t do any house stuff today?


**156.** `17:07` **You**

not nearly enough\.\. pool stuff though\.\. lots of that


**157.** `17:08` **You**

I am meeting with Hugh my new therapist tomorrow\.


**158.** `17:13` **Meredith Lamb (+14169386001)**

For real? I think that is great


**159.** `17:14` **You**

yep we will see\.\. I will be meeting him in person\.\. could be good\.\. we will see\. I see him at noon\.


**160.** `17:21` **Meredith Lamb (+14169386001)**

Wanna talk tonight or no?


**161.** `17:22` **You**

when


**162.** `17:22` **Meredith Lamb (+14169386001)**

I’m having a hard time reading how you are truly doing


**163.** `17:22` **You**

>
you are still worried??  we can talk just depends on when\.\. if I go to the gym easier\.

*💬 Reply*

**164.** `17:23` **Meredith Lamb (+14169386001)**

Whenever honestly


**165.** `17:23` **You**

but andrew


**166.** `17:24` **Meredith Lamb (+14169386001)**

I will be quiet and he will probably be at volleyball with Maelle anyway


**167.** `17:25` **You**

ok\.\. well I am probably going to the gym maybe around 7 or something\.  I can talk to you in car or whatever\.


**168.** `17:26` **You**

you sound like you are still really upset


**169.** `17:26` **You**

:\(


**170.** `17:26` **You**

if we can actually see each other tomorrow\.\. I will make you feel better\.


**171.** `17:28` **Meredith Lamb (+14169386001)**

I’m not upset\. Just leaving work


**172.** `17:29` **You**

no but you "sound" upset anyways


**173.** `17:29` **You**

you words etc/


**174.** `17:41` **Meredith Lamb (+14169386001)**

Stuck in lobby with Michelle and Dana\. Omg


**175.** `17:41` **You**

lol


**176.** `17:41` **You**

You will never escape


**177.** `17:45` **Meredith Lamb (+14169386001)**

Dana was very curious on “what happened” just like everyone else


**178.** `17:46` **Meredith Lamb (+14169386001)**

Omg asked soooooo many times today


**179.** `17:46` **You**

Yeah… but this will be it\.


**180.** `17:46` **Meredith Lamb (+14169386001)**

Well probably tomorrow too but hopefully then it is done


**181.** `17:48` **You**

Yep


**182.** `17:49` **You**

So gonna eat and then work in garage for an hour then to gym


**183.** `17:49` **Meredith Lamb (+14169386001)**

So Deanna is very unhappy fyi


**184.** `17:50` **Meredith Lamb (+14169386001)**

She told me today and I didn’t ask


**185.** `17:50` **Meredith Lamb (+14169386001)**

Remember fox told me that and I was skeptical


**186.** `17:50` **Meredith Lamb (+14169386001)**

She is VERY unhappy


**187.** `17:50` **You**

So she will be applying


**188.** `17:51` **Meredith Lamb (+14169386001)**

No she never said that


**189.** `17:52` **You**

Well I suspect she will


**190.** `17:55` **Meredith Lamb (+14169386001)**

Maybe


**191.** `17:55` **You**

Well she won’t get it


**192.** `18:08` **Meredith Lamb (+14169386001)**

lol


**193.** `18:09` **Meredith Lamb (+14169386001)**

I mean she is a hustler\. You gotta give her that at least


**194.** `18:09` **You**

I do not have to give her anything I helped her get the promotion in the first place


**195.** `18:09` **You**

She wa lbs going to reject it because she was pissed offf


**196.** `18:10` **You**

I had to convince her to get out of her own way\.\. then she turned into a mini Johana\.


**197.** `18:11` **Meredith Lamb (+14169386001)**

So I have to admit…\. I kind of felt deceptive today telling my story 15 million times to ppl


**198.** `18:11` **Meredith Lamb (+14169386001)**

Ughhh


**199.** `18:11` **Meredith Lamb (+14169386001)**

Was a weird day


**200.** `18:11` **Meredith Lamb (+14169386001)**

I think I might nap when I get home


**201.** `18:11` **You**

Well you will get to tell another story sometime down the road more than 15 times I suspect


**202.** `18:12` **Meredith Lamb (+14169386001)**

🤯


**203.** `18:12` **You**

Kk well I am still planning on going to the gym in or around 7 maybe 7:30


**204.** `18:12` **You**

If that time doesn’t work to talk let me know


**205.** `18:13` **Meredith Lamb (+14169386001)**

k almost home


**206.** `18:13` **Meredith Lamb (+14169386001)**

Will assess the situation and see if I can nap lol


**207.** `18:13` **You**

Kk I am just chilling for a bit\.\. go get your nap or whatever… yeah lol do that I guess


**208.** `18:14` **Meredith Lamb (+14169386001)**

Omg talked to Alison for a while today


**209.** `18:14` **Meredith Lamb (+14169386001)**

She made a sly “I guess you don’t want the system pruning job”


**210.** `18:14` **Meredith Lamb (+14169386001)**

As if


**211.** `18:15` **You**

ROFL


**212.** `18:15` **You**

I told her no shot


**213.** `18:17` **Meredith Lamb (+14169386001)**

So Diana said that origin all his girly friends were gossiping about what happens or may have happened to me in my role so imagine what the gossip would be like if we got out


**214.** `18:18` **Meredith Lamb (+14169386001)**

\*dana


**215.** `18:18` **Meredith Lamb (+14169386001)**

Dana said that ARJUN


**216.** `18:18` **Meredith Lamb (+14169386001)**

“Arjun and all his girly friends”


**217.** `18:18` **Meredith Lamb (+14169386001)**

lol


**218.** `18:19` **You**

Hmm lol probably Scott’s a bastard


**219.** `18:19` **You**

That fits


**220.** `18:21` **Meredith Lamb (+14169386001)**

lol she was all “I just told them to read the quote at the bottom” and it just meant she chose to leave it in her own\. It wasn’t a demotion\. I think they thought you fired me lol


**221.** `18:21` **You**

ROFL


**222.** `18:22` **You**

Boy will they be surprised


**223.** `18:22` **You**

There will unfortunately be a lot of abhhhhhhhhhhhs\.  Which again narrative


**224.** `18:25` **Meredith Lamb (+14169386001)**

Oh my God, the gossip is gonna be brutal


**225.** `18:25` **Meredith Lamb (+14169386001)**

I’m not sure I’ll be able to handle it


**226.** `18:25` **Meredith Lamb (+14169386001)**

Today was nuts


**227.** `18:25` **Meredith Lamb (+14169386001)**

I have a brutal headache and had no Tylenol at work so I’m going to take a Tylenol right now and go and have a nap


**228.** `18:26` **You**

Let’s tell people when our freedom to be together is a bit more definitive so I can actually help you and you me not like the shit we deal with right now


**229.** `18:26` **You**

Ok you go do that will head out in about an hour


**230.** `18:29` **Meredith Lamb (+14169386001)**

>
Yeah I wouldn’t be able to handle it right now

*💬 Reply*

**231.** `18:29` **Meredith Lamb (+14169386001)**

We would actually need to be like together together I think


**232.** `18:29` **You**

Same


**233.** `18:29` **You**

That would be a long time mer


**234.** `18:30` **You**

But your call


**235.** `18:30` **You**

Like years unless you have a plan


**236.** `18:31` **Meredith Lamb (+14169386001)**

I do not have a plan at all :\(


**237.** `18:31` **Meredith Lamb (+14169386001)**

All I know is if today was weird, explaining us would be too much


**238.** `18:31` **You**

So the we will have to agree to never tell anyone at work\.\. I think only way


**239.** `18:32` **Meredith Lamb (+14169386001)**

Sold\. Deal\.


**240.** `18:33` **You**

lol you won’t be happy like that\.\. We can talk about this later\.\. I think she you understand what is ahead of us before we can “be together” you might not be up for this\.\. lol


**241.** `18:33` **You**

She is supposed to be once


**242.** `18:35` **Meredith Lamb (+14169386001)**

I have a different pov after today


**243.** `18:35` **You**

I am not sure what that means but not sure it is good lol


**244.** `18:36` **Meredith Lamb (+14169386001)**

It means I forgot how gossipy people are


**245.** `18:37` **Meredith Lamb (+14169386001)**

Do you know how many times I was asked what happened?


**246.** `18:37` **Meredith Lamb (+14169386001)**

At least 10


**247.** `18:37` **Meredith Lamb (+14169386001)**

Even neeti who I never talk to


**248.** `18:38` **You**

lol


**249.** `18:38` **You**

Oh you have a different pov about work


**250.** `18:39` **You**

>
I was talking about this more
Of an absolute be together us statement

*💬 Reply*

**251.** `18:39` **You**

I think you will get tired of the challenges eventually too much of a pain in the ass


**252.** `18:39` **You**

And don’t tell me to stop


**253.** `18:40` **Meredith Lamb (+14169386001)**

Once I have a separation agreement signed my family will know \(the truth, not some weird version\) and that is all I will really care about\.


**254.** `18:41` **You**

Well mine will have a wierd version for a bit for the sake of
My sanity but it will be real as soon as I can make it happen


**255.** `18:41` **You**

I am not sure how that relates to what I said but ok\.\.


**256.** `18:41` **You**

lol


**257.** `18:42` **Meredith Lamb (+14169386001)**

>
Obviously, I misunderstanding what you said read back I don’t think you were clear

*💬 Reply*

**258.** `18:43` **You**

I said you are
Going to want to “be” with someone and that won’t be me for a very long time I think\.\. not sure that is something you would want to endure\.


**259.** `18:43` **You**

Like I said we can discuss later you can sleep


**260.** `18:45` **Meredith Lamb (+14169386001)**

>
This isn’t exactly what you said but ok\. I mean if you continue to not tell your family for years and we have to sneak around for years then yeah, I probably am not ok with that\. Otherwise, I’m good\.

*💬 Reply*

**261.** `18:45` **You**

Still not what I meant we\. Nah gerd


**262.** `18:45` **You**

I am telling them


**263.** `18:45` **You**

Likely this year


**264.** `18:45` **You**

Late
Fall


**265.** `18:45` **You**

Prolly


**266.** `18:45` **You**

But I meant living with you


**267.** `18:46` **You**

Wow words meaning hard


**268.** `18:46` **You**

lol I suck aoparently


**269.** `18:46` **Meredith Lamb (+14169386001)**

Ohhh I did not know that is what you meant


**270.** `18:46` **You**

That is what I meant


**271.** `18:46` **Meredith Lamb (+14169386001)**

We don’t need to live together as long as we don’t need to sneak around


**272.** `18:47` **You**

>
This is what I meant

*💬 Reply*

**273.** `18:47` **You**

I thought freedom to be together was living together


**274.** `18:47` **You**

And living together seems like sooooo far away


**275.** `18:47` **Meredith Lamb (+14169386001)**

>
In what world do those two things mean the same thing?

*💬 Reply*

**276.** `18:47` **You**

We will be in 50’s


**277.** `18:47` **You**

I thought be together


**278.** `18:47` **You**

Was just that


**279.** `18:48` **Meredith Lamb (+14169386001)**

Listen, I haven’t thought about timing on living together and quite frankly I’m really busy with three girls so haven’t even really thought about where I stand on that I more hate the sneaking around


**280.** `18:49` **You**

lol ok you have your priorities\.\. so I know what I have to do sooner than later somehow


**281.** `18:51` **Meredith Lamb (+14169386001)**

You don’t have to do anything “sooner”\.


**282.** `18:51` **Meredith Lamb (+14169386001)**

I’m just saying that is a higher priority to me than living together\.


**283.** `18:51` **Meredith Lamb (+14169386001)**

Doesn’t need to be soon


**284.** `18:51` **You**

Well it is clearly
First yeah and it does\.\.


**285.** `18:52` **You**

Like I said I think give it a few months into fall and I will mention something


**286.** `18:52` **You**

It will likely
Come up before then I will challenge me and I will just admit that our intention is to have a relationship


**287.** `18:53` **Meredith Lamb (+14169386001)**

Just wait until I tell Andrew and do it then\. :\) And what will change do you think?


**288.** `18:58` **You**

Nothing


**289.** `18:58` **You**

If I tell her before I have my separation or before she leaves it would be a shitstorm


**290.** `18:59` **You**

Kk go to sleep or you won’t be able to talk to me later


**291.** `18:59` **You**

Or get up in morning for park


**292.** `18:59` **You**

That is more important and we can actually chat about this topic later if
You want


**293.** `18:59` **You**

Ok working then gym cya\. ❤️


**294.** `18:59` **Meredith Lamb (+14169386001)**

❤️


**295.** `20:06` **You**

You still sleeping?


**296.** `20:14` **You**

I guess not yet\.\. driving to gym now


**297.** `20:26` **You**

Kk well
Even if
We don’t get
To talk tonight and you cannot see me with your eyes don’t worry you are clearly tired\.  More important\.


**298.** `20:43` **You**

If you do actually get on here I am running so if you want to chat just call me\.


**299.** `21:26` **Meredith Lamb (+14169386001)**

lol just woke up


**300.** `21:26` **Meredith Lamb (+14169386001)**

But kind of want to just get seriously ready for bed and go to bed


**301.** `22:20` **You**

ok well I guess I am going to bed too\.\. have a good night\.\. luv u\.


**302.** `22:21` **Meredith Lamb (+14169386001)**

I’m actually still up but we should go to bed\. Early morning


**303.** `22:22` **You**

Yeah I am just packing my shit up and going to sleep\.


**304.** `22:27` **Meredith Lamb (+14169386001)**

k, nite \- c u tomorrow ❤️❤️


**305.** `22:28` **You**

Nite ❤️❤️


