# Daily Conversation: 2025-04-23 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-04-23 |
| **Day** | Wednesday |
| **Week** | 2 |
| **Messages** | 315 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-04-23T06:10 - 2025-04-23T23:59 |

## 📝 Daily Summary

This day contains **315 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `06:10` **You**

Good morning sunshine looking forward to another fun filled no touchy day 😇\. Xoxo


**002.** `06:10` **Meredith Lamb (+14169386001)**

lol\!


**003.** `06:11` **Meredith Lamb (+14169386001)**

Incredible timing\. Was reading an annoying email from Andrew and you messaged\. :\)


**004.** `06:16` **Meredith Lamb (+14169386001)**

Sigh\. I don’t think he is doing spousal right\. He is doing child right\. It is tricky to get his explanations and then I get bullshit like this…\. Need to decide on a rental\. There are so many tho

*📎 1 attachment(s)*

**005.** `06:27` **You**

Reaction: ❤️ from Meredith Lamb
Well I aim to be good on timing 😝\. Sorry just jumping in shower want to be pretty well as pretty as I can be


**006.** `06:28` **You**

Eesh is he admitting spousal is wrong??? And saying the whole love thing or just weird\.\. anyways whatever shower time 😃


**007.** `06:29` **You**

Luv luv luv\.


**008.** `06:34` **Meredith Lamb (+14169386001)**

Process is super annoying to get through\. I feel like we are close though\.
K, ttyl xo dropping Maelle off at school before I go in today


**009.** `07:47` **You**

On my way in see you soon\.


**010.** `09:32` **You**

❤️❤️❤️❤️


**011.** `09:32` **You**

Reaction: 🙂 from Meredith Lamb
Necessary


**012.** `11:04` **You**

I actually looked at
My phone after you know knocked and thought shit is this the stairwell knock rofl


**013.** `11:04` **You**

I had to check messages
lol


**014.** `13:05` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I’ve been thinking about a label for you and it dawned on me that I already gave you one that I have said to no one ever\. You are home to me\. For real\. That’s your label\. And that home feeling is forever …\.


**015.** `13:08` **You**

Kk I can live with that ❤️


**016.** `13:08` **You**

Same feeling\-


**017.** `13:08` **You**

Just got blasted by Gracie and Jaimie no fun\.


**018.** `13:11` **You**

Reaction: 😢 from Meredith Lamb
J is not going home anytime soon she said she won’t leave for a year without maddie and if maddie goes to university here she might stay longer I said I cannot carry the house that long and rent so you will need to make a choice\.\. if you stay you will need to sell and rent until you move to Moncton\. Or buy sell and move to Moncton but I cannot cart that house and your expenses and deal on my own\.  Fuck my life\.  Shit going round and round in my head\.


**019.** `13:13` **You**

Be down in a few just need to calm down…\.


**020.** `13:13` **You**

A lot to process today\.


**021.** `13:18` **You**

Fack


**022.** `15:56` **Meredith Lamb (+14169386001)**

Is everything ok? You looked \(look\) very stressed, upset, frustrated… all of the above\.


**023.** `15:57` **You**

I am


**024.** `15:57` **You**

It’s fine


**025.** `15:58` **You**

I will deal


**026.** `15:58` **Meredith Lamb (+14169386001)**

Don’t believe you but it’s ok\.


**027.** `15:58` **You**

I will do the best I can\.\.  more accurate\.


**028.** `15:59` **You**

To deal that is


**029.** `16:01` **Meredith Lamb (+14169386001)**

Sorry, this too shall pass\. Why don’t you just go home


**030.** `17:32` **You**

Home won’t help and it doesn’t matter the shit is all in my head\.


**031.** `17:32` **You**

Just going to try to wipe myself out at the gym tonight and then blackout when I get home


**032.** `17:39` **Meredith Lamb (+14169386001)**

She will come around\. Just give it some time and back and forth\. Sorry your day was so crappy\. Love you


**033.** `17:39` **You**

Love you


**034.** `19:30` **Meredith Lamb (+14169386001)**

You don’t have to text me but I’m thinking of you and hoping you are ok


**035.** `19:31` **You**

I appreciate it\.\. having a hard time\.\. made a few mistakes today kicking myself\.  My own fault and I am dealing with it as best I can\.


**036.** `19:32` **Meredith Lamb (+14169386001)**

?


**037.** `19:32` **Meredith Lamb (+14169386001)**

Said things you regret?


**038.** `19:34` **You**

I wouldn't put it that way\.  I am downstairs working on the separation documents\.\. going to gym around 8:30\.  Gracie had a meltdown today which is why I had to leave meeting \- I was talking to financial advisor on one break that didn't go well \- and Jaimie went back a bit on going back to Moncton suggesting she only will if Gracie and Maddie come \- which won't be at min for a year\.\.  and max longer\.\. I told her if it is longer then we will need to sell the house and figure something else out\.\. in meantime I am just going to rent a 1 bedroom, it makes no sense for maddie to stay with me in this situation\.  Which is also kind of depressing\.


**039.** `19:34` **You**

additionally


**040.** `19:34` **You**

I broke the age old rule today \- do not ask questions you do not want to know the answers to\.


**041.** `19:35` **You**

So just paying the price LOL\.\.


**042.** `19:35` **You**

It's all on me, I will figure it out\.


**043.** `19:36` **You**

If maddie isn't living with me, I might just move closer to work to save money and km's depending on the rental difference


**044.** `19:37` **Meredith Lamb (+14169386001)**

>
Hrm?

*💬 Reply*

**045.** `19:38` **You**

😩 why hrm?  lol you know the stupid thing I did\.


**046.** `19:38` **Meredith Lamb (+14169386001)**

What question?


**047.** `19:39` **You**

I should never have pursued any questions re: you and Andrew\.\. was stupid of me\.


**048.** `19:39` **Meredith Lamb (+14169386001)**

Oh\. That\.


**049.** `19:39` **You**

yeah\.\. again my fault\.\. should have known better\.


**050.** `19:40` **Meredith Lamb (+14169386001)**

Are you really bothered?


**051.** `19:42` **You**

Reaction: 😢 from Meredith Lamb
It doesn't matter Mer, because I would never ever ask you to do anything to jeopardize the process you are going through, or the situation you are currently in without your kids knowing\.\. But yeah it bothers me, I think it would bother you too, I cannot help it\.\. I Love you\.\. it is impossible not to feel something about it\.\. but it isn't forever and I will just figure out how to get through it\.


**052.** `19:43` **Meredith Lamb (+14169386001)**

It is rare now\.


**053.** `19:43` **You**

sorry I don't want to make you feel bad, I just wanted to be honest


**054.** `19:44` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I also go to bed thinking of you and wake up thinking of you\.


**055.** `19:44` **Meredith Lamb (+14169386001)**

It’s really pretty simple\.


**056.** `19:44` **You**

listen used a CBT GPT for an hour today trying to get my head out of where it was\.\.


**057.** `19:45` **You**

I know what you are saying\.\. I just cannot help how I feel\.\. it isn't jealousy it just feels bad\.\. I don't know how to explain it\.


**058.** `19:45` **Meredith Lamb (+14169386001)**

My kids will know next week


**059.** `19:45` **You**

Anyhow\.\. I expect to work out till I pass out tonight\.,


**060.** `19:45` **Meredith Lamb (+14169386001)**

Then it all shifts\.


**061.** `19:45` **Meredith Lamb (+14169386001)**

>
Because of me or j and Gracie?

*💬 Reply*

**062.** `19:46` **You**

Not you, because of my stupid question\.


**063.** `19:46` **You**

The other problem is solveable through work


**064.** `19:47` **You**

I keep going through a little mantra I trust mer, and I want to be her Home\.  and just rinse and repeat\.


**065.** `19:47` **Meredith Lamb (+14169386001)**

I don’t even remember we a question per se\. It was more a conversation no?


**066.** `19:47` **You**

so just trying that and breathing etc,\.


**067.** `19:47` **You**

I had said something about him laying down with you at the cottage\.


**068.** `19:47` **You**

I was under the impression you didn't sleep with him


**069.** `19:47` **You**

I figured he came in and invaded your space


**070.** `19:47` **You**

but then I realized differently


**071.** `19:48` **You**

so it was like a gut punch\.\. lol\.\. I just made a poor assumption


**072.** `19:48` **Meredith Lamb (+14169386001)**

And I said we do not a lot of the time


**073.** `19:48` **Meredith Lamb (+14169386001)**

He likes to disrespect my boundaries tho


**074.** `19:48` **Meredith Lamb (+14169386001)**

Anyway I’m sorry


**075.** `19:49` **Meredith Lamb (+14169386001)**

You really can trust me


**076.** `19:49` **You**

not your fault nothing you can do


**077.** `19:49` **You**

and I know deep down\.\. I do\.


**078.** `19:49` **You**

I appreciated the label\. really it was sweet and meaningful, and I will own it


**079.** `19:49` **Meredith Lamb (+14169386001)**

I hope you do


**080.** `19:49` **You**

I just need to get through however long this continues for lol\.


**081.** `19:50` **You**

Like I can promise you this


**082.** `19:50` **You**

I will never sleep in a bed with Jaimie again, kiss her, nothing like that\.  ever


**083.** `19:50` **You**

so you don't need to worry about that


**084.** `19:51` **You**

last time I kissed Jaimie was on the cheek before she went to aruba with a half assed hug,


**085.** `19:51` **You**

and before that I cannot remember


**086.** `19:52` **Meredith Lamb (+14169386001)**

I am not anymore either despite the kids… I can’t even remember kissing Andrew\. Probably months ago \(and always forced\)


**087.** `19:52` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Always


**088.** `19:53` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I seriously am yours


**089.** `19:53` **Meredith Lamb (+14169386001)**

You can trust this


**090.** `19:54` **You**

I know mer\.\. it's just a yucky shitty feeling and again I 100% understand the logic\.\. I even through a logic model to rationalize the whole thing\.\. I just fuck I just love you so much it fucking hurts\.\. I don'


**091.** `19:54` **You**

t know how this happened lol


**092.** `19:54` **You**

I am so happy it did\.\.


**093.** `19:54` **You**

I would take this pain 100 times over\. and it would still be more than worth it\.


**094.** `19:55` **Meredith Lamb (+14169386001)**

Did the logic model help? That is intense\.


**095.** `19:55` **You**

it did not help\.\. lol\.\.


**096.** `19:55` **You**

logic failed me


**097.** `19:56` **Meredith Lamb (+14169386001)**

lol


**098.** `19:56` **Meredith Lamb (+14169386001)**

Aw


**099.** `19:56` **You**

the love so fucking much apparently overpowers my logic lol\.\.


**100.** `19:56` **Meredith Lamb (+14169386001)**

I can logic you through it if you need ever


**101.** `19:56` **Meredith Lamb (+14169386001)**

lol


**102.** `19:57` **You**

no it did it for me\.\. it worked\.\. it made sense\. Something like reframe it\.\. she isn't sleeping with her husband \- she is keeping up a facade for the sake of her kids and sacrificing herself in the process\.


**103.** `19:57` **You**

It is just all of the thoughts that go through my head if I think about it make my brain melt\.


**104.** `19:58` **Meredith Lamb (+14169386001)**

It isn’t even for “kids”\. It is for “kid”\. And it isn’t even 50% of the time so said kid knows we are splitting but Andrew thinks she is stupid


**105.** `19:58` **You**

for example\.\. say I was in the same situation \- would you not wonder if J would try to cuddle up to me every night\.\. despite the fact that I would not respond or want that to happen\.


**106.** `19:58` **You**

Your head would melt\.


**107.** `19:59` **You**

I don't even think your vaunted Compartmentalization could deal


**108.** `19:59` **You**

lol


**109.** `19:59` **Meredith Lamb (+14169386001)**

>
Yes 250%\.

*💬 Reply*

**110.** `20:00` **You**

so at least you don't resent me for feeling this way and can understand\.\. I appreciate that\.


**111.** `20:00` **You**

>
You had also told me he was pushy and shit\.\. so that made the thought worse\.

*💬 Reply*

**112.** `20:00` **You**

eesh\.\.


**113.** `20:01` **Meredith Lamb (+14169386001)**

I do understand completely\. It just sucks\. Because I have a 12 yr old and no spare room like in our old house


**114.** `20:01` **Meredith Lamb (+14169386001)**

He is pushy but he has stopped all that


**115.** `20:01` **You**

>
you don't have to explain\.\. I understand

*💬 Reply*

**116.** `20:02` **Meredith Lamb (+14169386001)**

He just talks and emails and texts\. Nothing physical in real life


**117.** `20:02` **Meredith Lamb (+14169386001)**

In Florida we were even in separate rooms


**118.** `20:02` **Meredith Lamb (+14169386001)**

I stayed with Mac


**119.** `20:02` **You**

Yeah I know\.\. you had told me that\.


**120.** `20:04` **Meredith Lamb (+14169386001)**

So I didn’t know this was bothering you today\. Sorry


**121.** `20:04` **You**

I tried really hard not to let it show when it happened\.\. but it was pretty immediate\.\. and I was like moron\!\!\! why did you ask that\.\. you know better\.


**122.** `20:04` **You**

again don't apologize\.\. I did not want you to know


**123.** `20:04` **You**

especially not at work


**124.** `20:06` **Meredith Lamb (+14169386001)**

Argggg


**125.** `20:06` **You**

what's wrong now\.\.


**126.** `20:06` **Meredith Lamb (+14169386001)**

I just wish I knew


**127.** `20:06` **You**

again I didn't want you to


**128.** `20:06` **Meredith Lamb (+14169386001)**

Could have tried to save you some angst


**129.** `20:06` **You**

and it wouldn't have worked


**130.** `20:06` **You**

not then


**131.** `20:07` **You**

when I am deep in something like that I need to take some time to try to get myself out of it\.


**132.** `20:07` **Meredith Lamb (+14169386001)**

I could tell you needed space but I thought it was mostly your fam


**133.** `20:08` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
If only you could be in my head and see how much I think about a new life with you


**134.** `20:08` **You**

nope that was more disappointing\.\. and frustrating\.\.


**135.** `20:08` **You**

same\.\.


**136.** `20:08` **You**

Reaction: ❤️ from Meredith Lamb
all the time\.


**137.** `20:09` **Meredith Lamb (+14169386001)**

\(Just staring at my phone sighing\)


**138.** `20:10` **Meredith Lamb (+14169386001)**

If only I could kiss you right now\. I think you’d feel better\.


**139.** `20:11` **You**

Yeah tbh any contact would make me feel better\.\. it is fine\.\. cannot happen\.\. just the reality of things for now\.


**140.** `20:13` **Meredith Lamb (+14169386001)**

3 days


**141.** `20:14` **You**

I know\.\. feels like a really really long time


**142.** `20:15` **Meredith Lamb (+14169386001)**

Yeah


**143.** `20:16` **Meredith Lamb (+14169386001)**

K Marlowe out of vball


**144.** `20:16` **You**

kk take care


**145.** `20:29` **Meredith Lamb (+14169386001)**

Ok home, but you going to the gym?


**146.** `20:30` **You**

I am shortly\.\.


**147.** `20:31` **Meredith Lamb (+14169386001)**

So is Gracie “ok” now?


**148.** `20:32` **You**

No\.\. she keeps coming at me not to leave\.\.


**149.** `20:33` **Meredith Lamb (+14169386001)**

What does Jamie think about it?


**150.** `20:33` **Meredith Lamb (+14169386001)**

Has she talked to her?


**151.** `20:33` **You**

She isn't engaging in it\.\. still my fault


**152.** `20:34` **Meredith Lamb (+14169386001)**

Shitty… and with the financials and the drama, no second thoughts


**153.** `20:34` **Meredith Lamb (+14169386001)**

And the drama from me lol


**154.** `20:36` **You**

no


**155.** `20:36` **You**

none


**156.** `20:36` **You**

full steam ahead\.\. frustration pain and all\.\. don't care


**157.** `20:38` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
This was the view of my backyard at home growing up\. Keep it as my wallpaper\.

*📎 1 attachment(s)*

**158.** `20:38` **Meredith Lamb (+14169386001)**

That will be us eventually … I feel that feeling when we are together


**159.** `20:39` **You**

I cannot put a big enough heart by that image


**160.** `20:39` **You**

omg 3 days FFS


**161.** `20:39` **Meredith Lamb (+14169386001)**

If I stayed until Tuesday I could go for a walk in those fields\. Will see lol


**162.** `20:40` **You**

If Mac wasn't there I would come\.


**163.** `20:40` **Meredith Lamb (+14169386001)**

:\(


**164.** `20:41` **You**

ok\.\. I am going to get ready for gym\.\. and go beat the shit out of my legs\.\. love you\.\. chat later\.\.  I would call you but don't want to risk it with Andrew around\.


**165.** `20:41` **Meredith Lamb (+14169386001)**

He is at vball but yeah will be back later\. And Marlowe won’t leave me alone


**166.** `20:42` **You**

it's fine\.\. going to go get my shit\.\. will chat later\.


**167.** `20:43` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
kk ❤️


**168.** `21:23` **You**

Still got shadow?


**169.** `21:24` **Meredith Lamb (+14169386001)**

I mean she is around\-ish


**170.** `21:24` **Meredith Lamb (+14169386001)**

:p


**171.** `21:25` **You**

Reaction: 👍 from Meredith Lamb
Got a financial model done high level


**172.** `21:25` **You**

But dun wanna text while driving if we cannot chat we can tomorrow


**173.** `21:26` **Meredith Lamb (+14169386001)**

Better not\. She is in the other room and she will come see what I’m doing 😫


**174.** `21:26` **You**

Kk


**175.** `21:26` **Meredith Lamb (+14169386001)**

If she hears me talking


**176.** `21:29` **You**

Actually not gonna go gonna go back and work in this more


**177.** `21:29` **You**

I want it done asap


**178.** `21:29` **Meredith Lamb (+14169386001)**

You are in car and turning around?


**179.** `21:34` **You**

Yep


**180.** `21:34` **You**

I can do a mini workout at home


**181.** `21:35` **Meredith Lamb (+14169386001)**

Maybe you should chill and try to get more sleep tonight


**182.** `21:35` **You**

Nope lose more weight


**183.** `21:36` **Meredith Lamb (+14169386001)**

Omg chill


**184.** `21:36` **You**

Nah fuck dad boss


**185.** `21:36` **You**

Bods


**186.** `21:40` **You**

kk back home\.\.\. you can chat whenever you want but don't feel obligated you probably next deep in handmaids tale\.\. I am around is all going to work on this and look for stupdio rentals\.


**187.** `22:19` **You**

Reaction: 😂 from Meredith Lamb
Not back home being sent to weed store for Gracie


**188.** `22:19` **You**

I cannot wait to get out of here


**189.** `22:46` **Meredith Lamb (+14169386001)**

Sorry, argument evening\. Not horrible\. Just arguing …\.


**190.** `22:46` **You**

Fack really


**191.** `22:47` **Meredith Lamb (+14169386001)**

Well we have to sort this financial crap


**192.** `22:47` **Meredith Lamb (+14169386001)**

I’m annoyed at his narrative


**193.** `22:47` **You**

listen easy solution pay a couple of grand to get a lawyer to at least look at it\.\.


**194.** `22:47` **You**

if he is cheating you


**195.** `22:48` **You**

he will shit himself about it


**196.** `22:48` **Meredith Lamb (+14169386001)**

We lived this extremely married life for 15 years\. Now he is clinging to the common law narrative and it is insulting to me … I sacrificed a lot


**197.** `22:48` **Meredith Lamb (+14169386001)**

Anyway


**198.** `22:48` **You**

again threaten lawyer


**199.** `22:48` **Meredith Lamb (+14169386001)**

We are going to a mediator when we think we have landed


**200.** `22:48` **You**

its a threat nothing else\.


**201.** `22:48` **Meredith Lamb (+14169386001)**

I think the current might be fine\. Going to look one more time tomorrow


**202.** `22:48` **You**

kk


**203.** `22:49` **Meredith Lamb (+14169386001)**

So done with all of this


**204.** `22:49` **Meredith Lamb (+14169386001)**

Gahhhh


**205.** `22:49` **Meredith Lamb (+14169386001)**

It’s exhausting


**206.** `22:49` **You**

yeah I know\.\. I have an idea for Sat\.


**207.** `22:49` **Meredith Lamb (+14169386001)**

>
Sleep?💤

*💬 Reply*

**208.** `22:49` **Meredith Lamb (+14169386001)**

lol


**209.** `22:50` **Meredith Lamb (+14169386001)**

Once we land on our financials we are going to sit with it for a week, see if it sticks for a week …then see mediator\.


**210.** `22:51` **You**

no not sleep


**211.** `22:51` **You**

but I for one am not going to worry about what I might feel like after the weekend is over regardless\.


**212.** `22:52` **You**

>
your idea or has he agreed

*💬 Reply*

**213.** `22:53` **Meredith Lamb (+14169386001)**

>
I’m just stressed bc if he wants to keep house for kids plus we keep cottage 50/50, with house Reno’s etc he can only afford a one time $150k spousal support payment which is way below what is considered fair under circumstances

*💬 Reply*

**214.** `22:53` **Meredith Lamb (+14169386001)**

So do I accept it for my kids


**215.** `22:53` **Meredith Lamb (+14169386001)**

If I don’t


**216.** `22:53` **Meredith Lamb (+14169386001)**

We need to sell something


**217.** `22:53` **You**

you mean 150k per year correct


**218.** `22:54` **You**

you won't be able to afford anything


**219.** `22:54` **You**

at least not easily


**220.** `22:54` **Meredith Lamb (+14169386001)**

No I mean 150k once\. \(Child support would be monthly on top of that\.\)


**221.** `22:54` **You**

yeah no that is bullshit


**222.** `22:54` **You**

you want to know what my spousal support is


**223.** `22:54` **You**

Reaction: 😮 from Meredith Lamb
400k


**224.** `22:54` **Meredith Lamb (+14169386001)**

I get that I can get more\. It’s just we have to sell then


**225.** `22:54` **You**

and that is me


**226.** `22:55` **You**

so all sharing\.\. I have way less than you guys\.\. but we are 2\.4 mil on paper right now\.


**227.** `22:55` **You**

I think she will get something like 1\.7


**228.** `22:55` **You**

lol


**229.** `22:55` **Meredith Lamb (+14169386001)**

2\.4m in what?


**230.** `22:55` **You**

just net worth


**231.** `22:56` **You**

not including pension


**232.** `22:56` **Meredith Lamb (+14169386001)**

Yeah we haven’t included rrsps


**233.** `22:56` **You**

well they need to be included mer


**234.** `22:56` **You**

everything does


**235.** `22:56` **You**

it all goes into the pile lol\.


**236.** `22:57` **Meredith Lamb (+14169386001)**

Well we are common law so it is different


**237.** `22:57` **You**

so I think she will be at 1\.7 after I include my penison


**238.** `22:57` **You**

not that much\.


**239.** `22:57` **You**

only what came before


**240.** `22:57` **Meredith Lamb (+14169386001)**

Slightly


**241.** `23:00` **Meredith Lamb (+14169386001)**

Key Elements of Your Situation:
- Common\-law relationship: 15 years
- 3 children
- Your income: $150K
- His income: $550K
- You receive full child support
- Equal asset division
- $150K one\-time spousal support payment
⸻
What This Means in Context:
1\. Child Support Already Helps Offset Income Disparity
If you’re receiving full Table child support \(i\.e\., based on his $550K income and you having primary or majority parenting time\), that could be $2,000–$3,000\+ per month—a meaningful monthly contribution\.
However, child support is for the children, not for your personal needs or long\-term support\. Courts don’t consider child support a substitute for spousal support, though it may reduce the amount or duration of spousal support in some cases\.
⸻
2\. Equal Asset Division
Equal asset division means there’s no property\-based compensation for career sacrifices, homemaking, or lost income opportunity\. So, unless the asset division is tilted heavily in your favour \(which it’s not here\), that also doesn’t replace spousal support\.
⸻
3\. Is $150,000 Fair in this Context?
The SSAG estimates showed a 10\-year total spousal support range of $900,000 to $1\.2 million\. If you’re receiving just $150,000, even with child support and an equal split of property:
- It’s still well below the lower guideline unless there’s a strong justification \(e\.g\., you asked for a clean break\)\.
- It could potentially be seen as unfair by a judge unless you voluntarily waive support with legal advice\.
⸻
Bottom Line
- If the $150K is truly meant to replace ongoing spousal support, it is likely inadequate under Ontario family law norms unless supported by other compensating factors \(which don’t seem present here\)\.
- It may be acceptable only if:
- You are choosing it in exchange for a clean break\.
- You’ve had independent legal advice and fully understand the tradeoffs\.
- The child support is generous and ongoing\.
- You’re confident in your long\-term financial security\.


**242.** `23:01` **Meredith Lamb (+14169386001)**

I’m stressed\.


**243.** `23:01` **Meredith Lamb (+14169386001)**

This whole situation sucks\.


**244.** `23:06` **You**

it gets kinda worse\.\. because you left some stuff out


**245.** `23:06` **You**

factor in the following


**246.** `23:06` **You**

and the courts actually take this shit really seriously


**247.** `23:07` **You**

Business Degree, MBA took off 7 years to have and raise 3 children while he furthered his education and career by getting a masters and phd\.\. etc


**248.** `23:07` **You**

he is very much ripping you off imho\.\. again trying not to get involved but 150k is a fucking joke for 16 years\+ the other stuff I mentioned\.


**249.** `23:08` **You**

7 years income by itself is 800k for you at least\.


**250.** `23:08` **You**

and then it is the wage increases and advnacements you passed up


**251.** `23:10` **You**

I also don't know your asset breakout but remember the debt and the equity are also shared equally\.\. so let's say you have a mortgage on a cottage worth 1\.5 million\.\. and the mortgage is 1 million\. well you arent' getting half value of 1\.5 million you are getting have value for 500k\.


**252.** `23:29` **You**

I hope you are ok\.


**253.** `23:38` **Meredith Lamb (+14169386001)**

Sigh… my head is going to explode\. Sorry he wouldn’t leave\.


**254.** `23:38` **You**

sok


**255.** `23:38` **You**

I been working on my own shit


**256.** `23:39` **You**

and gracie has been cry screaming at met


**257.** `23:39` **You**

this is such a toxic relationship now :\(


**258.** `23:39` **Meredith Lamb (+14169386001)**

Omg\.


**259.** `23:39` **Meredith Lamb (+14169386001)**

Today is the worst\.


**260.** `23:40` **Meredith Lamb (+14169386001)**

wtf


**261.** `23:40` **You**

:\( for everyone


**262.** `23:41` **Meredith Lamb (+14169386001)**

He’s driving me crazy\. At one point he accused me of not getting jobs with high enough salaries\.


**263.** `23:41` **Meredith Lamb (+14169386001)**

Hated that I went to Enbridge


**264.** `23:41` **Meredith Lamb (+14169386001)**

He wanted me to work in a sweatshop situation for more $


**265.** `23:42` **Meredith Lamb (+14169386001)**

There was a mention of “oh sorry that I took 5 years to take care of YOUR family” and he goes “but did you really?”


**266.** `23:42` **Meredith Lamb (+14169386001)**

I honestly have never felt my head go so black in my life\.


**267.** `23:43` **Meredith Lamb (+14169386001)**

Just pure rage\.


**268.** `23:43` **You**

jesus


**269.** `23:43` **You**

ouch


**270.** `23:43` **You**

like wow


**271.** `23:46` **You**

maybe disengage


**272.** `23:47` **Meredith Lamb (+14169386001)**

Reaction: 😢 from Scott Hicks
Yeah I’m going to stop thinking about it until tomorrow\.


**273.** `23:48` **You**

I am so sorry you had a bad night


**274.** `23:49` **Meredith Lamb (+14169386001)**

Sigh, I so wish I did this 3 yrs ago and ppl didn’t talk me out of it\. But oh well\.


**275.** `23:49` **You**

>
just want to make sure you didn't miss this comment from earlier\.

*💬 Reply*

**276.** `23:51` **Meredith Lamb (+14169386001)**

So what’s your idea


**277.** `23:51` **You**

to remove restrictions


**278.** `23:52` **Meredith Lamb (+14169386001)**

I am probably going to worry about after the weekend lol


**279.** `23:52` **You**

and not worry


**280.** `23:52` **Meredith Lamb (+14169386001)**

Just saying


**281.** `23:52` **Meredith Lamb (+14169386001)**

lol


**282.** `23:52` **You**

and not worry


**283.** `23:52` **Meredith Lamb (+14169386001)**

It’s a worrying time\!


**284.** `23:52` **You**

what would you worry about\.\. I am 1000% yours


**285.** `23:52` **Meredith Lamb (+14169386001)**

I would worry about the immense time away from you being much more painful


**286.** `23:52` **You**

and we will be careful and I am moving out sooner than I thought


**287.** `23:53` **Meredith Lamb (+14169386001)**

I would also worry about work getting more complicated


**288.** `23:54` **Meredith Lamb (+14169386001)**

I would worry


**289.** `23:54` **Meredith Lamb (+14169386001)**

I feel like I’m really good at it these days :p


**290.** `23:54` **You**

I am not worrying I think it would get easier


**291.** `23:55` **You**

I think when we are on our own\.\. even with our own responsibilities\.\. having had some time together like detroit, and knowing there is an endpoint to work towards\.\. I can get behind that\.


**292.** `23:56` **Meredith Lamb (+14169386001)**

Listen, all I want to do in Detroit is hole up in a room with you\. I think about the last time in my car constantly\.


**293.** `23:56` **Meredith Lamb (+14169386001)**

It doesn’t remove my worry\.


**294.** `23:56` **You**

perfect\.\. let's do that


**295.** `23:56` **You**

and not worry


**296.** `23:57` **You**

correction let's do that\.\. and then be careful\.\. and worry less


**297.** `23:57` **Meredith Lamb (+14169386001)**

lol


**298.** `23:57` **Meredith Lamb (+14169386001)**

So easy


**299.** `23:57` **You**

I told you I am easy


**300.** `23:58` **Meredith Lamb (+14169386001)**

Ha


**301.** `23:58` **You**

you will see


**302.** `23:58` **Meredith Lamb (+14169386001)**

I easily could have done more in that car \(despite the discomfort lol\) and it was pretty clear you would have also but I’m glad you didn’t push\.


**303.** `23:59` **Meredith Lamb (+14169386001)**

I know it was hard


**304.** `23:59` **You**

no pun intended


**305.** `23:59` **Meredith Lamb (+14169386001)**

Doh


**306.** `23:59` **You**

in either of those sentences


**307.** `23:59` **You**

well played back to back


**308.** `23:59` **Meredith Lamb (+14169386001)**

Doh


**309.** `23:59` **Meredith Lamb (+14169386001)**

lol


**310.** `23:59` **You**

omg mer


**311.** `23:59` **You**

I need to like screenshot that


**312.** `23:59` **You**

and frame it


**313.** `23:59` **Meredith Lamb (+14169386001)**

lol hahaha


**314.** `23:59` **You**

and hang it at my desk


**315.** `23:59` **Meredith Lamb (+14169386001)**

Please don’t


