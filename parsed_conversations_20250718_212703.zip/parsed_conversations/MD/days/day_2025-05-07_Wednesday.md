# Daily Conversation: 2025-05-07 (Wednesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-07 |
| **Day** | Wednesday |
| **Week** | 4 |
| **Messages** | 336 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-07T04:16 - 2025-05-07T23:58 |

## 📝 Daily Summary

This day contains **336 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `04:16` **You**

I keep track of everything\.\. don’t you worry


**002.** `04:35` **You**

Btw Sharon is back\!\!\!\! In J’s mind\.


**003.** `04:35` **You**

She thinks my 5 hours a day at gym is because I am dating Sharon\.


**004.** `04:35` **You**

Maybe a little something for you to consider huh…\.


**005.** `05:51` **Meredith Lamb (+14169386001)**

I mean she isn’t wrong\. Lol knows you well obviously


**006.** `05:57` **You**

And Sharon I mean she knows Sharon too\.


**007.** `05:57` **You**

You know Sharon… she’s crazy\!\!\!


**008.** `05:58` **You**

🥰


**009.** `06:00` **You**

Crazy hot and amazing


**010.** `06:01` **You**

And and and


**011.** `06:01` **Meredith Lamb (+14169386001)**

Definitely crazy right now\. Lol


**012.** `06:01` **You**

Nice way to wake up\.\.


**013.** `06:01` **Meredith Lamb (+14169386001)**

How did that conversation go?


**014.** `06:01` **You**

Which one


**015.** `06:01` **You**

Oh


**016.** `06:02` **You**

Short


**017.** `06:02` **Meredith Lamb (+14169386001)**

I wonder if you are a good liar re Sharon


**018.** `06:02` **You**

And over


**019.** `06:02` **You**

I told I will video call her every workout


**020.** `06:02` **You**

For the whole time


**021.** `06:02` **You**

She backed off


**022.** `06:02` **Meredith Lamb (+14169386001)**

Haha


**023.** `06:02` **You**

Speaking of video calls\.\. squats
Today lol\.\.😂


**024.** `06:02` **Meredith Lamb (+14169386001)**

Are you at gym now


**025.** `06:03` **You**

Yep


**026.** `06:03` **You**

Been here for a it


**027.** `06:03` **You**

But


**028.** `06:03` **Meredith Lamb (+14169386001)**

Omg


**029.** `06:03` **You**

Bit


**030.** `06:03` **You**

5:30


**031.** `06:03` **You**

Up at 4:45


**032.** `06:03` **You**

Feels good


**033.** `06:03` **Meredith Lamb (+14169386001)**

Until you crash later


**034.** `06:03` **You**

Nope


**035.** `06:03` **You**

I didn’t last night


**036.** `06:04` **You**

Went to sleep right before t you responded


**037.** `06:04` **Meredith Lamb (+14169386001)**

That’s good but you should get more sleep at least one day a week or something


**038.** `06:04` **You**

So I am going to ask Jim to come for a drink and/or a dinner tonight\. Fyi\.


**039.** `06:05` **Meredith Lamb (+14169386001)**

For real?


**040.** `06:05` **You**

Yah


**041.** `06:05` **You**

He likes to be wined and dined


**042.** `06:05` **Meredith Lamb (+14169386001)**

lol indeed


**043.** `06:06` **You**

Put the moves on him\.\.


**044.** `06:06` **Meredith Lamb (+14169386001)**

He will be surprised


**045.** `06:06` **You**

He will


**046.** `06:06` **You**

I will let
You know if goes
Off
On a tangent


**047.** `06:06` **You**

You focus on your stuff today more important


**048.** `06:06` **Meredith Lamb (+14169386001)**

He will be calling today to find out about girls for sure


**049.** `06:06` **You**

No doubt\.\. I will try to get him early


**050.** `06:06` **Meredith Lamb (+14169386001)**

I have some major work stuff to do today


**051.** `06:06` **You**

So he can ask you about the call


**052.** `06:06` **You**

Yeah you do you\.


**053.** `06:07` **Meredith Lamb (+14169386001)**

K but I don’t have calls all day so we can chat at some point


**054.** `06:08` **You**

Kk I would
Like that of course\.\. always like that ☺️


**055.** `06:09` **Meredith Lamb (+14169386001)**

k, I’m going to lie with griffin until 7\. He likes attention in the morning lol


**056.** `06:09` **Meredith Lamb (+14169386001)**

He’s a baby


**057.** `06:09` **You**

Lucky him


**058.** `06:09` **You**

Jealous


**059.** `06:09` **You**

Griffin……


**060.** `06:09` **Meredith Lamb (+14169386001)**

Yep you should be\. He gets spoiled


**061.** `06:10` **You**

Well he will
Only get
More
When I am around… so love dogs


**062.** `06:10` **You**

You have a partner there
For sure


**063.** `06:10` **You**

Reaction: ❤️ from Meredith Lamb
Kk go cuddle chat later


**064.** `06:12` **You**

Love you\.


**065.** `09:50` **You**

Check out this listing
https://realtor\.ca/real\-estate/27978860/35\-venetian\-drive\-riverview?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**066.** `09:51` **You**

Check out this listing
https://realtor\.ca/real\-estate/28260903/721\-pinewood\-road\-riverview?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


**067.** `11:17` **You**

While I believe you and I were meant to be can you see me fitting into your life\.\. like I am just worried I won’t\.


**068.** `11:17` **You**

Just\. A thought out of our earlier convo


**069.** `11:17` **Meredith Lamb (+14169386001)**

🙄


**070.** `11:17` **Meredith Lamb (+14169386001)**

Good response?


**071.** `11:18` **You**

Ummmmmmm mmmmm hmmmmm yes yes… very interesting\.


**072.** `11:20` **Meredith Lamb (+14169386001)**

When I said that I feel like you are home to me, I wasn’t lying\. Just because I had this particular life for the last few years doesn’t mean it felt right\. You feel right so I don’t understand how you couldn’t fit in to my life honestly\.


**073.** `12:05` **You**

I feel the same
Way but there is you and then there is this massive thing that is your life… and i guess I just don’t see where I fit except as the boy you keep off to the side jk… this is a ways out miles and miles and soooo many miles to go before that is a problem to worry about\.


**074.** `12:06` **You**

My life is small and simple compared\.\. so it is just timing\.\. everything else is easy\.


**075.** `12:06` **Meredith Lamb (+14169386001)**

My life is not massive\.


**076.** `12:06` **Meredith Lamb (+14169386001)**

Omg


**077.** `12:06` **You**

Relatively speaking


**078.** `12:07` **Meredith Lamb (+14169386001)**

I mean it is a bit more chaotic bc big family, younger kids, and 1 extra kid\.


**079.** `12:07` **Meredith Lamb (+14169386001)**

Otherwise same


**080.** `12:10` **You**

I mean yeah it soo sounds the same\.\.


**081.** `12:10` **Meredith Lamb (+14169386001)**

I’m not sure why it matters


**082.** `12:25` **You**

It probably doesn’t, miles away, just a thought that popped
Into my brain\.


**083.** `12:42` **Meredith Lamb (+14169386001)**

You would integrate into my life easily and could probably pull it off better than I can\. You have more energy than I do\.


**084.** `12:43` **You**

As you said I will focus on just integrating with you first that is what I want more than anything else regardless


**085.** `13:02` **You**

Hey I am going to need some me time to process some stuff today so I am not going to attend the team meeting\.


**086.** `13:07` **Meredith Lamb (+14169386001)**

Totally cool\. We are going to go over your list and status so I will update you at our one on one … we can actually talk about work maybe


**087.** `13:08` **Meredith Lamb (+14169386001)**

>
My family will like you and there isn’t any crazy upset people in my family by my whole situation so you will be entering a pretty drama free environment\. Andrew will be the only wild card\.

*💬 Reply*

**088.** `13:09` **You**

Sry yeah I moved past that but appreciate it I do want everyone to like me so I can fully be with you\.\. b


**089.** `13:17` **Meredith Lamb (+14169386001)**

Do you really believe I would treat you as “this boy i keep off to the side”??? Lol


**090.** `13:18` **You**

My issue is I feel trapped right now and I need to breathe… so j says just take more trips to Chatham T least the company pays\.\.


**091.** `13:18` **You**

I mean my idea\!\!\! lol


**092.** `13:18` **You**

But I am thinking of finding\. Studio or something


**093.** `13:18` **You**

Just to get the fuck out of the basement for a few months not sure


**094.** `13:19` **You**

Doing the hotel thing
For work isn’t bad either but it needs to make sense


**095.** `13:19` **You**

But I have to breathe to do something I know I cannot stay there until July\.


**096.** `13:19` **You**

At least not with both her and d grace there


**097.** `13:19` **Meredith Lamb (+14169386001)**

You need a mind map


**098.** `13:20` **You**

You need a mind map…


**099.** `13:20` **Meredith Lamb (+14169386001)**

🙄


**100.** `13:22` **You**

I need a lot of things… mind maps aren’t going to cut it\.\. not in this mind\.


**101.** `13:22` **Meredith Lamb (+14169386001)**

Can you afford a studio


**102.** `13:22` **Meredith Lamb (+14169386001)**

You could always just do some short term air bnbs here and there


**103.** `13:23` **You**

I don’t know maybe I am going to look part of the reason I live at the gym or need to make friends or just something


**104.** `13:25` **Meredith Lamb (+14169386001)**

You just want a single Sharon in Whitby who has tons of time on her hands\. 😜


**105.** `13:25` **You**

Sounds about right\.


**106.** `13:25` **You**

As long as we agree Sharon is you\.\.


**107.** `13:26` **You**

Other than that refer to previous statement because that doesn’t exist\.


**108.** `13:26` **Meredith Lamb (+14169386001)**

You never know\. Once you go looking…


**109.** `13:27` **Meredith Lamb (+14169386001)**

Sowing your oats…


**110.** `13:27` **Meredith Lamb (+14169386001)**

:p


**111.** `13:27` **Meredith Lamb (+14169386001)**

See where your messages take my head


**112.** `13:27` **You**

It’s very unfair\.


**113.** `13:27` **You**

I would never do that


**114.** `13:27` **You**

I just need something g to keep me from going insane


**115.** `13:27` **You**

You know what I had to stop doing


**116.** `13:28` **Meredith Lamb (+14169386001)**

k\.\.


**117.** `13:28` **You**

I had to stop listening to the mix tape and Morgan wallen\.


**118.** `13:28` **Meredith Lamb (+14169386001)**

Fair enough


**119.** `13:28` **You**

Because I do that and I cannot stop thinking of you or the dance or any of it\.\. lol


**120.** `13:29` **You**

Which sure if I am you I am maybe super supe reassured that this guy is absolutely in love with me\.


**121.** `13:29` **You**

But S me


**122.** `13:29` **You**

As me


**123.** `13:30` **You**

Like I am just trying to run around trying to find a way to distract myself, to kill time to get me to the next day and the next
Etc


**124.** `13:31` **You**

I know please you wanted me to be honest I didn’t want to talk about it anymore\.\. lol I am stuck


**125.** `13:31` **Meredith Lamb (+14169386001)**

I think once my separation agreement is done in a few weeks and then I’m in a new place you will feel differently


**126.** `17:08` **Meredith Lamb (+14169386001)**

Am I going to be getting shocked texts from Jim?


**127.** `17:09` **You**

Nope


**128.** `17:10` **Meredith Lamb (+14169386001)**

k… glad you aren’t a loose cannon today lol


**129.** `17:12` **You**

Nope I am just leaving to go home\.  Nothing to report\.


**130.** `17:13` **Meredith Lamb (+14169386001)**

How’d it go?


**131.** `17:27` **You**

Pretty easy straightforward


**132.** `17:27` **You**

Very supportive as Jim is


**133.** `17:27` **You**

No clue about is that he let I\. To


**134.** `17:28` **You**

You were only mentioned peripherally


**135.** `17:28` **You**

Although he has an interesting observation


**136.** `17:28` **You**

Very astute


**137.** `17:28` **You**

But it is a
Conversation not a text


**138.** `17:29` **You**

Especially when I am driving


**139.** `17:30` **Meredith Lamb (+14169386001)**

kk


**140.** `17:32` **You**

Point is nothing for you to worry about


**141.** `17:32` **Meredith Lamb (+14169386001)**

k I wasn’t worried per se


**142.** `17:32` **Meredith Lamb (+14169386001)**

lol


**143.** `17:32` **You**

Sure


**144.** `17:32` **Meredith Lamb (+14169386001)**

Well


**145.** `17:33` **Meredith Lamb (+14169386001)**

Not sure if I’m ready for Jim’s reaction to the whole thing


**146.** `17:33` **You**

Yep\. Awkward situational


**147.** `19:43` **You**

Been quiet a while hope everything is ok\.


**148.** `19:51` **Meredith Lamb (+14169386001)**

Just pulled in driveway and volleyball duties done for tonight :p


**149.** `20:01` **You**

Ah ok didnt know\.\.


**150.** `20:01` **You**

Thought bad news or Andrew or other stuff


**151.** `20:02` **Meredith Lamb (+14169386001)**

No but he did super bug me so I fought with him after work\. He called me self centred AGAIN


**152.** `20:03` **Meredith Lamb (+14169386001)**

I can’t…\.


**153.** `20:03` **You**

Ok don’t need to discuss


**154.** `20:04` **Meredith Lamb (+14169386001)**

Just trying to forget about it\. Very disturbing to keep getting called that and told him it better not be the narrative of our separation\. I will be pissed


**155.** `20:05` **You**

Sorry mer it isn’t who you are it is how he needs to frame you so he can tolerate himself


**156.** `20:06` **You**

Look we do t have to chat tonight if you need a break\.\.


**157.** `20:07` **Meredith Lamb (+14169386001)**

Exhausting\. Just cleaning up work emails


**158.** `20:07` **You**

Kk


**159.** `20:09` **Meredith Lamb (+14169386001)**

I do want to hear about Jim’s “astute” observation tho


**160.** `20:09` **Meredith Lamb (+14169386001)**

lol


**161.** `20:09` **You**

Well it is better discussed but whatever I will try to put in words that make sense


**162.** `20:10` **Meredith Lamb (+14169386001)**

You can call me\. I’m alone in my office


**163.** `21:26` **Meredith Lamb (+14169386001)**

If I go to Oshawa Friday night, you want to get together?


**164.** `21:26` **You**

Do you really have to ask


**165.** `21:26` **Meredith Lamb (+14169386001)**

Well, yeah


**166.** `21:26` **Meredith Lamb (+14169386001)**

lol


**167.** `21:27` **Meredith Lamb (+14169386001)**

Because I wouldn’t go otherwise


**168.** `21:27` **You**

What do you want to do?


**169.** `21:27` **Meredith Lamb (+14169386001)**

Not sure yet


**170.** `21:27` **Meredith Lamb (+14169386001)**

But I will figure it out


**171.** `21:27` **You**

Kk let me know I could actually go away for that night


**172.** `21:28` **Meredith Lamb (+14169386001)**

Go away?


**173.** `21:28` **You**

At least I have the option


**174.** `21:28` **Meredith Lamb (+14169386001)**

Hrm?


**175.** `21:28` **You**

J has told me just take the fuck off air bib or whatever


**176.** `21:28` **Meredith Lamb (+14169386001)**

Hmm ok let me think about that


**177.** `21:28` **You**

Think away\.


**178.** `21:28` **Meredith Lamb (+14169386001)**

K


**179.** `21:28` **Meredith Lamb (+14169386001)**

lol


**180.** `21:29` **You**

I mean I could book a couple of days it wouldnt be as suspicious I think


**181.** `21:29` **You**

Rather than just one


**182.** `21:30` **You**

Or saying yku staying for that saying I am


**183.** `21:30` **You**

Not


**184.** `21:30` **Meredith Lamb (+14169386001)**

So the plan for my mom is the girls need to be ready at like 7 or 7\.30 sat night\. No earlier


**185.** `21:31` **Meredith Lamb (+14169386001)**

So I just need to have them to Oshawa for then


**186.** `21:31` **Meredith Lamb (+14169386001)**

But I can always say I’m going to spend time with my parents\. Not unusual\. I’m close with them


**187.** `21:31` **You**

I am good with whatever mer\.


**188.** `21:32` **Meredith Lamb (+14169386001)**

I’m a LITTLE reluctant to say just come to my parents but not fully \(lol spoiled\)


**189.** `21:32` **Meredith Lamb (+14169386001)**

It feels a little weird at 47


**190.** `21:32` **You**

I still want to meet your mum but only when you are comfortable


**191.** `21:32` **You**

But I like the idea of a non


**192.** `21:32` **Meredith Lamb (+14169386001)**

But it wouldn’t have been weird before 20 yrs ago


**193.** `21:32` **You**

Bnb


**194.** `21:33` **You**

Yeah I could do Friday and Saturday then I am sure hi have to do some northern day thing Sunday


**195.** `21:33` **Meredith Lamb (+14169386001)**

You like the idea of my parents basement better?


**196.** `21:34` **Meredith Lamb (+14169386001)**

You said “non air bnb”


**197.** `21:34` **You**

Staying the night with you in your parents basement


**198.** `21:34` **Meredith Lamb (+14169386001)**

>
This is better?

*💬 Reply*

**199.** `21:34` **You**

No I like the idea of air bnb


**200.** `21:34` **Meredith Lamb (+14169386001)**

Oh ok


**201.** `21:34` **You**

Because I pay for it there is a record


**202.** `21:34` **You**

Cannot just say see ya


**203.** `21:34` **You**

lol


**204.** `21:34` **Meredith Lamb (+14169386001)**

Ahhh


**205.** `21:34` **Meredith Lamb (+14169386001)**

lol


**206.** `21:35` **Meredith Lamb (+14169386001)**

I would have to have my parents cover for me lol


**207.** `21:35` **You**

So whatever works for you\.\. I will find some place perhaps near
To your parents


**208.** `21:35` **Meredith Lamb (+14169386001)**

Maybe I could work from home tomorrow and discuss with my mom


**209.** `21:35` **You**

What are they north Oshawa


**210.** `21:35` **Meredith Lamb (+14169386001)**

I only texted with her today


**211.** `21:35` **Meredith Lamb (+14169386001)**

Yeah near airport


**212.** `21:35` **Meredith Lamb (+14169386001)**

827 law street


**213.** `21:36` **You**

Yeah whatever works yku will miss me tomorrow though


**214.** `21:36` **You**

Not gonna lie


**215.** `21:36` **You**

It’s a good workout tomorrow\.\. too bad


**216.** `21:37` **Meredith Lamb (+14169386001)**

It’s hard for me to talk to my mom from office


**217.** `21:37` **Meredith Lamb (+14169386001)**

I can get her on board but requires a conversation not texting


**218.** `21:37` **Meredith Lamb (+14169386001)**

:p


**219.** `21:37` **Meredith Lamb (+14169386001)**

And she talks on and on and on and on


**220.** `21:37` **Meredith Lamb (+14169386001)**

And on and on and on and on


**221.** `21:38` **Meredith Lamb (+14169386001)**

Kinda like someone else I know 😇


**222.** `21:41` **You**

Ok up to you\.\. like I said you miss\.\.


**223.** `21:41` **You**

Anyhow I am going into sauna now\.\. will chat later or if you are asleep say goodnight then\.


**224.** `21:42` **You**

Always those private booths\. Anyhow later


**225.** `21:56` **Meredith Lamb (+14169386001)**

Private booths?


**226.** `21:56` **Meredith Lamb (+14169386001)**

Not speaking my language


**227.** `21:56` **Meredith Lamb (+14169386001)**

Had to talk to Andrew and girls about weekend


**228.** `21:57` **Meredith Lamb (+14169386001)**

I can do Friday night but need to clear it with my mom tomorrow to cover for me


**229.** `21:57` **Meredith Lamb (+14169386001)**

I need her or it doesn’t work


**230.** `21:57` **Meredith Lamb (+14169386001)**

Andrew either stays home from cottage or gets his mom to come for Friday night


**231.** `21:57` **Meredith Lamb (+14169386001)**

We will see


**232.** `22:14` **You**

Kk I meant the sound proof booths


**233.** `22:14` **You**

So I won’t get my hopes up yet or tell Jaimie anything


**234.** `22:14` **Meredith Lamb (+14169386001)**

Hrm?


**235.** `22:15` **Meredith Lamb (+14169386001)**

You are confusing sometimes


**236.** `22:15` **Meredith Lamb (+14169386001)**

So let me talk to my mom tomorrow


**237.** `22:15` **Meredith Lamb (+14169386001)**

Then we should be good


**238.** `22:15` **Meredith Lamb (+14169386001)**

If she cooperates we are good lol


**239.** `22:15` **You**

The private booths to talk to your mum I referenced the sound proof booths then you said a bunch of stuff I didn’t understand


**240.** `22:15` **Meredith Lamb (+14169386001)**

Oh


**241.** `22:15` **You**

But it was like maybe maybe not so I just said I will wait and see


**242.** `22:16` **You**

Again not get hopes up or plan anything yet


**243.** `22:16` **You**

That’s all


**244.** `22:16` **Meredith Lamb (+14169386001)**

I’m just going to wfh and then I can reach her easier at some point


**245.** `22:16` **Meredith Lamb (+14169386001)**

Plus I’m fucking tired


**246.** `22:16` **You**

Kk


**247.** `22:17` **Meredith Lamb (+14169386001)**

I can’t even talk at me desk bc Carolyn is like eagle ears


**248.** `22:17` **You**

It’s all good
You do t need to explain


**249.** `22:17` **Meredith Lamb (+14169386001)**

And then she asks questions after my calls lol


**250.** `22:17` **Meredith Lamb (+14169386001)**

She doesn’t even apologize for eavesdropping


**251.** `22:17` **Meredith Lamb (+14169386001)**

Hilarious


**252.** `22:17` **Meredith Lamb (+14169386001)**

I mean I kind of admire that


**253.** `22:17` **Meredith Lamb (+14169386001)**

But it is cray


**254.** `22:17` **You**

Oh I know she is nosey I have told her to stop it before


**255.** `22:18` **Meredith Lamb (+14169386001)**

She is INTENSE


**256.** `22:18` **Meredith Lamb (+14169386001)**

it’s all good when work related


**257.** `22:18` **Meredith Lamb (+14169386001)**

Just not when personal


**258.** `22:18` **You**

Yep I can’t trust her with anything like this


**259.** `22:19` **Meredith Lamb (+14169386001)**

When we are talking in your office now she a us so diff after


**260.** `22:19` **Meredith Lamb (+14169386001)**

She doesn’t ask me questions


**261.** `22:19` **Meredith Lamb (+14169386001)**

\*she acts


**262.** `22:19` **You**

lol


**263.** `22:19` **Meredith Lamb (+14169386001)**

She just wants to be in the know


**264.** `22:19` **You**

Always


**265.** `22:19` **You**

I haven’t been talking to her much lately


**266.** `22:20` **You**

I think it os driving her crazy


**267.** `22:20` **Meredith Lamb (+14169386001)**

Yah


**268.** `22:20` **Meredith Lamb (+14169386001)**

She really thinks highly of you and obviously cares about you


**269.** `22:20` **Meredith Lamb (+14169386001)**

Kind of bothers me lol


**270.** `22:20` **Meredith Lamb (+14169386001)**

Hahah


**271.** `22:20` **Meredith Lamb (+14169386001)**

I’m getting used to it


**272.** `22:20` **You**

I don’t understand why people liking me bother you when you are the only one I think about ever


**273.** `22:21` **You**

I am literally neurotic


**274.** `22:21` **You**

Like I mean if I was old me


**275.** `22:21` **You**

Cold and kind of distant or kind of harder to read I would get
Your feelings


**276.** `22:22` **You**

But I have been begging just to see you and I say that in a way that I want to make
You feel amazing and nothing else


**277.** `22:22` **You**

Like that is all there is to it mer\.


**278.** `22:22` **You**

You literally never have to be jealous


**279.** `22:22` **Meredith Lamb (+14169386001)**

It doesn’t “bother me”\. \.\. it just bothers me


**280.** `22:22` **You**

No one will get any part of me but you


**281.** `22:23` **You**

Reaction: 🤔 from Meredith Lamb
So you can let just fall…listen I don’t flirt


**282.** `22:23` **You**

I don’t tease I don’t lead on


**283.** `22:23` **You**

I do t play games


**284.** `22:23` **You**

And I only text dirty things to you\.


**285.** `22:23` **You**

Sooooooo


**286.** `22:24` **You**

So frustrating that I cannot show you truly how I really feel
Every moment all the time till we can be together sometime in the next
Decade


**287.** `22:24` **Meredith Lamb (+14169386001)**

lol


**288.** `22:24` **Meredith Lamb (+14169386001)**

Next decade


**289.** `22:24` **You**

Mer I do t flirt I don’t t even look at other girls


**290.** `22:25` **You**

I mean I think most of you believes me but I cannot wait till all of you does


**291.** `22:27` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**292.** `22:27` **Meredith Lamb (+14169386001)**

>
I mean, ok\.

*💬 Reply*

**293.** `22:28` **You**

It’s true


**294.** `22:28` **You**

It was true before as well


**295.** `22:28` **Meredith Lamb (+14169386001)**

Okay


**296.** `22:32` **You**

Pshh  fine don’t believe me\.\. but I have never been more serious\.\.  and I am sorry you will worry for nothing\.  The only person I have worried about was Andrew… as irrational as that was\.


**297.** `22:33` **You**

Maybe you should follow your friends lead mer… younger man keeps you younger\.


**298.** `22:34` **Meredith Lamb (+14169386001)**

Huh?


**299.** `22:35` **Meredith Lamb (+14169386001)**

Carolyn and I were talking Monday and she and Eli are 1980 like Andrew


**300.** `22:35` **Meredith Lamb (+14169386001)**

She was like “oh you are the same as Scott\!”


**301.** `22:37` **You**

>
Your friends message the Madonna reference

*💬 Reply*

**302.** `22:37` **Meredith Lamb (+14169386001)**

Ohhhhhhh


**303.** `22:37` **Meredith Lamb (+14169386001)**

She’s a weirdo


**304.** `22:37` **Meredith Lamb (+14169386001)**

You will see when you meet her lol


**305.** `22:37` **Meredith Lamb (+14169386001)**

She’s always been a weirdo


**306.** `22:38` **You**

Omw home now ☹️ bah


**307.** `22:38` **Meredith Lamb (+14169386001)**

My nickname for her in third grade was “spazz matazz” and she HATED IT LOL


**308.** `22:39` **You**

That is a pretty 80’s nickname


**309.** `22:39` **Meredith Lamb (+14169386001)**

>
You are on your way home and Andrew is on his way to hockey\. lol

*💬 Reply*

**310.** `22:39` **You**

Well at least you can be happy about that lol


**311.** `22:41` **Meredith Lamb (+14169386001)**

I guess


**312.** `22:41` **Meredith Lamb (+14169386001)**

lol


**313.** `22:42` **Meredith Lamb (+14169386001)**

Honestly don’t care anymore


**314.** `22:43` **You**

I wouldn’t care at all were my situation a bit different


**315.** `22:48` **Meredith Lamb (+14169386001)**

Hrm?


**316.** `22:48` **Meredith Lamb (+14169386001)**

Why would you care about him going to hockey


**317.** `22:49` **You**

Gimme sec


**318.** `22:49` **Meredith Lamb (+14169386001)**

Aren’t you happier


**319.** `22:49` **Meredith Lamb (+14169386001)**

lol


**320.** `22:53` **You**

Where is your shadow


**321.** `22:54` **Meredith Lamb (+14169386001)**

Next room


**322.** `22:54` **Meredith Lamb (+14169386001)**

I’m in office on my laptop


**323.** `22:54` **You**

Ah ok nm lol


**324.** `22:54` **Meredith Lamb (+14169386001)**

Buying gifts for my mom


**325.** `22:54` **You**

Ninja is always lurking


**326.** `22:54` **Meredith Lamb (+14169386001)**

You can call


**327.** `22:54` **Meredith Lamb (+14169386001)**

It’s fine


**328.** `23:41` **You**

Here is a direct side\-by\-side comparison of Morgan Wallen and Kane Brown, focused on the key dimensions of their popularity, including sexual appeal, musical identity, public image, and cultural impact:
⸻
Morgan Wallen vs\. Kane Brown: Popularity Factors Comparison
Dimension	Morgan Wallen	Kane Brown
Sexual Appeal	Strong and overt; tied to his “bad boy” persona, rugged looks, and rebellious attitude\.	Present but softer; more tied to romantic vulnerability, tattoos, and devoted family man\.
Public Persona	Rebellious, raw, emotionally flawed; exudes a mix of charm and controversy\.	Wholesome, grounded, family\-oriented; perceived as humble and emotionally supportive\.
Musical Style	Traditional country with rock and Southern influences; rough\-edged vocals and themes\.	Country\-pop\-R&B hybrid; smoother vocals, crossover production, modern emotional themes\.
Emotional Themes	Heartbreak, drinking, defiance, masculinity, regret\.	Love, family, perseverance, racial identity, self\-worth\.
Fanbase Drivers	Fans are drawn to authenticity, drama, and the “wounded outlaw” image\.	Fans admire his relatability, emotional openness, and breaking barriers in country music\.
Controversies	Yes—high profile scandals have made him polarizing but also boosted visibility\.	Very few; image is carefully managed and mostly positive\.
Cultural Impact	Reinforces classic “Southern masculine” archetypes in country music\.	Disrupts country music norms as a biracial artist, expanding the genre’s inclusivity\.
Cross\-Genre Reach	Primarily country but with mainstream reach through collaborations and notoriety\.	Strong crossover appeal; frequent radio play on country, pop, and R&B charts\.
Masculinity Archetype	“The outlaw,” “the heartbreaker,” “the rebel with pain\.”	“The good man,” “the romantic,” “the role model husband/father\.”
Sexual Magnetism Type	Intense, unpredictable, brooding\.	Steady, sincere, emotionally safe\.
⸻
Summary of Similarities and Differences
- Similarities: Both are charismatic, emotionally expressive male country artists with a strong female fanbase\. They write about love, loss, and personal flaws, which humanizes them\.
- Differences: Wallen leans into a volatile, outlaw image that magnetizes attention and controversy; Brown projects calm strength and earnest vulnerability, appealing to broader and more diverse audiences\.
Would you like this in a visual format \(e\.g\., infographic or slide\-style summary\)?


**329.** `23:46` **You**

❤️❤️sleep well\.


**330.** `23:48` **Meredith Lamb (+14169386001)**

Love you xoxo


**331.** `23:50` **You**

Love you Morgan\. Wherever you are\!\! ❤️❤️❤️❤️❤️


**332.** `23:50` **You**

Reaction: ❤️ from Meredith Lamb
Love you mer, I don’t need a list\.\. you are it\.


**333.** `23:53` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
Nite\. Whether you are Morgan, Kane or Blake\. I’m cool\. All good\. lol kidding I like Scott to be Scott


**334.** `23:56` **You**

I can accept that\.


**335.** `23:57` **Meredith Lamb (+14169386001)**

Perf


**336.** `23:58` **You**

Go to bed and good luck
Tomorrow with ur mum\.\. let me know how it goes


