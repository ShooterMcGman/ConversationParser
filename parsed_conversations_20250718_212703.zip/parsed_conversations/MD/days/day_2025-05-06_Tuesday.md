# Daily Conversation: 2025-05-06 (Tuesday)

## 📅 Daily Metadata

| Field | Value |
|-------|-------|
| **Date** | 2025-05-06 |
| **Day** | Tuesday |
| **Week** | 4 |
| **Messages** | 630 |
| **Participants** | Meredith Lamb (+14169386001), You |
| **Time Range** | 2025-05-06T05:30 - 2025-05-06T23:33 |

## 📝 Daily Summary

This day contains **630 messages** exchanged between Meredith Lamb (+14169386001) and You. The conversation spans from morning to evening with various topics covered.

**Content Tags:** `morning`, `work`, `evening`, `planning`, `emotional`, `travel`, `food`

## 💬 Messages

**001.** `05:30` **You**

Just an fyi so you are not surprised j will be in my office for a meeting at 11 am\.


**002.** `05:42` **You**

Also curious\.\. how did you fall asleep at 8 and sleep right through this morning… I know you worry about me but are you ok, anything going on that you aren’t telling me about health or otherwise\.  Goes both ways mer just worried\. Heading to gym now\.


**003.** `06:39` **Meredith Lamb (+14169386001)**

I’m feeling very drained and overwhelmed\.  Extremely\. Also worried\. Just a whole bunch of crap…\.\. makes me tired\. Also I watched 5 episodes of four seasons and went to bed at 11\.30\. So there’s that too\. Xo


**004.** `06:41` **You**

Understandable\. Sorry\.\. I know I am not helping\.  I will be in\-whenever this morning\.\.  no point in going in early\. See you whenever that is\.


**005.** `06:46` **Meredith Lamb (+14169386001)**

I convinced Andrew to tell the kids tonight\.


**006.** `06:47` **Meredith Lamb (+14169386001)**

He was not happy about it and kept trying to delay last night\. I think he just never wants to talk them\. I convinced him last night\. Tonight is the night\.


**007.** `06:47` **Meredith Lamb (+14169386001)**

I have to lead the entire conversation


**008.** `06:47` **Meredith Lamb (+14169386001)**

I have therapy at 12 so am going to talk to her about it today


**009.** `06:47` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**010.** `06:47` **You**

Well that will at least that will get that milestone out of the way\.\. I will be thinking about you\.  J mused about keeping the house again today\.\. I told her mathematically it won’t work I hope she just fucks off about it\.


**011.** `06:48` **Meredith Lamb (+14169386001)**

Got that yday email yday from Maelle’s teacher


**012.** `06:48` **You**

Shit


**013.** `06:48` **Meredith Lamb (+14169386001)**

I told her teacher that I know Maelle knows but my stupid husband won’t let me tell her


**014.** `06:48` **Meredith Lamb (+14169386001)**

Sent Andrew that email and was like wtf we have to tell them


**015.** `06:48` **You**

Well maybe this will give closure to everyone to move forward


**016.** `06:48` **You**

Move


**017.** `06:49` **Meredith Lamb (+14169386001)**

>
She must feel attached to it… sad\.

*💬 Reply*

**018.** `06:50` **You**

No it is more to cater to Gracie


**019.** `06:50` **You**

I told her we engaged Mike in Moncton we are speaking to mortgage
And financial
Soecialists


**020.** `06:50` **You**

We cannot flip
Flop


**021.** `06:50` **You**

Anymore


**022.** `06:53` **You**

Reaction: ❤️ from Meredith Lamb
Just never ending fun\.  I mean just for the record\.\. and I will keep saying it every day if I have to\.\. I don’t mind\.  It makes me feel good to\.  I love you Meredith more than anything and no matter how shitty this gets I will be with you at the finish line if you will have me\.


**023.** `06:56` **You**

And yeah you know what I know it will be hard but when you can think on it I do want to see you in mornings sometimes\.\. nothing would make me happier than a few minutes alone with you to start the day\. Honestly


**024.** `06:56` **Meredith Lamb (+14169386001)**

Reaction: ❤️ from Scott Hicks
I already have you\. You already have me\. 🫠


**025.** `06:57` **Meredith Lamb (+14169386001)**

>
Okay I’m up for this\.

*💬 Reply*

**026.** `06:58` **You**

Kk will chat later just finishing up here


**027.** `07:25` **Meredith Lamb (+14169386001)**

Okie\. And listen, I know you don’t fully know how I deal with stress yet \(maybe not sure\) but my nervous system is completely shot right now\. With separation, finding a new place to live, worrying about financials, my kids, my mom’s health, all the secrecy and then work \(I haven’t led a team that long\) etc etc etc\. worried about you at times \(YESTERDAY\), our reporting relationship … etc etc …my insides are completely shot right now\. I’m like a burnt vape\. Time with you would definitely help but …\.\. I know\. But I am not well despite what outward appearances may show\. But this will pass and I know after telling girls tonight it will help a bit while also making it harder at the same time\.


**028.** `07:34` **Meredith Lamb (+14169386001)**

https://open\.spotify\.com/track/6Bm6qUCSatPAqkQllFL7oA?si=UxIfv4QES2eh4ApLXO4pwA


**029.** `07:41` **You**

>
Hey I appreciate you sharing and I know you are having a tough time I just want to be with you I try to keep my problems to myself as I know you do yours a lot of the time\.\. I don’t want to weigh on you you need to let me keep some things in okay sometimes because honestly you do have a shit ton and you cannot hold my hand all the time through my own stuff\.\. if the morning request is too much right now I will cope\.  We can chat later I will book a meeting maybe right before j comes in?? What do you think?   J/k do not attack\!\!\!

*💬 Reply*

**030.** `07:43` **You**

That is a great
Song\.\. look we can do whatever you want you want to leave 10 minutes apart and go drive over  accross the street behind that building and get a hug I will fucking do whatever to just give you a little bit of
Love to hold you through\.


**031.** `07:53` **Meredith Lamb (+14169386001)**

>
I don’t really get your joke at the end sorry
I gotta drive to work now\. Late again\. I just don’t want you to think I do something else to keep it all together and I’m somehow so different from you\. I am not\. Hence why all your stuff doesn’t really scare me\. May concern me but just bc I know the load… and what it feels like\.

*💬 Reply*

**032.** `07:56` **You**

Kk well talk at
Work about all the stuff I will find a few mins\. I am honestly up for anything big or small that you can deal with and that helps us both


**033.** `08:45` **Meredith Lamb (+14169386001)**

I just cannot……

*📎 1 attachment(s)*

**034.** `08:46` **You**

Still eh


**035.** `08:46` **Meredith Lamb (+14169386001)**

Talked to big brother Jim this morning about it\. Helped a little


**036.** `08:50` **Meredith Lamb (+14169386001)**

>
It’s not really that constant anymore but I could tell he wanted to say that last night\. The thing that zaps my nerves is that he doesn’t give a shit about me, it is just the image of the life of us together etc etc … he could care less if I was in that life suicidal as long as the image was there outwardly for everyone\.

*💬 Reply*

**037.** `08:52` **Meredith Lamb (+14169386001)**

I said to Jim this morning “at least Scott knows don’t makes work a bit more manageable right now” and he was all “oh if anyone can relate…\.”


**038.** `09:38` **You**

Yeah Jim is great that way I wish I could tell him but he would be onto us in 1/2
Second\.  Not sure he would care would probably be happy and help us keep
It a secret but man too risky\.\. would be nice to talk to him about the I bullshit though\.


**039.** `09:38` **You**

J was difficult again this morning fought in car in way in we sat in a meeting room for 30 mins still off\.


**040.** `09:39` **Meredith Lamb (+14169386001)**

30 minutes?


**041.** `09:39` **Meredith Lamb (+14169386001)**

Wow


**042.** `09:39` **You**

The joke earlier was that j is coming to my office for an 11 am meeting and I was going to book you for a meeting from 10 to 11


**043.** `09:40` **You**

And the\. I said just joking


**044.** `09:40` **You**

Emphatically


**045.** `09:40` **You**

Yeah more like an hour for drive and 30 mins here


**046.** `09:40` **You**

But she is not asking me to get back together


**047.** `09:40` **You**

And hasn’t for weeks


**048.** `09:44` **Meredith Lamb (+14169386001)**

Ohhhh\. Is she really going to your office at 11?


**049.** `09:44` **Meredith Lamb (+14169386001)**

😬


**050.** `09:44` **You**

Yes


**051.** `09:45` **You**

We have a meeting with a mortgage broker in Moncton


**052.** `09:45` **You**

I messaged you about this this morning inf


**053.** `09:45` **You**

Was an fyi


**054.** `09:46` **Meredith Lamb (+14169386001)**

Ohhhh didn’t fully get this\. I I thought the j was “I”

*📎 1 attachment(s)*

**055.** `09:47` **You**

Ah ok sry\.


**056.** `09:48` **You**



**057.** `09:55` **You**



**058.** `10:21` **Meredith Lamb (+14169386001)**

I think I have this today\. My sister had it when she went through her last divorce\.

*📎 1 attachment(s)*

**059.** `10:43` **Meredith Lamb (+14169386001)**

🤔

*📎 1 attachment(s)*

**060.** `10:47` **You**

This further supports my suggestion for afte and before work\.


**061.** `10:48` **You**

The deletions were because you missed an invite to my office and I figured to delete because you had t read until the time was
Past anyways\.


**062.** `10:48` **You**

>
I swear I can make this go away for a while\.

*💬 Reply*

**063.** `10:51` **You**

Running down to get some food


**064.** `10:51` **You**

J will be here in 10


**065.** `10:52` **Meredith Lamb (+14169386001)**

k I have a meeting at 11 phew lol


**066.** `12:09` **You**

It is safe


**067.** `12:41` **Meredith Lamb (+14169386001)**

lol


**068.** `12:41` **Meredith Lamb (+14169386001)**

How’d it go


**069.** `12:42` **You**

Come in and I will tell you much to detailed to text


**070.** `12:48` **You**

I have Yolanda popping in at 1 but it will be quick\.\.


**071.** `12:49` **You**

Maybe between when I finish and your 1:30


**072.** `13:03` **You**

Hope that went well


**073.** `14:02` **Meredith Lamb (+14169386001)**

Omg…

*📎 1 attachment(s)*

**074.** `14:03` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**075.** `14:04` **You**

Sry mer\.


**076.** `14:04` **You**

I know you need to get this done, I think discussion is over


**077.** `14:05` **You**

Leaver early and just go do it whether he wants to or not


**078.** `14:13` **You**

Ick


**079.** `14:13` **You**

I am guessing it continued


**080.** `16:45` **You**

You are going to have a rough night do not feel obligated to reach out\.  Good luck I love you\.


**081.** `16:46` **You**

And I hope your mum does ok tomorrow


**082.** `17:08` **Meredith Lamb (+14169386001)**

We will see if he even “allows” me to tell them\. He constantly says I’m being selfish and telling them for my benefit only\. 🙄


**083.** `17:09` **You**

Just do it get it over with


**084.** `17:09` **You**

Too heavy


**085.** `17:09` **Meredith Lamb (+14169386001)**

I know\. I will


**086.** `17:10` **You**

Well I am here for whatever you need but like I said don’t feel obligated tonight focus on you


**087.** `18:29` **Meredith Lamb (+14169386001)**

Most anti\-climatic situation ever\. They knew\. No tears\. All fine\.


**088.** `18:37` **You**

Are you ok


**089.** `18:37` **You**

Reaction: 👎 from Meredith Lamb
I just had another fight with Gracie super fun\.\.


**090.** `18:37` **You**

But glad it sounds like it went ok


**091.** `18:38` **Meredith Lamb (+14169386001)**

I feel great\. Had 2 glasses of wine during the convo and now taking dogs to park


**092.** `18:40` **You**

Enjoy happy for you


**093.** `18:45` **Meredith Lamb (+14169386001)**

I mean I’m sure it will get bad but they knew and seemed relieved to be told\. They are also happy with the plan so…\.


**094.** `18:53` **You**

Well that must be a HUGE relief for you


**095.** `19:00` **Meredith Lamb (+14169386001)**

At park with Marlowe and she said it was a relief but then she goes “I was just wondering who you were talking to that night” 🙄


**096.** `19:05` **You**

lol I thought that might come up


**097.** `19:05` **You**

How did you answer


**098.** `19:07` **Meredith Lamb (+14169386001)**

I was a little caught off guard tbh


**099.** `19:07` **Meredith Lamb (+14169386001)**

I said that has nothing to do with this


**100.** `19:07` **You**

At leaa as t it is Ther


**101.** `19:07` **You**

Try


**102.** `19:07` **You**

Aararegg


**103.** `19:08` **You**

True


**104.** `19:08` **You**

lol c and how did Andrew do


**105.** `19:08` **Meredith Lamb (+14169386001)**

What would you have said?


**106.** `19:09` **Meredith Lamb (+14169386001)**

It really tested me omg


**107.** `19:09` **Meredith Lamb (+14169386001)**

>
He didn’t say much

*💬 Reply*

**108.** `19:09` **You**

I would have likely said something similar


**109.** `19:09` **Meredith Lamb (+14169386001)**

He kind of teared up but didn’t full out cry bc none of them were even close to it


**110.** `19:09` **Meredith Lamb (+14169386001)**

He thought they’d be crying


**111.** `19:09` **You**

Well that was my next question


**112.** `19:09` **Meredith Lamb (+14169386001)**

He’s so stupid


**113.** `19:10` **You**

I also now know I can never cry around you


**114.** `19:10` **Meredith Lamb (+14169386001)**

They have known for a while


**115.** `19:10` **You**

Do you wonder why k worry about showing weakness lol really


**116.** `19:10` **Meredith Lamb (+14169386001)**

>
Not true\!\!\!

*💬 Reply*

**117.** `19:10` **You**

Rofl


**118.** `19:10` **You**

Or do you think it is fake vs real


**119.** `19:10` **Meredith Lamb (+14169386001)**

Haha am I that bad?


**120.** `19:11` **You**

I think you look at the world through your eyes\.\.


**121.** `19:11` **You**

Safe…\.\.


**122.** `19:11` **Meredith Lamb (+14169386001)**

?


**123.** `19:11` **You**

lol


**124.** `19:11` **You**

I rewrote five
Times


**125.** `19:11` **You**

It was a trap


**126.** `19:11` **You**

lol


**127.** `19:11` **You**

I do t mer


**128.** `19:11` **You**

I think you deal
With emotions differently is all


**129.** `19:12` **Meredith Lamb (+14169386001)**

>
?

*💬 Reply*

**130.** `19:12` **You**

I know you have them you looked so tormented today


**131.** `19:12` **You**

>
I was trying to say what I meant to say and shit can come accross wrong

*💬 Reply*

**132.** `19:12` **You**

It isn’t bad it is different


**133.** `19:13` **You**

I mean it is evident yku have extremely strong emotions\.


**134.** `19:14` **You**

This is one of those topics o would rather not discuss anymore ever again\.\. let’s just say I appreciate yku for who you are and after the last few days have a much better understanding of yku


**135.** `19:14` **You**

Thanks in part to some of what you shared this morning


**136.** `19:14` **You**

Please say something so I can stop typing\.


**137.** `19:15` **Meredith Lamb (+14169386001)**

LOL


**138.** `19:15` **You**

😢


**139.** `19:15` **Meredith Lamb (+14169386001)**

I talked to my therapist about this today


**140.** `19:15` **You**

About what


**141.** `19:15` **You**

Emotions


**142.** `19:16` **Meredith Lamb (+14169386001)**

One sec


**143.** `19:16` **You**

Yep


**144.** `19:18` **You**

For the record last one sec was 3 hours long\.  Just saying 🙂


**145.** `19:20` **Meredith Lamb (+14169386001)**

Sorry lol


**146.** `19:22` **Meredith Lamb (+14169386001)**

Yes, I talked to her about you thinking I have this special power just because I don’t outwardly show all of my emotions meanwhile my internal nervous system is going nuts…\. I have everyone in my life needing something from me… siblings, parents, Andrew, kids, dogs, work, etc and it is a lot\. That’s all


**147.** `19:23` **Meredith Lamb (+14169386001)**

I have 3 kids all needy in their own way\. It’s a lot\. And one isn’t even a teen yet\.


**148.** `19:23` **Meredith Lamb (+14169386001)**

\(Annoying\)


**149.** `19:24` **You**

>
Me

*💬 Reply*

**150.** `19:24` **You**

You left me out


**151.** `19:24` **Meredith Lamb (+14169386001)**

Because you were the center topic


**152.** `19:25` **Meredith Lamb (+14169386001)**

I want to be there 100% for you but it is a lot right now and I can’t the way I would prefer


**153.** `19:25` **Meredith Lamb (+14169386001)**

And that bothers me also


**154.** `19:26` **Meredith Lamb (+14169386001)**

And then things like Jaime coming to your office on our floor omg come on


**155.** `19:26` **Meredith Lamb (+14169386001)**

Lump in throat >


**156.** `19:26` **You**

In car I have more freedom now sorry


**157.** `19:26` **You**

Reading


**158.** `19:27` **You**

No come on fuck


**159.** `19:27` **You**

You can talk right


**160.** `19:27` **You**

I kinda want to reassure you there


**161.** `19:28` **You**

Can’t


**162.** `19:28` **Meredith Lamb (+14169386001)**

It isn’t about reassurance\. It is about shit I don’t want to see\.


**163.** `19:28` **Meredith Lamb (+14169386001)**

That’s all\.


**164.** `19:29` **You**

I can book a room next time


**165.** `19:29` **Meredith Lamb (+14169386001)**

Do you think she would have come to your office had she known about me and where I sat?


**166.** `19:29` **Meredith Lamb (+14169386001)**

Probably not\.


**167.** `19:29` **You**

No


**168.** `19:30` **Meredith Lamb (+14169386001)**

Exactly


**169.** `19:30` **You**

100%


**170.** `19:30` **You**

But why does that bother you


**171.** `19:30` **Meredith Lamb (+14169386001)**

Just shit no one wants to see


**172.** `19:30` **You**

Ok like I said


**173.** `19:30` **You**

I will go somewhere else


**174.** `19:30` **Meredith Lamb (+14169386001)**

I think it is just already being at a heightened level of over stress/over stimulation


**175.** `19:31` **Meredith Lamb (+14169386001)**

If life was “normal” it’d be different


**176.** `19:31` **You**

Maybe, you are right no one wants to see I wouldn’t either


**177.** `19:31` **You**

I am sorry that hurt you I did try to warn you


**178.** `19:31` **You**

But I will do we’re


**179.** `19:31` **You**

Better


**180.** `19:32` **Meredith Lamb (+14169386001)**

Just maybe do it if I’m not around\.


**181.** `19:32` **You**

I will just go away


**182.** `19:32` **You**

And not say anything


**183.** `19:33` **Meredith Lamb (+14169386001)**

The price of having a work girlfriend lol


**184.** `19:33` **Meredith Lamb (+14169386001)**

I won’t bring Andrew to work and have calls in front of you\.


**185.** `19:33` **Meredith Lamb (+14169386001)**

😝


**186.** `19:34` **You**

It’s fine bring him in you can introduce him to your boss


**187.** `19:34` **You**

🤯


**188.** `19:34` **You**

I think I get points there


**189.** `19:35` **Meredith Lamb (+14169386001)**

LOL


**190.** `19:36` **You**

Remember you are only the boss out of the office


**191.** `19:36` **Meredith Lamb (+14169386001)**

Hopefully


**192.** `19:37` **You**

Nope you are been established


**193.** `19:38` **Meredith Lamb (+14169386001)**

🤠


**194.** `19:38` **You**

Hmm busy at gym tonight\.\.  glad I am not going hard


**195.** `19:38` **Meredith Lamb (+14169386001)**

So was the Gracie stuff same old same old


**196.** `19:39` **You**

Yeah but


**197.** `19:39` **You**

I think I might have convinced Jaimie to put an offer in on a house in Moncton


**198.** `19:39` **You**

Tomorrow


**199.** `19:39` **You**

Potentially


**200.** `19:39` **Meredith Lamb (+14169386001)**

Wow, that is huge


**201.** `19:39` **You**

60 day closing likely


**202.** `19:39` **You**

But unsure


**203.** `19:39` **You**

Gracie being an ass


**204.** `19:40` **You**

Still will
Fight to the bitter end and causes j and I to fight


**205.** `19:40` **You**

She wants to stay here with me\.\. but there is no way it will work


**206.** `19:40` **You**

and j wants her to go there anyways


**207.** `19:40` **You**

She is just still
Living in a fantasy world


**208.** `19:41` **Meredith Lamb (+14169386001)**

Yikes, too bad\. Therapist doesn’t help?


**209.** `19:41` **You**

Nope I mean you would have to have all
Of the details\.\. but like I was completely broken last
Year
From
About Feb to July


**210.** `19:42` **You**

And I was
On stress
Leave\.


**211.** `19:42` **You**

The relationship is insanely toxic at this point and I am done getting broken and trying to lift her up at this age


**212.** `19:42` **You**

Not I


**213.** `19:43` **You**

J


**214.** `19:43` **You**

Like Gracie kind of created
A
Rift in the family


**215.** `19:43` **You**

J and I tried different ways but nothing worked


**216.** `19:44` **You**

So now it is reality time I said if she lived
With me she is working full
Time
Paying for her stuff accomplishing the goals we
Layout and the year after she can go to university


**217.** `19:44` **You**

She won’t do it


**218.** `19:44` **You**

She says I need to help her


**219.** `19:44` **You**

And I know what that means


**220.** `19:44` **Meredith Lamb (+14169386001)**

😬


**221.** `19:45` **You**

Yeah it is a mess and I feel bad but the same
Kind of
Poking I do to you about emotions they do to me


**222.** `19:45` **You**

And j won’t let me defend myself … so Gracie feels
Validated


**223.** `19:45` **You**

Super
Fun


**224.** `19:45` **Meredith Lamb (+14169386001)**

Yikes, they say you have no emotions?


**225.** `19:45` **You**

Yes


**226.** `19:45` **You**

None


**227.** `19:45` **Meredith Lamb (+14169386001)**

I have emotions\! Lol


**228.** `19:45` **You**

I told them this is just who I am here


**229.** `19:46` **You**

I know you do


**230.** `19:46` **You**

lol


**231.** `19:46` **Meredith Lamb (+14169386001)**

Maybe I’m just a terminator and no one knows it


**232.** `19:46` **You**

I am going to make you cry happy tears
Someday…


**233.** `19:46` **Meredith Lamb (+14169386001)**

They need to cut off my skin


**234.** `19:46` **You**

Wait for it


**235.** `19:46` **Meredith Lamb (+14169386001)**

Sure lol


**236.** `19:46` **You**

I will


**237.** `19:47` **Meredith Lamb (+14169386001)**

Uh huh…


**238.** `19:47` **You**

You will never ever see it coming


**239.** `19:47` **You**

And then… it will just happen


**240.** `19:47` **Meredith Lamb (+14169386001)**

Okay


**241.** `19:47` **Meredith Lamb (+14169386001)**

I have never cried happy tears


**242.** `19:47` **You**

Oh man soooooo much challenge
Accepted


**243.** `19:47` **Meredith Lamb (+14169386001)**

Like I don’t even understand that


**244.** `19:47` **You**

Again you will


**245.** `19:47` **Meredith Lamb (+14169386001)**

I could never do something I don’t understand


**246.** `19:48` **You**

I didn’t understand this


**247.** `19:48` **You**

But I am doing it


**248.** `19:48` **You**

Now you say touché


**249.** `19:48` **Meredith Lamb (+14169386001)**

I don’t think that’s true really


**250.** `19:48` **You**

Omg………\.😳


**251.** `19:48` **Meredith Lamb (+14169386001)**

I mean


**252.** `19:48` **Meredith Lamb (+14169386001)**

You have seen romantic movies and stuff


**253.** `19:49` **Meredith Lamb (+14169386001)**

You have some level of understanding


**254.** `19:49` **You**

Noooooo…… lol


**255.** `19:49` **You**

How can you watch a movie and understand the intensity of a feeling


**256.** `19:49` **Meredith Lamb (+14169386001)**

You are 46


**257.** `19:49` **You**

You complete me
Doesn’t do this justice


**258.** `19:49` **Meredith Lamb (+14169386001)**

lol


**259.** `19:50` **You**

Or just a guy standing in front of a girl


**260.** `19:50` **You**

Like wel


**261.** `19:50` **You**

Maybe that one


**262.** `19:50` **You**

A little


**263.** `19:50` **Meredith Lamb (+14169386001)**

See, you have some level of understanding


**264.** `19:50` **You**

Still not the same


**265.** `19:50` **You**

Not even close


**266.** `19:50` **You**

You won’t convince me\.\.
This hit
Me like nothing ever has
I had absolutely no control


**267.** `19:50` **You**

Still don’t have much


**268.** `19:51` **You**

My emotions are ruling me all
Over the place


**269.** `19:51` **You**

That is why I am having a hard time


**270.** `19:51` **Meredith Lamb (+14169386001)**

I know… I’m with you\.


**271.** `19:51` **You**

So I can honestly say no I have never experienced
Anything like this ever\.\.


**272.** `19:51` **You**

And the books and movies and Disney


**273.** `19:52` **You**

Don’t do it justice


**274.** `19:52` **You**

Which makes
Me
A little happy tbh


**275.** `19:52` **Meredith Lamb (+14169386001)**

What about true romance though?


**276.** `19:52` **You**

The movie


**277.** `19:52` **Meredith Lamb (+14169386001)**

That movie kind of does it justice lol


**278.** `19:52` **You**

Or the idea


**279.** `19:52` **Meredith Lamb (+14169386001)**

lol


**280.** `19:52` **You**

Mmmmmm no


**281.** `19:52` **Meredith Lamb (+14169386001)**

Haha


**282.** `19:53` **You**

Serendipity is kind of romantic


**283.** `19:53` **Meredith Lamb (+14169386001)**

I guess\.


**284.** `19:53` **You**

Been a long time since I watched that


**285.** `19:53` **Meredith Lamb (+14169386001)**

Same


**286.** `19:53` **You**

Ever after\.\.


**287.** `19:53` **Meredith Lamb (+14169386001)**

LOL


**288.** `19:53` **Meredith Lamb (+14169386001)**

Tell me you are a girl dad with out telling me you are a girl dad


**289.** `19:54` **Meredith Lamb (+14169386001)**

Ever after


**290.** `19:54` **You**

I watched that long before I had girls


**291.** `19:54` **Meredith Lamb (+14169386001)**

Really wow


**292.** `19:54` **You**

It is a good movie


**293.** `19:54` **Meredith Lamb (+14169386001)**

Is it?


**294.** `19:54` **You**

I think so


**295.** `19:54` **Meredith Lamb (+14169386001)**

Before sunrise


**296.** `19:55` **You**

Saw that once and I was
Drunk as
Shit


**297.** `19:55` **You**

So fairly certain I didn’t appreciate it


**298.** `19:55` **Meredith Lamb (+14169386001)**

lol


**299.** `19:58` **You**

Well it is gym time again


**300.** `19:58` **You**

And getting g man compliments\.\. makes me feel
Soo good\!\!


**301.** `20:00` **Meredith Lamb (+14169386001)**

G man?


**302.** `20:00` **You**

No g man\.\. just man compliments


**303.** `20:00` **Meredith Lamb (+14169386001)**

Oh lol


**304.** `20:01` **You**

Hey you take what you can get
Alright no judging lol


**305.** `20:01` **Meredith Lamb (+14169386001)**

No judgement


**306.** `20:04` **You**

Ok I feel like it is about time for you to get off you probably want to watch your shows\.\. starting to get a bit distracted\.\. all good go enjoy your night\.


**307.** `20:05` **You**

In case
You are wondering how I notice I scroll back and look at the number of words in your responses\.  lol\. Sure fire way to tell\.


**308.** `20:06` **Meredith Lamb (+14169386001)**

lol I’m watching four seasons and my SIL keeps texting\. She won’t stop


**309.** `20:07` **You**

I feel like I need to make some friends what do ya think\.


**310.** `20:08` **You**

I think that would be healthy


**311.** `20:08` **Meredith Lamb (+14169386001)**

Um, Hmmh no you’re good


**312.** `20:08` **You**

No I really am not


**313.** `20:08` **You**

Being serious


**314.** `20:08` **Meredith Lamb (+14169386001)**

k fine


**315.** `20:08` **You**

If you looked T my phone


**316.** `20:08` **You**

I talk to you…


**317.** `20:08` **You**

And no one


**318.** `20:09` **You**

So yeah


**319.** `20:09` **You**

I think I need to somehow\.\. if I had friends this wouldn’t be all on you


**320.** `20:09` **Meredith Lamb (+14169386001)**

I mean that is normal for males no?


**321.** `20:09` **You**

To not have any friends


**322.** `20:09` **You**

At L
All


**323.** `20:09` **You**

lol


**324.** `20:09` **Meredith Lamb (+14169386001)**

Or to not talk about stuff like this


**325.** `20:09` **You**

It isn’t to talk


**326.** `20:10` **You**

It is to go do things


**327.** `20:10` **You**

Keep my mind occupied


**328.** `20:10` **You**

I could many find better balance


**329.** `20:10` **You**

Been thinking\. Out how to get through all of the time we have to get through


**330.** `20:11` **You**

Besides you have all kinds of friends to do stuff with\.\.


**331.** `20:11` **Meredith Lamb (+14169386001)**

Yeah it is going to be long but then we do stuff together


**332.** `20:11` **Meredith Lamb (+14169386001)**

I don’t do stuff with friends


**333.** `20:11` **Meredith Lamb (+14169386001)**

I have too many kids


**334.** `20:11` **Meredith Lamb (+14169386001)**

:p


**335.** `20:11` **You**

Well then I need to get more kids??


**336.** `20:11` **You**

lol


**337.** `20:12` **Meredith Lamb (+14169386001)**

No


**338.** `20:12` **You**

That doesn’t track


**339.** `20:12` **Meredith Lamb (+14169386001)**

Big no


**340.** `20:12` **You**

Adopte


**341.** `20:12` **Meredith Lamb (+14169386001)**

No


**342.** `20:12` **You**

Someone out there needs me I am sure


**343.** `20:12` **Meredith Lamb (+14169386001)**

Yeah


**344.** `20:12` **Meredith Lamb (+14169386001)**

Me


**345.** `20:12` **Meredith Lamb (+14169386001)**

Duh


**346.** `20:13` **You**

W/e but you have to admit my life is pretty empty\.\. I am just looking to stay healthy


**347.** `20:13` **Meredith Lamb (+14169386001)**

Your life is not empty, it is just the way you are choosing to view it\.


**348.** `20:13` **You**

I wasn’t thinking ‘girl’ friends


**349.** `20:13` **You**

They would\. E men


**350.** `20:13` **You**

What


**351.** `20:13` **You**

Omg


**352.** `20:13` **You**

>
This is not a zen thing

*💬 Reply*

**353.** `20:13` **Meredith Lamb (+14169386001)**

Seriously


**354.** `20:14` **You**

I think I am full therefore I am


**355.** `20:14` **Meredith Lamb (+14169386001)**

You have ppl in your life


**356.** `20:14` **Meredith Lamb (+14169386001)**

You have ME


**357.** `20:14` **Meredith Lamb (+14169386001)**

you have daughters


**358.** `20:14` **Meredith Lamb (+14169386001)**

Sister


**359.** `20:14` **You**

Ok but read your earlier text


**360.** `20:14` **Meredith Lamb (+14169386001)**

Friends


**361.** `20:14` **You**

No


**362.** `20:14` **You**

Do not


**363.** `20:14` **Meredith Lamb (+14169386001)**

Even tho you say you don’t


**364.** `20:14` **You**

Sister only talks to
Me when I call her


**365.** `20:14` **Meredith Lamb (+14169386001)**

>
?

*💬 Reply*

**366.** `20:14` **You**

Kids are messed


**367.** `20:15` **You**

I have you yes in heart and mind 😃


**368.** `20:16` **You**

Again what I am shooting for is to make our lives easier so every time I see you I do t feel like I need to unload every emotion on your because I am better able to manage


**369.** `20:16` **You**

I cannot do
That with just gym and an empty basement


**370.** `20:16` **Meredith Lamb (+14169386001)**

Things are going to unfold naturally in time\.


**371.** `20:16` **You**

You have e said that before


**372.** `20:16` **Meredith Lamb (+14169386001)**

I get my own place\. You guys figure out your situation\. Etc etc


**373.** `20:17` **Meredith Lamb (+14169386001)**

It will happen


**374.** `20:17` **Meredith Lamb (+14169386001)**

Then eventually maybe we can tell ppl


**375.** `20:17` **You**

Ok but I am not trying to replace you\.\.


**376.** `20:17` **You**

I mean let me be honey


**377.** `20:17` **You**

Honest


**378.** `20:17` **You**

You easily could satisfy every need I have period


**379.** `20:18` **You**

Lover friend confident partner in


**380.** `20:18` **You**

Everything


**381.** `20:18` **You**

It it is a long way off and I M admittedly having a really hard time and I M just trying to find a bridge


**382.** `20:18` **You**

I do see you that way


**383.** `20:18` **You**

And I have never felt that way about anyone


**384.** `20:18` **You**

The you complete me is cheesy but accurate


**385.** `20:19` **You**

But there is right now


**386.** `20:19` **You**

And zero is too hard for me


**387.** `20:19` **Meredith Lamb (+14169386001)**

How do you just keep typing\. My breath stops a little and you don’t even pause


**388.** `20:19` **You**

Too much energy


**389.** `20:19` **You**

Emotions


**390.** `20:19` **You**

Like I said


**391.** `20:19` **You**

I do t want to put all
Of it I\. You this way


**392.** `20:20` **You**

Right now


**393.** `20:20` **You**

Reaction: 😂 from Meredith Lamb
Later sure


**394.** `20:20` **You**

It it is too hard and I M not trying to be hurtful I know we are doing the best we can


**395.** `20:20` **You**

But even today I had to really focus


**396.** `20:20` **You**

On not letting shit overwhelm
Me


**397.** `20:20` **Meredith Lamb (+14169386001)**

Yeah I know… I can’t handle it all right now\. I wish I could


**398.** `20:21` **You**

Partly why I want to him


**399.** `20:21` **You**

Jim


**400.** `20:21` **You**

Anyways all
I am saying is that I might need to find some support through some friends
Maybe dudes
From gym maybe join a basketball league or something


**401.** `20:21` **You**

Very lonely\.\. 😞 so just trying  it to carry that all the time


**402.** `20:22` **Meredith Lamb (+14169386001)**

You can tell Jim


**403.** `20:22` **Meredith Lamb (+14169386001)**

You can join a league


**404.** `20:22` **You**

I still do t want to risk it


**405.** `20:22` **You**

And I won’t tell him till we do the hand holding thing


**406.** `20:22` **You**

Epic


**407.** `20:23` **Meredith Lamb (+14169386001)**


*📎 1 attachment(s)*

**408.** `20:23` **Meredith Lamb (+14169386001)**

Jim’s a bad influence\. Be careful


**409.** `20:23` **You**

Ok now text him hey Jim btw I am in love with my boss and he is madly in love with me


**410.** `20:23` **You**

Then send me that text response


**411.** `20:23` **Meredith Lamb (+14169386001)**

Yeah WHATEVER


**412.** `20:24` **You**

No no I am curious lol


**413.** `20:24` **Meredith Lamb (+14169386001)**

Sure you are


**414.** `20:24` **Meredith Lamb (+14169386001)**

You would freak out if I told him


**415.** `20:24` **You**

Nope


**416.** `20:24` **Meredith Lamb (+14169386001)**

Sure


**417.** `20:24` **You**

Nope


**418.** `20:24` **You**

Bet


**419.** `20:24` **Meredith Lamb (+14169386001)**

Would regret it later


**420.** `20:25` **You**

I would


**421.** `20:25` **You**

Or you would


**422.** `20:25` **Meredith Lamb (+14169386001)**

You


**423.** `20:25` **You**

Why


**424.** `20:25` **Meredith Lamb (+14169386001)**

I dunno you’re a Manager


**425.** `20:25` **Meredith Lamb (+14169386001)**

Jim and I are lowly


**426.** `20:25` **You**

Ok how about this


**427.** `20:25` **Meredith Lamb (+14169386001)**

lol


**428.** `20:25` **You**

How about this


**429.** `20:25` **You**

Yku take him to that small
Corner meeting room


**430.** `20:26` **You**

Or Bette go to a different floor


**431.** `20:26` **You**

Then broach the topic sooooooo


**432.** `20:26` **You**

Here is something interesting


**433.** `20:26` **You**

Test the waters


**434.** `20:26` **You**

See how he reacts but do t say it is me


**435.** `20:26` **Meredith Lamb (+14169386001)**

Do you even understand how hard it was for me to tell him about separating?


**436.** `20:26` **Meredith Lamb (+14169386001)**

Oh just tell him I’m seeing someone


**437.** `20:26` **You**

Yeah you are right yku couldn’t pull that off


**438.** `20:27` **Meredith Lamb (+14169386001)**

I could NOT


**439.** `20:27` **You**

Maybe I will do it


**440.** `20:27` **You**

Thursday


**441.** `20:27` **Meredith Lamb (+14169386001)**

He’s like my big brother\. I had a hard time telling him also for some reason


**442.** `20:27` **You**

I will start with the separation


**443.** `20:28` **You**

It will lead into discussing you


**444.** `20:28` **Meredith Lamb (+14169386001)**

I trust that Jim would not say anything to anyone but it is a slippery slope\.


**445.** `20:28` **You**

Yeah I know just a happy idea


**446.** `20:28` **You**

You are right of
Course


**447.** `20:28` **Meredith Lamb (+14169386001)**

He’s probably the only person I would actually trust fully


**448.** `20:28` **You**

Same


**449.** `20:28` **Meredith Lamb (+14169386001)**

At work


**450.** `20:29` **Meredith Lamb (+14169386001)**

I’ve known him since 2008 … he wouldn’t do anything


**451.** `20:30` **You**

Well like I said I can always start with my situation


**452.** `20:30` **You**

Least u could talk to someone else
About that


**453.** `20:30` **You**

O one to talk to about us


**454.** `20:30` **You**

Therapist


**455.** `20:30` **You**

Need one


**456.** `20:31` **Meredith Lamb (+14169386001)**

Yeah I do have other ppl who check in too…


**457.** `20:31` **Meredith Lamb (+14169386001)**

But men don’t do that


**458.** `20:31` **Meredith Lamb (+14169386001)**

Do they?


**459.** `20:31` **You**

See I do t have that that is what I kinda meant about friends


**460.** `20:31` **You**

Reaction: 😂 from Meredith Lamb
Man you have a very specific view about men


**461.** `20:31` **You**

Reaction: 😂 from Meredith Lamb
You like big men who are emotionally stunted


**462.** `20:31` **You**

lol


**463.** `20:31` **You**

And use big words


**464.** `20:31` **You**

And wear
Glasss


**465.** `20:32` **You**

You have a type


**466.** `20:32` **Meredith Lamb (+14169386001)**

Whatever


**467.** `20:32` **You**

Reaction: ❤️ from Meredith Lamb
Hair optional apparently


**468.** `20:32` **You**

Yeah but you didn’t dispute it


**469.** `20:32` **Meredith Lamb (+14169386001)**

Whatever = dispute


**470.** `20:33` **You**

O


**471.** `20:33` **You**

No it means you don’t have an answer


**472.** `20:33` **Meredith Lamb (+14169386001)**

I don’t prefer big men who are emotionally stunted\.


**473.** `20:33` **Meredith Lamb (+14169386001)**

Can you stop


**474.** `20:34` **You**

Interesting… mmmmm hmmm


**475.** `20:34` **Meredith Lamb (+14169386001)**

Is that what you think of yourself?


**476.** `20:34` **You**

No but I am not perfect…\.\.
Yet


**477.** `20:35` **Meredith Lamb (+14169386001)**

Sure you are


**478.** `20:35` **You**

You know what whatever… I feel the same about you so meh\.\.


**479.** `20:36` **You**

I don’t have a leg to
Stand on


**480.** `20:36` **You**

You are perfect for me if you cannot read between the lines\.


**481.** `20:36` **You**

There isn’t a point analyzing it


**482.** `20:37` **Meredith Lamb (+14169386001)**

I think you need to accept it goes both ways


**483.** `20:37` **You**

Yeah well i am not
Sure I will ever fully


**484.** `20:37` **You**

Being honest


**485.** `20:39` **Meredith Lamb (+14169386001)**

Ever fully accept that I think you are perfect for me?


**486.** `20:40` **You**

Certain aspects of me maybe \.\. I dunno we’ll see


**487.** `20:40` **You**

Not a huge deal


**488.** `20:40` **Meredith Lamb (+14169386001)**

Or a massive deal like


**489.** `20:40` **You**

No


**490.** `20:41` **Meredith Lamb (+14169386001)**

We are both in stressful situations so this isn’t “normal” life currently


**491.** `20:41` **Meredith Lamb (+14169386001)**

Both acting a little odd


**492.** `20:41` **You**

Hmm


**493.** `20:42` **You**

I am afraid I am not
Much different than this with the exception of emotional control


**494.** `20:43` **Meredith Lamb (+14169386001)**

That is kind of a big factor


**495.** `20:44` **You**

Trying to figure out how I drug us
Here\.\. we can call it I love you and always will and think you are perfect for me in every way and you can feel likewise\.\.


**496.** `20:45` **You**

And I will use absolutes whenever
I mean them


**497.** `20:45` **Meredith Lamb (+14169386001)**

Okay 🙂


**498.** `20:45` **You**

All that said I will need to find\. Way tk
Get from here to there
So
I will think on it


**499.** `20:46` **Meredith Lamb (+14169386001)**

You could work in new sector plans?


**500.** `20:46` **Meredith Lamb (+14169386001)**

\*on


**501.** `20:46` **Meredith Lamb (+14169386001)**

lol


**502.** `20:46` **You**

May I ask
You a question


**503.** `20:46` **Meredith Lamb (+14169386001)**

Sure


**504.** `20:47` **You**

Why does it seem to bother
You, I am kind of
Surprised I thought you would be all
For me
Branching out to make friends


**505.** `20:47` **You**

Like I will do whatever you want


**506.** `20:47` **You**

Tbh


**507.** `20:47` **Meredith Lamb (+14169386001)**

I mean it doesn’t bother me at all


**508.** `20:47` **Meredith Lamb (+14169386001)**

Only if I don’t like them


**509.** `20:47` **Meredith Lamb (+14169386001)**

I don’t like Andrew’s friends


**510.** `20:48` **Meredith Lamb (+14169386001)**

lol


**511.** `20:48` **You**

I usually try to find people like me


**512.** `20:48` **You**

But I don’t have to\.\. I will just go back to ai\.


**513.** `20:48` **Meredith Lamb (+14169386001)**

I have no issue with friends as long as they are assholes that I have too many hang around with


**514.** `20:48` **You**

That will fill time at least


**515.** `20:48` **Meredith Lamb (+14169386001)**

\*arent


**516.** `20:49` **You**

I will find something else


**517.** `20:49` **You**

All good\.\. maybe if j leaves it will be better
But that is like 2 months ffs


**518.** `20:49` **You**

Earliest


**519.** `20:49` **Meredith Lamb (+14169386001)**

Like if your friend is like Jim, we are fine


**520.** `20:49` **You**

I should have moved
Our first


**521.** `20:50` **You**

It would have been worse
Overall but I would be happier


**522.** `20:50` **Meredith Lamb (+14169386001)**

I’m going to try for July 1 maybe


**523.** `20:50` **You**

Yeah you are a ways off too\.\. being k\. The abstinence\!\!\!\!


**524.** `20:50` **You**

Whoooi


**525.** `20:50` **You**

lol


**526.** `20:51` **Meredith Lamb (+14169386001)**

Reaction: 👍 from Scott Hicks
I’m not sure i could do before\. Mac’s 16th plus 2 graduations in June


**527.** `20:51` **Meredith Lamb (+14169386001)**

Mediator said 3 wks also


**528.** `20:51` **Meredith Lamb (+14169386001)**

So we will see


**529.** `20:52` **Meredith Lamb (+14169386001)**

At least now I can send the girls rentals to look at


**530.** `20:52` **You**

Still my point remains valid lol… mentally tough time


**531.** `20:52` **Meredith Lamb (+14169386001)**

Couldn’t before


**532.** `20:52` **You**

Silver lining


**533.** `20:52` **Meredith Lamb (+14169386001)**

>
Then we plan a work trip

*💬 Reply*

**534.** `20:52` **Meredith Lamb (+14169386001)**

🤔


**535.** `20:52` **You**

For august


**536.** `20:52` **Meredith Lamb (+14169386001)**

For June


**537.** `20:52` **Meredith Lamb (+14169386001)**

August?


**538.** `20:53` **Meredith Lamb (+14169386001)**

Wha


**539.** `20:53` **You**

I have to go to Chatham k\. 17


**540.** `20:53` **You**

Of may


**541.** `20:53` **You**

August was an exaggeration\. I am not optimistic


**542.** `20:53` **Meredith Lamb (+14169386001)**

I have zero reason to be in Chatham


**543.** `20:53` **You**

I low


**544.** `20:53` **Meredith Lamb (+14169386001)**

I also meant a fake work trip


**545.** `20:53` **You**

I wasn’t suggesting


**546.** `20:54` **Meredith Lamb (+14169386001)**

But your team will catch on


**547.** `20:54` **You**

It’s fine\.\.


**548.** `20:54` **You**

Will be fine


**549.** `20:54` **You**

I will just keep
Telling myself that


**550.** `20:54` **You**

My be mantra


**551.** `20:55` **Meredith Lamb (+14169386001)**

Sigh


**552.** `20:56` **You**

Mer I am a realist\.\. through and through… and I believe in us that way which is how I can reconcile it\.\. it isn’t an optimistic fantasy I believe it is real and eventually will happen\.  But all the rest…
Realist\.\. low
Expectations easier to survive


**553.** `20:57` **You**

I learened from
The weekend


**554.** `20:57` **Meredith Lamb (+14169386001)**

Which weekend? Last?


**555.** `20:57` **You**

Yeah


**556.** `20:58` **You**

Flew a bit to close
To the sun and all
Got super excited and a bit optimistic\.\. but problem
Was I
Literally forgot about everything else
There was just you\.\.


**557.** `20:58` **You**

Then it was time for a polar dip into realitt


**558.** `20:59` **You**

\.\. not sure how
Else
To explain


**559.** `20:59` **Meredith Lamb (+14169386001)**

Quite an explanation… how do you come up with this stuff lol


**560.** `20:59` **You**

I am smart and I read
Greek mythology


**561.** `21:00` **You**

And I know how to use analogies


**562.** `21:00` **Meredith Lamb (+14169386001)**

Thank goodness


**563.** `21:00` **You**

lol


**564.** `21:00` **Meredith Lamb (+14169386001)**

Apparently


**565.** `21:00` **You**

But it is true


**566.** `21:00` **Meredith Lamb (+14169386001)**

I know\. I feel like I let you down this weekend and then this week


**567.** `21:01` **Meredith Lamb (+14169386001)**

Told my therapist


**568.** `21:01` **You**

What are you talking about


**569.** `21:01` **Meredith Lamb (+14169386001)**

So you just need to be patient with me


**570.** `21:01` **You**

My problems are my own


**571.** `21:01` **You**

You can’t carry them I won’t let you


**572.** `21:01` **You**

I told you lot bugging
You anymore


**573.** `21:01` **You**

Too much pressure


**574.** `21:01` **Meredith Lamb (+14169386001)**

Well you wanted to get together for just like a quick whatever on weekend but I didn’t


**575.** `21:01` **Meredith Lamb (+14169386001)**

Then this week


**576.** `21:02` **Meredith Lamb (+14169386001)**

Gahhh


**577.** `21:02` **You**

It’s fine like I said reality


**578.** `21:02` **You**

Not pushing anymore wil deal yku are right too much weight


**579.** `21:02` **You**

Like you were begging for space
Mer… I have to give it to you and you cannot
Feel
Guilty


**580.** `21:03` **Meredith Lamb (+14169386001)**

What? I was not begging for space


**581.** `21:03` **You**

Last\. Ight


**582.** `21:03` **Meredith Lamb (+14169386001)**

I just have a lot going on atm


**583.** `21:03` **You**

I know you do


**584.** `21:03` **Meredith Lamb (+14169386001)**

Last night I was begging for space?


**585.** `21:04` **You**

Before you fell asleep yeah


**586.** `21:05` **Meredith Lamb (+14169386001)**

So took me forever to scroll up


**587.** `21:05` **Meredith Lamb (+14169386001)**

lol


**588.** `21:05` **Meredith Lamb (+14169386001)**

I was just tired


**589.** `21:05` **Meredith Lamb (+14169386001)**

Edited: 2 versions
| Version: 2
| Sent: Tue, 6 May 2025 21:06:57 \-0400
|
| I’m also GENERALLY not as wordy/chatty as you in ever single msg so…\.\. I think I would have arthritic thumbs if I was
|
| Version: 1
| Sent: Tue, 6 May 2025 21:05:49 \-0400
|
| Not begging for space


**590.** `21:07` **You**

Right so when you are wordy and articulate I pay attention\.\.


**591.** `21:08` **Meredith Lamb (+14169386001)**

But I wasn’t begging for space


**592.** `21:08` **Meredith Lamb (+14169386001)**

Just tired


**593.** `21:08` **Meredith Lamb (+14169386001)**

Drained


**594.** `21:08` **You**

It’s fine I told you I am going to chill that was my idea
With
Friends so I would bug you as
Much


**595.** `21:08` **You**

Only reason


**596.** `21:08` **You**

Wouldnt


**597.** `21:08` **Meredith Lamb (+14169386001)**

Why did you not have this friend thing before me?


**598.** `21:09` **You**

The only reason I pushed for after
Work today was that I was
Worried you were
Going into a shitstorm and wanted to hug you and tell you how much I love you in person it wasn’t even really for
Me\.\.


**599.** `21:09` **You**

I am a loner
And I didn’t need them


**600.** `21:09` **You**

I also didn’t feel lonely


**601.** `21:09` **You**

Ever


**602.** `21:09` **You**

Or really have needy deelings


**603.** `21:09` **You**

Feeinga


**604.** `21:09` **Meredith Lamb (+14169386001)**

>
It was very sweet

*💬 Reply*

**605.** `21:10` **You**

Anyhow I just wanted to explain I want going back
I\. What I said


**606.** `21:11` **You**

Well that was an hour of walking and 522 calories\.\. noice


**607.** `21:11` **You**

Anyways stop worrying about this mer


**608.** `21:11` **Meredith Lamb (+14169386001)**

>
Reptype this

*💬 Reply*

**609.** `21:12` **Meredith Lamb (+14169386001)**

Retype


**610.** `21:12` **You**

Nothing you can do now anyways


**611.** `21:12` **You**

What?


**612.** `21:12` **Meredith Lamb (+14169386001)**

That doesn’t make sense


**613.** `21:12` **You**

I wanted to explain that my asking you to rendezvous boys tonight was not meant to be me going back on my promise not to chill and stop bugging you to see me\.


**614.** `21:13` **Meredith Lamb (+14169386001)**

Ohhhhh got it


**615.** `21:13` **Meredith Lamb (+14169386001)**

Yeah I got that it and felt it


**616.** `21:13` **Meredith Lamb (+14169386001)**

And I’m not “worrying” per se\.


**617.** `21:14` **You**

It the point \- I just wanted to make sure you understood


**618.** `21:14` **You**

I am sticking bu what I said


**619.** `21:14` **You**

Not the point


**620.** `21:16` **Meredith Lamb (+14169386001)**

But… this is heavy and sometimes we have to make it lighter


**621.** `21:16` **You**

wtf


**622.** `21:16` **You**

Pocket dial
Apologies


**623.** `21:17` **Meredith Lamb (+14169386001)**

I wasn’t going to answer\. Marlowe in next room lol


**624.** `21:17` **You**

Yeah sorry didnt mean to\.


**625.** `21:18` **You**

Ok go watch your shows I am going into sauna then shower then home\.


**626.** `21:20` **Meredith Lamb (+14169386001)**

k i love you and glad we talked tonight xoxo


**627.** `21:21` **You**

Love you too night\.


**628.** `22:19` **You**

Just getting ready to settle in,
I mentioned it earlier but I will
E thinking about your mum tomorrow I hope all goes well\.


**629.** `23:04` **You**

I also had an idea for that work trip yku mentioned I mean lots kf people end up taking fridays off\.\. maybe ona\. Long weekend maybe something else\.\. I can make up a story to get up to Chatham for a day for my family and stay for the weekend as part of my getaway hang out with Tom and haris and have dinner with Sarah etc\.\. but really I would like to spend it with you just having yku tour me around and show me stuff\.  Anyhow unsure if it works but it is something I have wanted to do with you\.  At some point in time\.\. just an idea to think about for somewhere down the road if it fits\.  Can’t help having ideas always thinking\.


**630.** `23:33` **Meredith Lamb (+14169386001)**

You need a spreadsheet to track all of these ideas\. ❤️ We’ll see if we could make something like that work\. Nite\. Xox


