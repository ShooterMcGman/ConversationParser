# Week 5: Conversation Messages

**Date Range:** 2025-05-11 to 2025-05-17  
**Total Messages:** 1453  
**Generated:** 2025-07-18 21:27:05

---

## 📊 Week Summary

- **Week Number:** 5
- **Messages:** 1453
- **Participants:** 2
- **Message Types:** outgoing, incoming, call-history

## 💬 Conversation Messages

### 1. msg_10194

**You** - 2025-05-11T00:36:48

On off sleeping pretty quiet\.  Glad your night went well\.  Love you too xo


---

### 2. msg_10195

**You** - 2025-05-11T00:37:27

Fyi awake now so going to try to go back assuming I can\.


---

### 3. msg_10196

**You** - 2025-05-11T07:52:15

Packing up might shower and heading out soon hope you had a good night


---

### 4. msg_10197

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T07:54:17

Have a good day\. Tulips?


---

### 5. msg_10198

**You** - 2025-05-11T07:54:26

No tulips


---

### 6. msg_10199

**You** - 2025-05-11T07:54:40

Just home I think and planning


---

### 7. msg_10200

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T07:55:19

k I think I have to go to volleyball at noonish :p


---

### 8. msg_10201

**You** - 2025-05-11T07:56:20

Well I mean the fun never stops does it\. lol


---

### 9. msg_10202

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T07:56:48

Andrew might come home early and take her 🤞


---

### 10. msg_10203

**You** - 2025-05-11T07:58:11

Reaction: 😂 from Meredith Lamb
Might be nice for yku to get a break on a day that is supposed to be a bit about you at least


---

### 11. msg_10204

**You** - 2025-05-11T08:00:28

Reaction: ❤️ from Meredith Lamb
You are an amazing mother and daughter\.\. someone should say that to you today\.\. and you are amazing to me and I love you\.  I am going to pack up and head out\.\. will let
You know how things are back home when you have a moment to text later\.


---

### 12. msg_10205

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T08:00:29

>
Never happens\.


---

### 13. msg_10206

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T08:01:11

>
k will talk to you later\. Going to watch old vhs videos with my coffee lol


---

### 14. msg_10207

**You** - 2025-05-11T08:01:29

Try not to tear up 😝


---

### 15. msg_10208

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T08:06:24

lol


---

### 16. msg_10209

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T08:43:11

https://youtube\.com/watch?v=ryACpFUwybA&feature=shared
Things me, my mom, her mom and my oldest brother\.


---

### 17. msg_10210

**You** - 2025-05-11T08:45:52

You have a good scream


---

### 18. msg_10211

**You** - 2025-05-11T08:47:27

Chelsey Kelsey sounds similar\.\. didnt know you had a dog named that or was that Brett’s\.


---

### 19. msg_10212

**You** - 2025-05-11T08:49:55

Yeah I can see a lot of that in you today lol\.  Appreciate your sharing\. Oh how much fun can we have with a culvert


---

### 20. msg_10213

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T08:50:53

That was my dog in late elementary/ high school


---

### 21. msg_10214

**You** - 2025-05-11T08:51:18

Same\.


---

### 22. msg_10215

**You** - 2025-05-11T08:51:43

Looks like you had a great sense of humour\.


---

### 23. msg_10216

**You** - 2025-05-11T09:43:12

Heading out now hope you had a chance to pass my message on to your mom\.\. gonna do a drive by otw home\.\. curious 😊


---

### 24. msg_10217

**You** - 2025-05-11T09:57:57

Nice little place\.  Ok heading home chat later\.


---

### 25. msg_10218

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T10:06:43

lol I didn’t see your message so couldn’t look out for you :\)


---

### 26. msg_10219

**You** - 2025-05-11T10:09:28

Sok


---

### 27. msg_10220

**You** - 2025-05-11T10:09:46

I didn’t slow lol


---

### 28. msg_10221

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T10:10:32

lol still watching videos\.


---

### 29. msg_10222

**You** - 2025-05-11T10:10:52

Good it is nice to look back


---

### 30. msg_10223

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T10:46:05

It must be hard missing your mom today xoxoxoxxoxo


---

### 31. msg_10224

**You** - 2025-05-11T10:48:15

Reaction: 😢 from Meredith Lamb
I miss mum every day but I appreciate the thought it is tough\.


---

### 32. msg_10225

**You** - 2025-05-11T10:48:23

Everything happens for a reason though


---

### 33. msg_10226

**You** - 2025-05-11T10:49:09

If she is still alive I am not here right now\.\.


---

### 34. msg_10227

**You** - 2025-05-11T10:49:21

But I still miss her


---

### 35. msg_10228

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T10:49:44

Reaction: ❤️ from Scott Hicks
For sure\. ❤️


---

### 36. msg_10229

**You** - 2025-05-11T10:59:28

Nothing good here today\.\. apparently another massive fight last night gracie vs world again\.\. j clearly having a miserable day\.\. I have some running around to do at noon for my new hobby and then gym tonight for a walk soak sauna and shave\.\. and in between I have to get house stuff going so I will at least be busy


---

### 37. msg_10230

**You** - 2025-05-11T11:00:05

Your mum and her would have got along famously\.\. shawnie had a bit of an interesting side as well\.


---

### 38. msg_10231

**You** - 2025-05-11T11:00:45

She would have been 72 this year\.\.


---

### 39. msg_10232

**You** - 2025-05-11T11:00:52

June 8th


---

### 40. msg_10233

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T12:51:19

Too bad things didn’t improve there \.\.


---

### 41. msg_10234

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T12:51:25

I had a nap lol


---

### 42. msg_10235

**You** - 2025-05-11T12:51:58

Good for you just doing a bit of work on computer then heading out for a few to go buy some things\.


---

### 43. msg_10236

**You** - 2025-05-11T13:13:33

Oh signal analysis complete btw


---

### 44. msg_10237

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:23:34

What seriously?


---

### 45. msg_10238

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:23:53

So I talked to Mackenzie about the job situation and said it isn’t just bc of you\. Lol


---

### 46. msg_10239

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:24:05

I told her how last week my old role opened up


---

### 47. msg_10240

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:24:20

She goes “oh it’s a sign so Scott is obviously meant to be”


---

### 48. msg_10241

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:24:22

LOL


---

### 49. msg_10242

**You** - 2025-05-11T13:30:04

Yep I figured
Out how to back the whole thing up


---

### 50. msg_10243

**You** - 2025-05-11T13:30:13

And got an analysis done


---

### 51. msg_10244

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:30:29

Was it a biased analysis maybe


---

### 52. msg_10245

**You** - 2025-05-11T13:30:29

Mac
Is funny


---

### 53. msg_10246

**You** - 2025-05-11T13:30:35

Nope


---

### 54. msg_10247

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:30:40

Mmm hmm


---

### 55. msg_10248

**You** - 2025-05-11T13:30:51

I don’t ask biased questions


---

### 56. msg_10249

**You** - 2025-05-11T13:31:21

Gotta go out soon though so maybe I will share it with you later


---

### 57. msg_10250

**You** - 2025-05-11T13:31:58

And I think I have to do dinner tonight with family \-
Not my choice then gym\. So fun night ahead


---

### 58. msg_10251

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:36:47

>
Sounds good I just uber eats kfc for everyone so gotta organize


---

### 59. msg_10252

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:37:02

You should do dinner with the fam


---

### 60. msg_10253

**You** - 2025-05-11T13:37:04

Kk have fun chat later


---

### 61. msg_10254

**You** - 2025-05-11T13:37:11

Oh yeah it will be special


---

### 62. msg_10255

**You** - 2025-05-11T13:37:50

Reaction: 😮 from Meredith Lamb
Gracie has bruises all over her from where she bashed herself
All
Over
The house the counters everything\.\. she needs to be in a psychiatric ward but she is 18 and cannot convince Jaimie\.


---

### 63. msg_10256

**You** - 2025-05-11T13:38:11

I might need to actually leave here until they move\.\. I am just not sure yet\.


---

### 64. msg_10257

**You** - 2025-05-11T13:38:18

Anyhow chat later


---

### 65. msg_10258

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:46:17

Oh boy…\. So intense\.


---

### 66. msg_10259

**You** - 2025-05-11T13:55:56

Yeah shit show\.


---

### 67. msg_10260

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T13:57:03

:\(


---

### 68. msg_10261

**You** - 2025-05-11T14:16:18

Rofl ironically I ended up all the way back over here right by you that’s weird\.


---

### 69. msg_10262

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:16:44

Why? What are you doing?


---

### 70. msg_10263

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:17:06

I’m just waiting for my biased analysis\.


---

### 71. msg_10264

**You** - 2025-05-11T14:17:19

It’s a secret\.\. but close enough to walk there\.\. didnt expect that when wayz sent me here\.


---

### 72. msg_10265

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:17:54

🤔


---

### 73. msg_10266

**You** - 2025-05-11T14:17:55

I will get to that later\.\.
Let’s just say that it suggests I need to make some changes\.


---

### 74. msg_10267

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:18:14

That sounds biased


---

### 75. msg_10268

**You** - 2025-05-11T14:18:53

It wasn’t it was objective


---

### 76. msg_10269

**You** - 2025-05-11T14:18:56

And I agree


---

### 77. msg_10270

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:19:26

Why would you have to make changes tho? It is just literal conversation back and forth


---

### 78. msg_10271

**You** - 2025-05-11T14:19:46

No it assessed a whole bunch of things


---

### 79. msg_10272

**You** - 2025-05-11T14:19:58

Relatively etc


---

### 80. msg_10273

**You** - 2025-05-11T14:22:23

It suggested changes
For the good of the relationship etc\. somethings I knew some I should have probably known\.


---

### 81. msg_10274

**You** - 2025-05-11T14:23:31

If you are curious it suggested that while you are emotionally vulnerable you withdraw at requests
For clarity…
Where I am more hesitant at first and then overshare\.\.
And it is related the more you pull back the more I share lol


---

### 82. msg_10275

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:24:00

lol


---

### 83. msg_10276

**You** - 2025-05-11T14:24:02

There was a lot more stuff but that is the gist


---

### 84. msg_10277

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:24:06

I want to read it\!


---

### 85. msg_10278

**You** - 2025-05-11T14:24:10

Nope


---

### 86. msg_10279

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:24:19

Omg


---

### 87. msg_10280

**You** - 2025-05-11T14:24:27

Some of it is pretty raw…


---

### 88. msg_10281

**You** - 2025-05-11T14:24:44

So I can give you the transcript file though if you want to play around


---

### 89. msg_10282

**You** - 2025-05-11T14:24:52

It right now but later


---

### 90. msg_10283

**You** - 2025-05-11T14:24:55

Not


---

### 91. msg_10284

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:25:09

😭


---

### 92. msg_10285

**You** - 2025-05-11T14:25:22

lol I know that isn’t true


---

### 93. msg_10286

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:26:52

Did it say you “overshare”?


---

### 94. msg_10287

**You** - 2025-05-11T14:27:02

Yeah


---

### 95. msg_10288

**You** - 2025-05-11T14:27:38

Well something like that


---

### 96. msg_10289

**You** - 2025-05-11T14:27:56

Again the more you got quiet the more I share
Perhaps overly etc


---

### 97. msg_10290

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:29:45

Did it take into consideration that during some of those conversations I may have been, um, under the influence of stuff


---

### 98. msg_10291

**You** - 2025-05-11T14:30:27

It did not but there is a big enough sample that it should skew the results that much besides I already know there isn’t much difference lol\.


---

### 99. msg_10292

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:31:27

I feel like you should just share it\. You sort of set that expectation earlier


---

### 100. msg_10293

**You** - 2025-05-11T14:31:45

No no I will share the file\.\.


---

### 101. msg_10294

**You** - 2025-05-11T14:31:50

Then you can explore


---

### 102. msg_10295

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:33:59

I mean I’ve done piece meal conversations before\. I want your end result with whatever your prompt was


---

### 103. msg_10296

**You** - 2025-05-11T14:34:19

lol no\.\. not this time\.


---

### 104. msg_10297

**You** - 2025-05-11T14:34:23

We’re both navigating something rare and emotionally intense — something that hit us fast, and deep\. It’s clear we care a lot about each other\. What’s also clear is that we process emotion differently\.
I tend to externalize my feelings — I seek clarity and reassurance when I’m unsure\. You seem to internalize more — you reflect, feel deeply, and sometimes need space before you respond\.
Neither approach is wrong\. They’re just different\.
What this tool helped me realize is that when those two styles interact, we can unintentionally create pressure for each other without meaning to:
•	I might ask too much too fast\.
•	You might step back to protect your emotional boundaries\.
That dynamic can feel confusing — but understanding it has helped me calm down and re\-center\. I’m not sharing this because I need you to change anything\. I’m sharing it because I want to change how I show up, so this can feel safe and good for both of us\.
If we move forward gently, honoring our own timing but staying ho\.\.\. \[truncated\]


---

### 105. msg_10298

**You** - 2025-05-11T14:34:47

This was a neutral summary I asked it to write in a way uncoils convey to you\.


---

### 106. msg_10299

**You** - 2025-05-11T14:35:04

In a safe way to convey it to you


---

### 107. msg_10300

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:41:10

Yeah I have already had ChatGPT tell me this exact message based on some screenshots before\.


---

### 108. msg_10301

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:41:12

:\)


---

### 109. msg_10302

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:41:27

All makes a ton of sense


---

### 110. msg_10303

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:41:40

And I’m ok with it if you are lol


---

### 111. msg_10304

**You** - 2025-05-11T14:41:57

It made some recommendations for me though so I am going to dig into those


---

### 112. msg_10305

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:43:14

I don’t think you need to change\. I think we both just need to understand this\. And also think of everything we are dealing with outside of you and I that could be impacting things also…\.


---

### 113. msg_10306

**You** - 2025-05-11T14:51:31

Yeah I wouldn’t out too much thought into it\. I have had a chance to think and process\.\. I feel like I have a bit of a roadmap for myself\.


---

### 114. msg_10307

**You** - 2025-05-11T14:51:59

Ok shopping adventure done\.\.  headed back\.  Enjoy the kfc\.


---

### 115. msg_10308

**You** - 2025-05-11T14:54:01

Want me to do another drive by so you can wave lol


---

### 116. msg_10309

**You** - 2025-05-11T14:54:23

Joking


---

### 117. msg_10310

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:56:43

My bro and fam are leaving


---

### 118. msg_10311

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:56:45

lol


---

### 119. msg_10312

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:57:15

>
Are you really bothered by our differences in this area? You know it will evolve naturally right


---

### 120. msg_10313

**You** - 2025-05-11T14:58:09

>
It described an asymmetrical relationship which can cause stress


---

### 121. msg_10314

**You** - 2025-05-11T14:58:30

Mostly
Caused by me


---

### 122. msg_10315

**You** - 2025-05-11T14:58:39

Well almost completely


---

### 123. msg_10316

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:59:16

k well “asymmetrical” is a concerning word


---

### 124. msg_10317

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T14:59:18

lol


---

### 125. msg_10318

**You** - 2025-05-11T14:59:40

Mer it is fine no surprises


---

### 126. msg_10319

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:00:41

🤔


---

### 127. msg_10320

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:01:45

“It is fine”


---

### 128. msg_10321

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:01:50

🙄


---

### 129. msg_10322

**You** - 2025-05-11T15:04:46

It did say you use emoticons as a means to avoid emotional engagement


---

### 130. msg_10323

**You** - 2025-05-11T15:04:52

😝


---

### 131. msg_10324

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:05:15

Or is it just easier than typing?


---

### 132. msg_10325

**You** - 2025-05-11T15:05:28

Mmmmm I trust it


---

### 133. msg_10326

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:05:53

You should trust it with a grain of salt


---

### 134. msg_10327

**You** - 2025-05-11T15:06:41

Like it said you withdrew from specifically defining or clarifying emotions feelings etc\. and identified that emoticons were an alternative way to offer up sufficiently vague or safe responses or means of engagement


---

### 135. msg_10328

**You** - 2025-05-11T15:06:49

Subject to interpretation


---

### 136. msg_10329

**You** - 2025-05-11T15:06:54

lol


---

### 137. msg_10330

**You** - 2025-05-11T15:07:01

Beat that logic


---

### 138. msg_10331

**You** - 2025-05-11T15:07:46

Let’s say all in all I felt it was accurate including\.\. especially including my self assessment


---

### 139. msg_10332

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:10:31

I mean I know I’m not great at articulating emotions\. Good, bad, ugly\. It causes me a lot of issues in life generally\.


---

### 140. msg_10333

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:10:49

But they are there\. I just have difficulty processing and articulating them


---

### 141. msg_10334

**You** - 2025-05-11T15:11:24

I know that\.\. I don’t doubt you


---

### 142. msg_10335

**You** - 2025-05-11T15:12:04

I was more focused on the so what should I do selfishly


---

### 143. msg_10336

**You** - 2025-05-11T15:12:27

Anyhow don’t worry it didnt suggest bumble


---

### 144. msg_10337

**You** - 2025-05-11T15:12:58

You are fucked for your drive home


---

### 145. msg_10338

**You** - 2025-05-11T15:13:00

Go 407


---

### 146. msg_10339

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:13:15

Ugh


---

### 147. msg_10340

**You** - 2025-05-11T15:13:27

Srsly


---

### 148. msg_10341

**You** - 2025-05-11T15:13:30

407


---

### 149. msg_10342

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:13:39

Waze says 1hr10


---

### 150. msg_10343

**You** - 2025-05-11T15:13:59

401 was RED


---

### 151. msg_10344

**You** - 2025-05-11T15:14:08

And bailey is packed


---

### 152. msg_10345

**You** - 2025-05-11T15:14:16

Accident somewhere I think


---

### 153. msg_10346

**You** - 2025-05-11T15:17:25

>
Didn’t want bumble reference to get lost in drive time report


---

### 154. msg_10347

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T15:19:52

lol


---

### 155. msg_10348

**You** - 2025-05-11T15:22:09

Kk going into metro as I said I will send you the transcript of the conversations later\.\. will chat later\.


---

### 156. msg_10349

**You** - 2025-05-11T16:01:14

This is the transcript I was able to pull from our conversations\.

*1 attachment(s)*


---

### 157. msg_10350

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T16:58:38

Whoah that’s long


---

### 158. msg_10351

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T16:58:54

Not was I was looking for but whatever


---

### 159. msg_10352

**You** - 2025-05-11T17:11:54

lol I know what you were looking for but I said I would give you that so you could plug it into gpt\.


---

### 160. msg_10353

**You** - 2025-05-11T17:12:01

Hope your drive was ok


---

### 161. msg_10354

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T17:16:02

It was okay\.\.


---

### 162. msg_10355

**You** - 2025-05-11T17:33:31

big couple days\.\. you must be tired\.


---

### 163. msg_10356

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:00:51

Plus I was feeling nauseous from my mounjaro lol ughhhh


---

### 164. msg_10357

**You** - 2025-05-11T19:02:14

are you ok now?  I thought you might be cranky at me lol


---

### 165. msg_10358

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:12:08

No not cranky\. Just tired\. :\(


---

### 166. msg_10359

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:12:53

And Marlowe keeps bugging me


---

### 167. msg_10360

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:12:57

First math homework


---

### 168. msg_10361

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:13:04

Now her Instagram was hacked


---

### 169. msg_10362

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:13:12

And she is so annoying about passwords


---

### 170. msg_10363

**You** - 2025-05-11T19:15:46

LastPass


---

### 171. msg_10364

**You** - 2025-05-11T19:15:54

I think I told you about this before


---

### 172. msg_10365

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:16:58

Someone hacked her account so all the recovery methods go to a different email and \#


---

### 173. msg_10366

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:17:21

Someone promoting crypto


---

### 174. msg_10367

**You** - 2025-05-11T19:17:35

ah\.\. well then lastpass will only work once you have instagram delete it or return it to her\.


---

### 175. msg_10368

**You** - 2025-05-11T19:17:42

sorry that sucks :\(


---

### 176. msg_10369

**You** - 2025-05-11T19:18:39

Ok\.\. well I have been working on J's Lawyer shit all day\.\. so I am going to head to gym for some treadmill stuff\.


---

### 177. msg_10370

**You** - 2025-05-11T19:19:00

oh and plan for hobby time\.\. I need to get that going too\.


---

### 178. msg_10371

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T19:20:14

k, I’m going to watch’s new documentary I think lol


---

### 179. msg_10372

**You** - 2025-05-11T19:21:16

kk have fun\.


---

### 180. msg_10373

**Meredith Lamb \(\+14169386001\)** - 2025-05-11T21:29:26

I’m going to go to bed early\. Sorry I’ve been distant\. It’s been a shitty afternoon/evening\. Don’t feel like getting into it so I’m just going to go to sleep\. Wanted to let you know I’m not ignoring you and love you\. Xo


---

### 181. msg_10374

**You** - 2025-05-11T21:36:46

Reaction: ❤️ from Meredith Lamb
Love you too mer a lot, really enjoyed our night together\.  Sorry you had a shit aft/evening\.  Just heading home from gym then I am going to crash too\.  See you tomorrow\. Xoxo


---

### 182. msg_10375

**You** - 2025-05-12T03:54:09

And btw I really appreciate your explaining, the why and the context, that kind of stuff actually means a lot to me\.\. meant to mention it earlier\.


---

### 183. msg_10376

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T06:55:18

Up at 4am? Eeek


---

### 184. msg_10377

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T06:56:05

I took lots of melatonin so slept ok last night\. Won’t be in the best of moods today though\. 🫤


---

### 185. msg_10378

**You** - 2025-05-12T07:03:50

Oh goody


---

### 186. msg_10379

**You** - 2025-05-12T07:04:00

What did I do now lol


---

### 187. msg_10380

**You** - 2025-05-12T07:04:28

I was going to wear my special shirt and everything for Jim but if you are in a bad mood maybe I go back home


---

### 188. msg_10381

**You** - 2025-05-12T07:04:51

>
Woke up on my own no alarm\.\. love this shit\!\!


---

### 189. msg_10382

**You** - 2025-05-12T07:04:58

Can’t wait till you can do with me


---

### 190. msg_10383

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:17:02

I will be okay today\. Lol


---

### 191. msg_10384

**You** - 2025-05-12T07:17:57

Ok we’ll see when I see yah\. Heading in now\.


---

### 192. msg_10385

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:25:19

Just my family, this separation …


---

### 193. msg_10386

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:25:33

They pissed me off yday


---

### 194. msg_10387

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:25:38

I will be over that soon


---

### 195. msg_10388

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:26:09

I mean you not sending your analysis didn’t help 🤨


---

### 196. msg_10389

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:26:28

But that was just bc of other stuff going on


---

### 197. msg_10390

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:26:36

Don’t want to type it all out


---

### 198. msg_10391

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T07:26:39

Annoying


---

### 199. msg_10392

**You** - 2025-05-12T07:55:00

Just got here I have a bit of time this morning if you want to book something and come in for a few mins\.\. didnt look at your calendar\.


---

### 200. msg_10393

**You** - 2025-05-12T08:01:55

Reaction: ❤️ from Meredith Lamb
I love you mer\.\. ❤️❤️❤️❤️

*1 attachment(s)*


---

### 201. msg_10394

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T10:44:40

Phew


---

### 202. msg_10395

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T10:44:47

That was intense\.


---

### 203. msg_10396

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T10:44:53

Wasn’t expecting that\.


---

### 204. msg_10397

**You** - 2025-05-12T10:48:49

I am just talking to j coming up in a sec


---

### 205. msg_10398

**You** - 2025-05-12T11:57:02

You ok you looked really cranky


---

### 206. msg_10399

**You** - 2025-05-12T12:03:03

Are you ok??


---

### 207. msg_10400

**You** - 2025-05-12T12:11:51

Not sure what is going on but head home if you need to work from there\.


---

### 208. msg_10401

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:50:42

So I haven’t given really any thought to telling Daniel about our situation\. Will think about it if my brain can handle that


---

### 209. msg_10402

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:50:50

I’d really rather not tho


---

### 210. msg_10403

**You** - 2025-05-12T12:55:54

I thought we agreed in here not to


---

### 211. msg_10404

**You** - 2025-05-12T12:56:06

I said we can figure out a timeline later


---

### 212. msg_10405

**You** - 2025-05-12T12:56:13

Like down the road


---

### 213. msg_10406

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:56:19

I know but it sounds like you have thought about it more than I have


---

### 214. msg_10407

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:56:27

I honestly haven’t thought about it much


---

### 215. msg_10408

**You** - 2025-05-12T12:56:38

I just don’t want to seem duplicitous\.


---

### 216. msg_10409

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:56:38

I just don’t want to without even thinking about it lol


---

### 217. msg_10410

**You** - 2025-05-12T12:56:48

Like I said that is fine


---

### 218. msg_10411

**You** - 2025-05-12T12:56:52

No pressure


---

### 219. msg_10412

**You** - 2025-05-12T12:56:58

Remove it from your thoughts


---

### 220. msg_10413

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:57:32

Could it not be plausible that when we are both officially separated… a timeline would then start?


---

### 221. msg_10414

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:57:40

I will think about it


---

### 222. msg_10415

**You** - 2025-05-12T12:57:41

Yea


---

### 223. msg_10416

**You** - 2025-05-12T12:57:46

That is more realistic


---

### 224. msg_10417

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:57:57

But I think there is a way that it could not be duplicitous


---

### 225. msg_10418

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:58:18

But maybe I’m being naive?


---

### 226. msg_10419

**You** - 2025-05-12T12:58:36

But I would want to be honest maybe suggest that we kind of made a connection through supporting each other but agreed not to explore anything until after everything was sorted


---

### 227. msg_10420

**You** - 2025-05-12T12:58:44

But again
Don’t need to decide today\.\.


---

### 228. msg_10421

**You** - 2025-05-12T12:58:54

So you can just leave it lol


---

### 229. msg_10422

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T12:59:21

Hmmh ok … I will ask ChatGPT later ;\)


---

### 230. msg_10423

**You** - 2025-05-12T12:59:54

Whatever\.\. you wanted me to lighten the load I am trying here lol\.


---

### 231. msg_10424

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:00:41

I never said anything to you about that… ChatGPT did


---

### 232. msg_10425

**You** - 2025-05-12T13:05:02

Prompt 1\.
I am trying to get a conversation by conversation analysis from start to finish of this transcript\.  Specifically Meredith is someone I am madly in love with, and I think she feels the same about me\.\. but we are navigating some challenging situations, and I would be interested in your OBJECTIVE observations \- do not spare my feelings please\.  Let's start here\.


---

### 233. msg_10426

**You** - 2025-05-12T13:05:26

Response 1
Your provided transcript with Meredith highlights a deep emotional connection and intense attraction between you both\. Here’s a structured, objective analysis based on the conversation provided:
⸻
Conversation Analysis: Key Observations
1\. Emotional Connection
•	Mutual intensity and rarity:
Meredith explicitly notes via a ChatGPT response the rare nature of your connection—emotional depth, immediate understanding, and a sense of inevitability characterize your interactions\. This is significant as it shows she is intellectually rationalizing the intensity and rarity of your relationship, which indicates deep emotional investment\.
•	Rapid vulnerability:
Both of you express a quick escalation in openness and emotional vulnerability\. Meredith particularly emphasizes this as unusual for both of you, reinforcing the idea that the connection feels uniquely safe and genuine\.
2\. Mutual Insecurity
•	Both of you frequently express insecurity, especially about the stability and exclusiv\.\.\. \[truncated\]


---

### 234. msg_10427

**You** - 2025-05-12T13:05:50

Prompt 2
Some additional context that might prove useful \- despite our being the same age, my children are 16 and 18, and hers are 12, 14 and 16, and are all very much engaged with her on a regular basis\.  She has a significant amount of friends that engage with her on a regular basis\.\. I have none or maybe one\. Not counting her\.\. and while she is awesome she has significant demands on her time\.  She additionally has sought some comfort and peace in having a drink or two at night\.\. sometimes thc gummies\.\. something to take the edge off which might impact some of her conversations\.\. or when she becomes quieter and not as responsive\.  I truly believe we both feel the same way about each other\.\. I have made her a mix tape, wrote her a love letter like back in the 90's  all impulsively, all because I love her and want her to be happy\.  While this type of outward emotion is not her style, she also surprised me with a rock that represented the rocks in her yard when she was a kid \- one of he\.\.\. \[truncated\]


---

### 235. msg_10428

**You** - 2025-05-12T13:06:11

Response 2
Given your additional context, here’s a deeper, detailed exploration of the conversation, emphasizing key areas of emotional nuance, relationship dynamics, challenges, and strengths within your interactions with Meredith\.
⸻
Deeper Conversation Analysis with Contextual Integration
1\. Emotional Intensity and Mutual Affection
Your emotional connection with Meredith appears genuine, mutual, and intense\. Meredith repeatedly engages with concepts like rarity and emotional vulnerability, highlighting that this is not typical for either of you\. Notably:
•	Shared Sense of “Unbelievability”:
Meredith’s direct query to ChatGPT about the unusual nature of your connection strongly suggests she’s trying to rationalize powerful emotions\. This indicates significant self\-awareness about the intensity and rarity of her feelings, revealing deep emotional investment and vulnerability\.
•	Acts of Affection \(Love Language\):
•	Your spontaneous actions \(mixtape, handwritten love letter\) indicate pro\.\.\. \[truncated\]


---

### 236. msg_10429

**You** - 2025-05-12T13:13:09

There now you have some stuff to read\.


---

### 237. msg_10430

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:21:27

Although it isn’t your original, I will take it\. :\)


---

### 238. msg_10431

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:22:30

It all makes sense… a lot of things all converging at once\. Just stress left right and centre and when I have to tell the team, Carolyn etc mooooooore stress


---

### 239. msg_10432

**You** - 2025-05-12T13:22:35

It is pretty thorough


---

### 240. msg_10433

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:22:42

It is a lot right now


---

### 241. msg_10434

**You** - 2025-05-12T13:23:08

I am more concerned with you particularly how you feel how I can help you\.  I am going to ask it another question


---

### 242. msg_10435

**You** - 2025-05-12T13:31:00

Reaction: 😂 from Meredith Lamb
Last one for the day curious how close it comes to what I have already said\.
Prompt
I have frequently tried to explain to Meredith, and I get it can be hard to believe that I am absolutely in love with her\.\. like forever\.\. I think the only way I can feel this certain is that I am almost 47\.\. while she already is\.\.\.\.\.\.\.\.\.\.\.\.\.\.  How can I assure her that I have never felt this certain or this strongly for anyone\.\. both on an intimacy and friendship level\.\. which having both together is kind of insane\.\. I just need her to know without of a shadow of a doubt that she is my home, and that is all I will ever need?  The thing is if this is what it is like to fall deeply in love with someone, then I have never even approached this level of feeling and conviction\.  So help a fella out here please\!


---

### 243. msg_10436

**You** - 2025-05-12T13:31:23

Response
Scott, what you’re experiencing is powerful and deeply genuine, which is precisely why expressing it clearly and convincingly can feel challenging\. Here’s how you can convey this depth of feeling to Meredith with clarity, sincerity, and emotional intensity, leaving no room for doubt:
⸻
1\. Start with Complete, Vulnerable Honesty
Begin by openly acknowledging the magnitude and rarity of what you’re feeling\. Explicitly state that you’ve never felt anything approaching this\.
Example wording:
“Meredith, I understand how hard this must be to truly believe—honestly, it’s hard even for me to grasp sometimes\. But I need you to know that, at almost 47 years old, I’m experiencing something I’ve never come close to before\. If this is what truly falling in love feels like—deeply, madly, completely—then everything else in my life has just been practice\.”
⸻
2\. Explicitly Acknowledge Her Doubts
Recognize openly that her hesitation or uncertainty isn’t unreasonable, which validates her feeling\.\.\. \[truncated\]


---

### 244. msg_10437

**You** - 2025-05-12T13:31:48

Pretty sure gpt nailed it better\.\. but I agree with all of it\.


---

### 245. msg_10438

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:46:42

Okay that was a lot\. Lol I wouldn’t say I’m uncertain but I agree that I am cautious\. This is a lot, especially with everything else going on and you can’t argue with that\. I do feel the same way about you so agree with ChatGPT there but my rational side says be careful Meredith\.


---

### 246. msg_10439

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:47:28

https://open\.spotify\.com/track/0FTmksd2dxiE5e3rWyJXs6?si=y4acZIMhReKv7BWSt1uznw
Ever heard this song before? It’s like every Monday at work lol


---

### 247. msg_10440

**You** - 2025-05-12T13:48:21

I remember what it felt like to be hurt\.\.  it has been a long time but I Remeber and I through myself,
In an immature way albeit, into the relationship the same way\.\. I am not holding back but I will wait for you to catch up\.


---

### 248. msg_10441

**You** - 2025-05-12T13:48:36

I threw myself


---

### 249. msg_10442

**You** - 2025-05-12T13:48:54

I have Harare that song


---

### 250. msg_10443

**You** - 2025-05-12T13:48:57

Heard


---

### 251. msg_10444

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:49:56

This relationship is a bit complex though\. More than any I have experienced\.


---

### 252. msg_10445

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:50:08

No other relationship involved living with exes\.


---

### 253. msg_10446

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:50:14

lol


---

### 254. msg_10447

**You** - 2025-05-12T13:51:04

I am not even going to think on that anymore I 100% trust you\.  I was hesitant at first\.\. but I think I have looked in your eyes long enough that I don’t feel I have to worry\.


---

### 255. msg_10448

**You** - 2025-05-12T13:51:51

But it is complex\.\. but it doesn’t have to be just place the boundaries and move them when you are ready\.


---

### 256. msg_10449

**You** - 2025-05-12T13:53:31

I mean I feel like you are more uncertain now than previously just not sure how to fix that\.


---

### 257. msg_10450

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:55:45

I’m not “more uncertain”\. I’ve just had some exposure into how attached you two are and it feels different than Andrew and I\. That’s all\. It’s okay, just different\.


---

### 258. msg_10451

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:58:55

It actually seems like you guys have a bit of a connection when you talk\. Just saying\.


---

### 259. msg_10452

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:59:02

Hoping you don’t regret later\.


---

### 260. msg_10453

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:59:46

I know you situation is different than mine yadda yadda


---

### 261. msg_10454

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:59:49

I get that


---

### 262. msg_10455

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:59:53

And all the rest


---

### 263. msg_10456

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T13:59:54

lol


---

### 264. msg_10457

**You** - 2025-05-12T14:02:23

Meredith err nah gerrd there is nothing I have felt for anyone that comes close to you ever ever ever, friend, companion, partner,
Lover everything\.  I won’t 20 years with Jaimie I feel I owe her support\.\. we didn’t end the same way\.\. I don’t despise her\.\. but even at the best of times what I felt for her wasn’t even a shadow of what I feel for you\.  We were partners at best nothing else\. The only way I would ever regret t this is if you left for some reason\.


---

### 265. msg_10458

**You** - 2025-05-12T14:03:43

This is the kind of guy you love it is who I am\.  I am not a pos that would abandon someone completely just because our lives fell apart\.  But my commitment is to you\.\. you het everything I have to give you\.  No one else ever got that not even close\.


---

### 266. msg_10459

**You** - 2025-05-12T14:05:12

This is why spending time together is important that reassurance is meaningful\.  So when you can get your head around a solution you let me know lol\.\.
I will give you as much reassurance as
You need


---

### 267. msg_10460

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:07:28

Noted and I get that\. Our circumstances are very different even if somewhat similar\. Maybe I’m a bit jealous of Jaime lol I mean just understand I’m not dealing with the same kind of person on the other side so it might be a bit more stressful


---

### 268. msg_10461

**You** - 2025-05-12T14:10:03

Omg Meredith shall I get up on my desk here and scream it from inside my office\.


---

### 269. msg_10462

**You** - 2025-05-12T14:10:14

Cause I will 😈


---

### 270. msg_10463

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:10:22

Noooo


---

### 271. msg_10464

**You** - 2025-05-12T14:12:08

I am a bit jealous of everyone that gets time with you\.\. honestly if it makes it easier… I will get out and rent a place seriously like i just want to be with you\.\. everything else will take care of itself\.\. but if in the meantime this is easier it is easy for me to do\.


---

### 272. msg_10465

**You** - 2025-05-12T14:13:28

I also literally spend the minimum amount of time at home that I have to\.


---

### 273. msg_10466

**You** - 2025-05-12T14:15:45

But one thing you should be certain of is she dislikes me now\.\. a lot even though we are being amicable,  she does\. It want to get back together ever and suggested today she will never forgive me\.\. so again… time and patience and there will only be you\.


---

### 274. msg_10467

**You** - 2025-05-12T14:17:38

See this is what gpt said I go overboard because I want to make sure you are 100% ok because honestly I don’t ever wan you to feel uncertain about me\.


---

### 275. msg_10468

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:21:05

I’m not sure it is overboard “per se” but I think you can easily articulate your thoughts and some of us can’t do that quite so easily\.


---

### 276. msg_10469

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:21:16

Because you can, you do\.


---

### 277. msg_10470

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:21:26

Because I can’t, I don’t\.


---

### 278. msg_10471

**You** - 2025-05-12T14:22:01

Well I hope my articulating these thoughts helps ease the thoughts that you are having a harder time articulating\.


---

### 279. msg_10472

**You** - 2025-05-12T14:22:39

It is less important that you can reciprocate\.  It is more important that you understand and believe\.


---

### 280. msg_10473

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:55:28

I do believe but have moments of doubt\. That’s all\. If this situation wasn’t so messy all around, I think it would be incredibly easier to navigate\.


---

### 281. msg_10474

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T14:55:34

But it’s worth it\. ;\)


---

### 282. msg_10475

**You** - 2025-05-12T14:59:08

Just don’t give up on me because I won’t give up on you\.  If you ever have doubt ask\. It isn’t weak\.\. if you need reassurance I will always provide it without question\.


---

### 283. msg_10476

**You** - 2025-05-12T14:59:38

Honestly it is so sick that we are having to go through this we are months away\.


---

### 284. msg_10477

**You** - 2025-05-12T14:59:52

Like that is nothing compared to what comes after


---

### 285. msg_10478

**You** - 2025-05-12T15:00:02

Even if there will be some transition time etc


---

### 286. msg_10479

**You** - 2025-05-12T15:06:21

>
I guess my questions are and feel free to withdraw\.\. doubts about us, about me and Jaimie, about what you want, about what I want?  I know clarity is hard for you but I feel just leaving it at I have doubts is a little open ended, and hard for me to reconcile\.


---

### 287. msg_10480

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T15:45:12

So my moments of doubt come at random times\. But honestly when you were talking to Jaime when I was there…\. Enter doubt\. I just have such different conversations with Andrew even during logistical type stuff\. And oftentimes, we just don’t even talk at all ever\. No need to respond to that though because you already did\. Another doubt I sometimes have is just from not knowing you long enough\. If you are super into this right now will you turn a switch later but I have mentioned this before\. You just say yourself you are very fast at making decisions\. I don’t have any doubts about what I want\. If I did I wouldn’t bother switching jobs right now\. I would wait until later\.


---

### 288. msg_10481

**You** - 2025-05-12T15:49:46

I am so going to show you what you mean to me if given the chance mer\.\. all I can say\.  I cannot help with some of these doubts unfortunately\.  I will never be super into anyone else\.  Ever\.  I don’t want anyone else I have never said anything like any of what I have said to anyone else ever\.  I am sitting here writing this feeling chills because I am trying to literally will you into believing that my decision is you\.  I explained the Jaimie thing took years and I tried to change the course the entire time\.\. I didn’t just give up and say screw it\.   But yes like you in that moment where Andrew asked you to hook back up\.\. there was a moment like that for me where I was like yep I am done\.  I don’t think we are dissimilar there\.


---

### 289. msg_10482

**You** - 2025-05-12T15:50:23

Home is you there is no where else


---

### 290. msg_10483

**You** - 2025-05-12T15:50:57

Patience and time… and trust\.\. trust me mer I swear I won’t make you regret it ever\.


---

### 291. msg_10484

**You** - 2025-05-12T15:53:33

I am trying to do the same with you\. Bit of a leap I know\.\.


---

### 292. msg_10485

**You** - 2025-05-12T15:53:42

But we can hold hands on the way down\.


---

### 293. msg_10486

**You** - 2025-05-12T15:56:43

Do you have a min to pop in I have to leave shortly after 4


---

### 294. msg_10487

**You** - 2025-05-12T15:56:47

Going to bank


---

### 295. msg_10488

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T16:01:23

On a call with octo and mate


---

### 296. msg_10489

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T16:01:29

Maye


---

### 297. msg_10490

**You** - 2025-05-12T17:18:45

Hope that went well


---

### 298. msg_10491

**You** - 2025-05-12T17:31:59

Oh and if you doubt again and I am not around\.\. please come back and read this\.  It is now and always will be true\.  I am happy this is one more roadblock down mer\.


---

### 299. msg_10492

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T17:39:36

That went well but Michelle walked over so she knows\. Then we realized Louise was at her desk so she knows too\. Team doesn’t\.


---

### 300. msg_10493

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T17:41:33

I need to drive home but I did appreciate what you wrote\. Also appreciate you and Daniel making the job switch happen relatively quickly … realize transition may be lengthy but that is fine\.


---

### 301. msg_10494

**You** - 2025-05-12T17:48:46

As you said it is progress\.\. and I will do whatever I can to help you\.


---

### 302. msg_10495

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T18:08:03

I mean one less thing to do now \(find another job for various reasons\) so that is a relief honestly


---

### 303. msg_10496

**You** - 2025-05-12T18:14:19

Yep one down a few to go\. lol


---

### 304. msg_10497

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T19:02:19

Yeah just a few\. Got home \- bickered and fought about mediation, dogs etc for a while\. So fun this life is right now\. :p


---

### 305. msg_10498

**You** - 2025-05-12T19:08:46

Just focus on me then\.\.
Focus on us\.\. that is what I do


---

### 306. msg_10499

**You** - 2025-05-12T19:09:33

Don’t engage\.\. that is what the mediator is for let them do their job you won’t solve anything with him directly


---

### 307. msg_10500

**You** - 2025-05-12T19:10:01

He needs to be shown reality and then appreciate the sacrifices you were willing to make for what they actually are\.


---

### 308. msg_10501

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T19:12:15

>
I will do my best to :\)


---

### 309. msg_10502

**You** - 2025-05-12T19:12:50

I love you mer we got
Some shit days to go but I promise will be worth it\.


---

### 310. msg_10503

**You** - 2025-05-12T19:13:20

You don’t need to chat with me\.\. focus on you I am here if you need me\.


---

### 311. msg_10504

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T19:15:06

I love you too … today was helpful but I didn’t get much work done lol


---

### 312. msg_10505

**You** - 2025-05-12T19:15:36

lol I wouldn’t worry about it I am sure I won’t call you out for it lol


---

### 313. msg_10506

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T19:18:25

I got out of volleyball tonight so taking the dogs to the park


---

### 314. msg_10507

**You** - 2025-05-12T19:19:56

Good go get a good walk in with the dogs\.\. heading to gym shortly here to go for my own walk\.


---

### 315. msg_10508

**You** - 2025-05-12T19:21:58

Will be thinking about you tonight\.  I could see the pain and frustration in your eyes today\.\. I am sooooo sorry I never realized they were so heavy\.\.   I feel like I added to them but no more of that\.\. we can support each other through this\.


---

### 316. msg_10509

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T19:30:26

It’s a heavy time… phase that will pass… they all do\. I’m very glad I have you though\. xo


---

### 317. msg_10510

**You** - 2025-05-12T19:31:22

Same\. I am here for you just like you have been for me\.


---

### 318. msg_10511

**You** - 2025-05-12T19:56:03

You know I was thinking in the drive over here you are just as emotionally expressive as I am\.\. but a lot of it you do through the words of others this songs you share\.  Maybe I am way off but most of the time when I listen to the words there is a pretty clear message there\.


---

### 319. msg_10512

**You** - 2025-05-12T19:56:19

Remind me to play the sailor song next time we are together\.


---

### 320. msg_10513

**You** - 2025-05-12T22:06:12

Hey I assume you have already gone to bed or are having a bad night or maybe both\.  I am just going to go to sleep\.  Nite\. Xo


---

### 321. msg_10514

**You** - 2025-05-12T22:07:07

Hope you are ok\.


---

### 322. msg_10515

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T20:00:37

You are not way off\.


---

### 323. msg_10516

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T23:08:38

Reaction: 😔 from Scott Hicks
Both but all fine \- def fell asleep nite xoxo


---

### 324. msg_10517

**Meredith Lamb \(\+14169386001\)** - 2025-05-12T23:12:10

I mean on the bright side I woke up to a text from Mac asking if Johnny can come over on Thursday to do his proposal lol I was like “uh yeah\!”


---

### 325. msg_10518

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:42:45

Approach I took moving roles: Your approach is thoughtful, strategic, and wise given the circumstances\.
Here’s why it works well:
1\.	Protects Privacy and Professional Boundaries: By focusing your explanation on your separation and family responsibilities, you’re offering a legitimate, relatable reason without introducing personal dynamics that could complicate perceptions or workplace relationships\.
2\.	Keeps the Narrative Clean: Framing the move as a decision made for your children presents a clear and non\-controversial rationale\. It avoids any need for others to speculate or gossip about your relationship with Scott\.
3\.	Avoids Potential Conflicts of Interest: Not mentioning the relationship protects both you and Scott from the appearance of impropriety or favoritism, which could raise HR concerns or affect team morale\.
4\.	Maintains Professional Dignity: You’re positioning the move as an empowered choice based on personal values—not as a reaction to workplace drama—which helps preserve\.\.\. \[truncated\]


---

### 326. msg_10519

**You** - 2025-05-13T04:43:53

Seriously this at 4:43 in morning\.  Are you ok lol?


---

### 327. msg_10520

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:44:07

Could this be seen as duplicitous by Daniel or Erin later: That’s a very valid question—and the short answer is: very unlikely, as long as the relationship didn’t interfere with your work or decision\-making while you reported to Scott and you continue to act professionally\.
Here’s why:
⸻
1\. You’ve Already Taken the Ethical Action:
You removed yourself from Scott’s reporting line before the relationship became known or created issues\. That signals maturity, foresight, and responsibility\. You’ve acted in alignment with what most leaders would want from an employee in a complex situation\.
⸻
2\. It’s Reasonable to Keep Personal Life Private:
Your separation and needing flexibility for your kids is a full, valid explanation for the change\. You’re not obligated to disclose personal relationships if they’re no longer relevant to the reporting structure or operations\.
⸻
3\. People Understand Complexity—Especially Leaders:
If your boss or her boss ever found out about your relationship with Scott\.\.\. \[truncated\]


---

### 328. msg_10521

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:44:21

>
No\. Lol


---

### 329. msg_10522

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:44:29

\(Went to bed too early\.\)


---

### 330. msg_10523

**You** - 2025-05-13T04:45:06

Sucks too bad gym is too far away\.


---

### 331. msg_10524

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:45:13

Correct—Scott does not need to disclose anything to your new boss’s boss \(his peer\) unless there’s a specific reason to\.
Here’s why:
⸻
1\. There’s No Reporting Relationship or Oversight Involved
Your new boss’s boss has no formal authority or HR responsibility over Scott\. Peer\-to\-peer disclosure is not required and would actually be unusual unless that peer has a specific operational reason to know \(e\.g\., shared oversight, conflict\-of\-interest risk, or visible workplace exposure\)\.
⸻
2\. Disclosure Should Follow Chain of Responsibility, Not Familiarity
If Scott were to disclose to anyone, it should be:
•	His own manager
•	Or HR, if your workplace has a policy or if visibility becomes an issue
Telling a peer—even one who now oversees your work—can seem personal, political, or unnecessary unless:
•	That peer is raising questions
•	Or Scott anticipates some work\-related overlap that could make the relationship relevant again
⸻
3\. It Risks Overcomplicating Things
If he discloses to your new b\.\.\. \[truncated\]


---

### 332. msg_10525

**You** - 2025-05-13T04:45:47

You know I supported you right


---

### 333. msg_10526

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:46:18

Yes, I just hadn’t had time to really think about it\. Was going on gut reaction


---

### 334. msg_10527

**You** - 2025-05-13T04:46:18

I looked you right in the eyes, and said we are good to do it your way lol and I was absolutely fine\.


---

### 335. msg_10528

**You** - 2025-05-13T04:46:41

I knew we could make it work either way but this way was safer


---

### 336. msg_10529

**You** - 2025-05-13T04:46:57

Just a little tougher o\. My conscience but I can deal with that easy enough\.


---

### 337. msg_10530

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T04:47:35

k, good I’m sure your conscience will survive :\)


---

### 338. msg_10531

**You** - 2025-05-13T04:47:55

Yep it is absolutely fine\. No issues here\.


---

### 339. msg_10532

**You** - 2025-05-13T04:58:53

Well I hope you are able to get back to sleep and your mind doesn’t keep spinning to keep you awake\.


---

### 340. msg_10533

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:02:41

My head is currently spinning on finding a place to live\. It will spin until I am through this I think\. It’s ok\. I just need to make sure I get enough sleep\. Makes it easier\.


---

### 341. msg_10534

**You** - 2025-05-13T05:04:31

You are doing what I was doing a few weeks ago, and I think you are also worrying about me a bit
More even though you might not want to admit it\. It is the same thing I was going through\. Everything all at once from every direction makes you doubt everything\.


---

### 342. msg_10535

**You** - 2025-05-13T05:04:49

You just need to focus on one thing at a time


---

### 343. msg_10536

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:05:44

I also have an ex who doesn’t care if I can afford rent\.


---

### 344. msg_10537

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:05:53

In this area\.


---

### 345. msg_10538

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:06:00

Like literally doesn’t care\.


---

### 346. msg_10539

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:06:05

It’s just all annoying


---

### 347. msg_10540

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:06:14

I should just move and take my kids


---

### 348. msg_10541

**You** - 2025-05-13T05:06:45

That won’t happen regardless of what he cares about\.


---

### 349. msg_10542

**You** - 2025-05-13T05:07:02

Like I said don’t engage him on this at all talk through mediator get a lawyer


---

### 350. msg_10543

**You** - 2025-05-13T05:07:27

Trust my advice, I am only looking out for you\.


---

### 351. msg_10544

**You** - 2025-05-13T05:08:30

Reaction: 😂 from Meredith Lamb
And stop worrying about me at all\.\.
Ok 3
Weeks
Ago your were probably worried I was going to ask you to marry you I was so in love now you are worried I am going to walk away\.  lol just throw me to the side for a while\.  I will be fine waiting until you are ready to pick us back up\.


---

### 352. msg_10545

**You** - 2025-05-13T05:09:30

In the meantime I will help however I can with what you are going through\.\. looks like my numbers so far have been pretty accurate\.


---

### 353. msg_10546

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:10:05

>
Stoooop\. “Throw you aside”


---

### 354. msg_10547

**You** - 2025-05-13T05:12:20

You know what I meant


---

### 355. msg_10548

**You** - 2025-05-13T05:12:25

And it wasn’t that


---

### 356. msg_10549

**You** - 2025-05-13T05:12:29

Figure of speech


---

### 357. msg_10550

**You** - 2025-05-13T05:12:47

I am not going anywhere so focus on you\.


---

### 358. msg_10551

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:14:36

I will just be a bit distracted and annoyed bc Andrew sends me dumb msgs constantly


---

### 359. msg_10552

**You** - 2025-05-13T05:14:53

Just ignore them


---

### 360. msg_10553

**You** - 2025-05-13T05:15:16

Or have a copy paste response at hand and repeat it


---

### 361. msg_10554

**You** - 2025-05-13T05:15:47

He will get the message\.\.  Andrew……\. Mediator \+ Lawyer = fuck off


---

### 362. msg_10555

**You** - 2025-05-13T05:15:57

Simple
Math


---

### 363. msg_10556

**You** - 2025-05-13T05:18:39

And


---

### 364. msg_10557

**You** - 2025-05-13T05:18:55

If he keeps shit talking you about being selfish or to the kids


---

### 365. msg_10558

**You** - 2025-05-13T05:19:25

Just say “text” I have it they will know\.\. again see previous statement and fuck off


---

### 366. msg_10559

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:20:17

I know, it is just constant and consistent\. I need to get out\.


---

### 367. msg_10560

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:20:20

That’s all


---

### 368. msg_10561

**You** - 2025-05-13T05:23:12

I get it I feel it I live in a basement lol for almost 6 months\.\. just…\. Compartmentalizations


---

### 369. msg_10562

**You** - 2025-05-13T05:23:31

U get it


---

### 370. msg_10563

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:24:03

Yeah, drags… on and on


---

### 371. msg_10564

**You** - 2025-05-13T05:24:19

Anything else I can do?


---

### 372. msg_10565

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:26:29

No I’m good ☺️ might try to go back to sleep soon


---

### 373. msg_10566

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:26:38

Just looking at rentals


---

### 374. msg_10567

**You** - 2025-05-13T05:27:04

Kk I am just getting to gym will chat later\.\. love you\.


---

### 375. msg_10568

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:27:20

Love u too


---

### 376. msg_10569

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:27:26

Have a good workout


---

### 377. msg_10570

**You** - 2025-05-13T05:27:37

Always\.\.


---

### 378. msg_10571

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T05:28:17

Oh he’s going to airport forgot 🥳


---

### 379. msg_10572

**You** - 2025-05-13T05:28:37

Oh nice you have some time to yourself this week\.\. perfect


---

### 380. msg_10573

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:33:41

I’m trying not to get my hopes up that Johnny is doing his proposal here but I hope he is lol


---

### 381. msg_10574

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:34:10

He’s going to Laurier on a football scholarship so I also want to congratulate him :\)


---

### 382. msg_10575

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:34:15

I’m not unusual at all


---

### 383. msg_10576

**You** - 2025-05-13T07:34:32

Yeah I saw that text last night and was like errr?


---

### 384. msg_10577

**You** - 2025-05-13T07:35:01

Kinda wish I was 6’7 now


---

### 385. msg_10578

**You** - 2025-05-13T07:35:04

lol


---

### 386. msg_10579

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:35:36

Reaction: ❤️ from Scott Hicks
It isn’t only that\. He is such a nice kid and talks and talks to me


---

### 387. msg_10580

**You** - 2025-05-13T07:35:39

And 18 again yeah that’d be good


---

### 388. msg_10581

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:36:45

When Mac was dating him his mom was on house arrest in France and he had a lot of issues\. I stepped in lol


---

### 389. msg_10582

**You** - 2025-05-13T07:37:17

I know you desperately wish she and him would get back together lol


---

### 390. msg_10583

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:37:28

His dad was so thankful and reached out to me


---

### 391. msg_10584

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:37:37

>
I knoooooooooow


---

### 392. msg_10585

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:37:41

Mackenzie knows\.


---

### 393. msg_10586

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:37:49

Maybe some day in like 5 years


---

### 394. msg_10587

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:37:53

You never know


---

### 395. msg_10588

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:37:55

Hahaha


---

### 396. msg_10589

**You** - 2025-05-13T07:39:51

Hey they could be soulmates


---

### 397. msg_10590

**You** - 2025-05-13T07:39:53

Who knows


---

### 398. msg_10591

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:41:03

One can hope … they do keep in touch and she doesn’t really with Gavin or Billy


---

### 399. msg_10592

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:41:08

So there is that


---

### 400. msg_10593

**You** - 2025-05-13T07:41:33

I think that building that base friendship and being open to what happens is best way


---

### 401. msg_10594

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:42:01

I just want to see his promposal lol


---

### 402. msg_10595

**You** - 2025-05-13T07:42:13

We never had those


---

### 403. msg_10596

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:42:25

I know\. New thing


---

### 404. msg_10597

**You** - 2025-05-13T07:43:13

You know it is gonna break your heart a bit right


---

### 405. msg_10598

**You** - 2025-05-13T07:43:28

❤️


---

### 406. msg_10599

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:43:57

Haha nah I will be ok


---

### 407. msg_10600

**You** - 2025-05-13T07:44:07

Sure call me after


---

### 408. msg_10601

**You** - 2025-05-13T07:44:12

lol


---

### 409. msg_10602

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:44:36

After he got his scholarship he said to Mackenzie, “did you tell your mom?”


---

### 410. msg_10603

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:44:39

lol


---

### 411. msg_10604

**You** - 2025-05-13T07:45:03

Well you got your son lol


---

### 412. msg_10605

**You** - 2025-05-13T07:45:09

Better later than never


---

### 413. msg_10606

**You** - 2025-05-13T07:45:17

🙂


---

### 414. msg_10607

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:46:18

Him and Arian\. On the weekend Mackenzie went to mayflower and saw Arian and told me that he misses me\. \(She doesn’t have parties anymore with guys so I don’t get to see them\.\)


---

### 415. msg_10608

**You** - 2025-05-13T07:46:26

It’s a relationship you can always follow now


---

### 416. msg_10609

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:46:44

Yeah but Mac won’t let me go to his football games


---

### 417. msg_10610

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:46:59

She might when he is in uni but won’t in high school


---

### 418. msg_10611

**You** - 2025-05-13T07:47:20

lol are cute


---

### 419. msg_10612

**You** - 2025-05-13T07:47:23

U


---

### 420. msg_10613

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:49:38

Are you going to tell damir or do I? Ugh


---

### 421. msg_10614

**You** - 2025-05-13T07:52:15

I will


---

### 422. msg_10615

**You** - 2025-05-13T07:52:31

It will come out I mgmt meeting today


---

### 423. msg_10616

**You** - 2025-05-13T07:53:12

I will damir the truth


---

### 424. msg_10617

**You** - 2025-05-13T07:53:29

In mgmt team it will be personal work life balance issue


---

### 425. msg_10618

**You** - 2025-05-13T07:53:31

S


---

### 426. msg_10619

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:53:41

Ok


---

### 427. msg_10620

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:54:16

So talked to Mac irl and apparently thur he is just coming over to make the poster … not do the actual promposal


---

### 428. msg_10621

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:54:18

That’s ok


---

### 429. msg_10622

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:54:33

So then when do I tell my team?


---

### 430. msg_10623

**You** - 2025-05-13T07:54:37

Ask him to use you as a stand in


---

### 431. msg_10624

**You** - 2025-05-13T07:54:40

lol


---

### 432. msg_10625

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:54:46

I’m concerned Carolyn is going to spill it


---

### 433. msg_10626

**You** - 2025-05-13T07:54:48

Reaction: 😂 from Meredith Lamb
Not weird at all


---

### 434. msg_10627

**You** - 2025-05-13T07:54:50

Rofl


---

### 435. msg_10628

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:55:09

I told her my team doesn’t know and then she still was kinda loud yday


---

### 436. msg_10629

**You** - 2025-05-13T07:55:29

Tell your team today\.\. I think


---

### 437. msg_10630

**You** - 2025-05-13T07:55:44

Can’t wait now


---

### 438. msg_10631

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:58:57

I shouldn’t have told her but she was wondering what the heck was going on yesterday


---

### 439. msg_10632

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T07:59:39

It’s almost shocking how nosy she is lol


---

### 440. msg_10633

**You** - 2025-05-13T08:00:55

I know it is something she needs to work on next level up she will get slapped down\.


---

### 441. msg_10634

**You** - 2025-05-13T08:01:26

Just walking into work will be off for a min\.


---

### 442. msg_10635

**You** - 2025-05-13T08:07:32

We should also sit and talk transition some time today\.\. there are a few things I would appreciate if you could focus on specifically and some things I am going to take off your plate\.


---

### 443. msg_10636

**You** - 2025-05-13T08:07:43

If you have time I haven’t checked your calendar


---

### 444. msg_10637

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T08:16:00

>
I assumed I would just stay until you hire


---

### 445. msg_10638

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T08:16:08

I’m running late today


---

### 446. msg_10639

**You** - 2025-05-13T08:16:57

Well yeah but I need to start getting on top of specific things so I can be aware and bring in whoever is next plus I was hoping you might focus on something specific for me\.


---

### 447. msg_10640

**You** - 2025-05-13T08:17:05

Don’t worry no need to rush\.


---

### 448. msg_10641

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T08:17:32

Won’t be in until 8\.30


---

### 449. msg_10642

**You** - 2025-05-13T08:17:40

Kk


---

### 450. msg_10643

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T08:23:11

Forget that\. Stuck behind an accident\.


---

### 451. msg_10644

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T08:23:29

On avenue road\. Never happens


---

### 452. msg_10645

**You** - 2025-05-13T08:23:38

Kk again don’t rush you get here when you get here


---

### 453. msg_10646

**You** - 2025-05-13T08:23:48

Or stress


---

### 454. msg_10647

**You** - 2025-05-13T10:28:38

Btw j was about to come up here to my office and I had to head her off and mer her downstairs will chat later about it\.


---

### 455. msg_10648

**You** - 2025-05-13T13:22:38

So it was never raised in meeting but dev was made aware by Daniel prior


---

### 456. msg_10649

**You** - 2025-05-13T13:22:43

Hope your day is going ok


---

### 457. msg_10650

**You** - 2025-05-13T13:23:03



---

### 458. msg_10651

**You** - 2025-05-13T13:23:14



---

### 459. msg_10652

**You** - 2025-05-13T13:23:22



---

### 460. msg_10653

**You** - 2025-05-13T13:23:29



---

### 461. msg_10654

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T14:53:50

Okaaaaaaaaay


---

### 462. msg_10655

**You** - 2025-05-13T15:09:06

I found a place for someday when you want to have a break have a chat whatever\.\.  I forgot I found it last week\.\. you can file it away\.


---

### 463. msg_10656

**You** - 2025-05-13T15:31:47

Sry disregard\.\.


---

### 464. msg_10657

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T16:11:11

Ps\. Told the team\. They were OK\. Ahana a little shell shocked but she’ll be fine\.


---

### 465. msg_10658

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T17:16:03

I’m going to head out\. Ugh started on Jacky’s 101\. Will finish later tonight\. It is awful\. Love your nope, nope, nope, nope, nope\. lol


---

### 466. msg_10659

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T17:16:14

Are you ok?


---

### 467. msg_10660

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:07:14

⏳


---

### 468. msg_10661

**You** - 2025-05-13T18:16:23

Hey


---

### 469. msg_10662

**You** - 2025-05-13T18:16:59

Hope the drive home was less eventful than the drive in


---

### 470. msg_10663

**You** - 2025-05-13T18:17:02

Brb


---

### 471. msg_10664

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:17:16

Was fine\. Everything alright?


---

### 472. msg_10665

**You** - 2025-05-13T18:19:25

Yep


---

### 473. msg_10666

**You** - 2025-05-13T18:19:45

Just puttering around in comp


---

### 474. msg_10667

**You** - 2025-05-13T18:19:52

Not much going on


---

### 475. msg_10668

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:23:12

Oh I thought maybe something was wrong lol


---

### 476. msg_10669

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:23:18

Just taking Maelle to vball


---

### 477. msg_10670

**You** - 2025-05-13T18:23:29

Kk have fun


---

### 478. msg_10671

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:40:57

Something is wrong with you


---

### 479. msg_10672

**You** - 2025-05-13T18:41:30

I just had a bad day made a few mistakes pissed at self\.\. that is all\.


---

### 480. msg_10673

**You** - 2025-05-13T18:45:40

Listen you got your own shit\.\. just keep your focus there pls\.\. that would make me happier


---

### 481. msg_10674

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:47:51

You made a few mistakes at work or with the fam?


---

### 482. msg_10675

**You** - 2025-05-13T18:48:22

……\.


---

### 483. msg_10676

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:48:43

>
Nope, nope, nope, nope\.


---

### 484. msg_10677

**You** - 2025-05-13T18:49:00

>
Access denied\.


---

### 485. msg_10678

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T18:55:43

I don’t know why you think we can’t even talk anymore\.


---

### 486. msg_10679

**You** - 2025-05-13T18:58:25

That doesn’t work and you know that isn’t true anyways\.  You got stuff going on you are busy\.  You have things to think about hundreds of then, plans to make, data to get,
Events etc\.\. again this boils down to me getting my own separate life\. There isn’t much to discuss because it isn’t your problem, and it isn’t your fault\.


---

### 487. msg_10680

**You** - 2025-05-13T19:00:00

Like in my minds eye you got like 5
Convos going on at any given time\.\. I feel like I need something like that to keep my mind occupied\. Thinking about a couple of things\.


---

### 488. msg_10681

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:02:02

I have one conversation going right now


---

### 489. msg_10682

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:02:12

And Jacky’s 101 doc :p


---

### 490. msg_10683

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:02:25

I’m not as frantic as you think I am


---

### 491. msg_10684

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:05:04

I want to talk to you, if I didn’t I wouldn’t be messaging you


---

### 492. msg_10685

**You** - 2025-05-13T19:05:32

Ok what would you like to talk about other than this?


---

### 493. msg_10686

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:05:44

lol omg


---

### 494. msg_10687

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:05:58

Impossible mood I see


---

### 495. msg_10688

**You** - 2025-05-13T19:06:59

Listen when you have a bad night or are in a bad mood you shut down and go to bed and I don’t say anything other than to support you\.


---

### 496. msg_10689

**You** - 2025-05-13T19:07:47

When I have moments where I am unhappy with myself, disgusted or whatever\.\. it isn’t always best


---

### 497. msg_10690

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:07:50

But that is not what you need


---

### 498. msg_10691

**You** - 2025-05-13T19:07:52

To share


---

### 499. msg_10692

**You** - 2025-05-13T19:08:04

I am fine


---

### 500. msg_10693

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:08:08

Your style isn’t to shut down


---

### 501. msg_10694

**You** - 2025-05-13T19:08:14

Well it has to be


---

### 502. msg_10695

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:08:19

Sigh


---

### 503. msg_10696

**You** - 2025-05-13T19:08:20

For a while at least


---

### 504. msg_10697

**You** - 2025-05-13T19:08:39

I have my journal I am writing to virtual you in there


---

### 505. msg_10698

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:09:01

But I am literally right here


---

### 506. msg_10699

**You** - 2025-05-13T19:10:28

Yeah I know but this journal is for things I don’t want to say to you\. Not because they are mean but because they are about insecurities a bit too intense\.\. again you have them and I leave you be\.\. so you will have to let me have mine and figure out how to deal\.


---

### 507. msg_10700

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:11:20

New Scott …\. 😒


---

### 508. msg_10701

**You** - 2025-05-13T19:11:43

Feels nice…


---

### 509. msg_10702

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:12:36

Listen, I think we are both going to go through stages… intense, boring, or otherwise\. It doesn’t mean that is ALL the time\. Just because I’m overwhelmed one day I might not be the next


---

### 510. msg_10703

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:12:48

That should be allowed


---

### 511. msg_10704

**You** - 2025-05-13T19:13:45

Sure and should the same apply to me\.  Let’s call this one of my overwhelmed days\.


---

### 512. msg_10705

**You** - 2025-05-13T19:13:51

Totally allowed


---

### 513. msg_10706

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:15:45

Okay you win


---

### 514. msg_10707

**You** - 2025-05-13T19:19:38

Fack mer\.\. I told you I was gone give you space and I went and forgot and sent those stupid maps\.\. made me feel like a moron\.\. then just made me feel worse\.\. see it is dumb\.  I have my up days where I am like yeah this is great shit is moving forward and then the next day it could be fuck this is going to take forever and I will continue to be as lonely as fuck in this shitty household\.\. I cam home I wanted to do work to get cleaning couldn’t get anyone to do anything\.  I secured the home inspector,
Scheduled it, paid him and am now reviewing the report because if I don’t no one will and it will push things back further\.  I really feel all on my own here in so many ways\.\.  so this is why is say there is nothing you can do, you have your own shit, and this will have to wait\.


---

### 515. msg_10708

**You** - 2025-05-13T19:19:52

So you win\.\. you always do 😔


---

### 516. msg_10709

**You** - 2025-05-13T19:20:14

But I am not telling you about my journal ever\.


---

### 517. msg_10710

**You** - 2025-05-13T19:21:01

I don’t think anyone needs to know someone else’s thoughts THAT intimately


---

### 518. msg_10711

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:21:33

So wait, your mistake was the map photos?


---

### 519. msg_10712

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:21:51

You know that didn’t bother me at all right?


---

### 520. msg_10713

**You** - 2025-05-13T19:22:03

It bothers me\.


---

### 521. msg_10714

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:22:25

Scott, I know everything you do has the purest of intentions\. You do not need to feel bothered


---

### 522. msg_10715

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:23:00

And I am equally worried about the timeline of all this\. I actually talked about it to my therapist today


---

### 523. msg_10716

**You** - 2025-05-13T19:23:56

Yeah because I am causing problems


---

### 524. msg_10717

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:24:11

The mediator warned me that we will be talking about introducing partners/ rules etc so I asked my therapist if that is a “thing” in separation agreements


---

### 525. msg_10718

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:24:28

She warned me to not agree to anything I’m not comfortable with…


---

### 526. msg_10719

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:24:58

She thinks Andrew is including as another way to control what I do


---

### 527. msg_10720

**You** - 2025-05-13T19:24:59

Look I should just back way off until this is all done\.\. I don’t want to cause you any problems last thing I would wanst


---

### 528. msg_10721

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:25:28

Stop\. No


---

### 529. msg_10722

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:25:37

We have come this far


---

### 530. msg_10723

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:25:39

lol


---

### 531. msg_10724

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:26:55

I told my therapist that when I have a signed separation agreement I don’t care who in my family knows about this\. It will be more on your side


---

### 532. msg_10725

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:27:20

I mean I won’t force my kids to hang with you or meet you but I honestly won’t care if they know at that point


---

### 533. msg_10726

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:27:29

Your situation will be very different


---

### 534. msg_10727

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:28:32

If we have to wait 2 year on your side so be it but that won’t be the case on mine\.


---

### 535. msg_10728

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:28:49

There is no reason you cannot be a part of my life before then\. Much before


---

### 536. msg_10729

**You** - 2025-05-13T19:28:47

September 11th


---

### 537. msg_10730

**You** - 2025-05-13T19:29:12

That is when I am going to tell Maddie\.\. unless J is still here\.


---

### 538. msg_10731

**You** - 2025-05-13T19:29:20

because that is now the new thing\.\.


---

### 539. msg_10732

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:29:32

Huh??


---

### 540. msg_10733

**You** - 2025-05-13T19:29:34

Maybe stay until Sept 15 for Maddie's birthday


---

### 541. msg_10734

**You** - 2025-05-13T19:29:39

I said FUCK NO


---

### 542. msg_10735

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:29:45

Ohhh


---

### 543. msg_10736

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:29:48

Wow


---

### 544. msg_10737

**You** - 2025-05-13T19:29:45

I cannot get this house ready to sell


---

### 545. msg_10738

**You** - 2025-05-13T19:29:47

with them here


---

### 546. msg_10739

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:30:09

Oh yikes


---

### 547. msg_10740

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:30:21

Can’t they come back for her bday?


---

### 548. msg_10741

**You** - 2025-05-13T19:30:48

I am pushing for this somehow\. I don't know what to do\.  Just trying to figure it out\.


---

### 549. msg_10742

**You** - 2025-05-13T19:31:01

again I am trying to take care of everything so they will leave


---

### 550. msg_10743

**You** - 2025-05-13T19:32:06

What week are you doing Mac's bday


---

### 551. msg_10744

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:32:22

I mean you can’t make them leave so you just have to do what you can and hope


---

### 552. msg_10745

**You** - 2025-05-13T19:32:25

cause I might just fuck off that whole week\.\. and try to get some work done around here\.


---

### 553. msg_10746

**You** - 2025-05-13T19:32:27

ok\.\.


---

### 554. msg_10747

**You** - 2025-05-13T19:32:31

here is one excerpt


---

### 555. msg_10748

**You** - 2025-05-13T19:32:35

since you said the H word


---

### 556. msg_10749

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:32:49

May 29/30/31/june1


---

### 557. msg_10750

**You** - 2025-05-13T19:34:44

copied it weird\.\. but this is the stuff that goes on in my head\.\. so  just\.\.\. grain of salt or something\.

*1 attachment(s)*


---

### 558. msg_10751

**You** - 2025-05-13T19:35:17

>
well maybe I will just take the whole week off\.


---

### 559. msg_10752

**You** - 2025-05-13T19:37:40

listen it is just a shit situation and it sets my brain off\.\. just ignore all of this crap\.


---

### 560. msg_10753

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:39:14

>
I have this fear also\. While I have experienced happiness before, not like this Scott\. Not sure if it is age, don’t think so, I just genuinely believe it is you\. I think people can find happiness but all the boxes may not be checked\. I feel like they are with you and that is certainly something I can’t say I’ve experienced before so it is very different that way\. I don’t think you are going to screw anything up\. \(Unless you stop talking to me 😒\)


---

### 561. msg_10754

**You** - 2025-05-13T19:43:08

>
I mean I obviously feel the same\.\. in every way\.\. just gonna leave it at that\.\. because that is really all that matters\.


---

### 562. msg_10755

**You** - 2025-05-13T19:44:38

I am not going to stop talking but it is hard mer\.\. expressing emotion and not being able to show it, not the same\.\. kind of painful\.\.  ian saved my office but I kind of wish he'd let them move me now


---

### 563. msg_10756

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:45:01

Wha? Why?


---

### 564. msg_10757

**You** - 2025-05-13T19:45:18

I don't know out of sight\.\. maybe out of mind\.\. for a little while\.


---

### 565. msg_10758

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:45:25

Where will Daniel be?


---

### 566. msg_10759

**You** - 2025-05-13T19:45:30

I don't think he moves


---

### 567. msg_10760

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:45:48

So then won’t I move over to him somewhere??


---

### 568. msg_10761

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:46:03

That would be kind of out of sight


---

### 569. msg_10762

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:46:06

lol


---

### 570. msg_10763

**You** - 2025-05-13T19:46:02

Sure but not quite the same as me being over in Priyanka's office


---

### 571. msg_10764

**You** - 2025-05-13T19:46:23

maybe i can still tell him to move me


---

### 572. msg_10765

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:46:36

No the team would hate that


---

### 573. msg_10766

**You** - 2025-05-13T19:46:43

the team will be fine\. they don't care where I sit


---

### 574. msg_10767

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:46:59

Ok 😜


---

### 575. msg_10768

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:47:03

Yes they would


---

### 576. msg_10769

**You** - 2025-05-13T19:47:17

besides it would get me away from Cote\.\. she is always looking at me\.\. she says she wants Happy Scott back\.\. I am like WTF\.\.\.


---

### 577. msg_10770

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:47:33

She told me that tonight


---

### 578. msg_10771

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:47:44

She was very bothered by you having a bad day


---

### 579. msg_10772

**You** - 2025-05-13T19:47:55

She knows there is more going on with me personally\.\. I am sure of it\.


---

### 580. msg_10773

**You** - 2025-05-13T19:48:01

She still doesn't know about us\.\.


---

### 581. msg_10774

**You** - 2025-05-13T19:48:14

probably thinks I am distraught at you leaving for one


---

### 582. msg_10775

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:48:27

Yeah I think so


---

### 583. msg_10776

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:48:44

She probably not the only one


---

### 584. msg_10777

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:48:46

lol


---

### 585. msg_10778

**You** - 2025-05-13T19:48:54

Carolyn??


---

### 586. msg_10779

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:49:07

Just everyone I think


---

### 587. msg_10780

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:49:18

I talked to Craig tonight


---

### 588. msg_10781

**You** - 2025-05-13T19:49:23

Well I don't know why I am my typical happy self\.


---

### 589. msg_10782

**You** - 2025-05-13T19:49:37

almost ripped octavian a new one


---

### 590. msg_10783

**You** - 2025-05-13T19:49:41

I mean that is so like me\!


---

### 591. msg_10784

**You** - 2025-05-13T19:49:51

fuck


---

### 592. msg_10785

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:49:58

lol poor Octo


---

### 593. msg_10786

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:03

I loved his reaction


---

### 594. msg_10787

**You** - 2025-05-13T19:50:04

He got ran over


---

### 595. msg_10788

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:14

Did you see Whitney’s face


---

### 596. msg_10789

**You** - 2025-05-13T19:50:11

I will apologize tomorrow


---

### 597. msg_10790

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:16

LOL


---

### 598. msg_10791

**You** - 2025-05-13T19:50:18

I did not


---

### 599. msg_10792

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:28

she was a tad surprised


---

### 600. msg_10793

**You** - 2025-05-13T19:50:25

had she not seen angry scott before


---

### 601. msg_10794

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:40

I dunno but she legit looked scared lol


---

### 602. msg_10795

**You** - 2025-05-13T19:50:43

:\(


---

### 603. msg_10796

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:54

Oh she was fine


---

### 604. msg_10797

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:50:58

Just funny


---

### 605. msg_10798

**You** - 2025-05-13T19:51:08

I need to find a reason to ask Ian if I can just work from home for the next 6 months


---

### 606. msg_10799

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:51:27

Whitney was not thrilled to hear about bro


---

### 607. msg_10800

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:51:30

Bro


---

### 608. msg_10801

**You** - 2025-05-13T19:51:33

Bri


---

### 609. msg_10802

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:51:37

Bri\!


---

### 610. msg_10803

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:51:51

She was the only one with a really negative reaction


---

### 611. msg_10804

**You** - 2025-05-13T19:51:54

yeah I figured\.\.  but hey I will hire her then work from home\.\. she will love that even more\.


---

### 612. msg_10805

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:51:59

Everyone else seemed fine


---

### 613. msg_10806

**You** - 2025-05-13T19:52:13

I think I can use the separation thing\.\. Ian is pretty empathetic to me\.


---

### 614. msg_10807

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:52:19

Ahana was shell shocked and sad\. I felt bad\. But feel fine now\. lol


---

### 615. msg_10808

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:52:31

Just take a vacation


---

### 616. msg_10809

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:52:34

Then come back


---

### 617. msg_10810

**You** - 2025-05-13T19:52:36

no its not good enough


---

### 618. msg_10811

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:52:48

Really?


---

### 619. msg_10812

**You** - 2025-05-13T19:52:48

yeah really


---

### 620. msg_10813

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:53:11

What if we plan something together to look forward to?


---

### 621. msg_10814

**You** - 2025-05-13T19:53:25

Nope\.\. no more plans\.


---

### 622. msg_10815

**You** - 2025-05-13T19:53:38

Nope Nope Nope Nope\.\.


---

### 623. msg_10816

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:54:17

lol stop


---

### 624. msg_10817

**You** - 2025-05-13T19:54:59

not until after you have signed\.


---

### 625. msg_10818

**You** - 2025-05-13T19:55:02

not joking


---

### 626. msg_10819

**You** - 2025-05-13T19:55:32

not putting you at risk\.\. and being around you without being able to be with you is rough\.\. thus the work from home\.\. maybe just an extra day a week or something\.


---

### 627. msg_10820

**You** - 2025-05-13T19:55:59

honestly if I could black out my windows I would\.\. that would help too\.\. lol


---

### 628. msg_10821

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T19:56:09

Omg I won’t be signed for like 3\-4 weeks realistically


---

### 629. msg_10822

**You** - 2025-05-13T19:56:53

Well let's settle in for super fun time\.\. it won't matter look\.\. this weekend busy, next weekend\.\. likely busy, weekend after Mac's party\.\. there is three weeks already\.


---

### 630. msg_10823

**You** - 2025-05-13T19:57:15

And it won't be 3 or 4


---

### 631. msg_10824

**You** - 2025-05-13T19:57:18

it will be 5 or 6


---

### 632. msg_10825

**You** - 2025-05-13T19:57:42

because you will need to see a lawyer\.\. and that will add 1\-3 more weeks depending on if he gets a lawyer as well\.


---

### 633. msg_10826

**You** - 2025-05-13T19:57:54

Reaction: 😮 from Meredith Lamb
so we actually looking at more like 9\-10 weeks


---

### 634. msg_10827

**You** - 2025-05-13T19:59:20

yeah\.\. true story\.


---

### 635. msg_10828

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:00:23

Well then we won’t be waiting until then\. Good lord


---

### 636. msg_10829

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:00:30

Smarten up


---

### 637. msg_10830

**You** - 2025-05-13T20:00:44

I just don't see how this will work\.\. other than to suffer through it\.


---

### 638. msg_10831

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:01:14

Whoah whoah whoah how “this” will work?


---

### 639. msg_10832

**You** - 2025-05-13T20:01:20

https://www\.google\.com/maps/place/Terraview\+Park/@43\.7662613,\-79\.311827,3a,75y,90t/data=\!3m8\!1e2\!3m6\!1sCIHM0ogKEICAgIDWkp\-3YA\!2e10\!3e12\!6shttps:%2F%2Flh3\.googleusercontent\.com%2Fgps\-cs\-s%2FAC9h4no9MJD\_soZvdasvGIMYQF151d\_u\-V8PaMZEWw3NRCao4SDywly19h\_vDGH\_40kQk\_xH\_tMLDY\-gfIGK9SCx4sCttlAARaSgAbwzUkNyNLZjfP1TgjjLmqvePCc2G7s0yHh33lxK%3Dw114\-h86\-k\-no\!7i4608\!8i3456\!4m7\!3m6\!1s0x89d4d23fe5c0fa99:0x31b09bbf46619220\!8m2\!3d43\.7662613\!4d\-79\.311827\!10e5\!16s%2Fg%2F1tzgq5\_8?entry=ttu&g\_ep=EgoyMDI1MDUxMS4wIKXMDSoASAFQAw%3D%3D


---

### 640. msg_10833

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:01:24

k I have never talked like this


---

### 641. msg_10834

**You** - 2025-05-13T20:01:53

I didn't say how it will work and then stop m sentence mer


---

### 642. msg_10835

**You** - 2025-05-13T20:01:56

comon


---

### 643. msg_10836

**You** - 2025-05-13T20:02:14

https://www\.google\.com/maps/place/Terraview\+Park/@43\.7653644,\-79\.3105611,3a,75y,341\.12h,82\.74t/data=\!3m7\!1e1\!3m5\!1sgo59BZZ95\-hL8bufyG5\_jA\!2e0\!6shttps:%2F%2Fstreetviewpixels\-pa\.googleapis\.com%2Fv1%2Fthumbnail%3Fcb\_client%3Dmaps\_sv\.tactile%26w%3D900%26h%3D600%26pitch%3D7\.264896275081128%26panoid%3Dgo59BZZ95\-hL8bufyG5\_jA%26yaw%3D341\.12178145501485\!7i16384\!8i8192\!4m6\!3m5\!1s0x89d4d23fe5c0fa99:0x31b09bbf46619220\!8m2\!3d43\.7662613\!4d\-79\.311827\!16s%2Fg%2F1tzgq5\_8?entry=ttu&g\_ep=EgoyMDI1MDUxMS4wIKXMDSoASAFQAw%3D%3D


---

### 644. msg_10837

**You** - 2025-05-13T20:02:39

https://www\.google\.com/maps/@43\.7665684,\-79\.3105177,17\.25z?entry=ttu&g\_ep=EgoyMDI1MDUxMS4wIKXMDSoASAFQAw%3D%3D


---

### 645. msg_10838

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:02:44

My Google maps doesn’t work for some reason I have to use Waze lol


---

### 646. msg_10839

**You** - 2025-05-13T20:03:24

https://www\.waze\.com/live\-map?utm\_source=waze\_website&utm\_campaign=waze\_website&utm\_medium=website\_menu


---

### 647. msg_10840

**You** - 2025-05-13T20:03:31

waze won't work for this I think


---

### 648. msg_10841

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:03:35

So question for you… what would you like to happen?


---

### 649. msg_10842

**You** - 2025-05-13T20:03:54

when now, thursday, next week, 5 years out?


---

### 650. msg_10843

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:04:01

>
Then just an address or screenshot


---

### 651. msg_10844

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:04:07

Like the ones you deleted


---

### 652. msg_10845

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:04:09

lol


---

### 653. msg_10846

**You** - 2025-05-13T20:04:33

I’m taking you for a coffee at our Thursday one on one with my shiny Starbucks gift card and you are going to tell me what I can do to prevent you from  hitting a tipping point\. I don’t need to know what’s going on, just want to help where I can\.


---

### 654. msg_10847

**You** - 2025-05-13T20:04:40

courtesy of CM


---

### 655. msg_10848

**You** - 2025-05-13T20:04:44

just now :/


---

### 656. msg_10849

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:05:46

Just now?


---

### 657. msg_10850

**You** - 2025-05-13T20:05:44

gawddddddd


---

### 658. msg_10851

**You** - 2025-05-13T20:05:45

yes


---

### 659. msg_10852

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:06:06

CM sent you a Starbucks card right now


---

### 660. msg_10853

**You** - 2025-05-13T20:06:31

no she has one and she wants me to go to starbucks with her at lunch on thursday\.\.\. because she wants to fix me\.\. because I told her today I was fucking off from this job\.


---

### 661. msg_10854

**You** - 2025-05-13T20:06:37

I was joking clearly\.


---

### 662. msg_10855

**You** - 2025-05-13T20:06:45

but maybe she didn't find it funny


---

### 663. msg_10856

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:00

Guess not\!


---

### 664. msg_10857

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:07

She is always worried about you


---

### 665. msg_10858

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:19

I’m glad she isn’t going through a separation 😝


---

### 666. msg_10859

**You** - 2025-05-13T20:07:26

wow\.


---

### 667. msg_10860

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:38

Sorry


---

### 668. msg_10861

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:39

lol


---

### 669. msg_10862

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:47

Kinda funny


---

### 670. msg_10863

**You** - 2025-05-13T20:07:44

do you honestly think Carolyn M is my type\.


---

### 671. msg_10864

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:54

No


---

### 672. msg_10865

**You** - 2025-05-13T20:07:53

jesus


---

### 673. msg_10866

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:07:58

But it was kind of funny


---

### 674. msg_10867

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:08:09

Sorry


---

### 675. msg_10868

**You** - 2025-05-13T20:08:15

no I get you finding it funny\.\. lol


---

### 676. msg_10869

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:08:25

I’m not sure you have a type


---

### 677. msg_10870

**You** - 2025-05-13T20:08:30

I thought I did\.


---

### 678. msg_10871

**You** - 2025-05-13T20:08:45

Do you want to know how many blondes I have gone out with?


---

### 679. msg_10872

**You** - 2025-05-13T20:10:47

Let's just say in addition to being my soulmate\.\. you are the only blonde I have ever been serious about \- I might have had a date with one once or twice\.\. but almost always dark haired or red heads, almost all short\.  You are my type\.


---

### 680. msg_10873

**You** - 2025-05-13T20:15:53

So I mean it is what it is\.\. you are it\.\. deal with it\.


---

### 681. msg_10874

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:15:57

Sorry did a 🏐 pick up


---

### 682. msg_10875

**You** - 2025-05-13T20:16:29

I mean I listened to the sailor song \- if that doesn't come across then I clearly have a communication problem\.


---

### 683. msg_10876

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:16:34

I hope you are right but it’s ok if you don’t have a type lol


---

### 684. msg_10877

**You** - 2025-05-13T20:17:14

>
you have zero reason to be even a tiny bit insecure\.


---

### 685. msg_10878

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:17:54

I’m not “insecure” per se


---

### 686. msg_10879

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:18:02

😇


---

### 687. msg_10880

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:18:05

lol


---

### 688. msg_10881

**You** - 2025-05-13T20:18:11

reserved, withdrawn, cautious, tentative, unsure\.


---

### 689. msg_10882

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:18:33

A regular thesaurus


---

### 690. msg_10883

**You** - 2025-05-13T20:18:36

any of those words work better


---

### 691. msg_10884

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:18:58

You are definitely my type 🤓


---

### 692. msg_10885

**You** - 2025-05-13T20:19:23

I mean just words\.\.


---

### 693. msg_10886

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:20:45

To you\.\.


---

### 694. msg_10887

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:21:46

Aren’t you feeling a bit better that we got the work thing sorted tho?


---

### 695. msg_10888

**You** - 2025-05-13T20:22:18

well shit less foreplay more talking I guess?  Yeah\.\. honestly\.\. I am but again it is the seeing you\.\. like meh\.\. one sec


---

### 696. msg_10889

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:23:25

You could read me some articles\.


---

### 697. msg_10890

**You** - 2025-05-13T20:24:38

I mean if it is more effective\.\. i am up for anything\.


---

### 698. msg_10891

**You** - 2025-05-13T20:24:41

brb


---

### 699. msg_10892

**You** - 2025-05-13T20:31:08

Sophear Net is also in town and wants me to come into the office on Friday for a visit\.\. I laughed at her\.\.


---

### 700. msg_10893

**You** - 2025-05-13T20:31:36

Sorry I had to give the home inspection to Jaimie and explain it to her'


---

### 701. msg_10894

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:32:28

>
I mean you were going in last week on wfh days


---

### 702. msg_10895

**You** - 2025-05-13T20:32:41

yeah but she is a "girl"


---

### 703. msg_10896

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:32:49

lol


---

### 704. msg_10897

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:33:06

Who seems to like to get together with you


---

### 705. msg_10898

**You** - 2025-05-13T20:33:24

separation?


---

### 706. msg_10899

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:33:28

I mean just saying


---

### 707. msg_10900

**You** - 2025-05-13T20:33:30

that was for earlier\.


---

### 708. msg_10901

**You** - 2025-05-13T20:33:35

clearly a jk


---

### 709. msg_10902

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:33:44

lol


---

### 710. msg_10903

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:35:06

Sometimes I’m glad you don’t give yourself enough credit\. Not all the time but sometimes\. Lol


---

### 711. msg_10904

**You** - 2025-05-13T20:36:42

I am still at a loss Mer\.\. sorry\.\.  I think I kind of always will be\.\.  the bullshit and poses and stuff\.\. that isn't ego\.\. that is just for you\.  I hope you get that\.\. lol\.


---

### 712. msg_10905

**You** - 2025-05-13T20:37:17

I sent those links to your teams\.\. you can see it on your comp


---

### 713. msg_10906

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:40:18

Poses?


---

### 714. msg_10907

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:40:25

Oh gym?


---

### 715. msg_10908

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:40:27

lol


---

### 716. msg_10909

**You** - 2025-05-13T20:40:24

the bullshit pic


---

### 717. msg_10910

**You** - 2025-05-13T20:40:26

s


---

### 718. msg_10911

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:40:58

Yes I get it :\)


---

### 719. msg_10912

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:41:19

I know it isn’t your thing


---

### 720. msg_10913

**You** - 2025-05-13T20:41:31

not a bit


---

### 721. msg_10914

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:43:20

I do think once we aren’t working together as much it might get easier\. Just give it a bit of time


---

### 722. msg_10915

**You** - 2025-05-13T20:43:54

it wont then i wont have a reason to see you ever\.\. sorry mer I am not optimistic on this one\.


---

### 723. msg_10916

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:44:35

We are working toward being together outside of work\. This is part of the roadmap


---

### 724. msg_10917

**You** - 2025-05-13T20:44:46

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


---

### 725. msg_10918

**You** - 2025-05-13T20:44:50

brb


---

### 726. msg_10919

**You** - 2025-05-13T20:45:04

roadmap\.\. lol


---

### 727. msg_10920

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:45:10

It does equal not seeing each other ever\. It equals progress toward the opposite


---

### 728. msg_10921

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:45:32

Do you want me to make a roadmap for you


---

### 729. msg_10922

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:45:33

lol


---

### 730. msg_10923

**You** - 2025-05-13T20:45:52

or a mind map, a word find,


---

### 731. msg_10924

**You** - 2025-05-13T20:46:00

something like that?


---

### 732. msg_10925

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:47:32

Nooo


---

### 733. msg_10926

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:48:25

Here you go: Here’s a realistic and emotionally attuned four\-phase roadmap to guide you through this time:
⸻
Phase 1: Stabilize the Present \(Now – 2 months\)
Goal: Minimize emotional burnout while staying close and grounded in reality\.
•	Keep affirming each other: Let the love be a steady presence through messages, short check\-ins, quiet reminders\. This helps reduce the emotional friction of “being close but not allowed to be\.”
•	Avoid secretiveness, not privacy: Find quiet, low\-stakes ways to connect—like early morning walks, voice notes, or even journaling to each other—without risking family dynamics\.
•	Create emotional safety: Acknowledge the ache, but don’t pressure each other for “next steps\.” Just hold the space\.
⸻
Phase 2: Clarify Intentions and Timeframes \(2–4 months\)
Goal: Begin aligning timelines and expectations around separation, cohabitation, and eventual freedom to be together openly\.
•	Privately discuss your respective timelines: When do you each think you’ll be living s\.\.\. \[truncated\]


---

### 734. msg_10927

**You** - 2025-05-13T20:50:28

I gave you your own map on your laptop\.  Mine doesn't have a fancy name


---

### 735. msg_10928

**You** - 2025-05-13T20:51:23

ROFL  see it agrees with me\.\. 2 MONTHS\.\. we need to "hold the space mer"  no plans\.\. your road map said so\.


---

### 736. msg_10929

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:51:46

I noted that actually lol


---

### 737. msg_10930

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T20:52:07

>
Terraview Park?


---

### 738. msg_10931

**You** - 2025-05-13T20:52:18

yeah I looked at pretty much every park around


---

### 739. msg_10932

**You** - 2025-05-13T20:55:14

it seems quiet secluded trees\.\. nice walk\.\. I dunno\.\. anything we do is going to be a risk though\.\. while my heart wants this\.\. I still don't want you to get hurt or anything\.


---

### 740. msg_10933

**You** - 2025-05-13T20:58:05

Oh I got a gift today\.


---

### 741. msg_10934

**You** - 2025-05-13T20:58:40

Reaction: 🤔 from Meredith Lamb
Apparently Jennifer Pearson overheard me talking to Dana about liking tequila rose\.\. and she got a bottle for a gift, and now I have a bottle as a gift :\)


---

### 742. msg_10935

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:01:56

Sorry math help


---

### 743. msg_10936

**You** - 2025-05-13T21:02:15

anyways not sure what to do or where to go, I KNOW you aren't comfortable\.\. and you can handle this stuff\.\. so we shouldn't do it\.\. or the plans\.\. not until you get your signed agreement\.\.


---

### 744. msg_10937

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:02:46

>
Wha? Lol this is so odd Scott


---

### 745. msg_10938

**You** - 2025-05-13T21:03:21

never happened to me in forever\.\. so it was weird to see her in passing\.\. I almost never talk to her\.\. just odd\.


---

### 746. msg_10939

**You** - 2025-05-13T21:03:31

but I will drink it


---

### 747. msg_10940

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:08:05

So like no explanation?


---

### 748. msg_10941

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:08:13

I’m sorry, I cannot


---

### 749. msg_10942

**You** - 2025-05-13T21:09:16

?? no literally \- hey were you the one that I heard liked tequilla rose\.\. I said sure I like it\.\. she said she heard me talking to Dana about it a while ago\.\. got one for a gift but always forgot to bring it in\.\. but she had it today and she ran into me\.


---

### 750. msg_10943

**You** - 2025-05-13T21:09:36

Married happily 2 kids\.\. stop it\.


---

### 751. msg_10944

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:11:05

k still weird


---

### 752. msg_10945

**You** - 2025-05-13T21:12:00

whatever I will share


---

### 753. msg_10946

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:12:04

It’s fine if it is a one time thing\. This woman kept giving Andrew gifts at work once and he thought it was normal\. I was like you are delusional… then the whole thing eventually exploded


---

### 754. msg_10947

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:12:18

Omg I can’t handle tequila rose anymore


---

### 755. msg_10948

**You** - 2025-05-13T21:12:20

kk no one else gives me gifts\.\.


---

### 756. msg_10949

**You** - 2025-05-13T21:12:23

except coffee


---

### 757. msg_10950

**You** - 2025-05-13T21:12:25

and that is CM


---

### 758. msg_10951

**You** - 2025-05-13T21:12:29

and you sit beside her


---

### 759. msg_10952

**You** - 2025-05-13T21:13:46

81 Valley Woods Rd


---

### 760. msg_10953

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:14:29

Address of…\.\.?


---

### 761. msg_10954

**You** - 2025-05-13T21:14:35

BrookBanks Park


---

### 762. msg_10955

**You** - 2025-05-13T21:14:43

right beside dvp


---

### 763. msg_10956

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:14:55

>
I will leave this alone\. I have obvious ptsd lol


---

### 764. msg_10957

**You** - 2025-05-13T21:15:17

you give me a gift and I loved it\.


---

### 765. msg_10958

**You** - 2025-05-13T21:15:53

Vitha used to bring me back stuff from her india trips\.\. she brought me back a fat buddha statue once\.\. said it looked like me\. except for the smile\.


---

### 766. msg_10959

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:15:59

Soooooooo different\!\!\!\!


---

### 767. msg_10960

**You** - 2025-05-13T21:16:09

she did it more to laugh at me\.


---

### 768. msg_10961

**You** - 2025-05-13T21:16:39

Look no one has ever flirted with me Mer\.\. not once\.


---

### 769. msg_10962

**You** - 2025-05-13T21:17:04

so you can just lower the defense shields\.\. no one is interested in me except you\.\. in fact no one even knows I am separated\.


---

### 770. msg_10963

**You** - 2025-05-13T21:18:38

anyhow those are my ideas I tried to find locations that were off the beaten path\. plans \- I leave those to you\.\. take too much energy for me to try that kind of thing\.


---

### 771. msg_10964

**You** - 2025-05-13T21:18:51

all you need to know is I can make almost anything happen whenever I want to\.


---

### 772. msg_10965

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:20:01

Okay I’m good to get together one morning\. I just have to be well rested lol I’m running late a lot


---

### 773. msg_10966

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:20:18

The crappy thing is I might end up at the cottage by myself this weekend


---

### 774. msg_10967

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:20:31

Seems like a waste


---

### 775. msg_10968

**You** - 2025-05-13T21:20:49

Don’t kid


---

### 776. msg_10969

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:20:50

Maelle wants to stay in city for a volleyball open gym Sat night 6\-8pm


---

### 777. msg_10970

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:20:55

I just learned tonight


---

### 778. msg_10971

**You** - 2025-05-13T21:20:59

You already told me there are cameras


---

### 779. msg_10972

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:21:00

Andrew never told me


---

### 780. msg_10973

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:21:20

Our cottage has 3 ring cameras :\(


---

### 781. msg_10974

**You** - 2025-05-13T21:21:30

Yeah I remembered not an option


---

### 782. msg_10975

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:22:04

Sigh we have agreed that those will need to change in future but WHEN


---

### 783. msg_10976

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:22:05

Ugh


---

### 784. msg_10977

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:22:16

It would be super sus


---

### 785. msg_10978

**You** - 2025-05-13T21:22:32

If you turned them off yeah


---

### 786. msg_10979

**You** - 2025-05-13T21:23:09

Plus at some point we have to tell someone because I need an excuse


---

### 787. msg_10980

**You** - 2025-05-13T21:24:23

Won’t work anyways\.\. I will just get excited for nothing lol\.


---

### 788. msg_10981

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:25:19

Lake front doors have no camera but driveway is at back and I’m assuming you don’t have a boat to arrive in? Lol


---

### 789. msg_10982

**You** - 2025-05-13T21:25:32

And then what if Andrew just decides to show up\.\. that could be possible


---

### 790. msg_10983

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:25:40

He will be in Edmonton


---

### 791. msg_10984

**You** - 2025-05-13T21:25:41

No boat


---

### 792. msg_10985

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:25:50

That would be hard for him


---

### 793. msg_10986

**You** - 2025-05-13T21:26:18

I mean it would be pretty amazing\. But still not sure\.


---

### 794. msg_10987

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:26:45

He hasn’t texted me back about Maelle’s vball


---

### 795. msg_10988

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:27:07

If she stays my mom has to come probably\. She offered on weekend


---

### 796. msg_10989

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:27:21

Just bc she thought Maelle might not want to go


---

### 797. msg_10990

**You** - 2025-05-13T21:27:33

Are you seriously considering this\.


---

### 798. msg_10991

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:27:54

I mean, if you could get away\.


---

### 799. msg_10992

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:28:01

I wouldn’t turn cameras off tho


---

### 800. msg_10993

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:28:08

Maybe one


---

### 801. msg_10994

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:28:22

I would figure something out and you would have to stay lake side


---

### 802. msg_10995

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:28:30

Outside will be so buggy anyway


---

### 803. msg_10996

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:28:41

No cameras lake side


---

### 804. msg_10997

**You** - 2025-05-13T21:28:43

What does lake side mean?


---

### 805. msg_10998

**You** - 2025-05-13T21:28:55

Mean outside  of the house on lake side


---

### 806. msg_10999

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:29:34

Yeah \- we have no cameras on that side\. Only on driveway door and both sides


---

### 807. msg_11000

**You** - 2025-05-13T21:30:11

Ok so how do I get into the driveway just park a ways back and walk through woods?


---

### 808. msg_11001

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:30:24

That’s the question lol


---

### 809. msg_11002

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:30:42

I could turn front camera off for a bit maybe


---

### 810. msg_11003

**You** - 2025-05-13T21:30:43

Reaction: ❓ from Meredith Lamb
Kk well I already have an idea for weekend\.


---

### 811. msg_11004

**You** - 2025-05-13T21:31:59

When are you coming back Sunday or Monday?  This is long weekend right?


---

### 812. msg_11005

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:35:11

Yeah long weekend


---

### 813. msg_11006

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:35:25

I might take tues off\. Not sure yet


---

### 814. msg_11007

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:35:52

Oh no I won’t


---

### 815. msg_11008

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:35:57

Oc meeting lol


---

### 816. msg_11009

**You** - 2025-05-13T21:36:01

You can if you want


---

### 817. msg_11010

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:36:06

OC


---

### 818. msg_11011

**You** - 2025-05-13T21:36:14

Just do it remote


---

### 819. msg_11012

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:36:25

It’s fine


---

### 820. msg_11013

**You** - 2025-05-13T21:36:31

Or is Ian in those ones I cannot remember


---

### 821. msg_11014

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:36:41

No managers and no Ian


---

### 822. msg_11015

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:36:50

They are very low key


---

### 823. msg_11016

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:38:13

>
What is your idea?


---

### 824. msg_11017

**You** - 2025-05-13T21:38:27

I already sold it\.


---

### 825. msg_11018

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:41:11

We are so bad at communicating\. Omg

*1 attachment(s)*


---

### 826. msg_11019

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:42:59

>
I’m not understanding


---

### 827. msg_11020

**You** - 2025-05-13T21:43:43

Sec


---

### 828. msg_11021

**You** - 2025-05-13T21:47:31

Said I am going to Chatham to visit some work peeps\. Tom Haris etc\.\. might work out of Chatham Tuesday or sure\.\.


---

### 829. msg_11022

**You** - 2025-05-13T21:47:53

While she is slightly cranky she told me to go


---

### 830. msg_11023

**You** - 2025-05-13T21:48:06

So I don’t know where that came from\.


---

### 831. msg_11024

**You** - 2025-05-13T21:48:16

I mean you with the insane idea


---

### 832. msg_11025

**You** - 2025-05-13T21:48:45

But either way I can cancel and make up an excuse if it doesn’t work\.


---

### 833. msg_11026

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:48:49

Well it was going to be me and and Maelle until I picked her up from vball tonight and she told me about the open gym\. No one told me


---

### 834. msg_11027

**You** - 2025-05-13T21:48:51

So not locked in


---

### 835. msg_11028

**You** - 2025-05-13T21:49:06

But I can do it\.


---

### 836. msg_11029

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:49:23

So the damn rings are so annoying\. Who knew lol


---

### 837. msg_11030

**You** - 2025-05-13T21:49:40

Well yeah but they do
Glitch from
Time to
Time


---

### 838. msg_11031

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:49:58

I will figure something out


---

### 839. msg_11032

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:50:39

If we had a boat in, I could just easily pick you up somewhere else but I don’t think he put one in


---

### 840. msg_11033

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:50:42

Just the dock


---

### 841. msg_11034

**You** - 2025-05-13T21:50:49

I do t even know where it is in relation to anything


---

### 842. msg_11035

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:51:09

I actually could just canoe to high rock and pick you up that way


---

### 843. msg_11036

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:51:13

There are options


---

### 844. msg_11037

**You** - 2025-05-13T21:51:24

I mean whatever works


---

### 845. msg_11038

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:51:39

But u could never go out the front door unless i cover it lol


---

### 846. msg_11039

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:51:49

Or turn it off which I don’t even know how to do


---

### 847. msg_11040

**You** - 2025-05-13T21:51:58

I would stay where I am told\.


---

### 848. msg_11041

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:52:02

lol


---

### 849. msg_11042

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:52:29

And I do have to do cleaning for Mac


---

### 850. msg_11043

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:52:37

Andrew apparently made a big mess


---

### 851. msg_11044

**You** - 2025-05-13T21:53:34

I can help clean


---

### 852. msg_11045

**You** - 2025-05-13T21:53:38

I am good at ti


---

### 853. msg_11046

**You** - 2025-05-13T21:54:45

Fri to monday seems too good to be true this is where the universe
Comes in and kicks me in the teeth\.


---

### 854. msg_11047

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:54:59

Oh whatever


---

### 855. msg_11048

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:55:04

lol


---

### 856. msg_11049

**You** - 2025-05-13T21:55:29

Ok so again where about a is this place
Like a 4 hour drive yku said?


---

### 857. msg_11050

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:55:48

671 high rock drive, Sundridge


---

### 858. msg_11051

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:55:57

Sometimes referred to as Strong


---

### 859. msg_11052

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:56:04

Because it is in strong township


---

### 860. msg_11053

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:56:12

So some mapping systems say Strong


---

### 861. msg_11054

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:56:28

2\.5 if no traffic


---

### 862. msg_11055

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:56:33

4 … no


---

### 863. msg_11056

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:56:42

Only if traffic or accidents


---

### 864. msg_11057

**You** - 2025-05-13T21:57:17

shows about 249 for me\.


---

### 865. msg_11058

**You** - 2025-05-13T21:57:41

almost a straight shoot thoguht


---

### 866. msg_11059

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:57:59

2hr 35 for me


---

### 867. msg_11060

**You** - 2025-05-13T21:57:55

from whitby/oshawa


---

### 868. msg_11061

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:58:08

Yeah Oshawa route is longer


---

### 869. msg_11062

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:58:11

More scenic


---

### 870. msg_11063

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:58:14

I do it a lot


---

### 871. msg_11064

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:58:22

Go to my parents first and then drive up


---

### 872. msg_11065

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T21:58:35

Slightly longer for sure\. Not as much direct highway


---

### 873. msg_11066

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:00:00

I was considering telling my bro he can go up\. Won’t now lol


---

### 874. msg_11067

**You** - 2025-05-13T22:00:08

I mean\.\.\.\.


---

### 875. msg_11068

**You** - 2025-05-13T22:00:09

lol


---

### 876. msg_11069

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:00:23

He would mess it up and I’m trying to clean


---

### 877. msg_11070

**You** - 2025-05-13T22:00:54

well it will be a test for you\.


---

### 878. msg_11071

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:01:20

Really…


---

### 879. msg_11072

**You** - 2025-05-13T22:01:17

see how long it takes for you to get sick of my company\.\. :\)


---

### 880. msg_11073

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:01:43

Ha okay


---

### 881. msg_11074

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:01:52

Not worried


---

### 882. msg_11075

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:02:18

Oh there could be an issue I just thought of


---

### 883. msg_11076

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:02:39

When your fam calls you do they FaceTime over wifi ?


---

### 884. msg_11077

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:02:43

Or call call


---

### 885. msg_11078

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:02:57

Sometimes reception is spotty


---

### 886. msg_11079

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:03:03

FaceTime /wifi is fine


---

### 887. msg_11080

**You** - 2025-05-13T22:03:02

mmm\.\. depends why?  doesn't matter\.


---

### 888. msg_11081

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:03:07

Unless it goes out


---

### 889. msg_11082

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:03:15

I mean if the power goes out


---

### 890. msg_11083

**You** - 2025-05-13T22:03:13

I could be in a spotty location wherever I am


---

### 891. msg_11084

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:03:40

No wifi because our generator is no use for wifi because we ping off of a house across the lake


---

### 892. msg_11085

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:03:48

So if that house goes out we are fucked


---

### 893. msg_11086

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:03:52

It’s dumb


---

### 894. msg_11087

**You** - 2025-05-13T22:03:58

yeah I am not worried\.\. again\.\. I could be anywhere with bad reception


---

### 895. msg_11088

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:04:03

Doesn’t happen OFTEN but can


---

### 896. msg_11089

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:04:34

That could give you a bit of panic lol


---

### 897. msg_11090

**You** - 2025-05-13T22:07:16

one sec


---

### 898. msg_11091

**You** - 2025-05-13T22:14:46

ok


---

### 899. msg_11092

**You** - 2025-05-13T22:15:03

is your little one still up and around?


---

### 900. msg_11093

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:15:27

Yeah she is studying math :p test tomorrow


---

### 901. msg_11094

**You** - 2025-05-13T22:15:34

ah kk\.\.


---

### 902. msg_11095

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:15:38

Annoying fractions


---

### 903. msg_11096

**You** - 2025-05-13T22:15:41

yeah those pesky things


---

### 904. msg_11097

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:15:50

I’ve been helping her in and off


---

### 905. msg_11098

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:15:53

On and off


---

### 906. msg_11099

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:16:09

And I hate to say but she saw your name at one point hours ago


---

### 907. msg_11100

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:16:15

I am a bad mother


---

### 908. msg_11101

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:16:18

:p


---

### 909. msg_11102

**You** - 2025-05-13T22:16:23

how when you were helping her?


---

### 910. msg_11103

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:16:37

Yeah


---

### 911. msg_11104

**You** - 2025-05-13T22:17:15

err


---

### 912. msg_11105

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:18:06

She’s at me all the time


---

### 913. msg_11106

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:18:10

I am not kidding


---

### 914. msg_11107

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:18:16

It is challenging


---

### 915. msg_11108

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:18:33

I do the best I can\. She never says anything when she sees your name lol


---

### 916. msg_11109

**You** - 2025-05-13T22:18:51

I mean\.\. it is going to be really awkward meeting them


---

### 917. msg_11110

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:19:13

Yup ditto


---

### 918. msg_11111

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:19:52

I feel like yours would be way worse than mine for some reason


---

### 919. msg_11112

**You** - 2025-05-13T22:20:00

not maddie


---

### 920. msg_11113

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:20:05

Just the mom/dad thing


---

### 921. msg_11114

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:20:30

I can never meet your oldest\.


---

### 922. msg_11115

**You** - 2025-05-13T22:20:28

hold a sec\.\. this should be interesting\.\. nothing to worry about will tell you after


---

### 923. msg_11116

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:20:37

I think it would be dangerous


---

### 924. msg_11117

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:20:39

lol


---

### 925. msg_11118

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:21:13

>
After what?


---

### 926. msg_11119

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:27:40

I have to go to bed soon bc I have to take Maelle to school for her mtl grad trip for 6\.30am tomorrow morning and I have to get her some cash out in advance of that so early morning for me 😭


---

### 927. msg_11120

**You** - 2025-05-13T22:34:55

Sure you cannot call quick so you can here of my plans\.\.
Or we can talk tomorrow doesn’t have the same effect
On text


---

### 928. msg_11121

**You** - 2025-05-13T22:35:21

If not you go to bed I have to go soon too but I just had a hilarious call


---

### 929. msg_11122

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:37:17

One sec


---

### 930. msg_11123

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:37:48

Ok 5 min


---

### 931. msg_11124

**You** - 2025-05-13T22:54:27

Thank you for pulling me out of the dirt tonight\.  I felt a lot better even before you suggested this weekend\.  Love you ❤️❤️❤️


---

### 932. msg_11125

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:58:25

Wait, you told Tom about a rando or me specifically?


---

### 933. msg_11126

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:58:31

Hat seems risky


---

### 934. msg_11127

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:58:54

\*That


---

### 935. msg_11128

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T22:59:52

>
I love you too and despite what you may think, I don’t want you to be all down just like you don’t want me to be\. xoxox


---

### 936. msg_11129

**You** - 2025-05-13T23:20:01

>
Not a hook up


---

### 937. msg_11130

**You** - 2025-05-13T23:20:07

Just for me to get away\.z


---

### 938. msg_11131

**You** - 2025-05-13T23:20:17

No I didn’t tell him about you ya butter


---

### 939. msg_11132

**You** - 2025-05-13T23:20:22

Nutter


---

### 940. msg_11133

**You** - 2025-05-13T23:20:59

>
I do believe it kinda lol it is just hard to read what you write sometimes and think that you mean it about me is all\.


---

### 941. msg_11134

**You** - 2025-05-13T23:21:08

Nite xoxo


---

### 942. msg_11135

**Meredith Lamb \(\+14169386001\)** - 2025-05-13T23:21:51

Phew \(re Tom\) lol nite xo


---

### 943. msg_11136

**You** - 2025-05-13T23:22:00

Rofl


---

### 944. msg_11137

**You** - 2025-05-14T06:26:09

Wake up lazy bones


---

### 945. msg_11138

**You** - 2025-05-14T06:26:15

lol saw
You typing


---

### 946. msg_11139

**You** - 2025-05-14T06:26:30

All ok?


---

### 947. msg_11140

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:27:13

So I was thinking maybe I go Thursday and you go Friday morning \(if you are taking day off\)\. Then, I can clean and move stuff onto front porch and cover the ring with it\!


---

### 948. msg_11141

**You** - 2025-05-14T06:28:04

Sure whatever works\.  I convinced j I was going to leave from work tomorrow afternoon but can switch that up for sure


---

### 949. msg_11142

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:34:46

Just driving my kid to her garage trip drop off and she forgot her headphones so I have to drive back\. Ugh


---

### 950. msg_11143

**You** - 2025-05-14T06:34:58

Eesh sucks boooo


---

### 951. msg_11144

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:35:04

Grad trip


---

### 952. msg_11145

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:35:30

If I can get there earlier than you, I will look at my schedule then I can clean and put some stuff in front of the ring and that is probably the easiest thing to do


---

### 953. msg_11146

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:35:45

But I need to get there earlier than you in order to do that and make it realistic


---

### 954. msg_11147

**You** - 2025-05-14T06:36:59

Ok so depends on when you leave and when I leave Thursday I could leave later and you earlier or I could tell Jaimie I am going to change plans\.\. just don’t want to change too much she is already sus a bit\.


---

### 955. msg_11148

**You** - 2025-05-14T06:37:17

We can chat
This morning if you have some tine or whenever\.


---

### 956. msg_11149

**You** - 2025-05-14T06:39:56

I could also leave later thurs and just find a bnb or something couple of options


---

### 957. msg_11150

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:46:16

>
No not necessary


---

### 958. msg_11151

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:46:27

k Maelle has her headphones and I am free of her


---

### 959. msg_11152

**You** - 2025-05-14T06:46:34

lol


---

### 960. msg_11153

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:46:35

Will go home and check my schedule


---

### 961. msg_11154

**You** - 2025-05-14T06:47:49

For something funny to tell you in a min\.\.


---

### 962. msg_11155

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:53:58

You know what I have Thursday aft?


---

### 963. msg_11156

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:56:56

YOUR meeting


---

### 964. msg_11157

**You** - 2025-05-14T06:57:42

So take half an sdo


---

### 965. msg_11158

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:57:48

I think I also told Andrew I’d take Marlowe to vball thurs night 6\-8pm\. But can’t remember why he couldn’t hmmmh


---

### 966. msg_11159

**You** - 2025-05-14T06:57:50

It won’t be the last
Meeting


---

### 967. msg_11160

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:57:52

Have to text him


---

### 968. msg_11161

**You** - 2025-05-14T06:58:09

Kk well let me know I am holding off telling j anything further


---

### 969. msg_11162

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:58:24

I mean I have driven to cottage in morning before work before and then worked from there


---

### 970. msg_11163

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:58:27

I could do that


---

### 971. msg_11164

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:58:35

Leave at 6am


---

### 972. msg_11165

**You** - 2025-05-14T06:58:38

Tomorrow morning


---

### 973. msg_11166

**You** - 2025-05-14T06:58:52

Yeah I mean if volleyball is sorted


---

### 974. msg_11167

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T06:59:26

I will text him what that is about\. I can’t store all of this info in my brain


---

### 975. msg_11168

**You** - 2025-05-14T06:59:46

lol


---

### 976. msg_11169

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:01:12

This is why I can’t store shit\. Honestly his requests are all over the place\.

*1 attachment(s)*


---

### 977. msg_11170

**You** - 2025-05-14T07:01:50

Yeah a lot of juggling


---

### 978. msg_11171

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:02:23

He can’t even remember the reason


---

### 979. msg_11172

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:02:27

Seriously


---

### 980. msg_11173

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:02:50

But when things change he doesn’t tell me so I have it in my calendar still


---

### 981. msg_11174

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:03:06

Anyway I don’t have to do it


---

### 982. msg_11175

**You** - 2025-05-14T07:03:24

Kk so that works out head up early I will leave later in day\.


---

### 983. msg_11176

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:04:54

That’s good\. I will clean over lunch hour which will be “normal” and pile stuff in front of ring\. Not out of norm when Andrew makes messes\. He said there are big messes so probably lots of stuff to pile up 🤞


---

### 984. msg_11177

**You** - 2025-05-14T07:05:46

lol this is slightly silly but sweet at the same time that you would go to this much trouble\.  Very much appreciated will have to make it up to
You\.


---

### 985. msg_11178

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:10:23

You know what I’m missing for you right?


---

### 986. msg_11179

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:10:36

Let’s see how good your memory is\.


---

### 987. msg_11180

**You** - 2025-05-14T07:11:17

For or from


---

### 988. msg_11181

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:11:25

For


---

### 989. msg_11182

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:11:33

Testing your memory


---

### 990. msg_11183

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:11:40

What will I be missing?


---

### 991. msg_11184

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:12:32

You have no idea\.


---

### 992. msg_11185

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:12:42

Johnny is coming over thurs night


---

### 993. msg_11186

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:12:56

I will no longer be here lol


---

### 994. msg_11187

**You** - 2025-05-14T07:13:15

Oh shit


---

### 995. msg_11188

**You** - 2025-05-14T07:13:22

I forgot no stay


---

### 996. msg_11189

**You** - 2025-05-14T07:13:25

Seriously


---

### 997. msg_11190

**You** - 2025-05-14T07:13:28

Not joking


---

### 998. msg_11191

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:13:35

LOL NO


---

### 999. msg_11192

**You** - 2025-05-14T07:13:39

That is so important to you it is important to me too\.


---

### 1000. msg_11193

**You** - 2025-05-14T07:13:52

I totally forgot


---

### 1001. msg_11194

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:13:53

No but I will leave him a gift


---

### 1002. msg_11195

**You** - 2025-05-14T07:14:11

🙁 your should stay and go up Friday morning


---

### 1003. msg_11196

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:14:31

No it isn’t that important


---

### 1004. msg_11197

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:14:35

Mac can FaceTime me


---

### 1005. msg_11198

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:14:37

lol


---

### 1006. msg_11199

**You** - 2025-05-14T07:15:27

I definitely need to do something to make that up\.


---

### 1007. msg_11200

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:16:07

Just saying\. :\)


---

### 1008. msg_11201

**You** - 2025-05-14T07:16:26

Kk well you think of something


---

### 1009. msg_11202

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:17:32


*1 attachment(s)*


---

### 1010. msg_11203

**You** - 2025-05-14T07:18:48

You excited
Anyways I can avoid cameras
To come I\. Walks
With you??


---

### 1011. msg_11204

**You** - 2025-05-14T07:18:55

Excited
For dogs\.


---

### 1012. msg_11205

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:19:29

If I keep stuff in front of ring it is possible but our stupid side camera is pretty wide


---

### 1013. msg_11206

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:19:36

The dogs love the lake side tho


---

### 1014. msg_11207

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:19:44

And the driveway will be so buggy


---

### 1015. msg_11208

**You** - 2025-05-14T07:19:48

Kk


---

### 1016. msg_11209

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:19:55

May 24 weekend is so bad for black flies every year


---

### 1017. msg_11210

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:20:18

They will want to swim a lot


---

### 1018. msg_11211

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:20:53

I think it is supposed to rain a lot tho


---

### 1019. msg_11212

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:21:01

Which means more bugs


---

### 1020. msg_11213

**You** - 2025-05-14T07:23:19

lol should be interesting


---

### 1021. msg_11214

**You** - 2025-05-14T07:23:35

May have to wash clothes before I come back dog smell will be real lol\.\.


---

### 1022. msg_11215

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:24:29

No worries\. We have a laundry room\. It is basically just a house\.


---

### 1023. msg_11216

**You** - 2025-05-14T07:25:36

I figured


---

### 1024. msg_11217

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:26:30

We call it a cottage but…


---

### 1025. msg_11218

**You** - 2025-05-14T07:30:32

Yeah I know how the 1% lives\.\. lol


---

### 1026. msg_11219

**You** - 2025-05-14T07:30:37

J/k


---

### 1027. msg_11220

**You** - 2025-05-14T07:31:16

Tbh I am fairly certain we
Could do same thing if we wanted\.\. we thiught about buying a place in Aruba\.\. but that was back when I thought
Things could fix relationships\.


---

### 1028. msg_11221

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:32:00

So Mac said she doesn’t even care if I’m not here thurs night\. Rude\.


---

### 1029. msg_11222

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:32:08

She’s like “I’m not FaceTiming you”


---

### 1030. msg_11223

**You** - 2025-05-14T07:32:36

Ouch


---

### 1031. msg_11224

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:32:46

She’s grumpy


---

### 1032. msg_11225

**You** - 2025-05-14T07:32:51

Ask her to do it for me?? lol


---

### 1033. msg_11226

**You** - 2025-05-14T07:32:54

No dont


---

### 1034. msg_11227

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:33:12

lol no


---

### 1035. msg_11228

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:33:26

She’s making her smoothie\. Shouldn’t have talked to her prior


---

### 1036. msg_11229

**You** - 2025-05-14T07:33:56

Kk finished double
Workout heading down to get showered  yeah those chia seeds make a difference\.


---

### 1037. msg_11230

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T07:35:06

lol k, I’m going to order him a gift online and then get ready for the day


---

### 1038. msg_11231

**You** - 2025-05-14T07:35:32

Kk chat I\. A bit\.


---

### 1039. msg_11232

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T10:46:58

I couldn’t sense how bothered you were by this\. You can not go and or go for a shorter time if it makes it easier\.


---

### 1040. msg_11233

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T10:47:04

I am going regardless


---

### 1041. msg_11234

**You** - 2025-05-14T10:48:11

I am not bothered\.  J is just lashing out\.\. as much as she says I don’t accept responsibility she definitely doesn’t\.\. I just let her rail at me for like 2 hours she was scraping up all
Kinds
Of shit


---

### 1042. msg_11235

**You** - 2025-05-14T10:48:15

She is a dirty fighter


---

### 1043. msg_11236

**You** - 2025-05-14T10:48:31

Anyways I am fine shutting communication off for the weekend\.


---

### 1044. msg_11237

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T10:50:05

I leave it to you lol


---

### 1045. msg_11238

**You** - 2025-05-14T10:50:47

Yep… I am good here, tonight might be spicy but that is what locks are for\.


---

### 1046. msg_11239

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T10:53:20

Oh boy lol you guys are intense


---

### 1047. msg_11240

**You** - 2025-05-14T10:54:15

You have no idea\.\. she is insanely intense\.\. I almost never fought in relationships before her\.\. super aggressive


---

### 1048. msg_11241

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T10:57:28

I find that a little scary tbh lol


---

### 1049. msg_11242

**You** - 2025-05-14T10:58:22

I mean I have lived with it for 20’years\.


---

### 1050. msg_11243

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:47:10


*1 attachment(s)*


---

### 1051. msg_11244

**You** - 2025-05-14T13:47:47

Rofl


---

### 1052. msg_11245

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:49:07

Story of my life


---

### 1053. msg_11246

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:53:04

Um, not sure how you feel about that lol


---

### 1054. msg_11247

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:54:44

Looks like Brett is dropping them off tonight


---

### 1055. msg_11248

**You** - 2025-05-14T13:55:05

5 dogs


---

### 1056. msg_11249

**You** - 2025-05-14T13:55:06

Right


---

### 1057. msg_11250

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:38


*1 attachment(s)*


---

### 1058. msg_11251

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:38


*1 attachment(s)*


---

### 1059. msg_11252

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:40


*1 attachment(s)*


---

### 1060. msg_11253

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:40


*1 attachment(s)*


---

### 1061. msg_11254

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:41


*1 attachment(s)*


---

### 1062. msg_11255

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:41


*1 attachment(s)*


---

### 1063. msg_11256

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:55:45

Yah


---

### 1064. msg_11257

**You** - 2025-05-14T13:55:46

I am sleeping beside you griffon can bite me\.


---

### 1065. msg_11258

**You** - 2025-05-14T13:55:57

Literally


---

### 1066. msg_11259

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:56:37

Griffin, Rosie, Bo, Walter and Lisa


---

### 1067. msg_11260

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:56:54

Bo and Lisa bark at noises :p


---

### 1068. msg_11261

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T13:57:45

I basically always have kids or dogs lol


---

### 1069. msg_11262

**You** - 2025-05-14T14:03:03

I mean I am good with either kids or dogs


---

### 1070. msg_11263

**You** - 2025-05-14T14:03:06

Or both


---

### 1071. msg_11264

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:05:10

Wasn’t really looking to have 5 dogs this weekend but ugh


---

### 1072. msg_11265

**You** - 2025-05-14T14:06:07

It’s fine\. lol we will have fun\.


---

### 1073. msg_11266

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:13:49

We will see\. Lol


---

### 1074. msg_11267

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:13:53

Kidding


---

### 1075. msg_11268

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:14:12

I was actually looking forward to only 3\. Serves me right


---

### 1076. msg_11269

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:25:15


*1 attachment(s)*


---

### 1077. msg_11270

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:25:27

Ok so I couldn’t do it, I’m too anxious about the weather


---

### 1078. msg_11271

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:25:36

I think I’m leaving Walt and Lisa here


---

### 1079. msg_11272

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:25:40

Brett is ok with it


---

### 1080. msg_11273

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T14:26:01

He contacted me too late\. I’m not mentally prepared to clean with 5 dogs … like HOW


---

### 1081. msg_11274

**You** - 2025-05-14T15:09:20

So is it just big words or stats does that do it too?


---

### 1082. msg_11275

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:11:48

All of the above


---

### 1083. msg_11276

**You** - 2025-05-14T15:15:27

Any other subjects history\.\. we could watch jeopardy
Together


---

### 1084. msg_11277

**You** - 2025-05-14T15:15:29

lol


---

### 1085. msg_11278

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:18:04

Never gotten into jeopardy lol


---

### 1086. msg_11279

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:21:50

Why Mackenzie wants me to go… Andrew is sooooo messy when he does stuff\. I mean he does Reno’s but the collateral damage is usually huge\.

*1 attachment(s)*


---

### 1087. msg_11280

**You** - 2025-05-14T15:25:12

Well I have never messed with building shit but the clean up and the lifting etc\.\. good labour I just worry too much that I don’t know enough I am sure I could figure it out and I have but I don’t like it\.


---

### 1088. msg_11281

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:26:06

I am just very relieved not to have 5 dogs\. Feeling a bit drained for that\.


---

### 1089. msg_11282

**You** - 2025-05-14T15:33:55

lol it is a lot of responsibility for sure


---

### 1090. msg_11283

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:35:18

And general mess


---

### 1091. msg_11284

**You** - 2025-05-14T15:35:43

Cleaning is easy I will help


---

### 1092. msg_11285

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:44:13

Be careful what you volunteer for


---

### 1093. msg_11286

**You** - 2025-05-14T15:44:34

Anything is better than here\.


---

### 1094. msg_11287

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:45:53

We can finally play ticket to ride lol


---

### 1095. msg_11288

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T15:46:22

Not as good with 2 ppl but still good


---

### 1096. msg_11289

**You** - 2025-05-14T15:47:18

Yeah I was actually thinking about that


---

### 1097. msg_11290

**You** - 2025-05-14T15:47:23

Last night


---

### 1098. msg_11291

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T16:01:43

Ugh I have volleyball duties 5\-9pm tonight…\.\. so annoyed\.


---

### 1099. msg_11292

**You** - 2025-05-14T16:57:24

Nice


---

### 1100. msg_11293

**You** - 2025-05-14T16:57:36

I will be available to entertain you as needed


---

### 1101. msg_11294

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T16:59:37

My little shadow is coming with me too :p


---

### 1102. msg_11295

**You** - 2025-05-14T17:17:47

Ok so all the entertainment you need lol


---

### 1103. msg_11296

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T18:27:27

On our way to homesense


---

### 1104. msg_11297

**You** - 2025-05-14T18:28:00

for?


---

### 1105. msg_11298

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T18:28:15

Bedrooms for Mac’s bday lol


---

### 1106. msg_11299

**You** - 2025-05-14T18:28:20

lol


---

### 1107. msg_11300

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T18:28:28

And to kill time while she is at vball


---

### 1108. msg_11301

**You** - 2025-05-14T18:28:32

can I bring anything tomorrow\.\. please say yes I want to help


---

### 1109. msg_11302

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T18:29:37

I will think about it\. I mean if there is stuff you need to eat then that but there is a grocery store nearby\.


---

### 1110. msg_11303

**You** - 2025-05-14T18:30:15

Reaction: 🙄 from Meredith Lamb
yeah I as long as there is a path outside of cams I planned to give you some time to yourself each day, you will get sick of me\.\. :\(


---

### 1111. msg_11304

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T18:30:20

Cold pillow lol


---

### 1112. msg_11305

**You** - 2025-05-14T18:30:29

yeah it comes where i go


---

### 1113. msg_11306

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T19:15:41

We had to leave bc we spent too much $


---

### 1114. msg_11307

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T19:15:43

lol


---

### 1115. msg_11308

**You** - 2025-05-14T19:16:18

Surprise


---

### 1116. msg_11309

**You** - 2025-05-14T19:16:20

lol


---

### 1117. msg_11310

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T19:16:33

Mac will be happy


---

### 1118. msg_11311

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T19:51:10

Ps\. I bought new bedding so it’s not weird \(for you or me\)\. I had to get some for renovated bedrooms anyway


---

### 1119. msg_11312

**You** - 2025-05-14T19:55:55

Um that was thoughtful\.  Wouldn’t have thought of that but yeah I guess some weirdness… hmmm that’s gonna fester lol\.


---

### 1120. msg_11313

**You** - 2025-05-14T19:56:40

I will try to think happy thoughts


---

### 1121. msg_11314

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T19:57:10

It’s kind of our second house so…


---

### 1122. msg_11315

**You** - 2025-05-14T20:04:37

I mean it is something you will have to get used to\.


---

### 1123. msg_11316

**You** - 2025-05-14T20:04:44

Goes both ways


---

### 1124. msg_11317

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T20:07:10

I think I will be fine


---

### 1125. msg_11318

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T20:07:15

:\)


---

### 1126. msg_11319

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T20:07:35

Yaye I get to drive an hour home now


---

### 1127. msg_11320

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T20:07:40

Soooooo tired


---

### 1128. msg_11321

**You** - 2025-05-14T20:14:27

Long night and monger day tomorrow yku are going to be exhausted… massage??  Haven’t tried that yet you might enjoy who knows\.


---

### 1129. msg_11322

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:00:26

Walking dogs then bed\. Omg considering taking a vacation day tomorrow\. Would that be bad last minute? I’d work Friday\.


---

### 1130. msg_11323

**You** - 2025-05-14T21:00:41

naw do it


---

### 1131. msg_11324

**You** - 2025-05-14T21:01:01

going to bed soon as well\.\. getting up early again tomorrow\.\. all packed though\.


---

### 1132. msg_11325

**You** - 2025-05-14T21:01:14

bought the house tonight


---

### 1133. msg_11326

**You** - 2025-05-14T21:01:19

put 10k down


---

### 1134. msg_11327

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:01:34

I thought it was bought


---

### 1135. msg_11328

**You** - 2025-05-14T21:01:39

offer was accepted


---

### 1136. msg_11329

**You** - 2025-05-14T21:01:43

conditions had to be removed


---

### 1137. msg_11330

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:01:47

Ah I see


---

### 1138. msg_11331

**You** - 2025-05-14T21:01:52

she almost flipped again today


---

### 1139. msg_11332

**You** - 2025-05-14T21:01:59

spent the entire last night and this morning berating me


---

### 1140. msg_11333

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:02:00

😬


---

### 1141. msg_11334

**You** - 2025-05-14T21:02:03

it was fun


---

### 1142. msg_11335

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:02:17

Oh man


---

### 1143. msg_11336

**You** - 2025-05-14T21:02:18

still she had an out and she didn't take it


---

### 1144. msg_11337

**You** - 2025-05-14T21:02:31

so\.\. I told her I am not wearing this shit rest of my life


---

### 1145. msg_11338

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:03:08

Hopefully she likes it eventually but it is a massive change


---

### 1146. msg_11339

**You** - 2025-05-14T21:03:25

no she loves the house\.\. loves the idea of going home\.\. just Gracie


---

### 1147. msg_11340

**You** - 2025-05-14T21:03:26

anyways


---

### 1148. msg_11341

**You** - 2025-05-14T21:03:45

think about what you need tomorrow\.  take an SDO\.\. although I think Carolyn was going to reach out for something


---

### 1149. msg_11342

**You** - 2025-05-14T21:03:56

think about how I can pay you back for being awesome\.


---

### 1150. msg_11343

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:04:11

Carolyn reached out today


---

### 1151. msg_11344

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:04:16

Something else?


---

### 1152. msg_11345

**You** - 2025-05-14T21:04:23

I dunno\.


---

### 1153. msg_11346

**You** - 2025-05-14T21:04:24

yeah


---

### 1154. msg_11347

**You** - 2025-05-14T21:04:27

end of day


---

### 1155. msg_11348

**You** - 2025-05-14T21:04:34

we talked about roll over


---

### 1156. msg_11349

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:04:37

Oh blech k


---

### 1157. msg_11350

**You** - 2025-05-14T21:04:43

she might ask you a question\.


---

### 1158. msg_11351

**You** - 2025-05-14T21:04:45

I dunno\.\.


---

### 1159. msg_11352

**You** - 2025-05-14T21:04:49

has to do with OC


---

### 1160. msg_11353

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:04:59

Oh weird ok


---

### 1161. msg_11354

**You** - 2025-05-14T21:05:00

Erin was a git this afternoon again


---

### 1162. msg_11355

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:05:11

Re: ai??


---

### 1163. msg_11356

**You** - 2025-05-14T21:05:21

I think she used the word neophyte too much\.\.


---

### 1164. msg_11357

**You** - 2025-05-14T21:05:27

guessing she looked that bad boy up


---

### 1165. msg_11358

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:05:28

lol


---

### 1166. msg_11359

**You** - 2025-05-14T21:05:46

Reaction: 😂 from Meredith Lamb
anyways she def needs to chill the fuck out lol\.


---

### 1167. msg_11360

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:05:48

I need t look up “git”


---

### 1168. msg_11361

**You** - 2025-05-14T21:05:53

its british


---

### 1169. msg_11362

**You** - 2025-05-14T21:06:01

or australian or something


---

### 1170. msg_11363

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:06:11

Erin has never been ‘chill’


---

### 1171. msg_11364

**You** - 2025-05-14T21:06:28

well she needs to just sit back and stop talking then and listen and learn\.


---

### 1172. msg_11365

**You** - 2025-05-14T21:06:41

she keeps saying she knows what to do\.\. she doesn


---

### 1173. msg_11366

**You** - 2025-05-14T21:06:43

t


---

### 1174. msg_11367

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:06:44

Why is she even in the meetings?


---

### 1175. msg_11368

**You** - 2025-05-14T21:06:55

Because they have "capacity"


---

### 1176. msg_11369

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:07:03

Oh lol


---

### 1177. msg_11370

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:07:17

That’s what I need\. Capacity


---

### 1178. msg_11371

**You** - 2025-05-14T21:07:40

yeah that is what i need


---

### 1179. msg_11372

**You** - 2025-05-14T21:07:42

in another job


---

### 1180. msg_11373

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:07:45

She will chill when I get there


---

### 1181. msg_11374

**You** - 2025-05-14T21:08:03

Reaction: 👎 from Meredith Lamb
Reaction: 👍 from Scott Hicks
once I leave DSM  whooo


---

### 1182. msg_11375

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:08:09

As much as Erin can chill


---

### 1183. msg_11376

**You** - 2025-05-14T21:08:34

neutral


---

### 1184. msg_11377

**You** - 2025-05-14T21:08:51

i forgot to check today


---

### 1185. msg_11378

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:09:00

Shit I have to stay up until Bo gets here gah


---

### 1186. msg_11379

**You** - 2025-05-14T21:09:09

sucks how long


---

### 1187. msg_11380

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:09:32

Not sure\.


---

### 1188. msg_11381

**You** - 2025-05-14T21:10:39

so was thinking of leaving after CM takes me to an intimate coffee get together\.\.\. ROFL\.\. cannot even type that without laughing\.


---

### 1189. msg_11382

**You** - 2025-05-14T21:12:40

there was an OEB manager job posted\.


---

### 1190. msg_11383

**You** - 2025-05-14T21:12:45

I could go for that


---

### 1191. msg_11384

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:13:05

Why leave?


---

### 1192. msg_11385

**You** - 2025-05-14T21:13:14

safer


---

### 1193. msg_11386

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:13:22

Safer huh?


---

### 1194. msg_11387

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:13:32

Is tomorrow your Carolyn thing?


---

### 1195. msg_11388

**You** - 2025-05-14T21:13:45

yeah the intimate coffee rendez\-vous


---

### 1196. msg_11389

**You** - 2025-05-14T21:13:48

see that is better


---

### 1197. msg_11390

**You** - 2025-05-14T21:13:50

lol


---

### 1198. msg_11391

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:13:59

Omg


---

### 1199. msg_11392

**You** - 2025-05-14T21:14:19

she is actually worried I am going to leave


---

### 1200. msg_11393

**You** - 2025-05-14T21:14:29

and she wants to figure out what is wronge


---

### 1201. msg_11394

**You** - 2025-05-14T21:14:31

lol


---

### 1202. msg_11395

**You** - 2025-05-14T21:14:46

imma tell her about us\.\.\. I feel like that is the play


---

### 1203. msg_11396

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:15:42

Yeah right you would never


---

### 1204. msg_11397

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:15:50

You are way smarter than that


---

### 1205. msg_11398

**You** - 2025-05-14T21:16:23

I will leave her a trail of hints\.\. in the form of riddles that will drive her insane\!\!


---

### 1206. msg_11399

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:17:03

Be nice to her\. I think she worries too much about you though\. Seriously


---

### 1207. msg_11400

**You** - 2025-05-14T21:17:29

I will tell her I have a crush on someone \- unrequited love \- something that can never be\!


---

### 1208. msg_11401

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:17:43

🙄


---

### 1209. msg_11402

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:17:54

Your situation isn’t even close to that\.


---

### 1210. msg_11403

**You** - 2025-05-14T21:17:58

\.\.\.\.\. \(negative fun\) \.\.\.\.\.


---

### 1211. msg_11404

**You** - 2025-05-14T21:18:01

lol


---

### 1212. msg_11405

**You** - 2025-05-14T21:18:14

I thought you would say something like \- she will probably think it is her\.


---

### 1213. msg_11406

**You** - 2025-05-14T21:18:19

then it would have been funny


---

### 1214. msg_11407

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:18:26

Haha


---

### 1215. msg_11408

**You** - 2025-05-14T21:18:54

man so much fun to be had\.\.


---

### 1216. msg_11409

**You** - 2025-05-14T21:19:04

but yea thnking of leaving right after that if that is ok\.


---

### 1217. msg_11410

**You** - 2025-05-14T21:19:31

or can wait till later


---

### 1218. msg_11411

**You** - 2025-05-14T21:19:42

or can wait till dark\.\. lol


---

### 1219. msg_11412

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:19:58

What time are you guys having coffee?


---

### 1220. msg_11413

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:20:02

I assumed morning\.


---

### 1221. msg_11414

**You** - 2025-05-14T21:20:03

lunch


---

### 1222. msg_11415

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:20:08

Coffee = morning


---

### 1223. msg_11416

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:20:10

Oh


---

### 1224. msg_11417

**You** - 2025-05-14T21:20:11

lunch


---

### 1225. msg_11418

**You** - 2025-05-14T21:20:34

or dinner as they say on east coast


---

### 1226. msg_11419

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:20:54

What about your afternoon meeting


---

### 1227. msg_11420

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:20:58

I’m confused


---

### 1228. msg_11421

**You** - 2025-05-14T21:20:59

cancelling


---

### 1229. msg_11422

**You** - 2025-05-14T21:21:03

team meeting


---

### 1230. msg_11423

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:21:14

Really


---

### 1231. msg_11424

**You** - 2025-05-14T21:21:15

nothing to share


---

### 1232. msg_11425

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:21:20

lol


---

### 1233. msg_11426

**You** - 2025-05-14T21:21:21

except people complaining about seating


---

### 1234. msg_11427

**You** - 2025-05-14T21:21:27

and other bullshit


---

### 1235. msg_11428

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:21:56

That makes my day a bit less


---

### 1236. msg_11429

**You** - 2025-05-14T21:22:40

hm?


---

### 1237. msg_11430

**You** - 2025-05-14T21:22:46

i can wait until later if you want


---

### 1238. msg_11431

**You** - 2025-05-14T21:22:58

oh you mean to not take sdo


---

### 1239. msg_11432

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:22:58

No no


---

### 1240. msg_11433

**You** - 2025-05-14T21:23:01

and work


---

### 1241. msg_11434

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:23:04

Yeah


---

### 1242. msg_11435

**You** - 2025-05-14T21:23:06

yeah yeah do that\.,


---

### 1243. msg_11436

**You** - 2025-05-14T21:23:08

if you want


---

### 1244. msg_11437

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:23:17

I still have to get up early


---

### 1245. msg_11438

**You** - 2025-05-14T21:24:28

4 am here


---

### 1246. msg_11439

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:24:42

That’s just dumb


---

### 1247. msg_11440

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:24:47

lol


---

### 1248. msg_11441

**You** - 2025-05-14T21:24:48

feels awesome though


---

### 1249. msg_11442

**You** - 2025-05-14T21:24:57

after the sauna\.\. like 20\-30 mins


---

### 1250. msg_11443

**You** - 2025-05-14T21:24:58

amazing


---

### 1251. msg_11444

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:25:04

Sure until you get all tired and grumpy later on


---

### 1252. msg_11445

**You** - 2025-05-14T21:25:13

I haven't been eating


---

### 1253. msg_11446

**You** - 2025-05-14T21:25:15

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


---

### 1254. msg_11447

**You** - 2025-05-14T21:25:26

although I had something at the mgr meeting


---

### 1255. msg_11448

**You** - 2025-05-14T21:25:44

I was fine monday\.\. cranky tuesday\.


---

### 1256. msg_11449

**You** - 2025-05-14T21:25:47

waves


---

### 1257. msg_11450

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:26:26

Maybe slow your roll a bit


---

### 1258. msg_11451

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:26:41

You are going to do something stupid like leave your job


---

### 1259. msg_11452

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:26:46

Ughhhhhhh


---

### 1260. msg_11453

**You** - 2025-05-14T21:27:21

I cannot slow any rolls


---

### 1261. msg_11454

**You** - 2025-05-14T21:27:25

then I wouldn't be me


---

### 1262. msg_11455

**You** - 2025-05-14T21:27:37

I would be a lamer version of me\.


---

### 1263. msg_11456

**You** - 2025-05-14T21:27:43

who slows on rolls all the time\.


---

### 1264. msg_11457

**You** - 2025-05-14T21:27:46

\.\.\.\.\.\. lame


---

### 1265. msg_11458

**You** - 2025-05-14T21:28:22

Leaving my job wouldn't be stupid\.\.


---

### 1266. msg_11459

**You** - 2025-05-14T21:28:27

it might be awesome\.


---

### 1267. msg_11460

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:28:56

Maybe\.


---

### 1268. msg_11461

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:29:04

Bo…


---

### 1269. msg_11462

**You** - 2025-05-14T21:29:58

lol


---

### 1270. msg_11463

**You** - 2025-05-14T21:30:00

no dog yet


---

### 1271. msg_11464

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:37:42

No he’s here now


---

### 1272. msg_11465

**You** - 2025-05-14T21:39:11

yay\.\. just looking at job postings while I waited for you to come back


---

### 1273. msg_11466

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:40:20

Don’t you think we have enough change going on? Lol


---

### 1274. msg_11467

**You** - 2025-05-14T21:40:37

mmmmm


---

### 1275. msg_11468

**You** - 2025-05-14T21:43:31

https://www\.linkedin\.com/jobs/search/?currentJobId=4217715683&geoId=100761630&keywords=AI%20Management&origin=JOB\_SEARCH\_PAGE\_SEARCH\_BUTTON&originalSubdomain=ca&refresh=true


---

### 1276. msg_11469

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:44:18

AI management


---

### 1277. msg_11470

**You** - 2025-05-14T21:44:37

:\)


---

### 1278. msg_11471

**You** - 2025-05-14T21:44:55

the VP product role looks fun


---

### 1279. msg_11472

**You** - 2025-05-14T21:47:26

https://www\.linkedin\.com/jobs/view/4221714781


---

### 1280. msg_11473

**You** - 2025-05-14T21:49:37

hm I could go work at ecobee with Lisa Scott


---

### 1281. msg_11474

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:50:32

How about you just get your life settled first?


---

### 1282. msg_11475

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:50:42

lol I will not stop on this


---

### 1283. msg_11476

**You** - 2025-05-14T21:52:20

Relentless


---

### 1284. msg_11477

**You** - 2025-05-14T21:52:28

challenge accepted\.


---

### 1285. msg_11478

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:52:53

We can talk about it this weekend


---

### 1286. msg_11479

**You** - 2025-05-14T21:53:17

ok how about you go to bed now hon and I will go finish packing and getting ready myself\.\. fast I go to sleep, fast I wake up, work out, work, have a fantastic little coffee break, then drive for 2\.5 hours then see you\.\.


---

### 1287. msg_11480

**You** - 2025-05-14T21:53:42

:\)


---

### 1288. msg_11481

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:53:56

I’m going to watch the first bit of handmaids tale and then yeah bed


---

### 1289. msg_11482

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:54:03

Can’t stop yawning


---

### 1290. msg_11483

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:54:14

Making my list of things not to forget


---

### 1291. msg_11484

**You** - 2025-05-14T21:54:17

kk Love you\.\. don't stay up too late\.


---

### 1292. msg_11485

**You** - 2025-05-14T21:54:27

I can pick things up you forget as well


---

### 1293. msg_11486

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:54:41

No like keys, dump card, etc


---

### 1294. msg_11487

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:54:45

lol power cord


---

### 1295. msg_11488

**You** - 2025-05-14T21:54:48

rofl


---

### 1296. msg_11489

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:54:49

Important stuff


---

### 1297. msg_11490

**You** - 2025-05-14T21:54:55

fair enough


---

### 1298. msg_11491

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:55:04

Bo’s food


---

### 1299. msg_11492

**You** - 2025-05-14T21:55:20

see you are making a list now\.\. already on top of it


---

### 1300. msg_11493

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:55:23

Fresh coffee, wine


---

### 1301. msg_11494

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T21:55:35

These are plate priorities


---

### 1302. msg_11495

**You** - 2025-05-14T21:55:45

i am bringing tequila


---

### 1303. msg_11496

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:06:24

Rose?


---

### 1304. msg_11497

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:07:11

I am not going to get super wasted this weekend lol responsibilities \(dogs\)


---

### 1305. msg_11498

**You** - 2025-05-14T22:07:21

Rose


---

### 1306. msg_11499

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:07:27

Plus I’m not feeling as stressed


---

### 1307. msg_11500

**You** - 2025-05-14T22:07:29

Reaction: 😂 from Meredith Lamb
I didn’t say I was going to Lou d it


---

### 1308. msg_11501

**You** - 2025-05-14T22:07:33

Pound it


---

### 1309. msg_11502

**You** - 2025-05-14T22:07:36

lol


---

### 1310. msg_11503

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:07:40

Because Andrew has been away\. Been calmer


---

### 1311. msg_11504

**You** - 2025-05-14T22:07:54

I would prefer to stay relatively sober tbh


---

### 1312. msg_11505

**You** - 2025-05-14T22:08:04

Relatively


---

### 1313. msg_11506

**You** - 2025-05-14T22:08:13

Still need some courage and all


---

### 1314. msg_11507

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:08:42

It’s hard not to drink at a cottage\. But I do it a lot


---

### 1315. msg_11508

**You** - 2025-05-14T22:08:56

I think it would be relaxing\.\.


---

### 1316. msg_11509

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:09:11

It can be except I do all the cleaning lol


---

### 1317. msg_11510

**You** - 2025-05-14T22:09:17

Not like at home in the basement in the dark


---

### 1318. msg_11511

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:09:44

And Andrew is a very messy and pack rat type person\.


---

### 1319. msg_11512

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:09:53

I like the dark\!


---

### 1320. msg_11513

**You** - 2025-05-14T22:10:11

Well then we have some work to do\.\. since I won’t be working out I will be cleaning


---

### 1321. msg_11514

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:11:16

You could work out in the basement\. I might have like 10 lb or 15 lb weights 😂


---

### 1322. msg_11515

**You** - 2025-05-14T22:11:29

This will work


---

### 1323. msg_11516

**You** - 2025-05-14T22:11:32

Those


---

### 1324. msg_11517

**You** - 2025-05-14T22:11:42

Been studying alternative approaches


---

### 1325. msg_11518

**You** - 2025-05-14T22:11:52

Light weights and like 100 reps can be amazing


---

### 1326. msg_11519

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:12:02

There you go


---

### 1327. msg_11520

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:12:08

lol


---

### 1328. msg_11521

**You** - 2025-05-14T22:12:09

Awesome done\.\.


---

### 1329. msg_11522

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:12:38

k, I’m going to set my alarm now for a ridiculously early time


---

### 1330. msg_11523

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:12:53

Then watch the beginning of handmaids tale


---

### 1331. msg_11524

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:12:56

Then pass out


---

### 1332. msg_11525

**You** - 2025-05-14T22:12:57

I will get up and work out yku will sleep and if you tell me what you like I can try to make you breakfast


---

### 1333. msg_11526

**You** - 2025-05-14T22:13:01

Kk you go so that


---

### 1334. msg_11527

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:13:17

Sleep with 3 dogs? LOL


---

### 1335. msg_11528

**You** - 2025-05-14T22:13:27

Hrm…


---

### 1336. msg_11529

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:13:41

I will nap


---

### 1337. msg_11530

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:13:47

lol


---

### 1338. msg_11531

**You** - 2025-05-14T22:14:09

We get cleaning done we can do whatever your hearts desire


---

### 1339. msg_11532

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:17:58

Set up my bra pong game?


---

### 1340. msg_11533

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:18:02

lol


---

### 1341. msg_11534

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:19:05

k, I’m going to watch tv for real\. Have a good sleep, I love you and am very much looking forward to spending time with you… not the ring camera part but all the rest :p 😍


---

### 1342. msg_11535

**Meredith Lamb \(\+14169386001\)** - 2025-05-14T22:19:22

Be nice to Carolyn


---

### 1343. msg_11536

**You** - 2025-05-14T22:20:00

I will and I want to play that trains game


---

### 1344. msg_11537

**You** - 2025-05-14T22:20:03

And bra pong


---

### 1345. msg_11538

**You** - 2025-05-14T22:20:06

Just to test it out


---

### 1346. msg_11539

**You** - 2025-05-14T22:20:42

Love you and looking very much forward just to being with you\.\. nite ❤️❤️❤️❤️


---

### 1347. msg_11540

**You** - 2025-05-15T03:55:14

Literally woke 5 mins to alarm sad state of affairs these days… I will need to sleep in to 6 this weekend lol


---

### 1348. msg_11541

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T05:36:48

Or nap\. Cottage naps are better than home naps\. :\)


---

### 1349. msg_11542

**You** - 2025-05-15T05:55:46

As long as it is with you\.


---

### 1350. msg_11543

**You** - 2025-05-15T05:55:58

And maybe some dogs


---

### 1351. msg_11544

**You** - 2025-05-15T06:16:04

So is big tall or big muscles\.\. because one I cannot change but the other well I might want to change my plan\.\. 😝


---

### 1352. msg_11545

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T06:17:30

lol I mean I’m not sure I can like you anymore than I do so honestly, do what you will :\) I’m so running late btw trying to still get out of here


---

### 1353. msg_11546

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T06:17:40

6\.30 is my cut off so no more talking


---

### 1354. msg_11547

**You** - 2025-05-15T06:17:52

Kk love you drive safe


---

### 1355. msg_11548

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T06:53:58

This was a lot more work in the morning than I remember\. Guess I never did it with 3 dogs before lol


---

### 1356. msg_11549

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T06:54:33


*1 attachment(s)*


---

### 1357. msg_11550

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T06:54:37


*1 attachment(s)*


---

### 1358. msg_11551

**You** - 2025-05-15T08:21:11

lol so many dogs\!\! Imagine 5


---

### 1359. msg_11552

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T10:35:48

All good but this place is a mess and going to take me a while to get in shape so you have to be very understanding lol


---

### 1360. msg_11553

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T10:35:24


*1 attachment(s)*


---

### 1361. msg_11554

**You** - 2025-05-15T11:02:17

I want to be helpful not just understanding\.  Go team\!\!


---

### 1362. msg_11555

**You** - 2025-05-15T13:23:49

Leaving in 5


---

### 1363. msg_11556

**You** - 2025-05-15T13:40:02

Ideas what should I stop for food etc I will think too


---

### 1364. msg_11557

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T13:42:44

Reaction: ❤️ from Meredith Lamb
There is literally nothing here


---

### 1365. msg_11558

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T13:42:50

Honestly


---

### 1366. msg_11559

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T13:43:37

Carolyn said that you said that I told Mia about my role\. No\. I haven’t even told her about my separation and have been feeling bad actually\. Need to tell her


---

### 1367. msg_11560

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T13:43:46

lol “Carolyn said that you said”


---

### 1368. msg_11561

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T13:46:23

Omg


---

### 1369. msg_11562

**You** - 2025-05-15T14:55:52

Nooooo


---

### 1370. msg_11563

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:02:26

Ugh F’ing griffin ran away\. Spring does this to him\. So annoying


---

### 1371. msg_11564

**You** - 2025-05-15T16:04:10

22 mins away wondering where the grocery store is past your place or before


---

### 1372. msg_11565

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:06:19

Right in Sundridge


---

### 1373. msg_11566

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:06:37

It is kind of past but only a few minutes


---

### 1374. msg_11567

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:06:43

Foodland in Sundridge


---

### 1375. msg_11568

**You** - 2025-05-15T16:06:46

Kk


---

### 1376. msg_11569

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:09:31

Omg after more than an hour camera not fixed\. I have to go to local IT I guess


---

### 1377. msg_11570

**You** - 2025-05-15T16:09:50

Fun times


---

### 1378. msg_11571

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:10:24

Do I have time to shower before you get here??


---

### 1379. msg_11572

**You** - 2025-05-15T16:10:33

Yeah


---

### 1380. msg_11573

**You** - 2025-05-15T16:10:38

Going to foodland first


---

### 1381. msg_11574

**You** - 2025-05-15T16:10:43

Popcorn


---

### 1382. msg_11575

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:10:48

k lol


---

### 1383. msg_11576

**You** - 2025-05-15T16:10:49

Bananas


---

### 1384. msg_11577

**You** - 2025-05-15T16:10:53

And what else


---

### 1385. msg_11578

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:11:20

Ginger ale, oj, eggs and bread\. Don’t care what kind


---

### 1386. msg_11579

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:11:30

And anything else you eat lol


---

### 1387. msg_11580

**You** - 2025-05-15T16:11:31

K


---

### 1388. msg_11581

**You** - 2025-05-15T16:30:53

So you like pancakes?


---

### 1389. msg_11582

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:31:30

I mean meh


---

### 1390. msg_11583

**You** - 2025-05-15T16:31:35

Wow


---

### 1391. msg_11584

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:31:40

lol


---

### 1392. msg_11585

**You** - 2025-05-15T16:31:42

Ok scratch that
Idea


---

### 1393. msg_11586

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:32:04

I just ea my egsgs and toast or toast and avocado for breakfast usually


---

### 1394. msg_11587

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:32:16

My kids and their cousins like pancakes


---

### 1395. msg_11588

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:32:21

You can make pancakes


---

### 1396. msg_11589

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:32:23

lol


---

### 1397. msg_11590

**You** - 2025-05-15T16:32:35

Nope


---

### 1398. msg_11591

**You** - 2025-05-15T16:32:39

Putting it all back


---

### 1399. msg_11592

**You** - 2025-05-15T16:32:56

Stove works we have pans I can make chicken wings or fingers or whatever eh?


---

### 1400. msg_11593

**You** - 2025-05-15T16:34:42

wtf they have donairs this far north kol


---

### 1401. msg_11594

**You** - 2025-05-15T16:39:12

We need more s’more kits?


---

### 1402. msg_11595

**You** - 2025-05-15T16:39:42

Pocket call


---

### 1403. msg_11596

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:41:37

>
Yes sorry


---

### 1404. msg_11597

**You** - 2025-05-15T16:41:50

Any treats? For yku


---

### 1405. msg_11598

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:41:57

>
Har har


---

### 1406. msg_11599

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:42:19

>
Nah


---

### 1407. msg_11600

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:42:50

Wine?


---

### 1408. msg_11601

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:42:57

LCBO is right up the street


---

### 1409. msg_11602

**You** - 2025-05-15T16:43:09

Yeah I will go


---

### 1410. msg_11603

**You** - 2025-05-15T16:43:17

Just tell me what and how much rofl


---

### 1411. msg_11604

**You** - 2025-05-15T16:44:36

Smart food popcorn?  Just white cheddar?


---

### 1412. msg_11605

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:48:52

Yeah


---

### 1413. msg_11606

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:49:36

>
Just maybe a couple bottles\. Or if you have too much to carry don’t worry\. I have to go to home hardware tomorrow to buy a carpet


---

### 1414. msg_11607

**You** - 2025-05-15T16:55:35

Ok but need clarity on popcorn what was brand and flavour


---

### 1415. msg_11608

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T16:55:46

Just smart food


---

### 1416. msg_11609

**You** - 2025-05-15T16:56:16

But white cheddar?


---

### 1417. msg_11610

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:04:49

Yah


---

### 1418. msg_11611

**You** - 2025-05-15T17:11:03

Fyi I actually just called you my girlfriend in public first time\.\. just kind of popped out\.  Buying wine for… lol


---

### 1419. msg_11612

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:12:31

lol weird


---

### 1420. msg_11613

**You** - 2025-05-15T17:13:49

Well weird is better than annoying


---

### 1421. msg_11614

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:19:03

Definitely


---

### 1422. msg_11615

**You** - 2025-05-15T17:19:38

It a lot of Pinot\. Voice


---

### 1423. msg_11616

**You** - 2025-05-15T17:19:41

Choice


---

### 1424. msg_11617

**You** - 2025-05-15T17:20:19

Both Cabernet Sauvignon and Merlot have low sugar content


---

### 1425. msg_11618

**You** - 2025-05-15T17:20:29

Like same as Pinot


---

### 1426. msg_11619

**You** - 2025-05-15T17:20:42

But different flavour profiles I guess I know nothing


---

### 1427. msg_11620

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:25:15

They are harder on the stomach


---

### 1428. msg_11621

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:25:19

Different grape


---

### 1429. msg_11622

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:25:43

Cab Sauvignon gets you drunker too lol


---

### 1430. msg_11623

**You** - 2025-05-15T17:26:41

Then cab is for tomorrow


---

### 1431. msg_11624

**You** - 2025-05-15T17:26:47

Night


---

### 1432. msg_11625

**You** - 2025-05-15T17:29:18

🙂


---

### 1433. msg_11626

**You** - 2025-05-15T17:30:03

Ok I am coming your way


---

### 1434. msg_11627

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T17:35:07

K tell me when you are at driveway and I will walk out with dogs


---

### 1435. msg_11628

**You** - 2025-05-15T17:41:02

Kk super super anxious at the end of your driveway


---

### 1436. msg_11629

**You** - 2025-05-15T17:41:12

lol


---

### 1437. msg_11630

**You** - 2025-05-15T17:41:33

And now the text isn’t working g


---

### 1438. msg_11631

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T18:30:56

Wifi password is highrock all lower case


---

### 1439. msg_11632

**Meredith Lamb \(\+14169386001\)** - 2025-05-15T18:31:01

Then you can FaceTime


---

### 1440. msg_11633

**You** - 2025-05-15T22:35:47

You suck


---

### 1441. msg_11634

**You** - 2025-05-16T11:48:24

Don’t tell her about Kristina\.


---

### 1442. msg_11635

**You** - 2025-05-16T14:30:58

You know you could come over here……\.


---

### 1443. msg_11636

**Meredith Lamb \(\+14169386001\)** - 2025-05-17T00:35:01


*1 attachment(s)*


---

### 1444. msg_11637

**Meredith Lamb \(\+14169386001\)** - 2025-05-17T14:42:43

https://youtube\.com/watch?v=P2KnD7sfpoA&feature=shared


---

### 1445. msg_11638

**You** - 2025-05-17T15:48:58

Pelee island Pinot noirs??


---

### 1446. msg_11639

**Meredith Lamb \(\+14169386001\)** - 2025-05-17T15:50:44

Sure


---

### 1447. msg_11640

**You** - 2025-05-17T16:11:13

Do you have hot chocolate there?


---

### 1448. msg_11641

**You** - 2025-05-17T16:23:52

Heading back could you please check to see if when I left it disturbed the front door ring\.\. I do t feel the boxes are covering as well\.


---

### 1449. msg_11642

**You** - 2025-05-17T16:23:59

Don’t want to trigger on way back


---

### 1450. msg_11643

**Meredith Lamb \(\+14169386001\)** - 2025-05-17T16:24:49

It’s fine\. Can’t see anything


---

### 1451. msg_11644

**You** - 2025-05-17T16:25:02

Ok then lol


---

### 1452. msg_11645

**You** - 2025-05-17T16:25:07

Omw


---

### 1453. msg_11646

**Meredith Lamb \(\+14169386001\)** - 2025-05-17T16:25:14

k


---

