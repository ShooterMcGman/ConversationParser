# Week 4: Conversation Messages

**Date Range:** 2025-05-04 to 2025-05-10  
**Total Messages:** 2463  
**Generated:** 2025-07-18 21:27:05

---

## 📊 Week Summary

- **Week Number:** 4
- **Messages:** 2463
- **Participants:** 2
- **Message Types:** outgoing, incoming, call-history

## 💬 Conversation Messages

### 1. msg_7731

**You** - 2025-05-04T02:47:56

Reaction: ❤️ from Meredith Lamb
>
Rofl well played………


---

### 2. msg_7732

**You** - 2025-05-04T02:48:13

Sigh ❤️


---

### 3. msg_7733

**You** - 2025-05-04T02:51:24

How are you awake


---

### 4. msg_7734

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:52:04

On and off…


---

### 5. msg_7735

**You** - 2025-05-04T02:52:23

Messy?


---

### 6. msg_7736

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:52:39

lol no


---

### 7. msg_7737

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:52:57

I wish


---

### 8. msg_7738

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:53:03

Though


---

### 9. msg_7739

**You** - 2025-05-04T02:53:05

I just woke up will be hard to go back to sleep now


---

### 10. msg_7740

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:53:13

Too much to do tomorrow


---

### 11. msg_7741

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:53:33

You shouldnt have gotten on your phone


---

### 12. msg_7742

**You** - 2025-05-04T02:54:03

I had to check 1st thing I thought about


---

### 13. msg_7743

**You** - 2025-05-04T02:55:22

If you are tired though I will leave you be


---

### 14. msg_7744

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:55:50

I’m always tired these days\. :p


---

### 15. msg_7745

**You** - 2025-05-04T02:56:18

Well then I should leave you to try to sleep\.


---

### 16. msg_7746

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:56:48

Will you sleep?


---

### 17. msg_7747

**You** - 2025-05-04T02:56:58

Not likely


---

### 18. msg_7748

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:57:18

But you will try


---

### 19. msg_7749

**You** - 2025-05-04T02:58:05

I mean sure I guess pretty awake tho\.  It’s fine I slept straight since 1120


---

### 20. msg_7750

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:58:50

That’s not much sleep


---

### 21. msg_7751

**You** - 2025-05-04T02:59:14

More than I get a lot of times


---

### 22. msg_7752

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T02:59:50

Maybe you just need more sleep to feel better


---

### 23. msg_7753

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T03:00:01

Maybe lack of sleep is driving you nuts


---

### 24. msg_7754

**You** - 2025-05-04T03:01:11

Maybe you are really tired and should just go to bed lol sound like it\.  Don’t worry about me I will do whatever


---

### 25. msg_7755

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T03:01:46

I am tired\.


---

### 26. msg_7756

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T03:02:20

And I worry about you\.


---

### 27. msg_7757

**You** - 2025-05-04T04:07:33

Night love you\.


---

### 28. msg_7758

**You** - 2025-05-04T06:10:28

Reaction: ❤️ from Meredith Lamb
Stayed home and dreamed of us\.  Was nice ❤️


---

### 29. msg_7759

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T09:54:52

Slept in…\. Still not up\. Gummies are good for my sleep apparently\.


---

### 30. msg_7760

**You** - 2025-05-04T09:59:11

Yeah I am getting up now need to do work


---

### 31. msg_7761

**You** - 2025-05-04T10:00:22

Another super fun day\!\! Whee


---

### 32. msg_7762

**You** - 2025-05-04T10:07:40

Demotivated for a number of reasons no matter how successful I am in one place something else falls
Apart
It seems\.\. here there everywhere\. What a mess\.  Changed my Hyksos last night to declutterring my mind and getting rid of negative thoughts but it will take some time to work I think


---

### 33. msg_7763

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:13:42

I think it will eventually all come together but there is a lot of fall out you will probably be dealing with for a long time… I don’t think it means everything is falling apart tho\.


---

### 34. msg_7764

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:13:55

Just bumps in the road


---

### 35. msg_7765

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:14:08

Really big pot holes


---

### 36. msg_7766

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:20:00

I was thinking about your control comment and I’m not doing that intentionally by any means\. But I can see what you mean\. It isn’t you though it is more my life and everything going on and just protecting speed, flow, intensity \(not that I’ve done a good job\)\. This has moved really fast\. Like really… and we aren’t even out of our respective situations yet\. My kids don’t even know\. Gah\. Yet I’m looking at a rental tonight and will have to make some story to them about where I am\.


---

### 37. msg_7767

**You** - 2025-05-04T10:20:15

The only thing I have positive movement on is me physically


---

### 38. msg_7768

**You** - 2025-05-04T10:20:17

lol


---

### 39. msg_7769

**You** - 2025-05-04T10:20:21

228 today


---

### 40. msg_7770

**You** - 2025-05-04T10:20:28

So there is that


---

### 41. msg_7771

**You** - 2025-05-04T10:20:35

I started
252


---

### 42. msg_7772

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:21:19

>
Very amazing … you and Mackenzie right Joe…


---

### 43. msg_7773

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:21:24

\*now


---

### 44. msg_7774

**You** - 2025-05-04T10:21:40

>
The control thing is about protecting yourself


---

### 45. msg_7775

**You** - 2025-05-04T10:21:50

It isn’t about wanting to own me


---

### 46. msg_7776

**You** - 2025-05-04T10:21:59

I think it will break down in time


---

### 47. msg_7777

**You** - 2025-05-04T10:22:06

As you become more comfortable


---

### 48. msg_7778

**You** - 2025-05-04T10:22:18

I was just 85% comfortable
With you immediately


---

### 49. msg_7779

**You** - 2025-05-04T10:22:25

And was willing to put a lot on trust


---

### 50. msg_7780

**You** - 2025-05-04T10:22:29

Am willing


---

### 51. msg_7781

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:22:31

>
I have a lot to protect right now\. My life is a shitstorm\.


---

### 52. msg_7782

**You** - 2025-05-04T10:22:38

I meant yourself


---

### 53. msg_7783

**You** - 2025-05-04T10:22:41

Not everything


---

### 54. msg_7784

**You** - 2025-05-04T10:22:44

Just you


---

### 55. msg_7785

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:22:50

Yeah


---

### 56. msg_7786

**You** - 2025-05-04T10:23:15

I think you have a harder time to let go to give
Over
To someone else
To trust


---

### 57. msg_7787

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:23:17

Well you could impulsively change your mind on me tomorrow\. You do that with decisions and ppl


---

### 58. msg_7788

**You** - 2025-05-04T10:23:18

And rightly so


---

### 59. msg_7789

**You** - 2025-05-04T10:23:25

No


---

### 60. msg_7790

**You** - 2025-05-04T10:23:28

I dont


---

### 61. msg_7791

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:23:29

Yes


---

### 62. msg_7792

**You** - 2025-05-04T10:23:40

I told you I thought about this thing for years


---

### 63. msg_7793

**You** - 2025-05-04T10:23:48

Before deciding to pull the trigger


---

### 64. msg_7794

**You** - 2025-05-04T10:23:57

But when I pull it I am sure


---

### 65. msg_7795

**You** - 2025-05-04T10:24:00

That is the diff


---

### 66. msg_7796

**You** - 2025-05-04T10:24:46

And with you I have been nearly 100% transparent and honest which is like\. I thing before the buys I hold back are to protect me and my perception of what you might do if I open up all the way


---

### 67. msg_7797

**You** - 2025-05-04T10:25:10

So honestly you have nothing to worry about I am saying this and don’t correct me… I am never leaving


---

### 68. msg_7798

**You** - 2025-05-04T10:25:12

Ever


---

### 69. msg_7799

**You** - 2025-05-04T10:25:17

I don’t care about the process


---

### 70. msg_7800

**You** - 2025-05-04T10:25:39

This is not impulsive it is something else
Revelationary


---

### 71. msg_7801

**You** - 2025-05-04T10:25:55

It I am as certain of this and of using absolutes


---

### 72. msg_7802

**You** - 2025-05-04T10:26:15

Again barring you don’t do something terrible which I cannot foresee or believe you would do to me


---

### 73. msg_7803

**You** - 2025-05-04T10:26:27

There that is all there is


---

### 74. msg_7804

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:26:59

And I think I know all that deep down but my head has a very strong protect mode perhaps


---

### 75. msg_7805

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:27:03

Not sure


---

### 76. msg_7806

**You** - 2025-05-04T10:27:12

I head and heart


---

### 77. msg_7807

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:27:18

I really believe what you say like 90%


---

### 78. msg_7808

**You** - 2025-05-04T10:27:32

There are no detours here me


---

### 79. msg_7809

**You** - 2025-05-04T10:27:35

Mer


---

### 80. msg_7810

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:27:35

There is a piece of me that is all “mm Hmmh”


---

### 81. msg_7811

**You** - 2025-05-04T10:27:38

No off ramps


---

### 82. msg_7812

**You** - 2025-05-04T10:27:46

This is not a game


---

### 83. msg_7813

**You** - 2025-05-04T10:27:57

And I have never been more serious


---

### 84. msg_7814

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:28:39

I will try to believe you with everything that I have because I really hope that is true for both of us


---

### 85. msg_7815

**You** - 2025-05-04T10:28:42

Again problem is I cannot show you lol


---

### 86. msg_7816

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:28:52

Yeah


---

### 87. msg_7817

**You** - 2025-05-04T10:29:24

Please
Don’t try please just believe doubt is the killer of relationships my doubt of you and Andrew almost
Broke me


---

### 88. msg_7818

**You** - 2025-05-04T10:29:37

It still bothers me but I can shut it down


---

### 89. msg_7819

**You** - 2025-05-04T10:30:13

I know there is nothing going on I know you aren’t going back to him\.\. I say that over and over\.\. and I force doubt to fuck off\.


---

### 90. msg_7820

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:31:05

I don’t sit and live in doubt\. I just for sure have it but I don’t focus on it tbh and if I could see you, feel you, taste you … it would all go away…\.\.


---

### 91. msg_7821

**You** - 2025-05-04T10:31:42

Yeah and my worry is you cannot last… despite my concerns I know I can last it will just hurt a lot\. But be worth it in the end


---

### 92. msg_7822

**You** - 2025-05-04T10:32:18

I still have that concern\.\. cannot help that one \.  Which is why I wanted to get to a scenario where we could have some
Predictable interaction


---

### 93. msg_7823

**You** - 2025-05-04T10:32:27

And then last night that sounded way the fuck off


---

### 94. msg_7824

**You** - 2025-05-04T10:32:36

So yeah it was a little fought


---

### 95. msg_7825

**You** - 2025-05-04T10:32:38

Rough


---

### 96. msg_7826

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:32:58

I will figure something out


---

### 97. msg_7827

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:33:20

I think I can last


---

### 98. msg_7828

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:33:29

It will just impact my behaviour


---

### 99. msg_7829

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:33:46

But I will do my best obviously\.


---

### 100. msg_7830

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:33:58

All of this is a lot and I still have so much to deal with here


---

### 101. msg_7831

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:34:12

So I’m not too concerned short term


---

### 102. msg_7832

**You** - 2025-05-04T10:34:13

You don’t need to compromise yourself
For this


---

### 103. msg_7833

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:34:18

More longer time


---

### 104. msg_7834

**You** - 2025-05-04T10:34:21

I told you I will deal


---

### 105. msg_7835

**You** - 2025-05-04T10:34:37

The weekends are just the absolute worst


---

### 106. msg_7836

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:35:01

Yeah and getting more and more so


---

### 107. msg_7837

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:35:12

Not even staying the same


---

### 108. msg_7838

**You** - 2025-05-04T10:35:40

Look you keep on with your thing\.\. this is what I am worried about for you things will
Get worse and you will be like fuck it not worth it


---

### 109. msg_7839

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:36:05

No I will not Scott\.


---

### 110. msg_7840

**You** - 2025-05-04T10:36:06

So just don’t let me affect you I will try to keep down the emotions for a while


---

### 111. msg_7841

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:37:10

Reaction: ❤️ from Scott Hicks
I can lie here and imagine kissing your neck and I feel better


---

### 112. msg_7842

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:37:13

I will be fine


---

### 113. msg_7843

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:37:15

lol


---

### 114. msg_7844

**You** - 2025-05-04T10:37:22

Reaction: 😂 from Meredith Lamb
In fact
Lets
Put a moritorium in my emotions for a while\.


---

### 115. msg_7845

**You** - 2025-05-04T10:37:43

>
That is very much one of the numbers for me


---

### 116. msg_7846

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:38:44

I will find them all\. Don’t tell me


---

### 117. msg_7847

**You** - 2025-05-04T10:39:11

>
It will mean shorter convos I think\.\.  because eventually they come out\. I matter what I do\.\. but I think I can manage that\.


---

### 118. msg_7848

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:40:26

I like your emotions but not when they are pulling you into a deep dark hole\.


---

### 119. msg_7849

**You** - 2025-05-04T10:40:41

I also won’t bug you about trip idea anymore as I think it just puts pressure on you\.


---

### 120. msg_7850

**You** - 2025-05-04T10:41:06

Reaction: 😢 from Meredith Lamb
>
Yeah I know that but deep dark holes seem to be the norm lately\.


---

### 121. msg_7851

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:41:36

>
You haven’t been bugging me\. Relax\.


---

### 122. msg_7852

**You** - 2025-05-04T10:41:37

I still have no problems telling you how I feel about you and that hasn’t chenged an inch through all of this only gotten stronger


---

### 123. msg_7853

**You** - 2025-05-04T10:42:31

>
Well it is that and knowing you cannot do anything about it\.  I get disappointed so best to just forget about it\.\. for now at least\.  I will take some time for me because I need it I will figure out what that looks like


---

### 124. msg_7854

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:43:29

When Mackenzie and Andrew and Mar Mar are in Edmonton at nationals maybe we can swing something


---

### 125. msg_7855

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:43:38

Work dinner lol


---

### 126. msg_7856

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:44:40

We will see … I’m not opposed to a trip at all but it can’t be suspicious and I need to get my ass moved out of this house so I may need to take time off to move


---

### 127. msg_7857

**You** - 2025-05-04T10:48:32

Yep understood I get it\.\. sorry I just had to go upstairs to make my morning drink and take my pills


---

### 128. msg_7858

**You** - 2025-05-04T10:49:35

Again somehow I need to shit down a bit for a while lower expectations\.\. and I think that will help me cope\.\. if I can do that or not is a good question\.


---

### 129. msg_7859

**You** - 2025-05-04T10:50:01

But I cannot remain this open and vulnerable all the time and not take body blows every days


---

### 130. msg_7860

**You** - 2025-05-04T10:50:17

Like it isn’t what you are doing to me it is life


---

### 131. msg_7861

**You** - 2025-05-04T10:51:34

Deleted?


---

### 132. msg_7862

**You** - 2025-05-04T10:51:36

lol


---

### 133. msg_7863

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:52:03

I hope it isn’t me\. I will open up to you about anything you want\. I just may not exactly initiate these big msgs of emotional revelations on the fly while focusing on all this other crap


---

### 134. msg_7864

**You** - 2025-05-04T10:52:22

I don’t need you too especially not now


---

### 135. msg_7865

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:53:09

Finding balancing all of the stuff …\. Challenging\. And holy, the secrecy piece is about to make me lose it\. I have 2 secrecy pieces : 1\. My kids and then 2\. Us


---

### 136. msg_7866

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:54:05

I feel like I’m navigating this strange world where everyone in my life knows a different version of my reality right now and I have to try to remember what that version is constantly


---

### 137. msg_7867

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:54:09

😜


---

### 138. msg_7868

**You** - 2025-05-04T10:54:26

Yep I know that feeling \.\. but I was built for that\.


---

### 139. msg_7869

**You** - 2025-05-04T10:54:38

That is exactly how my brain helps me\.


---

### 140. msg_7870

**You** - 2025-05-04T10:55:19

When it is not stomping on everything else I don’t know why it does this to me it is really distressing but it has consistently through my whole life\.


---

### 141. msg_7871

**You** - 2025-05-04T10:55:25

Might be a childhood thing


---

### 142. msg_7872

**You** - 2025-05-04T10:56:04

I was never good enough\.\. as much as
I loved
My mum and we were as tight as
You could be, that is how I was raised and it was kind of relentless and brutal


---

### 143. msg_7873

**You** - 2025-05-04T10:56:22

And I mean that shapes you


---

### 144. msg_7874

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:56:31

>
This tracks incredibly…\.


---

### 145. msg_7875

**You** - 2025-05-04T10:56:37

Yep


---

### 146. msg_7876

**You** - 2025-05-04T10:56:58

I would be compared
To
Others to my sister but always in a manner Thant
Made
Me less than


---

### 147. msg_7877

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:57:02

I feel it in your anxieties about us


---

### 148. msg_7878

**You** - 2025-05-04T10:57:06

Because she thought it would motivate me


---

### 149. msg_7879

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:57:18

They are all related to not being good enough it seems or either fucking something up


---

### 150. msg_7880

**You** - 2025-05-04T10:57:27

You are soo important to me it is not even rational


---

### 151. msg_7881

**You** - 2025-05-04T10:57:48

So yeah my brain went into overdrive, and so did my heart same time


---

### 152. msg_7882

**You** - 2025-05-04T10:57:58

And my heart had t done shit for a
Long long time


---

### 153. msg_7883

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:57:59

Our relationship is not built on performance though\. I am not connected to you for that reason\.


---

### 154. msg_7884

**You** - 2025-05-04T10:58:15

It isn’t necessarily performance it is connection


---

### 155. msg_7885

**You** - 2025-05-04T10:58:33

I mean I worry about performance don’t get me wrong we talked kind of about that the other night


---

### 156. msg_7886

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:58:35

I mean performance is all aspects


---

### 157. msg_7887

**You** - 2025-05-04T10:58:42

You got drunk disk your tap dance passed out


---

### 158. msg_7888

**You** - 2025-05-04T10:58:48

And we avoided further discussion


---

### 159. msg_7889

**You** - 2025-05-04T10:58:55

lol


---

### 160. msg_7890

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:59:16

lol I tapped danced? Wow


---

### 161. msg_7891

**You** - 2025-05-04T10:59:19

You can scroll back and see if you are curious


---

### 162. msg_7892

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:59:29

Oh I did scroll back yday


---

### 163. msg_7893

**You** - 2025-05-04T10:59:30

Selective responses etc


---

### 164. msg_7894

**You** - 2025-05-04T10:59:40

How far back did you go


---

### 165. msg_7895

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T10:59:56

To the beginning of the night


---

### 166. msg_7896

**You** - 2025-05-04T11:00:06

Of yesterday or the night before


---

### 167. msg_7897

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:00:13

Night before


---

### 168. msg_7898

**You** - 2025-05-04T11:00:25

Ah ok then you got to reread all the fun


---

### 169. msg_7899

**You** - 2025-05-04T11:00:28

lol


---

### 170. msg_7900

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:00:51

Yep and I wasn’t avoiding per se\. I seriously was really stoned\.


---

### 171. msg_7901

**You** - 2025-05-04T11:01:27

Kk well don’t worry again I am not needing you to open up about anything right now so we can all relax
And take a breath


---

### 172. msg_7902

**You** - 2025-05-04T11:02:05

The timeline has changed and expected accessibility has changed so speed has changed


---

### 173. msg_7903

**You** - 2025-05-04T11:02:11

So I need to change


---

### 174. msg_7904

**You** - 2025-05-04T11:02:25

Not in a bad way mer


---

### 175. msg_7905

**You** - 2025-05-04T11:02:38

❤️❤️❤️❤️


---

### 176. msg_7906

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:02:53

lol


---

### 177. msg_7907

**You** - 2025-05-04T11:02:58

It isn’t just your neck I want\.\.


---

### 178. msg_7908

**You** - 2025-05-04T11:03:01

Fyi


---

### 179. msg_7909

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:03:29

Is there something that is like super annoying you that I am not sharing out loud? Or just that weekend because I wouldn’t let you


---

### 180. msg_7910

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:04:19

>
Same…\. ❤️


---

### 181. msg_7911

**You** - 2025-05-04T11:04:22

That isn’t super annoying me\. It was frustrating me because 1\. Fair play lol\.  2\. It has been my experience that that is enjoyable for others and I wanted to please you


---

### 182. msg_7912

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:04:44

So here’s my insecurity


---

### 183. msg_7913

**You** - 2025-05-04T11:04:57

That is all and then the refusal
Obviously begs questions but wait


---

### 184. msg_7914

**You** - 2025-05-04T11:05:01

You don’t have
To


---

### 185. msg_7915

**You** - 2025-05-04T11:05:13

I told you you don’t need to do this I can wait fine


---

### 186. msg_7916

**You** - 2025-05-04T11:06:08

These are pretty tough topics we don’t need to wade
In now\.\.


---

### 187. msg_7917

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:07:27

But it is so cliché I hate even talking about it\. I have never dated anyone 1\. Post kids and 2\. At this weight\. Like never been in this realm before even weight wise\. So it is all kind of unsettling and new to me\. Andrew was used to it but when we got together even I was very fit\. Anyway it is an odd one for me and definitely an insecurity\. Especially after 3 c sections\. Even when I get fit and work out etc etc etc I have a c section shelf\. I try not to focus on all that crap but it definitely bothers me when like lights are shone on it\.


---

### 188. msg_7918

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:08:00

I never complain about it bc it is even annoying hearing it come out of my mouth\. Never complained to Andrew about it until recently\.


---

### 189. msg_7919

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:08:10

The whole $200k thing


---

### 190. msg_7920

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:08:31

I was like “are you fucking kidding me?\!” I have a c section shelf for life and you care about $200k


---

### 191. msg_7921

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:08:38

He didn’t even know what the fuck it was


---

### 192. msg_7922

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:08:42

Had to google it


---

### 193. msg_7923

**You** - 2025-05-04T11:08:48

We are
Generally talking about intimacy here\. I think


---

### 194. msg_7924

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:08:54

My last c section was 12 yrs ago\.


---

### 195. msg_7925

**You** - 2025-05-04T11:08:55

Not specifics


---

### 196. msg_7926

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:09:24

>
This was more related to last weekend and my “control”


---

### 197. msg_7927

**You** - 2025-05-04T11:09:43

Ok I mean if it bothers you that much I paid 15 k for Jaimie to have a surgery that she wanted that I gave zero fucks about


---

### 198. msg_7928

**You** - 2025-05-04T11:09:48

But she did it for herself


---

### 199. msg_7929

**You** - 2025-05-04T11:10:05

Like I think you are beautiful


---

### 200. msg_7930

**You** - 2025-05-04T11:10:08

Every inch


---

### 201. msg_7931

**You** - 2025-05-04T11:10:15

Nothing to be self conscious about


---

### 202. msg_7932

**You** - 2025-05-04T11:10:19

At all


---

### 203. msg_7933

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:10:26

I wanted to have that surgery also\. Andrew got mad at me when I suggested it\. 🙄


---

### 204. msg_7934

**You** - 2025-05-04T11:10:36

It is your body mer


---

### 205. msg_7935

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:10:56

That’s not the way he worked…\. Entirely\.  🙄


---

### 206. msg_7936

**You** - 2025-05-04T11:11:06

If you are ever curious and want to know I will tell you\.


---

### 207. msg_7937

**You** - 2025-05-04T11:11:17

But it IS your body not his not
Mine\.


---

### 208. msg_7938

**You** - 2025-05-04T11:12:06

I just want to make you happy in every way that I can\.\.  but if it makes you uncomfortable
Then I don’t want to do it\.


---

### 209. msg_7939

**You** - 2025-05-04T11:12:28

Because
It will achieve the opposite and I would hate to find out you did something you didn’t want to to make me happy


---

### 210. msg_7940

**You** - 2025-05-04T11:12:34

Like it would really bother me


---

### 211. msg_7941

**You** - 2025-05-04T11:13:28

But j 100% had that surgery actually it was more like 5000 she also had a breast reduction which she very
Much regrets now\.


---

### 212. msg_7942

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:13:43

I’m just in a major transition period\. So I’m not super concerned\. Trying to get back to me weight of like 1\-2 years ago and get back to working out \.\. all while going through this separation crap and kids\.


---

### 213. msg_7943

**You** - 2025-05-04T11:13:45

I think it was 5 for stomach and 10’for all else


---

### 214. msg_7944

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:14:12

>
Oh I was talking about breast reduction what surgery are you talking about?


---

### 215. msg_7945

**You** - 2025-05-04T11:14:16

Yeah I know\.\. part
Of why I want us to get together finally we can support each other and grow together as we do it


---

### 216. msg_7946

**You** - 2025-05-04T11:14:32

Well you said something about shelf


---

### 217. msg_7947

**You** - 2025-05-04T11:14:39

Which is what Jaimie had removed


---

### 218. msg_7948

**You** - 2025-05-04T11:14:42

Maybe not same thing


---

### 219. msg_7949

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:14:51

Did she have c sections


---

### 220. msg_7950

**You** - 2025-05-04T11:15:03

She did not but she had a shelf
Or whatever she called it


---

### 221. msg_7951

**You** - 2025-05-04T11:15:06

There is a word


---

### 222. msg_7952

**You** - 2025-05-04T11:15:10

And it wouldn’t go away


---

### 223. msg_7953

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:15:11

Ah


---

### 224. msg_7954

**You** - 2025-05-04T11:15:15

No matter how much she lost


---

### 225. msg_7955

**You** - 2025-05-04T11:15:27

You feel you need a breast reduction?


---

### 226. msg_7956

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:15:27

Mine is c section related


---

### 227. msg_7957

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:15:53

C section shelf can’t be fixed to my knowledge\. It goes so deep\. The incision


---

### 228. msg_7958

**You** - 2025-05-04T11:16:00

I mean I have nothing but positive things to say in that department mind you but wiuld support whatever you want lol


---

### 229. msg_7959

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:16:22

Like it is actually numb all around the incision and you can feel how deep it goes\. I cant see them removing that


---

### 230. msg_7960

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:16:52

>
I mean of course but he freaked out in my ass\.


---

### 231. msg_7961

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:16:57

\*on


---

### 232. msg_7962

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:17:03

We have a major argument


---

### 233. msg_7963

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:17:13

\*had omg autocorrect


---

### 234. msg_7964

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:17:35

Major argument \(no yelling tho lol\)


---

### 235. msg_7965

**You** - 2025-05-04T11:17:41

So I will suggest


---

### 236. msg_7966

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:17:43

So I just didn’t do it


---

### 237. msg_7967

**You** - 2025-05-04T11:17:45

The following


---

### 238. msg_7968

**You** - 2025-05-04T11:17:55

You go see a plastic surgeon


---

### 239. msg_7969

**You** - 2025-05-04T11:18:00

Because j did not


---

### 240. msg_7970

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:18:00

When I lose weight it becomes less of an issue for me


---

### 241. msg_7971

**You** - 2025-05-04T11:18:09

And she has no feeling there anymore


---

### 242. msg_7972

**You** - 2025-05-04T11:18:22

And it never came back


---

### 243. msg_7973

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:18:22

Yes I read about complications like that


---

### 244. msg_7974

**You** - 2025-05-04T11:18:30

And she is fucking miserable about that


---

### 245. msg_7975

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:18:51

My lower abdomen is like that from c section\. Definitely weird feeling


---

### 246. msg_7976

**You** - 2025-05-04T11:19:04

Gemini says for the shelf thing it is very similar to j and there are 2\-3 surgical options coupled with non surgical


---

### 247. msg_7977

**You** - 2025-05-04T11:19:11

Some of which would be covered by benefits


---

### 248. msg_7978

**You** - 2025-05-04T11:19:31

Do you want me to paste it


---

### 249. msg_7979

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:19:36

And I can just lose weight and work out\. It isn’t as much of an issue if I’m doing that


---

### 250. msg_7980

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:19:50

No I’m going to start working out again


---

### 251. msg_7981

**You** - 2025-05-04T11:19:56

For sure same things for upper body


---

### 252. msg_7982

**You** - 2025-05-04T11:19:59

Push\-ups


---

### 253. msg_7983

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:20:10

That’s actually my favourite exercise


---

### 254. msg_7984

**You** - 2025-05-04T11:20:12

It has an effect so I am told


---

### 255. msg_7985

**You** - 2025-05-04T11:20:17

Yeah I like push\-ups


---

### 256. msg_7986

**You** - 2025-05-04T11:21:17

Not sure what I am at in a one time trial but it would be about 50 okus I think\.\. I have done\. Fair bit of work on upper body


---

### 257. msg_7987

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:21:50

I used to do 100 every workout


---

### 258. msg_7988

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:21:55

Built up to that tho


---

### 259. msg_7989

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:21:57

Over time


---

### 260. msg_7990

**You** - 2025-05-04T11:22:06

Well I want you to know in the future if
You ever wanted to consider anything g I would be 100% supportive but know I love as
Much as I do just as you are right this second


---

### 261. msg_7991

**You** - 2025-05-04T11:22:20

That is a lot of push\-ups\.\. lol


---

### 262. msg_7992

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:22:32

Everyone used to make fun of me


---

### 263. msg_7993

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:22:47

It is really only 4 sets of 25


---

### 264. msg_7994

**You** - 2025-05-04T11:22:49

Why\.\. it is awesome


---

### 265. msg_7995

**You** - 2025-05-04T11:23:07

If
You are doing 4 sets of straight 25
Push\-ups that is boss\.


---

### 266. msg_7996

**You** - 2025-05-04T11:23:44

I will resist the urge to lift tonight and just go back in to walk and shit\.


---

### 267. msg_7997

**You** - 2025-05-04T11:23:59

When is Andrew getting back\.\. tonight sometime I guess


---

### 268. msg_7998

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:24:04

Reaction: ❤️ from Scott Hicks
One of my goals to get back\. If I can get back to regular workouts I don’t need any surgeries

*1 attachment(s)*


---

### 269. msg_7999

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:24:25

He gets back tomorrow morning


---

### 270. msg_8000

**You** - 2025-05-04T11:25:07

Yeah I think we will get along fine\.\. I think you just need the space and the comfort to be intense I don’t think we are that far
Off
From each other I think you will be surprised


---

### 271. msg_8001

**You** - 2025-05-04T11:25:22

I think when you love
Someone that deep a lot of things change


---

### 272. msg_8002

**You** - 2025-05-04T11:26:43

I am about 4% from abs again I think end of this week you def had abs srsly


---

### 273. msg_8003

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:26:44

>
I’m internally intense\. You are externally\.


---

### 274. msg_8004

**You** - 2025-05-04T11:26:58

I am both internally with myself


---

### 275. msg_8005

**You** - 2025-05-04T11:27:12

And then I let it out in the form of emotions


---

### 276. msg_8006

**You** - 2025-05-04T11:27:24

Which again and I apologize has not happened like this before


---

### 277. msg_8007

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:28:31

You do not have to apologize to me\. I’m also experiencing something on a level that I have not before and I guess I just process it differently…


---

### 278. msg_8008

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:28:42

But I am processing it\.


---

### 279. msg_8009

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:31:42

And I’m dealing with so many other factors punching me in the head\. Example… Andrew making such a big deal about his fucking $200k\. This shit bugs me and I have to process it too at the same time as all of us/this\. It is just a lot


---

### 280. msg_8010

**You** - 2025-05-04T11:33:30

Yeah I know


---

### 281. msg_8011

**You** - 2025-05-04T11:34:34

I am trying not to think about it


---

### 282. msg_8012

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:35:52

Plus my mom might be legit like dying or something\.  There’s that too…\.  And Andrew keeps saying shit about my family in this whole separation\. He is basically like nails on a chalkboard\.


---

### 283. msg_8013

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:36:20

She’s having a colonoscopy and endoscopy this Wednesday


---

### 284. msg_8014

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:36:24

More tests


---

### 285. msg_8015

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:36:32

😵‍💫


---

### 286. msg_8016

**You** - 2025-05-04T11:36:54

I really want to meet her


---

### 287. msg_8017

**You** - 2025-05-04T11:36:58

Would she be willing


---

### 288. msg_8018

**You** - 2025-05-04T11:37:01

For real


---

### 289. msg_8019

**You** - 2025-05-04T11:37:13

Coffee tea or anything


---

### 290. msg_8020

**You** - 2025-05-04T11:37:17

I would take her out


---

### 291. msg_8021

**You** - 2025-05-04T11:37:31

Just me though


---

### 292. msg_8022

**You** - 2025-05-04T11:37:33

Not you


---

### 293. msg_8023

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:37:37

She’s pretty sick


---

### 294. msg_8024

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:37:40

Not me


---

### 295. msg_8025

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:37:41

What


---

### 296. msg_8026

**You** - 2025-05-04T11:37:51

I want her to get to know me


---

### 297. msg_8027

**You** - 2025-05-04T11:38:06

I want to get to know her


---

### 298. msg_8028

**You** - 2025-05-04T11:38:12

It is important to me


---

### 299. msg_8029

**You** - 2025-05-04T11:38:19

I thought there was more time


---

### 300. msg_8030

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:38:31

You will be getting a different version of her\. But she is still kind of there


---

### 301. msg_8031

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:38:40

There likely is but who knows


---

### 302. msg_8032

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:38:55

They don’t know what is wrong with her and she legit hasn’t been able to eat in almost a year


---

### 303. msg_8033

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:39:27

She’s lost like 35–40 lbs


---

### 304. msg_8034

**You** - 2025-05-04T11:39:44

I am gentle\.  And I get it


---

### 305. msg_8035

**You** - 2025-05-04T11:39:53

Only if she wants to


---

### 306. msg_8036

**You** - 2025-05-04T11:40:00

It the offer is there


---

### 307. msg_8037

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:40:22

She will tell you that you are stupid and reckless lol


---

### 308. msg_8038

**You** - 2025-05-04T11:40:30

If were her I would want to meet me


---

### 309. msg_8039

**You** - 2025-05-04T11:40:41

She might and i will tell her my story


---

### 310. msg_8040

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:41:18

It would able an interesting conversation for sure lol


---

### 311. msg_8041

**You** - 2025-05-04T11:41:54

I mean it is your call if you are comfortable feel free to share the offer with her \.\. I would be interested in her response


---

### 312. msg_8042

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:41:58

Gotta do her bday next weekend and get that over with


---

### 313. msg_8043

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:42:32

Maelle tomorrow, mom next weekend, then Mac June 1


---

### 314. msg_8044

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:42:36

Then I’m free


---

### 315. msg_8045

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:42:49

From birthday duties for a while


---

### 316. msg_8046

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:43:16

Until a couple of virgos I know


---

### 317. msg_8047

**You** - 2025-05-04T11:43:33

Like i said I will leave it with you I always wanted to meet her but when you said that I felt a sense of urgency


---

### 318. msg_8048

**You** - 2025-05-04T11:43:45

I don’t do birthdays


---

### 319. msg_8049

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:43:58

You and my dad are both virgos


---

### 320. msg_8050

**You** - 2025-05-04T11:44:04

I do them for other people


---

### 321. msg_8051

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:44:06

Oh you are doing your birthday this year


---

### 322. msg_8052

**You** - 2025-05-04T11:44:32

I will let other people do shit because it made them happy how it always was


---

### 323. msg_8053

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:44:44

I mean same


---

### 324. msg_8054

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:44:54

But you and I will do it properly


---

### 325. msg_8055

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:44:58

Not about that


---

### 326. msg_8056

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:45:28

Just a day to properly thank the universe for all things Scott


---

### 327. msg_8057

**You** - 2025-05-04T11:46:30

lol that is a long way off mer\.\. not focusing that far out yet\.


---

### 328. msg_8058

**You** - 2025-05-04T11:46:39

So next week is her bday right\.


---

### 329. msg_8059

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:46:47

No may 14


---

### 330. msg_8060

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:46:55

We are doing it next week tho


---

### 331. msg_8061

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:46:58

Andrew was mad


---

### 332. msg_8062

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:47:15

He’s like “I guess I will go to my moms ALONE on Mother’s Day”


---

### 333. msg_8063

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:47:33

I looked at him and was like “you know I’m a fucking mother too right?”


---

### 334. msg_8064

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:47:37

Jesus Christ


---

### 335. msg_8065

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:47:47

I can’t even with him anymore


---

### 336. msg_8066

**You** - 2025-05-04T11:47:59

Eesh


---

### 337. msg_8067

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:48:08

Little concerned about sharing the cottage\. Another stressor / thing to process now


---

### 338. msg_8068

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:48:16

But I think I’m going to do it anyway


---

### 339. msg_8069

**You** - 2025-05-04T11:48:24

Yeah I know\.\. you will for
Your kids thigh


---

### 340. msg_8070

**You** - 2025-05-04T11:48:33

Though I already knew that


---

### 341. msg_8071

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:48:44

It is just going to require conversations either him


---

### 342. msg_8072

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:48:46

Ughhhhh


---

### 343. msg_8073

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:48:54

\*with him


---

### 344. msg_8074

**You** - 2025-05-04T11:49:35

I think part of me is concerned that until we actually can get to a point where everyone knows and then everyone is comfortable and then Andrew doesn’t freak if I am around kids\.\. we are a long ways off from spending time together\.\. like a long long something I thought about last night


---

### 345. msg_8075

**You** - 2025-05-04T11:49:58

You guys will have busy weekends all summer right\.\. like it is what it is… just thinking through


---

### 346. msg_8076

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:50:12

My therapist would say Andrew has no right to any of my decisions\.


---

### 347. msg_8077

**You** - 2025-05-04T11:50:23

He does re his children


---

### 348. msg_8078

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:50:55

>
No\. We hardly went up together last year\. Mostly separately\. When I was babysitting those 5 dogs he was in the uk, for example\. I go up a lot by myself\.


---

### 349. msg_8079

**You** - 2025-05-04T11:51:27

Ah k\.\. well I will be challenged anyways unless I y maddie home for a week
Or two in summer


---

### 350. msg_8080

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:51:30

>
What? No\. If I want to have ppl around my children, they are old enough\. My choice at this point imo


---

### 351. msg_8081

**You** - 2025-05-04T11:51:36

Which would be only likely if I can get Jaimie to buy


---

### 352. msg_8082

**You** - 2025-05-04T11:51:42

Which I am trying again today


---

### 353. msg_8083

**You** - 2025-05-04T11:52:16

>
I just want to be careful
Don’t want them to hate me or give Andrew cause\.\.
And we can only do that after job shift
I think


---

### 354. msg_8084

**You** - 2025-05-04T11:52:38

Which at this point knowing how you feel about the job still
Might make
The most sense for you


---

### 355. msg_8085

**You** - 2025-05-04T11:52:45

And anyone would take you as a 620


---

### 356. msg_8086

**You** - 2025-05-04T11:52:50

510


---

### 357. msg_8087

**You** - 2025-05-04T11:52:54

Anyone lol


---

### 358. msg_8088

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:53:05

Yeah I will be careful also… for my kids sake\.


---

### 359. msg_8089

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:53:13

And your sake\.


---

### 360. msg_8090

**You** - 2025-05-04T11:53:21

You could suggest work life balance
Given everything else


---

### 361. msg_8091

**You** - 2025-05-04T11:53:28

Yeah I really want them to like me


---

### 362. msg_8092

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:53:49

I think I will have options\.


---

### 363. msg_8093

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:53:56

I just need to get in a rental first\.


---

### 364. msg_8094

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:54:23

Honestly if I have to move and move jobs at the same time, my getting wasted weekends will increase\.


---

### 365. msg_8095

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:54:26

Too much\.


---

### 366. msg_8096

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:54:37

Need to focus on getting out first\.


---

### 367. msg_8097

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:54:47

We haven’t separated our bank accounts yet either


---

### 368. msg_8098

**You** - 2025-05-04T11:54:52

No I get it but as I said to j sometimes timing doesn’t work


---

### 369. msg_8099

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:55:01

True


---

### 370. msg_8100

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:55:09

But there are no work opps right now


---

### 371. msg_8101

**You** - 2025-05-04T11:56:34

Yeah I know but I will know what is coming too


---

### 372. msg_8102

**You** - 2025-05-04T11:56:49

I get it mer it is a lot same here


---

### 373. msg_8103

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T11:57:49

>
k, well I am all for moving if there is something\. It isn’t that I don’t like the role, it is just so difficult right now with separating and you/i\. I can’t focus at all


---

### 374. msg_8104

**You** - 2025-05-04T11:59:14

I will help you


---

### 375. msg_8105

**You** - 2025-05-04T11:59:18

Not rescue you


---

### 376. msg_8106

**You** - 2025-05-04T11:59:30

Help you\.\. just like you do me\.


---

### 377. msg_8107

**You** - 2025-05-04T12:00:41

Reaction: ❤️ from Meredith Lamb
I totally see you as a partner and an equal and awesome in every
Way\.\. I am so excited\.\. part
If the problem if I could
Just focus on excitement and nothing else I would be I\. A high for months and months\.


---

### 378. msg_8108

**You** - 2025-05-04T12:02:12

Going to need a
Min
Being summoned but the above is all
True


---

### 379. msg_8109

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T12:04:01

I think your love language is service\. Lol it’s ok\. I appreciate the non\-rescuing though\. :\) I would like us to not have that dynamic too much in one direction … if it is balanced I’m ok with it\. k, I should shower and take this kid to Yorkdale :p Yaye gah


---

### 380. msg_8110

**You** - 2025-05-04T12:16:51

Yeah go get it done enjoy the shower\.\. my love language is love\.\. period\.\. me wanting to help or make
You happy or do anything is just part
Of that it doesn’t define it


---

### 381. msg_8111

**You** - 2025-05-04T12:26:00

Holy fuck you need to watch snl opening from last night and the weekend report\.


---

### 382. msg_8112

**You** - 2025-05-04T12:26:21

Literally 90’s Level offensive I loved
It\.


---

### 383. msg_8113

**You** - 2025-05-04T12:33:42

Srsly though I would ask one thing if it is not too much I would love to see if there is any way to try the morning thing\.\. I do think it would make a difference for
Both of us\.


---

### 384. msg_8114

**You** - 2025-05-04T12:33:55

Anyhow you get going I have to get to work here\.


---

### 385. msg_8115

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T12:34:45

>
Will watch tonight


---

### 386. msg_8116

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T12:35:31

>
Ok 🙂


---

### 387. msg_8117

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T12:35:35

Reaction: ❤️ from Scott Hicks
Sold


---

### 388. msg_8118

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T12:35:58

That was difficult eh ;\)


---

### 389. msg_8119

**You** - 2025-05-04T12:37:10

Ok I will have several options for
You to consider later
lol\.\. my wake up time is going to be interesting tomorrow\.


---

### 390. msg_8120

**You** - 2025-05-04T12:39:13

She just agreed to speak with my realtor/best friend back home\.\. like immediately… so that is a good sign\.


---

### 391. msg_8121

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T12:47:11

That’s good\.


---

### 392. msg_8122

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:03:03

One thing you don’t know about me\. I used to be super obsessed with rowing until Covid happened\. My laser skull was my baby\. Then Covid happened and everything all went to shit and my skull has sat untouched for probably 3 years

*1 attachment(s)*


---

### 393. msg_8123

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:12:48


*1 attachment(s)*


---

### 394. msg_8124

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:13:39

Even in the freezing cold I would row and row and row\. Escape my kids and family constantly lol

*1 attachment(s)*


---

### 395. msg_8125

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:14:45

The only nice thing Andrew ever bought me\. Altho he would argue the skull is half his I bet


---

### 396. msg_8126

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:28:12

Sort of a private obsession\.
People: “what did you do off work?”
Me: “take care of my kids 🙈”


---

### 397. msg_8127

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:28:19

I did but I did a lot rowing too


---

### 398. msg_8128

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:28:21

lol


---

### 399. msg_8129

**You** - 2025-05-04T13:36:07

Would you teach me


---

### 400. msg_8130

**You** - 2025-05-04T13:36:16

I have never and would love to go with you


---

### 401. msg_8131

**You** - 2025-05-04T13:36:28

And please keep sending me as many pics as you want especially of you\.


---

### 402. msg_8132

**You** - 2025-05-04T13:37:25

The call was amazing with Mike I will send you the house she is looking at\.\. it is new and beautiful\.\. but it means a quicker closing and means I have to sort out a ton of financial shit
Asap


---

### 403. msg_8133

**You** - 2025-05-04T13:37:38

And cancel my viewing tomorrow


---

### 404. msg_8134

**You** - 2025-05-04T13:37:51

Because I will be in this house
For a while\.


---

### 405. msg_8135

**You** - 2025-05-04T13:42:23

Check out this listing
https://realtor\.ca/real\-estate/27592698/71\-petersfield\-street\-lower\-coverdale?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 406. msg_8136

**You** - 2025-05-04T13:43:13

Would want to get her a generator since it is a ways from town she would be in sceptic and well\.\. all manageable needs
Finished basement but I know a guy\.


---

### 407. msg_8137

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:47:03

>
Yeah but some ppl hate it\. Requires a lot of balance\.


---

### 408. msg_8138

**You** - 2025-05-04T13:47:40

I have that


---

### 409. msg_8139

**You** - 2025-05-04T13:47:49

Not worried even a little


---

### 410. msg_8140

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:47:58

lol a lot of ppl lose it on a skull


---

### 411. msg_8141

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:48:24

I have confidence in you though


---

### 412. msg_8142

**You** - 2025-05-04T13:49:02

So ego \- there aren’t a lot of things that I have tried that require some degree of strength balance coordination reaction time\.\. that I haven’t been able to get good at\.


---

### 413. msg_8143

**You** - 2025-05-04T13:49:12

Also I am insane when it comes to challenges


---

### 414. msg_8144

**You** - 2025-05-04T13:49:26

And even more insane when it comes to you\.


---

### 415. msg_8145

**You** - 2025-05-04T13:49:49

You think I was motivated to learn guitar\.\. I will crush skulling


---

### 416. msg_8146

**You** - 2025-05-04T13:49:57

😝


---

### 417. msg_8147

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:50:42

Have you kayaked?


---

### 418. msg_8148

**You** - 2025-05-04T13:51:39

Yep


---

### 419. msg_8149

**You** - 2025-05-04T13:51:52

It a ton but it wasn’t hard


---

### 420. msg_8150

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:51:54

Good start \- a lot easier to balance


---

### 421. msg_8151

**You** - 2025-05-04T13:51:54

Not


---

### 422. msg_8152

**You** - 2025-05-04T13:52:05

And again I will learn fast


---

### 423. msg_8153

**You** - 2025-05-04T13:52:22

I don’t have insecurities there


---

### 424. msg_8154

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:52:22

Kayaking is great … it is the easiest for sure\.


---

### 425. msg_8155

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:52:42

We have 2 kayaks but one is more of a kid one


---

### 426. msg_8156

**You** - 2025-05-04T13:53:25

I will buy one when the time is right and add the rowing machine to my workout


---

### 427. msg_8157

**You** - 2025-05-04T13:53:51

My back is pretty solid but can always get better and it is good for upper body and back anyways


---

### 428. msg_8158

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:54:17

Just do push ups


---

### 429. msg_8159

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:54:28

Rowing is easy if you do push ups I find


---

### 430. msg_8160

**You** - 2025-05-04T13:54:37

Ok…\.


---

### 431. msg_8161

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:54:42

Otherwise I struggle\. Like now I would struggle so badly


---

### 432. msg_8162

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T13:56:19

Cottages are for fit ppl\. I struggle there now


---

### 433. msg_8163

**You** - 2025-05-04T13:56:40

Reaction: 😮 from Meredith Lamb

*1 attachment(s)*


---

### 434. msg_8164

**You** - 2025-05-04T13:56:47

I am not worried


---

### 435. msg_8165

**You** - 2025-05-04T13:58:19

We can struggle and get good together


---

### 436. msg_8166

**You** - 2025-05-04T14:00:52

Also after
Chest
Day yesterday… maybe would be better with a few days off


---

### 437. msg_8167

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:03:11

I’m at Yorkdale and opened that lol


---

### 438. msg_8168

**You** - 2025-05-04T14:13:50

I told my sister


---

### 439. msg_8169

**You** - 2025-05-04T14:14:04

Well it only matters if you watched it and were like dammmmmmmm


---

### 440. msg_8170

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:14:20

>
I was and it makes me want to start again


---

### 441. msg_8171

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:14:27

>
And…\.


---

### 442. msg_8172

**You** - 2025-05-04T14:14:34

She was super happy


---

### 443. msg_8173

**You** - 2025-05-04T14:14:38

Honestly


---

### 444. msg_8174

**You** - 2025-05-04T14:14:52

She asked your name and wanted to know all kinds of shit


---

### 445. msg_8175

**You** - 2025-05-04T14:14:58

But her daughter was coming to the car


---

### 446. msg_8176

**You** - 2025-05-04T14:15:03

So we will connect again


---

### 447. msg_8177

**You** - 2025-05-04T14:15:31

Maybe if we can talk later I can fill you in more similar
To last night if
Little shadow isn’t
Lurking lol


---

### 448. msg_8178

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:16:40

lol kk


---

### 449. msg_8179

**You** - 2025-05-04T14:18:11

I told you Katie will absolutely adore you and she was shocked at how I felt she remembers how
I was\.


---

### 450. msg_8180

**You** - 2025-05-04T14:18:28

She said you get one kick at the can\.\. go for it as hard as have to\.


---

### 451. msg_8181

**You** - 2025-05-04T14:18:38

We are alike in some ways


---

### 452. msg_8182

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:20:49

Well I look forward to meeting her


---

### 453. msg_8183

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:21:53

I feel like I would give her a fist just to see her super thankful reaction lol kidding


---

### 454. msg_8184

**You** - 2025-05-04T14:23:53

Reaction: ❤️ from Meredith Lamb
She honestly said she hadn’t seen me like this I walked her through the whole thing she just sat there kind of
Mesmerized


---

### 455. msg_8185

**You** - 2025-05-04T14:24:19

Reaction: ❤️ from Meredith Lamb
It was nice to have that kind of support


---

### 456. msg_8186

**You** - 2025-05-04T14:24:39

She is mentally tough like you though she would tell me to put on my big boy pants\.


---

### 457. msg_8187

**You** - 2025-05-04T14:24:55

Younger sisters pshh


---

### 458. msg_8188

**You** - 2025-05-04T14:25:09

I have helped her through her shit too though\. So she owes me\.


---

### 459. msg_8189

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:26:11

>
Older brothers pshhh\. They are worse\.


---

### 460. msg_8190

**You** - 2025-05-04T14:29:03

Nope we are awesome and we scare off other bad boys


---

### 461. msg_8191

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:29:27

So your sister didn’t feel bad for j?


---

### 462. msg_8192

**You** - 2025-05-04T14:29:30

Walking around the corner to an open house listed at 1\.4 million not nearly as nice as ares no finished basement but a bit bigger


---

### 463. msg_8193

**You** - 2025-05-04T14:29:37

>
No


---

### 464. msg_8194

**You** - 2025-05-04T14:29:42

Will get into that later


---

### 465. msg_8195

**You** - 2025-05-04T14:29:46

Love you\.


---

### 466. msg_8196

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:29:47

K


---

### 467. msg_8197

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:29:55

Love you too


---

### 468. msg_8198

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:34:59

lol having a hard time not smirking\.

*1 attachment(s)*


---

### 469. msg_8199

**You** - 2025-05-04T14:38:22

Smirk away


---

### 470. msg_8200

**You** - 2025-05-04T14:38:24

lol


---

### 471. msg_8201

**You** - 2025-05-04T14:38:32

Just got myself a real estate
Agent


---

### 472. msg_8202

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T14:40:26

Nice


---

### 473. msg_8203

**You** - 2025-05-04T14:52:38

Positive directional
Movement makes me happy identified
Mortgage
Specialists from Moncton reaching out to seek out competitive mortgage
Rates\.\. etc
Etc\. guy coming back from
Trinidad next week will fix my house\.\. if j goes most of the house goes so I can stage
It\.


---

### 474. msg_8204

**You** - 2025-05-04T14:52:52

This is where brain is happy\.\.  he needs to fix shit


---

### 475. msg_8205

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T15:05:16

Wow that is a lot of movement


---

### 476. msg_8206

**You** - 2025-05-04T15:16:23

Yep mowing lawn getting shit done already have a meeting set up with realtor\.\. cancelling viewing tomorrow\.


---

### 477. msg_8207

**You** - 2025-05-04T15:37:14

Reaction: 🙂 from Meredith Lamb
Next… man this feels so much better than last few nights just need to keep seeing wins\.


---

### 478. msg_8208

**You** - 2025-05-04T15:45:48

I can almost here the be careful it could all
Turn around and kick you in the ass tomorrow…
lol


---

### 479. msg_8209

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T15:49:24

I mean it could tonight\. Lol


---

### 480. msg_8210

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T15:49:32

Reaction: 😢 from Scott Hicks
Seems to be my experience\. No day is safe


---

### 481. msg_8211

**You** - 2025-05-04T15:54:31

Maybe I don’t call at the gym and ride my high and no more naughty photos for you\! 😝


---

### 482. msg_8212

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:09:09

No call no photos\. How is that a high lol


---

### 483. msg_8213

**You** - 2025-05-04T16:11:12

Well if you think I am just going to come down\.\. maybe you don’t want to talk to me


---

### 484. msg_8214

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:15:44

Oh\!


---

### 485. msg_8215

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:15:56

I didn’t get that cause and effect reference lol


---

### 486. msg_8216

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:16:03

Still out with girls


---

### 487. msg_8217

**You** - 2025-05-04T16:25:21

Ah ok well many my logic is a bit off with my being a bit happy\.  Still feels right somehow\.  I mean odds are
You won’t be able to talk to me tonight anyways\.  All the little
One’s will be home\.


---

### 488. msg_8218

**You** - 2025-05-04T16:25:34

Hope shopping is going well spend lots and lots of money


---

### 489. msg_8219

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:36:33

Finally home\.


---

### 490. msg_8220

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:36:40

Spent lots\. Lol


---

### 491. msg_8221

**You** - 2025-05-04T16:38:01

Good for you I don’t even want to know\.\. if you can spend 550 on random stuff at a volleyball tournament I shudder to think\.


---

### 492. msg_8222

**You** - 2025-05-04T16:38:38

Yorkdale err mah gerd\!\!\!\!\!\!\!\!\!\!\!


---

### 493. msg_8223

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:42:09

lol I will refrain


---

### 494. msg_8224

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:42:14

From sharing


---

### 495. msg_8225

**You** - 2025-05-04T16:43:27

I won't be able to afford to keep up with you\.


---

### 496. msg_8226

**You** - 2025-05-04T16:43:32

true story


---

### 497. msg_8227

**You** - 2025-05-04T16:43:36

I need to be a VP\.


---

### 498. msg_8228

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:44:17

It’s what child support is for lol


---

### 499. msg_8229

**You** - 2025-05-04T16:44:25

but after


---

### 500. msg_8230

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:46:53

Well my kids will have to chill\. It will be a gradual thing


---

### 501. msg_8231

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:46:55

lol


---

### 502. msg_8232

**You** - 2025-05-04T16:47:30

maybe\.\. we'll see


---

### 503. msg_8233

**You** - 2025-05-04T16:48:42

either way I feel like I need to consider advancement where I don't think I would have previously\.\. more for me than anything\.


---

### 504. msg_8234

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:50:47

Omg stooooooop


---

### 505. msg_8235

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:51:11

You do not need to fund me\. Seriously\.


---

### 506. msg_8236

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:51:21

Like not at all


---

### 507. msg_8237

**You** - 2025-05-04T16:51:28

I wasn't suggesting that\.


---

### 508. msg_8238

**You** - 2025-05-04T16:51:55

but pls don't look at it that way


---

### 509. msg_8239

**You** - 2025-05-04T16:52:07

I don't want to have to ask permission if I want to give you something


---

### 510. msg_8240

**You** - 2025-05-04T16:52:13

and vice versa


---

### 511. msg_8241

**You** - 2025-05-04T16:52:27

unless it is excessive\.\. ok then we can have some boundaries


---

### 512. msg_8242

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:53:51

All of my spending is excessive right now\. That will change extremely soon\.


---

### 513. msg_8243

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:54:01

I don’t even care honestly\.


---

### 514. msg_8244

**You** - 2025-05-04T16:54:21

I absolutely believe you\.


---

### 515. msg_8245

**You** - 2025-05-04T16:54:41

and I promise our being happy will have nothing to do with money\.


---

### 516. msg_8246

**You** - 2025-05-04T16:54:48

I never expected it would\.\. even a bit\.


---

### 517. msg_8247

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:56:29

I tried spending more and it doesn’t make ppl happier\. Teens maybe\.


---

### 518. msg_8248

**You** - 2025-05-04T16:56:56

It definitely does not \- Jaimie spent a shit ton\!\! lol didn't make her happy\.


---

### 519. msg_8249

**You** - 2025-05-04T16:57:20

I mean we know the only thing that really helps\.\.\.\.\.


---

### 520. msg_8250

**You** - 2025-05-04T16:57:28

gummies, thc drinks, and wine


---

### 521. msg_8251

**You** - 2025-05-04T16:57:33

LOTS and LOTS


---

### 522. msg_8252

**You** - 2025-05-04T16:57:50

:\)


---

### 523. msg_8253

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T16:57:53

I mean that doesn’t make one happy but it certainly numbs the pain\. 😫


---

### 524. msg_8254

**You** - 2025-05-04T16:58:09

Yeah numb is yucky\.\. but so is pain\.


---

### 525. msg_8255

**You** - 2025-05-04T18:29:25

Built j a financial model found another house cause first one I shared was built on a slab and had a conditional offer


---

### 526. msg_8256

**You** - 2025-05-04T18:42:51

Sending something else your way later
For your consideration heading to gym soon, inquiring if you thought you might be able
To chat again you could tell me all about your shopping etc if not no worries I will just focus in more on working out


---

### 527. msg_8257

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T18:45:08

I fell asleep in couch lol Well I have to go see the rental at 7\.25pm


---

### 528. msg_8258

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T18:45:17

That should be quick


---

### 529. msg_8259

**You** - 2025-05-04T18:49:50

Kk well let me know if you want to call later
I will leave
That with you\.


---

### 530. msg_8260

**You** - 2025-05-04T18:49:57

Have fun at rental


---

### 531. msg_8261

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T18:51:56

For sure \- when I’m back maybe depending on when you go


---

### 532. msg_8262

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T18:52:43

I need to wrap some gifts tonight so will be by myself for that lol


---

### 533. msg_8263

**You** - 2025-05-04T18:54:30

I am going now and will be there until 10


---

### 534. msg_8264

**You** - 2025-05-04T18:56:50

no pics though since you mocked my ability to remain happy\.\. that seems fair\.  No faith\.


---

### 535. msg_8265

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:02:03

I wasn’t mocking\. Merely mentioning the reality of late\.


---

### 536. msg_8266

**You** - 2025-05-04T19:16:52

Mmm hmmm well…\.\.


---

### 537. msg_8267

**You** - 2025-05-04T19:20:11

I dunno


---

### 538. msg_8268

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:29:23

You can’t argue with that\.


---

### 539. msg_8269

**You** - 2025-05-04T19:29:37

Well maybe you need a night off then\.\. 😝


---

### 540. msg_8270

**You** - 2025-05-04T19:29:40

Below is a structured, step\-by\-step “isochrone” \(drive\-time\) model for identifying increasingly distant meeting spots from 500 Consumers Drive, Toronto, with a focus on quiet, private, and naturally romantic settings\. We’ll sketch out the methodology first, then populate three concentric “rings” \(5\-, 10\-, and 15\-minute drive times\) while biasing away from westward options\.
⸻
1\. Methodology: Building Your Drive\-Time Isochrones
1\.	Pick your drive\-time thresholds\.
•	Ring 1: ~5 minutes
•	Ring 2: ~10 minutes
•	Ring 3: ~15 minutes
2\.	Use an isochrone tool \(e\.g\., Google Maps Platform, Mapbox Isochrone API\) centered at 500 Consumers Dr to generate these polygons\.
•	Filter out western arcs if you want to minimize west\-ward travel\.
•	Export the geojson for each ring\.
3\.	Overlay parks/natural areas\.
•	Import the isochrone polygons into a GIS or even Google My Maps\.
•	Layer on Toronto parks, ravines, gardens data\.
4\.	Score candidate spots by:
•	Privacy: smaller parks or off\-path trails
•	Romance f\.\.\. \[truncated\]


---

### 541. msg_8271

**You** - 2025-05-04T19:29:57

I don’t know these places but built N algorithm


---

### 542. msg_8272

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:32:20

Just at the rental\. That seems like a long read lol


---

### 543. msg_8273

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:32:35

Not tomorrow tho right? Musarrat starts tomorrow\.


---

### 544. msg_8274

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:32:45

I need to print her off some stuff in morning


---

### 545. msg_8275

**You** - 2025-05-04T19:34:04

Whenever you want up to you\.\. you ignored my smart ass comment not as fun when you ignore it\.


---

### 546. msg_8276

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:34:29

What smart ass comment


---

### 547. msg_8277

**You** - 2025-05-04T19:34:40

The one before the long ass read


---

### 548. msg_8278

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:35:10

Oh


---

### 549. msg_8279

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:35:20

I’m really sharp today


---

### 550. msg_8280

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:35:28

I think I need a sober weekend


---

### 551. msg_8281

**You** - 2025-05-04T19:37:43

Enjoy the rental\.\. all dressed heading upstairs to work\.


---

### 552. msg_8282

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:38:04

My stupid 12 yr old is tracking me on find my


---

### 553. msg_8283

**You** - 2025-05-04T19:38:43

Well I mean shouldn’t matter much should it


---

### 554. msg_8284

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:55:47

I told her I was talking to Diana bc Diana is 3 doors down from the rental place


---

### 555. msg_8285

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T19:55:59

She’s just so annoying about that shit


---

### 556. msg_8286

**You** - 2025-05-04T19:56:29

Ah ok


---

### 557. msg_8287

**You** - 2025-05-04T19:56:33

Well
Little shadow


---

### 558. msg_8288

**You** - 2025-05-04T20:15:03

Hope
Your is going well


---

### 559. msg_8289

**You** - 2025-05-04T20:15:06

Tour


---

### 560. msg_8290

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:15:55

Meh


---

### 561. msg_8291

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:16:09

Is fine\. Would be fine\. Just not amazing\. But would totally work


---

### 562. msg_8292

**You** - 2025-05-04T20:16:23

Then don’t settle


---

### 563. msg_8293

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:52:58

Looking at that place by myself was a bit heavier than I thought it would be\. Maybe it was having to hide it from girls…\.


---

### 564. msg_8294

**You** - 2025-05-04T20:53:21

Guilt?


---

### 565. msg_8295

**You** - 2025-05-04T20:53:29

Regret?


---

### 566. msg_8296

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:55:28

I’m not even sure honestly\.


---

### 567. msg_8297

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:55:33

Not regret


---

### 568. msg_8298

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:55:37

I have no regrets\.


---

### 569. msg_8299

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:55:51

A bit of fear


---

### 570. msg_8300

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:55:55

A bit of grief


---

### 571. msg_8301

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:56:01

\(Not the same as regret\)


---

### 572. msg_8302

**You** - 2025-05-04T20:56:15

Yeah I think I understand… I do better with those emotions


---

### 573. msg_8303

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:56:32

A bit of disbelief


---

### 574. msg_8304

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:56:41

A bit of loneliness


---

### 575. msg_8305

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:56:49

A bit of everything really


---

### 576. msg_8306

**You** - 2025-05-04T20:58:06

I mean it does sound like regret\.\. a kind of at least


---

### 577. msg_8307

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:59:27

No, no regret\.


---

### 578. msg_8308

**You** - 2025-05-04T20:59:41

🙄


---

### 579. msg_8309

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:59:56

Omg honestly


---

### 580. msg_8310

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T20:59:59

I swear


---

### 581. msg_8311

**You** - 2025-05-04T21:07:09

Pose pic?


---

### 582. msg_8312

**You** - 2025-05-04T21:07:16



---

### 583. msg_8313

**You** - 2025-05-04T21:07:55

Aww darn


---

### 584. msg_8314

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:10:56

🙄


---

### 585. msg_8315

**You** - 2025-05-04T21:11:39

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 586. msg_8316

**You** - 2025-05-04T21:11:47

This wasn’t it


---

### 587. msg_8317

**You** - 2025-05-04T21:12:10

I so for gthink you like big dudes anywayy th a


---

### 588. msg_8318

**You** - 2025-05-04T21:12:17

I should trim down


---

### 589. msg_8319

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:12:30

>
?


---

### 590. msg_8320

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:12:33

lol


---

### 591. msg_8321

**You** - 2025-05-04T21:13:26

It is this bag I am in shower I said I don’t think u like big dudes


---

### 592. msg_8322

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:14:28

What are you talking about? How would you know?


---

### 593. msg_8323

**You** - 2025-05-04T21:14:40

Just a guess


---

### 594. msg_8324

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:14:48

Based on


---

### 595. msg_8325

**You** - 2025-05-04T21:14:56

This one was earlier I keep these for time series


---

### 596. msg_8326

**You** - 2025-05-04T21:15:15


*1 attachment(s)*


---

### 597. msg_8327

**You** - 2025-05-04T21:15:28

Feel should delete fast


---

### 598. msg_8328

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:16:54

No you don’t have to delete\.


---

### 599. msg_8329

**You** - 2025-05-04T21:17:06

Sok you can laugh


---

### 600. msg_8330

**You** - 2025-05-04T21:17:08

I am


---

### 601. msg_8331

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:17:11

I actually prefer bigger guys\. Andrew was always insecure about it lol


---

### 602. msg_8332

**You** - 2025-05-04T21:17:30

Surprised


---

### 603. msg_8333

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:17:38

Why?


---

### 604. msg_8334

**You** - 2025-05-04T21:17:52

Dunno just didn’t figure


---

### 605. msg_8335

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:18:35

Becaaaaaaause………


---

### 606. msg_8336

**You** - 2025-05-04T21:22:11

>
Btw most guys are insecure about this fyi


---

### 607. msg_8337

**You** - 2025-05-04T21:22:34

Sry just shaving 5 years off 😆


---

### 608. msg_8338

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:24:46

I wasn’t sure how to respond to either of those msgs lol


---

### 609. msg_8339

**You** - 2025-05-04T21:27:39

Well the first one is obvious the second is just loving post shaves\. Feel younger


---

### 610. msg_8340

**You** - 2025-05-04T21:28:02

But it doesn’t require a response


---

### 611. msg_8341

**You** - 2025-05-04T21:28:21

It is an observation and one I think is common


---

### 612. msg_8342

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:36:46

When you’re feeling even beyond overwhelmed, it can move into what psychologists sometimes call:
•	Emotional flooding – when your nervous system is overloaded and you feel unable to process or respond clearly\. It can come with tears, numbness, irritability, or even a shutdown feeling\.
•	Dysregulation – when your emotions are so heightened that your mind and body can’t stay balanced\. It’s like your inner system is short\-circuiting\.
•	Overcapacity – not a clinical term, but a deeply real one\. It means your mental, emotional, and physical bandwidth has been maxed out, and even small things feel enormous\.
•	Disintegration – the opposite of feeling integrated or whole\. It’s when your usual coping tools and sense of self feel like they’re coming apart, even if temporarily\.
•	Collapse – when the system doesn’t fight or flee anymore—it just drops\. You may feel flat, hopeless, or disconnected\.
These states are often signs that your body and heart are begging for gentleness, not more pressure to\.\.\. \[truncated\]


---

### 613. msg_8343

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:37:17

Question lol: Tonight I’m feeling even beyond overwhelmed\. What is that called?


---

### 614. msg_8344

**You** - 2025-05-04T21:38:08

I think it is more like you are realizing what is about to happen\.\. the difficult moments are here and you are feeling what I call dread


---

### 615. msg_8345

**You** - 2025-05-04T21:38:28

And I am sorry mer I would hug you if I could


---

### 616. msg_8346

**You** - 2025-05-04T21:39:41

To bad the morning couldn’t work


---

### 617. msg_8347

**You** - 2025-05-04T21:41:23

For the record I feel that way a lot


---

### 618. msg_8348

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:42:11

I thought you were going to tell my about your sister


---

### 619. msg_8349

**You** - 2025-05-04T21:42:34

When we talk not texting it


---

### 620. msg_8350

**You** - 2025-05-04T21:42:47

Just getting dressed and going to car


---

### 621. msg_8351

**You** - 2025-05-04T21:42:59

But if we can’t chat maybe we can find some time tomorrow


---

### 622. msg_8352

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:43:00

Ah k


---

### 623. msg_8353

**You** - 2025-05-04T21:47:12

You alright?  Heading to car now


---

### 624. msg_8354

**You** - 2025-05-04T21:47:15

If you want to


---

### 625. msg_8355

**Meredith Lamb \(\+14169386001\)** - 2025-05-04T21:48:30

k, I think my shadow is upstairs


---

### 626. msg_8356

**You** - 2025-05-04T21:49:00

Kk ca
Whenever


---

### 627. msg_8357

**You** - 2025-05-04T22:15:09

Sorry a means call and I am waiting on you because I don’t know when it is safe\.


---

### 628. msg_8358

**You** - 2025-05-05T00:26:42

Reaction: ❤️ from Meredith Lamb
I hope
You are sleeping ok\.\. love you more than anything\.\. see you later xoxo❤️\. The feelings will pass I promise\.  Anything I can do let
Me know\.


---

### 629. msg_8359

**You** - 2025-05-05T04:53:47

Oooh it is nice and shiny this morning\.


---

### 630. msg_8360

**You** - 2025-05-05T06:48:46

Feels good\.\. steam sauna shower and off
To work\.\.
See you there \.\. love you\.


---

### 631. msg_8361

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T07:01:30

So much energy lol


---

### 632. msg_8362

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T07:02:08

These are nice messages to wake up to ❤️❤️❤️


---

### 633. msg_8363

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T07:02:16

Love you


---

### 634. msg_8364

**You** - 2025-05-05T07:09:36

No pics this morning though too many dudes watching


---

### 635. msg_8365

**You** - 2025-05-05T07:10:16

Just imagine with this energy if I was coming home to you instead
Of going to work\. Eesh… I mean… I don’t feel 46 😈


---

### 636. msg_8366

**You** - 2025-05-05T07:11:18

It would be a nice wake up 😇


---

### 637. msg_8367

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T08:02:45

>
I can imagine but then it’s all arghhhh lol


---

### 638. msg_8368

**You** - 2025-05-05T08:10:53

Well
You will have to imagine for a while\.


---

### 639. msg_8369

**You** - 2025-05-05T08:10:58

So will I


---

### 640. msg_8370

**You** - 2025-05-05T08:14:52

You just be running late thought you were in early this morning


---

### 641. msg_8371

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T08:18:00

Kids…\.


---

### 642. msg_8372

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T08:18:10

Just got here


---

### 643. msg_8373

**You** - 2025-05-05T08:18:16

Ahh fun


---

### 644. msg_8374

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T08:18:56

Maelle’s\. Bday


---

### 645. msg_8375

**You** - 2025-05-05T08:19:25

Yeah I know I thought you were celebrating tomorrow… must be a 2 day affair lol\.


---

### 646. msg_8376

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T13:38:50

Just had a 30 min mediator consultation with Andrew\. Very interesting


---

### 647. msg_8377

**You** - 2025-05-05T13:40:49

Bet it was\.\. I had to make some difficult legal decisions today as well\.\.  giving a lot of trust to Jaimie\.


---

### 648. msg_8378

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T13:49:59

When the mediator heard he made $600 last year and I made $150k she was like “you need legal advice on spousal”\. He wasn’t thrilled with that\.


---

### 649. msg_8379

**You** - 2025-05-05T13:50:20

Rofl called it


---

### 650. msg_8380

**You** - 2025-05-05T13:50:59

I am sure he is just texting Mike crazy


---

### 651. msg_8381

**You** - 2025-05-05T13:51:03

Like


---

### 652. msg_8382

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T13:52:25

He actually hasn’t texted so must be on a call


---

### 653. msg_8383

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T13:52:28

Not sure


---

### 654. msg_8384

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:04:08

I’m leaving early for bday dinner\. She’s allowed to do it tonight :p


---

### 655. msg_8385

**You** - 2025-05-05T16:04:27

Cya


---

### 656. msg_8386

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:16:55

Omg what is wrong


---

### 657. msg_8387

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:32:30

Um Scott …


---

### 658. msg_8388

**You** - 2025-05-05T16:33:27

I had a panic attack…\.\.


---

### 659. msg_8389

**You** - 2025-05-05T16:33:39

I couldn’t stay


---

### 660. msg_8390

**You** - 2025-05-05T16:34:17

It was building for about 3 hours


---

### 661. msg_8391

**You** - 2025-05-05T16:34:43

I was already trying to leave before you told me anything


---

### 662. msg_8392

**You** - 2025-05-05T16:35:02

And I didn’t want cote there


---

### 663. msg_8393

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:35:03

Why didn’t you say anything?


---

### 664. msg_8394

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:35:15

Are you ok now?


---

### 665. msg_8395

**You** - 2025-05-05T16:35:17

What am I gonna say\.\.


---

### 666. msg_8396

**You** - 2025-05-05T16:35:25

Hey team


---

### 667. msg_8397

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:35:31

I meant to me


---

### 668. msg_8398

**You** - 2025-05-05T16:35:31

About to lose my shit lol


---

### 669. msg_8399

**You** - 2025-05-05T16:35:40

I don’t like doing that


---

### 670. msg_8400

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:36:00

Do you think it is recent developments with Jaime or just everything?


---

### 671. msg_8401

**You** - 2025-05-05T16:36:09

Not you


---

### 672. msg_8402

**You** - 2025-05-05T16:36:23

Or bud


---

### 673. msg_8403

**You** - 2025-05-05T16:36:25

Us


---

### 674. msg_8404

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:37:00

Maybe go back on half an anxiety pill per day


---

### 675. msg_8405

**You** - 2025-05-05T16:37:25

It won’t help and I don’t like how it makes me feel


---

### 676. msg_8406

**You** - 2025-05-05T16:38:14

Or not feel


---

### 677. msg_8407

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:38:28

But maybe for a month or two you need that


---

### 678. msg_8408

**You** - 2025-05-05T16:38:38

I will go numb


---

### 679. msg_8409

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:39:35

I get it but survival


---

### 680. msg_8410

**You** - 2025-05-05T16:39:51

You won’t like me…


---

### 681. msg_8411

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:40:39

I will hardly get to see you anyway\. I will like you, love you just the same


---

### 682. msg_8412

**You** - 2025-05-05T16:42:34

Before I do that I am going to try something else tomorrow\.


---

### 683. msg_8413

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:42:36

I’m not conditional right now\.


---

### 684. msg_8414

**You** - 2025-05-05T16:43:05

I know


---

### 685. msg_8415

**You** - 2025-05-05T16:43:30

Don’t worry about me I will be fine I just needed to leave


---

### 686. msg_8416

**You** - 2025-05-05T16:44:48

Just go have a good time with your fam tonight\.\. I will find something to keep me
Occupied


---

### 687. msg_8417

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:44:56

I will of course worry about especially when you practically run away suddenly


---

### 688. msg_8418

**You** - 2025-05-05T16:45:26

I don’t want people to see me like that


---

### 689. msg_8419

**You** - 2025-05-05T16:45:54

It’s fine I will manage it\.\. just please focus on your night\.


---

### 690. msg_8420

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:47:11

https://open\.spotify\.com/track/7vRriwrloYVaoAe3a9wJHe?si=mLaVXTHYQYeCHF4qFlDSWg
Don’t listen if you don’t want deep\. Listening right now


---

### 691. msg_8421

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:47:23

Just a good song


---

### 692. msg_8422

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:47:43

>
I plan to get caught up in work tonight actually after dinner


---

### 693. msg_8423

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:48:04

You should go for a walk somewhere calm\. Not the gym


---

### 694. msg_8424

**You** - 2025-05-05T16:48:35

Not sure yet will figure it out later


---

### 695. msg_8425

**You** - 2025-05-05T16:48:54

Got things I have to do though


---

### 696. msg_8426

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:53:18

Is there anything i can do?


---

### 697. msg_8427

**You** - 2025-05-05T16:54:41

Nope


---

### 698. msg_8428

**You** - 2025-05-05T16:56:08

Focus on you and yours mer you have more than enough on your own plate\.


---

### 699. msg_8429

**You** - 2025-05-05T16:56:26

I don’t think there is anything you could do anyways\.


---

### 700. msg_8430

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T16:58:15

Maybe in person… 😕


---

### 701. msg_8431

**You** - 2025-05-05T16:59:10

U can’t do that either


---

### 702. msg_8432

**You** - 2025-05-05T17:00:18

I me\. I just have to get used to the fact that we aren’t going to see each other again for months\. But that is separate from today\.


---

### 703. msg_8433

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T17:01:50

I don’t think we can do “months”\. We will figure it out\.


---

### 704. msg_8434

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T17:04:12

Our mediator that we just secured told us 3 weeks to a separation agreement\.


---

### 705. msg_8435

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T17:04:25

Then I move out\.


---

### 706. msg_8436

**You** - 2025-05-05T17:04:56

Congrats… light at the end of the tunnel for you\.


---

### 707. msg_8437

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:06:00

How are you doing? \(For real\)


---

### 708. msg_8438

**You** - 2025-05-05T18:07:19

Mer pls\.\. hun I feel really guilty for distracting you please be with your family tonight\.


---

### 709. msg_8439

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:07:55

Mac and Maelle going to volleyball\.


---

### 710. msg_8440

**You** - 2025-05-05T18:08:08

What happened to not doing that and having the party


---

### 711. msg_8441

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:08:41

We had dinner, cake, she opened gifts\. Pretty much done so they are both going to volleyball


---

### 712. msg_8442

**You** - 2025-05-05T18:08:58

ah ok\.\. well I hope she had fun and she enjoyed her gifts etc\.


---

### 713. msg_8443

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:09:47

Yes she did of course\. Gifts = always good\. Lol


---

### 714. msg_8444

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:10:12

So answer my original question


---

### 715. msg_8445

**You** - 2025-05-05T18:10:15

fack


---

### 716. msg_8446

**You** - 2025-05-05T18:10:26

why can't I skip over questions I don't want to answer


---

### 717. msg_8447

**You** - 2025-05-05T18:10:28

you get to


---

### 718. msg_8448

**You** - 2025-05-05T18:10:32

lol


---

### 719. msg_8449

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:10:52

You don’t have my skill level in that area


---

### 720. msg_8450

**You** - 2025-05-05T18:10:56

pshh


---

### 721. msg_8451

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:10:59

Thems the breaks


---

### 722. msg_8452

**You** - 2025-05-05T18:11:40

Ok\.\. so here is the thing\.\. I ate last night \- went to the gym, went hard\.\. came home\.\. had my shake\.\. woke up 5 hours later\.\. another hard workout another shake and then nothing\.


---

### 723. msg_8453

**You** - 2025-05-05T18:11:45

So


---

### 724. msg_8454

**You** - 2025-05-05T18:11:50

I probably crashed


---

### 725. msg_8455

**You** - 2025-05-05T18:11:58

I should have eaten\.\.


---

### 726. msg_8456

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:12:01

Uh, yeah


---

### 727. msg_8457

**You** - 2025-05-05T18:12:09

So there you go no harm no foul


---

### 728. msg_8458

**You** - 2025-05-05T18:12:11

case closed


---

### 729. msg_8459

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:12:17

Errrrrr


---

### 730. msg_8460

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:12:33

That sounds like a teen explanation


---

### 731. msg_8461

**You** - 2025-05-05T18:12:41

I feel like it holds its own


---

### 732. msg_8462

**You** - 2025-05-05T18:13:03

outside of that


---

### 733. msg_8463

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:13:11

So did you eat tonight?


---

### 734. msg_8464

**You** - 2025-05-05T18:13:13

there is an ache that won't go away no matter what I do\.


---

### 735. msg_8465

**You** - 2025-05-05T18:13:33

I cannot help it\.\.  it isn't me trying to feel that way\.\. I cannot think it away


---

### 736. msg_8466

**You** - 2025-05-05T18:13:40

I cannot ignore it


---

### 737. msg_8467

**You** - 2025-05-05T18:13:55

But that wasn't the crash


---

### 738. msg_8468

**You** - 2025-05-05T18:13:58

or the reason for it


---

### 739. msg_8469

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:14:09

Yeah I have that also\.


---

### 740. msg_8470

**You** - 2025-05-05T18:14:09

but you were going to push and bug me until I admitted it


---

### 741. msg_8471

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:14:17

A crash and panic attack are different


---

### 742. msg_8472

**You** - 2025-05-05T18:14:26

Felt the same


---

### 743. msg_8473

**You** - 2025-05-05T18:14:29

scarily


---

### 744. msg_8474

**You** - 2025-05-05T18:15:00

You guys were occupied\.\. I just wanted to bolt with no one noticing


---

### 745. msg_8475

**You** - 2025-05-05T18:15:18

just sec grabbing food 2 mins\.


---

### 746. msg_8476

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:15:33

Carolyn and Michelle didn’t notice actually\. Strange


---

### 747. msg_8477

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:15:40

kk


---

### 748. msg_8478

**You** - 2025-05-05T18:19:52

good


---

### 749. msg_8479

**You** - 2025-05-05T18:19:53

glad


---

### 750. msg_8480

**You** - 2025-05-05T18:20:21

anyhow\.\. the ache thing is torture\.\. I try to ignore but it doesn't want to go away\.\. so I am not sure what to do tbh\.


---

### 751. msg_8481

**You** - 2025-05-05T18:21:31

like i said this is my problem


---

### 752. msg_8482

**You** - 2025-05-05T18:21:34

not yours


---

### 753. msg_8483

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:21:45

Whatever it is my problem too


---

### 754. msg_8484

**You** - 2025-05-05T18:22:05

not the fact that I cannot deal


---

### 755. msg_8485

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:22:11

I have been very much struggling since our weekend together\.


---

### 756. msg_8486

**You** - 2025-05-05T18:22:24

i wasn't suggesting you weren't hon


---

### 757. msg_8487

**You** - 2025-05-05T18:22:29

at all


---

### 758. msg_8488

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:22:42

Just saying it is both of our problems


---

### 759. msg_8489

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:22:46

Unfortunately


---

### 760. msg_8490

**You** - 2025-05-05T18:23:36

well I cannot get a handle on it\.\. so just going to have to find some way to deal\.\. somehow\.\. I will just keep on trying to figure something out\.\. eventually


---

### 761. msg_8491

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:25:39

We will plan the next time we see each other\. Maybe that will help


---

### 762. msg_8492

**You** - 2025-05-05T18:26:11

you know we cannot do that\.\. too far out\.


---

### 763. msg_8493

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:26:23

Doesn’t matter\. Is what it is


---

### 764. msg_8494

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:27:05

We might be able to get creative


---

### 765. msg_8495

**You** - 2025-05-05T18:27:45

there are too many risks\.\. and I don't want anything happening that could hurt you in any way


---

### 766. msg_8496

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:27:59

Honestly, I feel the ache too entirely\. Everything in my body wants more from that weekend…


---

### 767. msg_8497

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:28:07

I’m sure we can figure something out


---

### 768. msg_8498

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:28:13

I will ask ChatGPT lol


---

### 769. msg_8499

**You** - 2025-05-05T18:28:25

Have at it\.\. it didn't help me very much\.


---

### 770. msg_8500

**You** - 2025-05-05T18:30:19

Look I know you are trying to be optimistic and cheer me up and yes mer\.\. no matter how shitty I feel right now, I am still 100% in this for the long haul\.\. but I don't have much hope for the near to medium term\.


---

### 771. msg_8501

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:31:23

Reaction: ❤️ from Scott Hicks
😭


---

### 772. msg_8502

**You** - 2025-05-05T18:31:46

>
Sorry but you know it too you said it earlier


---

### 773. msg_8503

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:32:54

I mean I’ve been more focusing on bdays and separation crap so didn’t fully think about something short term\. I’m sure if I thought hard enough I could come up with something\. Might not be great but could be sufficient lol


---

### 774. msg_8504

**You** - 2025-05-05T18:33:26

Again you have too much on the go\.\. separation, finding a place, kids all the time, little shadows tracking you, etc\.


---

### 775. msg_8505

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:34:06

Stop


---

### 776. msg_8506

**You** - 2025-05-05T18:34:11

I am not doing anything


---

### 777. msg_8507

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:34:14

I don’t like reading it


---

### 778. msg_8508

**You** - 2025-05-05T18:34:14

this isn't moping


---

### 779. msg_8509

**You** - 2025-05-05T18:34:22

this is stating facts


---

### 780. msg_8510

**You** - 2025-05-05T18:34:29

and the problem is


---

### 781. msg_8511

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:34:33

I know…


---

### 782. msg_8512

**You** - 2025-05-05T18:34:33

it builds expectation


---

### 783. msg_8513

**You** - 2025-05-05T18:34:40

which leads to hope


---

### 784. msg_8514

**You** - 2025-05-05T18:34:45

which leads tooooooooooo\.\.\.\.


---

### 785. msg_8515

**You** - 2025-05-05T18:34:47

what?


---

### 786. msg_8516

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:35:13

The funny thing is that I feel like I knew this would happen\.


---

### 787. msg_8517

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:35:16

🤔


---

### 788. msg_8518

**You** - 2025-05-05T18:35:20

You did


---

### 789. msg_8519

**You** - 2025-05-05T18:35:22

you told me so


---

### 790. msg_8520

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:35:33

I know…


---

### 791. msg_8521

**You** - 2025-05-05T18:35:34

You don't even have to say it I will


---

### 792. msg_8522

**You** - 2025-05-05T18:35:49

It doesn't matter\.\. like you said it is what it is\.\. changes nothing\.


---

### 793. msg_8523

**You** - 2025-05-05T18:35:53

not for me


---

### 794. msg_8524

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:36:20

But everything has changed\. Everything is harder now\. More heavy\.


---

### 795. msg_8525

**You** - 2025-05-05T18:36:27

For now\.\. yeah\.


---

### 796. msg_8526

**You** - 2025-05-05T18:37:04

I know you aren't giving up\.\. neither am I\.\. we don't have a lot of choices


---

### 797. msg_8527

**You** - 2025-05-05T18:37:22

I would never give up on this no matter how heavy or shitty it got


---

### 798. msg_8528

**You** - 2025-05-05T18:37:33

so please if you brain takes you there shut it down


---

### 799. msg_8529

**You** - 2025-05-05T18:38:31

Again\.\. if it sucked, or was awkward, or was meh\.\. that weekend would be easy\.\. like\.\.\. well first time\.\. let's give it some time\.\. we will get there\.\.


---

### 800. msg_8530

**You** - 2025-05-05T18:38:34

but it wasn't


---

### 801. msg_8531

**You** - 2025-05-05T18:38:36

at all


---

### 802. msg_8532

**You** - 2025-05-05T18:39:07

anyway I am done typing\. because now you are just listening again


---

### 803. msg_8533

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:39:32

I am letting you finish your thoughts lol


---

### 804. msg_8534

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:39:40

It’s called respect


---

### 805. msg_8535

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:39:47

😋


---

### 806. msg_8536

**You** - 2025-05-05T18:39:53

>
oh\.\.\. that is what it is\.\. mmmm hhhmmmmm


---

### 807. msg_8537

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:40:46

For the record my brain has not taken me to giving up ever\. Not even one time\. But today was concerning\.


---

### 808. msg_8538

**You** - 2025-05-05T18:41:06

no I meant don't let your brain let you think I would


---

### 809. msg_8539

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:41:32

Oh well, if you start having panic attacks everyday :p


---

### 810. msg_8540

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:41:39

Your brain might tell you to


---

### 811. msg_8541

**You** - 2025-05-05T18:42:12

mer\.\.\.


---

### 812. msg_8542

**You** - 2025-05-05T18:42:29

like\.\. how many times in how many ways do I need to say this\.


---

### 813. msg_8543

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:42:45

>
I think the fact that it was a little too perfect is causing this to be way more overload…\.


---

### 814. msg_8544

**You** - 2025-05-05T18:42:59

there is no one on earth that I want to spend the rest of my life with but you, and I know that in the years we have known each other, and the months we have fallen in love\.


---

### 815. msg_8545

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:43:10

>
I’m just saying you haven’t had panic attacks everyday for a week yet


---

### 816. msg_8546

**You** - 2025-05-05T18:43:14

Reaction: ❤️ from Meredith Lamb
I cannot say it more plainly than that\.\. and I believe it\.\. and it is what it is\.


---

### 817. msg_8547

**You** - 2025-05-05T18:43:39

If it got bad I would go back on medication\.


---

### 818. msg_8548

**You** - 2025-05-05T18:43:45

there is nothing for the ache though\.


---

### 819. msg_8549

**You** - 2025-05-05T18:43:46

sorry


---

### 820. msg_8550

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:44:32

Were you upset that I didn’t do the park thing this morning?


---

### 821. msg_8551

**You** - 2025-05-05T18:44:33

like that is what this is to me\.\. it is everything\.\. it is also just very painful atm


---

### 822. msg_8552

**You** - 2025-05-05T18:44:54

nope\.\. you had shit to do\.\. I figured we would try that sometime whenever you figure out what you want to do\.


---

### 823. msg_8553

**You** - 2025-05-05T18:45:02

I didn't bank on it anytime soon\.


---

### 824. msg_8554

**You** - 2025-05-05T18:45:14

But\.\.


---

### 825. msg_8555

**You** - 2025-05-05T18:45:17

and I will be honest


---

### 826. msg_8556

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:45:22

k, I thought maybe you were


---

### 827. msg_8557

**You** - 2025-05-05T18:45:51

I don't want to suggest anything else\.\. because it is difficult to constantly be putting that out there\.\. like it just is\.\. nothing other than that\.


---

### 828. msg_8558

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:46:09

You deleted and rewrote


---

### 829. msg_8559

**You** - 2025-05-05T18:46:12

no


---

### 830. msg_8560

**You** - 2025-05-05T18:46:37

I wanted to make sure it was written in such a way that it didn't make you mad\.\. or anyting


---

### 831. msg_8561

**You** - 2025-05-05T18:46:51

but that is what I was writing\.


---

### 832. msg_8562

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:47:09

You don’t want to suggest anything else? Wdym


---

### 833. msg_8563

**You** - 2025-05-05T18:47:32

Like throwing ideas out to connect\.\. they never seem to happen\.\. so I just gonna stop for a bit\.\. draining\.


---

### 834. msg_8564

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:47:45

Ah gotcha


---

### 835. msg_8565

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:48:04

I’m sorry


---

### 836. msg_8566

**You** - 2025-05-05T18:48:14

again\.\. it isn't your fault I don't blame you\.


---

### 837. msg_8567

**You** - 2025-05-05T18:48:33

but still it takes energy\.\. and like I said earlier it leads to expectations and hope and\.\.\.\.\.


---

### 838. msg_8568

**You** - 2025-05-05T18:48:49

so like I am just going to chill for a while I think\.


---

### 839. msg_8569

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:49:39

Yes please do\. I feel so overloaded right now so really would like for you to chill\. I’m not going anywhere


---

### 840. msg_8570

**You** - 2025-05-05T18:49:38

now you deleted


---

### 841. msg_8571

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:49:45

I didn’t delete


---

### 842. msg_8572

**You** - 2025-05-05T18:49:54

>
kk


---

### 843. msg_8573

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:50:10

I will try to suggest something soon so just wait for me


---

### 844. msg_8574

**You** - 2025-05-05T18:50:40

Not going anywhere Mer\.\. will be in that office again tomorrow morning\.


---

### 845. msg_8575

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:51:50

I know but things felt incredibly off today


---

### 846. msg_8576

**You** - 2025-05-05T18:52:33

Mer, it is difficult\.\. if I start joking with you I see how awesome you are\.\. and I feel good for a minute\.\.


---

### 847. msg_8577

**You** - 2025-05-05T18:52:45

it was easier to walk away today\.\. and to be more curt\.


---

### 848. msg_8578

**You** - 2025-05-05T18:52:50

I hated it


---

### 849. msg_8579

**You** - 2025-05-05T18:52:57

it hurt but I think maybe it hurt less


---

### 850. msg_8580

**You** - 2025-05-05T18:53:15

I still don't like it I don't think I can keep doing it anyways


---

### 851. msg_8581

**You** - 2025-05-05T18:53:23

so I don't even know what to od


---

### 852. msg_8582

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:53:47

😵‍💫


---

### 853. msg_8583

**You** - 2025-05-05T18:54:13

this isn't easy\.\. and I am not trying to make this hard\.\. I don't know what it is you do\.\. but I cannot do that\.


---

### 854. msg_8584

**You** - 2025-05-05T18:54:41

I am not saying you don't feel but you handle it


---

### 855. msg_8585

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:54:59

I mean we can’t go home together, can’t be together so we have no choice really


---

### 856. msg_8586

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:55:25

I was looking forward to seeing you but felt concerned all day


---

### 857. msg_8587

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:55:32

Basically


---

### 858. msg_8588

**You** - 2025-05-05T18:55:37

Ok\.\. Mer I won't do that anymore\.


---

### 859. msg_8589

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:55:56

Go back on anxiety meds for a WHILE


---

### 860. msg_8590

**You** - 2025-05-05T18:55:57

I was just don't know what to do\. the ache just never stops


---

### 861. msg_8591

**You** - 2025-05-05T18:56:35

I mean it sounds like you want me to just turn my emotions back off\.\. lol\.  I am not sure meds can do that\.


---

### 862. msg_8592

**You** - 2025-05-05T18:56:47

I know the old me would have been much easier though


---

### 863. msg_8593

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:56:51

I mean you were fine before


---

### 864. msg_8594

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:57:06

Then you go off them and start to get all antsy


---

### 865. msg_8595

**You** - 2025-05-05T18:57:35

I will go to the doctor tomorrow\.


---

### 866. msg_8596

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:57:39

I get the ache too entirely … I have that too\. But you need to survive


---

### 867. msg_8597

**You** - 2025-05-05T18:57:41

Get back on fluoxotine


---

### 868. msg_8598

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:59:12

I take a really tiny bit of cipralex a day


---

### 869. msg_8599

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:59:18

Google it vs yours


---

### 870. msg_8600

**You** - 2025-05-05T18:59:24

I know what that is


---

### 871. msg_8601

**You** - 2025-05-05T18:59:29

I have about 500 pills here


---

### 872. msg_8602

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:59:37

I used to take more when the crap happened


---

### 873. msg_8603

**You** - 2025-05-05T18:59:41

between gracie and jaimie


---

### 874. msg_8604

**You** - 2025-05-05T18:59:43

and maddie


---

### 875. msg_8605

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T18:59:53

Now I am just paranoid to go off completely


---

### 876. msg_8606

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:00:16

And now you are making me more paranoid\.


---

### 877. msg_8607

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:00:35

I will go off entirely when I’m more settled


---

### 878. msg_8608

**You** - 2025-05-05T19:00:48

mer if we were together right now\.\. I wouldn't need anything\.\. I know that\.


---

### 879. msg_8609

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:00:57

Same


---

### 880. msg_8610

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:02:07

My ChatGPT letter made you laugh tho didn’t it


---

### 881. msg_8611

**You** - 2025-05-05T19:02:20

a little\.\.


---

### 882. msg_8612

**You** - 2025-05-05T19:02:23

it was funny


---

### 883. msg_8613

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:02:28

lol


---

### 884. msg_8614

**You** - 2025-05-05T19:02:27

I just wasn't laughy


---

### 885. msg_8615

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:02:35

Oh come on


---

### 886. msg_8616

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:02:38

It so was


---

### 887. msg_8617

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:02:42

It was hilarious


---

### 888. msg_8618

**You** - 2025-05-05T19:02:41

took me a lot to get through that meeting


---

### 889. msg_8619

**You** - 2025-05-05T19:02:44

I was really irritated


---

### 890. msg_8620

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:02:52

I could tell


---

### 891. msg_8621

**You** - 2025-05-05T19:03:09

look if I hadn't gone to that meeting \- they wouldn't have come off their targets at all


---

### 892. msg_8622

**You** - 2025-05-05T19:03:12

that was stupid


---

### 893. msg_8623

**You** - 2025-05-05T19:03:31

I don't know how Haris didn't see what would happen


---

### 894. msg_8624

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:03:44

Well it was an early meeting to get them thinking bc we figured they wouldn’t know


---

### 895. msg_8625

**You** - 2025-05-05T19:03:45

I know jacky was trying


---

### 896. msg_8626

**You** - 2025-05-05T19:03:54

I appreciated that


---

### 897. msg_8627

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:03:55

Still 2 weeks until oc


---

### 898. msg_8628

**You** - 2025-05-05T19:04:05

but they needed to be smacked


---

### 899. msg_8629

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:04:15

Talked to Michael y after and he is going to relook


---

### 900. msg_8630

**You** - 2025-05-05T19:05:16

God I have literally nothing tomorrow\.\.\. maybe stay home\.\.\. not sure that'd be better\.


---

### 901. msg_8631

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:05:18

What’s worse… what you are feeling or feeling nothing


---

### 902. msg_8632

**You** - 2025-05-05T19:05:31

If the good feelings went I would hate myself\.


---

### 903. msg_8633

**You** - 2025-05-05T19:05:53

I haven't had them in so long\.


---

### 904. msg_8634

**You** - 2025-05-05T19:06:07

jesus\.\. no I wouldn't be happy at all I suspect


---

### 905. msg_8635

**You** - 2025-05-05T19:06:14

still going to do it\.


---

### 906. msg_8636

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:06:33

Do what


---

### 907. msg_8637

**You** - 2025-05-05T19:06:37

take the drug


---

### 908. msg_8638

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:07:07

I think you should for a while at the very least


---

### 909. msg_8639

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:07:14

This is a lot


---

### 910. msg_8640

**You** - 2025-05-05T19:07:30

It just makes me sad to think about it but w/e


---

### 911. msg_8641

**You** - 2025-05-05T19:07:35

not much of a choice


---

### 912. msg_8642

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:07:46

We both have these crumbling lives \+ this secretive thing\. It’s a lot


---

### 913. msg_8643

**You** - 2025-05-05T19:08:29

I don't think this will help\.\. I was having these feelings even when I was on it\.


---

### 914. msg_8644

**You** - 2025-05-05T19:08:38

part of why I quit


---

### 915. msg_8645

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:09:06

Then maybe don’t overdo it at the gym? Like 2x per day etc


---

### 916. msg_8646

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:09:21

I mean there are probably contributing factors


---

### 917. msg_8647

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:09:24

Not one thing


---

### 918. msg_8648

**You** - 2025-05-05T19:09:57

maybe\.\. I dunno\.\. I just know i have shit to do because no one else will\.\. and i feel how i feel and no drug is touching that\.


---

### 919. msg_8649

**You** - 2025-05-05T19:11:19

look if it gets bad next time\.\. I will just leave before it gets to that point\./


---

### 920. msg_8650

**You** - 2025-05-05T19:12:10

but I agree shit is not going to change\.\. it will hurt and ache and suck for a long time\.\. I just have to get through\.


---

### 921. msg_8651

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:12:15

Ugh, I wish we could lie together …\.


---

### 922. msg_8652

**You** - 2025-05-05T19:12:56

ditto\.\. and as much as I love thinking about it\.\. and can remember insane details\.\. I try not to\.


---

### 923. msg_8653

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:14:56

I’m kinda the same


---

### 924. msg_8654

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:15:56

It is an odd feeling to miss something so much that we only really had for 4 days … and not even full time lol


---

### 925. msg_8655

**You** - 2025-05-05T19:16:39

but see that isn't just it\.\. even absent that time\.\. I would still be frustrated and lonely, and achy\.\. even if all we had was the back of the car that first time\.


---

### 926. msg_8656

**You** - 2025-05-05T19:16:46

that was enough\.\.


---

### 927. msg_8657

**You** - 2025-05-05T19:17:18

I was in love before the car\.\. after I was convinced something different was going on\.


---

### 928. msg_8658

**You** - 2025-05-05T19:17:59

so while it makes it harder probably because there was something very tangible and now we cannot have any of it\.\. I sitll would have felt incomplete\.


---

### 929. msg_8659

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:20:26

It likely wouldn’t be as intense\.


---

### 930. msg_8660

**You** - 2025-05-05T19:20:48

maybe not\.\. maybe it would be\.\. it was getting awful intense before the weekend


---

### 931. msg_8661

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:22:13

True enough but the weekend solidified something for me\. Just the time together…\.\.  \(Not talking sex necessarily…\)


---

### 932. msg_8662

**You** - 2025-05-05T19:22:31

Agreed and it was a lot more than just sex\.\. agreed\.


---

### 933. msg_8663

**You** - 2025-05-05T19:22:39

like even the sex wasn't that to me\.\.


---

### 934. msg_8664

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:22:43

Definitely fell in love with you before the weekend also tho


---

### 935. msg_8665

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:23:10

>
Same, I know what you mean


---

### 936. msg_8666

**You** - 2025-05-05T19:24:04

anyhow let's not talk about the weekend anymore\.\. magical and rainbows and unicorns\.\. lol and real as hell and as perfect as I could expect it to be\.\. and it reflects what can be\.\. but honestly the more I think about it the more everything sucks\.


---

### 937. msg_8667

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:25:00

Sure but we were lucky really


---

### 938. msg_8668

**You** - 2025-05-05T19:25:09

this whole think has been luck


---

### 939. msg_8669

**You** - 2025-05-05T19:25:13

or fate


---

### 940. msg_8670

**You** - 2025-05-05T19:25:21

pick whatever you believe in


---

### 941. msg_8671

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:25:44

Fate


---

### 942. msg_8672

**You** - 2025-05-05T19:25:58

that is what I think\.\. but I never would have before


---

### 943. msg_8673

**You** - 2025-05-05T19:26:16

but fate does suck a bit\.


---

### 944. msg_8674

**You** - 2025-05-05T19:26:29

it could have fucking waited like 4 more months


---

### 945. msg_8675

**You** - 2025-05-05T19:26:32

lol


---

### 946. msg_8676

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:26:37

LOL


---

### 947. msg_8677

**You** - 2025-05-05T19:26:46

but then


---

### 948. msg_8678

**You** - 2025-05-05T19:27:00

all the emotion and stuff and urgency and connection etc\.\. wouldn't be the same


---

### 949. msg_8679

**You** - 2025-05-05T19:27:09

oh I still think we would have gotten to the same place


---

### 950. msg_8680

**You** - 2025-05-05T19:27:21

but this is memorable and unique to me


---

### 951. msg_8681

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:27:31

I honestly think this was my fault\. If I never told you about the text that day on our one on one I don’t see this happening


---

### 952. msg_8682

**You** - 2025-05-05T19:27:42

not ever or not now\.


---

### 953. msg_8683

**You** - 2025-05-05T19:27:50

you might be right


---

### 954. msg_8684

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:27:53

Not now


---

### 955. msg_8685

**You** - 2025-05-05T19:28:08

like I said I was going this way anyways


---

### 956. msg_8686

**You** - 2025-05-05T19:28:14

we would have connected the dots eventually


---

### 957. msg_8687

**You** - 2025-05-05T19:28:19

and then\.\. same thing happens\.


---

### 958. msg_8688

**You** - 2025-05-05T19:28:22

I bet\.\.


---

### 959. msg_8689

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:28:46

Probably\. Just different timing


---

### 960. msg_8690

**You** - 2025-05-05T19:29:06

it still would have been too early\.


---

### 961. msg_8691

**You** - 2025-05-05T19:29:08

my bet


---

### 962. msg_8692

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:29:16

Not sure tho\. We kind of connected over my messed up life


---

### 963. msg_8693

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:29:25

lol


---

### 964. msg_8694

**You** - 2025-05-05T19:29:54

well I am ok if you take the blame for the kickoff \- but I am fairly certain I jumped off the cliff after you\.


---

### 965. msg_8695

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:30:22

Yep you definitely did


---

### 966. msg_8696

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:30:31

\(Thanks\)


---

### 967. msg_8697

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:30:35

Reaction: ❤️ from Scott Hicks
💕


---

### 968. msg_8698

**You** - 2025-05-05T19:30:46

oh yeah cause I made everything super easy for everyone LOL


---

### 969. msg_8699

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:31:15

Super easy or super interesting?


---

### 970. msg_8700

**You** - 2025-05-05T19:31:35

Reaction: 😂 from Meredith Lamb
let's fall madly insanely in love, have an absolute soul crushing weekend, then go into limbo for 4 months while our lives explode all over everything, and oh yeah you work on my team\.


---

### 971. msg_8701

**You** - 2025-05-05T19:31:59

i mean\.\. wtf


---

### 972. msg_8702

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:32:03

Well when you put it like that


---

### 973. msg_8703

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:32:04

lol


---

### 974. msg_8704

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:33:04

I think if there are 2 ppl that are well suited to this situation and can handle it, it is us\.


---

### 975. msg_8705

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:33:11

LOL


---

### 976. msg_8706

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:33:19

NOT\. that was sarcasm


---

### 977. msg_8707

**You** - 2025-05-05T19:34:07

yeah I don't feel suited


---

### 978. msg_8708

**You** - 2025-05-05T19:34:15

old me yes


---

### 979. msg_8709

**You** - 2025-05-05T19:34:24

Reaction: 💋 from Meredith Lamb
new me\.\. he sucks and is a big fucking baby\.


---

### 980. msg_8710

**You** - 2025-05-05T19:36:06

no he is not cool\.\. he wants to kill me\.


---

### 981. msg_8711

**You** - 2025-05-05T19:36:16

lke 20 years worth of pent up emotion/


---

### 982. msg_8712

**You** - 2025-05-05T19:36:58

seriously mer you are going to have to try to be patient with me\.\. I know I am going to have a really really hard time these next few months\.


---

### 983. msg_8713

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:37:31

I know… :\(


---

### 984. msg_8714

**You** - 2025-05-05T19:38:28

In my head I thought we would be past this whole thing in like 2 months\.\. and we could find a bit of time every week to try to take the edge off\.\. but lol it feels more like we are about to enter a 3\-4 week dry spell\.\.\.


---

### 985. msg_8715

**You** - 2025-05-05T19:39:01

I will literally have to do something \- like figure out a way to shut down or something\.


---

### 986. msg_8716

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:39:31

There must be another way


---

### 987. msg_8717

**You** - 2025-05-05T19:40:14

no I don't know how to handle it\.\. and it is getting too bad\.\. like go back to the cold version of me somehow??


---

### 988. msg_8718

**You** - 2025-05-05T19:40:21

at least he didn't feel it\.


---

### 989. msg_8719

**You** - 2025-05-05T19:40:50

But that would basically be today


---

### 990. msg_8720

**You** - 2025-05-05T19:40:53

but worse and all the time


---

### 991. msg_8721

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:41:04

No don’t do that\. I didn’t like today


---

### 992. msg_8722

**You** - 2025-05-05T19:41:11

:\(


---

### 993. msg_8723

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:44:22

>
You are kind of scaring me a little\. I’m not going anywhere but genuinely concerned\.


---

### 994. msg_8724

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:44:43

I know this is messy but we are in it together\. You aren’t alone\.


---

### 995. msg_8725

**You** - 2025-05-05T19:44:53

I know\.\. but it is like you said\.\. Survival mode right\.\.


---

### 996. msg_8726

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:45:33

Right but when you say “it is getting too bad”…… 😥😢😥😢


---

### 997. msg_8727

**You** - 2025-05-05T19:45:57

It is getting too bad to not see you, or not do something myself to deal with it\.


---

### 998. msg_8728

**You** - 2025-05-05T19:46:16

not too bad to give up I already said there isn't bad enough that = that choice


---

### 999. msg_8729

**You** - 2025-05-05T19:46:50

Listen I know what you want\.


---

### 1000. msg_8730

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:46:56

k well let’s try seeing each other this week …


---

### 1001. msg_8731

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:47:16

Even if in morning


---

### 1002. msg_8732

**You** - 2025-05-05T19:47:29

You want me to be this chill dude\.\. who can basically float along be happy all day \- chat here and there\.\. and hold my emotions in check until the time is right\.


---

### 1003. msg_8733

**You** - 2025-05-05T19:47:31

ROFL


---

### 1004. msg_8734

**You** - 2025-05-05T19:47:42

problem is I was an unemotional GIT for like 2 decades


---

### 1005. msg_8735

**You** - 2025-05-05T19:47:49

then you broke the hoover damn


---

### 1006. msg_8736

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:47:57

I honestly just want you to be honest and real


---

### 1007. msg_8737

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:48:06

If that is not chill, so be it


---

### 1008. msg_8738

**You** - 2025-05-05T19:48:07

I am but that is pain, and ache and longing


---

### 1009. msg_8739

**You** - 2025-05-05T19:48:09

so


---

### 1010. msg_8740

**You** - 2025-05-05T19:48:11

not cool


---

### 1011. msg_8741

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:48:22

That’s ok\. I have that too


---

### 1012. msg_8742

**You** - 2025-05-05T19:48:35

But I have let it define me\.\. and I don't know how to make it go the fuck away\.


---

### 1013. msg_8743

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:49:19

We just need time together\. Real time


---

### 1014. msg_8744

**You** - 2025-05-05T19:50:55

Yeah I know Mer but that isn't coming for months\.\. so I am just trying to solve this\.\. maybe there is something I haven't thought of yet\.\. I am not giving up\.


---

### 1015. msg_8745

**You** - 2025-05-05T19:51:39

But I mean I know we need time together\.\. we just aren't going to get it\.  So I don't even think about it because I know it won't happen\.


---

### 1016. msg_8746

**You** - 2025-05-05T19:52:08

and by solve this I mean me


---

### 1017. msg_8747

**You** - 2025-05-05T19:52:10

not time\.\.


---

### 1018. msg_8748

**You** - 2025-05-05T19:52:12

I cannot solve that


---

### 1019. msg_8749

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:52:16

It will happen\.


---

### 1020. msg_8750

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:52:32

Just not sure when exactly


---

### 1021. msg_8751

**You** - 2025-05-05T19:53:21

I love you Mer\.\. I will do whatever I have to, to get through this\.\. it just won't be pretty\.\. and I will likely be a lot messy by the end of it\.


---

### 1022. msg_8752

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T19:54:01

Yeah we both will\. :p


---

### 1023. msg_8753

**You** - 2025-05-05T21:02:07

not sure how long I am going to stay up tonight J and I have been fighting again \- not really bad but again it is the stress of it all\.


---

### 1024. msg_8754

**You** - 2025-05-05T21:03:55

I had to go upstairs to do some shit and I figured you had gone off to take care of some stuff when I got back anyways\.\. may be here or not\.\. not sure\.\. still doing some work \- if I can respond I will\.


---

### 1025. msg_8755

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T21:35:28

Fell asleep watching tv\. Tired\. Going to go to bed early xoxox miss you so much


---

### 1026. msg_8756

**You** - 2025-05-05T21:36:30

night xo ❤️


---

### 1027. msg_8757

**You** - 2025-05-05T21:41:17

Still not sure what my plan is tomorrow\.\. I will let you know in morning\.


---

### 1028. msg_8758

**Meredith Lamb \(\+14169386001\)** - 2025-05-05T21:45:25

kk ❤️


---

### 1029. msg_8759

**You** - 2025-05-05T22:28:54

Bed now night love you\.  Going to gym first thing tomorrow not sure what else to do anyways I will be up and going early\.


---

### 1030. msg_8760

**You** - 2025-05-06T05:30:37

Just an fyi so you are not surprised j will be in my office for a meeting at 11 am\.


---

### 1031. msg_8761

**You** - 2025-05-06T05:42:37

Also curious\.\. how did you fall asleep at 8 and sleep right through this morning… I know you worry about me but are you ok, anything going on that you aren’t telling me about health or otherwise\.  Goes both ways mer just worried\. Heading to gym now\.


---

### 1032. msg_8762

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:39:28

I’m feeling very drained and overwhelmed\.  Extremely\. Also worried\. Just a whole bunch of crap…\.\. makes me tired\. Also I watched 5 episodes of four seasons and went to bed at 11\.30\. So there’s that too\. Xo


---

### 1033. msg_8763

**You** - 2025-05-06T06:41:28

Understandable\. Sorry\.\. I know I am not helping\.  I will be in\-whenever this morning\.\.  no point in going in early\. See you whenever that is\.


---

### 1034. msg_8764

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:46:22

I convinced Andrew to tell the kids tonight\.


---

### 1035. msg_8765

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:47:05

He was not happy about it and kept trying to delay last night\. I think he just never wants to talk them\. I convinced him last night\. Tonight is the night\.


---

### 1036. msg_8766

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:47:14

I have to lead the entire conversation


---

### 1037. msg_8767

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:47:28

I have therapy at 12 so am going to talk to her about it today


---

### 1038. msg_8768

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:47:43


*1 attachment(s)*


---

### 1039. msg_8769

**You** - 2025-05-06T06:47:54

Well that will at least that will get that milestone out of the way\.\. I will be thinking about you\.  J mused about keeping the house again today\.\. I told her mathematically it won’t work I hope she just fucks off about it\.


---

### 1040. msg_8770

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:48:04

Got that yday email yday from Maelle’s teacher


---

### 1041. msg_8771

**You** - 2025-05-06T06:48:19

Shit


---

### 1042. msg_8772

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:48:23

I told her teacher that I know Maelle knows but my stupid husband won’t let me tell her


---

### 1043. msg_8773

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:48:38

Sent Andrew that email and was like wtf we have to tell them


---

### 1044. msg_8774

**You** - 2025-05-06T06:48:43

Well maybe this will give closure to everyone to move forward


---

### 1045. msg_8775

**You** - 2025-05-06T06:48:45

Move


---

### 1046. msg_8776

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:49:44

>
She must feel attached to it… sad\.


---

### 1047. msg_8777

**You** - 2025-05-06T06:50:22

No it is more to cater to Gracie


---

### 1048. msg_8778

**You** - 2025-05-06T06:50:37

I told her we engaged Mike in Moncton we are speaking to mortgage
And financial
Soecialists


---

### 1049. msg_8779

**You** - 2025-05-06T06:50:42

We cannot flip
Flop


---

### 1050. msg_8780

**You** - 2025-05-06T06:50:43

Anymore


---

### 1051. msg_8781

**You** - 2025-05-06T06:53:51

Reaction: ❤️ from Meredith Lamb
Just never ending fun\.  I mean just for the record\.\. and I will keep saying it every day if I have to\.\. I don’t mind\.  It makes me feel good to\.  I love you Meredith more than anything and no matter how shitty this gets I will be with you at the finish line if you will have me\.


---

### 1052. msg_8782

**You** - 2025-05-06T06:56:15

And yeah you know what I know it will be hard but when you can think on it I do want to see you in mornings sometimes\.\. nothing would make me happier than a few minutes alone with you to start the day\. Honestly


---

### 1053. msg_8783

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:56:28

Reaction: ❤️ from Scott Hicks
I already have you\. You already have me\. 🫠


---

### 1054. msg_8784

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T06:57:42

>
Okay I’m up for this\.


---

### 1055. msg_8785

**You** - 2025-05-06T06:58:24

Kk will chat later just finishing up here


---

### 1056. msg_8786

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T07:25:14

Okie\. And listen, I know you don’t fully know how I deal with stress yet \(maybe not sure\) but my nervous system is completely shot right now\. With separation, finding a new place to live, worrying about financials, my kids, my mom’s health, all the secrecy and then work \(I haven’t led a team that long\) etc etc etc\. worried about you at times \(YESTERDAY\), our reporting relationship … etc etc …my insides are completely shot right now\. I’m like a burnt vape\. Time with you would definitely help but …\.\. I know\. But I am not well despite what outward appearances may show\. But this will pass and I know after telling girls tonight it will help a bit while also making it harder at the same time\.


---

### 1057. msg_8787

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T07:34:18

https://open\.spotify\.com/track/6Bm6qUCSatPAqkQllFL7oA?si=UxIfv4QES2eh4ApLXO4pwA


---

### 1058. msg_8788

**You** - 2025-05-06T07:41:54

>
Hey I appreciate you sharing and I know you are having a tough time I just want to be with you I try to keep my problems to myself as I know you do yours a lot of the time\.\. I don’t want to weigh on you you need to let me keep some things in okay sometimes because honestly you do have a shit ton and you cannot hold my hand all the time through my own stuff\.\. if the morning request is too much right now I will cope\.  We can chat later I will book a meeting maybe right before j comes in?? What do you think?   J/k do not attack\!\!\!


---

### 1059. msg_8789

**You** - 2025-05-06T07:43:00

That is a great
Song\.\. look we can do whatever you want you want to leave 10 minutes apart and go drive over  accross the street behind that building and get a hug I will fucking do whatever to just give you a little bit of
Love to hold you through\.


---

### 1060. msg_8790

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T07:53:01

>
I don’t really get your joke at the end sorry
I gotta drive to work now\. Late again\. I just don’t want you to think I do something else to keep it all together and I’m somehow so different from you\. I am not\. Hence why all your stuff doesn’t really scare me\. May concern me but just bc I know the load… and what it feels like\.


---

### 1061. msg_8791

**You** - 2025-05-06T07:56:35

Kk well talk at
Work about all the stuff I will find a few mins\. I am honestly up for anything big or small that you can deal with and that helps us both


---

### 1062. msg_8792

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T08:45:39

I just cannot……

*1 attachment(s)*


---

### 1063. msg_8793

**You** - 2025-05-06T08:46:10

Still eh


---

### 1064. msg_8794

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T08:46:36

Talked to big brother Jim this morning about it\. Helped a little


---

### 1065. msg_8795

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T08:50:52

>
It’s not really that constant anymore but I could tell he wanted to say that last night\. The thing that zaps my nerves is that he doesn’t give a shit about me, it is just the image of the life of us together etc etc … he could care less if I was in that life suicidal as long as the image was there outwardly for everyone\.


---

### 1066. msg_8796

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T08:52:22

I said to Jim this morning “at least Scott knows don’t makes work a bit more manageable right now” and he was all “oh if anyone can relate…\.”


---

### 1067. msg_8797

**You** - 2025-05-06T09:38:25

Yeah Jim is great that way I wish I could tell him but he would be onto us in 1/2
Second\.  Not sure he would care would probably be happy and help us keep
It a secret but man too risky\.\. would be nice to talk to him about the I bullshit though\.


---

### 1068. msg_8798

**You** - 2025-05-06T09:38:56

J was difficult again this morning fought in car in way in we sat in a meeting room for 30 mins still off\.


---

### 1069. msg_8799

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T09:39:41

30 minutes?


---

### 1070. msg_8800

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T09:39:43

Wow


---

### 1071. msg_8801

**You** - 2025-05-06T09:39:56

The joke earlier was that j is coming to my office for an 11 am meeting and I was going to book you for a meeting from 10 to 11


---

### 1072. msg_8802

**You** - 2025-05-06T09:40:03

And the\. I said just joking


---

### 1073. msg_8803

**You** - 2025-05-06T09:40:12

Emphatically


---

### 1074. msg_8804

**You** - 2025-05-06T09:40:28

Yeah more like an hour for drive and 30 mins here


---

### 1075. msg_8805

**You** - 2025-05-06T09:40:35

But she is not asking me to get back together


---

### 1076. msg_8806

**You** - 2025-05-06T09:40:40

And hasn’t for weeks


---

### 1077. msg_8807

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T09:44:35

Ohhhh\. Is she really going to your office at 11?


---

### 1078. msg_8808

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T09:44:39

😬


---

### 1079. msg_8809

**You** - 2025-05-06T09:44:51

Yes


---

### 1080. msg_8810

**You** - 2025-05-06T09:45:04

We have a meeting with a mortgage broker in Moncton


---

### 1081. msg_8811

**You** - 2025-05-06T09:45:11

I messaged you about this this morning inf


---

### 1082. msg_8812

**You** - 2025-05-06T09:45:14

Was an fyi


---

### 1083. msg_8813

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T09:46:38

Ohhhh didn’t fully get this\. I I thought the j was “I”

*1 attachment(s)*


---

### 1084. msg_8814

**You** - 2025-05-06T09:47:43

Ah ok sry\.


---

### 1085. msg_8815

**You** - 2025-05-06T09:48:12



---

### 1086. msg_8816

**You** - 2025-05-06T09:55:36



---

### 1087. msg_8817

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T10:21:42

I think I have this today\. My sister had it when she went through her last divorce\.

*1 attachment(s)*


---

### 1088. msg_8818

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T10:43:49

🤔

*1 attachment(s)*


---

### 1089. msg_8819

**You** - 2025-05-06T10:47:34

This further supports my suggestion for afte and before work\.


---

### 1090. msg_8820

**You** - 2025-05-06T10:48:13

The deletions were because you missed an invite to my office and I figured to delete because you had t read until the time was
Past anyways\.


---

### 1091. msg_8821

**You** - 2025-05-06T10:48:41

>
I swear I can make this go away for a while\.


---

### 1092. msg_8822

**You** - 2025-05-06T10:51:10

Running down to get some food


---

### 1093. msg_8823

**You** - 2025-05-06T10:51:20

J will be here in 10


---

### 1094. msg_8824

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T10:52:07

k I have a meeting at 11 phew lol


---

### 1095. msg_8825

**You** - 2025-05-06T12:09:57

It is safe


---

### 1096. msg_8826

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T12:41:43

lol


---

### 1097. msg_8827

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T12:41:49

How’d it go


---

### 1098. msg_8828

**You** - 2025-05-06T12:42:12

Come in and I will tell you much to detailed to text


---

### 1099. msg_8829

**You** - 2025-05-06T12:48:58

I have Yolanda popping in at 1 but it will be quick\.\.


---

### 1100. msg_8830

**You** - 2025-05-06T12:49:09

Maybe between when I finish and your 1:30


---

### 1101. msg_8831

**You** - 2025-05-06T13:03:03

Hope that went well


---

### 1102. msg_8832

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T14:02:42

Omg…

*1 attachment(s)*


---

### 1103. msg_8833

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T14:03:34


*1 attachment(s)*


---

### 1104. msg_8834

**You** - 2025-05-06T14:04:35

Sry mer\.


---

### 1105. msg_8835

**You** - 2025-05-06T14:04:59

I know you need to get this done, I think discussion is over


---

### 1106. msg_8836

**You** - 2025-05-06T14:05:10

Leaver early and just go do it whether he wants to or not


---

### 1107. msg_8837

**You** - 2025-05-06T14:13:03

Ick


---

### 1108. msg_8838

**You** - 2025-05-06T14:13:10

I am guessing it continued


---

### 1109. msg_8839

**You** - 2025-05-06T16:45:33

You are going to have a rough night do not feel obligated to reach out\.  Good luck I love you\.


---

### 1110. msg_8840

**You** - 2025-05-06T16:46:06

And I hope your mum does ok tomorrow


---

### 1111. msg_8841

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T17:08:51

We will see if he even “allows” me to tell them\. He constantly says I’m being selfish and telling them for my benefit only\. 🙄


---

### 1112. msg_8842

**You** - 2025-05-06T17:09:11

Just do it get it over with


---

### 1113. msg_8843

**You** - 2025-05-06T17:09:16

Too heavy


---

### 1114. msg_8844

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T17:09:24

I know\. I will


---

### 1115. msg_8845

**You** - 2025-05-06T17:10:01

Well I am here for whatever you need but like I said don’t feel obligated tonight focus on you


---

### 1116. msg_8846

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T18:29:16

Most anti\-climatic situation ever\. They knew\. No tears\. All fine\.


---

### 1117. msg_8847

**You** - 2025-05-06T18:37:31

Are you ok


---

### 1118. msg_8848

**You** - 2025-05-06T18:37:42

Reaction: 👎 from Meredith Lamb
I just had another fight with Gracie super fun\.\.


---

### 1119. msg_8849

**You** - 2025-05-06T18:37:48

But glad it sounds like it went ok


---

### 1120. msg_8850

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T18:38:18

I feel great\. Had 2 glasses of wine during the convo and now taking dogs to park


---

### 1121. msg_8851

**You** - 2025-05-06T18:40:05

Enjoy happy for you


---

### 1122. msg_8852

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T18:45:07

I mean I’m sure it will get bad but they knew and seemed relieved to be told\. They are also happy with the plan so…\.


---

### 1123. msg_8853

**You** - 2025-05-06T18:53:27

Well that must be a HUGE relief for you


---

### 1124. msg_8854

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:00:27

At park with Marlowe and she said it was a relief but then she goes “I was just wondering who you were talking to that night” 🙄


---

### 1125. msg_8855

**You** - 2025-05-06T19:05:19

lol I thought that might come up


---

### 1126. msg_8856

**You** - 2025-05-06T19:05:26

How did you answer


---

### 1127. msg_8857

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:07:06

I was a little caught off guard tbh


---

### 1128. msg_8858

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:07:21

I said that has nothing to do with this


---

### 1129. msg_8859

**You** - 2025-05-06T19:07:43

At leaa as t it is Ther


---

### 1130. msg_8860

**You** - 2025-05-06T19:07:45

Try


---

### 1131. msg_8861

**You** - 2025-05-06T19:07:56

Aararegg


---

### 1132. msg_8862

**You** - 2025-05-06T19:08:02

True


---

### 1133. msg_8863

**You** - 2025-05-06T19:08:22

lol c and how did Andrew do


---

### 1134. msg_8864

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:08:58

What would you have said?


---

### 1135. msg_8865

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:09:06

It really tested me omg


---

### 1136. msg_8866

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:09:16

>
He didn’t say much


---

### 1137. msg_8867

**You** - 2025-05-06T19:09:23

I would have likely said something similar


---

### 1138. msg_8868

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:09:43

He kind of teared up but didn’t full out cry bc none of them were even close to it


---

### 1139. msg_8869

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:09:54

He thought they’d be crying


---

### 1140. msg_8870

**You** - 2025-05-06T19:09:56

Well that was my next question


---

### 1141. msg_8871

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:09:57

He’s so stupid


---

### 1142. msg_8872

**You** - 2025-05-06T19:10:05

I also now know I can never cry around you


---

### 1143. msg_8873

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:10:06

They have known for a while


---

### 1144. msg_8874

**You** - 2025-05-06T19:10:17

Do you wonder why k worry about showing weakness lol really


---

### 1145. msg_8875

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:10:17

>
Not true\!\!\!


---

### 1146. msg_8876

**You** - 2025-05-06T19:10:22

Rofl


---

### 1147. msg_8877

**You** - 2025-05-06T19:10:33

Or do you think it is fake vs real


---

### 1148. msg_8878

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:10:33

Haha am I that bad?


---

### 1149. msg_8879

**You** - 2025-05-06T19:11:11

I think you look at the world through your eyes\.\.


---

### 1150. msg_8880

**You** - 2025-05-06T19:11:17

Safe…\.\.


---

### 1151. msg_8881

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:11:24

?


---

### 1152. msg_8882

**You** - 2025-05-06T19:11:24

lol


---

### 1153. msg_8883

**You** - 2025-05-06T19:11:35

I rewrote five
Times


---

### 1154. msg_8884

**You** - 2025-05-06T19:11:39

It was a trap


---

### 1155. msg_8885

**You** - 2025-05-06T19:11:42

lol


---

### 1156. msg_8886

**You** - 2025-05-06T19:11:49

I do t mer


---

### 1157. msg_8887

**You** - 2025-05-06T19:11:58

I think you deal
With emotions differently is all


---

### 1158. msg_8888

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:12:13

>
?


---

### 1159. msg_8889

**You** - 2025-05-06T19:12:14

I know you have them you looked so tormented today


---

### 1160. msg_8890

**You** - 2025-05-06T19:12:38

>
I was trying to say what I meant to say and shit can come accross wrong


---

### 1161. msg_8891

**You** - 2025-05-06T19:12:47

It isn’t bad it is different


---

### 1162. msg_8892

**You** - 2025-05-06T19:13:17

I mean it is evident yku have extremely strong emotions\.


---

### 1163. msg_8893

**You** - 2025-05-06T19:14:21

This is one of those topics o would rather not discuss anymore ever again\.\. let’s just say I appreciate yku for who you are and after the last few days have a much better understanding of yku


---

### 1164. msg_8894

**You** - 2025-05-06T19:14:29

Thanks in part to some of what you shared this morning


---

### 1165. msg_8895

**You** - 2025-05-06T19:14:59

Please say something so I can stop typing\.


---

### 1166. msg_8896

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:15:13

LOL


---

### 1167. msg_8897

**You** - 2025-05-06T19:15:23

😢


---

### 1168. msg_8898

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:15:31

I talked to my therapist about this today


---

### 1169. msg_8899

**You** - 2025-05-06T19:15:42

About what


---

### 1170. msg_8900

**You** - 2025-05-06T19:15:46

Emotions


---

### 1171. msg_8901

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:16:23

One sec


---

### 1172. msg_8902

**You** - 2025-05-06T19:16:28

Yep


---

### 1173. msg_8903

**You** - 2025-05-06T19:18:24

For the record last one sec was 3 hours long\.  Just saying 🙂


---

### 1174. msg_8904

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:20:01

Sorry lol


---

### 1175. msg_8905

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:22:44

Yes, I talked to her about you thinking I have this special power just because I don’t outwardly show all of my emotions meanwhile my internal nervous system is going nuts…\. I have everyone in my life needing something from me… siblings, parents, Andrew, kids, dogs, work, etc and it is a lot\. That’s all


---

### 1176. msg_8906

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:23:35

I have 3 kids all needy in their own way\. It’s a lot\. And one isn’t even a teen yet\.


---

### 1177. msg_8907

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:23:42

\(Annoying\)


---

### 1178. msg_8908

**You** - 2025-05-06T19:24:03

>
Me


---

### 1179. msg_8909

**You** - 2025-05-06T19:24:07

You left me out


---

### 1180. msg_8910

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:24:27

Because you were the center topic


---

### 1181. msg_8911

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:25:48

I want to be there 100% for you but it is a lot right now and I can’t the way I would prefer


---

### 1182. msg_8912

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:25:59

And that bothers me also


---

### 1183. msg_8913

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:26:19

And then things like Jaime coming to your office on our floor omg come on


---

### 1184. msg_8914

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:26:36

Lump in throat >


---

### 1185. msg_8915

**You** - 2025-05-06T19:26:47

In car I have more freedom now sorry


---

### 1186. msg_8916

**You** - 2025-05-06T19:26:52

Reading


---

### 1187. msg_8917

**You** - 2025-05-06T19:27:27

No come on fuck


---

### 1188. msg_8918

**You** - 2025-05-06T19:27:33

You can talk right


---

### 1189. msg_8919

**You** - 2025-05-06T19:27:39

I kinda want to reassure you there


---

### 1190. msg_8920

**You** - 2025-05-06T19:28:12

Can’t


---

### 1191. msg_8921

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:28:46

It isn’t about reassurance\. It is about shit I don’t want to see\.


---

### 1192. msg_8922

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:28:50

That’s all\.


---

### 1193. msg_8923

**You** - 2025-05-06T19:29:07

I can book a room next time


---

### 1194. msg_8924

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:29:49

Do you think she would have come to your office had she known about me and where I sat?


---

### 1195. msg_8925

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:29:55

Probably not\.


---

### 1196. msg_8926

**You** - 2025-05-06T19:29:56

No


---

### 1197. msg_8927

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:30:00

Exactly


---

### 1198. msg_8928

**You** - 2025-05-06T19:30:02

100%


---

### 1199. msg_8929

**You** - 2025-05-06T19:30:12

But why does that bother you


---

### 1200. msg_8930

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:30:13

Just shit no one wants to see


---

### 1201. msg_8931

**You** - 2025-05-06T19:30:28

Ok like I said


---

### 1202. msg_8932

**You** - 2025-05-06T19:30:32

I will go somewhere else


---

### 1203. msg_8933

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:30:41

I think it is just already being at a heightened level of over stress/over stimulation


---

### 1204. msg_8934

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:31:00

If life was “normal” it’d be different


---

### 1205. msg_8935

**You** - 2025-05-06T19:31:19

Maybe, you are right no one wants to see I wouldn’t either


---

### 1206. msg_8936

**You** - 2025-05-06T19:31:45

I am sorry that hurt you I did try to warn you


---

### 1207. msg_8937

**You** - 2025-05-06T19:31:53

But I will do we’re


---

### 1208. msg_8938

**You** - 2025-05-06T19:31:56

Better


---

### 1209. msg_8939

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:32:19

Just maybe do it if I’m not around\.


---

### 1210. msg_8940

**You** - 2025-05-06T19:32:54

I will just go away


---

### 1211. msg_8941

**You** - 2025-05-06T19:32:59

And not say anything


---

### 1212. msg_8942

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:33:00

The price of having a work girlfriend lol


---

### 1213. msg_8943

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:33:33

I won’t bring Andrew to work and have calls in front of you\.


---

### 1214. msg_8944

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:33:44

😝


---

### 1215. msg_8945

**You** - 2025-05-06T19:34:14

It’s fine bring him in you can introduce him to your boss


---

### 1216. msg_8946

**You** - 2025-05-06T19:34:35

🤯


---

### 1217. msg_8947

**You** - 2025-05-06T19:34:55

I think I get points there


---

### 1218. msg_8948

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:35:47

LOL


---

### 1219. msg_8949

**You** - 2025-05-06T19:36:28

Remember you are only the boss out of the office


---

### 1220. msg_8950

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:36:51

Hopefully


---

### 1221. msg_8951

**You** - 2025-05-06T19:37:08

Nope you are been established


---

### 1222. msg_8952

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:38:10

🤠


---

### 1223. msg_8953

**You** - 2025-05-06T19:38:42

Hmm busy at gym tonight\.\.  glad I am not going hard


---

### 1224. msg_8954

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:38:58

So was the Gracie stuff same old same old


---

### 1225. msg_8955

**You** - 2025-05-06T19:39:03

Yeah but


---

### 1226. msg_8956

**You** - 2025-05-06T19:39:23

I think I might have convinced Jaimie to put an offer in on a house in Moncton


---

### 1227. msg_8957

**You** - 2025-05-06T19:39:31

Tomorrow


---

### 1228. msg_8958

**You** - 2025-05-06T19:39:34

Potentially


---

### 1229. msg_8959

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:39:45

Wow, that is huge


---

### 1230. msg_8960

**You** - 2025-05-06T19:39:46

60 day closing likely


---

### 1231. msg_8961

**You** - 2025-05-06T19:39:50

But unsure


---

### 1232. msg_8962

**You** - 2025-05-06T19:39:56

Gracie being an ass


---

### 1233. msg_8963

**You** - 2025-05-06T19:40:09

Still will
Fight to the bitter end and causes j and I to fight


---

### 1234. msg_8964

**You** - 2025-05-06T19:40:30

She wants to stay here with me\.\. but there is no way it will work


---

### 1235. msg_8965

**You** - 2025-05-06T19:40:43

and j wants her to go there anyways


---

### 1236. msg_8966

**You** - 2025-05-06T19:40:52

She is just still
Living in a fantasy world


---

### 1237. msg_8967

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:41:24

Yikes, too bad\. Therapist doesn’t help?


---

### 1238. msg_8968

**You** - 2025-05-06T19:41:57

Nope I mean you would have to have all
Of the details\.\. but like I was completely broken last
Year
From
About Feb to July


---

### 1239. msg_8969

**You** - 2025-05-06T19:42:06

And I was
On stress
Leave\.


---

### 1240. msg_8970

**You** - 2025-05-06T19:42:36

The relationship is insanely toxic at this point and I am done getting broken and trying to lift her up at this age


---

### 1241. msg_8971

**You** - 2025-05-06T19:42:57

Not I


---

### 1242. msg_8972

**You** - 2025-05-06T19:43:00

J


---

### 1243. msg_8973

**You** - 2025-05-06T19:43:15

Like Gracie kind of created
A
Rift in the family


---

### 1244. msg_8974

**You** - 2025-05-06T19:43:26

J and I tried different ways but nothing worked


---

### 1245. msg_8975

**You** - 2025-05-06T19:44:09

So now it is reality time I said if she lived
With me she is working full
Time
Paying for her stuff accomplishing the goals we
Layout and the year after she can go to university


---

### 1246. msg_8976

**You** - 2025-05-06T19:44:13

She won’t do it


---

### 1247. msg_8977

**You** - 2025-05-06T19:44:18

She says I need to help her


---

### 1248. msg_8978

**You** - 2025-05-06T19:44:23

And I know what that means


---

### 1249. msg_8979

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:44:40

😬


---

### 1250. msg_8980

**You** - 2025-05-06T19:45:06

Yeah it is a mess and I feel bad but the same
Kind of
Poking I do to you about emotions they do to me


---

### 1251. msg_8981

**You** - 2025-05-06T19:45:26

And j won’t let me defend myself … so Gracie feels
Validated


---

### 1252. msg_8982

**You** - 2025-05-06T19:45:30

Super
Fun


---

### 1253. msg_8983

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:45:46

Yikes, they say you have no emotions?


---

### 1254. msg_8984

**You** - 2025-05-06T19:45:50

Yes


---

### 1255. msg_8985

**You** - 2025-05-06T19:45:52

None


---

### 1256. msg_8986

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:45:57

I have emotions\! Lol


---

### 1257. msg_8987

**You** - 2025-05-06T19:45:59

I told them this is just who I am here


---

### 1258. msg_8988

**You** - 2025-05-06T19:46:06

I know you do


---

### 1259. msg_8989

**You** - 2025-05-06T19:46:08

lol


---

### 1260. msg_8990

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:46:18

Maybe I’m just a terminator and no one knows it


---

### 1261. msg_8991

**You** - 2025-05-06T19:46:23

I am going to make you cry happy tears
Someday…


---

### 1262. msg_8992

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:46:27

They need to cut off my skin


---

### 1263. msg_8993

**You** - 2025-05-06T19:46:27

Wait for it


---

### 1264. msg_8994

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:46:42

Sure lol


---

### 1265. msg_8995

**You** - 2025-05-06T19:46:55

I will


---

### 1266. msg_8996

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:47:02

Uh huh…


---

### 1267. msg_8997

**You** - 2025-05-06T19:47:02

You will never ever see it coming


---

### 1268. msg_8998

**You** - 2025-05-06T19:47:13

And then… it will just happen


---

### 1269. msg_8999

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:47:21

Okay


---

### 1270. msg_9000

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:47:35

I have never cried happy tears


---

### 1271. msg_9001

**You** - 2025-05-06T19:47:40

Oh man soooooo much challenge
Accepted


---

### 1272. msg_9002

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:47:42

Like I don’t even understand that


---

### 1273. msg_9003

**You** - 2025-05-06T19:47:56

Again you will


---

### 1274. msg_9004

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:47:59

I could never do something I don’t understand


---

### 1275. msg_9005

**You** - 2025-05-06T19:48:08

I didn’t understand this


---

### 1276. msg_9006

**You** - 2025-05-06T19:48:13

But I am doing it


---

### 1277. msg_9007

**You** - 2025-05-06T19:48:20

Now you say touché


---

### 1278. msg_9008

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:48:27

I don’t think that’s true really


---

### 1279. msg_9009

**You** - 2025-05-06T19:48:40

Omg………\.😳


---

### 1280. msg_9010

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:48:50

I mean


---

### 1281. msg_9011

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:48:59

You have seen romantic movies and stuff


---

### 1282. msg_9012

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:49:07

You have some level of understanding


---

### 1283. msg_9013

**You** - 2025-05-06T19:49:29

Noooooo…… lol


---

### 1284. msg_9014

**You** - 2025-05-06T19:49:41

How can you watch a movie and understand the intensity of a feeling


---

### 1285. msg_9015

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:49:43

You are 46


---

### 1286. msg_9016

**You** - 2025-05-06T19:49:51

You complete me
Doesn’t do this justice


---

### 1287. msg_9017

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:49:56

lol


---

### 1288. msg_9018

**You** - 2025-05-06T19:50:03

Or just a guy standing in front of a girl


---

### 1289. msg_9019

**You** - 2025-05-06T19:50:07

Like wel


---

### 1290. msg_9020

**You** - 2025-05-06T19:50:09

Maybe that one


---

### 1291. msg_9021

**You** - 2025-05-06T19:50:14

A little


---

### 1292. msg_9022

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:50:16

See, you have some level of understanding


---

### 1293. msg_9023

**You** - 2025-05-06T19:50:23

Still not the same


---

### 1294. msg_9024

**You** - 2025-05-06T19:50:26

Not even close


---

### 1295. msg_9025

**You** - 2025-05-06T19:50:47

You won’t convince me\.\.
This hit
Me like nothing ever has
I had absolutely no control


---

### 1296. msg_9026

**You** - 2025-05-06T19:50:53

Still don’t have much


---

### 1297. msg_9027

**You** - 2025-05-06T19:51:06

My emotions are ruling me all
Over the place


---

### 1298. msg_9028

**You** - 2025-05-06T19:51:12

That is why I am having a hard time


---

### 1299. msg_9029

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:51:31

I know… I’m with you\.


---

### 1300. msg_9030

**You** - 2025-05-06T19:51:40

So I can honestly say no I have never experienced
Anything like this ever\.\.


---

### 1301. msg_9031

**You** - 2025-05-06T19:51:58

And the books and movies and Disney


---

### 1302. msg_9032

**You** - 2025-05-06T19:52:02

Don’t do it justice


---

### 1303. msg_9033

**You** - 2025-05-06T19:52:19

Which makes
Me
A little happy tbh


---

### 1304. msg_9034

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:52:31

What about true romance though?


---

### 1305. msg_9035

**You** - 2025-05-06T19:52:37

The movie


---

### 1306. msg_9036

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:52:42

That movie kind of does it justice lol


---

### 1307. msg_9037

**You** - 2025-05-06T19:52:43

Or the idea


---

### 1308. msg_9038

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:52:44

lol


---

### 1309. msg_9039

**You** - 2025-05-06T19:52:48

Mmmmmm no


---

### 1310. msg_9040

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:52:51

Haha


---

### 1311. msg_9041

**You** - 2025-05-06T19:53:03

Serendipity is kind of romantic


---

### 1312. msg_9042

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:53:17

I guess\.


---

### 1313. msg_9043

**You** - 2025-05-06T19:53:26

Been a long time since I watched that


---

### 1314. msg_9044

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:53:31

Same


---

### 1315. msg_9045

**You** - 2025-05-06T19:53:33

Ever after\.\.


---

### 1316. msg_9046

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:53:38

LOL


---

### 1317. msg_9047

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:53:58

Tell me you are a girl dad with out telling me you are a girl dad


---

### 1318. msg_9048

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:54:02

Ever after


---

### 1319. msg_9049

**You** - 2025-05-06T19:54:13

I watched that long before I had girls


---

### 1320. msg_9050

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:54:22

Really wow


---

### 1321. msg_9051

**You** - 2025-05-06T19:54:28

It is a good movie


---

### 1322. msg_9052

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:54:38

Is it?


---

### 1323. msg_9053

**You** - 2025-05-06T19:54:46

I think so


---

### 1324. msg_9054

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:54:52

Before sunrise


---

### 1325. msg_9055

**You** - 2025-05-06T19:55:05

Saw that once and I was
Drunk as
Shit


---

### 1326. msg_9056

**You** - 2025-05-06T19:55:13

So fairly certain I didn’t appreciate it


---

### 1327. msg_9057

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T19:55:38

lol


---

### 1328. msg_9058

**You** - 2025-05-06T19:58:11

Well it is gym time again


---

### 1329. msg_9059

**You** - 2025-05-06T19:58:44

And getting g man compliments\.\. makes me feel
Soo good\!\!


---

### 1330. msg_9060

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:00:00

G man?


---

### 1331. msg_9061

**You** - 2025-05-06T20:00:30

No g man\.\. just man compliments


---

### 1332. msg_9062

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:00:47

Oh lol


---

### 1333. msg_9063

**You** - 2025-05-06T20:01:16

Hey you take what you can get
Alright no judging lol


---

### 1334. msg_9064

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:01:41

No judgement


---

### 1335. msg_9065

**You** - 2025-05-06T20:04:02

Ok I feel like it is about time for you to get off you probably want to watch your shows\.\. starting to get a bit distracted\.\. all good go enjoy your night\.


---

### 1336. msg_9066

**You** - 2025-05-06T20:05:02

In case
You are wondering how I notice I scroll back and look at the number of words in your responses\.  lol\. Sure fire way to tell\.


---

### 1337. msg_9067

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:06:09

lol I’m watching four seasons and my SIL keeps texting\. She won’t stop


---

### 1338. msg_9068

**You** - 2025-05-06T20:07:53

I feel like I need to make some friends what do ya think\.


---

### 1339. msg_9069

**You** - 2025-05-06T20:08:03

I think that would be healthy


---

### 1340. msg_9070

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:08:28

Um, Hmmh no you’re good


---

### 1341. msg_9071

**You** - 2025-05-06T20:08:36

No I really am not


---

### 1342. msg_9072

**You** - 2025-05-06T20:08:39

Being serious


---

### 1343. msg_9073

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:08:44

k fine


---

### 1344. msg_9074

**You** - 2025-05-06T20:08:48

If you looked T my phone


---

### 1345. msg_9075

**You** - 2025-05-06T20:08:52

I talk to you…


---

### 1346. msg_9076

**You** - 2025-05-06T20:08:56

And no one


---

### 1347. msg_9077

**You** - 2025-05-06T20:09:04

So yeah


---

### 1348. msg_9078

**You** - 2025-05-06T20:09:23

I think I need to somehow\.\. if I had friends this wouldn’t be all on you


---

### 1349. msg_9079

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:09:30

I mean that is normal for males no?


---

### 1350. msg_9080

**You** - 2025-05-06T20:09:40

To not have any friends


---

### 1351. msg_9081

**You** - 2025-05-06T20:09:43

At L
All


---

### 1352. msg_9082

**You** - 2025-05-06T20:09:47

lol


---

### 1353. msg_9083

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:09:52

Or to not talk about stuff like this


---

### 1354. msg_9084

**You** - 2025-05-06T20:09:59

It isn’t to talk


---

### 1355. msg_9085

**You** - 2025-05-06T20:10:03

It is to go do things


---

### 1356. msg_9086

**You** - 2025-05-06T20:10:10

Keep my mind occupied


---

### 1357. msg_9087

**You** - 2025-05-06T20:10:21

I could many find better balance


---

### 1358. msg_9088

**You** - 2025-05-06T20:10:42

Been thinking\. Out how to get through all of the time we have to get through


---

### 1359. msg_9089

**You** - 2025-05-06T20:11:17

Besides you have all kinds of friends to do stuff with\.\.


---

### 1360. msg_9090

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:11:31

Yeah it is going to be long but then we do stuff together


---

### 1361. msg_9091

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:11:38

I don’t do stuff with friends


---

### 1362. msg_9092

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:11:43

I have too many kids


---

### 1363. msg_9093

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:11:45

:p


---

### 1364. msg_9094

**You** - 2025-05-06T20:11:55

Well then I need to get more kids??


---

### 1365. msg_9095

**You** - 2025-05-06T20:11:57

lol


---

### 1366. msg_9096

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:12:02

No


---

### 1367. msg_9097

**You** - 2025-05-06T20:12:03

That doesn’t track


---

### 1368. msg_9098

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:12:12

Big no


---

### 1369. msg_9099

**You** - 2025-05-06T20:12:14

Adopte


---

### 1370. msg_9100

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:12:18

No


---

### 1371. msg_9101

**You** - 2025-05-06T20:12:27

Someone out there needs me I am sure


---

### 1372. msg_9102

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:12:33

Yeah


---

### 1373. msg_9103

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:12:35

Me


---

### 1374. msg_9104

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:12:37

Duh


---

### 1375. msg_9105

**You** - 2025-05-06T20:13:02

W/e but you have to admit my life is pretty empty\.\. I am just looking to stay healthy


---

### 1376. msg_9106

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:13:28

Your life is not empty, it is just the way you are choosing to view it\.


---

### 1377. msg_9107

**You** - 2025-05-06T20:13:28

I wasn’t thinking ‘girl’ friends


---

### 1378. msg_9108

**You** - 2025-05-06T20:13:30

They would\. E men


---

### 1379. msg_9109

**You** - 2025-05-06T20:13:36

What


---

### 1380. msg_9110

**You** - 2025-05-06T20:13:39

Omg


---

### 1381. msg_9111

**You** - 2025-05-06T20:13:48

>
This is not a zen thing


---

### 1382. msg_9112

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:13:57

Seriously


---

### 1383. msg_9113

**You** - 2025-05-06T20:14:03

I think I am full therefore I am


---

### 1384. msg_9114

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:08

You have ppl in your life


---

### 1385. msg_9115

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:24

You have ME


---

### 1386. msg_9116

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:30

you have daughters


---

### 1387. msg_9117

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:33

Sister


---

### 1388. msg_9118

**You** - 2025-05-06T20:14:34

Ok but read your earlier text


---

### 1389. msg_9119

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:37

Friends


---

### 1390. msg_9120

**You** - 2025-05-06T20:14:40

No


---

### 1391. msg_9121

**You** - 2025-05-06T20:14:43

Do not


---

### 1392. msg_9122

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:44

Even tho you say you don’t


---

### 1393. msg_9123

**You** - 2025-05-06T20:14:53

Sister only talks to
Me when I call her


---

### 1394. msg_9124

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:14:55

>
?


---

### 1395. msg_9125

**You** - 2025-05-06T20:14:57

Kids are messed


---

### 1396. msg_9126

**You** - 2025-05-06T20:15:17

I have you yes in heart and mind 😃


---

### 1397. msg_9127

**You** - 2025-05-06T20:16:12

Again what I am shooting for is to make our lives easier so every time I see you I do t feel like I need to unload every emotion on your because I am better able to manage


---

### 1398. msg_9128

**You** - 2025-05-06T20:16:22

I cannot do
That with just gym and an empty basement


---

### 1399. msg_9129

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:16:36

Things are going to unfold naturally in time\.


---

### 1400. msg_9130

**You** - 2025-05-06T20:16:52

You have e said that before


---

### 1401. msg_9131

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:16:55

I get my own place\. You guys figure out your situation\. Etc etc


---

### 1402. msg_9132

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:17:05

It will happen


---

### 1403. msg_9133

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:17:18

Then eventually maybe we can tell ppl


---

### 1404. msg_9134

**You** - 2025-05-06T20:17:28

Ok but I am not trying to replace you\.\.


---

### 1405. msg_9135

**You** - 2025-05-06T20:17:35

I mean let me be honey


---

### 1406. msg_9136

**You** - 2025-05-06T20:17:39

Honest


---

### 1407. msg_9137

**You** - 2025-05-06T20:17:51

You easily could satisfy every need I have period


---

### 1408. msg_9138

**You** - 2025-05-06T20:18:00

Lover friend confident partner in


---

### 1409. msg_9139

**You** - 2025-05-06T20:18:05

Everything


---

### 1410. msg_9140

**You** - 2025-05-06T20:18:24

It it is a long way off and I M admittedly having a really hard time and I M just trying to find a bridge


---

### 1411. msg_9141

**You** - 2025-05-06T20:18:31

I do see you that way


---

### 1412. msg_9142

**You** - 2025-05-06T20:18:38

And I have never felt that way about anyone


---

### 1413. msg_9143

**You** - 2025-05-06T20:18:47

The you complete me is cheesy but accurate


---

### 1414. msg_9144

**You** - 2025-05-06T20:19:02

But there is right now


---

### 1415. msg_9145

**You** - 2025-05-06T20:19:13

And zero is too hard for me


---

### 1416. msg_9146

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:19:26

How do you just keep typing\. My breath stops a little and you don’t even pause


---

### 1417. msg_9147

**You** - 2025-05-06T20:19:38

Too much energy


---

### 1418. msg_9148

**You** - 2025-05-06T20:19:41

Emotions


---

### 1419. msg_9149

**You** - 2025-05-06T20:19:44

Like I said


---

### 1420. msg_9150

**You** - 2025-05-06T20:19:58

I do t want to put all
Of it I\. You this way


---

### 1421. msg_9151

**You** - 2025-05-06T20:20:01

Right now


---

### 1422. msg_9152

**You** - 2025-05-06T20:20:04

Reaction: 😂 from Meredith Lamb
Later sure


---

### 1423. msg_9153

**You** - 2025-05-06T20:20:23

It it is too hard and I M not trying to be hurtful I know we are doing the best we can


---

### 1424. msg_9154

**You** - 2025-05-06T20:20:31

But even today I had to really focus


---

### 1425. msg_9155

**You** - 2025-05-06T20:20:49

On not letting shit overwhelm
Me


---

### 1426. msg_9156

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:20:52

Yeah I know… I can’t handle it all right now\. I wish I could


---

### 1427. msg_9157

**You** - 2025-05-06T20:21:02

Partly why I want to him


---

### 1428. msg_9158

**You** - 2025-05-06T20:21:04

Jim


---

### 1429. msg_9159

**You** - 2025-05-06T20:21:35

Anyways all
I am saying is that I might need to find some support through some friends
Maybe dudes
From gym maybe join a basketball league or something


---

### 1430. msg_9160

**You** - 2025-05-06T20:21:57

Very lonely\.\. 😞 so just trying  it to carry that all the time


---

### 1431. msg_9161

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:22:21

You can tell Jim


---

### 1432. msg_9162

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:22:30

You can join a league


---

### 1433. msg_9163

**You** - 2025-05-06T20:22:31

I still do t want to risk it


---

### 1434. msg_9164

**You** - 2025-05-06T20:22:52

And I won’t tell him till we do the hand holding thing


---

### 1435. msg_9165

**You** - 2025-05-06T20:22:54

Epic


---

### 1436. msg_9166

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:23:02


*1 attachment(s)*


---

### 1437. msg_9167

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:23:39

Jim’s a bad influence\. Be careful


---

### 1438. msg_9168

**You** - 2025-05-06T20:23:45

Ok now text him hey Jim btw I am in love with my boss and he is madly in love with me


---

### 1439. msg_9169

**You** - 2025-05-06T20:23:50

Then send me that text response


---

### 1440. msg_9170

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:23:57

Yeah WHATEVER


---

### 1441. msg_9171

**You** - 2025-05-06T20:24:09

No no I am curious lol


---

### 1442. msg_9172

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:24:17

Sure you are


---

### 1443. msg_9173

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:24:25

You would freak out if I told him


---

### 1444. msg_9174

**You** - 2025-05-06T20:24:30

Nope


---

### 1445. msg_9175

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:24:35

Sure


---

### 1446. msg_9176

**You** - 2025-05-06T20:24:37

Nope


---

### 1447. msg_9177

**You** - 2025-05-06T20:24:41

Bet


---

### 1448. msg_9178

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:24:56

Would regret it later


---

### 1449. msg_9179

**You** - 2025-05-06T20:25:02

I would


---

### 1450. msg_9180

**You** - 2025-05-06T20:25:05

Or you would


---

### 1451. msg_9181

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:25:11

You


---

### 1452. msg_9182

**You** - 2025-05-06T20:25:16

Why


---

### 1453. msg_9183

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:25:25

I dunno you’re a Manager


---

### 1454. msg_9184

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:25:34

Jim and I are lowly


---

### 1455. msg_9185

**You** - 2025-05-06T20:25:35

Ok how about this


---

### 1456. msg_9186

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:25:37

lol


---

### 1457. msg_9187

**You** - 2025-05-06T20:25:42

How about this


---

### 1458. msg_9188

**You** - 2025-05-06T20:25:59

Yku take him to that small
Corner meeting room


---

### 1459. msg_9189

**You** - 2025-05-06T20:26:05

Or Bette go to a different floor


---

### 1460. msg_9190

**You** - 2025-05-06T20:26:15

Then broach the topic sooooooo


---

### 1461. msg_9191

**You** - 2025-05-06T20:26:23

Here is something interesting


---

### 1462. msg_9192

**You** - 2025-05-06T20:26:30

Test the waters


---

### 1463. msg_9193

**You** - 2025-05-06T20:26:37

See how he reacts but do t say it is me


---

### 1464. msg_9194

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:26:41

Do you even understand how hard it was for me to tell him about separating?


---

### 1465. msg_9195

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:26:52

Oh just tell him I’m seeing someone


---

### 1466. msg_9196

**You** - 2025-05-06T20:26:55

Yeah you are right yku couldn’t pull that off


---

### 1467. msg_9197

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:27:07

I could NOT


---

### 1468. msg_9198

**You** - 2025-05-06T20:27:11

Maybe I will do it


---

### 1469. msg_9199

**You** - 2025-05-06T20:27:25

Thursday


---

### 1470. msg_9200

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:27:34

He’s like my big brother\. I had a hard time telling him also for some reason


---

### 1471. msg_9201

**You** - 2025-05-06T20:27:55

I will start with the separation


---

### 1472. msg_9202

**You** - 2025-05-06T20:28:03

It will lead into discussing you


---

### 1473. msg_9203

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:28:15

I trust that Jim would not say anything to anyone but it is a slippery slope\.


---

### 1474. msg_9204

**You** - 2025-05-06T20:28:26

Yeah I know just a happy idea


---

### 1475. msg_9205

**You** - 2025-05-06T20:28:31

You are right of
Course


---

### 1476. msg_9206

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:28:46

He’s probably the only person I would actually trust fully


---

### 1477. msg_9207

**You** - 2025-05-06T20:28:51

Same


---

### 1478. msg_9208

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:28:53

At work


---

### 1479. msg_9209

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:29:36

I’ve known him since 2008 … he wouldn’t do anything


---

### 1480. msg_9210

**You** - 2025-05-06T20:30:05

Well like I said I can always start with my situation


---

### 1481. msg_9211

**You** - 2025-05-06T20:30:16

Least u could talk to someone else
About that


---

### 1482. msg_9212

**You** - 2025-05-06T20:30:22

O one to talk to about us


---

### 1483. msg_9213

**You** - 2025-05-06T20:30:25

Therapist


---

### 1484. msg_9214

**You** - 2025-05-06T20:30:29

Need one


---

### 1485. msg_9215

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:31:03

Yeah I do have other ppl who check in too…


---

### 1486. msg_9216

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:31:20

But men don’t do that


---

### 1487. msg_9217

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:31:24

Do they?


---

### 1488. msg_9218

**You** - 2025-05-06T20:31:25

See I do t have that that is what I kinda meant about friends


---

### 1489. msg_9219

**You** - 2025-05-06T20:31:35

Reaction: 😂 from Meredith Lamb
Man you have a very specific view about men


---

### 1490. msg_9220

**You** - 2025-05-06T20:31:45

Reaction: 😂 from Meredith Lamb
You like big men who are emotionally stunted


---

### 1491. msg_9221

**You** - 2025-05-06T20:31:46

lol


---

### 1492. msg_9222

**You** - 2025-05-06T20:31:50

And use big words


---

### 1493. msg_9223

**You** - 2025-05-06T20:31:56

And wear
Glasss


---

### 1494. msg_9224

**You** - 2025-05-06T20:32:00

You have a type


---

### 1495. msg_9225

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:32:16

Whatever


---

### 1496. msg_9226

**You** - 2025-05-06T20:32:22

Reaction: ❤️ from Meredith Lamb
Hair optional apparently


---

### 1497. msg_9227

**You** - 2025-05-06T20:32:36

Yeah but you didn’t dispute it


---

### 1498. msg_9228

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:32:54

Whatever = dispute


---

### 1499. msg_9229

**You** - 2025-05-06T20:33:02

O


---

### 1500. msg_9230

**You** - 2025-05-06T20:33:10

No it means you don’t have an answer


---

### 1501. msg_9231

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:33:35

I don’t prefer big men who are emotionally stunted\.


---

### 1502. msg_9232

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:33:39

Can you stop


---

### 1503. msg_9233

**You** - 2025-05-06T20:34:10

Interesting… mmmmm hmmm


---

### 1504. msg_9234

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:34:17

Is that what you think of yourself?


---

### 1505. msg_9235

**You** - 2025-05-06T20:34:40

No but I am not perfect…\.\.
Yet


---

### 1506. msg_9236

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:35:01

Sure you are


---

### 1507. msg_9237

**You** - 2025-05-06T20:35:42

You know what whatever… I feel the same about you so meh\.\.


---

### 1508. msg_9238

**You** - 2025-05-06T20:36:03

I don’t have a leg to
Stand on


---

### 1509. msg_9239

**You** - 2025-05-06T20:36:38

You are perfect for me if you cannot read between the lines\.


---

### 1510. msg_9240

**You** - 2025-05-06T20:36:50

There isn’t a point analyzing it


---

### 1511. msg_9241

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:37:09

I think you need to accept it goes both ways


---

### 1512. msg_9242

**You** - 2025-05-06T20:37:30

Yeah well i am not
Sure I will ever fully


---

### 1513. msg_9243

**You** - 2025-05-06T20:37:32

Being honest


---

### 1514. msg_9244

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:39:43

Ever fully accept that I think you are perfect for me?


---

### 1515. msg_9245

**You** - 2025-05-06T20:40:25

Certain aspects of me maybe \.\. I dunno we’ll see


---

### 1516. msg_9246

**You** - 2025-05-06T20:40:39

Not a huge deal


---

### 1517. msg_9247

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:40:51

Or a massive deal like


---

### 1518. msg_9248

**You** - 2025-05-06T20:40:56

No


---

### 1519. msg_9249

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:41:30

We are both in stressful situations so this isn’t “normal” life currently


---

### 1520. msg_9250

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:41:38

Both acting a little odd


---

### 1521. msg_9251

**You** - 2025-05-06T20:41:58

Hmm


---

### 1522. msg_9252

**You** - 2025-05-06T20:42:19

I am afraid I am not
Much different than this with the exception of emotional control


---

### 1523. msg_9253

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:43:27

That is kind of a big factor


---

### 1524. msg_9254

**You** - 2025-05-06T20:44:49

Trying to figure out how I drug us
Here\.\. we can call it I love you and always will and think you are perfect for me in every way and you can feel likewise\.\.


---

### 1525. msg_9255

**You** - 2025-05-06T20:45:07

And I will use absolutes whenever
I mean them


---

### 1526. msg_9256

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:45:55

Okay 🙂


---

### 1527. msg_9257

**You** - 2025-05-06T20:45:58

All that said I will need to find\. Way tk
Get from here to there
So
I will think on it


---

### 1528. msg_9258

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:46:34

You could work in new sector plans?


---

### 1529. msg_9259

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:46:39

\*on


---

### 1530. msg_9260

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:46:48

lol


---

### 1531. msg_9261

**You** - 2025-05-06T20:46:49

May I ask
You a question


---

### 1532. msg_9262

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:46:53

Sure


---

### 1533. msg_9263

**You** - 2025-05-06T20:47:19

Why does it seem to bother
You, I am kind of
Surprised I thought you would be all
For me
Branching out to make friends


---

### 1534. msg_9264

**You** - 2025-05-06T20:47:35

Like I will do whatever you want


---

### 1535. msg_9265

**You** - 2025-05-06T20:47:37

Tbh


---

### 1536. msg_9266

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:47:42

I mean it doesn’t bother me at all


---

### 1537. msg_9267

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:47:50

Only if I don’t like them


---

### 1538. msg_9268

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:47:58

I don’t like Andrew’s friends


---

### 1539. msg_9269

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:48:01

lol


---

### 1540. msg_9270

**You** - 2025-05-06T20:48:11

I usually try to find people like me


---

### 1541. msg_9271

**You** - 2025-05-06T20:48:32

But I don’t have to\.\. I will just go back to ai\.


---

### 1542. msg_9272

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:48:43

I have no issue with friends as long as they are assholes that I have too many hang around with


---

### 1543. msg_9273

**You** - 2025-05-06T20:48:44

That will fill time at least


---

### 1544. msg_9274

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:48:52

\*arent


---

### 1545. msg_9275

**You** - 2025-05-06T20:49:14

I will find something else


---

### 1546. msg_9276

**You** - 2025-05-06T20:49:34

All good\.\. maybe if j leaves it will be better
But that is like 2 months ffs


---

### 1547. msg_9277

**You** - 2025-05-06T20:49:44

Earliest


---

### 1548. msg_9278

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:49:44

Like if your friend is like Jim, we are fine


---

### 1549. msg_9279

**You** - 2025-05-06T20:49:56

I should have moved
Our first


---

### 1550. msg_9280

**You** - 2025-05-06T20:50:11

It would have been worse
Overall but I would be happier


---

### 1551. msg_9281

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:50:17

I’m going to try for July 1 maybe


---

### 1552. msg_9282

**You** - 2025-05-06T20:50:41

Yeah you are a ways off too\.\. being k\. The abstinence\!\!\!\!


---

### 1553. msg_9283

**You** - 2025-05-06T20:50:44

Whoooi


---

### 1554. msg_9284

**You** - 2025-05-06T20:50:48

lol


---

### 1555. msg_9285

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:51:02

Reaction: 👍 from Scott Hicks
I’m not sure i could do before\. Mac’s 16th plus 2 graduations in June


---

### 1556. msg_9286

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:51:35

Mediator said 3 wks also


---

### 1557. msg_9287

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:51:42

So we will see


---

### 1558. msg_9288

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:52:02

At least now I can send the girls rentals to look at


---

### 1559. msg_9289

**You** - 2025-05-06T20:52:03

Still my point remains valid lol… mentally tough time


---

### 1560. msg_9290

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:52:06

Couldn’t before


---

### 1561. msg_9291

**You** - 2025-05-06T20:52:13

Silver lining


---

### 1562. msg_9292

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:52:27

>
Then we plan a work trip


---

### 1563. msg_9293

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:52:32

🤔


---

### 1564. msg_9294

**You** - 2025-05-06T20:52:39

For august


---

### 1565. msg_9295

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:52:46

For June


---

### 1566. msg_9296

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:52:57

August?


---

### 1567. msg_9297

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:53:02

Wha


---

### 1568. msg_9298

**You** - 2025-05-06T20:53:05

I have to go to Chatham k\. 17


---

### 1569. msg_9299

**You** - 2025-05-06T20:53:11

Of may


---

### 1570. msg_9300

**You** - 2025-05-06T20:53:30

August was an exaggeration\. I am not optimistic


---

### 1571. msg_9301

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:53:35

I have zero reason to be in Chatham


---

### 1572. msg_9302

**You** - 2025-05-06T20:53:40

I low


---

### 1573. msg_9303

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:53:42

I also meant a fake work trip


---

### 1574. msg_9304

**You** - 2025-05-06T20:53:44

I wasn’t suggesting


---

### 1575. msg_9305

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:54:08

But your team will catch on


---

### 1576. msg_9306

**You** - 2025-05-06T20:54:20

It’s fine\.\.


---

### 1577. msg_9307

**You** - 2025-05-06T20:54:26

Will be fine


---

### 1578. msg_9308

**You** - 2025-05-06T20:54:34

I will just keep
Telling myself that


---

### 1579. msg_9309

**You** - 2025-05-06T20:54:39

My be mantra


---

### 1580. msg_9310

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:55:10

Sigh


---

### 1581. msg_9311

**You** - 2025-05-06T20:56:27

Mer I am a realist\.\. through and through… and I believe in us that way which is how I can reconcile it\.\. it isn’t an optimistic fantasy I believe it is real and eventually will happen\.  But all the rest…
Realist\.\. low
Expectations easier to survive


---

### 1582. msg_9312

**You** - 2025-05-06T20:57:06

I learened from
The weekend


---

### 1583. msg_9313

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:57:22

Which weekend? Last?


---

### 1584. msg_9314

**You** - 2025-05-06T20:57:28

Yeah


---

### 1585. msg_9315

**You** - 2025-05-06T20:58:16

Flew a bit to close
To the sun and all
Got super excited and a bit optimistic\.\. but problem
Was I
Literally forgot about everything else
There was just you\.\.


---

### 1586. msg_9316

**You** - 2025-05-06T20:58:27

Then it was time for a polar dip into realitt


---

### 1587. msg_9317

**You** - 2025-05-06T20:59:07

\.\. not sure how
Else
To explain


---

### 1588. msg_9318

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T20:59:34

Quite an explanation… how do you come up with this stuff lol


---

### 1589. msg_9319

**You** - 2025-05-06T20:59:54

I am smart and I read
Greek mythology


---

### 1590. msg_9320

**You** - 2025-05-06T21:00:06

And I know how to use analogies


---

### 1591. msg_9321

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:00:06

Thank goodness


---

### 1592. msg_9322

**You** - 2025-05-06T21:00:12

lol


---

### 1593. msg_9323

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:00:16

Apparently


---

### 1594. msg_9324

**You** - 2025-05-06T21:00:28

But it is true


---

### 1595. msg_9325

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:00:56

I know\. I feel like I let you down this weekend and then this week


---

### 1596. msg_9326

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:01:06

Told my therapist


---

### 1597. msg_9327

**You** - 2025-05-06T21:01:13

What are you talking about


---

### 1598. msg_9328

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:01:17

So you just need to be patient with me


---

### 1599. msg_9329

**You** - 2025-05-06T21:01:20

My problems are my own


---

### 1600. msg_9330

**You** - 2025-05-06T21:01:27

You can’t carry them I won’t let you


---

### 1601. msg_9331

**You** - 2025-05-06T21:01:33

I told you lot bugging
You anymore


---

### 1602. msg_9332

**You** - 2025-05-06T21:01:39

Too much pressure


---

### 1603. msg_9333

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:01:53

Well you wanted to get together for just like a quick whatever on weekend but I didn’t


---

### 1604. msg_9334

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:01:59

Then this week


---

### 1605. msg_9335

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:02:06

Gahhh


---

### 1606. msg_9336

**You** - 2025-05-06T21:02:06

It’s fine like I said reality


---

### 1607. msg_9337

**You** - 2025-05-06T21:02:22

Not pushing anymore wil deal yku are right too much weight


---

### 1608. msg_9338

**You** - 2025-05-06T21:02:51

Like you were begging for space
Mer… I have to give it to you and you cannot
Feel
Guilty


---

### 1609. msg_9339

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:03:15

What? I was not begging for space


---

### 1610. msg_9340

**You** - 2025-05-06T21:03:23

Last\. Ight


---

### 1611. msg_9341

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:03:24

I just have a lot going on atm


---

### 1612. msg_9342

**You** - 2025-05-06T21:03:34

I know you do


---

### 1613. msg_9343

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:03:47

Last night I was begging for space?


---

### 1614. msg_9344

**You** - 2025-05-06T21:04:05

Before you fell asleep yeah


---

### 1615. msg_9345

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:05:35

So took me forever to scroll up


---

### 1616. msg_9346

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:05:36

lol


---

### 1617. msg_9347

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:05:44

I was just tired


---

### 1618. msg_9348

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:05:49

Edited: 2 versions
| Version: 2
| Sent: Tue, 6 May 2025 21:06:57 \-0400
|
| I’m also GENERALLY not as wordy/chatty as you in ever single msg so…\.\. I think I would have arthritic thumbs if I was
|
| Version: 1
| Sent: Tue, 6 May 2025 21:05:49 \-0400
|
| Not begging for space


---

### 1619. msg_9349

**You** - 2025-05-06T21:07:31

Right so when you are wordy and articulate I pay attention\.\.


---

### 1620. msg_9350

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:08:02

But I wasn’t begging for space


---

### 1621. msg_9351

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:08:05

Just tired


---

### 1622. msg_9352

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:08:07

Drained


---

### 1623. msg_9353

**You** - 2025-05-06T21:08:08

It’s fine I told you I am going to chill that was my idea
With
Friends so I would bug you as
Much


---

### 1624. msg_9354

**You** - 2025-05-06T21:08:20

Only reason


---

### 1625. msg_9355

**You** - 2025-05-06T21:08:39

Wouldnt


---

### 1626. msg_9356

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:08:51

Why did you not have this friend thing before me?


---

### 1627. msg_9357

**You** - 2025-05-06T21:09:24

The only reason I pushed for after
Work today was that I was
Worried you were
Going into a shitstorm and wanted to hug you and tell you how much I love you in person it wasn’t even really for
Me\.\.


---

### 1628. msg_9358

**You** - 2025-05-06T21:09:34

I am a loner
And I didn’t need them


---

### 1629. msg_9359

**You** - 2025-05-06T21:09:41

I also didn’t feel lonely


---

### 1630. msg_9360

**You** - 2025-05-06T21:09:44

Ever


---

### 1631. msg_9361

**You** - 2025-05-06T21:09:50

Or really have needy deelings


---

### 1632. msg_9362

**You** - 2025-05-06T21:09:53

Feeinga


---

### 1633. msg_9363

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:09:57

>
It was very sweet


---

### 1634. msg_9364

**You** - 2025-05-06T21:10:20

Anyhow I just wanted to explain I want going back
I\. What I said


---

### 1635. msg_9365

**You** - 2025-05-06T21:11:36

Well that was an hour of walking and 522 calories\.\. noice


---

### 1636. msg_9366

**You** - 2025-05-06T21:11:49

Anyways stop worrying about this mer


---

### 1637. msg_9367

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:11:55

>
Reptype this


---

### 1638. msg_9368

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:12:02

Retype


---

### 1639. msg_9369

**You** - 2025-05-06T21:12:09

Nothing you can do now anyways


---

### 1640. msg_9370

**You** - 2025-05-06T21:12:11

What?


---

### 1641. msg_9371

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:12:21

That doesn’t make sense


---

### 1642. msg_9372

**You** - 2025-05-06T21:12:51

I wanted to explain that my asking you to rendezvous boys tonight was not meant to be me going back on my promise not to chill and stop bugging you to see me\.


---

### 1643. msg_9373

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:13:13

Ohhhhh got it


---

### 1644. msg_9374

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:13:23

Yeah I got that it and felt it


---

### 1645. msg_9375

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:13:54

And I’m not “worrying” per se\.


---

### 1646. msg_9376

**You** - 2025-05-06T21:14:41

It the point \- I just wanted to make sure you understood


---

### 1647. msg_9377

**You** - 2025-05-06T21:14:46

I am sticking bu what I said


---

### 1648. msg_9378

**You** - 2025-05-06T21:14:53

Not the point


---

### 1649. msg_9379

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:16:29

But… this is heavy and sometimes we have to make it lighter


---

### 1650. msg_9380

**You** - 2025-05-06T21:16:43

wtf


---

### 1651. msg_9381

**You** - 2025-05-06T21:16:53

Pocket dial
Apologies


---

### 1652. msg_9382

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:17:13

I wasn’t going to answer\. Marlowe in next room lol


---

### 1653. msg_9383

**You** - 2025-05-06T21:17:35

Yeah sorry didnt mean to\.


---

### 1654. msg_9384

**You** - 2025-05-06T21:18:49

Ok go watch your shows I am going into sauna then shower then home\.


---

### 1655. msg_9385

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T21:20:41

k i love you and glad we talked tonight xoxo


---

### 1656. msg_9386

**You** - 2025-05-06T21:21:04

Love you too night\.


---

### 1657. msg_9387

**You** - 2025-05-06T22:19:07

Just getting ready to settle in,
I mentioned it earlier but I will
E thinking about your mum tomorrow I hope all goes well\.


---

### 1658. msg_9388

**You** - 2025-05-06T23:04:45

I also had an idea for that work trip yku mentioned I mean lots kf people end up taking fridays off\.\. maybe ona\. Long weekend maybe something else\.\. I can make up a story to get up to Chatham for a day for my family and stay for the weekend as part of my getaway hang out with Tom and haris and have dinner with Sarah etc\.\. but really I would like to spend it with you just having yku tour me around and show me stuff\.  Anyhow unsure if it works but it is something I have wanted to do with you\.  At some point in time\.\. just an idea to think about for somewhere down the road if it fits\.  Can’t help having ideas always thinking\.


---

### 1659. msg_9389

**Meredith Lamb \(\+14169386001\)** - 2025-05-06T23:33:41

You need a spreadsheet to track all of these ideas\. ❤️ We’ll see if we could make something like that work\. Nite\. Xox


---

### 1660. msg_9390

**You** - 2025-05-07T04:16:26

I keep track of everything\.\. don’t you worry


---

### 1661. msg_9391

**You** - 2025-05-07T04:35:24

Btw Sharon is back\!\!\!\! In J’s mind\.


---

### 1662. msg_9392

**You** - 2025-05-07T04:35:43

She thinks my 5 hours a day at gym is because I am dating Sharon\.


---

### 1663. msg_9393

**You** - 2025-05-07T04:35:59

Maybe a little something for you to consider huh…\.


---

### 1664. msg_9394

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T05:51:22

I mean she isn’t wrong\. Lol knows you well obviously


---

### 1665. msg_9395

**You** - 2025-05-07T05:57:03

And Sharon I mean she knows Sharon too\.


---

### 1666. msg_9396

**You** - 2025-05-07T05:57:21

You know Sharon… she’s crazy\!\!\!


---

### 1667. msg_9397

**You** - 2025-05-07T05:58:13

🥰


---

### 1668. msg_9398

**You** - 2025-05-07T06:00:57

Crazy hot and amazing


---

### 1669. msg_9399

**You** - 2025-05-07T06:01:11

And and and


---

### 1670. msg_9400

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:01:28

Definitely crazy right now\. Lol


---

### 1671. msg_9401

**You** - 2025-05-07T06:01:38

Nice way to wake up\.\.


---

### 1672. msg_9402

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:01:46

How did that conversation go?


---

### 1673. msg_9403

**You** - 2025-05-07T06:01:54

Which one


---

### 1674. msg_9404

**You** - 2025-05-07T06:01:59

Oh


---

### 1675. msg_9405

**You** - 2025-05-07T06:02:00

Short


---

### 1676. msg_9406

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:02:00

I wonder if you are a good liar re Sharon


---

### 1677. msg_9407

**You** - 2025-05-07T06:02:02

And over


---

### 1678. msg_9408

**You** - 2025-05-07T06:02:16

I told I will video call her every workout


---

### 1679. msg_9409

**You** - 2025-05-07T06:02:19

For the whole time


---

### 1680. msg_9410

**You** - 2025-05-07T06:02:26

She backed off


---

### 1681. msg_9411

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:02:30

Haha


---

### 1682. msg_9412

**You** - 2025-05-07T06:02:44

Speaking of video calls\.\. squats
Today lol\.\.😂


---

### 1683. msg_9413

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:02:59

Are you at gym now


---

### 1684. msg_9414

**You** - 2025-05-07T06:03:03

Yep


---

### 1685. msg_9415

**You** - 2025-05-07T06:03:07

Been here for a it


---

### 1686. msg_9416

**You** - 2025-05-07T06:03:08

But


---

### 1687. msg_9417

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:03:09

Omg


---

### 1688. msg_9418

**You** - 2025-05-07T06:03:11

Bit


---

### 1689. msg_9419

**You** - 2025-05-07T06:03:17

5:30


---

### 1690. msg_9420

**You** - 2025-05-07T06:03:21

Up at 4:45


---

### 1691. msg_9421

**You** - 2025-05-07T06:03:25

Feels good


---

### 1692. msg_9422

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:03:35

Until you crash later


---

### 1693. msg_9423

**You** - 2025-05-07T06:03:38

Nope


---

### 1694. msg_9424

**You** - 2025-05-07T06:03:42

I didn’t last night


---

### 1695. msg_9425

**You** - 2025-05-07T06:04:00

Went to sleep right before t you responded


---

### 1696. msg_9426

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:04:42

That’s good but you should get more sleep at least one day a week or something


---

### 1697. msg_9427

**You** - 2025-05-07T06:04:46

So I am going to ask Jim to come for a drink and/or a dinner tonight\. Fyi\.


---

### 1698. msg_9428

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:05:08

For real?


---

### 1699. msg_9429

**You** - 2025-05-07T06:05:22

Yah


---

### 1700. msg_9430

**You** - 2025-05-07T06:05:30

He likes to be wined and dined


---

### 1701. msg_9431

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:05:39

lol indeed


---

### 1702. msg_9432

**You** - 2025-05-07T06:06:00

Put the moves on him\.\.


---

### 1703. msg_9433

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:06:02

He will be surprised


---

### 1704. msg_9434

**You** - 2025-05-07T06:06:07

He will


---

### 1705. msg_9435

**You** - 2025-05-07T06:06:15

I will let
You know if goes
Off
On a tangent


---

### 1706. msg_9436

**You** - 2025-05-07T06:06:23

You focus on your stuff today more important


---

### 1707. msg_9437

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:06:36

He will be calling today to find out about girls for sure


---

### 1708. msg_9438

**You** - 2025-05-07T06:06:47

No doubt\.\. I will try to get him early


---

### 1709. msg_9439

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:06:48

I have some major work stuff to do today


---

### 1710. msg_9440

**You** - 2025-05-07T06:06:53

So he can ask you about the call


---

### 1711. msg_9441

**You** - 2025-05-07T06:06:58

Yeah you do you\.


---

### 1712. msg_9442

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:07:46

K but I don’t have calls all day so we can chat at some point


---

### 1713. msg_9443

**You** - 2025-05-07T06:08:06

Kk I would
Like that of course\.\. always like that ☺️


---

### 1714. msg_9444

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:09:02

k, I’m going to lie with griffin until 7\. He likes attention in the morning lol


---

### 1715. msg_9445

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:09:07

He’s a baby


---

### 1716. msg_9446

**You** - 2025-05-07T06:09:17

Lucky him


---

### 1717. msg_9447

**You** - 2025-05-07T06:09:22

Jealous


---

### 1718. msg_9448

**You** - 2025-05-07T06:09:27

Griffin……


---

### 1719. msg_9449

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T06:09:44

Yep you should be\. He gets spoiled


---

### 1720. msg_9450

**You** - 2025-05-07T06:10:07

Well he will
Only get
More
When I am around… so love dogs


---

### 1721. msg_9451

**You** - 2025-05-07T06:10:19

You have a partner there
For sure


---

### 1722. msg_9452

**You** - 2025-05-07T06:10:27

Reaction: ❤️ from Meredith Lamb
Kk go cuddle chat later


---

### 1723. msg_9453

**You** - 2025-05-07T06:12:22

Love you\.


---

### 1724. msg_9454

**You** - 2025-05-07T09:50:50

Check out this listing
https://realtor\.ca/real\-estate/27978860/35\-venetian\-drive\-riverview?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 1725. msg_9455

**You** - 2025-05-07T09:51:32

Check out this listing
https://realtor\.ca/real\-estate/28260903/721\-pinewood\-road\-riverview?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 1726. msg_9456

**You** - 2025-05-07T11:17:00

While I believe you and I were meant to be can you see me fitting into your life\.\. like I am just worried I won’t\.


---

### 1727. msg_9457

**You** - 2025-05-07T11:17:16

Just\. A thought out of our earlier convo


---

### 1728. msg_9458

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T11:17:46

🙄


---

### 1729. msg_9459

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T11:17:54

Good response?


---

### 1730. msg_9460

**You** - 2025-05-07T11:18:23

Ummmmmmm mmmmm hmmmmm yes yes… very interesting\.


---

### 1731. msg_9461

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T11:20:08

When I said that I feel like you are home to me, I wasn’t lying\. Just because I had this particular life for the last few years doesn’t mean it felt right\. You feel right so I don’t understand how you couldn’t fit in to my life honestly\.


---

### 1732. msg_9462

**You** - 2025-05-07T12:05:57

I feel the same
Way but there is you and then there is this massive thing that is your life… and i guess I just don’t see where I fit except as the boy you keep off to the side jk… this is a ways out miles and miles and soooo many miles to go before that is a problem to worry about\.


---

### 1733. msg_9463

**You** - 2025-05-07T12:06:22

My life is small and simple compared\.\. so it is just timing\.\. everything else is easy\.


---

### 1734. msg_9464

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T12:06:28

My life is not massive\.


---

### 1735. msg_9465

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T12:06:34

Omg


---

### 1736. msg_9466

**You** - 2025-05-07T12:06:37

Relatively speaking


---

### 1737. msg_9467

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T12:07:04

I mean it is a bit more chaotic bc big family, younger kids, and 1 extra kid\.


---

### 1738. msg_9468

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T12:07:08

Otherwise same


---

### 1739. msg_9469

**You** - 2025-05-07T12:10:06

I mean yeah it soo sounds the same\.\.


---

### 1740. msg_9470

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T12:10:39

I’m not sure why it matters


---

### 1741. msg_9471

**You** - 2025-05-07T12:25:10

It probably doesn’t, miles away, just a thought that popped
Into my brain\.


---

### 1742. msg_9472

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T12:42:38

You would integrate into my life easily and could probably pull it off better than I can\. You have more energy than I do\.


---

### 1743. msg_9473

**You** - 2025-05-07T12:43:35

As you said I will focus on just integrating with you first that is what I want more than anything else regardless


---

### 1744. msg_9474

**You** - 2025-05-07T13:02:48

Hey I am going to need some me time to process some stuff today so I am not going to attend the team meeting\.


---

### 1745. msg_9475

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:07:02

Totally cool\. We are going to go over your list and status so I will update you at our one on one … we can actually talk about work maybe


---

### 1746. msg_9476

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:08:44

>
My family will like you and there isn’t any crazy upset people in my family by my whole situation so you will be entering a pretty drama free environment\. Andrew will be the only wild card\.


---

### 1747. msg_9477

**You** - 2025-05-07T13:09:41

Sry yeah I moved past that but appreciate it I do want everyone to like me so I can fully be with you\.\. b


---

### 1748. msg_9478

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:17:26

Do you really believe I would treat you as “this boy i keep off to the side”??? Lol


---

### 1749. msg_9479

**You** - 2025-05-07T13:18:01

My issue is I feel trapped right now and I need to breathe… so j says just take more trips to Chatham T least the company pays\.\.


---

### 1750. msg_9480

**You** - 2025-05-07T13:18:14

I mean my idea\!\!\! lol


---

### 1751. msg_9481

**You** - 2025-05-07T13:18:23

But I am thinking of finding\. Studio or something


---

### 1752. msg_9482

**You** - 2025-05-07T13:18:35

Just to get the fuck out of the basement for a few months not sure


---

### 1753. msg_9483

**You** - 2025-05-07T13:19:00

Doing the hotel thing
For work isn’t bad either but it needs to make sense


---

### 1754. msg_9484

**You** - 2025-05-07T13:19:39

But I have to breathe to do something I know I cannot stay there until July\.


---

### 1755. msg_9485

**You** - 2025-05-07T13:19:52

At least not with both her and d grace there


---

### 1756. msg_9486

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:19:56

You need a mind map


---

### 1757. msg_9487

**You** - 2025-05-07T13:20:07

You need a mind map…


---

### 1758. msg_9488

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:20:18

🙄


---

### 1759. msg_9489

**You** - 2025-05-07T13:22:00

I need a lot of things… mind maps aren’t going to cut it\.\. not in this mind\.


---

### 1760. msg_9490

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:22:25

Can you afford a studio


---

### 1761. msg_9491

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:22:52

You could always just do some short term air bnbs here and there


---

### 1762. msg_9492

**You** - 2025-05-07T13:23:41

I don’t know maybe I am going to look part of the reason I live at the gym or need to make friends or just something


---

### 1763. msg_9493

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:25:18

You just want a single Sharon in Whitby who has tons of time on her hands\. 😜


---

### 1764. msg_9494

**You** - 2025-05-07T13:25:44

Sounds about right\.


---

### 1765. msg_9495

**You** - 2025-05-07T13:25:53

As long as we agree Sharon is you\.\.


---

### 1766. msg_9496

**You** - 2025-05-07T13:26:12

Other than that refer to previous statement because that doesn’t exist\.


---

### 1767. msg_9497

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:26:59

You never know\. Once you go looking…


---

### 1768. msg_9498

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:27:05

Sowing your oats…


---

### 1769. msg_9499

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:27:10

:p


---

### 1770. msg_9500

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:27:21

See where your messages take my head


---

### 1771. msg_9501

**You** - 2025-05-07T13:27:30

It’s very unfair\.


---

### 1772. msg_9502

**You** - 2025-05-07T13:27:39

I would never do that


---

### 1773. msg_9503

**You** - 2025-05-07T13:27:49

I just need something g to keep me from going insane


---

### 1774. msg_9504

**You** - 2025-05-07T13:27:56

You know what I had to stop doing


---

### 1775. msg_9505

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:28:07

k\.\.


---

### 1776. msg_9506

**You** - 2025-05-07T13:28:12

I had to stop listening to the mix tape and Morgan wallen\.


---

### 1777. msg_9507

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:28:14

Fair enough


---

### 1778. msg_9508

**You** - 2025-05-07T13:28:35

Because I do that and I cannot stop thinking of you or the dance or any of it\.\. lol


---

### 1779. msg_9509

**You** - 2025-05-07T13:29:09

Which sure if I am you I am maybe super supe reassured that this guy is absolutely in love with me\.


---

### 1780. msg_9510

**You** - 2025-05-07T13:29:14

But S me


---

### 1781. msg_9511

**You** - 2025-05-07T13:29:17

As me


---

### 1782. msg_9512

**You** - 2025-05-07T13:30:04

Like I am just trying to run around trying to find a way to distract myself, to kill time to get me to the next day and the next
Etc


---

### 1783. msg_9513

**You** - 2025-05-07T13:31:06

I know please you wanted me to be honest I didn’t want to talk about it anymore\.\. lol I am stuck


---

### 1784. msg_9514

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T13:31:19

I think once my separation agreement is done in a few weeks and then I’m in a new place you will feel differently


---

### 1785. msg_9515

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:08:52

Am I going to be getting shocked texts from Jim?


---

### 1786. msg_9516

**You** - 2025-05-07T17:09:58

Nope


---

### 1787. msg_9517

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:10:26

k… glad you aren’t a loose cannon today lol


---

### 1788. msg_9518

**You** - 2025-05-07T17:12:12

Nope I am just leaving to go home\.  Nothing to report\.


---

### 1789. msg_9519

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:13:22

How’d it go?


---

### 1790. msg_9520

**You** - 2025-05-07T17:27:32

Pretty easy straightforward


---

### 1791. msg_9521

**You** - 2025-05-07T17:27:41

Very supportive as Jim is


---

### 1792. msg_9522

**You** - 2025-05-07T17:27:49

No clue about is that he let I\. To


---

### 1793. msg_9523

**You** - 2025-05-07T17:28:00

You were only mentioned peripherally


---

### 1794. msg_9524

**You** - 2025-05-07T17:28:12

Although he has an interesting observation


---

### 1795. msg_9525

**You** - 2025-05-07T17:28:35

Very astute


---

### 1796. msg_9526

**You** - 2025-05-07T17:28:46

But it is a
Conversation not a text


---

### 1797. msg_9527

**You** - 2025-05-07T17:29:02

Especially when I am driving


---

### 1798. msg_9528

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:30:13

kk


---

### 1799. msg_9529

**You** - 2025-05-07T17:32:17

Point is nothing for you to worry about


---

### 1800. msg_9530

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:32:46

k I wasn’t worried per se


---

### 1801. msg_9531

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:32:48

lol


---

### 1802. msg_9532

**You** - 2025-05-07T17:32:52

Sure


---

### 1803. msg_9533

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:32:57

Well


---

### 1804. msg_9534

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T17:33:08

Not sure if I’m ready for Jim’s reaction to the whole thing


---

### 1805. msg_9535

**You** - 2025-05-07T17:33:43

Yep\. Awkward situational


---

### 1806. msg_9536

**You** - 2025-05-07T19:43:47

Been quiet a while hope everything is ok\.


---

### 1807. msg_9537

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T19:51:17

Just pulled in driveway and volleyball duties done for tonight :p


---

### 1808. msg_9538

**You** - 2025-05-07T20:01:06

Ah ok didnt know\.\.


---

### 1809. msg_9539

**You** - 2025-05-07T20:01:19

Thought bad news or Andrew or other stuff


---

### 1810. msg_9540

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:02:58

No but he did super bug me so I fought with him after work\. He called me self centred AGAIN


---

### 1811. msg_9541

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:03:09

I can’t…\.


---

### 1812. msg_9542

**You** - 2025-05-07T20:03:16

Ok don’t need to discuss


---

### 1813. msg_9543

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:04:47

Just trying to forget about it\. Very disturbing to keep getting called that and told him it better not be the narrative of our separation\. I will be pissed


---

### 1814. msg_9544

**You** - 2025-05-07T20:05:34

Sorry mer it isn’t who you are it is how he needs to frame you so he can tolerate himself


---

### 1815. msg_9545

**You** - 2025-05-07T20:06:45

Look we do t have to chat tonight if you need a break\.\.


---

### 1816. msg_9546

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:07:32

Exhausting\. Just cleaning up work emails


---

### 1817. msg_9547

**You** - 2025-05-07T20:07:44

Kk


---

### 1818. msg_9548

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:09:08

I do want to hear about Jim’s “astute” observation tho


---

### 1819. msg_9549

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:09:10

lol


---

### 1820. msg_9550

**You** - 2025-05-07T20:09:51

Well it is better discussed but whatever I will try to put in words that make sense


---

### 1821. msg_9551

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T20:10:15

You can call me\. I’m alone in my office


---

### 1822. msg_9552

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:26:10

If I go to Oshawa Friday night, you want to get together?


---

### 1823. msg_9553

**You** - 2025-05-07T21:26:38

Do you really have to ask


---

### 1824. msg_9554

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:26:52

Well, yeah


---

### 1825. msg_9555

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:26:54

lol


---

### 1826. msg_9556

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:27:02

Because I wouldn’t go otherwise


---

### 1827. msg_9557

**You** - 2025-05-07T21:27:12

What do you want to do?


---

### 1828. msg_9558

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:27:32

Not sure yet


---

### 1829. msg_9559

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:27:38

But I will figure it out


---

### 1830. msg_9560

**You** - 2025-05-07T21:27:55

Kk let me know I could actually go away for that night


---

### 1831. msg_9561

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:28:06

Go away?


---

### 1832. msg_9562

**You** - 2025-05-07T21:28:07

At least I have the option


---

### 1833. msg_9563

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:28:13

Hrm?


---

### 1834. msg_9564

**You** - 2025-05-07T21:28:22

J has told me just take the fuck off air bib or whatever


---

### 1835. msg_9565

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:28:42

Hmm ok let me think about that


---

### 1836. msg_9566

**You** - 2025-05-07T21:28:49

Think away\.


---

### 1837. msg_9567

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:28:53

K


---

### 1838. msg_9568

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:28:55

lol


---

### 1839. msg_9569

**You** - 2025-05-07T21:29:40

I mean I could book a couple of days it wouldnt be as suspicious I think


---

### 1840. msg_9570

**You** - 2025-05-07T21:29:53

Rather than just one


---

### 1841. msg_9571

**You** - 2025-05-07T21:30:14

Or saying yku staying for that saying I am


---

### 1842. msg_9572

**You** - 2025-05-07T21:30:21

Not


---

### 1843. msg_9573

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:30:51

So the plan for my mom is the girls need to be ready at like 7 or 7\.30 sat night\. No earlier


---

### 1844. msg_9574

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:31:01

So I just need to have them to Oshawa for then


---

### 1845. msg_9575

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:31:22

But I can always say I’m going to spend time with my parents\. Not unusual\. I’m close with them


---

### 1846. msg_9576

**You** - 2025-05-07T21:31:40

I am good with whatever mer\.


---

### 1847. msg_9577

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:32:21

I’m a LITTLE reluctant to say just come to my parents but not fully \(lol spoiled\)


---

### 1848. msg_9578

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:32:35

It feels a little weird at 47


---

### 1849. msg_9579

**You** - 2025-05-07T21:32:47

I still want to meet your mum but only when you are comfortable


---

### 1850. msg_9580

**You** - 2025-05-07T21:32:54

But I like the idea of a non


---

### 1851. msg_9581

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:32:56

But it wouldn’t have been weird before 20 yrs ago


---

### 1852. msg_9582

**You** - 2025-05-07T21:32:56

Bnb


---

### 1853. msg_9583

**You** - 2025-05-07T21:33:50

Yeah I could do Friday and Saturday then I am sure hi have to do some northern day thing Sunday


---

### 1854. msg_9584

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:33:50

You like the idea of my parents basement better?


---

### 1855. msg_9585

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:34:08

You said “non air bnb”


---

### 1856. msg_9586

**You** - 2025-05-07T21:34:08

Staying the night with you in your parents basement


---

### 1857. msg_9587

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:34:21

>
This is better?


---

### 1858. msg_9588

**You** - 2025-05-07T21:34:22

No I like the idea of air bnb


---

### 1859. msg_9589

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:34:28

Oh ok


---

### 1860. msg_9590

**You** - 2025-05-07T21:34:42

Because I pay for it there is a record


---

### 1861. msg_9591

**You** - 2025-05-07T21:34:49

Cannot just say see ya


---

### 1862. msg_9592

**You** - 2025-05-07T21:34:50

lol


---

### 1863. msg_9593

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:34:53

Ahhh


---

### 1864. msg_9594

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:34:55

lol


---

### 1865. msg_9595

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:35:17

I would have to have my parents cover for me lol


---

### 1866. msg_9596

**You** - 2025-05-07T21:35:18

So whatever works for you\.\. I will find some place perhaps near
To your parents


---

### 1867. msg_9597

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:35:39

Maybe I could work from home tomorrow and discuss with my mom


---

### 1868. msg_9598

**You** - 2025-05-07T21:35:39

What are they north Oshawa


---

### 1869. msg_9599

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:35:45

I only texted with her today


---

### 1870. msg_9600

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:35:51

Yeah near airport


---

### 1871. msg_9601

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:35:58

827 law street


---

### 1872. msg_9602

**You** - 2025-05-07T21:36:13

Yeah whatever works yku will miss me tomorrow though


---

### 1873. msg_9603

**You** - 2025-05-07T21:36:16

Not gonna lie


---

### 1874. msg_9604

**You** - 2025-05-07T21:36:44

It’s a good workout tomorrow\.\. too bad


---

### 1875. msg_9605

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:37:24

It’s hard for me to talk to my mom from office


---

### 1876. msg_9606

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:37:42

I can get her on board but requires a conversation not texting


---

### 1877. msg_9607

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:37:45

:p


---

### 1878. msg_9608

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:37:53

And she talks on and on and on and on


---

### 1879. msg_9609

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:37:59

And on and on and on and on


---

### 1880. msg_9610

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:38:14

Kinda like someone else I know 😇


---

### 1881. msg_9611

**You** - 2025-05-07T21:41:16

Ok up to you\.\. like I said you miss\.\.


---

### 1882. msg_9612

**You** - 2025-05-07T21:41:51

Anyhow I am going into sauna now\.\. will chat later or if you are asleep say goodnight then\.


---

### 1883. msg_9613

**You** - 2025-05-07T21:42:04

Always those private booths\. Anyhow later


---

### 1884. msg_9614

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:56:26

Private booths?


---

### 1885. msg_9615

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:56:32

Not speaking my language


---

### 1886. msg_9616

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:56:42

Had to talk to Andrew and girls about weekend


---

### 1887. msg_9617

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:57:07

I can do Friday night but need to clear it with my mom tomorrow to cover for me


---

### 1888. msg_9618

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:57:13

I need her or it doesn’t work


---

### 1889. msg_9619

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:57:56

Andrew either stays home from cottage or gets his mom to come for Friday night


---

### 1890. msg_9620

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T21:57:59

We will see


---

### 1891. msg_9621

**You** - 2025-05-07T22:14:26

Kk I meant the sound proof booths


---

### 1892. msg_9622

**You** - 2025-05-07T22:14:38

So I won’t get my hopes up yet or tell Jaimie anything


---

### 1893. msg_9623

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:14:48

Hrm?


---

### 1894. msg_9624

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:15:04

You are confusing sometimes


---

### 1895. msg_9625

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:15:15

So let me talk to my mom tomorrow


---

### 1896. msg_9626

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:15:22

Then we should be good


---

### 1897. msg_9627

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:15:35

If she cooperates we are good lol


---

### 1898. msg_9628

**You** - 2025-05-07T22:15:35

The private booths to talk to your mum I referenced the sound proof booths then you said a bunch of stuff I didn’t understand


---

### 1899. msg_9629

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:15:48

Oh


---

### 1900. msg_9630

**You** - 2025-05-07T22:15:48

But it was like maybe maybe not so I just said I will wait and see


---

### 1901. msg_9631

**You** - 2025-05-07T22:16:04

Again not get hopes up or plan anything yet


---

### 1902. msg_9632

**You** - 2025-05-07T22:16:06

That’s all


---

### 1903. msg_9633

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:16:29

I’m just going to wfh and then I can reach her easier at some point


---

### 1904. msg_9634

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:16:35

Plus I’m fucking tired


---

### 1905. msg_9635

**You** - 2025-05-07T22:16:38

Kk


---

### 1906. msg_9636

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:17:05

I can’t even talk at me desk bc Carolyn is like eagle ears


---

### 1907. msg_9637

**You** - 2025-05-07T22:17:17

It’s all good
You do t need to explain


---

### 1908. msg_9638

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:17:22

And then she asks questions after my calls lol


---

### 1909. msg_9639

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:17:33

She doesn’t even apologize for eavesdropping


---

### 1910. msg_9640

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:17:36

Hilarious


---

### 1911. msg_9641

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:17:43

I mean I kind of admire that


---

### 1912. msg_9642

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:17:48

But it is cray


---

### 1913. msg_9643

**You** - 2025-05-07T22:17:59

Oh I know she is nosey I have told her to stop it before


---

### 1914. msg_9644

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:18:09

She is INTENSE


---

### 1915. msg_9645

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:18:16

it’s all good when work related


---

### 1916. msg_9646

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:18:22

Just not when personal


---

### 1917. msg_9647

**You** - 2025-05-07T22:18:34

Yep I can’t trust her with anything like this


---

### 1918. msg_9648

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:19:15

When we are talking in your office now she a us so diff after


---

### 1919. msg_9649

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:19:22

She doesn’t ask me questions


---

### 1920. msg_9650

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:19:31

\*she acts


---

### 1921. msg_9651

**You** - 2025-05-07T22:19:39

lol


---

### 1922. msg_9652

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:19:43

She just wants to be in the know


---

### 1923. msg_9653

**You** - 2025-05-07T22:19:48

Always


---

### 1924. msg_9654

**You** - 2025-05-07T22:19:56

I haven’t been talking to her much lately


---

### 1925. msg_9655

**You** - 2025-05-07T22:20:03

I think it os driving her crazy


---

### 1926. msg_9656

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:20:08

Yah


---

### 1927. msg_9657

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:20:24

She really thinks highly of you and obviously cares about you


---

### 1928. msg_9658

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:20:33

Kind of bothers me lol


---

### 1929. msg_9659

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:20:36

Hahah


---

### 1930. msg_9660

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:20:54

I’m getting used to it


---

### 1931. msg_9661

**You** - 2025-05-07T22:20:58

I don’t understand why people liking me bother you when you are the only one I think about ever


---

### 1932. msg_9662

**You** - 2025-05-07T22:21:06

I am literally neurotic


---

### 1933. msg_9663

**You** - 2025-05-07T22:21:20

Like I mean if I was old me


---

### 1934. msg_9664

**You** - 2025-05-07T22:21:43

Cold and kind of distant or kind of harder to read I would get
Your feelings


---

### 1935. msg_9665

**You** - 2025-05-07T22:22:06

But I have been begging just to see you and I say that in a way that I want to make
You feel amazing and nothing else


---

### 1936. msg_9666

**You** - 2025-05-07T22:22:19

Like that is all there is to it mer\.


---

### 1937. msg_9667

**You** - 2025-05-07T22:22:29

You literally never have to be jealous


---

### 1938. msg_9668

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:22:32

It doesn’t “bother me”\. \.\. it just bothers me


---

### 1939. msg_9669

**You** - 2025-05-07T22:22:38

No one will get any part of me but you


---

### 1940. msg_9670

**You** - 2025-05-07T22:23:08

Reaction: 🤔 from Meredith Lamb
So you can let just fall…listen I don’t flirt


---

### 1941. msg_9671

**You** - 2025-05-07T22:23:13

I don’t tease I don’t lead on


---

### 1942. msg_9672

**You** - 2025-05-07T22:23:17

I do t play games


---

### 1943. msg_9673

**You** - 2025-05-07T22:23:29

And I only text dirty things to you\.


---

### 1944. msg_9674

**You** - 2025-05-07T22:23:37

Sooooooo


---

### 1945. msg_9675

**You** - 2025-05-07T22:24:16

So frustrating that I cannot show you truly how I really feel
Every moment all the time till we can be together sometime in the next
Decade


---

### 1946. msg_9676

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:24:29

lol


---

### 1947. msg_9677

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:24:35

Next decade


---

### 1948. msg_9678

**You** - 2025-05-07T22:24:38

Mer I do t flirt I don’t t even look at other girls


---

### 1949. msg_9679

**You** - 2025-05-07T22:25:55

I mean I think most of you believes me but I cannot wait till all of you does


---

### 1950. msg_9680

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:27:24


*1 attachment(s)*


---

### 1951. msg_9681

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:27:58

>
I mean, ok\.


---

### 1952. msg_9682

**You** - 2025-05-07T22:28:12

It’s true


---

### 1953. msg_9683

**You** - 2025-05-07T22:28:21

It was true before as well


---

### 1954. msg_9684

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:28:43

Okay


---

### 1955. msg_9685

**You** - 2025-05-07T22:32:25

Pshh  fine don’t believe me\.\. but I have never been more serious\.\.  and I am sorry you will worry for nothing\.  The only person I have worried about was Andrew… as irrational as that was\.


---

### 1956. msg_9686

**You** - 2025-05-07T22:33:38

Maybe you should follow your friends lead mer… younger man keeps you younger\.


---

### 1957. msg_9687

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:34:46

Huh?


---

### 1958. msg_9688

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:35:27

Carolyn and I were talking Monday and she and Eli are 1980 like Andrew


---

### 1959. msg_9689

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:35:38

She was like “oh you are the same as Scott\!”


---

### 1960. msg_9690

**You** - 2025-05-07T22:37:02

>
Your friends message the Madonna reference


---

### 1961. msg_9691

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:37:21

Ohhhhhhh


---

### 1962. msg_9692

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:37:33

She’s a weirdo


---

### 1963. msg_9693

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:37:42

You will see when you meet her lol


---

### 1964. msg_9694

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:37:48

She’s always been a weirdo


---

### 1965. msg_9695

**You** - 2025-05-07T22:38:06

Omw home now ☹️ bah


---

### 1966. msg_9696

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:38:24

My nickname for her in third grade was “spazz matazz” and she HATED IT LOL


---

### 1967. msg_9697

**You** - 2025-05-07T22:39:08

That is a pretty 80’s nickname


---

### 1968. msg_9698

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:39:14

>
You are on your way home and Andrew is on his way to hockey\. lol


---

### 1969. msg_9699

**You** - 2025-05-07T22:39:48

Well at least you can be happy about that lol


---

### 1970. msg_9700

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:41:21

I guess


---

### 1971. msg_9701

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:41:23

lol


---

### 1972. msg_9702

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:42:01

Honestly don’t care anymore


---

### 1973. msg_9703

**You** - 2025-05-07T22:43:00

I wouldn’t care at all were my situation a bit different


---

### 1974. msg_9704

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:48:34

Hrm?


---

### 1975. msg_9705

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:48:57

Why would you care about him going to hockey


---

### 1976. msg_9706

**You** - 2025-05-07T22:49:05

Gimme sec


---

### 1977. msg_9707

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:49:05

Aren’t you happier


---

### 1978. msg_9708

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:49:08

lol


---

### 1979. msg_9709

**You** - 2025-05-07T22:53:50

Where is your shadow


---

### 1980. msg_9710

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:54:10

Next room


---

### 1981. msg_9711

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:54:17

I’m in office on my laptop


---

### 1982. msg_9712

**You** - 2025-05-07T22:54:18

Ah ok nm lol


---

### 1983. msg_9713

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:54:25

Buying gifts for my mom


---

### 1984. msg_9714

**You** - 2025-05-07T22:54:26

Ninja is always lurking


---

### 1985. msg_9715

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:54:32

You can call


---

### 1986. msg_9716

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T22:54:38

It’s fine


---

### 1987. msg_9717

**You** - 2025-05-07T23:41:21

Here is a direct side\-by\-side comparison of Morgan Wallen and Kane Brown, focused on the key dimensions of their popularity, including sexual appeal, musical identity, public image, and cultural impact:
⸻
Morgan Wallen vs\. Kane Brown: Popularity Factors Comparison
Dimension	Morgan Wallen	Kane Brown
Sexual Appeal	Strong and overt; tied to his “bad boy” persona, rugged looks, and rebellious attitude\.	Present but softer; more tied to romantic vulnerability, tattoos, and devoted family man\.
Public Persona	Rebellious, raw, emotionally flawed; exudes a mix of charm and controversy\.	Wholesome, grounded, family\-oriented; perceived as humble and emotionally supportive\.
Musical Style	Traditional country with rock and Southern influences; rough\-edged vocals and themes\.	Country\-pop\-R&B hybrid; smoother vocals, crossover production, modern emotional themes\.
Emotional Themes	Heartbreak, drinking, defiance, masculinity, regret\.	Love, family, perseverance, racial identity, self\-worth\.
Fanbase Drivers	\.\.\. \[truncated\]


---

### 1988. msg_9718

**You** - 2025-05-07T23:46:09

❤️❤️sleep well\.


---

### 1989. msg_9719

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T23:48:46

Love you xoxo


---

### 1990. msg_9720

**You** - 2025-05-07T23:50:14

Love you Morgan\. Wherever you are\!\! ❤️❤️❤️❤️❤️


---

### 1991. msg_9721

**You** - 2025-05-07T23:50:48

Reaction: ❤️ from Meredith Lamb
Love you mer, I don’t need a list\.\. you are it\.


---

### 1992. msg_9722

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T23:53:48

Reaction: ❤️ from Scott Hicks
Nite\. Whether you are Morgan, Kane or Blake\. I’m cool\. All good\. lol kidding I like Scott to be Scott


---

### 1993. msg_9723

**You** - 2025-05-07T23:56:33

I can accept that\.


---

### 1994. msg_9724

**Meredith Lamb \(\+14169386001\)** - 2025-05-07T23:57:30

Perf


---

### 1995. msg_9725

**You** - 2025-05-07T23:58:20

Go to bed and good luck
Tomorrow with ur mum\.\. let me know how it goes


---

### 1996. msg_9726

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T00:02:07

k 😋


---

### 1997. msg_9727

**You** - 2025-05-08T00:14:23

https://www\.airbnb\.com/l/ELn7dQaA


---

### 1998. msg_9728

**You** - 2025-05-08T04:32:52

Kept me up too late with your musicians as sexual icon shenanigans… I will no better next time\.


---

### 1999. msg_9729

**You** - 2025-05-08T04:33:05

Love you…


---

### 2000. msg_9730

**You** - 2025-05-08T05:36:53

Oh and my ass hurts\.\. leg day was hard going to walk funny
Today\.


---

### 2001. msg_9731

**You** - 2025-05-08T06:20:33

Maybe pic this morning since you not coming in??


---

### 2002. msg_9732

**You** - 2025-05-08T06:20:46

Trade?


---

### 2003. msg_9733

**You** - 2025-05-08T06:23:25

Like a hungover pic of my love
For whatever I’ve got\.\. will trade\.


---

### 2004. msg_9734

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T06:33:58

>
This place is cool\. Who knew … the shwa…


---

### 2005. msg_9735

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T06:34:23

>
lol back to sleep for a bit


---

### 2006. msg_9736

**You** - 2025-05-08T06:34:33

Just give me the nod whenever and I will book\.\.


---

### 2007. msg_9737

**You** - 2025-05-08T06:34:48

Remember trade hungover pic I wasn’t it\.\.
lol


---

### 2008. msg_9738

**You** - 2025-05-08T06:36:11

Will make it worth it


---

### 2009. msg_9739

**You** - 2025-05-08T06:36:16

☺️


---

### 2010. msg_9740

**You** - 2025-05-08T09:33:38

Guessing you woke up late


---

### 2011. msg_9741

**You** - 2025-05-08T09:33:40

lol


---

### 2012. msg_9742

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:33:50

Sorry I didn’t respond to this\. There will be no hungover 47 yr old photos of me in existence online ever\.


---

### 2013. msg_9743

**You** - 2025-05-08T09:34:02

Ok then no fun stuff for you


---

### 2014. msg_9744

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:34:09

Erin called so talked to her for 45 min


---

### 2015. msg_9745

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:34:33

I told her I’m going to take Geoff’s role\. She freaked out\. Lol


---

### 2016. msg_9746

**You** - 2025-05-08T09:34:38

lol


---

### 2017. msg_9747

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:34:40

I said I was kidding …\. Kind of


---

### 2018. msg_9748

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:34:42

lol


---

### 2019. msg_9749

**You** - 2025-05-08T09:34:46

You do you


---

### 2020. msg_9750

**You** - 2025-05-08T09:34:50

I will supportive


---

### 2021. msg_9751

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:35:15

I’m honestly going to think about it\. I told her it might ruin my rep


---

### 2022. msg_9752

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T09:35:20

She didn’t think so


---

### 2023. msg_9753

**You** - 2025-05-08T09:45:04

It’s truly up to you there are different people that think different things\.\.


---

### 2024. msg_9754

**You** - 2025-05-08T09:45:08

I might wait


---

### 2025. msg_9755

**You** - 2025-05-08T09:45:28

I don’t want you moving out of some sense that I am going to lose my shit


---

### 2026. msg_9756

**You** - 2025-05-08T09:45:33

It needs to make sense


---

### 2027. msg_9757

**You** - 2025-05-08T09:45:50

I mean if they could bunp it to a 510 expand the role


---

### 2028. msg_9758

**You** - 2025-05-08T09:45:57

You could talk to Daniel


---

### 2029. msg_9759

**You** - 2025-05-08T09:45:59

Or I could


---

### 2030. msg_9760

**You** - 2025-05-08T09:46:26

It I think I would need to come clean on a few things, not that we are in a relationship but that one might develop down the road


---

### 2031. msg_9761

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:35:48

Hmmh


---

### 2032. msg_9762

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:36:12

Honestly I have so much going on in my life I wouldn’t even care if it is a 510


---

### 2033. msg_9763

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:36:37

It would bother me leaving the team tho … would feel bad


---

### 2034. msg_9764

**You** - 2025-05-08T10:37:59

I think you should speak to Daniel and I think we would need to tell him something


---

### 2035. msg_9765

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:38:14

Why would we need to?


---

### 2036. msg_9766

**You** - 2025-05-08T10:38:35

Because if and when it comes out later it will be obvious


---

### 2037. msg_9767

**You** - 2025-05-08T10:38:41

Or maybe\. Or I dunno


---

### 2038. msg_9768

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:38:55

But why would that matter?


---

### 2039. msg_9769

**You** - 2025-05-08T10:39:25

Optics


---

### 2040. msg_9770

**You** - 2025-05-08T10:39:47

I mean we could say clearly nothing g happened but it is about your motivations


---

### 2041. msg_9771

**You** - 2025-05-08T10:39:59

If you moved back so we could date the\. That would be Eesh


---

### 2042. msg_9772

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:40:48

I mean I enjoy policy more so that is a very real story\. I’m also overwhelmed with this team and my personal life\. So it is two fold\.


---

### 2043. msg_9773

**You** - 2025-05-08T10:42:16

Ok if that is what you want\.\. but again I would talk to Daniel we would need\. A story for Ian cause he will ask\.\. and we could keep everything quiet here for months easily


---

### 2044. msg_9774

**You** - 2025-05-08T10:42:28

I am not worried about that I am worried about you\.\.


---

### 2045. msg_9775

**You** - 2025-05-08T10:42:33

All I care about


---

### 2046. msg_9776

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:43:09

Isn’t my “story” \(which is real\) good for Ian?


---

### 2047. msg_9777

**You** - 2025-05-08T10:43:12

I can only get it one night so will have to find another place for the next night I think\.\. need to figure some shit out or I find another pls e


---

### 2048. msg_9778

**You** - 2025-05-08T10:43:16

It is\.\.


---

### 2049. msg_9779

**You** - 2025-05-08T10:43:23

Thinking long term


---

### 2050. msg_9780

**You** - 2025-05-08T10:43:27

But yeah


---

### 2051. msg_9781

**You** - 2025-05-08T10:43:51

Just let me know what and when o will end up having to speak with Daniel he will want to ask


---

### 2052. msg_9782

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:44:09

He will want to ask what?


---

### 2053. msg_9783

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:46:27

Ps\. Erin already knows\. We’ve talked about it a few times\.


---

### 2054. msg_9784

**You** - 2025-05-08T10:46:53

He will just want to talk to me mgr to mgr to ask if I am ok with this


---

### 2055. msg_9785

**You** - 2025-05-08T10:47:49

Ok I kinda need to know this how long on sat did you plan on hanging out


---

### 2056. msg_9786

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:47:51

Just tell him I can’t hack this job lol


---

### 2057. msg_9787

**You** - 2025-05-08T10:47:56

No


---

### 2058. msg_9788

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:48:06

Yes


---

### 2059. msg_9789

**You** - 2025-05-08T10:48:11

It will depend what I book


---

### 2060. msg_9790

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:48:31

>
Not beyond lunch for sure


---

### 2061. msg_9791

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:48:40

I have to drive back to Toronto to get my girls


---

### 2062. msg_9792

**You** - 2025-05-08T10:48:44

Ok late checkout is lunch so that is fine


---

### 2063. msg_9793

**You** - 2025-05-08T10:49:15

Yep I get it\.  I will pick up and move somewhere else for the next night


---

### 2064. msg_9794

**You** - 2025-05-08T10:49:57

Sucks because both nights were open last night just bad luck


---

### 2065. msg_9795

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:50:18

Nowhere else?


---

### 2066. msg_9796

**You** - 2025-05-08T10:50:55

I mean I could look but it isn’t like you can come back anyways so not a huge deal


---

### 2067. msg_9797

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:51:38

k


---

### 2068. msg_9798

**You** - 2025-05-08T10:52:48

I will let you know where the second one I book is anyways just so you can keep tabs on me\.


---

### 2069. msg_9799

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T10:54:38

lol ok


---

### 2070. msg_9800

**You** - 2025-05-08T10:55:03

You know or for whatever other reasons\.\. 🥰


---

### 2071. msg_9801

**You** - 2025-05-08T10:55:09

Alright booking now


---

### 2072. msg_9802

**You** - 2025-05-08T10:55:17

I will need an image of if though


---

### 2073. msg_9803

**You** - 2025-05-08T12:00:25

Can you talk


---

### 2074. msg_9804

**You** - 2025-05-08T12:00:37

Nm you on a call


---

### 2075. msg_9805

**You** - 2025-05-08T12:37:09

Offer being submitted


---

### 2076. msg_9806

**You** - 2025-05-08T12:37:14

Reaction: 😬 from Meredith Lamb
Sick to my stomach


---

### 2077. msg_9807

**You** - 2025-05-08T12:39:21

Gah I wish we had 2 days\.\. who is a greedy boy\!?


---

### 2078. msg_9808

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:40:57

Yeah really holy


---

### 2079. msg_9809

**You** - 2025-05-08T12:42:38


*1 attachment(s)*


---

### 2080. msg_9810

**You** - 2025-05-08T12:42:49

That is how close to your parents house


---

### 2081. msg_9811

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:43:24

Nice


---

### 2082. msg_9812

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:43:33

I won’t have to turn my find my off


---

### 2083. msg_9813

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:43:39

For my little shadow


---

### 2084. msg_9814

**You** - 2025-05-08T12:44:10

Checkin is 4 pm I will be finishing work early it seems


---

### 2085. msg_9815

**You** - 2025-05-08T12:44:14

Yay


---

### 2086. msg_9816

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:45:06

Debating working from my parents tomorrow\.


---

### 2087. msg_9817

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:45:09

Will see


---

### 2088. msg_9818

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T12:45:18

The drive is awful during rush hour


---

### 2089. msg_9819

**You** - 2025-05-08T12:48:51

Scott is sharing details of an upcoming trip\.
This invite expires in 7 days\.
https://expe\.app\.link/Nk4iu9pUcTb


---

### 2090. msg_9820

**You** - 2025-05-08T12:49:19

Prolly not a bad idea save a lot of time


---

### 2091. msg_9821

**You** - 2025-05-08T14:17:42

Love you cranky girl… ❤️


---

### 2092. msg_9822

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T14:20:49

I need a nap lol \(I am not a volt of lightning\) love you too


---

### 2093. msg_9823

**You** - 2025-05-08T14:32:55

You are something\.\. always something else to learn\.\. so many layers… and sexual fantasies to figure out… should make things interesting at least\.\. I am boring in comparison but hey I will
Try whatever you want me to \- drug or otherwise\.


---

### 2094. msg_9824

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T14:44:20

lol you are hardly boring\. Omg


---

### 2095. msg_9825

**You** - 2025-05-08T15:50:22

I feel like I am I so don’t want to lose you omg\.\. how bad does that sound lol…
I am the saddest person o\. Earth and never saw myself
Like this nor acted like this\.\. Jesus\.\. kk ignore everything I just said\.\. what have you done to me\!\!\! lol


---

### 2096. msg_9826

**You** - 2025-05-08T15:56:00

Doing seating will call you after if you can take a call


---

### 2097. msg_9827

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T15:57:57

>
Omg… lol


---

### 2098. msg_9828

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T15:58:20

>
k, I’m around just reading IRP 😛


---

### 2099. msg_9829

**You** - 2025-05-08T16:19:42

Yeah having a moment here all triggered by yku switching teams how does that even make any sense wtf seriously I am broken


---

### 2100. msg_9830

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T16:35:04

Our work situation is becoming untenable and I don’t really love this role anyway\. It’s a bit much especially going through separation and I will be living alone etc etc\. lots of adjustments \.\. youngest starting middle school, middle starting high school etc etc it is just a lot


---

### 2101. msg_9831

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T16:37:01

You are good in your role and everyone loves you\. You should stay\. Makes no sense for you to leave


---

### 2102. msg_9832

**You** - 2025-05-08T16:48:14

I am not having an issue with you doing this\.\. I just had some stupid triggered moment of you leaving the team and equating it to leaving me for some reason\.\.


---

### 2103. msg_9833

**You** - 2025-05-08T16:48:29

Stuck doing seating assignments so annoyed


---

### 2104. msg_9834

**You** - 2025-05-08T16:48:49

Just too much atm too much\.


---

### 2105. msg_9835

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T16:52:13

>
Definitely not the case\.


---

### 2106. msg_9836

**You** - 2025-05-08T17:03:40

You can show me tomorrow\.


---

### 2107. msg_9837

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T17:20:30

Sure


---

### 2108. msg_9838

**You** - 2025-05-08T17:31:06

I know I am being crazy too much change today\.\.


---

### 2109. msg_9839

**You** - 2025-05-08T17:31:10

Cannot process


---

### 2110. msg_9840

**You** - 2025-05-08T17:31:20

We have been back and forth on house already once


---

### 2111. msg_9841

**You** - 2025-05-08T17:31:25

I suspect we close tonight


---

### 2112. msg_9842

**You** - 2025-05-08T17:42:02

Going to car jow


---

### 2113. msg_9843

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T17:50:45

>
That is overwhelming change for sure


---

### 2114. msg_9844

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:26:33

So survived open house… it was the same the third time around\. Imagine that\. :p


---

### 2115. msg_9845

**You** - 2025-05-08T20:33:47

Omg shocking


---

### 2116. msg_9846

**You** - 2025-05-08T20:33:51

Out buying shoes


---

### 2117. msg_9847

**You** - 2025-05-08T20:39:24

So you are cranky again tonight 🙁


---

### 2118. msg_9848

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:40:35

Kinda\. Watching some tv


---

### 2119. msg_9849

**You** - 2025-05-08T20:40:37

I think you need a glass


---

### 2120. msg_9850

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:40:43

lol no


---

### 2121. msg_9851

**You** - 2025-05-08T20:40:46

Or 5


---

### 2122. msg_9852

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:40:51

I will stay up too late


---

### 2123. msg_9853

**You** - 2025-05-08T20:40:55

94 some edibles


---

### 2124. msg_9854

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:41:01

I want to go to sleep earlier


---

### 2125. msg_9855

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:41:12

I do have lots of gummies lol


---

### 2126. msg_9856

**You** - 2025-05-08T20:42:48

Kk I will be up late


---

### 2127. msg_9857

**You** - 2025-05-08T20:42:55

Going to try new shoes out


---

### 2128. msg_9858

**You** - 2025-05-08T20:43:53

Since I not getting up early


---

### 2129. msg_9859

**You** - 2025-05-08T20:43:59

And actually working from home


---

### 2130. msg_9860

**You** - 2025-05-08T20:44:35

Bout to drive home


---

### 2131. msg_9861

**You** - 2025-05-08T20:44:58

So out of touch for a few mins


---

### 2132. msg_9862

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T20:45:23

k ❤️


---

### 2133. msg_9863

**You** - 2025-05-08T21:09:07

Sorry I was a bit occupied unfortunately apologies ❤️❤️❤️


---

### 2134. msg_9864

**You** - 2025-05-08T21:10:28

Love you sorry you are having a bad night tomorrow night will be better


---

### 2135. msg_9865

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:12:16

Can’t wait\!


---

### 2136. msg_9866

**You** - 2025-05-08T21:12:39

Same\.\. watcha watching\.\. I am just getting ready to head out


---

### 2137. msg_9867

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:14:01

Four seasons


---

### 2138. msg_9868

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:14:21

Head out to gym?


---

### 2139. msg_9869

**You** - 2025-05-08T21:19:53

Yep


---

### 2140. msg_9870

**You** - 2025-05-08T21:20:07

Sorry had to
Get out to car


---

### 2141. msg_9871

**You** - 2025-05-08T21:20:12

Annoying tonight


---

### 2142. msg_9872

**You** - 2025-05-08T21:20:51

You have a quiet night till happy whatever is ice


---

### 2143. msg_9873

**You** - 2025-05-08T21:20:55

O we


---

### 2144. msg_9874

**You** - 2025-05-08T21:21:01

Over……


---

### 2145. msg_9875

**You** - 2025-05-08T21:21:40

Anyways here if you need me


---

### 2146. msg_9876

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:22:08

You had an annoying night?


---

### 2147. msg_9877

**You** - 2025-05-08T21:22:18

Yep


---

### 2148. msg_9878

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:22:33

Why?


---

### 2149. msg_9879

**You** - 2025-05-08T21:22:34

Fought all way to mall all way back


---

### 2150. msg_9880

**You** - 2025-05-08T21:22:36

Gracie


---

### 2151. msg_9881

**You** - 2025-05-08T21:22:38

About


---

### 2152. msg_9882

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:22:46

Ohh


---

### 2153. msg_9883

**You** - 2025-05-08T21:22:52

Bullshit


---

### 2154. msg_9884

**You** - 2025-05-08T21:23:02

Definition of insanity


---

### 2155. msg_9885

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:23:30

So no progress at all


---

### 2156. msg_9886

**You** - 2025-05-08T21:24:00

Not with Gracie\. It house is about 1 negotiation from done


---

### 2157. msg_9887

**You** - 2025-05-08T21:24:07

If she decides to close


---

### 2158. msg_9888

**You** - 2025-05-08T21:24:10

lol who knows


---

### 2159. msg_9889

**You** - 2025-05-08T21:24:31

I mean I think she will


---

### 2160. msg_9890

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:24:32

Oh wow


---

### 2161. msg_9891

**You** - 2025-05-08T21:24:53

Probably in morning tomorrow


---

### 2162. msg_9892

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:25:14

That’s wild…


---

### 2163. msg_9893

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:25:29

Seems fast considering where she was a short time ago


---

### 2164. msg_9894

**You** - 2025-05-08T21:25:47

Everything is wild


---

### 2165. msg_9895

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:25:57

True


---

### 2166. msg_9896

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:26:00

lol


---

### 2167. msg_9897

**You** - 2025-05-08T21:26:19

Not always in a good way


---

### 2168. msg_9898

**You** - 2025-05-08T21:26:26

Most of the time not\.\.


---

### 2169. msg_9899

**You** - 2025-05-08T21:26:29

Man


---

### 2170. msg_9900

**You** - 2025-05-08T21:26:34

Just want this over with


---

### 2171. msg_9901

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:26:54

Yeah same\.\.


---

### 2172. msg_9902

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:29:02

It will all be worth it \.\.


---

### 2173. msg_9903

**You** - 2025-05-08T21:30:40

I hope you always feel that way


---

### 2174. msg_9904

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:31:46

Same to you…


---

### 2175. msg_9905

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:32:07

Once I leave your team no replacing me and doing this all over again


---

### 2176. msg_9906

**You** - 2025-05-08T21:32:14

Oh I know I will lol\.\.


---

### 2177. msg_9907

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:32:15

😛


---

### 2178. msg_9908

**You** - 2025-05-08T21:32:17

Well I mean


---

### 2179. msg_9909

**You** - 2025-05-08T21:32:48

Soohear is kinda married\.\. so a little difficult and she would be in like Chatham or wherever\.


---

### 2180. msg_9910

**You** - 2025-05-08T21:32:54

Think you are safe


---

### 2181. msg_9911

**You** - 2025-05-08T21:32:55

lol


---

### 2182. msg_9912

**You** - 2025-05-08T21:33:08

I could always hire a dude


---

### 2183. msg_9913

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:33:27

You were married\.\. I was basically …


---

### 2184. msg_9914

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:33:31

I mean


---

### 2185. msg_9915

**You** - 2025-05-08T21:33:49

We were on the way out together\.\. besides only one soul mate\.


---

### 2186. msg_9916

**You** - 2025-05-08T21:34:05

Why would I ever look after I found you


---

### 2187. msg_9917

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:34:15

I was kidding, not serious\.


---

### 2188. msg_9918

**You** - 2025-05-08T21:34:19

Good


---

### 2189. msg_9919

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:35:24

I worry a bit that you are going to get tired of my lack of ability to bleed emotion like you do though…\.


---

### 2190. msg_9920

**You** - 2025-05-08T21:36:48

It’s not that you don’t\.  It’s that we don’t see each other


---

### 2191. msg_9921

**You** - 2025-05-08T21:37:01

When we are together I have never been happier ever


---

### 2192. msg_9922

**You** - 2025-05-08T21:37:38

You perfect the way you are\.\. The more we are together The more I get to know you the more you open up the more I love you even the crazy stuff lol


---

### 2193. msg_9923

**You** - 2025-05-08T21:39:24

I promise I am never leaving\.\.


---

### 2194. msg_9924

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:39:27

Crazy stuff lol …


---

### 2195. msg_9925

**You** - 2025-05-08T21:39:34

Easy promise to make and keep


---

### 2196. msg_9926

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:39:41

Ok well I am not either


---

### 2197. msg_9927

**You** - 2025-05-08T21:39:41

Reaction: 😂 from Meredith Lamb
Fan girl crazy stuff


---

### 2198. msg_9928

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:39:53

Whatever omg


---

### 2199. msg_9929

**You** - 2025-05-08T21:40:26

Since you were a bit pounded go read my goodnight message


---

### 2200. msg_9930

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:42:13

Morgan wallen vs Kane brown LOL forgot about that


---

### 2201. msg_9931

**You** - 2025-05-08T21:43:00

No the good night message \.\. lol I didn’t even know if you actually read it at the time


---

### 2202. msg_9932

**You** - 2025-05-08T21:45:07

Kk I am on treadmill will try to text or you can call whatever works for you\.\. just starting up now


---

### 2203. msg_9933

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:45:48

Can’t call\. Everyone around\.


---

### 2204. msg_9934

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:46:06

I’m on the last episode of four seasons


---

### 2205. msg_9935

**You** - 2025-05-08T21:46:24

Ah ok do your thing


---

### 2206. msg_9936

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:46:29

>
I read all of your messages\. I just maybe don’t remember them all the time lol


---

### 2207. msg_9937

**You** - 2025-05-08T21:47:16

Yeah I am
Overly verbose i know it lol


---

### 2208. msg_9938

**You** - 2025-05-08T21:51:39

I forgot


---

### 2209. msg_9939

**You** - 2025-05-08T21:52:02



---

### 2210. msg_9940

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:52:33

\[shakes head\]


---

### 2211. msg_9941

**You** - 2025-05-08T21:53:09

All you had to give was one pic


---

### 2212. msg_9942

**You** - 2025-05-08T21:53:33

This one too


---

### 2213. msg_9943

**You** - 2025-05-08T21:53:39



---

### 2214. msg_9944

**You** - 2025-05-08T21:54:02

All I wanted was hungover pic


---

### 2215. msg_9945

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T21:54:42

Noooooo hungover photos


---

### 2216. msg_9946

**You** - 2025-05-08T21:55:02

Kk 😝


---

### 2217. msg_9947

**You** - 2025-05-08T22:12:23

Alright I am going sauna and shower will ping you o ce when I am out\.\. no answer will say nite\.


---

### 2218. msg_9948

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T22:13:02

k I have moved onto handmaids tale


---

### 2219. msg_9949

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T22:13:04

lol


---

### 2220. msg_9950

**You** - 2025-05-08T22:13:17

Glad you are relaxing


---

### 2221. msg_9951

**You** - 2025-05-08T22:41:06

I mean I think we should eat a full season of handsmaids tale tomorrow


---

### 2222. msg_9952

**You** - 2025-05-08T22:41:13

Watch


---

### 2223. msg_9953

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T22:51:09

lol ok


---

### 2224. msg_9954

**Meredith Lamb \(\+14169386001\)** - 2025-05-08T22:51:32

I’m totally falling asleep so going to bed xoxox love you and can’t wait to see you tomorrow


---

### 2225. msg_9955

**You** - 2025-05-08T22:54:02

On my way home going to get some stuff ready for tomorrow and go to bed too\.\. really looking forward to seeing you\.\. probably heading over
Right around 4 ish need
To get
Away\.


---

### 2226. msg_9956

**You** - 2025-05-08T22:54:31

Reaction: 😂 from Meredith Lamb
We can go out and grab anything you want when you get there I will even let you stay in car so you aren’t seen with me


---

### 2227. msg_9957

**You** - 2025-05-08T22:54:50

Reaction: ❤️ from Meredith Lamb
Love you very much and thanks
For
Finding a way to make this happen


---

### 2228. msg_9958

**You** - 2025-05-08T22:54:56

❤️❤️❤️❤️😝


---

### 2229. msg_9959

**You** - 2025-05-08T22:55:05

I mean the last one


---

### 2230. msg_9960

**You** - 2025-05-08T22:55:11

Really typo lol


---

### 2231. msg_9961

**You** - 2025-05-08T22:55:26

Nite


---

### 2232. msg_9962

**You** - 2025-05-08T23:02:38

For the morning curious\.\. preference scruffy vs clean shaven think on it\.\. 😊


---

### 2233. msg_9963

**You** - 2025-05-09T06:25:29

Nah ignore you don’t have to answer that too personal 😝


---

### 2234. msg_9964

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:56:36

Not sure \- you will have to let me experience both\. Then I can tell you\. Scientific analysis


---

### 2235. msg_9965

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:56:48

So I woke up at 4am and couldn’t sleep


---

### 2236. msg_9966

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:56:52

Gahhhhhh


---

### 2237. msg_9967

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:56:56

Insomnia


---

### 2238. msg_9968

**You** - 2025-05-09T07:56:59

What is wrong


---

### 2239. msg_9969

**You** - 2025-05-09T07:57:04

What are you worried about


---

### 2240. msg_9970

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:57:12

So I took melatonin


---

### 2241. msg_9971

**You** - 2025-05-09T07:57:16

You are going to be tired tonight\.\. we can take it easy


---

### 2242. msg_9972

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:57:27

No I will be on


---

### 2243. msg_9973

**You** - 2025-05-09T07:57:28

Just cuddle me and handmaids take


---

### 2244. msg_9974

**You** - 2025-05-09T07:57:34

🙂


---

### 2245. msg_9975

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:57:39

I was thinking about switching roles


---

### 2246. msg_9976

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:58:01

Totally ok with it but thinking about explaining it to EVERYONE


---

### 2247. msg_9977

**You** - 2025-05-09T07:58:01

Worried


---

### 2248. msg_9978

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:58:16

just the explaining to 100 ppl


---

### 2249. msg_9979

**You** - 2025-05-09T07:58:16

You will need to explain the personal side


---

### 2250. msg_9980

**You** - 2025-05-09T07:58:21

Not 100


---

### 2251. msg_9981

**You** - 2025-05-09T07:58:24

Your team


---

### 2252. msg_9982

**You** - 2025-05-09T07:58:31

It will trickle around


---

### 2253. msg_9983

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:58:36

Sales


---

### 2254. msg_9984

**You** - 2025-05-09T07:58:39

But nothing you have to do behind that


---

### 2255. msg_9985

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:58:40

Marketing


---

### 2256. msg_9986

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:58:43

Bailey


---

### 2257. msg_9987

**You** - 2025-05-09T07:58:47

No you don’t have to explain


---

### 2258. msg_9988

**You** - 2025-05-09T07:58:51

But bailey yeah


---

### 2259. msg_9989

**You** - 2025-05-09T07:58:57

Still no biggy


---

### 2260. msg_9990

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:59:02

Shailley


---

### 2261. msg_9991

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:59:11

Everyone


---

### 2262. msg_9992

**You** - 2025-05-09T07:59:12

I think you are overthinking


---

### 2263. msg_9993

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:59:35

I am not overthinking\. It is just part of it


---

### 2264. msg_9994

**You** - 2025-05-09T07:59:35

But if you want to stay that is completely fine with me the team loves you


---

### 2265. msg_9995

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:59:43

No no


---

### 2266. msg_9996

**You** - 2025-05-09T07:59:43

And I think you are a great leader


---

### 2267. msg_9997

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T07:59:51

It is just part of the process


---

### 2268. msg_9998

**You** - 2025-05-09T08:00:20

Ok let me know what I can do to help\.\. for my part I have a convo with soohear in 5 mins to test the waters\.


---

### 2269. msg_9999

**You** - 2025-05-09T08:00:42

I figured you are all in on this and I need mon downtime


---

### 2270. msg_10000

**You** - 2025-05-09T08:00:46

Min


---

### 2271. msg_10001

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:00:54

It is just something my brain has to process and unfortunately sometimes that happens at 4am


---

### 2272. msg_10002

**You** - 2025-05-09T08:01:02

That sucks


---

### 2273. msg_10003

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:01:07

During Covid I had insomnia


---

### 2274. msg_10004

**You** - 2025-05-09T08:01:19

My brain went dead last night massive blow up with Gracie


---

### 2275. msg_10005

**You** - 2025-05-09T08:01:26

Then went to bed after
Midnight


---

### 2276. msg_10006

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:02:23

Same thing with her?


---

### 2277. msg_10007

**You** - 2025-05-09T08:06:36

Yep


---

### 2278. msg_10008

**You** - 2025-05-09T08:56:52

Wow we are literal at the finish line and she flipping again\.\. cannot believe it\.


---

### 2279. msg_10009

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:58:37

Jaime?


---

### 2280. msg_10010

**You** - 2025-05-09T08:58:46

Yah


---

### 2281. msg_10011

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:58:57

Last minute cold feet


---

### 2282. msg_10012

**You** - 2025-05-09T08:59:02

Yep


---

### 2283. msg_10013

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:59:06

It’s a huge change\. Not surprised really


---

### 2284. msg_10014

**You** - 2025-05-09T08:59:09

Says I am not giving her options


---

### 2285. msg_10015

**You** - 2025-05-09T08:59:19

I dunno what to do\.\. back to renting I think


---

### 2286. msg_10016

**You** - 2025-05-09T08:59:28

But it will be much much much sooner


---

### 2287. msg_10017

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:59:39

“Options”


---

### 2288. msg_10018

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T08:59:55

Hmm


---

### 2289. msg_10019

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T09:00:08

There aren’t TOO many options really


---

### 2290. msg_10020

**You** - 2025-05-09T09:00:40

I know


---

### 2291. msg_10021

**You** - 2025-05-09T09:00:45

Brb driving maddie


---

### 2292. msg_10022

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T10:19:20

Was sophear interested?


---

### 2293. msg_10023

**You** - 2025-05-09T11:01:21

Nope I mean yep but I think there might be a mgr role coming up on elder side she doesn’t want to miss out o \.


---

### 2294. msg_10024

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T11:11:20

Gah


---

### 2295. msg_10025

**You** - 2025-05-09T11:59:49

It’s fine Mia manyu is also interested


---

### 2296. msg_10026

**You** - 2025-05-09T11:59:55

And a few others I think


---

### 2297. msg_10027

**You** - 2025-05-09T12:03:23

Not saying this in teams but I am def not worth it\.\. too much driving


---

### 2298. msg_10028

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:07:21

Omg stop it


---

### 2299. msg_10029

**You** - 2025-05-09T12:07:42

Omg…\.\. just stop it\!\!


---

### 2300. msg_10030

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:09:55

Well seriously


---

### 2301. msg_10031

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:09:59

Not necessary


---

### 2302. msg_10032

**You** - 2025-05-09T12:10:24

lol I am just saying I appreciate it\.\. it is a lot of
Trouble


---

### 2303. msg_10033

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:13:58

Tell octo that bc I’m going to be late for his 1pm lol


---

### 2304. msg_10034

**You** - 2025-05-09T12:14:13

Ok


---

### 2305. msg_10035

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:14:28

I already warned him


---

### 2306. msg_10036

**You** - 2025-05-09T12:14:42

Then I won’t again or it would be weird


---

### 2307. msg_10037

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:14:52

I was kidding


---

### 2308. msg_10038

**You** - 2025-05-09T12:15:22

Now I am confused lol warn not warn\.\. go have a nap?


---

### 2309. msg_10039

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:15:35

Do not


---

### 2310. msg_10040

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:15:41

I did already


---

### 2311. msg_10041

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:16:39

Shit I forgot my gummies lol


---

### 2312. msg_10042

**You** - 2025-05-09T12:16:52

Rofl


---

### 2313. msg_10043

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:17:05

I knew I forgot something


---

### 2314. msg_10044

**You** - 2025-05-09T12:17:06

You can buy some dispensaries all over oshawa


---

### 2315. msg_10045

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:17:07

lol


---

### 2316. msg_10046

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:17:21

But they are specific


---

### 2317. msg_10047

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:17:41

But yeah


---

### 2318. msg_10048

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:17:45

I don’t need them lol


---

### 2319. msg_10049

**You** - 2025-05-09T12:19:32

Tell me what they are I will pick some up


---

### 2320. msg_10050

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:23:56

Nah I don’t need them


---

### 2321. msg_10051

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:24:10

I can get them tomorrow for tomorrow night lol


---

### 2322. msg_10052

**You** - 2025-05-09T12:24:16

lol ok


---

### 2323. msg_10053

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:25:53

I do want to have a couple \(?\) drinks tho\. And didn’t bring anything so will have to pick up\. Which is fine\. I have no meetings past 2\.30


---

### 2324. msg_10054

**You** - 2025-05-09T12:27:02

I can also stop I was going to get something for myself anyways and Pinot for yku if you weren’t grabbing g any\.


---

### 2325. msg_10055

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T12:47:45

What is with traffic at Salem rd omg


---

### 2326. msg_10056

**You** - 2025-05-09T12:53:49

Dunno been shit last few days


---

### 2327. msg_10057

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:09:01

Ugh forgot my power cord lol


---

### 2328. msg_10058

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:09:17

I have 3 hrs on my laptop and that’s it


---

### 2329. msg_10059

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:09:22

Should be fine


---

### 2330. msg_10060

**You** - 2025-05-09T13:10:27

I will bring my power cord to place
Tonight if you want to charge for weekend


---

### 2331. msg_10061

**You** - 2025-05-09T13:10:35

Well bringing laptop anyways for tomorrow


---

### 2332. msg_10062

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:25:29

I don’t need it


---

### 2333. msg_10063

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:25:40

I will just need a phone charger


---

### 2334. msg_10064

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:25:42

lol


---

### 2335. msg_10065

**You** - 2025-05-09T13:25:47

I know but I will because I will be working


---

### 2336. msg_10066

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:25:49

I basically forgot everything


---

### 2337. msg_10067

**You** - 2025-05-09T13:25:51

I have a phone charger


---

### 2338. msg_10068

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:25:57

Kidding


---

### 2339. msg_10069

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:26:00

K good


---

### 2340. msg_10070

**You** - 2025-05-09T13:26:20

In meetings for a bit then heading out after I meet with Ian\.\.


---

### 2341. msg_10071

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:40:40

k


---

### 2342. msg_10072

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T13:41:01

Keep me updated


---

### 2343. msg_10073

**You** - 2025-05-09T13:41:15

Will do


---

### 2344. msg_10074

**You** - 2025-05-09T15:15:24

Making progress


---

### 2345. msg_10075

**You** - 2025-05-09T15:15:28

Oh we got the house


---

### 2346. msg_10076

**You** - 2025-05-09T15:15:36

Fyi


---

### 2347. msg_10077

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T15:16:04

The mansion?


---

### 2348. msg_10078

**You** - 2025-05-09T15:16:23

Yep


---

### 2349. msg_10079

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T15:21:18

How are you feeling?


---

### 2350. msg_10080

**You** - 2025-05-09T15:48:27

Can I call


---

### 2351. msg_10081

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T15:53:48

Sure I’m cleaning my moms basement


---

### 2352. msg_10082

**You** - 2025-05-09T15:57:23

Sec just lcbo


---

### 2353. msg_10083

**You** - 2025-05-09T16:09:36

Holy fuck I want to leave just doing some shit for fam because that’s me \.\.


---

### 2354. msg_10084

**You** - 2025-05-09T16:10:24

I am very impatient atm
Ground it out all day to avoid this


---

### 2355. msg_10085

**You** - 2025-05-09T16:12:00

Morgan wallen came on radio at subway…\. lol


---

### 2356. msg_10086

**You** - 2025-05-09T16:12:10

Universe telling me to hurry up


---

### 2357. msg_10087

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T16:12:13

I’m cleaning for my mom lol


---

### 2358. msg_10088

**You** - 2025-05-09T16:12:26

She is probably happy to have you there anyways


---

### 2359. msg_10089

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T16:17:49

Yeah for sure\. What time are you thinking\. I’m good with whatever


---

### 2360. msg_10090

**You** - 2025-05-09T16:28:01

I am leaving now have to make a stop otw haven’t earn not sure what to do the


---

### 2361. msg_10091

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T16:35:41

I can’t interpret the end of that msg\. Grammar lol


---

### 2362. msg_10092

**You** - 2025-05-09T16:36:23

Sec


---

### 2363. msg_10093

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T16:37:07

Just talking to my parents


---

### 2364. msg_10094

**You** - 2025-05-09T16:44:53

Kk sorry getting blasted with teams calls


---

### 2365. msg_10095

**You** - 2025-05-09T16:45:01

I said I hadn’t eaten not sure what to do


---

### 2366. msg_10096

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T16:47:13

We can order?


---

### 2367. msg_10097

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T16:47:17

I haven’t eaten either


---

### 2368. msg_10098

**You** - 2025-05-09T17:04:21

Kk I am heading to location\. Now should be there in 10
Mins


---

### 2369. msg_10099

**You** - 2025-05-09T17:05:41

Want me to pick you up


---

### 2370. msg_10100

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:08:31

No I’ll drive myself


---

### 2371. msg_10101

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:08:39

lol


---

### 2372. msg_10102

**You** - 2025-05-09T17:10:36

I checked there were 2 spots


---

### 2373. msg_10103

**You** - 2025-05-09T17:10:39

For parking


---

### 2374. msg_10104

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:10:46

I have to vacuum the upper floor


---

### 2375. msg_10105

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:10:50

Will do that now


---

### 2376. msg_10106

**You** - 2025-05-09T17:10:53

lol


---

### 2377. msg_10107

**You** - 2025-05-09T17:10:56

Edited: 2 versions
| Version: 2
| Sent: Fri, 9 May 2025 17:39:56 \-0400
|
| K
|
| Version: 1
| Sent: Fri, 9 May 2025 17:10:56 \-0400
|
| Ok


---

### 2378. msg_10108

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:11:04

Have just been talking to me parents


---

### 2379. msg_10109

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:11:07

\*my


---

### 2380. msg_10110

**You** - 2025-05-09T17:11:09

All good


---

### 2381. msg_10111

**You** - 2025-05-09T17:11:24

Did you tell them j bought a house


---

### 2382. msg_10112

**You** - 2025-05-09T17:20:32

I am here it is literally straight ahead when you get to cedar point road my rental is in yard just park behind I think should be fine


---

### 2383. msg_10113

**You** - 2025-05-09T17:22:46

Cozy


---

### 2384. msg_10114

**You** - 2025-05-09T17:23:08

Walk around right side of house down the steps take a left second set of sliding doors and they are open


---

### 2385. msg_10115

**You** - 2025-05-09T17:23:40

I might grab a shower


---

### 2386. msg_10116

**You** - 2025-05-09T17:35:37

Sorry unintentional


---

### 2387. msg_10117

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:39:35

K I will probably leave in like 10
Min or so


---

### 2388. msg_10118

**You** - 2025-05-09T17:40:06

K


---

### 2389. msg_10119

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T17:45:57

What is the address


---

### 2390. msg_10120

**You** - 2025-05-09T17:46:50

264 Cedar Valley Blvd, Oshawa, ON, L1G 3W1 Canada


---

### 2391. msg_10121

**You** - 2025-05-09T18:21:44

You ok lol?


---

### 2392. msg_10122

**Meredith Lamb \(\+14169386001\)** - 2025-05-09T18:22:03

On my way sorry


---

### 2393. msg_10123

**You** - 2025-05-09T18:22:24

Sok take your time if you want to hang with parents


---

### 2394. msg_10124

**You** - 2025-05-09T18:22:30

Totally understand


---

### 2395. msg_10125

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T03:43:48

2 min away


---

### 2396. msg_10126

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T03:44:19

I think you should go? Even at least for maddie?? I can go to my parents?


---

### 2397. msg_10127

**You** - 2025-05-10T14:19:36

Hope the drive back is/was ok


---

### 2398. msg_10128

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T14:22:54

Soooooo much traffic


---

### 2399. msg_10129

**You** - 2025-05-10T14:23:20

That sucks\.\. does it look like drive back will be equally bad


---

### 2400. msg_10130

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T14:35:38

https://open\.spotify\.com/track/21IYMdzTrzSe191Cy5eMap?si=OE9sZcE0QPq6222KBljzPQ
A new favourite song I found a few days ago\.


---

### 2401. msg_10131

**You** - 2025-05-10T15:19:38

That is a pretty awesome song\.\. listened to it a few times,
Some stuff to relate
To


---

### 2402. msg_10132

**You** - 2025-05-10T17:14:05

You left little white hillfiger sockies here


---

### 2403. msg_10133

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:15:44

Whoops you can just toss them


---

### 2404. msg_10134

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:15:52

We have a million of them


---

### 2405. msg_10135

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:16:01

So I slept for 2 hrs


---

### 2406. msg_10136

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:16:02

lol


---

### 2407. msg_10137

**You** - 2025-05-10T17:16:03

Kk


---

### 2408. msg_10138

**You** - 2025-05-10T17:16:07

Me too


---

### 2409. msg_10139

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:16:11

Now I have to get up :\(


---

### 2410. msg_10140

**You** - 2025-05-10T17:16:18

I slept since my 3 pm


---

### 2411. msg_10141

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:16:26

Same


---

### 2412. msg_10142

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T17:17:18

I could sleep more but will have to get Maelle at work shortly and then drive back to the shwa\! Yaye\. Lol


---

### 2413. msg_10143

**You** - 2025-05-10T17:18:26

I had a bite then watched tv got a really bad stitch from moving a wierd way came in to listen to the song you sent kept mynfavs playing and passed out


---

### 2414. msg_10144

**You** - 2025-05-10T17:20:12

Maybe go to sleep early tonight and bounce out of here early to do hun tomorrow morning and work everything out a bit\.\. might he kind of nice


---

### 2415. msg_10145

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T18:24:36

Told the girls I’m going back to old jobs so I have more time for them\. Mac smirked and raised her eyebrows\.


---

### 2416. msg_10146

**You** - 2025-05-10T18:25:08

I think
Mac an I will get along well


---

### 2417. msg_10147

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T18:45:11

lol


---

### 2418. msg_10148

**You** - 2025-05-10T18:45:53

I hope tonight goes well for you hon\.


---

### 2419. msg_10149

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T18:48:42

Just arrived at park to meet others


---

### 2420. msg_10150

**You** - 2025-05-10T18:49:12

❤️


---

### 2421. msg_10151

**You** - 2025-05-10T18:49:38

You are pretty awesome for doing this your mother and family are so lucky


---

### 2422. msg_10152

**You** - 2025-05-10T19:04:38

Reaction: 😂 from Meredith Lamb
So I have had a very naughty weekend for food I am going to have to make up for it next week


---

### 2423. msg_10153

**You** - 2025-05-10T19:08:41

Reaction: ❤️ from Meredith Lamb
Also bumble kind of
Boring I think I need to find something else


---

### 2424. msg_10154

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T19:16:38

Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 2425. msg_10155

**You** - 2025-05-10T19:16:54

I deleted the app just so you know\.\. and my account\.\. very sad attempt to fill in something that really only you can fill in\.


---

### 2426. msg_10156

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T19:17:02

I have to make my video into a tik tok now


---

### 2427. msg_10157

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T19:17:24

>
D’aw ❤️


---

### 2428. msg_10158

**You** - 2025-05-10T19:17:42

Love you mer\.\. have fun


---

### 2429. msg_10159

**You** - 2025-05-10T19:19:56

Tell your mum Scottie wishes her a happy bday too\.\. tell her not to judge me too harshly lol… you a hard person not to want to be around\.


---

### 2430. msg_10160

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T19:22:18

lol I will tell her later\.


---

### 2431. msg_10161

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:07:03

Reaction: ❤️ from Scott Hicks
Opening all my drunken amazing shopping gifts lol

*1 attachment(s)*


---

### 2432. msg_10162

**You** - 2025-05-10T20:07:46

She looks really happy


---

### 2433. msg_10163

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:08:49

She is… very\. But only because I gave her a heads up lol


---

### 2434. msg_10164

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:08:58

No one figured it out and I didn’t tell anyone


---

### 2435. msg_10165

**You** - 2025-05-10T20:09:18

She genuinely acted
Surprised
In video\.\.
Good actress lol


---

### 2436. msg_10166

**You** - 2025-05-10T20:10:13

80 is a big year and she looks great\.\.  I am glad you were able
To do this\.\. these kinds
Of memories matter
Most\.


---

### 2437. msg_10167

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:28:14


*1 attachment(s)*


---

### 2438. msg_10168

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:28:39

I got her this book to work her brain lol


---

### 2439. msg_10169

**You** - 2025-05-10T20:28:56

I see where you get your smile from 😃


---

### 2440. msg_10170

**You** - 2025-05-10T20:29:20

Was your dad happy too


---

### 2441. msg_10171

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:32:46

Yes he’s having a great time


---

### 2442. msg_10172

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:33:28

Strong silent type\.

*1 attachment(s)*


---

### 2443. msg_10173

**You** - 2025-05-10T20:33:31

Awesome sounds like you nailed it ❤️


---

### 2444. msg_10174

**You** - 2025-05-10T20:34:06

He still looks happy


---

### 2445. msg_10175

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:34:55

She just read the\. She of the book out loud lol

*1 attachment(s)*


---

### 2446. msg_10176

**You** - 2025-05-10T20:35:55

Did you come up with all this yourself?


---

### 2447. msg_10177

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:38:33

Yes wed night when I was drinking and talking to you


---

### 2448. msg_10178

**You** - 2025-05-10T20:44:28

They are pretty brilliant\.\. and thoughtful and funny\.


---

### 2449. msg_10179

**You** - 2025-05-10T20:45:05

Sounds like you\.\. you are so notch more extra than me\.


---

### 2450. msg_10180

**You** - 2025-05-10T20:45:11

Much


---

### 2451. msg_10181

**You** - 2025-05-10T20:46:07

Reaction: ❤️ from Meredith Lamb
Next year maybe I can attend\.


---

### 2452. msg_10182

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T20:55:17

She liked the soft stuff I got her the best probably bc she is sick\. Got her soft lounge wear, pjs, blankets\. All in a smaller size bc she is small now and didn’t buy new clothes


---

### 2453. msg_10183

**You** - 2025-05-10T20:57:27

Quality of life and comfort\.\. but don’t kid yourself she just just like it because it is soft and functional\.\. she loves it because it is from yku most of all I think\.  And she likely appreciates that the most\.


---

### 2454. msg_10184

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T21:10:41

How are you doing? Not bored?


---

### 2455. msg_10185

**You** - 2025-05-10T21:11:34

Just laying in bed pretty content enjoying your updates\. Thinking about you etc\.


---

### 2456. msg_10186

**You** - 2025-05-10T21:12:02

Nothing is wrong I am fine\.😌


---

### 2457. msg_10187

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T21:12:55

Good\. I am sorry we can’t hang out


---

### 2458. msg_10188

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T21:13:01

But the home videos are coming out


---

### 2459. msg_10189

**You** - 2025-05-10T21:13:10

Don’t apologize enjoy your night


---

### 2460. msg_10190

**You** - 2025-05-10T21:13:34

I didn’t think you were going to be able to anyways too difficult


---

### 2461. msg_10191

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T21:17:36


*1 attachment(s)*


---

### 2462. msg_10192

**You** - 2025-05-10T21:18:12

lol oldie cute


---

### 2463. msg_10193

**Meredith Lamb \(\+14169386001\)** - 2025-05-10T23:33:29

Omg so tired I passed out\. I’m going to bed \(no one else is lol\) I love you \- hope your night has gone ok xo


---

