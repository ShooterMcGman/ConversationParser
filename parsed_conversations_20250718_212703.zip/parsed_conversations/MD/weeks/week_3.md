# Week 3: Conversation Messages

**Date Range:** 2025-04-27 to 2025-05-01  
**Total Messages:** 2426  
**Generated:** 2025-07-18 21:27:04

---

## 📊 Week Summary

- **Week Number:** 3
- **Messages:** 2426
- **Participants:** 2
- **Message Types:** outgoing, incoming, call-history

## 💬 Conversation Messages

### 1. msg_5329

**You** - 2025-04-27T03:24:48

Reaction: ❤️ from Meredith Lamb
It doesn’t know what it is talking about\.  That was simply the best night I have had in an immensely long time\.  And the only reason I can think of is that is because it was with you\.  I love you very much
Thank you for being with me tonight\.  Have a great
Sleep\.


---

### 2. msg_5330

**You** - 2025-04-27T08:12:18

Ok sightly hung over


---

### 3. msg_5331

**You** - 2025-04-27T08:12:26

😩


---

### 4. msg_5332

**You** - 2025-04-27T09:41:55

Still worth although I am sore I am really sorry if you are too\.


---

### 5. msg_5333

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:42:29

>
I feel like that is my fault\. Sorry lol\. I am also\.


---

### 6. msg_5334

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:43:04

Mac uber eats eh king donuts for coffee\. Lol waiting


---

### 7. msg_5335

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:43:09

\*dunkin


---

### 8. msg_5336

**You** - 2025-04-27T10:43:32

Ok out of shower\.\.  feeling good\.\. hydrated electrolytes in me\.\. so much better now\.


---

### 9. msg_5337

**You** - 2025-04-27T10:44:00

No way not
Your fault I wanted to drink with you I promised\.\. man of my word


---

### 10. msg_5338

**You** - 2025-04-27T10:44:11

Fireball was yummy


---

### 11. msg_5339

**You** - 2025-04-27T10:44:16

I will be having that again


---

### 12. msg_5340

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:44:19

lol


---

### 13. msg_5341

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:44:59

>
ChatGPT knows everything\. Will wait to see how this new reality unfolds…\.


---

### 14. msg_5342

**You** - 2025-04-27T10:45:00

Eesh lol


---

### 15. msg_5343

**You** - 2025-04-27T10:45:48

Reaction: 😵‍💫 from Meredith Lamb
I think we are going to have to take reality by the face and make it unfold the way we want it to a little bit\.


---

### 16. msg_5344

**You** - 2025-04-27T10:46:23

I had no coffee yesterday\.\. was very unsettling


---

### 17. msg_5345

**You** - 2025-04-27T10:46:33

I will get some o\. Way to Chatham


---

### 18. msg_5346

**You** - 2025-04-27T10:51:56

So you are here until what about 5 ish


---

### 19. msg_5347

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:57:42

Yeah\. They play at 3 and again at 4\. So we will likely leave 5\.30\-6 unless the games are delayed


---

### 20. msg_5348

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:57:56

She’s going to make me stop for stuff tho


---

### 21. msg_5349

**You** - 2025-04-27T10:58:01

Yeah I don’t think you make the dinner


---

### 22. msg_5350

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:58:01

\(Vape\)


---

### 23. msg_5351

**You** - 2025-04-27T10:58:08

It’s fine if you don’t


---

### 24. msg_5352

**You** - 2025-04-27T10:58:17

This is more important


---

### 25. msg_5353

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:58:19

>
I’m ok with this\. Less awkward\.


---

### 26. msg_5354

**You** - 2025-04-27T10:58:27

lol I knew you would be


---

### 27. msg_5355

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:58:56

😇


---

### 28. msg_5356

**You** - 2025-04-27T10:59:16

Can you pop up before noon?  Just to relax for a few before I check out at noon?


---

### 29. msg_5357

**You** - 2025-04-27T10:59:26

Or shit nm you have to pack


---

### 30. msg_5358

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T10:59:44

I haven’t gotten out of bed yet\. Waiting for my coffee\. One min away


---

### 31. msg_5359

**You** - 2025-04-27T11:00:08

ROFL all good either way I am just packing anyways


---

### 32. msg_5360

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:01:10

Mac is mad I haven’t packed


---

### 33. msg_5361

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:01:14

🙄


---

### 34. msg_5362

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:01:42

Can’t without coffee\. She just went to front desk to get it if you want to meet her lol


---

### 35. msg_5363

**You** - 2025-04-27T11:02:16

No that is ok


---

### 36. msg_5364

**You** - 2025-04-27T11:02:18

lol


---

### 37. msg_5365

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:11:00

If I can make the dinner I will go but I will keep you updated\.


---

### 38. msg_5366

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:11:32

Reaction: ❤️ from Scott Hicks
I feel like my head has a lot to process today so maybe no dinner would be better lol\. We will see


---

### 39. msg_5367

**You** - 2025-04-27T11:11:48

Seriously don’t worry about it\.\. people know you are here for volleyball I will tell them you messaged me that you wouldn’t be able to make it


---

### 40. msg_5368

**You** - 2025-04-27T11:12:16

It’s no biggy\.


---

### 41. msg_5369

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:12:49

Kk


---

### 42. msg_5370

**You** - 2025-04-27T11:14:19

>
I get it I am kind of processing too\.\. all in a good way mind you\.


---

### 43. msg_5371

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:14:46


*1 attachment(s)*


---

### 44. msg_5372

**You** - 2025-04-27T11:16:23

ROFL the dress


---

### 45. msg_5373

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:16:42

Mackenzie goes “why would she wear that to meet the parents??”


---

### 46. msg_5374

**You** - 2025-04-27T11:16:50

Heheh


---

### 47. msg_5375

**You** - 2025-04-27T11:17:00

Good question


---

### 48. msg_5376

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:17:06


*1 attachment(s)*


---

### 49. msg_5377

**You** - 2025-04-27T11:18:11

I mean that could be a fair conclusion some moms might be like that


---

### 50. msg_5378

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:18:30

Yeah it is but the dress didn’t help for sure lol


---

### 51. msg_5379

**You** - 2025-04-27T11:19:31

No omg it screams “your son is hitting this, and can you imagine all of the shit I am teaching him”\. Feel free
To share that lol


---

### 52. msg_5380

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:19:47

Haha


---

### 53. msg_5381

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:19:49

No


---

### 54. msg_5382

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:20:07

I told her she could be besties with the mom\. Prob same age


---

### 55. msg_5383

**You** - 2025-04-27T11:20:17

ROFL


---

### 56. msg_5384

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:21:03

k, some coffee consumed\. Time to get up and ready


---

### 57. msg_5385

**You** - 2025-04-27T11:21:32

Cool have fun I am almost done


---

### 58. msg_5386

**You** - 2025-04-27T11:53:17

Just got a slight extension beyond 12 I said I was almost done if I could get a bit more time\.\. I think they are busy now so they will pretty much say yes to anything


---

### 59. msg_5387

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:54:25

We are waiting for a cart and then all set


---

### 60. msg_5388

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:54:32

I’m feeling unwell lol


---

### 61. msg_5389

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:54:53

Not sure about the day drinking and night drinking yday while sick on mounjaro


---

### 62. msg_5390

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:54:58

Sighhhh lol


---

### 63. msg_5391

**You** - 2025-04-27T11:55:37

Sry I feel like I contributed to the night drinking for sure


---

### 64. msg_5392

**You** - 2025-04-27T11:55:52

And had you up too late


---

### 65. msg_5393

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:55:58

We got an extension until the cart comes


---

### 66. msg_5394

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:56:07

Omg the 3am nights at 47


---

### 67. msg_5395

**You** - 2025-04-27T11:56:15

Yeah I know


---

### 68. msg_5396

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:56:17

It’s fine\. I kind of got to sleep in


---

### 69. msg_5397

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:56:28

Until Mac disrupted


---

### 70. msg_5398

**You** - 2025-04-27T11:57:08

Reaction: ❤️ from Meredith Lamb
And still being able to do stuff at 3 am at 47\.\. happy\.


---

### 71. msg_5399

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T11:57:49

Shit keeps getting realERRRR


---

### 72. msg_5400

**You** - 2025-04-27T11:59:10

I very much enjoyed it\.  I was worried though I hope you were ok with what happened I thought you might ya know regret
In the morning\.


---

### 73. msg_5401

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T12:01:09

No regrets but my prior concern remains lol


---

### 74. msg_5402

**You** - 2025-04-27T12:01:45

Stating the for the record are you lol


---

### 75. msg_5403

**You** - 2025-04-27T12:03:24

Keeping this also for the memory


---

### 76. msg_5404

**You** - 2025-04-27T12:03:28

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 77. msg_5405

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T12:08:31

So Detroit is our place now


---

### 78. msg_5406

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T12:08:33

lol


---

### 79. msg_5407

**You** - 2025-04-27T12:09:29

I feel like it is yeah


---

### 80. msg_5408

**You** - 2025-04-27T12:09:38

Good news for Lori\.


---

### 81. msg_5409

**You** - 2025-04-27T12:19:21

Ok I am pretty
Much done about to head out assuming you still waiting on cart lol


---

### 82. msg_5410

**You** - 2025-04-27T12:29:47

Ok here is the deal you might have left so this will be moot\.  But if Mac wants to see who I am I am taking my stuff down to the lobby I think there are places to sit down there\.\. I am going to find a spot and read my iPad for a few mins\.
Then leave\.


---

### 83. msg_5411

**You** - 2025-04-27T12:42:47

You guys must be go a already


---

### 84. msg_5412

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T12:48:34

Sorry yeah we left\! Lol Mac took me to the hood to a vape store


---

### 85. msg_5413

**You** - 2025-04-27T12:50:01

ROFL ok well I wasn’t in a hurry anyways relaxing here reading emails


---

### 86. msg_5414

**You** - 2025-04-27T12:50:31

Reaction: 😂 from Meredith Lamb
Might I make a suggestion


---

### 87. msg_5415

**You** - 2025-04-27T12:52:07

For the vaping when I quite
It was using a fake vape or e cigarette no nicotine just the smoke and a nic patch it
Might work for her\.\. side effect she gains back a bit of healthy weight\.  I think like smoking vaping curbs your appetite S another side effect


---

### 88. msg_5416

**You** - 2025-04-27T12:52:17

I know I gained 20 lbs when I wuit


---

### 89. msg_5417

**You** - 2025-04-27T12:54:46

See now it feels weird


---

### 90. msg_5418

**You** - 2025-04-27T12:55:37

Before I would have no problem making a suggestion re Mac\. lol now I am anxious\.\. what if I suggest the wrong thing etc\.\. heheh


---

### 91. msg_5419

**You** - 2025-04-27T12:56:03

Ok heading to car getting I\. Road\.\. will check in on how your day is going\.


---

### 92. msg_5420

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:24:08

At the venue and I get to sit around and wait until 3\. Forgot to bring my laptop in and we valeted parking god…\.


---

### 93. msg_5421

**You** - 2025-04-27T13:24:48

That sucks… it’s ok I will work on it when I get to hotel I suspect I will be at hotel
Working before the game starts


---

### 94. msg_5422

**You** - 2025-04-27T13:24:53

Super fun for you


---

### 95. msg_5423

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:25:02

I’m going to have a nap lol


---

### 96. msg_5424

**You** - 2025-04-27T13:25:18

Did you want anything at duty free shop getting gas and it is right here


---

### 97. msg_5425

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:25:34

Nope all good\. No more drinking\.


---

### 98. msg_5426

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:25:38

lol


---

### 99. msg_5427

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:25:46

Gotta be good around Michelle


---

### 100. msg_5428

**You** - 2025-04-27T13:29:37

Rofl


---

### 101. msg_5429

**You** - 2025-04-27T13:29:48

Apparently I shouldn’t have invited her


---

### 102. msg_5430

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:34:35

lol


---

### 103. msg_5431

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:34:47

She’s scary


---

### 104. msg_5432

**You** - 2025-04-27T13:53:59

Well that was a little expensive stopped in called j and the kids to see what they wanted spent 300 like how… I was just like going to get something small lol


---

### 105. msg_5433

**You** - 2025-04-27T13:54:06

Next
Time not calling


---

### 106. msg_5434

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:54:44

lol still under our target bill so you are fine lol


---

### 107. msg_5435

**You** - 2025-04-27T13:54:55

Yeah that was
Silly rofl


---

### 108. msg_5436

**You** - 2025-04-27T13:57:48

Thought you were napping


---

### 109. msg_5437

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:58:43

Impossible here I think


---

### 110. msg_5438

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T13:58:58

Also hungry but too lazy to go get something\. Going to soon


---

### 111. msg_5439

**You** - 2025-04-27T14:00:23

Ur going to be in a good mood later


---

### 112. msg_5440

**You** - 2025-04-27T14:00:25

lol


---

### 113. msg_5441

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:01:55

There is never any time to nap\. That is the problem\. Just like a 20 min Power Nap


---

### 114. msg_5442

**You** - 2025-04-27T14:02:46

That sucks… I don’t nap much since I had my apnea fixed


---

### 115. msg_5443

**You** - 2025-04-27T14:02:52

But I used to like it


---

### 116. msg_5444

**You** - 2025-04-27T14:04:26

I could take a nap right now though bit of a line to get into Canada


---

### 117. msg_5445

**You** - 2025-04-27T14:09:45

Back in Canada\!\! The border guard had a Morgan wallen mustache \#jealous


---

### 118. msg_5446

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:20:29

lol


---

### 119. msg_5447

**You** - 2025-04-27T14:27:25

So they playing 3 games no matter what or do they need to win to advance


---

### 120. msg_5448

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:27:40

2 games


---

### 121. msg_5449

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:27:48

For sure


---

### 122. msg_5450

**You** - 2025-04-27T14:32:14

How is your stomach


---

### 123. msg_5451

**You** - 2025-04-27T14:32:22

Feeling ok or still really bad


---

### 124. msg_5452

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:35:49

I ate some real nonkid grilled cheese food and having a smoothie so feeling better


---

### 125. msg_5453

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:39:42

Stomach is ok \(not Perf\) but my head is messing with me 🤔


---

### 126. msg_5454

**You** - 2025-04-27T14:43:11

What is wrong with your head


---

### 127. msg_5455

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:47:27

It’s asking me so many things while also telling me so many things…\.


---

### 128. msg_5456

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:47:38

It’s annoying me


---

### 129. msg_5457

**You** - 2025-04-27T14:48:47

Like what…\.\.


---

### 130. msg_5458

**You** - 2025-04-27T14:49:03

As a good friend of mine would say\.


---

### 131. msg_5459

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:49:12

lol


---

### 132. msg_5460

**You** - 2025-04-27T14:49:28

You are that you know\.


---

### 133. msg_5461

**You** - 2025-04-27T14:49:40

I do see you that way


---

### 134. msg_5462

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:49:52

You see me as a good friend


---

### 135. msg_5463

**You** - 2025-04-27T14:49:59

In addition


---

### 136. msg_5464

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:50:00

Or annoying


---

### 137. msg_5465

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:50:03

lol


---

### 138. msg_5466

**You** - 2025-04-27T14:50:11

No kk


---

### 139. msg_5467

**You** - 2025-04-27T14:50:24

Not annoying


---

### 140. msg_5468

**You** - 2025-04-27T14:50:45

I like seeing you as a friend as well as everything else


---

### 141. msg_5469

**You** - 2025-04-27T14:51:03

So what is your head asking and telling


---

### 142. msg_5470

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:53:10

Basic stuff: “What the f are you doing Meredith? Why are you so ocd about this? You aren’t focusing on your separation stuff\. You aren’t focusing on WORK\. Now you have gone and made things even MORE complicated\. Etc etc etc” \(it goes on and on and won’t stop\)


---

### 143. msg_5471

**You** - 2025-04-27T14:54:23

I’m sorry mer\.\. I can back off if you want\.\. for a bit\. Let you focus
I would def do that for you\.


---

### 144. msg_5472

**You** - 2025-04-27T14:55:02

I want to be part of making your life better not worse


---

### 145. msg_5473

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:56:24

>
No, this is impossible at this point\.  But you realize after this weekend we probably won’t spend time together for so long\.


---

### 146. msg_5474

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T14:57:00

And you won’t be off at war\. You will literally be right in front of my face everyday\. Lol


---

### 147. msg_5475

**You** - 2025-04-27T14:57:51



---

### 148. msg_5476

**You** - 2025-04-27T14:58:21

Sec


---

### 149. msg_5477

**You** - 2025-04-27T15:00:58

I mean I know that was why I wanted to try to spend as much time as I could with you these few days\.  And honestly it
Felt amazing\.\. it felt easy I was so much less self
Conscious around you everything for me was perfect\.\. I can focus on that as my motivation to get
Moving faster


---

### 150. msg_5478

**You** - 2025-04-27T15:01:31

Like moving my separation along\.  Just
Got
To hotel\.


---

### 151. msg_5479

**You** - 2025-04-27T15:02:23

Anyhow for me this weekend was amazing and I very
Much appreciated
The opportunity had we not
Taken it it
Would be that much longer


---

### 152. msg_5480

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:03:03

Well I’m glad to read that\. That helps a bit\.


---

### 153. msg_5481

**You** - 2025-04-27T15:03:22

Which part exactly lol


---

### 154. msg_5482

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:03:48

All of it


---

### 155. msg_5483

**You** - 2025-04-27T15:04:00

Anyhow think about what you need to get through this mer I will do whatever you want


---

### 156. msg_5484

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:04:53

Will try to get out of my head a bit…


---

### 157. msg_5485

**You** - 2025-04-27T15:05:28

Reaction: ❤️ from Meredith Lamb
We can talk later
Tonight if
You would
Like whatever I can do\.
Just
Going to check in and get
To my room


---

### 158. msg_5486

**You** - 2025-04-27T15:05:55

Love you\.


---

### 159. msg_5487

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:06:47

Love u too and want to see you again\. Gah\. Delayed here again\. Not started yet


---

### 160. msg_5488

**You** - 2025-04-27T15:17:03

Ummmmmmm soooooooo


---

### 161. msg_5489

**You** - 2025-04-27T15:17:06

I checked in


---

### 162. msg_5490

**You** - 2025-04-27T15:17:16

Thankfully by myself


---

### 163. msg_5491

**You** - 2025-04-27T15:17:31

Reaction: 😮 from Meredith Lamb
The girl read the notation in my file\.


---

### 164. msg_5492

**You** - 2025-04-27T15:17:38

I was like Jesus


---

### 165. msg_5493

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:17:40

So jealous you can nap


---

### 166. msg_5494

**You** - 2025-04-27T15:17:40

lol


---

### 167. msg_5495

**You** - 2025-04-27T15:17:50

You are literally next door


---

### 168. msg_5496

**You** - 2025-04-27T15:18:06

At the end of a small hallway


---

### 169. msg_5497

**You** - 2025-04-27T15:19:52

I think there are 2 rooms it could be but they suggested
You were next door lol so don’t check in when anyone else is around\. I just said in the vacinity of because we work
Together


---

### 170. msg_5498

**You** - 2025-04-27T15:19:58

Not next door lol


---

### 171. msg_5499

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:20:11

>
So this will be interesting with Mac


---

### 172. msg_5500

**You** - 2025-04-27T15:20:21

Ya think


---

### 173. msg_5501

**You** - 2025-04-27T15:20:35

I am hiding in here for the full 2 days


---

### 174. msg_5502

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:21:06

I mean all day meeting


---

### 175. msg_5503

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:21:11

lol


---

### 176. msg_5504

**You** - 2025-04-27T15:21:20

Eeesh


---

### 177. msg_5505

**You** - 2025-04-27T15:21:35

Too sick
To come don’t want people
To catch\.\.


---

### 178. msg_5506

**You** - 2025-04-27T15:21:41

Yeah going with that


---

### 179. msg_5507

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:21:53

I think that should be me not you


---

### 180. msg_5508

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:22:16

Omg warming up finally


---

### 181. msg_5509

**You** - 2025-04-27T15:22:55

What should be on you


---

### 182. msg_5510

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:23:14

I should be the sick one


---

### 183. msg_5511

**You** - 2025-04-27T15:23:22

Well you still might be


---

### 184. msg_5512

**You** - 2025-04-27T15:23:26

Who knows


---

### 185. msg_5513

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:25:27

This meeting was such a great idea


---

### 186. msg_5514

**You** - 2025-04-27T15:25:53

Sarcasm?


---

### 187. msg_5515

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:26:04

lol yep


---

### 188. msg_5516

**You** - 2025-04-27T15:26:24

I mean originally it
Gave me
The excuse
To go
To Detroit\.


---

### 189. msg_5517

**You** - 2025-04-27T15:26:39

Me going to Detroit was your idea


---

### 190. msg_5518

**You** - 2025-04-27T15:26:51

So technically so was the meeting\.


---

### 191. msg_5519

**You** - 2025-04-27T15:26:54

😝


---

### 192. msg_5520

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:27:17

I’m not sure all those dots connect\.


---

### 193. msg_5521

**You** - 2025-04-27T15:27:28

I feel like they should


---

### 194. msg_5522

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:27:34

You talked about the meeting before you knew about Detroit


---

### 195. msg_5523

**You** - 2025-04-27T15:27:42

Not the date


---

### 196. msg_5524

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:27:46

>
lol k, but they don’t


---

### 197. msg_5525

**You** - 2025-04-27T15:28:16

Maybe I was a little
Ambitious\.


---

### 198. msg_5526

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:29:19

Can’t stay up until 3 tonight


---

### 199. msg_5527

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:29:25

I will die tomorrow


---

### 200. msg_5528

**You** - 2025-04-27T15:31:24

Reaction: 😂 from Meredith Lamb
How about 2:30


---

### 201. msg_5529

**You** - 2025-04-27T15:31:39

Reaction: 👍 from Meredith Lamb
Maybe 1 would be better


---

### 202. msg_5530

**You** - 2025-04-27T15:31:48

lol


---

### 203. msg_5531

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:32:02

>
No


---

### 204. msg_5532

**You** - 2025-04-27T15:32:53

1 is good we can watch a few episodes of wrexham\.


---

### 205. msg_5533

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:33:18

We have been watching movies and tv so well together


---

### 206. msg_5534

**You** - 2025-04-27T15:33:31

I know but there is a couch here


---

### 207. msg_5535

**You** - 2025-04-27T15:33:43

Easier to behave perhaps?


---

### 208. msg_5536

**You** - 2025-04-27T15:34:37

Or……


---

### 209. msg_5537

**You** - 2025-04-27T15:34:43

lol


---

### 210. msg_5538

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T15:35:56

Reaction: ❤️ from Scott Hicks
We’ll see … if this game ever freaking starts and I get out of here


---

### 211. msg_5539

**You** - 2025-04-27T16:06:37

How is game


---

### 212. msg_5540

**You** - 2025-04-27T16:11:02

Also random question would you ever consider moving back to Chatham someday?


---

### 213. msg_5541

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:14:20

Lost first one\. Warming up now for second


---

### 214. msg_5542

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:14:41

>
I never lived in Chatham


---

### 215. msg_5543

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:14:54

I just worked there


---

### 216. msg_5544

**You** - 2025-04-27T16:16:43

I like it here


---

### 217. msg_5545

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:17:17

Are you not just in the hotel? Lol


---

### 218. msg_5546

**You** - 2025-04-27T16:17:41

Nope


---

### 219. msg_5547

**You** - 2025-04-27T16:17:44

I went to Best Buy


---

### 220. msg_5548

**You** - 2025-04-27T16:17:57

And then I need a snack before supper


---

### 221. msg_5549

**You** - 2025-04-27T16:18:05

Because damn I am hungry


---

### 222. msg_5550

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:20:31

Ahhh Chatham is OK


---

### 223. msg_5551

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:20:55

Not sure I’d ever live in Chatham\. A bunch of better places


---

### 224. msg_5552

**You** - 2025-04-27T16:20:56

I guess anything but Toronto\.\.  I just thought I could work out of Chatham


---

### 225. msg_5553

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:21:15

Better places within driving distance


---

### 226. msg_5554

**You** - 2025-04-27T16:21:30

I mean if j went back to Moncton\. I would think of transferring to Chatham


---

### 227. msg_5555

**You** - 2025-04-27T16:21:44

Would be much easier for me to afford


---

### 228. msg_5556

**You** - 2025-04-27T16:22:02

Eventually


---

### 229. msg_5557

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:22:05

Or you could just move in with me


---

### 230. msg_5558

**You** - 2025-04-27T16:22:15

Yeah I could do that\.


---

### 231. msg_5559

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:22:31

🙂


---

### 232. msg_5560

**You** - 2025-04-27T16:22:40

Still I don’t think your kids or Andrew would be happy


---

### 233. msg_5561

**You** - 2025-04-27T16:22:50

lol


---

### 234. msg_5562

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:23:41

Andrew doesn’t have a say\. My kids would be fine


---

### 235. msg_5563

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:24:27

Besides I wouldn’t tell Andrew lol


---

### 236. msg_5564

**You** - 2025-04-27T16:24:32

Well I would want everything absolutely rock solid and finalized with J so it would be a little ways out and would need another job at
Enbridge\.


---

### 237. msg_5565

**You** - 2025-04-27T16:24:42

But yeah like I said


---

### 238. msg_5566

**You** - 2025-04-27T16:24:51

It felt so easy with you\.\. I don’t think that changes


---

### 239. msg_5567

**You** - 2025-04-27T16:25:13

We aren’t putting in airs for each other we are mid 40s we take each other as we are


---

### 240. msg_5568

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:25:15

Why did you think it would feel different?


---

### 241. msg_5569

**You** - 2025-04-27T16:25:51

I didn’t know what to expect\.\. I hadn’t spent time like that with anyone else in 25 years\.


---

### 242. msg_5570

**You** - 2025-04-27T16:26:09

I figured it would be good if for no other reason than I know what you are like at work


---

### 243. msg_5571

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:27:09

But you didn’t think it would feel “easy”?


---

### 244. msg_5572

**You** - 2025-04-27T16:28:31

I didn’t know I don’t want to disappoint you\.\. I have my idiosyncratic ways\. So lol I just
Didnt assume


---

### 245. msg_5573

**You** - 2025-04-27T16:28:57

I figured I would be the one to annoy you not the other way around


---

### 246. msg_5574

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:29:48

If I thought you were annoying in any way we would not be talking right now lol trust me


---

### 247. msg_5575

**You** - 2025-04-27T16:31:28

See that is scary lol you don’t see it though\.  The way I read that is \- if I were to find something about you annoying……
Fill in blank\. lol\. Your mind does it’s wacky things mine does my own foolishness


---

### 248. msg_5576

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:32:26

Fill in the blank?


---

### 249. msg_5577

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:32:46

Huh? Like you think I would hide it if I was annoyed by you?


---

### 250. msg_5578

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:32:56

I’m not at that stage in my life


---

### 251. msg_5579

**You** - 2025-04-27T16:33:06

O but you could


---

### 252. msg_5580

**You** - 2025-04-27T16:33:09

In the future


---

### 253. msg_5581

**You** - 2025-04-27T16:33:15

Find something annoying


---

### 254. msg_5582

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:33:25

Oh I’m sure I will at some point


---

### 255. msg_5583

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:33:30

But it will be minor


---

### 256. msg_5584

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:33:47

Relative to who you are generally and who I am in love with


---

### 257. msg_5585

**You** - 2025-04-27T16:34:55

I haven’t tired to be someone I am not with you so there is that


---

### 258. msg_5586

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:36:11

I’ve known you for a while now\. Pretty confident in my feelings


---

### 259. msg_5587

**You** - 2025-04-27T16:36:59

Kk well it did feel good
And easy and i would love to live with you when we sort our shit out\.


---

### 260. msg_5588

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:37:29

2 years


---

### 261. msg_5589

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:37:38

😜


---

### 262. msg_5590

**You** - 2025-04-27T16:38:34

Reaction: ❤️ from Meredith Lamb
Mmmm maybe a little sooner but 1 for sure


---

### 263. msg_5591

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:41:56

Would never guessed 2 months ago that you would be saying that lol


---

### 264. msg_5592

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:41:59

How things change


---

### 265. msg_5593

**You** - 2025-04-27T16:42:03

Nope


---

### 266. msg_5594

**You** - 2025-04-27T16:42:08

But this isn’t normal


---

### 267. msg_5595

**You** - 2025-04-27T16:42:23

This is the exception


---

### 268. msg_5596

**You** - 2025-04-27T16:42:31

Like way out there


---

### 269. msg_5597

**You** - 2025-04-27T16:46:08

I mean that is why it is special I have never
Heard of
This happening to anyone else\. Everything had to happen just as it did for this to work out the way it did\.  As I have said before I feel incredibly lucky\.


---

### 270. msg_5598

**You** - 2025-04-27T16:46:28

How are
Girls doing winning or losing?


---

### 271. msg_5599

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:46:49

Just won first set of second game


---

### 272. msg_5600

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:47:03

Marlowe’s team in Ottawa won their first game today


---

### 273. msg_5601

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:47:24

Ugh I’m so ready to leave\.


---

### 274. msg_5602

**You** - 2025-04-27T16:47:40

Nice


---

### 275. msg_5603

**You** - 2025-04-27T16:47:52

lol I bet you are


---

### 276. msg_5604

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:48:57

Got my hair clipped by a random lol

*1 attachment(s)*


---

### 277. msg_5605

**You** - 2025-04-27T16:56:26

Rofl


---

### 278. msg_5606

**You** - 2025-04-27T16:56:32

That is awesome


---

### 279. msg_5607

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:57:18

Marlowe loves them\. The younger kids do it a lot


---

### 280. msg_5608

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:57:31


*1 attachment(s)*


---

### 281. msg_5609

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:57:42

Marlowe just sent me hers so far lol


---

### 282. msg_5610

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T16:59:49

https://youtube\.com/watch?v=tCM44SrLC5A&feature=shared


---

### 283. msg_5611

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:00:10

https://youtube\.com/watch?v=stNHqsxzqzo&feature=shared


---

### 284. msg_5612

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:03:05

I just thought of something\. This is probably the last volleyball game I will watch Mac play ever\.


---

### 285. msg_5613

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:08:23

Omg going to third set\.


---

### 286. msg_5614

**You** - 2025-04-27T17:14:18

I was going to say something g to you earlier about enjoying what is right in front of you\.  I felt same way\.\. it
Drove me crazy running all over the fucking place for basketball but I missed it when it was gone


---

### 287. msg_5615

**You** - 2025-04-27T17:14:32

It’s a connection you and Mac have\.\.


---

### 288. msg_5616

**You** - 2025-04-27T17:14:49

Watching the video
You sent


---

### 289. msg_5617

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:15:37

Reaction: ❤️ from Scott Hicks
I got a good photo of her on her last game I will see

*1 attachment(s)*


---

### 290. msg_5618

**You** - 2025-04-27T17:16:40

>
It might not be you never know


---

### 291. msg_5619

**You** - 2025-04-27T17:17:11

You should write a blog about it


---

### 292. msg_5620

**You** - 2025-04-27T17:17:22

Maybe getting back into that would help deal with some shit


---

### 293. msg_5621

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:22:00

Errrr no\.


---

### 294. msg_5622

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:22:03

lol


---

### 295. msg_5623

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:22:15

I don’t need another distraction


---

### 296. msg_5624

**You** - 2025-04-27T17:23:29

Well store up your shit and let it out later\.\. you need some kind of release mer you are carrying a lot\.


---

### 297. msg_5625

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:26:13

Ok they finally won a game lol


---

### 298. msg_5626

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:26:20

Ridiculous tournament


---

### 299. msg_5627

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:26:34

I get to leave now 🎉🎉🎉🎉🎉


---

### 300. msg_5628

**You** - 2025-04-27T17:36:04

Yay I mean remember do not check in with anyone from the team around\. Lol


---

### 301. msg_5629

**You** - 2025-04-27T17:36:28

If you don’t see anyone should I tell them you couldn’t come?


---

### 302. msg_5630

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:46:23

Omg tire pressure was low\. Like can this day end already lol

*1 attachment(s)*


---

### 303. msg_5631

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:46:43

>
Huh?


---

### 304. msg_5632

**You** - 2025-04-27T17:47:14

I am asking if you are coming to dinner\.


---

### 305. msg_5633

**You** - 2025-04-27T17:47:48

Man that sucks about tires


---

### 306. msg_5634

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:49:01

>
I will let you know in an hour


---

### 307. msg_5635

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:49:08

Dinner is 8 right


---

### 308. msg_5636

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T17:50:48

Shouldn’t I get ready for tomorrow lol


---

### 309. msg_5637

**You** - 2025-04-27T17:51:31

I would be supportive of that\.


---

### 310. msg_5638

**You** - 2025-04-27T17:51:34

lol


---

### 311. msg_5639

**You** - 2025-04-27T17:51:37

Your call though


---

### 312. msg_5640

**You** - 2025-04-27T17:52:25

>
Pinging this again last time\.\. lol\.\. careful right


---

### 313. msg_5641

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T18:02:34

>
Thanks\. Like wtf\. What do I do if someone is there\. Geeeez


---

### 314. msg_5642

**You** - 2025-04-27T18:05:07

Um I feel like you will be creative\.


---

### 315. msg_5643

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T18:17:12

Border is so slow\. Dinner looking unlikely


---

### 316. msg_5644

**You** - 2025-04-27T18:26:43

Yeah I totally feel you


---

### 317. msg_5645

**You** - 2025-04-27T18:45:14

How goes the progress


---

### 318. msg_5646

**You** - 2025-04-27T18:45:47

I think everyone is going to arrive at the same time I bet


---

### 319. msg_5647

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T18:52:03

Will arrive at 7\.20


---

### 320. msg_5648

**You** - 2025-04-27T18:53:08

Ah ok well I will still be in my room working away


---

### 321. msg_5649

**You** - 2025-04-27T18:53:36

I left the bolt on my door over if you wanted to say hello\.


---

### 322. msg_5650

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:06:25

Stopping for gas and caffeine


---

### 323. msg_5651

**You** - 2025-04-27T19:08:30

Cote going to be late 8:20 going straight to restaurant


---

### 324. msg_5652

**You** - 2025-04-27T19:08:36

Carolyn and Louise
Already here


---

### 325. msg_5653

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:08:56

I will go to dinner if I can have one glass of wine


---

### 326. msg_5654

**You** - 2025-04-27T19:08:58

Not sure about rest I tried calling Deanna and Sarah they might be caught I\. Traffic as well


---

### 327. msg_5655

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:08:59

lol


---

### 328. msg_5656

**You** - 2025-04-27T19:09:10

Rofl you can have many glasses
Of wine


---

### 329. msg_5657

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:09:14

No


---

### 330. msg_5658

**You** - 2025-04-27T19:09:16

And I will sit far away from you


---

### 331. msg_5659

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:09:19

Absolutely not


---

### 332. msg_5660

**You** - 2025-04-27T19:09:20

And ignore you


---

### 333. msg_5661

**You** - 2025-04-27T19:09:49

There is a corkscrew in my kitchen ete


---

### 334. msg_5662

**You** - 2025-04-27T19:09:55

lol


---

### 335. msg_5663

**You** - 2025-04-27T19:10:05

I think I have a taste for Pinot now\.


---

### 336. msg_5664

**You** - 2025-04-27T19:10:09

Uh oh


---

### 337. msg_5665

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:11:12

No drinking tonight


---

### 338. msg_5666

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:11:49

What restaurant again?


---

### 339. msg_5667

**You** - 2025-04-27T19:12:59

Mamma marias


---

### 340. msg_5668

**You** - 2025-04-27T19:13:03

Shots?


---

### 341. msg_5669

**You** - 2025-04-27T19:13:08

Fireball\!\!


---

### 342. msg_5670

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:13:13

>
Are you sure?


---

### 343. msg_5671

**You** - 2025-04-27T19:13:18

I am sure


---

### 344. msg_5672

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T19:13:21

I thought it closed early


---

### 345. msg_5673

**You** - 2025-04-27T19:13:29

Nope cote booked it


---

### 346. msg_5674

**You** - 2025-04-27T19:13:52

But as I said she called me and is going to be quite late


---

### 347. msg_5675

**You** - 2025-04-27T19:24:32

You getting close… was just going to run down to desk to get some more coffee\.\. just making sure lol


---

### 348. msg_5676

**You** - 2025-04-27T19:24:45

Like to avoid lol


---

### 349. msg_5677

**You** - 2025-04-27T19:26:53

I have a balcony\!\! Awesome


---

### 350. msg_5678

**You** - 2025-04-27T19:33:02

Made the dash I am all stocked up


---

### 351. msg_5679

**You** - 2025-04-27T19:39:06

I see you


---

### 352. msg_5680

**You** - 2025-04-27T22:06:23

Not sure if and or you planned on coming over but I just need 15
Minutes if so have to call Gracie\.


---

### 353. msg_5681

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:09:54

I’m having a shower and getting my laptop on\. :p Just let me know\.


---

### 354. msg_5682

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:10:12

I will come\. I know where Carolyn’s room is so should be fine


---

### 355. msg_5683

**You** - 2025-04-27T22:11:39

Ok listen I am going to grab a quick shower too I will leave the bolt Orr so you can just come in whenever


---

### 356. msg_5684

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:12:33

Marlowe’s team went 3\-0 today\. Just learned


---

### 357. msg_5685

**You** - 2025-04-27T22:13:13

Nice good for her\!\!


---

### 358. msg_5686

**You** - 2025-04-27T22:38:06

I am out


---

### 359. msg_5687

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:39:11

What is the room number again


---

### 360. msg_5688

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:39:23

Be weird if I went to the wrong room


---

### 361. msg_5689

**You** - 2025-04-27T22:39:50

206


---

### 362. msg_5690

**You** - 2025-04-27T22:40:22

Thought you were 205


---

### 363. msg_5691

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:41:23

No 203


---

### 364. msg_5692

**You** - 2025-04-27T22:41:38

Is Carolyn 205


---

### 365. msg_5693

**You** - 2025-04-27T22:41:40

lol


---

### 366. msg_5694

**Meredith Lamb \(\+14169386001\)** - 2025-04-27T22:42:11

Um yes


---

### 367. msg_5695

**You** - 2025-04-28T01:35:35

All safe?


---

### 368. msg_5696

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T01:35:49

Oh right forgot\. Yes\! Lol


---

### 369. msg_5697

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T01:36:40

All Mackenzie said was “bruh”…


---

### 370. msg_5698

**You** - 2025-04-28T01:37:08

Rofl


---

### 371. msg_5699

**You** - 2025-04-28T01:37:34

Have a good sleep chat in morning


---

### 372. msg_5700

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T01:38:08

💕


---

### 373. msg_5701

**You** - 2025-04-28T06:37:38

Morning sunshine boy did I pass out hard oof hope today goes ok I know it isn’t going to be a ton of fun\.


---

### 374. msg_5702

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T06:48:00

Morning xo Omg my throat…… swear to god\.


---

### 375. msg_5703

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T06:50:01

Throat so intense\. Like last night 😋


---

### 376. msg_5704

**You** - 2025-04-28T06:57:33

Rofl this the best and the most insane I think I have ever felt\.  Man\.\. well I am up and grabbing a shower and then something from downstairs likely a coffee\.  Anything you want or need?  Really sorry about throat I have more losanges\.


---

### 377. msg_5705

**You** - 2025-04-28T06:57:42

Or Advil cold


---

### 378. msg_5706

**You** - 2025-04-28T06:58:13

I have vitamin c packets vitamin d and zinc that is supposed to help lessen and ouch back on symptoms\.


---

### 379. msg_5707

**You** - 2025-04-28T06:59:09

Reaction: 😂 from Meredith Lamb
Now crossing fingers that I dot t have an awkward conversation with Carolyn this morning\.


---

### 380. msg_5708

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T07:06:33

I’m ok thanks\. You and your pharmacy\. Lol


---

### 381. msg_5709

**You** - 2025-04-28T07:09:58

Btw I do want to chat
Sometime about stuff making you happy and what I can do\.  Again 47 seems to take away any reservations about talking about certain topics\.


---

### 382. msg_5710

**You** - 2025-04-28T07:10:10

Btw talking with Carolyn now on teams\.


---

### 383. msg_5711

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T07:18:20

Someone is listening to metal music near me or foo fighters maybe? You don’t hear that?


---

### 384. msg_5712

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T07:20:15

>
Of course, we have lots of time \(2 yrs :p\)\. Please know you make me so happy\. The feel of you, the taste …\. It’s really wild\. I will think about it all day and it will be super awkward\. lol


---

### 385. msg_5713

**You** - 2025-04-28T07:25:36

I don’t hear anything, and I appreciate the sentiment\.\.
Pretty much everything about you drives me nuts… especially the kissing which is why I say I don’t think that will ever get old\.\. feels more intimate for some reason\. Yeah we can talk about other stuff, but I am glad you feel that way because I do too\.


---

### 386. msg_5714

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T07:32:07

Reaction: ❤️ from Scott Hicks
Same, I am at ease the minute I’m in the same room with you\. The connection we have makes everything a little haywire\. In a good way\. 💋


---

### 387. msg_5715

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T07:50:22

Girl that bought our home\. Grew up with her so I get to see photos a lot\.

*1 attachment(s)*


---

### 388. msg_5716

**You** - 2025-04-28T08:00:26

That’s really nice you can tell you have a deep connection to your hometown\.\. I would really like to go there with you\.  Just walk around and listen to you tell me stories\.\. ☺️\. You can tell they mean a lot to you when you relive them for me\.


---

### 389. msg_5717

**You** - 2025-04-28T08:01:06

I thought your screenshot was beautiful\. Can imagine what the rest is like\.


---

### 390. msg_5718

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:02:29

For the record I am incredible freezing and achy\. Full out cold\. Lol this is hilarious … 2 days and boom\. Science, wow\.


---

### 391. msg_5719

**You** - 2025-04-28T08:03:30

Just stay home call in remotely


---

### 392. msg_5720

**You** - 2025-04-28T08:03:36

Seriously


---

### 393. msg_5721

**You** - 2025-04-28T08:04:21

If it is hitting you that hard\.\. I mean I eat 3 Advil extra str
Every six hours to kick the shit out of this and two packs kf extreme c per day/


---

### 394. msg_5722

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:05:08

I have a low immune system right now\. Stress and “stuff” lol


---

### 395. msg_5723

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:05:59

Are you in your room


---

### 396. msg_5724

**You** - 2025-04-28T08:06:11

Yeah I am totally to blame my immune system is pretty solid on the worst of days\.


---

### 397. msg_5725

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:06:38

The iron is missing from this room


---

### 398. msg_5726

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:06:40

Argh


---

### 399. msg_5727

**You** - 2025-04-28T08:11:16

I have one here already heated up


---

### 400. msg_5728

**You** - 2025-04-28T08:11:24

Should I bring it over


---

### 401. msg_5729

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:11:31

You could put it outside my door


---

### 402. msg_5730

**You** - 2025-04-28T08:11:37

lol ok


---

### 403. msg_5731

**You** - 2025-04-28T08:11:39

203


---

### 404. msg_5732

**You** - 2025-04-28T08:11:45

Give 4
Mins


---

### 405. msg_5733

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:11:55

So the heavy metal just stopped lol


---

### 406. msg_5734

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:12:00

Mac: bruuuh


---

### 407. msg_5735

**You** - 2025-04-28T08:14:30

Ok


---

### 408. msg_5736

**You** - 2025-04-28T08:14:33

It is out there


---

### 409. msg_5737

**You** - 2025-04-28T08:14:51

Only country playing in my room I don’t know about yours ☺️


---

### 410. msg_5738

**You** - 2025-04-28T08:15:10

Coyote in a field of wolves right now\.


---

### 411. msg_5739

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:16:26

>
Thank u\!


---

### 412. msg_5740

**You** - 2025-04-28T08:16:38

Np


---

### 413. msg_5741

**You** - 2025-04-28T08:44:46

Heading down for coffee then likely driving I\. Figured you would take your own vehicle\.


---

### 414. msg_5742

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:45:32

Yeah\. Had to get Mac coffee :p


---

### 415. msg_5743

**You** - 2025-04-28T08:52:25

Ah ok I forgot my phone


---

### 416. msg_5744

**You** - 2025-04-28T08:52:34

Leaving now was going to crow place for coffee I guess


---

### 417. msg_5745

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:58:31

I’m taking a little detour to look around and then going


---

### 418. msg_5746

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T08:58:39

Been a few years since I’ve been here


---

### 419. msg_5747

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T09:14:41

This is a little weird being back after 10 years\. Yeah I could move back here\-ish\. Lol … ish\.


---

### 420. msg_5748

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T09:15:04

Difficult if I have a F’ing cottage near north bay tho


---

### 421. msg_5749

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T09:22:34

Where are we ugh


---

### 422. msg_5750

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T09:28:48

I opened my laptop and found the rm \#\. I need a work phone gah


---

### 423. msg_5751

**You** - 2025-04-28T09:57:03

lol sorry I ended up getting waylaid missed all of this\.\. btw going to try to use a lot of big
Words today\.


---

### 424. msg_5752

**You** - 2025-04-28T14:20:33

You feeling ok


---

### 425. msg_5753

**You** - 2025-04-28T14:32:32

You look so unhappy and I feel soooooooooo guilty


---

### 426. msg_5754

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T14:32:40

Defend ok


---

### 427. msg_5755

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T14:32:44

\*define


---

### 428. msg_5756

**You** - 2025-04-28T14:36:42

I feel soooooo bad I am a bad bad bad person


---

### 429. msg_5757

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T14:41:10

It’s fine\. It’s worth it\. If I didn’t have these lozenges I’d be dying tho


---

### 430. msg_5758

**You** - 2025-04-28T14:46:21

It will be more worth it


---

### 431. msg_5759

**You** - 2025-04-28T16:44:31

At hotel going up to room to rest for a bit I have to grab a drink with Sophear at 8 but otherwise staying in room and shouldn’t be a long drink
Out\.


---

### 432. msg_5760

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T16:48:50

I’m having some neocitran and then going to nap\. 😴


---

### 433. msg_5761

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T16:51:31

I feel like I have Covid btw\. Lol it’s in my chest now…


---

### 434. msg_5762

**You** - 2025-04-28T16:52:01

Omg :\( I didn’t get that at all\.


---

### 435. msg_5763

**You** - 2025-04-28T16:52:10

I mean a little cough nothing more


---

### 436. msg_5764

**You** - 2025-04-28T16:52:20

But again I hammered vitamin c and water


---

### 437. msg_5765

**You** - 2025-04-28T16:52:36

I had to stop for restroom like 25 times on way to Detroit


---

### 438. msg_5766

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T16:52:42

It’s fine\. Just tired\.


---

### 439. msg_5767

**You** - 2025-04-28T16:53:11

I feel like such a selfish ass I should have stayed home and just saw you on Sunday\.


---

### 440. msg_5768

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T16:53:30

I would have been upset if you did that


---

### 441. msg_5769

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T16:53:38

Reaction: ❤️ from Scott Hicks
No winning lol


---

### 442. msg_5770

**You** - 2025-04-28T16:54:33

Reaction: 👍 from Meredith Lamb
Ok well depending on how long you sleep I might see you before I go out\. I am setting up the couch for us to actually watch something and for you to be able to lay down with your head in my lap on a pillow and sleep or watch but just want to make
You feel better


---

### 443. msg_5771

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T16:57:22

k\.\.


---

### 444. msg_5772

**You** - 2025-04-28T17:01:50

If you want me to poke you after a certain time I will do that as well let me know I will be just relaxing in my
Room\.


---

### 445. msg_5773

**You** - 2025-04-28T17:54:30

Reaction: 😮 from Meredith Lamb
Fack j called more fucking separation discussions\.  I told her to take it to a lawyer to see if it is fair


---

### 446. msg_5774

**You** - 2025-04-28T17:54:41

Soo tired of this shit


---

### 447. msg_5775

**You** - 2025-04-28T18:29:30

Reaction: ❤️ from Meredith Lamb
Going to meet sophear at 7 instead hoping to end it earlier so I can spend more time with you\.


---

### 448. msg_5776

**You** - 2025-04-28T18:46:37

Reaction: ❤️ from Meredith Lamb
Just been sitting here listening to the mix tape thinking about you since I got back\.  There are so many thing is wish\.\. but mostly I wish I was the one that read your blog and reached out…\.\. I know it is a pointless wish but I wish it anyways\.


---

### 449. msg_5777

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:49:46

Just woke up bc of Mackenzie\. She is so loud\.


---

### 450. msg_5778

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:49:49

Argh


---

### 451. msg_5779

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:50:49

Going to lay here half asleep and eventually have a hot shower\.


---

### 452. msg_5780

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:51:03

>
Ditto\.


---

### 453. msg_5781

**You** - 2025-04-28T18:51:47

Gah I hate feeling like that\.\. so much I want to do with you\.


---

### 454. msg_5782

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:51:58

I might need some more of your cepacols lol


---

### 455. msg_5783

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:52:11

>
Like…\.\. lol


---

### 456. msg_5784

**You** - 2025-04-28T18:52:39

I mean with you not to you\.\. although that to


---

### 457. msg_5785

**You** - 2025-04-28T18:52:52

Just make our own memories


---

### 458. msg_5786

**You** - 2025-04-28T18:52:55

So jealous


---

### 459. msg_5787

**You** - 2025-04-28T18:53:00

It is stupid


---

### 460. msg_5788

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:53:50

We will absolutely do that\. And hopefully it will be outside of work lol


---

### 461. msg_5789

**You** - 2025-04-28T18:54:40

Hope so\.


---

### 462. msg_5790

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:55:39

So are you leaving now?


---

### 463. msg_5791

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:56:22

It’s almost 7


---

### 464. msg_5792

**You** - 2025-04-28T18:56:57

Yeah I am heading downstairs but if you are decent I could use a hug lol\.


---

### 465. msg_5793

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:57:29

I am in bed with Mac…\. After?


---

### 466. msg_5794

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:57:37

She’s ordering food


---

### 467. msg_5795

**You** - 2025-04-28T18:58:05

lol yeah I have something I want to do with you later will tell you about it then\.  Will let you know when I am back enjoy your super and your time with Max


---

### 468. msg_5796

**You** - 2025-04-28T18:58:09

Mac


---

### 469. msg_5797

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T18:58:30

K love you


---

### 470. msg_5798

**You** - 2025-04-28T18:58:47

Love you too\. ❤️❤️❤️❤️


---

### 471. msg_5799

**You** - 2025-04-28T21:10:40

Hey I am back you still awake lol?


---

### 472. msg_5800

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T21:11:16

Yeah did some emails and watching a documentary on my phone now


---

### 473. msg_5801

**You** - 2025-04-28T21:11:56

Nice well the bolt
Is
Over I\. The door I am just going to jump in the shower you are welcome
To
Come over whenever
You want\.


---

### 474. msg_5802

**You** - 2025-04-28T21:18:54

Are you here already


---

### 475. msg_5803

**Meredith Lamb \(\+14169386001\)** - 2025-04-28T21:19:02

lol yah


---

### 476. msg_5804

**You** - 2025-04-28T21:19:15

Ok let me jump in shower I will be quick damn that was fast


---

### 477. msg_5805

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T00:29:10


*1 attachment(s)*


---

### 478. msg_5806

**You** - 2025-04-29T01:10:51

Night mer you def are my home ❤️ love you xoxo\.


---

### 479. msg_5807

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T01:14:16

🏡❤️ Amazing unforgettable night…\.\. love you


---

### 480. msg_5808

**You** - 2025-04-29T07:43:37

Ur damn right it was the whole weekend was I will never forget this weekend\.   I love you mer\.  God help me through this next phase\.


---

### 481. msg_5809

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T07:49:53

God help “us”…\.


---

### 482. msg_5810

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T07:49:58

lol


---

### 483. msg_5811

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T08:02:56

Ps\. I know you think it was “irresponsible” or whatever but I was just so focused on having you completely … honestly can’t stop thinking about it\. Will be an interesting day\. Lol xo hope you made it to your meeting on time\! Xoxoxox


---

### 484. msg_5812

**You** - 2025-04-29T08:05:41

Reaction: ❤️ from Meredith Lamb
I am leaving now will see how that goes\.   I wanted the same\.\. that is what I was debating\.  I just wanted to be with you in the same way\.  ❤️ this whole level of emotions is quite overwhelming for me but so much in a good way\.  Love you\!\!\!


---

### 485. msg_5813

**You** - 2025-04-29T08:05:55

Too many firsts for me at this age\.


---

### 486. msg_5814

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T09:02:19

Erin just told me about the rollover\. I didn’t even reach out\. She is so deflated\. Needed to vent\.


---

### 487. msg_5815

**You** - 2025-04-29T10:03:15

Yeah I am messaging the sup group\.


---

### 488. msg_5816

**You** - 2025-04-29T10:54:46

Going to Leave after my lunch not staying this afternoon very tired will tell you more about this process later\.


---

### 489. msg_5817

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T10:56:38

I’m just in caf with other Scott


---

### 490. msg_5818

**You** - 2025-04-29T11:01:15

Cool hope you are having fun\.


---

### 491. msg_5819

**You** - 2025-04-29T11:01:39

You of course are
Welcome to join us for lunch just my team and Octavian but I suspect
You will want to get
Back in the road\.


---

### 492. msg_5820

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:17:24

Yeah we are just finishing up


---

### 493. msg_5821

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:17:36

He’s got a meeting and I need to get Mac by 12


---

### 494. msg_5822

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:17:41

Checkout time


---

### 495. msg_5823

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:18:30

I got some good separation tips


---

### 496. msg_5824

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:18:32

lol


---

### 497. msg_5825

**You** - 2025-04-29T11:41:02

lol just finished my meeting also had a conversation with Ian felt it was time to tell him about my separation\.  He was very empathetic\.


---

### 498. msg_5826

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:59:17

Oh wow


---

### 499. msg_5827

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T11:59:56

That is good to hear\. We just bought dog sitter gift and are leaving\. Not going to Glencoe\. Too tired and want to do some work / emails at home


---

### 500. msg_5828

**You** - 2025-04-29T12:00:54

Safe drive mer will chat at
You later ❤️


---

### 501. msg_5829

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T12:40:53

At the Dutton on route\. My first job :P


---

### 502. msg_5830

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T12:41:10

I should probably think about telling my manager about my separation too\.


---

### 503. msg_5831

**You** - 2025-04-29T13:19:27

Might not be a bad idea that is probably something he should be aware of\.  😝


---

### 504. msg_5832

**You** - 2025-04-29T13:19:52

Just finished lunch about to go fill up and get on the road\.\. it is getting windy here\.


---

### 505. msg_5833

**You** - 2025-04-29T14:03:06

J is back to wanting to move back to Moncton before end of summer now


---

### 506. msg_5834

**You** - 2025-04-29T14:03:12

Going to chat tonight


---

### 507. msg_5835

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T14:33:02

Whip lash\. I told you lol


---

### 508. msg_5836

**You** - 2025-04-29T14:49:14

I mean yeah but I would be happier with that


---

### 509. msg_5837

**You** - 2025-04-29T14:53:03

You must almost be home


---

### 510. msg_5838

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T14:57:45

Yep\! Getting dogs first


---

### 511. msg_5839

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T15:00:10

Marlowe won first game so just getting ready for QF 😬


---

### 512. msg_5840

**You** - 2025-04-29T15:01:47

Wow excitement\!\!\! Bout 1\.5 hours out from home now…


---

### 513. msg_5841

**You** - 2025-04-29T15:01:57

Gym tonight lol


---

### 514. msg_5842

**You** - 2025-04-29T15:03:43

Back to the grind


---

### 515. msg_5843

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T15:14:36

Just driving Mac to gym now 🙄 chauffeuring continues


---

### 516. msg_5844

**You** - 2025-04-29T15:16:07

Geese


---

### 517. msg_5845

**You** - 2025-04-29T15:16:13

Geeze


---

### 518. msg_5846

**You** - 2025-04-29T15:16:27

Fun never stops


---

### 519. msg_5847

**You** - 2025-04-29T15:16:40

I need to start cleaning and fixing house at a rapid pace


---

### 520. msg_5848

**You** - 2025-04-29T15:17:02

Because no one else will going to need to focus


---

### 521. msg_5849

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T15:17:55

Reality 🙃


---

### 522. msg_5850

**You** - 2025-04-29T15:18:18

Means to an end\.


---

### 523. msg_5851

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T15:26:55

Yeah I have so much to do also\.


---

### 524. msg_5852

**You** - 2025-04-29T15:34:44

Yeah I guess you have a tough week ahead of you too


---

### 525. msg_5853

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T15:55:18

On my way home finally

*1 attachment(s)*


---

### 526. msg_5854

**You** - 2025-04-29T15:57:09

Going to doctor


---

### 527. msg_5855

**You** - 2025-04-29T15:57:44

Cute pups bet you glad to be with them again


---

### 528. msg_5856

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T16:45:04

Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 529. msg_5857

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T16:46:35

>
Doctor??


---

### 530. msg_5858

**You** - 2025-04-29T16:59:41

Tough break but they had a good run\.


---

### 531. msg_5859

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T17:01:33

Why did you say “going to doctor”?


---

### 532. msg_5860

**You** - 2025-04-29T17:09:57

I had to take over Gracie’s appointment because she wouldn’t go…\. Again… I had to go see him anyways\.\. just some stuff,
Nothing for you to worry about\.


---

### 533. msg_5861

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T17:13:33

Oh kk thought something might be wrong


---

### 534. msg_5862

**You** - 2025-04-29T17:14:41

Well we are
Old there is always something “wrong”


---

### 535. msg_5863

**You** - 2025-04-29T17:15:52

Anyways it doesn’t help not having a paternal history… Fack\.


---

### 536. msg_5864

**You** - 2025-04-29T17:20:06

Not much more I can do anyways\.\.
BP related, trying to get off that\.\. he is hesitant\.\. something about some potential tests\.\. I have to track a bunch of stuf for the next little while\.


---

### 537. msg_5865

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T17:42:49

High BP?


---

### 538. msg_5866

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T17:45:16

My niece … gah\. I never told her\. My sis obviously did

*1 attachment(s)*


---

### 539. msg_5867

**You** - 2025-04-29T17:58:12

I love how much support you are getting it must make things  little easier\.


---

### 540. msg_5868

**You** - 2025-04-29T17:58:43

>
Yeah, pretty much\.


---

### 541. msg_5869

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T18:03:46

My low bp will even you out :\)


---

### 542. msg_5870

**You** - 2025-04-29T18:07:59

Not sure that is how it works


---

### 543. msg_5871

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T18:08:18

lol


---

### 544. msg_5872

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T18:08:37

I mean it can’t hurt


---

### 545. msg_5873

**You** - 2025-04-29T18:26:37

Nah I got shot
To take care
If I am not happy with where I am at\.\. there stuff that isn’t right and it needs to be addressed\.  Like I said don’t worry about it, just something I will need to deal with\.


---

### 546. msg_5874

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T18:31:04

My mom has always had high bp\.
Our power was out for hours and just came back on phewwww going to do some work now


---

### 547. msg_5875

**You** - 2025-04-29T19:19:01

Kkk have fun whiplash all over the place here we’re staying we’re going can we work something out where I buy you out of the house but can still afford to stay\.\. to which I said no\.\. I would need to give a lot more and that would be well beyond reasonable Gracie still refuses to go what a fucking shit show\.


---

### 548. msg_5876

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:26:09

Total shit show\. My crew is on the way home and not looking forward to arrival\. Ugh\.


---

### 549. msg_5877

**You** - 2025-04-29T19:56:10

What are you predicting I thought you and Andrew had reached an accommodation or is there whiplash there too?


---

### 550. msg_5878

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:56:20

Sorry accident


---

### 551. msg_5879

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:56:44

I don’t think I can predict at this point\.


---

### 552. msg_5880

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:57:01

I’d just like to go to a mediator now so hoping he will be receptive to that\.


---

### 553. msg_5881

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:57:20

We haven’t talked all weekend


---

### 554. msg_5882

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:57:32

Since night before I left


---

### 555. msg_5883

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T19:57:52

It’s been lovely\.


---

### 556. msg_5884

**You** - 2025-04-29T20:24:13

Reaction: ❤️ from Meredith Lamb
If things get bad mer think about the slow dance think about the fact that someone loves you so much you are home to them\. Think about all of that and then think somewhere down the road, we get to have that\.  That is what I am holding onto here\.


---

### 557. msg_5885

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T20:28:59

Today is definitely a bit of an adjustment\. Quite the rollercoaster we are on…


---

### 558. msg_5886

**You** - 2025-04-29T20:32:50

Yeah I know but at least we are on it together\.


---

### 559. msg_5887

**You** - 2025-04-29T20:34:20

I am heading to the gym can you please
Let me know you are ok tonight\.\. I worry that all the stuff he would be thinking about this weekend will hit you like a truck\.


---

### 560. msg_5888

**You** - 2025-04-29T20:35:46

Gracie had a meltdown here\.\. she wants to stay I basically said I am selling the house one way or the other\.
Which is really what she is trying to control she cannot deal with any change\.  She thinks she is ready for university
But she is not\.\. this will be tough but I still hope she can make it back to Moncton I will have to fly up regularly I suspect but she will do better there\.


---

### 561. msg_5889

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T20:37:59

That sounds very difficult for her for sure\. Not easy\.
I can msg later but I might go to bed early and then I don’t have to talk to him\. lol


---

### 562. msg_5890

**You** - 2025-04-29T20:38:50

Ok :\( well please let
Me know you are ok I am really worried\. I will leave you be, going to get my shit and go in and try to work off everything I am feeling\.


---

### 563. msg_5891

**Meredith Lamb \(\+14169386001\)** - 2025-04-29T20:42:55

I will be good\. The missing you will be worse than anything here\.


---

### 564. msg_5892

**You** - 2025-04-29T20:59:57

😞


---

### 565. msg_5893

**You** - 2025-04-29T21:07:08

Uggh


---

### 566. msg_5894

**You** - 2025-04-30T00:01:35

Well I am hoping I didn’t hear from you because you went to sleep early and got a good night sleep\.  Love you\. Xoxo


---

### 567. msg_5895

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T02:58:48

Yes, sorry xoxoxo


---

### 568. msg_5896

**You** - 2025-04-30T04:46:17

Kk


---

### 569. msg_5897

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T09:03:47

Ugh busy talky morning\. Everything is “fine” tho\. My heart really hurts tho\.


---

### 570. msg_5898

**You** - 2025-04-30T09:05:33

Yeah I tried to give you space,
Had a really bad night in my head but didn’t want to burden you\.  Figured you would reach out when you can\.


---

### 571. msg_5899

**You** - 2025-04-30T09:07:19

And yeah I was in a lot of pain too\.


---

### 572. msg_5900

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:03:43

Listen, Andrew worked from home today so he can take Mac to orthodontist so I had to be careful\. But I love you and am not changing my mind so chill those thoughts…\. Unnecessary stress\. ❤️❤️


---

### 573. msg_5901

**You** - 2025-04-30T13:05:59

I am trying and I love you too\. But this is not what I expected it is all new and I don’t know how to adjust,  but I am trying\.  And there is no alternative anyways, so I just need to figure it out\. ❤️❤️


---

### 574. msg_5902

**You** - 2025-04-30T13:07:36

It’s like I have all of……\. “This” that I want to share with you and I cannot and I have no other outlet\.  If you were on your own it would be different\.\. so maybe when that happens I won’t be as kind of messed up or broken as I am now\.\.


---

### 575. msg_5903

**You** - 2025-04-30T13:08:15

Anyhow again feel like a fool\.\. not sure what else to do


---

### 576. msg_5904

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:08:38

You are hardly messed up… you are navigating an immense amount of conflict and other “stuff” all at once\.


---

### 577. msg_5905

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:12:00

Check out this listing
https://realtor\.ca/real\-estate/27885098/5\-crestview\-road\-toronto\-lawrence\-park\-south\-lawrence\-park\-south?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 578. msg_5906

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:12:29

I’m frustrated\. I want to rent that place but can’t inquire until we get our financials organized\.


---

### 579. msg_5907

**You** - 2025-04-30T13:13:52

It’s a very nice place, real fireplaces I bet was a draw 2 of them


---

### 580. msg_5908

**You** - 2025-04-30T13:14:25

Who is I\. Charge of securing a mediator since that is your next step


---

### 581. msg_5909

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:15:43


*1 attachment(s)*


---

### 582. msg_5910

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:16:14


*1 attachment(s)*


---

### 583. msg_5911

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:16:37

Literally for those texts when we were talking


---

### 584. msg_5912

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:17:01

Life is exhausting right now\. I hope you ranked me LAST\. I can’t keep up\.


---

### 585. msg_5913

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:17:21

Also planning 3 birthdays, Maelle, my moms 80th and Mac’s 16


---

### 586. msg_5914

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:17:29

Lord ……\.


---

### 587. msg_5915

**You** - 2025-04-30T13:18:54

See I mean I wish I had your problem because it would keep my mind occupied


---

### 588. msg_5916

**You** - 2025-04-30T13:19:24

You are always ranked at the top mer\.\. even if I was busy\.


---

### 589. msg_5917

**You** - 2025-04-30T13:19:39

My situation is different though


---

### 590. msg_5918

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:20:12

Yours involves more conflict and trauma for sure


---

### 591. msg_5919

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:20:21

It’s heavier maybe


---

### 592. msg_5920

**You** - 2025-04-30T13:24:18

But nothing to focus on to keep my mind off of what I cannot have or feel I could lose if I make a mistake or don’t go fast enough or something beyond my control happens on your side\.  I know you said not to worry, and I appreciate it, but as I have said I have never had something work out like this\.  Well nothing like this has happened\.\. it’s like hoping for a happily ever after but always getting screwed\. Not your fault or your problem I just have to figure out a way to get some kind of mental control over my emotions\.


---

### 593. msg_5921

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:26:08

Maybe don’t go cold turkey off your anxiety meds\. :p


---

### 594. msg_5922

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:26:17

No but for real…


---

### 595. msg_5923

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:28:11

If your brain needs reassurance I can give that to you anytime\. It will not bother me \(unless you ask multiple times a day\)\. I don’t struggle with needing reassurance so much and more so with feeling stuck and like that will last too long\. I get in my head about that\. This current state dragging on and on and on…\.\.


---

### 596. msg_5924

**You** - 2025-04-30T13:30:41

Doctor confirmed there was nothing left I\. My system so no anxiety from that\. I won’t ask for reassurance\.  I will just try to take it on faith\.   It I cannot help the scenarios that play out\.\. I will just have to suffer through those\.


---

### 597. msg_5925

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:31:46

I can guarantee you that your scenarios \(without having any details of them\) are likely all very ridiculous for one reason or another…


---

### 598. msg_5926

**You** - 2025-04-30T13:33:20

Maybe\. I don’t know\.  Anyhow it’s fine I have to get ready for a long haul, no choice in the matter\.  So I either figure it out or well I need to figure it out\.


---

### 599. msg_5927

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T13:34:36

Maybe? Come on… after this past weekend you truly think one of those made up scenarios plays out for real?


---

### 600. msg_5928

**You** - 2025-04-30T13:37:13

You don’t understand\.  I cannot read certain things in people\.  For someone that can read almost anything, genuine happiness satisfaction anything like that I cannot read\.\. I just hope for it\.  And then my head suggests I am mistaken etc etc enter scenarios as a result\.  It is the most illogical part
Of me\.\. but I have never had self confidence in this area because I have been burned so many times in the past and none of them held a candle to how I feel about you so a bit more worried than usual\.


---

### 601. msg_5929

**You** - 2025-04-30T14:14:13

It sounds so childish\.\. and again weak\.\. not how I saw myself\.  But I guess in certain situations this is me unfortunately\.


---

### 602. msg_5930

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:16:09

You have been burned because you haven’t met the right person\. Like so many of us other people\. You are not unlike the rest of us\. You just think you are\. :\)


---

### 603. msg_5931

**You** - 2025-04-30T14:17:06

Reaction: 🙂 from Meredith Lamb
You are so much more wise than me\.\. maybe I will get that too when I hit 47\.


---

### 604. msg_5932

**You** - 2025-04-30T14:18:14

But it is more than what you are saying my issues are internal\.\. so I will have to reconcile or rationalize them somehow\.  While your logic is solid it still doesn’t change how I feel\.


---

### 605. msg_5933

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:19:03

You know when I wrote the LSAT I scored highest on logic\.


---

### 606. msg_5934

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:19:04

lol


---

### 607. msg_5935

**You** - 2025-04-30T14:19:48

Someone used to being in control, being able to read situation and people\.  To put them into something where the opposite is true they cannot read anything and feel slightly helpless and out of control would be an apt comparison \.


---

### 608. msg_5936

**You** - 2025-04-30T14:20:40

When I wrote gmat I scored in the 99th % on writing, comprehension and articulation


---

### 609. msg_5937

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:20:48

I don’t think our situation is that hard to read\.


---

### 610. msg_5938

**You** - 2025-04-30T14:21:13

It is you that are hard to read but it will come in time I think\.


---

### 611. msg_5939

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:21:16

>
Not shocking\.


---

### 612. msg_5940

**You** - 2025-04-30T14:21:57

I mean logic is my go to\.  Which is why I am so fucked right now


---

### 613. msg_5941

**You** - 2025-04-30T14:21:58

lol


---

### 614. msg_5942

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:22:06

>
If I was easy to read you’d be bored with me anyway


---

### 615. msg_5943

**You** - 2025-04-30T14:23:40

Reached a point where I cannot articulate further\.


---

### 616. msg_5944

**You** - 2025-04-30T14:23:57

Suffice to say you wouldn’t bore me ever


---

### 617. msg_5945

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:33:51

I’m watching a holocaust documentary right now… I could bore you easily


---

### 618. msg_5946

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:33:53

lol


---

### 619. msg_5947

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:34:06

Sigh Andrew doesn’t want to do mediation


---

### 620. msg_5948

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:34:15

He thinks it will drag on too long


---

### 621. msg_5949

**You** - 2025-04-30T14:35:07

I think you just take it a lawyer to get some advice if it is close take it\.


---

### 622. msg_5950

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:40:03

He seems very worried about the financial disclosure aspect which is concerning me 🚩🚩🚩🚩🚩


---

### 623. msg_5951

**You** - 2025-04-30T14:40:52

I am not sure what the concerns there are\.\. has he not paid his taxes? lol


---

### 624. msg_5952

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:41:29

Maybe he has more pension or rrsps that he is not disclosing to me\. No idea


---

### 625. msg_5953

**You** - 2025-04-30T14:43:24

Checking something


---

### 626. msg_5954

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:44:48

He’s like “if we don’t go do that we can just go now” and I’m all “hardly because you haven’t allowed me to tell the kids\!”


---

### 627. msg_5955

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:45:06

Like as if I can just move out next week\. They need a bit of time to process\.


---

### 628. msg_5956

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T14:45:12

So frustrating


---

### 629. msg_5957

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T15:58:50


*1 attachment(s)*


---

### 630. msg_5958

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T15:59:17

I might be having a drink tonight\. Lol


---

### 631. msg_5959

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T15:59:29

I hate being accused of taking advantage of anyone\.


---

### 632. msg_5960

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T15:59:34

I get it constantly


---

### 633. msg_5961

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T15:59:37

So annoying


---

### 634. msg_5962

**You** - 2025-04-30T15:59:40

Does he understand that the house rennovations is not an expense


---

### 635. msg_5963

**You** - 2025-04-30T15:59:47

It is an ivestment


---

### 636. msg_5964

**You** - 2025-04-30T15:59:52

Rrsp is an asset


---

### 637. msg_5965

**You** - 2025-04-30T16:00:01

He is transferring value from one asset to another


---

### 638. msg_5966

**You** - 2025-04-30T16:00:05

And that is his choice


---

### 639. msg_5967

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T16:00:06

Yes but he think I’m an idiot


---

### 640. msg_5968

**You** - 2025-04-30T16:00:58

Hmm


---

### 641. msg_5969

**You** - 2025-04-30T16:01:20

Again that is his choice in that last paragraph


---

### 642. msg_5970

**You** - 2025-04-30T16:01:46

Your choice is to not sacrifice your own independent ability to live comfortably where the girls currently go to school


---

### 643. msg_5971

**You** - 2025-04-30T16:01:50

For the sake of his dream


---

### 644. msg_5972

**You** - 2025-04-30T16:02:35

If he sold the cottage or properly bought you out then he could provide you that he doesn’t want to\.


---

### 645. msg_5973

**You** - 2025-04-30T16:02:55

Again the only thing that is different here is the value of assets\.\.


---

### 646. msg_5974

**You** - 2025-04-30T16:02:59

And equalization


---

### 647. msg_5975

**You** - 2025-04-30T16:03:09

In common law you don’t have as many rights Ther


---

### 648. msg_5976

**You** - 2025-04-30T16:03:17

But he is low balling you on spousal


---

### 649. msg_5977

**You** - 2025-04-30T16:03:24

So that is all he has to play with


---

### 650. msg_5978

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T16:03:32

Yeah he uses the kids to excuse his selfishness sometimes\.


---

### 651. msg_5979

**You** - 2025-04-30T16:03:43

Yeah I can read that lol


---

### 652. msg_5980

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T16:03:44

Then blames me for


---

### 653. msg_5981

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T16:03:53

Everything is always my fault


---

### 654. msg_5982

**You** - 2025-04-30T16:03:58

I mean at the end of the day this was his decision


---

### 655. msg_5983

**You** - 2025-04-30T16:04:06

He decided to send the text


---

### 656. msg_5984

**You** - 2025-04-30T16:04:10

To blow up the trust


---

### 657. msg_5985

**You** - 2025-04-30T16:04:15

And the relationship


---

### 658. msg_5986

**You** - 2025-04-30T16:04:18

Period full stop


---

### 659. msg_5987

**You** - 2025-04-30T16:04:28

And there is no justification ever for it’s


---

### 660. msg_5988

**You** - 2025-04-30T16:05:26

Again I think going back to my example you got well over a million in a lumps in that considered everything I a very reasonable fashion


---

### 661. msg_5989

**You** - 2025-04-30T16:05:40

If you have what I provided to a lawyer they could tell you more


---

### 662. msg_5990

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T16:06:16

If I didn’t have kids I would address this differently but trying to think of them also so I get conflicted\.


---

### 663. msg_5991

**You** - 2025-04-30T16:06:29

You are thinking of them


---

### 664. msg_5992

**You** - 2025-04-30T16:06:48

How will it work with you struggling but hey the kids have a cottage and a house all that belong to him


---

### 665. msg_5993

**You** - 2025-04-30T16:06:58

That is not in their best interests


---

### 666. msg_5994

**You** - 2025-04-30T16:30:53

Alright I am heading home, hoping we can chat a bit later\.\. always helps me end my day on a high note\. Honestly the thing I look forward to most every day\.


---

### 667. msg_5995

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:19:56

He fucking cried on me this afternoon\. Sooo annoyed


---

### 668. msg_5996

**You** - 2025-04-30T17:24:02

Probably because I cried on you too


---

### 669. msg_5997

**You** - 2025-04-30T17:25:35

What was it now cottage or reverse course


---

### 670. msg_5998

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:29:15

Just telling the kids… and he hates all of this


---

### 671. msg_5999

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:29:23

I said not to cry when we tell the kids


---

### 672. msg_6000

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:29:27

He said he will


---

### 673. msg_6001

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:29:30

Ughhhhhhhhhhh


---

### 674. msg_6002

**You** - 2025-04-30T17:30:23

Eesh


---

### 675. msg_6003

**You** - 2025-04-30T17:30:56

I get feeling sad


---

### 676. msg_6004

**You** - 2025-04-30T17:31:02

But not crying over that


---

### 677. msg_6005

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:31:45

I find it manipulative\. But that might be the Dexter in me talking


---

### 678. msg_6006

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:31:48

:p


---

### 679. msg_6007

**You** - 2025-04-30T17:31:55

I literally just thought that


---

### 680. msg_6008

**You** - 2025-04-30T17:31:57

I swear


---

### 681. msg_6009

**You** - 2025-04-30T17:32:08

Apparently I have a little dexter in my brain too\.


---

### 682. msg_6010

**You** - 2025-04-30T17:32:20

Like look kids I care more


---

### 683. msg_6011

**You** - 2025-04-30T17:32:27

Was that what you were thinking


---

### 684. msg_6012

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:32:30

Exactly


---

### 685. msg_6013

**You** - 2025-04-30T17:32:34

Rofl


---

### 686. msg_6014

**You** - 2025-04-30T17:33:03

I mean I cannot see what it would accomplish otherwise\.


---

### 687. msg_6015

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:34:14

Sigh


---

### 688. msg_6016

**You** - 2025-04-30T17:35:17

Sry I cannot help with that\.   Doing it next week I assume should give him time to prepare


---

### 689. msg_6017

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:37:06

In the next breath he was being an asshole\. Hilarious


---

### 690. msg_6018

**You** - 2025-04-30T17:39:23

Honestly I don’t understand where he feels he has the right?


---

### 691. msg_6019

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:48:47

Oh he is pissed I got the dog walker to come today $$


---

### 692. msg_6020

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:48:50

🙄


---

### 693. msg_6021

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:49:03

So then he acts assholish


---

### 694. msg_6022

**You** - 2025-04-30T17:51:42

Oh ffs


---

### 695. msg_6023

**You** - 2025-04-30T17:52:01

The drama of it all


---

### 696. msg_6024

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:53:29

Life is hard


---

### 697. msg_6025

**You** - 2025-04-30T17:54:09

I mean I think it is hard filled with really shitty problems\.\. dog walkers for people that make 500 gs or whatever shouldn’t rank in the top 1000


---

### 698. msg_6026

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T17:54:41

Well especially when I’m the one that walks the dogs lol


---

### 699. msg_6027

**You** - 2025-04-30T17:55:06

Well I guess yeah that should make it your prerogative


---

### 700. msg_6028

**You** - 2025-04-30T17:55:18

More important things to sort out for sure


---

### 701. msg_6029

**You** - 2025-04-30T21:25:27

Hope your night better than mi e


---

### 702. msg_6030

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:25:40

Talking to my bro :\)


---

### 703. msg_6031

**You** - 2025-04-30T21:26:41

Another fight with j and Gracie no further now I think they want to stay in the house a year and anyways it is all messed up I am going to have to drag this through to completion\. On my own\.


---

### 704. msg_6032

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:28:01

Omg whip lash


---

### 705. msg_6033

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:28:14

Wait were j and Gracie ganging up


---

### 706. msg_6034

**You** - 2025-04-30T21:36:58

Yeah a bit and I was being mean in response which I shouldn’t have


---

### 707. msg_6035

**You** - 2025-04-30T21:38:15

I apologized again I just want out I do t care what I give up or who lives where I will do whatever at this point\.


---

### 708. msg_6036

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:39:35

I’m at that point too


---

### 709. msg_6037

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:42:22

I kind of want to see you being mean


---

### 710. msg_6038

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:42:25

Is that bad


---

### 711. msg_6039

**You** - 2025-04-30T21:46:00

No you don’t mer


---

### 712. msg_6040

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:46:07

I dooooooo


---

### 713. msg_6041

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:46:14

Is it worse than damir mad


---

### 714. msg_6042

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:46:17

lol


---

### 715. msg_6043

**You** - 2025-04-30T21:46:29

Mer it is an awful version of myself and yes it is worse than damir


---

### 716. msg_6044

**You** - 2025-04-30T21:46:37

It gets there i should say


---

### 717. msg_6045

**You** - 2025-04-30T21:46:52

Reaction: 😢 from Meredith Lamb
Over a long time of being constantly abused and berated


---

### 718. msg_6046

**You** - 2025-04-30T21:47:05

I think everyone ahead a
Limit I just reached mine in this family


---

### 719. msg_6047

**You** - 2025-04-30T21:47:19

And now when you get mad you just go all the way to the angry place


---

### 720. msg_6048

**You** - 2025-04-30T21:47:28

Why wait a sec


---

### 721. msg_6049

**You** - 2025-04-30T21:47:39

Don’t tell me you liked the damir conversation


---

### 722. msg_6050

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:47:43

No


---

### 723. msg_6051

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:47:46

Painful


---

### 724. msg_6052

**You** - 2025-04-30T21:47:47

Ok


---

### 725. msg_6053

**You** - 2025-04-30T21:47:50

Was checking


---

### 726. msg_6054

**You** - 2025-04-30T21:47:52

lol


---

### 727. msg_6055

**You** - 2025-04-30T21:47:58

Was like why do you want to see me mad


---

### 728. msg_6056

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:48:21

I dunno\. I want to see all sides of u I guess


---

### 729. msg_6057

**You** - 2025-04-30T21:48:31

Well you saw some anger today it exists


---

### 730. msg_6058

**You** - 2025-04-30T21:48:35

More frustration
Though


---

### 731. msg_6059

**You** - 2025-04-30T21:49:44

It yeah I am not a wimpy ball of emotions all the time lol there are other dynamics


---

### 732. msg_6060

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:49:57

Thank god


---

### 733. msg_6061

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:49:59

lol


---

### 734. msg_6062

**You** - 2025-04-30T21:51:12

Ouch


---

### 735. msg_6063

**You** - 2025-04-30T21:51:37

You know the big ball of emotions is the one that does all the romantic stuff too\.


---

### 736. msg_6064

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:51:49

True true


---

### 737. msg_6065

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:51:55

Touché


---

### 738. msg_6066

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:52:24

I’m okay with that … I guess\.


---

### 739. msg_6067

**You** - 2025-04-30T21:53:00

lol well I hope so because you are the reason the emotional ball even exists right now\.


---

### 740. msg_6068

**You** - 2025-04-30T21:53:32

That is a compliment in case you are unsure


---

### 741. msg_6069

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:53:59

Are you sure?


---

### 742. msg_6070

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:54:12

I feel like if you are emotional you are emotional


---

### 743. msg_6071

**You** - 2025-04-30T21:55:28

I feel like I was in a cozey loner ice prison and then we
Smashed into each other


---

### 744. msg_6072

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:58:06

Ice prison …\. Wow\. …\. Quite a vision


---

### 745. msg_6073

**You** - 2025-04-30T21:58:59

I was safe and secure\.


---

### 746. msg_6074

**You** - 2025-04-30T21:59:09

Btw\. No fam at gym


---

### 747. msg_6075

**You** - 2025-04-30T21:59:14

But I saw Sharon last night


---

### 748. msg_6076

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:59:27

>
??


---

### 749. msg_6077

**You** - 2025-04-30T21:59:39

She was running on a treadmill across from me and she kept smiling at me was a bit awkward


---

### 750. msg_6078

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:59:46

Omg


---

### 751. msg_6079

**You** - 2025-04-30T21:59:46

😛


---

### 752. msg_6080

**You** - 2025-04-30T21:59:53

True story\. Mishaps


---

### 753. msg_6081

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T21:59:55

Making me angry


---

### 754. msg_6082

**You** - 2025-04-30T22:00:02

That was muahaha


---

### 755. msg_6083

**You** - 2025-04-30T22:00:05

Not mishaps


---

### 756. msg_6084

**You** - 2025-04-30T22:00:07

lol


---

### 757. msg_6085

**You** - 2025-04-30T22:00:25

Whatever I am yours what are angry about


---

### 758. msg_6086

**You** - 2025-04-30T22:00:31

We established that


---

### 759. msg_6087

**You** - 2025-04-30T22:00:36

A few times


---

### 760. msg_6088

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:00:54

Uh huh


---

### 761. msg_6089

**You** - 2025-04-30T22:01:32

Ok come on now\.\. you know I am messing with you\.\. not about the me being yours part


---

### 762. msg_6090

**You** - 2025-04-30T22:02:20

🙁 ok no more joking……


---

### 763. msg_6091

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:02:43

Yah maybe stop


---

### 764. msg_6092

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:02:45

lol


---

### 765. msg_6093

**You** - 2025-04-30T22:03:40

Ok just learning some boundaries is all\.


---

### 766. msg_6094

**You** - 2025-04-30T22:05:23

Don’t be mad at me pls… wasn’t my intent was just playing around\.


---

### 767. msg_6095

**You** - 2025-04-30T22:05:47

No more jokes\.


---

### 768. msg_6096

**You** - 2025-04-30T22:06:53

Sigh


---

### 769. msg_6097

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:07:08

So I got you something small


---

### 770. msg_6098

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:07:21

I’m going to leave it on your chair tomorrow


---

### 771. msg_6099

**You** - 2025-04-30T22:07:53

Why you didn’t need to do that\.


---

### 772. msg_6100

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:08:03

Very small


---

### 773. msg_6101

**You** - 2025-04-30T22:08:29

Is it a note that indicates when and where we can find a few minutes together for a hug because I would take that\.


---

### 774. msg_6102

**You** - 2025-04-30T22:09:31

Like a park\!\!


---

### 775. msg_6103

**You** - 2025-04-30T22:09:34

lol


---

### 776. msg_6104

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:09:40

Um, no sorry :\(


---

### 777. msg_6105

**You** - 2025-04-30T22:10:03

Ah well unfortunate… well I might be there before you\.\. so we’ll see


---

### 778. msg_6106

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:10:14

Yah right


---

### 779. msg_6107

**You** - 2025-04-30T22:10:25

I was in there around 7:39’today


---

### 780. msg_6108

**You** - 2025-04-30T22:10:28

7:30


---

### 781. msg_6109

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:10:33

Why?\!


---

### 782. msg_6110

**You** - 2025-04-30T22:10:48

Because I couldn’t sleep I couldn’t get out of my head and I could t stay home


---

### 783. msg_6111

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:10:50

Ok well if you are in earlier I will just give it to you :\)


---

### 784. msg_6112

**You** - 2025-04-30T22:10:50

So I went in


---

### 785. msg_6113

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:10:58

It is very small


---

### 786. msg_6114

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:11:44

>
Out of your head about us or your family?


---

### 787. msg_6115

**You** - 2025-04-30T22:11:57

Us this morning


---

### 788. msg_6116

**You** - 2025-04-30T22:12:11

I thought I mentioned that earlier


---

### 789. msg_6117

**You** - 2025-04-30T22:12:14

Not rehashing


---

### 790. msg_6118

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:12:39

Yah just wasn’t sure if fam played a role\.


---

### 791. msg_6119

**You** - 2025-04-30T22:14:11

Reaction: ❤️ from Meredith Lamb
Nope I mean k have two major concerns and I feel like I have little control over both\.  So it varies\.\. but you are usually my happy place
Except when my brain wants to have a go at me\.\. like i said won’t always be like that\.


---

### 792. msg_6120

**You** - 2025-04-30T22:14:45

Like you said I think the whole thing is just a bit overwhelming so it makes
Everything a bit more intense


---

### 793. msg_6121

**You** - 2025-04-30T22:15:01

For
Me
That is\.  You are a vault


---

### 794. msg_6122

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:18:15

I’m a vault?


---

### 795. msg_6123

**You** - 2025-04-30T22:18:34

Like super controlled


---

### 796. msg_6124

**You** - 2025-04-30T22:18:52

Way better than me\.\.


---

### 797. msg_6125

**You** - 2025-04-30T22:19:10

But that being said


---

### 798. msg_6126

**You** - 2025-04-30T22:19:17

I am not suggesting it doesn’t affect you either


---

### 799. msg_6127

**You** - 2025-04-30T22:19:29

Maybe I just feel like shit because I look more needy


---

### 800. msg_6128

**You** - 2025-04-30T22:19:30

lol


---

### 801. msg_6129

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:19:35

I kind of like your intensity


---

### 802. msg_6130

**You** - 2025-04-30T22:19:38

And I am not used to that


---

### 803. msg_6131

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:19:49

Are you needy?


---

### 804. msg_6132

**You** - 2025-04-30T22:19:54

I dunno I think you like certain kinds of intensify


---

### 805. msg_6133

**You** - 2025-04-30T22:20:04

I worry I might seem that way


---

### 806. msg_6134

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:20:12

Would your family describe you that way?


---

### 807. msg_6135

**You** - 2025-04-30T22:20:17

Absolutely not


---

### 808. msg_6136

**You** - 2025-04-30T22:20:27

But again that is defined a lot by the situation


---

### 809. msg_6137

**You** - 2025-04-30T22:20:37

Jaimie would never but I never opened to Jaimie like this


---

### 810. msg_6138

**You** - 2025-04-30T22:20:47

And she want the right fit


---

### 811. msg_6139

**You** - 2025-04-30T22:20:52

For me to want to tegardless


---

### 812. msg_6140

**You** - 2025-04-30T22:20:56

Wasn’t


---

### 813. msg_6141

**You** - 2025-04-30T22:22:20

I mean as I said to j tonight I don’t like the person I have become I this situation this isn’t who i really am or am supposed to be\.


---

### 814. msg_6142

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:23:11

>
Why???


---

### 815. msg_6143

**You** - 2025-04-30T22:23:36

She wasn’t you\.  I mean the answer sounds like it sounds but it is the only answer I have\.


---

### 816. msg_6144

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:23:39

>
I agree\.


---

### 817. msg_6145

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:29:35

“The answer sounds like it sounds but it is the only answer I have\.” ???


---

### 818. msg_6146

**You** - 2025-04-30T22:29:53

It sounds like a line or something cheesy


---

### 819. msg_6147

**You** - 2025-04-30T22:30:20

Reaction: ❤️ from Meredith Lamb
But based on the way I feel and that I haven’t felt like this before you\.\. the the answer to your question is she wasn’t you


---

### 820. msg_6148

**You** - 2025-04-30T22:30:28

See logic and emotion\.\.


---

### 821. msg_6149

**You** - 2025-04-30T22:30:29

lol


---

### 822. msg_6150

**You** - 2025-04-30T22:31:41

I could have thrown an ergo in there if that works better


---

### 823. msg_6151

**You** - 2025-04-30T22:32:13

I think it goes to when something clicks and fits together right we are who we are meant to be\.


---

### 824. msg_6152

**You** - 2025-04-30T22:32:20

I don’t think we can be that with anyone


---

### 825. msg_6153

**You** - 2025-04-30T22:32:49

Granted I wouldn’t have said that before now but I have had to reassess


---

### 826. msg_6154

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:35:01

You wouldn’t have said before?


---

### 827. msg_6155

**You** - 2025-04-30T22:35:48

No I didn’t believe


---

### 828. msg_6156

**You** - 2025-04-30T22:36:10

I had no previous basis\.\. so it didn’t seem to exist


---

### 829. msg_6157

**You** - 2025-04-30T22:36:52

I knew though that what I felt for Jaimie wasn’t being in love though\. Not that I knew what that really felt like just not that loving someone and being I love aren’t same thing


---

### 830. msg_6158

**You** - 2025-04-30T22:37:16

I just didn’t realize how different it was


---

### 831. msg_6159

**You** - 2025-04-30T22:37:51

Hmm can I ask a question now you mentioned you were going to have some wine tonight\.


---

### 832. msg_6160

**You** - 2025-04-30T22:37:56

Did you partake?


---

### 833. msg_6161

**You** - 2025-04-30T22:38:14

Cause you are doing the open ended question thing again\.


---

### 834. msg_6162

**You** - 2025-04-30T22:39:15

lol


---

### 835. msg_6163

**You** - 2025-04-30T22:39:40

Do you want to FaceTime me and tell me\.\.


---

### 836. msg_6164

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T22:40:50

One sec


---

### 837. msg_6165

**You** - 2025-04-30T22:44:55

Kk


---

### 838. msg_6166

**You** - 2025-04-30T22:56:19

lol and she went to sleep ROFL


---

### 839. msg_6167

**You** - 2025-04-30T23:07:51

Kk hun wel it is 10
After and I have to have my shower and shave before this place closes
Down tried to wait sorry\.  I will ping you when I get to car but if you aren’t asleep now I am sure you will be by then\.


---

### 840. msg_6168

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T23:16:11

I am not asleep\. Talking finances :p


---

### 841. msg_6169

**You** - 2025-04-30T23:34:15

Oh I thought the one sec meant call me in a sec my mistake lol\.


---

### 842. msg_6170

**You** - 2025-04-30T23:34:36

Getting dressed and heading to car but you probably still occupied\.


---

### 843. msg_6171

**You** - 2025-04-30T23:42:55

Omw home if we don’t chat have a good night\.


---

### 844. msg_6172

**Meredith Lamb \(\+14169386001\)** - 2025-04-30T23:43:20

Just in an argument :p


---

### 845. msg_6173

**You** - 2025-04-30T23:47:01

Ah well then kick him in the teeth mer\.


---

### 846. msg_6174

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T00:03:36

🤯


---

### 847. msg_6175

**You** - 2025-05-01T00:08:51

You still
Going?


---

### 848. msg_6176

**You** - 2025-05-01T00:14:42

In bed will try to stay awake for a bit to see how you ended up if you end up texting back


---

### 849. msg_6177

**You** - 2025-05-01T00:20:59

Uggh will see
You tomorrow\.\.
Nite ❤️ xo hope you are ok\.


---

### 850. msg_6178

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T00:53:48

Nite xoxo omg still going\. He made me cry 😢


---

### 851. msg_6179

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T01:37:10

Gah\. Going to bed\. Xoxo lovely evening 🫤


---

### 852. msg_6180

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T01:38:34

On the bright side, we have both agreed not to talk about this shit again\. No point\. So there is that\. 🤕


---

### 853. msg_6181

**You** - 2025-05-01T02:35:50

Omg mer I am so sorry fuck what can I do to make you feel better\.\. I love you so much I would do anything\. I tried to stay up but passed out\.  😢 I am sooo sorry you are dealing with that in your own\.


---

### 854. msg_6182

**You** - 2025-05-01T02:39:15

If you don’t want to come in tomorrow would completely understand\.


---

### 855. msg_6183

**You** - 2025-05-01T02:40:12

😢 ❤️❤️❤️❤️🏡🏡🏡🏡


---

### 856. msg_6184

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T06:57:23

We are just not going to talk about past shit anymore\. We aren’t even sure how we got on the conversation honestly\. We were trying to discuss financials etc but it went off track completely\.


---

### 857. msg_6185

**You** - 2025-05-01T06:57:54

Happened to j and I as well


---

### 858. msg_6186

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T06:58:26

It comes back to me being to blame for basically everything always\. Lol that’s always the short story 🙄


---

### 859. msg_6187

**You** - 2025-05-01T06:59:15

That’s awful although Jaimie would say same thing\.\. she always says I blame her for everything and I would say likewise


---

### 860. msg_6188

**You** - 2025-05-01T06:59:24

20 years there is a lot of shit


---

### 861. msg_6189

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T06:59:25

We just need to get this over with and live apart\. Very soon\.


---

### 862. msg_6190

**You** - 2025-05-01T06:59:38

Same


---

### 863. msg_6191

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T06:59:38

Yeah…


---

### 864. msg_6192

**You** - 2025-05-01T07:00:18

Anyways i love you very much mer\.\. that’s the truth maybe think about that might make you feel just a bit better\.


---

### 865. msg_6193

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T07:50:44

I love you too


---

### 866. msg_6194

**You** - 2025-05-01T08:00:08

I got stuck at home you will beat me in


---

### 867. msg_6195

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T08:01:33

Omg I got approached this morning so literally ran away


---

### 868. msg_6196

**You** - 2025-05-01T08:04:44

J and I talked for about an hour or more


---

### 869. msg_6197

**You** - 2025-05-01T08:05:01

Wasn’t bad


---

### 870. msg_6198

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T08:16:00

That’s good\. Andrew is just treating me like an idiot constantly  and I’m done with it\. Had to tell him to stop this morning\.


---

### 871. msg_6199

**You** - 2025-05-01T08:23:13

🙁 u aren’t you are amazing what you do is insane to balance and support everyone including him


---

### 872. msg_6200

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T09:12:15

So I left something on your desk\. Turn it over\. I didn’t want to write you a note bc felt risky but growing up, our driveway was all those rocks and I used to love walking on them in my bare feet\. Wanted to give you something that reminded me of home\. Xoxoxo


---

### 873. msg_6201

**You** - 2025-05-01T09:23:09

That was more than a little thing\.\. you are breaking down my work resolve\.\. gawd\. I cannot keep loving you more but I do\.\. thank you so much this means\.\. everything especially now… ❤️❤️❤️❤️ you are my home\.


---

### 874. msg_6202

**You** - 2025-05-01T09:26:03

Reaction: ❤️ from Meredith Lamb
I wish I could keep it out but I put it in with the cork and the cards\.\. I will always hold on to that\.


---

### 875. msg_6203

**You** - 2025-05-01T15:52:33

I am likely going to leave soon\.  But you made my day today\.\. just wanted you to know that\.  I love you and if I could show you right now I would\.  I will check on to see if you can chat later not to see if you are ok\.\. I know you don’t want me to do that lol\.


---

### 876. msg_6204

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T16:20:29

Good job getting out of here\. Lol ❤️


---

### 877. msg_6205

**You** - 2025-05-01T16:21:50

Errrrrrrrrrrrrrrrrr yeah that was a fail but I am leaving now\.


---

### 878. msg_6206

**You** - 2025-05-01T17:08:30

So didn’t leave I suck


---

### 879. msg_6207

**You** - 2025-05-01T17:08:48

Can you send me the contact info for your therapist if you are comfortable with that meant to follow up


---

### 880. msg_6208

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:10:54

Wouldn’t that be weird?


---

### 881. msg_6209

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:10:57

lol


---

### 882. msg_6210

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:11:47

Like she would be getting the same story from both sides??


---

### 883. msg_6211

**You** - 2025-05-01T17:14:42

Oh well then don’t for sure\.\. I had mentioned it previously you seemed open it’s ok


---

### 884. msg_6212

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:15:08

I mean if she is fine with it I’m fine with it


---

### 885. msg_6213

**You** - 2025-05-01T17:18:27

I am good either way you just said she was good


---

### 886. msg_6214

**You** - 2025-05-01T17:18:42

Whatever you are comfortable with


---

### 887. msg_6215

**You** - 2025-05-01T17:18:48

More whiplash at home


---

### 888. msg_6216

**You** - 2025-05-01T17:18:54

Going to be a fun night


---

### 889. msg_6217

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:19:49

https://midtowntorontocounselling\.com/


---

### 890. msg_6218

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:20:18

I see Allison


---

### 891. msg_6219

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:20:27

>
What now


---

### 892. msg_6220

**You** - 2025-05-01T17:32:33

No one will go back now


---

### 893. msg_6221

**You** - 2025-05-01T17:32:48

And why don’t you ask Allison firsthand


---

### 894. msg_6222

**You** - 2025-05-01T17:32:51

First


---

### 895. msg_6223

**You** - 2025-05-01T17:33:05

Don’t want this to be weird


---

### 896. msg_6224

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:35:04

lol I don’t talk to her again until tues


---

### 897. msg_6225

**You** - 2025-05-01T17:35:18

I can wait


---

### 898. msg_6226

**You** - 2025-05-01T17:35:22

It’s fine


---

### 899. msg_6227

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:36:31

Okay


---

### 900. msg_6228

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:37:13

I think there will be a lot more flip flopping with your family\. It isn’t a minor change…\. So will take some time


---

### 901. msg_6229

**You** - 2025-05-01T17:37:27

We will see I don’t know


---

### 902. msg_6230

**You** - 2025-05-01T17:37:43

I am very frustrated


---

### 903. msg_6231

**You** - 2025-05-01T17:37:53

But I have to chill


---

### 904. msg_6232

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:38:30

Yes, time is the only solution unfortunately here\.


---

### 905. msg_6233

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:38:44

Things settle with time and the dust needs to settle a bit still


---

### 906. msg_6234

**You** - 2025-05-01T17:39:20

This seems so logical to me


---

### 907. msg_6235

**You** - 2025-05-01T17:39:30

But yeah Gracie is hardly that


---

### 908. msg_6236

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:41:34

She just wants her parents to stay together


---

### 909. msg_6237

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:41:37

At any cost


---

### 910. msg_6238

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:41:46

That will be hard to get over


---

### 911. msg_6239

**You** - 2025-05-01T17:43:31

Yep but if we had t had to deal with so much over past 5 years I would have more empathy\.


---

### 912. msg_6240

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:45:45

Yeah it has to be draining


---

### 913. msg_6241

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:45:51

K I’m driving home now\!


---

### 914. msg_6242

**You** - 2025-05-01T17:46:04

It took everything and more ok leave ❤️


---

### 915. msg_6243

**You** - 2025-05-01T17:46:11

Reaction: ❤️ from Meredith Lamb
Talk later


---

### 916. msg_6244

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T17:59:42

Reality check\. My childhood best friend’s hubby just diagnosed with cancer\. Life is short\.


---

### 917. msg_6245

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:00:01

Grew up with him also\.


---

### 918. msg_6246

**You** - 2025-05-01T18:01:14

Ah that sucks\.\.  I have lost a few friends along the way recently too\.


---

### 919. msg_6247

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:01:43

😬


---

### 920. msg_6248

**You** - 2025-05-01T18:01:49

I mean this is kind of what i said to you about us getting older and me wanting to make the most of the time we have


---

### 921. msg_6249

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:02:08

Our limited time lol


---

### 922. msg_6250

**You** - 2025-05-01T18:02:14

For now limited


---

### 923. msg_6251

**You** - 2025-05-01T18:02:28

For later I am hoping daily\.


---

### 924. msg_6252

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:03:39

We can dream :\)


---

### 925. msg_6253

**You** - 2025-05-01T18:04:39

I mean I have to hope\. It is what I want so it is what it is will plan for


---

### 926. msg_6254

**You** - 2025-05-01T18:05:17

Spending whatever time I have for however long we get is what I want


---

### 927. msg_6255

**You** - 2025-05-01T18:07:35

Or whatever time you will have me for maybe when I get old you will be like meh whatever


---

### 928. msg_6256

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:08:22

>
I would never… 👎


---

### 929. msg_6257

**You** - 2025-05-01T18:09:25

lol well I hope to get to see ☺️


---

### 930. msg_6258

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:10:56

Reaction: ❤️ from Scott Hicks
You will ❤️


---

### 931. msg_6259

**You** - 2025-05-01T18:12:35

Still thinking about the rock\.  Wish we had 20 extra years so much I want to do with you\.


---

### 932. msg_6260

**You** - 2025-05-01T18:13:29

Well about to drive into the shitstorm best of luck with yours let me know if you decide\. To tell kids as I hope it goes ok\.  Otherwise at gym tonight again can chat whenever


---

### 933. msg_6261

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:16:01

K ttyl xo


---

### 934. msg_6262

**You** - 2025-05-01T18:16:05

Do


---

### 935. msg_6263

**You** - 2025-05-01T18:16:09

Xo


---

### 936. msg_6264

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:17:06

Ps\. Andrew at a “happy hour”


---

### 937. msg_6265

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:17:14

lol


---

### 938. msg_6266

**You** - 2025-05-01T18:22:53

Ffs I wish we could get another happy hour


---

### 939. msg_6267

**You** - 2025-05-01T18:23:00

The last few were kinda fun


---

### 940. msg_6268

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:24:47

Totally


---

### 941. msg_6269

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:25:44

Depending on what time he gets home not sure if telling kids tonight\. Sigh this happy hour was last minute


---

### 942. msg_6270

**You** - 2025-05-01T18:26:01

lol maybe he needs liquid courage?


---

### 943. msg_6271

**You** - 2025-05-01T18:26:08

Shit


---

### 944. msg_6272

**You** - 2025-05-01T18:26:17

I forgot he doesn’t drink


---

### 945. msg_6273

**You** - 2025-05-01T18:26:22

What is happy hour the


---

### 946. msg_6274

**You** - 2025-05-01T18:26:24

Then


---

### 947. msg_6275

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:26:27

lol


---

### 948. msg_6276

**You** - 2025-05-01T18:27:57

So confused


---

### 949. msg_6277

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:41:49

On and on and on and on and on…\. This is the freaking neverending story

*1 attachment(s)*


---

### 950. msg_6278

**You** - 2025-05-01T18:44:20

Well you can give him the choice to be part
Of it or not but that to continue on this way will only further confuse the children to what they are surely catching on to by now and can only get worse as it drags on\.


---

### 951. msg_6279

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:46:59


*1 attachment(s)*


---

### 952. msg_6280

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:49:11

Omg he asked if we are preparing a script/notes or just winging it


---

### 953. msg_6281

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:49:18

I can’t even anymore…\.\.


---

### 954. msg_6282

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:49:23

A script


---

### 955. msg_6283

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:49:25

wtf


---

### 956. msg_6284

**You** - 2025-05-01T18:52:43

I mean I think you just need to say you are done he doesn’t set the time table you have been patient\.\. and accommodating, played your part bud the truth which you will continue to do from them and now his time is up


---

### 957. msg_6285

**You** - 2025-05-01T18:52:58

lol I don’t know how you have the patience I would have snapped long before now


---

### 958. msg_6286

**You** - 2025-05-01T18:54:55

I mean I think he will just continue to find excuses to delay it will be something else when he gets back \.\. I mean  I feel for you\.\. wish I could help more


---

### 959. msg_6287

**You** - 2025-05-01T18:56:03

Sorry I am probably not helping


---

### 960. msg_6288

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:56:06

I will likely just tell them myself lol


---

### 961. msg_6289

**You** - 2025-05-01T18:56:35

I mean that might be your only option at this point because he will not seem to allow this to proceed


---

### 962. msg_6290

**You** - 2025-05-01T18:58:08

Only thing is how will he react he won’t do anything stupid will he


---

### 963. msg_6291

**You** - 2025-05-01T18:58:26

I know you can take care of yourself this isn’t that


---

### 964. msg_6292

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T18:59:46

I will wait until he gets home from whatever he is doing 😝


---

### 965. msg_6293

**You** - 2025-05-01T19:00:12

Again you never explained the happy hour thing just lol\.\. is this like wolf of wall street shit


---

### 966. msg_6294

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:00:25

No idea\!


---

### 967. msg_6295

**You** - 2025-05-01T19:00:28

Or just a bunch of guys


---

### 968. msg_6296

**You** - 2025-05-01T19:00:31

Sh ok


---

### 969. msg_6297

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:00:37

lol no not guys only


---

### 970. msg_6298

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:00:41

I do know that


---

### 971. msg_6299

**You** - 2025-05-01T19:00:52

Ah ok\.\. brazen


---

### 972. msg_6300

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:00:59

It might be code for having dinner with someone\. Who knows


---

### 973. msg_6301

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:01:04

Could be anything


---

### 974. msg_6302

**You** - 2025-05-01T19:02:34

Man… I just…


---

### 975. msg_6303

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:03:26

He used to do them a lot in his 30s\. Then an incident happened in 2016 and he stopped\. When we separated officially he started again lol


---

### 976. msg_6304

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:03:43

I honestly don’t care but I wanted to tell them tonight


---

### 977. msg_6305

**You** - 2025-05-01T19:04:42

I think it is valid will further force him to continue to move forward and not
Drag his feet\.


---

### 978. msg_6306

**You** - 2025-05-01T19:06:02

While
You don’t plan on involving lawyers to negotiate they will be drawing up your contract right\.\. Andrew just doesn’t seem
Particularly trustworthy\.


---

### 979. msg_6307

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:07:12

Yeah…


---

### 980. msg_6308

**You** - 2025-05-01T19:08:19

Uggh this is sucky while I think you will feel better after telling them I still kinda wish he had have just gone to cottage


---

### 981. msg_6309

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:12:12

Oh guess who arrived home when I threatened to tell them myself\. He was out of breath lol


---

### 982. msg_6310

**You** - 2025-05-01T19:12:58

lol well good luck mer I know it is going to be challenging but at least one of you is an adult


---

### 983. msg_6311

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:41:41

I found a big “mistake” in his spreadsheet and he says he doesn’t know how it happened


---

### 984. msg_6312

**You** - 2025-05-01T19:41:58

Yeah sure he doesn’t


---

### 985. msg_6313

**You** - 2025-05-01T19:42:01

lol


---

### 986. msg_6314

**You** - 2025-05-01T19:42:04

Good for you


---

### 987. msg_6315

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:42:07

My daughter is going to swimming so… gah


---

### 988. msg_6316

**You** - 2025-05-01T19:42:17

Oh so blocked again


---

### 989. msg_6317

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:42:20

It was $100k


---

### 990. msg_6318

**You** - 2025-05-01T19:42:22

Ah well


---

### 991. msg_6319

**You** - 2025-05-01T19:42:30

Monday


---

### 992. msg_6320

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:42:51

Like wtf


---

### 993. msg_6321

**You** - 2025-05-01T19:42:51

Or whenever it will happen eventually and then you can figure out what is next


---

### 994. msg_6322

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:43:23

He was padding to make it look like I was getting more assets


---

### 995. msg_6323

**You** - 2025-05-01T19:43:28

I mean you cannot trust him which is why lawyer\.\. the guy feels you are at fault he owes you nothing


---

### 996. msg_6324

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:43:32

Now he’s all worried he has to sell


---

### 997. msg_6325

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T19:43:54

Yeah contemplating a lawyer now\. Will think tonight


---

### 998. msg_6326

**You** - 2025-05-01T19:59:08

Sucks mer tough spot and I know you wanted to move this forward well you can decide on lawyers at least to review it and inform you and maybe tell girls after swimming?


---

### 999. msg_6327

**You** - 2025-05-01T19:59:19

So you can feel you made some progress


---

### 1000. msg_6328

**You** - 2025-05-01T20:52:38

You back in the budgets tonight?


---

### 1001. msg_6329

**You** - 2025-05-01T20:55:40

Well on my side took two hours of j screaming she is trapped
Here and it is my fault and she will need to live in some crappy townhouse etc… I said what do you think I will be living in …\.
She is just fucking mad because no one wants to go back to Moncton\.  Holy hell\.  At gym now going to work this out\.


---

### 1002. msg_6330

**You** - 2025-05-01T21:02:54

I told her I would take both of them and work it out but she won’t do that either


---

### 1003. msg_6331

**You** - 2025-05-01T21:14:04

Doing treadmill listening to our song now or at least I am calling it that


---

### 1004. msg_6332

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:14:10

Ugh\. Crappy night too\. Things have gotten very nasty\. I think now I might just take a $300k lump sum spousal \+ monthly child  and be done\.


---

### 1005. msg_6333

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:14:19

We are going to try to find a lawyer tomorrow


---

### 1006. msg_6334

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:14:29

Meet as soon as we can and be done


---

### 1007. msg_6335

**You** - 2025-05-01T21:14:30

Array hun


---

### 1008. msg_6336

**You** - 2025-05-01T21:14:35

Sorry


---

### 1009. msg_6337

**You** - 2025-05-01T21:14:45

Kids ok


---

### 1010. msg_6338

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:14:50

Not sure on telling kids


---

### 1011. msg_6339

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:14:55

Maelle at bronze cross


---

### 1012. msg_6340

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:15:32

Maelle’s bday is Monday and she wants me to take her to Yorkdale tomorrow night after work


---

### 1013. msg_6341

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:15:50

He said he’d stay home from cottage to tell them and I’m like ughhhhh ummmm


---

### 1014. msg_6342

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:15:58

I’d rather he go honestly


---

### 1015. msg_6343

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:16:08

I want to have a nice weekend


---

### 1016. msg_6344

**You** - 2025-05-01T21:16:17

I totally get it\.\. makes
Sense


---

### 1017. msg_6345

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:16:38

I’m thinking maybe we tell them wed or thurs


---

### 1018. msg_6346

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:16:50

If they want to stay home from school for a day they can


---

### 1019. msg_6347

**You** - 2025-05-01T21:17:14

Seems like you are trying best you can


---

### 1020. msg_6348

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:17:23

But we will see\. He is mad and doesn’t want to go to cottage now


---

### 1021. msg_6349

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:17:32

Ughhhhhhhhhhh


---

### 1022. msg_6350

**You** - 2025-05-01T21:17:43

Asshole


---

### 1023. msg_6351

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:17:55

He wants me to apologize for telling them in December when he was in the uk


---

### 1024. msg_6352

**You** - 2025-05-01T21:18:15

Tell him to apologize
In front of kids for text and for 2016


---

### 1025. msg_6353

**You** - 2025-05-01T21:18:34

And you would be happy to apologize for December


---

### 1026. msg_6354

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:18:50

I am not apologizing ever I told him


---

### 1027. msg_6355

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:19:04

That was directly correlated to his actions


---

### 1028. msg_6356

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:19:10

Will never apologize


---

### 1029. msg_6357

**You** - 2025-05-01T21:19:21

Yeah well he doesn’t deserve shit


---

### 1030. msg_6358

**You** - 2025-05-01T21:19:31

Not after that


---

### 1031. msg_6359

**You** - 2025-05-01T21:19:37

Or whatever came\. Edie’s


---

### 1032. msg_6360

**You** - 2025-05-01T21:19:39

Before


---

### 1033. msg_6361

**You** - 2025-05-01T21:19:48

Doesn’t sound like you had a happy life for a while


---

### 1034. msg_6362

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:20:06

We just need to live apart asap


---

### 1035. msg_6363

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:20:11

It is getting bad


---

### 1036. msg_6364

**You** - 2025-05-01T21:20:23

I am worried about the same thing


---

### 1037. msg_6365

**You** - 2025-05-01T21:20:50

For me I know you got you lol


---

### 1038. msg_6366

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:22:22

lol thank you


---

### 1039. msg_6367

**You** - 2025-05-01T21:22:42

Hehe


---

### 1040. msg_6368

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:22:51

Good save


---

### 1041. msg_6369

**You** - 2025-05-01T21:22:59

Reaction: ❤️ from Meredith Lamb
But listen I am not to proud you can rescue me whenever you want


---

### 1042. msg_6370

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:23:58

https://open\.spotify\.com/track/37LNNQNbL1YLyutBG6aWRx?si=NdlXu12xRt\-99WJWmsdllg


---

### 1043. msg_6371

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:24:45

Haha


---

### 1044. msg_6372

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T21:24:51

Actually a good song


---

### 1045. msg_6373

**You** - 2025-05-01T21:25:00

I know I like that song\.


---

### 1046. msg_6374

**You** - 2025-05-01T21:25:49

Back night workout with Morgan wallen se how this goes


---

### 1047. msg_6375

**You** - 2025-05-01T21:54:51

I mean I like him but not feeling it


---

### 1048. msg_6376

**You** - 2025-05-01T21:55:28

He is just to smooth need something with a kick to workout\.


---

### 1049. msg_6377

**You** - 2025-05-01T21:57:23

And that stache is so distracting


---

### 1050. msg_6378

**You** - 2025-05-01T22:01:56

https://open\.spotify\.com/track/6OMwRbRH5SnUDNNvga360Q?si=pAs9FjuKSpm7aaZOHv0Fog&context=spotify%3Asearch%3Achampion%2Bmiranda
Thinking of you my love you are this song\.


---

### 1051. msg_6379

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:03:17

Sorry, final conversation for the night\. Gah


---

### 1052. msg_6380

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:03:20

All done


---

### 1053. msg_6381

**You** - 2025-05-01T22:03:42

Sorry you had to go through all that been many lights in a row fucking sucks


---

### 1054. msg_6382

**You** - 2025-05-01T22:03:47

Listen to the song and feel better


---

### 1055. msg_6383

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:04:20

Yeah we are both done, exhausted and so done with each other\.


---

### 1056. msg_6384

**You** - 2025-05-01T22:05:02

I mean I am sad for what you have had to go through but I am happy if you are closer to where you want to be


---

### 1057. msg_6385

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:05:38

Yeah\. Lawyer next up\.


---

### 1058. msg_6386

**You** - 2025-05-01T22:05:48

Fack


---

### 1059. msg_6387

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:05:50

We are telling kids thurs


---

### 1060. msg_6388

**You** - 2025-05-01T22:05:55

Kk


---

### 1061. msg_6389

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:05:58

He’s going to cottage thank god


---

### 1062. msg_6390

**You** - 2025-05-01T22:06:04

Gl till then


---

### 1063. msg_6391

**You** - 2025-05-01T22:14:37

Not last chat?  Deja vu


---

### 1064. msg_6392

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:15:51

Huh? Sorry, just sitting here\. I miss you\.


---

### 1065. msg_6393

**You** - 2025-05-01T22:16:12

You ok??


---

### 1066. msg_6394

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:16:23

Yah


---

### 1067. msg_6395

**You** - 2025-05-01T22:16:32

Miss you always could give you a great big hug right now


---

### 1068. msg_6396

**You** - 2025-05-01T22:16:59

Sucks being apart\.\. any chance
You have to go out in your own this weekend anywhere during the day\.


---

### 1069. msg_6397

**You** - 2025-05-01T22:17:24

I could meet you just to say hey give you that big hug and chat for a few mins only


---

### 1070. msg_6398

**You** - 2025-05-01T22:17:32

I am ok if not


---

### 1071. msg_6399

**You** - 2025-05-01T22:17:35

Just thinking


---

### 1072. msg_6400

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:18:15

Yeah not 100%\. I have to buy Maelle bday gifts\.


---

### 1073. msg_6401

**You** - 2025-05-01T22:18:27

I know you got shopping tommorrow night and prep for bday I am sure over the weekend


---

### 1074. msg_6402

**You** - 2025-05-01T22:18:46

Just thought there might be an hour no worries mer just trying to lighten your load lol not make it worse


---

### 1075. msg_6403

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:18:48

I also have to get Maelle to a bat mitzvah for 6\.30pm on Sat night and Marlowe to a bat mitzvah for 7pm on Sat night\. 😵‍💫


---

### 1076. msg_6404

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:18:53

Somehow


---

### 1077. msg_6405

**You** - 2025-05-01T22:18:55

Sok


---

### 1078. msg_6406

**You** - 2025-05-01T22:18:58

Dun worry


---

### 1079. msg_6407

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:19:03

I might see if Marlowe can carpool


---

### 1080. msg_6408

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:19:26

I have some planning to do


---

### 1081. msg_6409

**You** - 2025-05-01T22:20:13

Yep take care of your stuff all
Good


---

### 1082. msg_6410

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:20:38

Are you worried we are going to drift if we don’t get to see each other?


---

### 1083. msg_6411

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:20:49

Is that what your head was thinking last night


---

### 1084. msg_6412

**You** - 2025-05-01T22:20:58

Nope


---

### 1085. msg_6413

**You** - 2025-05-01T22:21:10

I was worried you would think it not worth the trouble eventually


---

### 1086. msg_6414

**You** - 2025-05-01T22:21:30

Or maybe you might drift sure


---

### 1087. msg_6415

**You** - 2025-05-01T22:21:33

Possibly


---

### 1088. msg_6416

**You** - 2025-05-01T22:21:35

Not me


---

### 1089. msg_6417

**You** - 2025-05-01T22:21:38

And not you


---

### 1090. msg_6418

**You** - 2025-05-01T22:21:45

Really after this morning


---

### 1091. msg_6419

**You** - 2025-05-01T22:22:02

But I am still worried about the not worth the trouble you have other priorities


---

### 1092. msg_6420

**You** - 2025-05-01T22:22:06

More to lift than me


---

### 1093. msg_6421

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:22:52

Maybe you will think my busy life isn’t worth YOUR trouble lol


---

### 1094. msg_6422

**You** - 2025-05-01T22:23:11

No mer I would happily join you in that just life


---

### 1095. msg_6423

**You** - 2025-05-01T22:23:15

Happily


---

### 1096. msg_6424

**You** - 2025-05-01T22:24:16

Honestly I have pretty blunt even today in the office and last night there has never been and never will be anyone other than you for me I have never been more certain of anything in my life\.\. cannot say it more plainly


---

### 1097. msg_6425

**You** - 2025-05-01T22:24:36

I am just trying to find time to see you because I love you and want to hug you and make you feel better not rescue you\.


---

### 1098. msg_6426

**You** - 2025-05-01T22:24:42

Not because I am worried


---

### 1099. msg_6427

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:25:06

Yeah I wish we could…\.\.


---

### 1100. msg_6428

**You** - 2025-05-01T22:25:54

Well if you can find an hour at all I say or Sunday I will try to find a way to meet you halfway wherever you want\.  Open offer no expectations


---

### 1101. msg_6429

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:27:45

We will see\. Hard with my little shadow…


---

### 1102. msg_6430

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:27:49

:p


---

### 1103. msg_6431

**You** - 2025-05-01T22:27:57

I get it


---

### 1104. msg_6432

**You** - 2025-05-01T22:31:15

Well maybe we video chat tomorrow night whatever works mer I am up for it


---

### 1105. msg_6433

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:33:26

Hmmmh possible …


---

### 1106. msg_6434

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:37:08

I think I’m going to just go to bed early right now\. Feeling super exhausted and drained\.


---

### 1107. msg_6435

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:37:36

I love you, miss you, … 😕


---

### 1108. msg_6436

**You** - 2025-05-01T22:38:23

Love
You too same xoxox chat tomorrow if you have time


---

### 1109. msg_6437

**You** - 2025-05-01T22:41:46

Reaction: ❤️ from Meredith Lamb
Hope
You dream
Of home tonight and better times


---

### 1110. msg_6438

**You** - 2025-05-02T00:14:21

Check out this listing
https://realtor\.ca/real\-estate/28055316/18\-annable\-lane\-ajax\-south\-east\-south\-east?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 1111. msg_6439

**You** - 2025-05-02T00:18:10

Alright honey hoping you are in a good sleep\.\. I had a fantastic workout and I am wiped and I will be going to bed dreaming of you\.  Love you, chat in morning\.  ❤️❤️❤️❤️


---

### 1112. msg_6440

**You** - 2025-05-02T06:46:30

Reaction: ❤️ from Meredith Lamb
It worked 🥰


---

### 1113. msg_6441

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T07:07:44

>
Nice place\. $$


---

### 1114. msg_6442

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T07:09:20

Not a fan of waking up to this reality\. \(In all aspects\.\) 😵‍💫 But being patient\.


---

### 1115. msg_6443

**You** - 2025-05-02T08:11:31

I’m sry I would give anything to wake up role over and see you\.


---

### 1116. msg_6444

**You** - 2025-05-02T08:12:21

And I am really trying on my side maybe I skip gym for a few days and do worry around here won’t get done otherwise


---

### 1117. msg_6445

**You** - 2025-05-02T08:12:34

But the gym right now is my escape


---

### 1118. msg_6446

**You** - 2025-05-02T08:12:56

Still just want to be with you


---

### 1119. msg_6447

**You** - 2025-05-02T08:13:52

>
Did you have a bad sleep or did he bug you again?


---

### 1120. msg_6448

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:16:49

No more bugging\. He had work to do for a meeting today thank god\. Sleep was meh\. This place just feels really heavy\.  I just don’t fit here anymore which makes it heavier\. Then having to stay fully normal or composed for my kids is just draining\. It is all draining and heavy\. Nothing like last weekend…\.\.


---

### 1121. msg_6449

**You** - 2025-05-02T08:18:34

Yeah i know this does suck but i promise those weekends will become nights and days eventually


---

### 1122. msg_6450

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:21:46

Holding you to that\.


---

### 1123. msg_6451

**You** - 2025-05-02T08:22:46

Same mer\. Same\.


---

### 1124. msg_6452

**You** - 2025-05-02T08:29:11

Did you guys resolve anything last night after your final chat I know you went to bed shortly thereafter


---

### 1125. msg_6453

**You** - 2025-05-02T08:29:36

>
It’s a good price for what you get and I will be able
To afford it


---

### 1126. msg_6454

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:38:15

So I think we resolved a spreadsheet to take to a lawyer\. Just picked one now


---

### 1127. msg_6455

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:38:30

He can’t do a $300k up front lump sum without selling


---

### 1128. msg_6456

**You** - 2025-05-02T08:39:33

All you do is simply determine the value of what he owes the net present value of the owe subtract
The lump sum and then stretch the balance back out over
The term


---

### 1129. msg_6457

**You** - 2025-05-02T08:39:50

Hopefully he can do that without losing 100k along the way


---

### 1130. msg_6458

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:39:56

So I can get $150k up front and the rest monthly over 8 hrs


---

### 1131. msg_6459

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:40:00

8 yrs


---

### 1132. msg_6460

**You** - 2025-05-02T08:40:24

Again just determines what value the rest equals to determine if it is fair


---

### 1133. msg_6461

**You** - 2025-05-02T08:40:39

And it matters how he split the assets


---

### 1134. msg_6462

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:40:39

BUT he wants to put a clause in that if I marry or cohabitate, that changes


---

### 1135. msg_6463

**You** - 2025-05-02T08:40:47

Refuse it


---

### 1136. msg_6464

**You** - 2025-05-02T08:40:50

I am refusing too


---

### 1137. msg_6465

**You** - 2025-05-02T08:41:09

He will relent on that he has no standing


---

### 1138. msg_6466

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:41:16

Asset split was equalized


---

### 1139. msg_6467

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:41:23

Except for his $200k


---

### 1140. msg_6468

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:41:37

So I got most of our savings to equalize it


---

### 1141. msg_6469

**You** - 2025-05-02T08:41:49

So then he is not using any assets to offset the lump sum


---

### 1142. msg_6470

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:41:56

Right


---

### 1143. msg_6471

**You** - 2025-05-02T08:41:57

Not like I am doing


---

### 1144. msg_6472

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:42:03

He was before last night


---

### 1145. msg_6473

**You** - 2025-05-02T08:42:08

Yeah so then the calc really matters to
You


---

### 1146. msg_6474

**You** - 2025-05-02T08:42:25

Btw you do hold
All
The power
Here he would never ever want to go to court


---

### 1147. msg_6475

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:42:27

Our assets are almost equal before equalization


---

### 1148. msg_6476

**You** - 2025-05-02T08:42:39

They would deal with you being home and your education in a harsh way


---

### 1149. msg_6477

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:42:47

We just have this $100k sitting in cash


---

### 1150. msg_6478

**You** - 2025-05-02T08:42:48

And then add the text and he would be decimated


---

### 1151. msg_6479

**You** - 2025-05-02T08:42:52

Anyhow


---

### 1152. msg_6480

**You** - 2025-05-02T08:42:56

I am mean like that


---

### 1153. msg_6481

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:43:05

He split the $100 50/50


---

### 1154. msg_6482

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:43:20

Now I have $93 of it in the actual proper equalization


---

### 1155. msg_6483

**You** - 2025-05-02T08:43:45

But he stands to inherit a fair amount too I bet\.


---

### 1156. msg_6484

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:02

Doubt it


---

### 1157. msg_6485

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:09

His step dad is insane


---

### 1158. msg_6486

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:16

His step dad will take everything


---

### 1159. msg_6487

**You** - 2025-05-02T08:45:20

Eesh


---

### 1160. msg_6488

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:20

His mom will let him


---

### 1161. msg_6489

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:29

She has already said everything goes to Jeff


---

### 1162. msg_6490

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:35

His mom is weird


---

### 1163. msg_6491

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:48

Step dad hates Andrew


---

### 1164. msg_6492

**You** - 2025-05-02T08:45:54

Well yeah that sounds off… still
I feel like you hold more cards here mer


---

### 1165. msg_6493

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:45:55

I bet Andrew gets nothing


---

### 1166. msg_6494

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:46:07

His brother is Jeff’s son


---

### 1167. msg_6495

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:46:14

His bro will get everything


---

### 1168. msg_6496

**You** - 2025-05-02T08:46:33

Hmm well that is a bit twisted


---

### 1169. msg_6497

**You** - 2025-05-02T08:46:45

I have seen it in my fam too though


---

### 1170. msg_6498

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:46:55

Yeah it is pretty common


---

### 1171. msg_6499

**You** - 2025-05-02T08:46:56

Just not with me or Katie cousins etc


---

### 1172. msg_6500

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:47:07

But will happen to Andrew and his sister for sure


---

### 1173. msg_6501

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:47:18

His mom has basically told him


---

### 1174. msg_6502

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:47:22

Just weird


---

### 1175. msg_6503

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:47:34

It is the reason why the cottage is so important to Andrew


---

### 1176. msg_6504

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:47:44

He doesn’t depend on his mom and Jeff and their cottage


---

### 1177. msg_6505

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:48:14

We bought the cottage after they last minute cancelled one of our cottage trips and didn’t let us go


---

### 1178. msg_6506

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:48:29

Andrew had a temper tantrum and was like “fine I will buy my own”


---

### 1179. msg_6507

**You** - 2025-05-02T08:48:42

Man


---

### 1180. msg_6508

**You** - 2025-05-02T08:48:53

We are very different people


---

### 1181. msg_6509

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:49:19

lol


---

### 1182. msg_6510

**You** - 2025-05-02T08:49:36

I mean only you could truly know that


---

### 1183. msg_6511

**You** - 2025-05-02T08:49:40

But seems like to me


---

### 1184. msg_6512

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:49:43

So I’m trying to respect some of the insaneness in his family


---

### 1185. msg_6513

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:50:11

>
I mean we haven’t lived together :\)


---

### 1186. msg_6514

**You** - 2025-05-02T08:50:51

Well I guess from what you do know or are aware of then lol


---

### 1187. msg_6515

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:50:51

If j marries or cohabitates do you stop paying or are you doing all lump sum?


---

### 1188. msg_6516

**You** - 2025-05-02T08:51:11

I am going to all lump sum if I can and I won’t change anything on marriage or cohabitation


---

### 1189. msg_6517

**You** - 2025-05-02T08:51:25

It will be much much harder
For me


---

### 1190. msg_6518

**You** - 2025-05-02T08:51:49

But it
Is safer for her and the kids still we will have a lawyer
Look and make a recommendation


---

### 1191. msg_6519

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:52:53

And you had no more flip flopping last night or this morning


---

### 1192. msg_6520

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:53:28

Last night we ALMOST got into a conversation about how I contributed nothing to his courses and actually made his life harder


---

### 1193. msg_6521

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:53:34

I was honestly speachless


---

### 1194. msg_6522

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:53:50

Then I was just like “I don’t think we should talk about this”


---

### 1195. msg_6523

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:54:18

I literally did everything for years


---

### 1196. msg_6524

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:54:20

Everything


---

### 1197. msg_6525

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:54:28

I couldn’t even respond


---

### 1198. msg_6526

**You** - 2025-05-02T08:54:28

I had no more let’s try again for days now


---

### 1199. msg_6527

**You** - 2025-05-02T08:54:35

I solution on housing


---

### 1200. msg_6528

**You** - 2025-05-02T08:55:10

>
Like where is he coming from… I think he will attack anything for the sake of it


---

### 1201. msg_6529

**You** - 2025-05-02T08:55:21

No solution sorry in housing


---

### 1202. msg_6530

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:55:24

Yeah he also remakes the past


---

### 1203. msg_6531

**You** - 2025-05-02T08:55:26

She is just miserable


---

### 1204. msg_6532

**You** - 2025-05-02T08:55:32

She yelled at me when I got home


---

### 1205. msg_6533

**You** - 2025-05-02T08:55:37

And tried to show her the listing


---

### 1206. msg_6534

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:55:42

Do they want to stay in house and you just have an apt in basement? Lol


---

### 1207. msg_6535

**You** - 2025-05-02T08:55:44

Originally it was for her


---

### 1208. msg_6536

**You** - 2025-05-02T08:55:51

They would yea


---

### 1209. msg_6537

**You** - 2025-05-02T08:55:55

Def


---

### 1210. msg_6538

**You** - 2025-05-02T08:56:02

Cause then they could keep the house


---

### 1211. msg_6539

**You** - 2025-05-02T08:56:11

And who cares about me because I caused this


---

### 1212. msg_6540

**You** - 2025-05-02T08:56:17

Essentially


---

### 1213. msg_6541

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:56:33

I mean could you make a basement apt for the short term or is that ridiculous


---

### 1214. msg_6542

**You** - 2025-05-02T08:56:40

She is trapped because I wouldn’t go back to Moncton with no job or prospects on a whim


---

### 1215. msg_6543

**You** - 2025-05-02T08:56:50

It is a ridiculous investment


---

### 1216. msg_6544

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:57:00

Yeah likely


---

### 1217. msg_6545

**You** - 2025-05-02T08:57:06

And would be impossible regardless maddie wants out as welll


---

### 1218. msg_6546

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:57:16

She right


---

### 1219. msg_6547

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:57:23

\*ah right


---

### 1220. msg_6548

**You** - 2025-05-02T08:57:42

But Gracie still won’t go to Moncton which is the lynch pin


---

### 1221. msg_6549

**You** - 2025-05-02T08:58:22

So 133/83 this morning and I am
Down 19\.5 lbs


---

### 1222. msg_6550

**You** - 2025-05-02T08:58:38

Did a 30 min interval training on the treadmill last night


---

### 1223. msg_6551

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T08:58:39

Holy crap


---

### 1224. msg_6552

**You** - 2025-05-02T08:58:41

Eesh


---

### 1225. msg_6553

**You** - 2025-05-02T08:58:43

Hard


---

### 1226. msg_6554

**You** - 2025-05-02T08:58:54

After the 1 hr on back


---

### 1227. msg_6555

**You** - 2025-05-02T08:58:58

Fun\!\!


---

### 1228. msg_6556

**You** - 2025-05-02T08:59:10

Honestly you are
Great
Motivation


---

### 1229. msg_6557

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:00:18

lol


---

### 1230. msg_6558

**You** - 2025-05-02T09:01:05

Reaction: 😂 from Meredith Lamb
Seriously not joking thought about stopping in treadmill like 3/4 through\.


---

### 1231. msg_6559

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:01:22

So musarrat starts on Monday and I’m having a team meeting and lunch and didn’t invite you bc I don’t want to be distracted


---

### 1232. msg_6560

**You** - 2025-05-02T09:01:26

But I have trained before I know how to focus on a mental image


---

### 1233. msg_6561

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:01:30

I will intro her to you separately


---

### 1234. msg_6562

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:01:34

LOL


---

### 1235. msg_6563

**You** - 2025-05-02T09:01:42

No worries


---

### 1236. msg_6564

**You** - 2025-05-02T09:01:51

I don’t eat lunches wel not much at least


---

### 1237. msg_6565

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:02:14

Well we are doing intros and lunch  but we will intro you separate


---

### 1238. msg_6566

**You** - 2025-05-02T09:02:37

Sok


---

### 1239. msg_6567

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:02:42

And I did all the on boarding right\. She has everything


---

### 1240. msg_6568

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:02:49

\*pats back


---

### 1241. msg_6569

**You** - 2025-05-02T09:03:18

Hav e to drive maddie to school but I am free till 11 and then all
Through lunch and on until 2:30


---

### 1242. msg_6570

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:03:28

Kk


---

### 1243. msg_6571

**You** - 2025-05-02T09:03:38

Would love
To sit and chat if you have time tell me when and I will book an official
Meeting


---

### 1244. msg_6572

**You** - 2025-05-02T09:03:50

Will ping you when I am back


---

### 1245. msg_6573

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:31:10

I forgot to tell you that Michelle is so different now that she knows my situation\. She was SO suspicious before… I knew it


---

### 1246. msg_6574

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T09:31:14

Just got off a call with her


---

### 1247. msg_6575

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T10:17:39

So Andrew is WFH today bc he doesn’t care anymore and is going to cottage this afternoon\. Not sure what time he is leaving\. Doesn’t mean I can’t talk but I would be more careful\. He’s on calls most of the day by anyway


---

### 1248. msg_6576

**You** - 2025-05-02T10:20:54

Ok I mean we can talk this aft if that works better for you\.


---

### 1249. msg_6577

**You** - 2025-05-02T10:23:07

I can do whatever you want basically


---

### 1250. msg_6578

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T10:25:39

I’m free until 11\.30


---

### 1251. msg_6579

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T10:25:53

You need to respond to Jacky’s email tho


---

### 1252. msg_6580

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T10:26:01

And don’t be an ass about the service line


---

### 1253. msg_6581

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T10:26:02

lol


---

### 1254. msg_6582

**You** - 2025-05-02T10:26:11

lol


---

### 1255. msg_6583

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:23:54

Our first lawyer call just scheduled\. Tues 1pm


---

### 1256. msg_6584

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:24:15

Like a breath of fresh air… seriously


---

### 1257. msg_6585

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:38:58

K scrap that\. The lawyer won’t see us both


---

### 1258. msg_6586

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:39:04

We each have to have our own


---

### 1259. msg_6587

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:39:11

Omg can this just end already


---

### 1260. msg_6588

**You** - 2025-05-02T12:39:36

Mine will see us both


---

### 1261. msg_6589

**You** - 2025-05-02T12:39:45

Do you want me to give you the name


---

### 1262. msg_6590

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:39:47

This guy won’t


---

### 1263. msg_6591

**You** - 2025-05-02T12:40:05

Well some are
Like that


---

### 1264. msg_6592

**You** - 2025-05-02T12:40:09

I guess


---

### 1265. msg_6593

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:40:12

Yah


---

### 1266. msg_6594

**You** - 2025-05-02T12:40:45

Russell Alexander Collaborative Family Lawyers


---

### 1267. msg_6595

**You** - 2025-05-02T12:40:55

That is who I am filling out a form for now


---

### 1268. msg_6596

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:44:08

We wanted one nearby right at yeg \(building oeb is in\)


---

### 1269. msg_6597

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:44:12

Just easy


---

### 1270. msg_6598

**You** - 2025-05-02T12:57:51

Sure but I believe you will want one you can both see together or this will get very
Contentious although I still expect you would come out further ahead


---

### 1271. msg_6599

**You** - 2025-05-02T12:57:58

Just puts at further risk cottage and house


---

### 1272. msg_6600

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:58:24

Yeah I’m done\. Not negotiating anymore


---

### 1273. msg_6601

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:58:36

I just want it on paper and done


---

### 1274. msg_6602

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:58:54

I want the girls to get their home and cottage so it is what it is\. And it is fine


---

### 1275. msg_6603

**You** - 2025-05-02T12:59:13

As long as you feel you have enough to get to where you need to be\.
Beyond 8 years have you planned out how you will proceed


---

### 1276. msg_6604

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T12:59:54

I won’t be in this area beyond 8 yrs


---

### 1277. msg_6605

**You** - 2025-05-02T12:59:58

I mean pls tel me to shut it lol I am just thinking about how I thought this through for Jaimie


---

### 1278. msg_6606

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:00:02

Marlowe done high school in 6 yrs


---

### 1279. msg_6607

**You** - 2025-05-02T13:00:07

And I set it up so she will be fine beyond the term


---

### 1280. msg_6608

**You** - 2025-05-02T13:00:31

But if you rent you will have no equity to put down on a new home right


---

### 1281. msg_6609

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:00:37

If he buys me out of cottage I get half of $1\.5m


---

### 1282. msg_6610

**You** - 2025-05-02T13:00:40

Unless
You borrow against the cottage or whatever


---

### 1283. msg_6611

**You** - 2025-05-02T13:00:46

Yeah


---

### 1284. msg_6612

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:00:59

I don’t want in the cottage long term


---

### 1285. msg_6613

**You** - 2025-05-02T13:01:03

Make sure that is in agreement


---

### 1286. msg_6614

**You** - 2025-05-02T13:01:08

The buyout clause


---

### 1287. msg_6615

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:01:29

Yeah


---

### 1288. msg_6616

**You** - 2025-05-02T13:01:32

So I assume you will be continuing to pay a portion of the cottage mortgage etc


---

### 1289. msg_6617

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:01:40

Yup


---

### 1290. msg_6618

**You** - 2025-05-02T13:01:51

Kk then that could work for you\.


---

### 1291. msg_6619

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:01:53

$1,500 per month


---

### 1292. msg_6620

**You** - 2025-05-02T13:02:00

Fack lol


---

### 1293. msg_6621

**You** - 2025-05-02T13:03:09

Just mer I know you are smart smarter
Than me in a ton of ways but you also have a huge heart\.\. again much bigger
Than mine I am way meaner\.\. or would be in this situation\.
I just want you to be
Taken care of to be able
To retire when you want and have the life you want\.


---

### 1294. msg_6622

**You** - 2025-05-02T13:04:00

I was going to say if but when we can be together I have no doubt we would support each other through whatever comes anyways


---

### 1295. msg_6623

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:05:15

Wdym “Fack lol”


---

### 1296. msg_6624

**You** - 2025-05-02T13:05:41

Just a lot of money lol


---

### 1297. msg_6625

**You** - 2025-05-02T13:05:43

For me that is


---

### 1298. msg_6626

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:06:55

With insurances and property tax and gas it is 2,002 \+ 250 per month total lol


---

### 1299. msg_6627

**You** - 2025-05-02T13:06:56

You focus on the Fack and not the nice things… psssh… 😛


---

### 1300. msg_6628

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:07:00

Feel better?


---

### 1301. msg_6629

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:07:36

Reaction: 😝 from Scott Hicks
I was just curious what you were reacting to


---

### 1302. msg_6630

**You** - 2025-05-02T13:25:29

So my feelings on your comment\.\. never been happier or felt
More at ease\.\.  it still want to learn more about what makes you “happy” and suggest much practice should be forthcoming\.


---

### 1303. msg_6631

**You** - 2025-05-02T13:25:36

But we will leave that out of teams


---

### 1304. msg_6632

**You** - 2025-05-02T13:28:31

And we will see how brave you are lol


---

### 1305. msg_6633

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:28:31

Yeah not teams content for sure


---

### 1306. msg_6634

**You** - 2025-05-02T13:28:44

As you would say So…………\.


---

### 1307. msg_6635

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:28:44

How BRAVE I am?


---

### 1308. msg_6636

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:28:53

lol


---

### 1309. msg_6637

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:29:14

Depends on the context in terms of my bravery haha


---

### 1310. msg_6638

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:29:35

It is quite a spectrum


---

### 1311. msg_6639

**You** - 2025-05-02T13:30:44

Just in response\.\. nothing else
Right now\.


---

### 1312. msg_6640

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:32:43

My bravery is different everyday lol


---

### 1313. msg_6641

**You** - 2025-05-02T13:33:14

Ok fine don’t engage\.\. I can be patient\.


---

### 1314. msg_6642

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:33:31

I mean you have no choice so…


---

### 1315. msg_6643

**You** - 2025-05-02T13:34:15

Agreed, just trying to be the best I can be as the saying goes 😊


---

### 1316. msg_6644

**You** - 2025-05-02T13:39:28

We could continue this conversation tonight but I think you would need a few drinks\.  anyways you know where I stand on this lol\.


---

### 1317. msg_6645

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:55:07

lol sorry, had to find my freaking cc


---

### 1318. msg_6646

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:55:20

Mac took my credit card in Detroit and still hasn’t given it back


---

### 1319. msg_6647

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:55:24

Needed it


---

### 1320. msg_6648

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:55:28

Man


---

### 1321. msg_6649

**You** - 2025-05-02T13:55:34

lol


---

### 1322. msg_6650

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:55:54

Found weight loss pills in her room


---

### 1323. msg_6651

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:55:56

Argh


---

### 1324. msg_6652

**You** - 2025-05-02T13:56:02

Eesh that isn’t good


---

### 1325. msg_6653

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:56:02

I think she is anorexic


---

### 1326. msg_6654

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:56:14

New thing to deal with


---

### 1327. msg_6655

**You** - 2025-05-02T13:56:25

☹️ sucks\.


---

### 1328. msg_6656

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:56:41

>
Probably need more than a few drinks


---

### 1329. msg_6657

**You** - 2025-05-02T13:57:44

Hey I am just so out of practice I think I need some help\.  I mean it is only in our best interests\.


---

### 1330. msg_6658

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:58:24

Oh stop lol I just need to know you better


---

### 1331. msg_6659

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:58:30

As weird as that sounds


---

### 1332. msg_6660

**You** - 2025-05-02T13:59:02

Well we can figure that out whenever you want\.


---

### 1333. msg_6661

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T13:59:41

I mean we have had all of one weekend together and it was amazing so slow your roll


---

### 1334. msg_6662

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T14:00:21

Or maybe, just don’t worry


---

### 1335. msg_6663

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T14:00:27

Or whatever


---

### 1336. msg_6664

**You** - 2025-05-02T14:04:28

I am not worried\. Initially I was just playing with the weekend alignment  comment but was then like whatever why not… 🙁


---

### 1337. msg_6665

**You** - 2025-05-02T14:06:12

😇


---

### 1338. msg_6666

**You** - 2025-05-02T14:06:22

Sad face was supposed to be this guy


---

### 1339. msg_6667

**You** - 2025-05-02T14:06:32

But maybe both work LOL


---

### 1340. msg_6668

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T14:06:41

k and yes both work


---

### 1341. msg_6669

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T14:06:44

lol


---

### 1342. msg_6670

**You** - 2025-05-02T14:06:49

heh


---

### 1343. msg_6671

**You** - 2025-05-02T16:41:15

Insane fight all over cheap little crappy rings


---

### 1344. msg_6672

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:41:50

Ok that is a little crazy\. For real\.


---

### 1345. msg_6673

**You** - 2025-05-02T16:42:10

Seriously I swear this is what my life has been like for years but this is my fault


---

### 1346. msg_6674

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:42:34

I mean it takes two


---

### 1347. msg_6675

**You** - 2025-05-02T16:43:29

Well yeah but to be honest Gracie will literally never ever quit and if you hold out long enough she starts breaking stuff and then she moves on to hitting herself in the head\.  And j wouldn’t let me take her in for a psyche eval\.


---

### 1348. msg_6676

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:46:36

Maybe she will let you now? Have you tried re\-suggesting it?


---

### 1349. msg_6677

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:46:56

She could get suicidal if she is left too long


---

### 1350. msg_6678

**You** - 2025-05-02T16:47:11

We don’t have a choice now


---

### 1351. msg_6679

**You** - 2025-05-02T16:47:15

She is 18


---

### 1352. msg_6680

**You** - 2025-05-02T16:47:20

We cannot do anything


---

### 1353. msg_6681

**You** - 2025-05-02T16:47:26

The cops even told us


---

### 1354. msg_6682

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:47:50

Ohhhhhh right


---

### 1355. msg_6683

**You** - 2025-05-02T16:47:59

It really is bad we have very little control


---

### 1356. msg_6684

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:48:05

Was she checked for bi\-polar?


---

### 1357. msg_6685

**You** - 2025-05-02T16:48:06

All we can really do is kick her out


---

### 1358. msg_6686

**You** - 2025-05-02T16:48:32

I think she has it\.  But we didn’t hear that from the psychiatrist she sees and the bi polar mess made her worse


---

### 1359. msg_6687

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:48:35

My sis is bi\-polar and really unstable at times


---

### 1360. msg_6688

**You** - 2025-05-02T16:48:55

I feel like Gracie has a bunch of shit wrong but we cannot figure out how to get it addressed


---

### 1361. msg_6689

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:49:04

It’s weird bc my sis is adopted but we have bipolar in my family on both sides


---

### 1362. msg_6690

**You** - 2025-05-02T16:49:24

It is a tough problem\.\. I have friends with it


---

### 1363. msg_6691

**You** - 2025-05-02T16:49:28

The meds can be rough


---

### 1364. msg_6692

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:50:41

Well if she is freaking out over rings she needs more important things in her life \(school, work, etc etc\)…


---

### 1365. msg_6693

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:50:53

It would put the rings into a different perspective lol


---

### 1366. msg_6694

**You** - 2025-05-02T16:50:58

Logic doesn’t work I have tried this lol


---

### 1367. msg_6695

**You** - 2025-05-02T16:51:16

It was
Like this when she had school


---

### 1368. msg_6696

**You** - 2025-05-02T16:51:18

And work


---

### 1369. msg_6697

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T16:51:25

Does her therapist not help?


---

### 1370. msg_6698

**You** - 2025-05-02T16:51:27

She needs everything the way her mind requires it


---

### 1371. msg_6699

**You** - 2025-05-02T16:51:39

Not so far and we are t allowed to interact


---

### 1372. msg_6700

**You** - 2025-05-02T16:51:54

Again 18 and we have no rights


---

### 1373. msg_6701

**You** - 2025-05-02T16:53:30

Like right now she is losing her goddamn mind because she absolutely has to have an iPad in the bathroom
With her while
She showers
Some she can watch or listen to something g


---

### 1374. msg_6702

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T17:13:56

Intense


---

### 1375. msg_6703

**You** - 2025-05-02T17:17:48

Now j says she has to live with me which I said is fine but there will be rules and she will have to follow them\.\. and then she said but you cannot kick her out\.\. and I said this is your problem there are no real consequences\.\. and at her age these are them


---

### 1376. msg_6704

**You** - 2025-05-02T17:20:56

Hey don’t worry about responding you are busy we can chat later


---

### 1377. msg_6705

**You** - 2025-05-02T17:21:09

❤️ u


---

### 1378. msg_6706

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T17:24:02

Going to go over finances one last time just to get him the hell out of here


---

### 1379. msg_6707

**You** - 2025-05-02T17:31:23

No worries best of luck I know you are tired but he doesn’t deserve any relief\.


---

### 1380. msg_6708

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:13:30

K we are good\. All fine\. Lawyer next week


---

### 1381. msg_6709

**You** - 2025-05-02T18:16:32

Good


---

### 1382. msg_6710

**You** - 2025-05-02T18:16:48

Was thinking about you but trying not worry


---

### 1383. msg_6711

**You** - 2025-05-02T18:17:00

Cause you get mad at me when I show caring feelings lol


---

### 1384. msg_6712

**You** - 2025-05-02T18:20:37

Cause when you love
Someone this much you always care but it isn’t about you not being capable it is just about me caring about your well\-being\.  I just want you to understand when I worry that is why\.\. well that or because my brain kicks me in the face but that is happening less and less frequently to be honest\.


---

### 1385. msg_6713

**You** - 2025-05-02T18:23:15

So ❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️ I hope it went well and you feel good about the outcome and that he leaves you be to have a nice weekend\.


---

### 1386. msg_6714

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:23:49

He hasn’t left yet omg


---

### 1387. msg_6715

**You** - 2025-05-02T18:23:56

Errr


---

### 1388. msg_6716

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:24:04

Mac and all her friends are here and playing country music omg


---

### 1389. msg_6717

**You** - 2025-05-02T18:24:04

Well that went in a diff direction


---

### 1390. msg_6718

**You** - 2025-05-02T18:24:06

lol


---

### 1391. msg_6719

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:24:08

Zack Bryan


---

### 1392. msg_6720

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:24:21

I have them edibles so they love me


---

### 1393. msg_6721

**You** - 2025-05-02T18:24:23

So he is not going to go now


---

### 1394. msg_6722

**You** - 2025-05-02T18:24:59

I mean you are the mum with candy so they all love you lol


---

### 1395. msg_6723

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:26:54

He is but omg taking forever


---

### 1396. msg_6724

**You** - 2025-05-02T18:27:04

🙁


---

### 1397. msg_6725

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:27:36

One of them told me I look like a teenager bc of my sweatpants\. She has the same ones\. She is a duck up


---

### 1398. msg_6726

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:27:41

\*suck up


---

### 1399. msg_6727

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:27:43

lol


---

### 1400. msg_6728

**You** - 2025-05-02T18:27:53

Take it whatever the reason


---

### 1401. msg_6729

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:27:57

lol


---

### 1402. msg_6730

**You** - 2025-05-02T18:28:14

You certainly can still act
Like one


---

### 1403. msg_6731

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:28:21

They are having fan\. Just left with a speaker blaring walking down the street


---

### 1404. msg_6732

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:28:27

>
No shame


---

### 1405. msg_6733

**You** - 2025-05-02T18:28:34

We made out like teenagers for sure


---

### 1406. msg_6734

**You** - 2025-05-02T18:28:47

And that was super fun


---

### 1407. msg_6735

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:29:19

I mean it was more than fun for sure


---

### 1408. msg_6736

**You** - 2025-05-02T18:29:46

Yeah no it was fun, remained fun but yeah was def more\.


---

### 1409. msg_6737

**You** - 2025-05-02T18:30:10

And like I told you will never get tired of it


---

### 1410. msg_6738

**You** - 2025-05-02T18:30:35

It is something about how great it is anyways and how great you are period


---

### 1411. msg_6739

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:30:38

Don’t say never please


---

### 1412. msg_6740

**You** - 2025-05-02T18:31:07

I cannot foresee a possible situation in which I might feel differently one might exist but I cannot see it


---

### 1413. msg_6741

**You** - 2025-05-02T18:31:34

Reaction: ❤️ from Meredith Lamb
How is that for getting around never in an awesome way


---

### 1414. msg_6742

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:32:15

Much better


---

### 1415. msg_6743

**You** - 2025-05-02T18:32:58

When I use absolutes consider the intent not the literal\.\.
Will make it easier but the second thing I said is way more
Literally accurate


---

### 1416. msg_6744

**You** - 2025-05-02T18:33:52

And my memory brings me back to the moments whenever I want and still thinking about it over
And
Over I feel
The same


---

### 1417. msg_6745

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:34:09

I couldn’t get the tv working for some reason and he goes “what are you going to do without me?” 🙄


---

### 1418. msg_6746

**You** - 2025-05-02T18:34:12

I could not find a flaw or bad moment or bad feeling


---

### 1419. msg_6747

**You** - 2025-05-02T18:34:20

Rofl


---

### 1420. msg_6748

**You** - 2025-05-02T18:34:22

Wow


---

### 1421. msg_6749

**You** - 2025-05-02T18:34:27

Ask ChatGPT douchebag


---

### 1422. msg_6750

**You** - 2025-05-02T18:34:40

That should have been your answer


---

### 1423. msg_6751

**You** - 2025-05-02T18:34:41

lol


---

### 1424. msg_6752

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:34:49

He hates ChatGPT


---

### 1425. msg_6753

**You** - 2025-05-02T18:35:04

See I knew I would never like him\.


---

### 1426. msg_6754

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:35:11

Hahaha


---

### 1427. msg_6755

**You** - 2025-05-02T18:36:04

Anyways I know you have a hard time with affection\.\.
So just take it for what it is and feel good about it\.\.
Give
Yourself a break relax
He will be gone soon and you can chill with your teeny friends


---

### 1428. msg_6756

**You** - 2025-05-02T18:36:25

That is why I picked the song I did


---

### 1429. msg_6757

**You** - 2025-05-02T18:36:33

The lyrics
Pretty much describe you lol


---

### 1430. msg_6758

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:36:55

The only exception song?


---

### 1431. msg_6759

**You** - 2025-05-02T18:37:06

No that describes how I feel about you


---

### 1432. msg_6760

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:37:13

What song


---

### 1433. msg_6761

**You** - 2025-05-02T18:37:16

Our song I considered to be the one we danced to


---

### 1434. msg_6762

**You** - 2025-05-02T18:37:22

But it could also be only exception


---

### 1435. msg_6763

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:37:28

Ohhhhhhhhh\!


---

### 1436. msg_6764

**You** - 2025-05-02T18:37:53

I listen to it every day at least a couple times lol sap\.


---

### 1437. msg_6765

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:38:34

:\)


---

### 1438. msg_6766

**You** - 2025-05-02T18:38:45

I don’t think you were listening to the song though when we were dancing


---

### 1439. msg_6767

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:38:53

Reaction: ❤️ from Scott Hicks
I was not


---

### 1440. msg_6768

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:38:54

lol


---

### 1441. msg_6769

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:39:02

I was distracted


---

### 1442. msg_6770

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:39:22

You distract me a lot


---

### 1443. msg_6771

**You** - 2025-05-02T18:40:01

I try to\. But in a good way\. I do not expect that I will ever likely stop trying to distract you in that way\.


---

### 1444. msg_6772

**You** - 2025-05-02T18:40:11

Reaction: 😂 from Meredith Lamb
God it is so wordy to get around absolutes


---

### 1445. msg_6773

**You** - 2025-05-02T18:40:48

Words though\.\. I got lots of those\.


---

### 1446. msg_6774

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:41:03

Reaction: 😀 from Scott Hicks
Literally


---

### 1447. msg_6775

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:41:53

Friday night last week was so much better :p


---

### 1448. msg_6776

**You** - 2025-05-02T18:42:17

Yeah it was\.\. man I was out of my mind\.\.


---

### 1449. msg_6777

**You** - 2025-05-02T18:42:26

Can still remember


---

### 1450. msg_6778

**You** - 2025-05-02T18:42:39

The whole weekend was
Like that for me though


---

### 1451. msg_6779

**You** - 2025-05-02T18:42:48

Just surreal in so many ways


---

### 1452. msg_6780

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:42:59

And now we are back here\.


---

### 1453. msg_6781

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:43:06

😵‍💫


---

### 1454. msg_6782

**You** - 2025-05-02T18:43:08

Well I do t think back


---

### 1455. msg_6783

**You** - 2025-05-02T18:43:16

I think we took a step forward


---

### 1456. msg_6784

**You** - 2025-05-02T18:43:24

And just have to pause before taking the next


---

### 1457. msg_6785

**You** - 2025-05-02T18:43:35

So I don’t see it as back


---

### 1458. msg_6786

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:44:02

I guess\. But we are literally back in the same places\.


---

### 1459. msg_6787

**You** - 2025-05-02T18:44:54

We are in our houses respectively and I loved you certainly before last
Weekend more than I have ever loved
Anyone \.\. and
Like I said it only grew
And continues
To\.\. we are making progress
In our respective situations\.


---

### 1460. msg_6788

**You** - 2025-05-02T18:45:21

And that rock you gave me was one of the nicest most thoughtful things anyone has ever done for me


---

### 1461. msg_6789

**You** - 2025-05-02T18:46:06

So while I worry and fret I am feeling more and more confident about the future more specifically that we might not be too far off from having a bit more opportunity to connect\.


---

### 1462. msg_6790

**You** - 2025-05-02T18:46:35

I can deal with 40 days and 40 nights for those kinds of weekends\.


---

### 1463. msg_6791

**You** - 2025-05-02T18:47:31

Are you worried this will
Ever stop?


---

### 1464. msg_6792

**You** - 2025-05-02T18:47:47

The wooing and texting because I don’t think it is likely to either


---

### 1465. msg_6793

**You** - 2025-05-02T18:47:55

Just in case you are worried


---

### 1466. msg_6794

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:48:28

I have a little anxiety…


---

### 1467. msg_6795

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:48:43

But my life is such a shitty mess I don’t focus on it too much


---

### 1468. msg_6796

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:48:45

Tbh


---

### 1469. msg_6797

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:48:50

But it is there


---

### 1470. msg_6798

**You** - 2025-05-02T18:49:00

Why are you anxious\.\. I can relieve it for you I am sure


---

### 1471. msg_6799

**You** - 2025-05-02T18:49:15

Or you can tell me later if you want


---

### 1472. msg_6800

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:49:15

I don’t think you can


---

### 1473. msg_6801

**You** - 2025-05-02T18:49:19

Why not


---

### 1474. msg_6802

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:50:44

It is just related to the fact that if we never get real opportunities to actually spent time together in real life, what happens… just haven’t been in this situation so it is the unknown I guess


---

### 1475. msg_6803

**You** - 2025-05-02T18:51:27

This and talking \- communicating reassuring each other that is how we stay healthy


---

### 1476. msg_6804

**You** - 2025-05-02T18:51:56

That we know that despite the lack of opportunities or having to prioritize other things this is important enough to hold
Onto


---

### 1477. msg_6805

**You** - 2025-05-02T18:52:28

I never wanted to let you leave Monday night because I knew when you walked out that was it for a while


---

### 1478. msg_6806

**You** - 2025-05-02T18:52:36

And it hurt literally but I did it anyways


---

### 1479. msg_6807

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:53:16

Here is another smaller anxiety


---

### 1480. msg_6808

**You** - 2025-05-02T18:53:17

Reaction: 😂 from Meredith Lamb
But I think what I have said above is key and I think we are ok at it\.\. yes I might communicate more than you but as long as you can tolerate it lol


---

### 1481. msg_6809

**You** - 2025-05-02T18:53:21

Ok


---

### 1482. msg_6810

**You** - 2025-05-02T18:53:28

What is the other


---

### 1483. msg_6811

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:54:49

So I feel like you have been very neglected \(not sure of the right word but that is the closest\) for years…\. So you think ppl don’t like you or are not attracted to you or whatever when it just isn’t the case\. You were just blind in your weird situation


---

### 1484. msg_6812

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:54:53

Sooo


---

### 1485. msg_6813

**You** - 2025-05-02T18:55:40

So why are you anxious


---

### 1486. msg_6814

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:55:50

Now that I have shown interest and an actual longing/connection/desire for you that you might feel like testing the waters lol


---

### 1487. msg_6815

**You** - 2025-05-02T18:56:36

So let me lay a few things out\. This will take a few sentences


---

### 1488. msg_6816

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:56:48

But does that make sense?


---

### 1489. msg_6817

**You** - 2025-05-02T18:57:10

I can see how you might feel that way\.\. just responding before I share my thoughts


---

### 1490. msg_6818

**You** - 2025-05-02T18:57:42

So first I haven’t connected with anyone like this on any level ever and I can say ever in this instance\.


---

### 1491. msg_6819

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:58:15

But it doesn’t mean you couldn’t with someone else


---

### 1492. msg_6820

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T18:58:20

Right?


---

### 1493. msg_6821

**You** - 2025-05-02T18:59:33

Second, I have had ED for about 5 years probably psychological ,
My performance
anxiety was
Literally off the charts… as
I said to you my changing my “personal” habits for the first
Time since I was what 15 to something g that has never happened, my ability at all to do what we did\.\. like you don’t understand that is what
YOU do to
Me\.


---

### 1494. msg_6822

**You** - 2025-05-02T18:59:37

Not other people


---

### 1495. msg_6823

**You** - 2025-05-02T18:59:54

I haven’t looked at a girl in any way
For years before you and haven’t after


---

### 1496. msg_6824

**You** - 2025-05-02T19:00:02

I am not joking


---

### 1497. msg_6825

**You** - 2025-05-02T19:00:11

Ok on to the next point


---

### 1498. msg_6826

**You** - 2025-05-02T19:01:24

I do have like zero confidence in my abilities it is true it has been so friggen long like pre Jaimie likely that anything like that happened,
But still
All
I can think about is your happiness
Were you weren’t you what can I do better differently etc


---

### 1499. msg_6827

**You** - 2025-05-02T19:01:48

Again not a single thought of anything but you


---

### 1500. msg_6828

**You** - 2025-05-02T19:02:03

I am so worried tontell you because I thought it would scare you off


---

### 1501. msg_6829

**You** - 2025-05-02T19:02:19

See I will tell you anything


---

### 1502. msg_6830

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:02:27

I am not scared even an inch


---

### 1503. msg_6831

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:02:43

This does not scare me


---

### 1504. msg_6832

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:03:04

But it is surprising to hear bc from what I know about ED that wasn’t it


---

### 1505. msg_6833

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:03:05

lol


---

### 1506. msg_6834

**You** - 2025-05-02T19:03:05

You have nothing to worry about out from me\.\. all I do is try to figure out how to give you whatever I can however I can\.\.


---

### 1507. msg_6835

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:03:35

So you don’t want to go sow your oats


---

### 1508. msg_6836

**You** - 2025-05-02T19:03:37

I have been taking tadafil for years even that doesn’t really help\.\.
Got thinks it is emotional and psychological


---

### 1509. msg_6837

**You** - 2025-05-02T19:03:46

Just with you repeatedly


---

### 1510. msg_6838

**You** - 2025-05-02T19:04:02

And I know you told me your drive was kind of\. It there


---

### 1511. msg_6839

**You** - 2025-05-02T19:04:09

I didn’t think mine was either


---

### 1512. msg_6840

**You** - 2025-05-02T19:04:14

But apparently
It so


---

### 1513. msg_6841

**You** - 2025-05-02T19:04:17

Not so


---

### 1514. msg_6842

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:04:47

Yeah thoughts if andrew…\. 👎


---

### 1515. msg_6843

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:04:51

\*of


---

### 1516. msg_6844

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:05:02

But my body could always perform


---

### 1517. msg_6845

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:05:14

Just had to not think about him lol


---

### 1518. msg_6846

**You** - 2025-05-02T19:05:30

I could not… do that


---

### 1519. msg_6847

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:05:40

Very interesting


---

### 1520. msg_6848

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:05:54

Did you ChatGPT that


---

### 1521. msg_6849

**You** - 2025-05-02T19:06:00

There is some kind of emotional requirement


---

### 1522. msg_6850

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:06:02

Is it psychological


---

### 1523. msg_6851

**You** - 2025-05-02T19:06:14

I think it is both emotional and psychological


---

### 1524. msg_6852

**You** - 2025-05-02T19:06:52

But yeah I mean there are other things insecurities everyone has and I try not to think about them


---

### 1525. msg_6853

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:07:14

The emotional part is massive for me for sure


---

### 1526. msg_6854

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:08:51

I would want to be with you even if we couldn’t have sex\. I honestly wouldn’t care


---

### 1527. msg_6855

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:09:04

The other stuff is just as important


---

### 1528. msg_6856

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:09:08

If not more


---

### 1529. msg_6857

**You** - 2025-05-02T19:11:24

I appreciate that and I agree\.\. but sex is important and I don’t say that because I think it\.\. because it just is everything f I have ever read talks about sexual compatibility being important to maintaining a strong healthy relationship\.  I cannot help but worry not about you… so like that is where my main concern is\.\. I haven’t always felt that way\.\. but I am older and love you more than anything so I cannot help but feel that way now\.\.
Another mental thing I will have to overcome\.\.  it I have been ok so far I guess at doing that\.


---

### 1530. msg_6858

**You** - 2025-05-02T19:12:31

I just try not to think about certain things\.\. and focus on others\.\. sometimes more successfully than others\.


---

### 1531. msg_6859

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:13:03

I mean I think all those articles are written biased lol


---

### 1532. msg_6860

**You** - 2025-05-02T19:13:51

Mmmm I don’t think so I believe it is true\. To a large degree\.
I didn’t a long time ago but seeing what I went through I think there might be some truth to it


---

### 1533. msg_6861

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:13:52

My dad had prostate surgery at like 53 or some young age and couldn’t have sex after\. My parents are great 30 yrs later…errrr wait sorry


---

### 1534. msg_6862

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:13:54

lol


---

### 1535. msg_6863

**You** - 2025-05-02T19:15:08

I mean the ability or have sex isn’t overly a concern I feel like I have a better handle on that now it is the rest\.


---

### 1536. msg_6864

**You** - 2025-05-02T19:16:02

Anyhow it is a topic that is tough to talk about out let alone think about\.\. or lead to questioning a whole bunch of things that don’t make me feel good\.


---

### 1537. msg_6865

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:16:27

Why are you so hard on yourself?


---

### 1538. msg_6866

**You** - 2025-05-02T19:16:40

I don’t know I always have been


---

### 1539. msg_6867

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:16:52

Low key yeah


---

### 1540. msg_6868

**You** - 2025-05-02T19:16:57

It is part of who I am


---

### 1541. msg_6869

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:16:58

\(Ad Mac would say\)


---

### 1542. msg_6870

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:17:04

\*As


---

### 1543. msg_6871

**You** - 2025-05-02T19:17:38

It drives me to do things to get better
To be better\.  To want to be worthy etc\.\. and it doesn’t matter what I hear it always is there


---

### 1544. msg_6872

**You** - 2025-05-02T19:18:37

I don’t know if I can fix this it will just likely become less prominent over time perhaps\.\. I am not sure you are a unique case


---

### 1545. msg_6873

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:19:17

So curious \.\. what you are seeking? An instruction manual to me?


---

### 1546. msg_6874

**You** - 2025-05-02T19:19:27

777777777777


---

### 1547. msg_6875

**You** - 2025-05-02T19:19:30

lol


---

### 1548. msg_6876

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:19:58

Hahahaha


---

### 1549. msg_6877

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:20:19

That was a good one


---

### 1550. msg_6878

**You** - 2025-05-02T19:20:52

I mean usually that comes with time but seeing as we don’t have a ton of it\.\. I just want to get to a place where you are comfortable and I know what to do to make you happy\.  I think there are a lot of selfish people when it comes to this kind of thing\.\. I am not that\.


---

### 1551. msg_6879

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:22:34

Definitely time… I need time for sure\. I’m not as intense as you I don’t think\. Trust me, I am comfortable with you but there are degrees that come with time and really getting to know someone\. So we are not degrees deep yet but I find that fun personally


---

### 1552. msg_6880

**You** - 2025-05-02T19:23:56

I can be patient if you are happy\.  It is just how I am made\.\. it think it has to do with how I was raised \- always be courteous and polite always think about the other person first, always give more than you receive\.


---

### 1553. msg_6881

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:24:42

I mean you can call it being patient but maybe just enjoy the ride\.\.


---

### 1554. msg_6882

**You** - 2025-05-02T19:25:35

Like you said the ride has a lot of long pauses\.\. it won’t change how I feel or how long I will wait but you know anticipation \- only so much of a good thing\.


---

### 1555. msg_6883

**You** - 2025-05-02T19:25:49

But you shouldn’t worry about where my head is at\.


---

### 1556. msg_6884

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:25:56

Did your past girlfriends and wife tell you exactly what to do after your first weekend together?


---

### 1557. msg_6885

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:25:59

lol


---

### 1558. msg_6886

**You** - 2025-05-02T19:26:09

Mmmmm


---

### 1559. msg_6887

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:26:13

lol


---

### 1560. msg_6888

**You** - 2025-05-02T19:26:21

It was a different time and I was different


---

### 1561. msg_6889

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:26:35

Meaning you didn’t care about them?


---

### 1562. msg_6890

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:26:37

Haha


---

### 1563. msg_6891

**You** - 2025-05-02T19:26:45

No


---

### 1564. msg_6892

**You** - 2025-05-02T19:27:13

I just never really had a problem with that kind of thing\. The giving and all\.\. lol\.


---

### 1565. msg_6893

**You** - 2025-05-02T19:27:55

Like you said your body was capable mine probably was a lot more before the last 20 years of kind of meh\.


---

### 1566. msg_6894

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:28:41

Was that like a gradual thing or all of a sudden?


---

### 1567. msg_6895

**You** - 2025-05-02T19:28:48

Anyhow it was a long time ago and I cannot even remember most of it now\.


---

### 1568. msg_6896

**You** - 2025-05-02T19:29:07

It was after kids well before we moved here


---

### 1569. msg_6897

**You** - 2025-05-02T19:29:25

That is kind of when I realized I made a mistake and I was stuck


---

### 1570. msg_6898

**You** - 2025-05-02T19:29:34

Still no desire to look anywhere else


---

### 1571. msg_6899

**You** - 2025-05-02T19:29:39

Was not acceptable to me


---

### 1572. msg_6900

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:30:21

Reaction: ❤️ from Scott Hicks
Just reading all of that like I’m so glad we met\.


---

### 1573. msg_6901

**You** - 2025-05-02T19:30:31

I mean listen even thinking about competitive math makes me cry inside lol


---

### 1574. msg_6902

**You** - 2025-05-02T19:30:39

Comparative


---

### 1575. msg_6903

**You** - 2025-05-02T19:31:03

So like you said will take some time I will get my head around this


---

### 1576. msg_6904

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:31:26

Me too :\)


---

### 1577. msg_6905

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:35:21

👻


---

### 1578. msg_6906

**You** - 2025-05-02T19:36:50

>
lol why


---

### 1579. msg_6907

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:37:57

Just because\.


---

### 1580. msg_6908

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:40:23

I just got asked “Do you not have any sadness about this?”


---

### 1581. msg_6909

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:40:42

Hasn’t left yet


---

### 1582. msg_6910

**You** - 2025-05-02T19:40:43

Look you have insecurities about the future I have then about the past\.\. I guess we will just have to see how we can deal with those\.  We are human


---

### 1583. msg_6911

**You** - 2025-05-02T19:40:48

Ouch


---

### 1584. msg_6912

**You** - 2025-05-02T19:40:53

Ok


---

### 1585. msg_6913

**You** - 2025-05-02T19:41:01

Maybe ignore my comment for a min


---

### 1586. msg_6914

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:41:07

>
This is very true\. Didn’t think about that\.


---

### 1587. msg_6915

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:41:31

I said I had my sadness 3 years ago


---

### 1588. msg_6916

**You** - 2025-05-02T19:42:26

Yeah remeber how I said never try to compete with the past\.\. it is really really hard to keep that out of your head\.\.
lol\.


---

### 1589. msg_6917

**You** - 2025-05-02T19:42:34

>
What did he say


---

### 1590. msg_6918

**You** - 2025-05-02T19:42:38

Eye roll\.\.


---

### 1591. msg_6919

**You** - 2025-05-02T19:42:42

My bet is on that


---

### 1592. msg_6920

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:42:49

No he nodded


---

### 1593. msg_6921

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:42:59

He knows how I felt then


---

### 1594. msg_6922

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:43:14

My mom and him convinced me to stay


---

### 1595. msg_6923

**You** - 2025-05-02T19:43:48

We’re you with the company yet


---

### 1596. msg_6924

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:43:59

Yup


---

### 1597. msg_6925

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:44:08

Had recently started


---

### 1598. msg_6926

**You** - 2025-05-02T19:44:21

That might have caused something to happen sooner


---

### 1599. msg_6927

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:44:28

I was going home to these conversations when I first started working for you


---

### 1600. msg_6928

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:44:34

Can’t remember exactly when


---

### 1601. msg_6929

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:44:51

I went back to work basically bc I hated him


---

### 1602. msg_6930

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:45:19

When you asked me during the interview…


---

### 1603. msg_6931

**You** - 2025-05-02T19:45:21

I never really knew about that at the time\.\.


---

### 1604. msg_6932

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:45:35

“Why now? Why go back to work now?” I laughed a little in my head


---

### 1605. msg_6933

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:45:55

Like not fully but like 1/5 of me knew this was coming


---

### 1606. msg_6934

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:46:04

Wasn’t a big focus


---

### 1607. msg_6935

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:46:21

>
No one did except Andrew and my parents


---

### 1608. msg_6936

**You** - 2025-05-02T19:46:57

Had I known had we gotten to know each other like we have I think I would have likely called it\.


---

### 1609. msg_6937

**You** - 2025-05-02T19:48:01

Still woukd have been in same awkward situation with you reporting to me though lol


---

### 1610. msg_6938

**You** - 2025-05-02T19:48:10

But I guess not for long


---

### 1611. msg_6939

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:48:53

lol


---

### 1612. msg_6940

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:49:26

>
I didn’t even tell my best friends 3 yrs ago\.


---

### 1613. msg_6941

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:49:37

Unheard of for me\.


---

### 1614. msg_6942

**You** - 2025-05-02T19:49:51

I mean I don’t blame you


---

### 1615. msg_6943

**You** - 2025-05-02T19:49:57

It is tough


---

### 1616. msg_6944

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:50:08

Yeah they helped me through the 2016 stuff everyday


---

### 1617. msg_6945

**You** - 2025-05-02T19:50:08

I have told very few people about my situation


---

### 1618. msg_6946

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:50:31

But the most important knows


---

### 1619. msg_6947

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:50:33

:\)


---

### 1620. msg_6948

**You** - 2025-05-02T19:50:35

Only one knows about you and how I feel


---

### 1621. msg_6949

**You** - 2025-05-02T19:50:47

Well 2you


---

### 1622. msg_6950

**You** - 2025-05-02T19:50:50

Well 3


---

### 1623. msg_6951

**You** - 2025-05-02T19:50:55

If you and I cojnt


---

### 1624. msg_6952

**You** - 2025-05-02T19:51:10

Cause Mike knows and believes me


---

### 1625. msg_6953

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:51:17

Are you going to tell anyone else?


---

### 1626. msg_6954

**You** - 2025-05-02T19:51:33

Not right now I came close to telling Katie


---

### 1627. msg_6955

**You** - 2025-05-02T19:51:39

She is just always busy


---

### 1628. msg_6956

**You** - 2025-05-02T19:51:43

It is a sit down talk


---

### 1629. msg_6957

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:51:44

I’ve told a bunch of ppl sorry


---

### 1630. msg_6958

**You** - 2025-05-02T19:51:49

Sok


---

### 1631. msg_6959

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:51:49

lol


---

### 1632. msg_6960

**You** - 2025-05-02T19:51:52

I don’t care


---

### 1633. msg_6961

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:52:05

Mac can be trusted tho\. You didn’t need to get anxiety today


---

### 1634. msg_6962

**You** - 2025-05-02T19:52:23

Oh I think she wants you to be happy


---

### 1635. msg_6963

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:52:47

Desperately she does\.


---

### 1636. msg_6964

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:53:10

She’s a good person deep down\. Lol


---

### 1637. msg_6965

**You** - 2025-05-02T19:53:25

She is you she has to be


---

### 1638. msg_6966

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:53:27

Just a little superficial but whatever


---

### 1639. msg_6967

**You** - 2025-05-02T19:53:53

That is all teens


---

### 1640. msg_6968

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:53:58

>
Lord help her if so


---

### 1641. msg_6969

**You** - 2025-05-02T19:54:46

I think you did ok\.


---

### 1642. msg_6970

**You** - 2025-05-02T19:54:58

😊


---

### 1643. msg_6971

**You** - 2025-05-02T19:55:53

I mean same can be said for me


---

### 1644. msg_6972

**You** - 2025-05-02T19:55:58

Wasn’t a straight line


---

### 1645. msg_6973

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:56:07

Same\.


---

### 1646. msg_6974

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:56:09

lol


---

### 1647. msg_6975

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:56:15

Even tho it was a little


---

### 1648. msg_6976

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:56:21

The background wasn’t\. Lol


---

### 1649. msg_6977

**You** - 2025-05-02T19:56:34

But I did go through a really really long period of disappointment so that sucked


---

### 1650. msg_6978

**You** - 2025-05-02T19:57:17

But still here I am and different choices put me somewhere else


---

### 1651. msg_6979

**You** - 2025-05-02T19:57:32

And I believe I will look back and say I wouldn’t change a thing


---

### 1652. msg_6980

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T19:59:20

Except this and this and this lol you are so hard on yourself there will be 15 things you’d change 🙃


---

### 1653. msg_6981

**You** - 2025-05-02T19:59:49

No mer because if I changed anything I wouldn’t have met you\.


---

### 1654. msg_6982

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:00:24

🫠


---

### 1655. msg_6983

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:00:28

;\)


---

### 1656. msg_6984

**You** - 2025-05-02T20:01:03

No words… just gah\.


---

### 1657. msg_6985

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:02:56

Little quiet…\. Listening to music while chaos is around me lol


---

### 1658. msg_6986

**You** - 2025-05-02T20:03:16

Half naked at gym getting changed


---

### 1659. msg_6987

**You** - 2025-05-02T20:03:26

😇


---

### 1660. msg_6988

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:03:48

lol wow


---

### 1661. msg_6989

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:03:54

Escalated


---

### 1662. msg_6990

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:03:58

Quickly


---

### 1663. msg_6991

**You** - 2025-05-02T20:04:11

lol no


---

### 1664. msg_6992

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:04:11

\(Not mad\)


---

### 1665. msg_6993

**You** - 2025-05-02T20:04:13

That is later


---

### 1666. msg_6994

**You** - 2025-05-02T20:04:21

Reaction: 😂 from Meredith Lamb
This is just what I am doing


---

### 1667. msg_6995

**You** - 2025-05-02T20:05:33

June 21 is a bust j is going back to pei for 5 days and not taking either of the girls\.


---

### 1668. msg_6996

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:06:31

June 21\. Omg so far away\.


---

### 1669. msg_6997

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:06:32

lol


---

### 1670. msg_6998

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:06:37

And you are planning


---

### 1671. msg_6999

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:06:46

It’s sad though


---

### 1672. msg_7000

**You** - 2025-05-02T20:07:09

No i was I mentioned it the other night but yeah it wa far
Out\.


---

### 1673. msg_7001

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:07:32

Just leave your kids alone all night


---

### 1674. msg_7002

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:07:35

No biggie


---

### 1675. msg_7003

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:07:46

Lol


---

### 1676. msg_7004

**You** - 2025-05-02T20:07:59

I won’t be able to do that it would be too obvious and we have never done that


---

### 1677. msg_7005

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:08:17

I was being sarcastic


---

### 1678. msg_7006

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:08:29

I wouldn’t be able to either


---

### 1679. msg_7007

**You** - 2025-05-02T20:08:37

https://open\.spotify\.com/track/47Xj8eIAp7hYOOqArmkqZE?si=D51s2dDaTA\-HEgkS7wtawQ&context=spotify%3Aplaylist%3A37i9dQZF1DZ06evO2zJOi2
Listening now


---

### 1680. msg_7008

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:09:00

I listened to Morgan a lot today\.


---

### 1681. msg_7009

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:09:20

I go on and off…\.


---

### 1682. msg_7010

**You** - 2025-05-02T20:09:31

Just a lot


---

### 1683. msg_7011

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:10:31

?


---

### 1684. msg_7012

**You** - 2025-05-02T20:10:45

Heavy


---

### 1685. msg_7013

**You** - 2025-05-02T20:10:50

Like you said feel it


---

### 1686. msg_7014

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:10:54

Oh yeah


---

### 1687. msg_7015

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:10:58

Like jelly roll


---

### 1688. msg_7016

**You** - 2025-05-02T20:11:14

I don’t mean the song although it is


---

### 1689. msg_7017

**You** - 2025-05-02T20:11:21

Just feel heavy all of a sudden


---

### 1690. msg_7018

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:11:42

I thought you meant Morgan is heavy\. He is lol


---

### 1691. msg_7019

**You** - 2025-05-02T20:11:57

Yep agreed


---

### 1692. msg_7020

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:12:18

I’m kinda high now so the night is now forever clumsy :p


---

### 1693. msg_7021

**You** - 2025-05-02T20:13:28

Lucky


---

### 1694. msg_7022

**You** - 2025-05-02T20:13:40

This is why I shouldn’t


---

### 1695. msg_7023

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:14:44


*1 attachment(s)*


---

### 1696. msg_7024

**You** - 2025-05-02T20:15:06

It’s fine you enjoy your high and your music just gonna work out I don’t want to bring you down\.


---

### 1697. msg_7025

**You** - 2025-05-02T20:15:31

Wow


---

### 1698. msg_7026

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:15:33


*1 attachment(s)*


---

### 1699. msg_7027

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:15:51

I think I need to go to the basement


---

### 1700. msg_7028

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:15:55

Brb lol


---

### 1701. msg_7029

**You** - 2025-05-02T20:15:58

Kk


---

### 1702. msg_7030

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:17:40

Mac’s friend bea is Haris to you


---

### 1703. msg_7031

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:17:59

I go down there and go to the fridge and she’s like “omg can I give you a hug?”


---

### 1704. msg_7032

**You** - 2025-05-02T20:18:01

Ah lol


---

### 1705. msg_7033

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:05

They are all my edibles


---

### 1706. msg_7034

**You** - 2025-05-02T20:18:07

Girlmance


---

### 1707. msg_7035

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:11

But I had 4 drinks


---

### 1708. msg_7036

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:13

lol


---

### 1709. msg_7037

**You** - 2025-05-02T20:18:17

Jesus


---

### 1710. msg_7038

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:18

They don’t do the drinks


---

### 1711. msg_7039

**You** - 2025-05-02T20:18:19

4


---

### 1712. msg_7040

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:23

9


---

### 1713. msg_7041

**You** - 2025-05-02T20:18:33

4 drinks of 9


---

### 1714. msg_7042

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:49

9 edibles, 4 drinks


---

### 1715. msg_7043

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:18:55

They ate all the gummies


---

### 1716. msg_7044

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:19:03

No drinks


---

### 1717. msg_7045

**You** - 2025-05-02T20:19:05

Rofl you will be preferring more tonight or tomorrow


---

### 1718. msg_7046

**You** - 2025-05-02T20:19:17

Ordering


---

### 1719. msg_7047

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:19:39

They are a bunch of very high girls\. Honestly preferable to drunk


---

### 1720. msg_7048

**You** - 2025-05-02T20:19:49

I agree


---

### 1721. msg_7049

**You** - 2025-05-02T20:19:56

Gracie drinking tonight


---

### 1722. msg_7050

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:19:57

Sharon’s here :\)


---

### 1723. msg_7051

**You** - 2025-05-02T20:20:01

Fireball


---

### 1724. msg_7052

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:20:13

Oh no


---

### 1725. msg_7053

**You** - 2025-05-02T20:20:16

J wanted me to pick her up


---

### 1726. msg_7054

**You** - 2025-05-02T20:20:19

I said fuck\. O


---

### 1727. msg_7055

**You** - 2025-05-02T20:20:20

No


---

### 1728. msg_7056

**You** - 2025-05-02T20:20:30

She is drinking and I am getting high


---

### 1729. msg_7057

**You** - 2025-05-02T20:20:34

Gracie can walk home


---

### 1730. msg_7058

**You** - 2025-05-02T20:20:39

I will stay awake


---

### 1731. msg_7059

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:21:12

I am going through our old laptop’s photos … Andrew is on his laptop across the house\. He is not leaving yet


---

### 1732. msg_7060

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:21:14

wtf


---

### 1733. msg_7061

**You** - 2025-05-02T20:21:35

He won’t leave I bet at this point


---

### 1734. msg_7062

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:22:13

Omg he better\. I think he will but he prefers to drive at night


---

### 1735. msg_7063

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:22:20

So I’m still optimistic lol


---

### 1736. msg_7064

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:22:29

Not even dark yet


---

### 1737. msg_7065

**You** - 2025-05-02T20:23:36

Sry was on a run interval hard to
Text


---

### 1738. msg_7066

**You** - 2025-05-02T20:23:55

Well I hope he does otherwise
Will be a quiet night


---

### 1739. msg_7067

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:24:36

https://open\.spotify\.com/track/5IOUNrN8E37eLGdLNRr9aC?si=l9sstqhwQ2ifaB5RIHwjEQ


---

### 1740. msg_7068

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:26:16

If he was gone I’d play a game with mar and Maelle right now but if I start he will stay longer ermagerrrrrd


---

### 1741. msg_7069

**You** - 2025-05-02T20:26:42

🙁 no win


---

### 1742. msg_7070

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:28:23

Just soooooo ugh\. 🤷‍♀️


---

### 1743. msg_7071

**You** - 2025-05-02T20:28:39

Yep I feel you


---

### 1744. msg_7072

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:29:33

One thing I look forward to…


---

### 1745. msg_7073

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:29:55

The first time we play ticket to ride together\.


---

### 1746. msg_7074

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:29:57

lol


---

### 1747. msg_7075

**You** - 2025-05-02T20:30:15

Should be fun I have never played


---

### 1748. msg_7076

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:30:34

Next time we get together


---

### 1749. msg_7077

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:30:48

Actually no I only have them at the cottage


---

### 1750. msg_7078

**You** - 2025-05-02T20:31:10

As I said the clear result the Friday after next after next after…\. lol sad lol but still lol


---

### 1751. msg_7079

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:31:17

Ant believe you have never played with your daughters\. :\(


---

### 1752. msg_7080

**You** - 2025-05-02T20:31:28

We never did that


---

### 1753. msg_7081

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:31:28

\*cant


---

### 1754. msg_7082

**You** - 2025-05-02T20:31:31

Reaction: 👎 from Meredith Lamb
Just monopoly


---

### 1755. msg_7083

**You** - 2025-05-02T20:31:41

All j wanted to play


---

### 1756. msg_7084

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:31:44

Not Pandemic??


---

### 1757. msg_7085

**You** - 2025-05-02T20:31:48

Nope


---

### 1758. msg_7086

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:31:51

Wow


---

### 1759. msg_7087

**You** - 2025-05-02T20:31:53

No family here mer


---

### 1760. msg_7088

**You** - 2025-05-02T20:31:56

Not really


---

### 1761. msg_7089

**You** - 2025-05-02T20:32:06

Used to be diff pre pandemic


---

### 1762. msg_7090

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:32:11

Yeah


---

### 1763. msg_7091

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:32:25

Altho


---

### 1764. msg_7092

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:32:46

During Covid I made my kids play ticket to ride too much and they have resentment


---

### 1765. msg_7093

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:32:49

lol


---

### 1766. msg_7094

**You** - 2025-05-02T20:33:15

It’s a strategy game right


---

### 1767. msg_7095

**You** - 2025-05-02T20:36:41

So do me a favour chatgpt Europa universalis 4 and ask it to do a comparison to ticket to ride\.\. I think it could
Make it interesting for you\.


---

### 1768. msg_7096

**You** - 2025-05-02T20:38:18

That was the game I played for 10
Years to get through my marriage


---

### 1769. msg_7097

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:40:24

😮

*1 attachment(s)*


---

### 1770. msg_7098

**You** - 2025-05-02T20:40:44

😇


---

### 1771. msg_7099

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:40:57

That is so true wow


---

### 1772. msg_7100

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:40:58

lol


---

### 1773. msg_7101

**You** - 2025-05-02T20:41:03

I have played strategy games
Like that online since I was
12


---

### 1774. msg_7102

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:41:05

Such a nice short game


---

### 1775. msg_7103

**You** - 2025-05-02T20:41:09

:\)


---

### 1776. msg_7104

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:41:12

\(Ticket to ride\)


---

### 1777. msg_7105

**You** - 2025-05-02T20:41:31

First strategy
Game
I played was a Baird
Game
Called
Bazaar
Though


---

### 1778. msg_7106

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:41:32

And you stopped playing them?


---

### 1779. msg_7107

**You** - 2025-05-02T20:41:35

Got me hooked


---

### 1780. msg_7108

**You** - 2025-05-02T20:41:43

Yeah I don’t play anymore


---

### 1781. msg_7109

**You** - 2025-05-02T20:41:47

Been a few years


---

### 1782. msg_7110

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:41:51

Reaction: 👍 from Scott Hicks
Omg he left


---

### 1783. msg_7111

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:42:26

>
Why’d you stop?


---

### 1784. msg_7112

**You** - 2025-05-02T20:42:41

Lost its fun life
Just sucked too much


---

### 1785. msg_7113

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:43:14

Board games\. Start end\. Fini\.


---

### 1786. msg_7114

**You** - 2025-05-02T20:43:48

Didn’t have anyone


---

### 1787. msg_7115

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:44:33

What about cards


---

### 1788. msg_7116

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:44:38

Second best


---

### 1789. msg_7117

**You** - 2025-05-02T20:44:53

Used to play when I was
Younger up till I was married


---

### 1790. msg_7118

**You** - 2025-05-02T20:44:55

Cribbage


---

### 1791. msg_7119

**You** - 2025-05-02T20:44:59

200’s


---

### 1792. msg_7120

**You** - 2025-05-02T20:45:03

Which is like euchre


---

### 1793. msg_7121

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:45:11

My dad was obsessed with crib


---

### 1794. msg_7122

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:45:16

I used to play with him


---

### 1795. msg_7123

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:45:55

My kids basically know gin rummy, crazy 8s and go fish


---

### 1796. msg_7124

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:46:04

They have learned euchre maybe once


---

### 1797. msg_7125

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:46:21

I make them play gin rummy a lot\. I like it\. Lifeguarding game


---

### 1798. msg_7126

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:46:32

They had to learn\. No choice


---

### 1799. msg_7127

**You** - 2025-05-02T20:46:37

Played gin rummy drinking game


---

### 1800. msg_7128

**You** - 2025-05-02T20:46:38

lol


---

### 1801. msg_7129

**You** - 2025-05-02T20:46:44

I learned a lot of card games


---

### 1802. msg_7130

**You** - 2025-05-02T20:46:48

When I wa
You get


---

### 1803. msg_7131

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:46:50

My grandparents and mom used to make us play bridge


---

### 1804. msg_7132

**You** - 2025-05-02T20:46:53

Younger


---

### 1805. msg_7133

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:47:26

>
We played hours and hours and betted lifeguarding lol


---

### 1806. msg_7134

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:47:31

Hearts?


---

### 1807. msg_7135

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T20:47:39

My grandpa loved hearts


---

### 1808. msg_7136

**You** - 2025-05-02T20:49:09

Hearts on comp


---

### 1809. msg_7137

**You** - 2025-05-02T20:49:13

Mostly in university


---

### 1810. msg_7138

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:04:31

“How many rounds are we playing?”

*1 attachment(s)*


---

### 1811. msg_7139

**You** - 2025-05-02T21:06:46

That is an awwww mum moment


---

### 1812. msg_7140

**You** - 2025-05-02T21:32:49

Aww I had an idea of a risky thing to do for you tonight to make you smile but not sure I am up
For it lol some other time maybe


---

### 1813. msg_7141

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:33:56

🤔


---

### 1814. msg_7142

**You** - 2025-05-02T21:34:08

Well I am heading to the hot tub then the shower


---

### 1815. msg_7143

**You** - 2025-05-02T21:34:32

But nah


---

### 1816. msg_7144

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:34:37

lol


---

### 1817. msg_7145

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:34:50

You could write a sitcom


---

### 1818. msg_7146

**You** - 2025-05-02T21:35:19

I mean if it was about locking a try hard 47 year old man\.\. yep


---

### 1819. msg_7147

**You** - 2025-05-02T21:35:23

Mocking


---

### 1820. msg_7148

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:35:58

lol ok


---

### 1821. msg_7149

**You** - 2025-05-02T21:36:24

Some other time I figured out how to make it work\.\. lol too much time on my hands and slightly insane for you\.


---

### 1822. msg_7150

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:37:01

Sorry, am I supposed to understand that?


---

### 1823. msg_7151

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:38:45

https://open\.spotify\.com/track/1aZfq7TK3tNl9XJLkOpwKw?si=yzdIJJweT\_6rlIu2Vxnn3g


---

### 1824. msg_7152

**You** - 2025-05-02T21:39:00

Nope fail


---

### 1825. msg_7153

**You** - 2025-05-02T21:39:04

Won’t work


---

### 1826. msg_7154

**You** - 2025-05-02T21:39:16

There is a clear plastic bag for wet clothes


---

### 1827. msg_7155

**You** - 2025-05-02T21:39:23

But cannot video through


---

### 1828. msg_7156

**You** - 2025-05-02T21:39:54

Still safe to bring in hot tub


---

### 1829. msg_7157

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:40:51

I hope you read this later\.


---

### 1830. msg_7158

**You** - 2025-05-02T21:40:57

Read what


---

### 1831. msg_7159

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:41:19

I’m just so confused


---

### 1832. msg_7160

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:41:21

lol


---

### 1833. msg_7161

**You** - 2025-05-02T21:41:22

Oh you want me to revisit


---

### 1834. msg_7162

**You** - 2025-05-02T21:41:36

Ah ok


---

### 1835. msg_7163

**You** - 2025-05-02T21:41:40

Sure maybe


---

### 1836. msg_7164

**You** - 2025-05-02T21:42:08

You must be completely messed right now


---

### 1837. msg_7165

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:42:23

😇👼😇👼😇👼😇👼😇👼😇


---

### 1838. msg_7166

**You** - 2025-05-02T21:42:24

Jealous


---

### 1839. msg_7167

**You** - 2025-05-02T21:44:07

I am not sure we are going to be able to have a conversation later not sure you will be coherent by then lol


---

### 1840. msg_7168

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:44:24

Definitely possible


---

### 1841. msg_7169

**You** - 2025-05-02T21:44:45

Ah well will just go to bed early


---

### 1842. msg_7170

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:44:58

I am not sleepy


---

### 1843. msg_7171

**You** - 2025-05-02T21:45:50

O I know you aren’t but you are going to be in your own little world by the time I get home showering now


---

### 1844. msg_7172

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:46:01

LOL


---

### 1845. msg_7173

**You** - 2025-05-02T21:53:39

Less than satisfactory


---

### 1846. msg_7174

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:54:22

\[lol no words\]


---

### 1847. msg_7175

**You** - 2025-05-02T21:55:21

Another first I look forward to


---

### 1848. msg_7176

**You** - 2025-05-02T21:55:42

Mistake


---

### 1849. msg_7177

**You** - 2025-05-02T21:55:44

Phew


---

### 1850. msg_7178

**You** - 2025-05-02T21:55:45

lol


---

### 1851. msg_7179

**You** - 2025-05-02T21:55:53

That would have been slightly awkward


---

### 1852. msg_7180

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:55:55

Phew?


---

### 1853. msg_7181

**You** - 2025-05-02T21:56:19

I called you by mistake


---

### 1854. msg_7182

**You** - 2025-05-02T21:56:23

Hung up fast


---

### 1855. msg_7183

**You** - 2025-05-02T21:56:24

lol


---

### 1856. msg_7184

**You** - 2025-05-02T21:56:35

Wasn’t decent


---

### 1857. msg_7185

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:57:02

lol man you are loving that gym until the end eh


---

### 1858. msg_7186

**You** - 2025-05-02T21:57:20

Like I said
Might keep it my only refuge atm


---

### 1859. msg_7187

**You** - 2025-05-02T21:58:07

At least
Till I move out


---

### 1860. msg_7188

**You** - 2025-05-02T21:58:15

Still have to decide rent or buy


---

### 1861. msg_7189

**You** - 2025-05-02T21:58:20

Working k\. That tonight


---

### 1862. msg_7190

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:58:54

For real? Working \*on that tonight?


---

### 1863. msg_7191

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T21:59:00

Ew no


---

### 1864. msg_7192

**You** - 2025-05-02T21:59:34

Cannot do anything else


---

### 1865. msg_7193

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:00:33

Talk to me


---

### 1866. msg_7194

**You** - 2025-05-02T22:00:58

Well I can do both but I doubt I can get high


---

### 1867. msg_7195

**You** - 2025-05-02T22:01:15

Cause Jaimie drinking and I think someone will have to get Gracie


---

### 1868. msg_7196

**You** - 2025-05-02T22:01:34

Even though we told her to either stay or
Get a drive she will call or someone will call to come get her


---

### 1869. msg_7197

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:02:15

Uber


---

### 1870. msg_7198

**You** - 2025-05-02T22:02:37

She will be too drunk no doubt


---

### 1871. msg_7199

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:02:54

I had to put $100/ month in my expenses for rando ubers


---

### 1872. msg_7200

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:03:23

\(And those aren’t me\)


---

### 1873. msg_7201

**You** - 2025-05-02T22:03:56

Rofl


---

### 1874. msg_7202

**You** - 2025-05-02T22:04:00

I mean the fucking detail


---

### 1875. msg_7203

**You** - 2025-05-02T22:04:04

Omfg


---

### 1876. msg_7204

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:04:17

lol


---

### 1877. msg_7205

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:04:33

What more detail do you require


---

### 1878. msg_7206

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:04:48

Perfectionist much?


---

### 1879. msg_7207

**You** - 2025-05-02T22:05:01

No I am not criticizing


---

### 1880. msg_7208

**You** - 2025-05-02T22:05:10

That is like 5x
The detail


---

### 1881. msg_7209

**You** - 2025-05-02T22:05:12

I went to


---

### 1882. msg_7210

**You** - 2025-05-02T22:05:16

Too much


---

### 1883. msg_7211

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:05:19

Ohhh


---

### 1884. msg_7212

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:05:29

My budget is very specific


---

### 1885. msg_7213

**You** - 2025-05-02T22:05:40

Yeah I can tell


---

### 1886. msg_7214

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:05:45

Wanted to make sure he knows what I spend on his daughters


---

### 1887. msg_7215

**You** - 2025-05-02T22:05:54

Like I said we didn’t go bottom up we went too down


---

### 1888. msg_7216

**You** - 2025-05-02T22:06:27

Here is how much you get…\.
It is a lot more than k get…\. Figure it out


---

### 1889. msg_7217

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:06:29

Do one and calibrate with the other


---

### 1890. msg_7218

**You** - 2025-05-02T22:06:36

I like my approach


---

### 1891. msg_7219

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:07:12

I generally like your approaches\.


---

### 1892. msg_7220

**You** - 2025-05-02T22:07:54

Dev


---

### 1893. msg_7221

**You** - 2025-05-02T22:09:28

Sec


---

### 1894. msg_7222

**You** - 2025-05-02T22:36:05

Friday you tried something I was like nope\.\. then relented\.\. then funny shit happened\.\.
Which you won’t remember anyways and then I explained\.


---

### 1895. msg_7223

**You** - 2025-05-02T22:36:55

Because you were persistent lol\.\. I am fairly certain I allowed
You to be much more persistent than me\.


---

### 1896. msg_7224

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:38:46

Were you upset?


---

### 1897. msg_7225

**You** - 2025-05-02T22:50:28

lol about what


---

### 1898. msg_7226

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:51:08

That I was so persistent


---

### 1899. msg_7227

**You** - 2025-05-02T22:52:02

Hardly it was amazing but I am still self conscious\.\.


---

### 1900. msg_7228

**You** - 2025-05-02T22:52:15

But  I wanted the same opportunity I guess


---

### 1901. msg_7229

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:52:50

I just don’t think I enjoy it like a guy does


---

### 1902. msg_7230

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:53:07

Something different about the whole thing with guys and girls


---

### 1903. msg_7231

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T22:54:00

\(I now know what a burnt vape tastes like…\. Doesn’t deserve the word “burnt”\. So much less than that…\. 🙄\)


---

### 1904. msg_7232

**You** - 2025-05-02T23:07:06

Rofl


---

### 1905. msg_7233

**You** - 2025-05-02T23:07:54

>
I think we should try at least
Once and if no then find something else\. Imho\. Maybe it will be different…


---

### 1906. msg_7234

**You** - 2025-05-02T23:08:02

Sorry fighting with Jaimie again\.


---

### 1907. msg_7235

**You** - 2025-05-02T23:08:06

Now done


---

### 1908. msg_7236

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T23:12:40

lol


---

### 1909. msg_7237

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T23:12:47

Neverending story


---

### 1910. msg_7238

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T23:13:00

On both sides


---

### 1911. msg_7239

**You** - 2025-05-02T23:17:13

Reaction: ❤️ from Meredith Lamb
>
Mmmmmmhmmmmmm


---

### 1912. msg_7240

**You** - 2025-05-02T23:21:54

Sooo……\.


---

### 1913. msg_7241

**You** - 2025-05-02T23:22:12

Cmon you know how this works


---

### 1914. msg_7242

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T23:22:59

I’m not sure I do\.


---

### 1915. msg_7243

**You** - 2025-05-02T23:23:46

Well I am unsure what the heart means in this context lol


---

### 1916. msg_7244

**Meredith Lamb \(\+14169386001\)** - 2025-05-02T23:31:11

Ong im too stoned for this… lol


---

### 1917. msg_7245

**You** - 2025-05-02T23:39:34

Oh sure you are


---

### 1918. msg_7246

**You** - 2025-05-02T23:39:41

It’s ok you don’t have to engage


---

### 1919. msg_7247

**You** - 2025-05-02T23:39:52

I know this is hard for you\.s


---

### 1920. msg_7248

**You** - 2025-05-02T23:49:43

Reaction: 😢 from Meredith Lamb
You went to sleep\.\. kk I am going to go to bed tired
Of
Fighting with j another shit night  here I need to fucking leave\.


---

### 1921. msg_7249

**You** - 2025-05-02T23:51:40

Man almost went full lawyers tonight


---

### 1922. msg_7250

**You** - 2025-05-02T23:59:26

😢


---

### 1923. msg_7251

**You** - 2025-05-03T00:00:10

Reaction: ❤️ from Meredith Lamb
I wish I could see you


---

### 1924. msg_7252

**You** - 2025-05-03T01:00:10

…\.\.


---

### 1925. msg_7253

**You** - 2025-05-03T04:58:25

Omfg worst sleep ever cannot even… going to gym\.


---

### 1926. msg_7254

**You** - 2025-05-03T05:52:21

Told Jaimie before I left no more fighting at all I don’t care what anyone says or spits out I am not fighting


---

### 1927. msg_7255

**You** - 2025-05-03T06:23:37

Reaction: ❤️ from Meredith Lamb
Well the one shiny thing this morning 17\.2% body fat at 232 lbs pretty pleased about that down from 252 and well\. Lot more body fat lol\.


---

### 1928. msg_7256

**You** - 2025-05-03T06:36:42

Thought about it last night I am going to buy\.  I don’t want to
Just dump money in a rental only to buy later\.\. I figure if and when you are ever ready for to cohabitate which could be some time into the future I would be better served to own something even if I get dinged with real estate fees down the road


---

### 1929. msg_7257

**You** - 2025-05-03T06:36:56

Just sharing as I kind of came to a decision when trying to fall asleep last night


---

### 1930. msg_7258

**You** - 2025-05-03T06:53:58

Hope you are not too hung over this morning


---

### 1931. msg_7259

**You** - 2025-05-03T07:13:02

Think maybe pic this morning 🤔


---

### 1932. msg_7260

**You** - 2025-05-03T07:32:29

Maybe not if you aren’t up yet


---

### 1933. msg_7261

**You** - 2025-05-03T08:10:20

Sorry you will have lots
To read
Shitty night no sleep up early and no one to talk to sorry you are it


---

### 1934. msg_7262

**You** - 2025-05-03T08:21:58

Well I dunno workout done lazy person still sleeping going in sauna and steam room check in after


---

### 1935. msg_7263

**You** - 2025-05-03T09:00:56

Still sleeping I don’t think you deserve have to earn\.


---

### 1936. msg_7264

**You** - 2025-05-03T09:02:06

Pics are there though going to have a shower\.


---

### 1937. msg_7265

**You** - 2025-05-03T09:20:45

You are never getting up


---

### 1938. msg_7266

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T09:34:40

Never getting up indeed\. Think I’m still passed out honestly lol


---

### 1939. msg_7267

**You** - 2025-05-03T09:36:19

Well you have a lot to read I will let you to it\.


---

### 1940. msg_7268

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T09:39:21

Wow how many hours between your gym trips?


---

### 1941. msg_7269

**You** - 2025-05-03T09:40:05

Not enough and I went stupid hard today had a really fucked up bad night\.


---

### 1942. msg_7270

**You** - 2025-05-03T09:40:09

No sleep


---

### 1943. msg_7271

**You** - 2025-05-03T09:41:39

Oh you can call me if you want I am just I\. Car driving around looking at houses


---

### 1944. msg_7272

**You** - 2025-05-03T09:56:07

Actually nm I have to go home now and pick up j to bring her to Costco then looking at a townhome for me


---

### 1945. msg_7273

**You** - 2025-05-03T09:56:23

Think maybe you went back to sleep lol


---

### 1946. msg_7274

**You** - 2025-05-03T09:58:03

I had hoped to see
You this weekend even for a few mins but doesn’t look like it’s doable\.  Maybe we can catch up on the above stuff later sometime\.


---

### 1947. msg_7275

**You** - 2025-05-03T10:00:32

lol sigh well talk to you later shutting this down for a while\.


---

### 1948. msg_7276

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:16:49

I think I was still high this morning\. lol just waking up


---

### 1949. msg_7277

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:17:04

Sorry


---

### 1950. msg_7278

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:17:31

I will read all your stuff over my coffee when I get it made gah


---

### 1951. msg_7279

**You** - 2025-05-03T11:26:22

Just out at Costco now with j ☹️


---

### 1952. msg_7280

**You** - 2025-05-03T11:26:44

Hope home soo


---

### 1953. msg_7281

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:36:42

Wow I was a mess at like 9pm last night 😝


---

### 1954. msg_7282

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:37:53

Sorry about that but my brain really needed that\. It feels so much better today\.


---

### 1955. msg_7283

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:38:37

I feel like you had so many revelations and made so many decisions


---

### 1956. msg_7284

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:40:44

>
I think I stared at this last night and my hands were paralyzed at the time\. Lol I was so f’cked up


---

### 1957. msg_7285

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:40:54

So I couldn’t respond


---

### 1958. msg_7286

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:42:09

>
Given the uncertainty of our respective situations I would totally do what your gut it telling you and what you think is right\. Buying is right if you can


---

### 1959. msg_7287

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:43:03

Reaction: ❤️ from Scott Hicks
But yes, I absolutely envision us living together and everyone being annoyed about it except for us\. 🫠


---

### 1960. msg_7288

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:50:19

>
\[deleted\]


---

### 1961. msg_7289

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T11:50:23

lol


---

### 1962. msg_7290

**You** - 2025-05-03T12:22:01

Deleted I am sure that was interesting


---

### 1963. msg_7291

**You** - 2025-05-03T12:22:45

>
You were a bit of a mess\.\.but it is understandable with what you are
Going through


---

### 1964. msg_7292

**You** - 2025-05-03T12:23:28

Sucks though lonely… like hanging with j is not companionship lol\.\. but it sounds again as if she is relegated
To going back
To Moncton


---

### 1965. msg_7293

**You** - 2025-05-03T12:24:33

You are probably out shopping or doing bat mitzvah stuff


---

### 1966. msg_7294

**You** - 2025-05-03T12:24:48

Will check in later


---

### 1967. msg_7295

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:36:12

I had to drop Maelle off at work


---

### 1968. msg_7296

**You** - 2025-05-03T12:37:06

Nah it’s all
Good
You have a busy few days


---

### 1969. msg_7297

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:37:24

>
I mean, I think when you going through a separation it is supposed to be kind of lonely so not unusual really\.


---

### 1970. msg_7298

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:38:26

>
I’m just a chauffeur on demand disguised as a real person :p


---

### 1971. msg_7299

**You** - 2025-05-03T12:38:52

Sounds about right


---

### 1972. msg_7300

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:39:43

>
Why are you hanging out together tho?


---

### 1973. msg_7301

**You** - 2025-05-03T12:40:40

I offered to pick some stuff up at Costco for her she asked if I would pick her up and bring her I said fine


---

### 1974. msg_7302

**You** - 2025-05-03T12:40:51

We talked about Gracie’s night last night


---

### 1975. msg_7303

**You** - 2025-05-03T12:41:02

Her moving to Moncton


---

### 1976. msg_7304

**You** - 2025-05-03T12:41:17

Not sure how many more flips\.


---

### 1977. msg_7305

**You** - 2025-05-03T12:41:49

Not really “hanging out” equivalent to you and Andrew “hanging out at
Cottage”\. Well not cottage is def worse


---

### 1978. msg_7306

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:42:17

We don’t hang out at the cottage


---

### 1979. msg_7307

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:42:44

For like probably a couple of years honestly


---

### 1980. msg_7308

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:43:04

We have a very large cottage … no hanging out together required


---

### 1981. msg_7309

**You** - 2025-05-03T12:45:28

Ok well now I am down in my basement with the door locked……\.\. where I belong\.


---

### 1982. msg_7310

**You** - 2025-05-03T12:45:41

😔 kinda lol


---

### 1983. msg_7311

**You** - 2025-05-03T12:48:50

Better imagery lights off listening to sad country\.\.


---

### 1984. msg_7312

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:49:00

You don’t belong there\.


---

### 1985. msg_7313

**You** - 2025-05-03T12:49:12

I have no where to go


---

### 1986. msg_7314

**You** - 2025-05-03T12:49:18

It is what it is


---

### 1987. msg_7315

**You** - 2025-05-03T12:50:34

We just have very different situations so we will experience this differently


---

### 1988. msg_7316

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:50:34

https://open\.spotify\.com/track/0iPyyo8GtCAgRGEmxldAGi?si=DfIiJkyyQtuUxZapDWVp0Q
Do you know this one? Great sad song… :\)


---

### 1989. msg_7317

**You** - 2025-05-03T12:50:55

I don’t but I will put
It on the sad list


---

### 1990. msg_7318

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:51:08

One of my favourite songs


---

### 1991. msg_7319

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:51:15

Altho that list is long lol


---

### 1992. msg_7320

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:52:01

>
I guess\. Just don’t mention j gym and Costco excursions maybe\. My head will take that and do what it will…\.


---

### 1993. msg_7321

**You** - 2025-05-03T12:54:42

Kk we don’t do anything together I stay down here with door locked on my own 90% of time\.


---

### 1994. msg_7322

**You** - 2025-05-03T12:54:48

Or I go to gym


---

### 1995. msg_7323

**You** - 2025-05-03T12:54:55

Like I will go back again tonight


---

### 1996. msg_7324

**You** - 2025-05-03T12:55:09

I will refrain from mentioning j


---

### 1997. msg_7325

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:55:23

Just in that context


---

### 1998. msg_7326

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T12:55:37

Lovely little excursion context lol


---

### 1999. msg_7327

**You** - 2025-05-03T12:56:05

Reaction: 😂 from Meredith Lamb
I hardly provided anywhere near
That context\.


---

### 2000. msg_7328

**You** - 2025-05-03T12:56:34

I do the least amount I have to do insofar as engaging her


---

### 2001. msg_7329

**You** - 2025-05-03T12:59:15

I’m just going to go to sleep\.


---

### 2002. msg_7330

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T13:01:21

:\( I feel like I made you sadder\.


---

### 2003. msg_7331

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T13:03:02

It would be so much easier if I was there in person\. Gah\.


---

### 2004. msg_7332

**You** - 2025-05-03T13:04:10

It’s fine mer nothing you can do\.  You got your own stuff don’t worry about it\.


---

### 2005. msg_7333

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T13:06:56

Always stuff I can do ❤️


---

### 2006. msg_7334

**You** - 2025-05-03T13:07:48

I ❤️u too\.\. but I don’t think There is hon


---

### 2007. msg_7335

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T13:11:42

Just know I want to always be there for you … even if I was absent this time\. Brain fried\. lol I won’t make a habit of it


---

### 2008. msg_7336

**You** - 2025-05-03T13:12:27

I don’t blame you mer like I said I understand\.


---

### 2009. msg_7337

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:09:15

Bat mitzvah dresses organized\. Cards, $ etc\!


---

### 2010. msg_7338

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:09:49

Remind me not get so messed up when I have a million things to do the next day\. Omg

*1 attachment(s)*


---

### 2011. msg_7339

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:09:52

Painful


---

### 2012. msg_7340

**You** - 2025-05-03T14:10:47

Congrats climbed a small mountain\.  I am just
Getting up no sleep just done laying down\. I felt like you needed it\.\. I was concerned you hit yourself pretty hard last night\.\. lots of stuff like I said would put me under\.


---

### 2013. msg_7341

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:11:53

I was under\! Haha


---

### 2014. msg_7342

**You** - 2025-05-03T14:11:56

>
She’s cute love
The pose\!  Ur
Cute too of course


---

### 2015. msg_7343

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:12:39

I need a nap now lol


---

### 2016. msg_7344

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:12:43

Having a coffee


---

### 2017. msg_7345

**You** - 2025-05-03T14:13:02

Reaction: 😮 from Meredith Lamb
I haven’t even had my 1st yet just about to sit down to computer and have it


---

### 2018. msg_7346

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T14:15:34

Omg my friends are “interesting”\. They wanted to go to a spa\. Couldn’t find anything\. Now we are back where we started\. This convo is like 4\-6 weeks long…\.\.

*1 attachment(s)*


---

### 2019. msg_7347

**You** - 2025-05-03T16:43:02

Well back from another house hunting adventure\. So expensive\.


---

### 2020. msg_7348

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T16:46:58

How’d it go?


---

### 2021. msg_7349

**You** - 2025-05-03T16:52:17

Well I saw a nursery house


---

### 2022. msg_7350

**You** - 2025-05-03T16:52:21

Murder


---

### 2023. msg_7351

**You** - 2025-05-03T16:52:27

That was a first


---

### 2024. msg_7352

**You** - 2025-05-03T16:53:19

Then I went to a new development looked at a town for about 875


---

### 2025. msg_7353

**You** - 2025-05-03T16:53:31

Could get it for a little less
But not much


---

### 2026. msg_7354

**You** - 2025-05-03T16:54:09

Going to do a bit of research see
What I can find out met a nice young real estate agent at the murder house might engage him to help me


---

### 2027. msg_7355

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T16:54:33

>
?


---

### 2028. msg_7356

**You** - 2025-05-03T16:54:36

I mean I could afford the new one if I structured the mortgage right


---

### 2029. msg_7357

**You** - 2025-05-03T16:54:45

Reaction: 😮 from Meredith Lamb
Someone was killed there in 2017


---

### 2030. msg_7358

**You** - 2025-05-03T16:55:33

Anyhow gave me something to do and I was bored


---

### 2031. msg_7359

**You** - 2025-05-03T16:56:20

Now I have to think of what to do next but I feel like it will be eat
Something a bit of work and back to gym


---

### 2032. msg_7360

**You** - 2025-05-03T16:56:52

Yeah it was a no go after that


---

### 2033. msg_7361

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T16:58:02

It is incredible how we are both in so limbo today when we could be together…\. It is so weird\.


---

### 2034. msg_7362

**You** - 2025-05-03T16:58:17

How could we be together\!\! lol


---

### 2035. msg_7363

**You** - 2025-05-03T16:58:23

That is all I wanted rofl


---

### 2036. msg_7364

**You** - 2025-05-03T16:58:31

But you had a million things to do\.


---

### 2037. msg_7365

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T16:58:33

I mean like technically we could but obviously we can’t\.


---

### 2038. msg_7366

**You** - 2025-05-03T16:58:38

Rofl


---

### 2039. msg_7367

**You** - 2025-05-03T16:58:56

Ok I was like what… srsly


---

### 2040. msg_7368

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T16:59:04

lol sorry


---

### 2041. msg_7369

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T16:59:17

I have gotten a lot done


---

### 2042. msg_7370

**You** - 2025-05-03T16:59:28

Yep
Sucks super bad but is what it is\.


---

### 2043. msg_7371

**You** - 2025-05-03T16:59:42

I have not gotten a ton done\.\. because no one wants to help


---

### 2044. msg_7372

**You** - 2025-05-03T17:00:11

The trick here is either Jaimie moves sooner than me and we get her a mortgage and I sell
This house and then figure out the money


---

### 2045. msg_7373

**You** - 2025-05-03T17:00:19

Or I buy and the reverse


---

### 2046. msg_7374

**You** - 2025-05-03T17:00:40

But glad
You got a lot
Done\!


---

### 2047. msg_7375

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:01:37

Reaction: 👍 from Scott Hicks
Well not a lot for separating but a lot for bat mitzvah la and 14th birthday


---

### 2048. msg_7376

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:01:39

lol


---

### 2049. msg_7377

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:11:37


*1 attachment(s)*


---

### 2050. msg_7378

**You** - 2025-05-03T17:12:25

Very classy and cost effective


---

### 2051. msg_7379

**You** - 2025-05-03T17:14:11



---

### 2052. msg_7380

**You** - 2025-05-03T17:14:30

Oops


---

### 2053. msg_7381

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:14:32

Why did you delete that


---

### 2054. msg_7382

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:14:43

>
Didn’t buy a thing


---

### 2055. msg_7383

**You** - 2025-05-03T17:14:46

Mistakes were made


---

### 2056. msg_7384

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:15:07

😐


---

### 2057. msg_7385

**You** - 2025-05-03T17:15:33

Mmmmm hmmmm


---

### 2058. msg_7386

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:16:02

This is challenging\. lol


---

### 2059. msg_7387

**You** - 2025-05-03T17:16:37



---

### 2060. msg_7388

**You** - 2025-05-03T17:16:59

Nope


---

### 2061. msg_7389

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:17:17

I like that you are a people pleaser but the deleter in you, no


---

### 2062. msg_7390

**You** - 2025-05-03T17:17:22

You were sleeping this morning when I offered you kissed out


---

### 2063. msg_7391

**You** - 2025-05-03T17:17:31

Missed


---

### 2064. msg_7392

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:17:44

That wasn’t fair bc I wasn’t awake


---

### 2065. msg_7393

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:17:53

I think I was still high lol


---

### 2066. msg_7394

**You** - 2025-05-03T17:18:12

I feel like it was
Kinda
Fair then I said you could earn it\.
But then you stayed asleep
For like 3’more hours
lol


---

### 2067. msg_7395

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:18:35

🙊


---

### 2068. msg_7396

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:18:49

I couldn’t type\. My hands were paralyzed


---

### 2069. msg_7397

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:18:53

Like seriously


---

### 2070. msg_7398

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:18:55

Haha


---

### 2071. msg_7399

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:19:08

I was very messed up


---

### 2072. msg_7400

**You** - 2025-05-03T17:19:13


*3 attachment(s)*


---

### 2073. msg_7401

**You** - 2025-05-03T17:19:29

The steam room one was too sweaty


---

### 2074. msg_7402

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:19:49

I know nothing about too sweaty


---

### 2075. msg_7403

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:20:07

Can you not delete those pls\.


---

### 2076. msg_7404

**You** - 2025-05-03T17:20:08


*1 attachment(s)*


---

### 2077. msg_7405

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:20:59

Sigh


---

### 2078. msg_7406

**You** - 2025-05-03T17:21:04

I figured that i am
Self
Conscious I could care less
If anyone likes me but you anyways\.  So if it makes you happy regardless of what I think I am happy to share


---

### 2079. msg_7407

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:21:25

I have zero workout photos but maybe eventually\. I used to take them nonstop


---

### 2080. msg_7408

**You** - 2025-05-03T17:21:38

I never did


---

### 2081. msg_7409

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:22:13

I used to IG my fitness stuff\. Hence Ehsan’s knowledge\. We followed each other


---

### 2082. msg_7410

**You** - 2025-05-03T17:22:26

Yeah no I won’t be doing that\.


---

### 2083. msg_7411

**You** - 2025-05-03T17:22:39

And I can probably delete them if I want to\.


---

### 2084. msg_7412

**You** - 2025-05-03T17:22:44

But I won’t


---

### 2085. msg_7413

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:22:54

Thank you


---

### 2086. msg_7414

**You** - 2025-05-03T17:25:40

Kk I am going to make
Myself supped and then go to the gym\.\. maybe chat later\.\.
You have been pretty
Busy and a bit distracted\.\. so don’t worry if you not up for it\.


---

### 2087. msg_7415

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:26:36

Omg gym again lol


---

### 2088. msg_7416

**You** - 2025-05-03T17:27:11

Just hot tub and sauna and steam then I get up at 5 am tomorrow for workout\.\.
Switching to mornings\.


---

### 2089. msg_7417

**You** - 2025-05-03T17:27:50

And I have nothing else
To do\.\. so there
Is that too\.\. and I hate it here\.\. so pretty easy choice


---

### 2090. msg_7418

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:28:25

Yeah I get that


---

### 2091. msg_7419

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:29:09

Reaction: ❤️ from Scott Hicks
6am a month before I quit union\. Was working for Ehsan and if he was a better mgr I might have stayed lol

*1 attachment(s)*


---

### 2092. msg_7420

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:29:41

I was obsessed with morning workouts and you getting obsessed is bring back that feeling in my head lol


---

### 2093. msg_7421

**You** - 2025-05-03T17:31:45

It is just a means to an end for me\.


---

### 2094. msg_7422

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:33:45

For me it was an outlet like what you are doing\. After a bad 2016 experience\. So I get what you are doing\. I did the same…

*1 attachment(s)*


---

### 2095. msg_7423

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:34:46

It is a good thing … need to get back there but my mom is like “just don’t get so obsessive about it”


---

### 2096. msg_7424

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:35:02

She should meet you and hear your gym schedule


---

### 2097. msg_7425

**You** - 2025-05-03T17:35:05

I just want to be happy that is it


---

### 2098. msg_7426

**You** - 2025-05-03T17:35:21

I would love to meet
Your mum whenever the time is right


---

### 2099. msg_7427

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:35:44

2 yrs


---

### 2100. msg_7428

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:35:47

Kidding


---

### 2101. msg_7429

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T17:36:18

K I have to go pick Maelle up from work and then take her to her bat mitzvah


---

### 2102. msg_7430

**You** - 2025-05-03T17:36:21

☹️


---

### 2103. msg_7431

**You** - 2025-05-03T17:36:32

I don’t even like my joke anymore


---

### 2104. msg_7432

**You** - 2025-05-03T17:36:48

You are right it wasn’t funny when I said it


---

### 2105. msg_7433

**You** - 2025-05-03T17:36:56

Kk have fun


---

### 2106. msg_7434

**You** - 2025-05-03T17:39:43

Reaction: ❤️ from Meredith Lamb
Maybe chat later\.


---

### 2107. msg_7435

**You** - 2025-05-03T17:56:59

>
It would be interesting given the opportunity to work out with you\.  Could be a lot of fun\.


---

### 2108. msg_7436

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:25:44

I would enjoy that if I was semi in shape\. I hate working out with ppl when I am not in shape\. Lol


---

### 2109. msg_7437

**You** - 2025-05-03T18:28:16

Well I am a good motivator


---

### 2110. msg_7438

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:33:41

You are


---

### 2111. msg_7439

**You** - 2025-05-03T18:34:19

Anyhow it could be fun but it is a ways off lots to focus on until then


---

### 2112. msg_7440

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:36:27

She won’t get out of the car bc her hair is “wet” from lifeguarding\.

*2 attachment(s)*


---

### 2113. msg_7441

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:36:55

It isn’t that wet


---

### 2114. msg_7442

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:37:05

I still have a 30 min drive home


---

### 2115. msg_7443

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:37:07

Fack


---

### 2116. msg_7444

**You** - 2025-05-03T18:37:08

Not at all looks nice


---

### 2117. msg_7445

**You** - 2025-05-03T18:37:28

Sorry you look non\-plussed


---

### 2118. msg_7446

**You** - 2025-05-03T18:37:43

So 30 mins home then when you going back to get her?


---

### 2119. msg_7447

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:38:51

Omfg her phone is dead so I have to charge it for 10\-15 min before I leave


---

### 2120. msg_7448

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:39:01

Otherwise she has no way to text me for a ride home


---

### 2121. msg_7449

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:39:19

This kid… I swear


---

### 2122. msg_7450

**You** - 2025-05-03T18:39:35

Errr yeah fucked night


---

### 2123. msg_7451

**You** - 2025-05-03T18:40:39

Sorry mer that sucks no fun tonight


---

### 2124. msg_7452

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:41:46

Kids are so fucking annoying sometimes


---

### 2125. msg_7453

**You** - 2025-05-03T18:42:10

Yep I know… it makes a difficult day so much moreso


---

### 2126. msg_7454

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:42:31

https://open\.spotify\.com/track/7lGKEWMXVWWTt3X71Bv44I?si=ZWtaj5miSZu032M\_xYLkjA


---

### 2127. msg_7455

**You** - 2025-05-03T18:42:45

lol always a song


---

### 2128. msg_7456

**You** - 2025-05-03T18:43:04

Well I am busy putting together a one not journal while I am eating


---

### 2129. msg_7457

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:43:22

One note for what


---

### 2130. msg_7458

**You** - 2025-05-03T18:46:27

Sec


---

### 2131. msg_7459

**You** - 2025-05-03T18:49:26

It’s a chat for inspired journal for me with sections for different types of information… I need an outlet\.


---

### 2132. msg_7460

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:51:07

Good idea\. I mean providing no one snoops through your stuff


---

### 2133. msg_7461

**You** - 2025-05-03T18:51:23

No one can access it


---

### 2134. msg_7462

**You** - 2025-05-03T18:51:49

Anyhow it covers a lot of stuff and I have way too much going on so need to let it out\.


---

### 2135. msg_7463

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:52:23

Do you think it was a great time to go off anxiety meds?


---

### 2136. msg_7464

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:52:32

🤔


---

### 2137. msg_7465

**You** - 2025-05-03T18:53:35

Yea I have to learn to deal with this\. On my own\.  And this is too much to share\.\. so this is the only other option I have thought of plus maybe it will keep my mind occupied a bit


---

### 2138. msg_7466

**You** - 2025-05-03T18:54:26

Also mer… it was literally the lowest dose I could be on\.  I know someone who is 10x my dose


---

### 2139. msg_7467

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:55:10

k just don’t like to see you struggling either


---

### 2140. msg_7468

**You** - 2025-05-03T18:55:36

I don’t want you to see me struggling\. This trying to find other solutions\.


---

### 2141. msg_7469

**You** - 2025-05-03T18:56:16

I want to have somewhere else to drop off my feelings and push the rest down into a box


---

### 2142. msg_7470

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:57:13

I don’t think you have to do that\. Doesn’t seem healthy for you


---

### 2143. msg_7471

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:57:23

More my thing


---

### 2144. msg_7472

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:57:25

lol


---

### 2145. msg_7473

**You** - 2025-05-03T18:57:25

Not healthy for us if I do t


---

### 2146. msg_7474

**You** - 2025-05-03T18:57:27

Don’t


---

### 2147. msg_7475

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:57:35

Not true


---

### 2148. msg_7476

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T18:57:39

Wdym


---

### 2149. msg_7477

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:00:01

This is what I did when I stayed home and didn’t work\. Lol

*1 attachment(s)*


---

### 2150. msg_7478

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:00:36

I would design them on paper first lol

*1 attachment(s)*


---

### 2151. msg_7479

**You** - 2025-05-03T19:01:05

Mer I don’t have a life\.\. honestly this family has been broken a long time maddie is relatively self sufficient Gracie is a mess but we cannot connect\.\. j is well whatever\.\. my life has been my job and trying to make people happy here\. I have had nothing for myself\.  You come along and the analogy of the drowning man and the lifeguard comes
To mind\.  I don’t want to weigh you down or pull you under\.  Having these feelings now I want to have them as much as I can, and looking forward to weeks and weeks of can’t\.\. it really crushes on me\.\. and I cannot let that touch you or you will eventually resent me\. So I need to find an alternative outlet and I need to build a life for myself\.


---

### 2152. msg_7480

**You** - 2025-05-03T19:01:53

>
Again I don’t care what you think about it I think it and you are amazing\.  The more I learn the more you prove it to be true\.


---

### 2153. msg_7481

**You** - 2025-05-03T19:03:20

So I am just trying to find ways to avoid you eventually seeing me as weak and needy and broken and overly dependent on you because that isn’t or wasn’t me\.


---

### 2154. msg_7482

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:05:38

>
You have a life but not one you are happy with…\. And you are changing that\. Same\. Listen, you will not nor are you dragging me down\. I could say the same\. Our lives/situations/whatever is part of our story and connection\. You don’t need to hide any part of you from me\. Quite frankly, that would suck……


---

### 2155. msg_7483

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:05:46

K I’m allowed to drive home now omg


---

### 2156. msg_7484

**You** - 2025-05-03T19:08:00

Safe drive\.\. but honestly mer I share a lot but remember how you talked about our levels of intensity being different\.\. I don’t think you quite get the difference\.\.  and I don’t understand it so I am trying to wrap my head around it daily\.  And I cannot open up that much because it is just too much to put on anyone\.  Again someday I hope this will all go away when situations change\.  I suspect it will\.


---

### 2157. msg_7485

**You** - 2025-05-03T19:08:48

For now I will carry it myself and try to figure out how to manage it\.


---

### 2158. msg_7486

**You** - 2025-05-03T19:13:51

I can very much empathize with cold as a stone\.\. I wish was too\.


---

### 2159. msg_7487

**You** - 2025-05-03T19:14:15

That or Tinman


---

### 2160. msg_7488

**You** - 2025-05-03T19:27:54

Jesus some dark fucking sad songs out there\.\.


---

### 2161. msg_7489

**You** - 2025-05-03T19:28:12

Was trying to find something to reflect I\. And I am finding super depressing shit


---

### 2162. msg_7490

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:30:06

https://open\.spotify\.com/track/0GVuLQtPXFaL18ijEOqoAa?si=PgrY1vN\-SQuZQPAUpQ7WfQ
Not sad


---

### 2163. msg_7491

**You** - 2025-05-03T19:31:05

Treasure trove of songs\. Aren’t you\.


---

### 2164. msg_7492

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:31:40

Playing my liked playlist on shuffle lol


---

### 2165. msg_7493

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:31:55

>
It is not too much\.


---

### 2166. msg_7494

**You** - 2025-05-03T19:33:27

Mer sorry but it is\.


---

### 2167. msg_7495

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:34:14

https://open\.spotify\.com/track/44IeABaLLsnFVb7rjzNTzS?si=gignjju4T2CLW9vdDI\_3vw


---

### 2168. msg_7496

**You** - 2025-05-03T19:34:27

Here this is for you\.


---

### 2169. msg_7497

**You** - 2025-05-03T19:34:32

Reaction: ❤️ from Meredith Lamb
https://open\.spotify\.com/track/2qLMf6TuEC3ruGJg4SMMN6?si=iozhHjmJRUmGHqarJR5WXw&context=spotify%3Aartist%3A6aZyMrc4doVtZyKNilOmwu


---

### 2170. msg_7498

**You** - 2025-05-03T19:36:28

You have a lot of really strong feeling songs\.


---

### 2171. msg_7499

**You** - 2025-05-03T19:36:37

What drove this


---

### 2172. msg_7500

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:37:23

>
Never heard this song


---

### 2173. msg_7501

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:37:38

>
Just the music I prefer


---

### 2174. msg_7502

**You** - 2025-05-03T19:38:17

That lucky song was on glee


---

### 2175. msg_7503

**You** - 2025-05-03T19:38:26

But I have always liked it


---

### 2176. msg_7504

**You** - 2025-05-03T19:38:38

Going back to your greatest showman


---

### 2177. msg_7505

**You** - 2025-05-03T19:38:57

https://open\.spotify\.com/track/65fpYBrI8o2cfrwf2US4gq?si=TqK57ISWQraRlRnZAEeZvg&context=spotify%3Atrack%3A65fpYBrI8o2cfrwf2US4gq


---

### 2178. msg_7506

**You** - 2025-05-03T19:39:10

>
It is pretty longing and powerful


---

### 2179. msg_7507

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:41:50

I have the whole greatest showman soundtrack in my liked songs lol


---

### 2180. msg_7508

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:42:00

Did you watch the Movie


---

### 2181. msg_7509

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:43:12

https://open\.spotify\.com/track/28cnXtME493VX9NOw9cIUh?si=Gb7\_op6zQgS24L8s67HqiQ
I like sad songs


---

### 2182. msg_7510

**You** - 2025-05-03T19:44:15

>
I was saving it\.


---

### 2183. msg_7511

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:46:37

I’m not sure if we watch movies together well


---

### 2184. msg_7512

**You** - 2025-05-03T19:47:15

Not yet but we will need to take a break sometime


---

### 2185. msg_7513

**You** - 2025-05-03T19:47:29

Super cheesy incoming but I read the lyrics\.\.


---

### 2186. msg_7514

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:47:57

Lyrics of?


---

### 2187. msg_7515

**You** - 2025-05-03T19:47:58

Reaction: 😂 from Meredith Lamb
The non commitment commitment?


---

### 2188. msg_7516

**You** - 2025-05-03T19:48:01

https://open\.spotify\.com/track/0Q7Jp3aCwfYnSnbMDoXWyR?si=IpHM5l6zTiC3pYVQMn1OdQ&context=spotify%3Atrack%3A0Q7Jp3aCwfYnSnbMDoXWyR


---

### 2189. msg_7517

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:49:08

Shania wow bringing it back


---

### 2190. msg_7518

**You** - 2025-05-03T19:49:16

If the shoe fits\.


---

### 2191. msg_7519

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:49:50

Grade 13\. We were all obsessed with her haha


---

### 2192. msg_7520

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:50:11

It’s kind of a wedding song you know


---

### 2193. msg_7521

**You** - 2025-05-03T19:51:04

Non commitment commitment song you mean


---

### 2194. msg_7522

**You** - 2025-05-03T19:51:23

I would never suggest a wedding song I know better


---

### 2195. msg_7523

**You** - 2025-05-03T19:51:51

Shania had a shit ton of great songs\.\. still the one is pretty heavy too\.


---

### 2196. msg_7524

**You** - 2025-05-03T19:52:18

But we would need to be together for a while for that to work


---

### 2197. msg_7525

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:52:36

For what to work?


---

### 2198. msg_7526

**You** - 2025-05-03T19:52:46

And yes I used an absolute I am sry lol


---

### 2199. msg_7527

**You** - 2025-05-03T19:53:02

The song is a reference to a long term relationship


---

### 2200. msg_7528

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:53:16

It is a reference to a marriage


---

### 2201. msg_7529

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:53:21

But whatever lol


---

### 2202. msg_7530

**You** - 2025-05-03T19:53:32

I feel like it is open to interpretation


---

### 2203. msg_7531

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:53:39

lol


---

### 2204. msg_7532

**You** - 2025-05-03T19:53:45

In this case non commitment commitment


---

### 2205. msg_7533

**You** - 2025-05-03T19:54:30

You know your reaction the other\. Ight when I talked about our song and you went to the paramour one\.\. I could live with that too it is completely true\.


---

### 2206. msg_7534

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:54:55

It reminds me you bc I had never heard it before…


---

### 2207. msg_7535

**You** - 2025-05-03T19:55:07

Well we
Can use that one then


---

### 2208. msg_7536

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:55:08

I connect it to you


---

### 2209. msg_7537

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:55:15

I like Morgan too :\)


---

### 2210. msg_7538

**You** - 2025-05-03T19:55:26

I mean they both work for me\.


---

### 2211. msg_7539

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:55:38

More than one song is ok


---

### 2212. msg_7540

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:55:41

lol


---

### 2213. msg_7541

**You** - 2025-05-03T19:55:45

Yep


---

### 2214. msg_7542

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:56:43

https://open\.spotify\.com/track/1XbC2PUR09MlgmpVbLgF4L?si=Xhatz6z2Q4CvaJaBVoipLQ
Listening to this now…


---

### 2215. msg_7543

**You** - 2025-05-03T19:57:09

Ahh divergent


---

### 2216. msg_7544

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:57:27

Such a good movie


---

### 2217. msg_7545

**You** - 2025-05-03T19:57:34

You had mentioned it before


---

### 2218. msg_7546

**You** - 2025-05-03T19:57:45

The boy is pretty cute I think I recall


---

### 2219. msg_7547

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:58:05


*1 attachment(s)*


---

### 2220. msg_7548

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:59:17

>
His name is Four\. And yes\.


---

### 2221. msg_7549

**You** - 2025-05-03T19:59:36

Jim is a bad man


---

### 2222. msg_7550

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T19:59:44

lol


---

### 2223. msg_7551

**You** - 2025-05-03T20:01:27

Are you doing that again tonight lol


---

### 2224. msg_7552

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:01:51

I can’t\. I have to drive from 10\.30\-11\.30pm\. :p


---

### 2225. msg_7553

**You** - 2025-05-03T20:02:07

Wow that sucks\.


---

### 2226. msg_7554

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:02:32

Yeah…


---

### 2227. msg_7555

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:02:38

After 11\.30 all bets are off


---

### 2228. msg_7556

**You** - 2025-05-03T20:02:57

Well
You can do whatever you want then I will be going to bed


---

### 2229. msg_7557

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:03:08

Mac’s friends are coming over again apparently


---

### 2230. msg_7558

**You** - 2025-05-03T20:03:24

Well then you will be entertained


---

### 2231. msg_7559

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:03:36

Maybe\. We will see


---

### 2232. msg_7560

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:05:17

So how is your one note going


---

### 2233. msg_7561

**You** - 2025-05-03T20:06:48

It isn’t I was talking to you and listening to music


---

### 2234. msg_7562

**You** - 2025-05-03T20:06:58

I will have nothing to do later I will do it then


---

### 2235. msg_7563

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:07:00

Much more fun


---

### 2236. msg_7564

**You** - 2025-05-03T20:07:21

Yep true


---

### 2237. msg_7565

**You** - 2025-05-03T20:08:29

Plus there is going to be an absolute shit ton for me to download\.\. will take a while


---

### 2238. msg_7566

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:08:48

Download?


---

### 2239. msg_7567

**You** - 2025-05-03T20:08:56

From myself


---

### 2240. msg_7568

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:09:03

Ohhhh


---

### 2241. msg_7569

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:09:39

Maybe you just need to take a couple edibles and relax


---

### 2242. msg_7570

**You** - 2025-05-03T20:11:00

No


---

### 2243. msg_7571

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:11:12

https://open\.spotify\.com/track/5b9Iolaee6xTaMWb8c5rLB?si=NPpxJV1PQF29b\-EdBpqTVw
Have you ever heard this song?


---

### 2244. msg_7572

**You** - 2025-05-03T20:11:14

Remeber they take me to the bad place


---

### 2245. msg_7573

**You** - 2025-05-03T20:11:29

Will listen in a sec getting stuff to get in car


---

### 2246. msg_7574

**You** - 2025-05-03T20:11:57

I cannot do what you do mer very jealous


---

### 2247. msg_7575

**You** - 2025-05-03T20:12:06

And our situations are different so there is that


---

### 2248. msg_7576

**You** - 2025-05-03T20:12:15

Just drugs are not my friends atm


---

### 2249. msg_7577

**You** - 2025-05-03T20:13:23

And this isn’t who I am outside of work\.\. unlike work I am typically more up beat optimistic fun goofy guy\.


---

### 2250. msg_7578

**You** - 2025-05-03T20:13:36

But yeah\.\. not quite atm lol


---

### 2251. msg_7579

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:15:28

Same atm


---

### 2252. msg_7580

**You** - 2025-05-03T20:17:41

Anyhow as I said I am not dumping this on you anymore\.\. so no more sooo……\.\. and mmmm hmmmmm and stuff like that to draw it out\.


---

### 2253. msg_7581

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:18:19

lol you are not dumping stuff on me so stop


---

### 2254. msg_7582

**You** - 2025-05-03T20:19:53

I am and I know I am\.  And everything I have read ever before and in the last two days tell me if I do this you will leave\.  So I don’t want that\. Even if you say you won’t I don’t want to risk it\.


---

### 2255. msg_7583

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:20:45

What have you read? Curious minds…\.


---

### 2256. msg_7584

**You** - 2025-05-03T20:20:57

Always curious


---

### 2257. msg_7585

**You** - 2025-05-03T20:21:21

Read online forums gpt Gemini psychological journals etc
Etc


---

### 2258. msg_7586

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:21:21

😇


---

### 2259. msg_7587

**You** - 2025-05-03T20:21:26

You know me I research


---

### 2260. msg_7588

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:21:36

And what was your “topic”


---

### 2261. msg_7589

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:22:26

What are you researching, what is one of your current issues?


---

### 2262. msg_7590

**You** - 2025-05-03T20:22:41

That isn’t what I researched nice try though


---

### 2263. msg_7591

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:22:58

I was ASKING what you researched


---

### 2264. msg_7592

**You** - 2025-05-03T20:23:11

No you wanted to know about my issues


---

### 2265. msg_7593

**You** - 2025-05-03T20:23:12

lol


---

### 2266. msg_7594

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:23:22

Well I’m assuming they are linked


---

### 2267. msg_7595

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:23:36

Research topic = issue


---

### 2268. msg_7596

**You** - 2025-05-03T20:23:36

Sure but I am not talking isssue


---

### 2269. msg_7597

**You** - 2025-05-03T20:23:58

Research topic was what happens when you feel too much and open up too often


---

### 2270. msg_7598

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:24:10

Sigh\.\.


---

### 2271. msg_7599

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:24:25

You are feeling too much?


---

### 2272. msg_7600

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:24:30

Or just enough


---

### 2273. msg_7601

**You** - 2025-05-03T20:24:44

See you are signing


---

### 2274. msg_7602

**You** - 2025-05-03T20:24:50

That is a clear sign


---

### 2275. msg_7603

**You** - 2025-05-03T20:24:53

They said so


---

### 2276. msg_7604

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:24:55

Huh?


---

### 2277. msg_7605

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:25:01

Who is they


---

### 2278. msg_7606

**You** - 2025-05-03T20:25:11

The research


---

### 2279. msg_7607

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:25:15

Omg


---

### 2280. msg_7608

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:25:19

I’m signing


---

### 2281. msg_7609

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:25:24

Going to research that now


---

### 2282. msg_7610

**You** - 2025-05-03T20:25:59

This is not the right\-now kind of love\. This is the build\-it\-slow\-and\-sacred kind\. And that means the ache is part of it, not a detour from it\.


---

### 2283. msg_7611

**You** - 2025-05-03T20:26:20

Don’t treat the ache as failure\. Treat it as evidence\. You love her\. Now, build the stamina to hold that love with reverence until the world can catch up\.


---

### 2284. msg_7612

**You** - 2025-05-03T20:26:28

Impossible I don’t know how to do this


---

### 2285. msg_7613

**You** - 2025-05-03T20:26:44

Boundaries: Don’t seek constant reassurance from her—it will backfire\. Set mutually agreed check\-ins that give both of you stability\.


---

### 2286. msg_7614

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:26:53

>
Same\.


---

### 2287. msg_7615

**You** - 2025-05-03T20:27:15

You need one person—a therapist, coach, or deeply trusted friend—who:
•	Is not your ex\.
•	Is not your lover\.
•	Doesn’t work for you\.
•	Can hold your sadness without fixing it\.
Keeping this inside will rot you from the core\. You don’t have to carry it alone\.


---

### 2288. msg_7616

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:27:23

I can’t find anything on “signing”\. What did you mean


---

### 2289. msg_7617

**You** - 2025-05-03T20:27:31

Sighing


---

### 2290. msg_7618

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:27:40

Oh


---

### 2291. msg_7619

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:27:43

lol


---

### 2292. msg_7620

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:28:30

I just think you are opening up too often


---

### 2293. msg_7621

**You** - 2025-05-03T20:28:49

See


---

### 2294. msg_7622

**You** - 2025-05-03T20:28:51

lol


---

### 2295. msg_7623

**You** - 2025-05-03T20:28:57

It was right\!\!\!


---

### 2296. msg_7624

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:29:05

I’m not sure why you are feeling that way other than you are feeling unreciprocated but I just don’t express myself like you\. Doesn’t mean I’m not feeling it


---

### 2297. msg_7625

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:29:22

>
Sorry I meant “I just don’t think you are…”


---

### 2298. msg_7626

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:29:34

Typo


---

### 2299. msg_7627

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:29:36

Sorry


---

### 2300. msg_7628

**You** - 2025-05-03T20:29:59

Hmmmmmmmmmm I dunno


---

### 2301. msg_7629

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:30:03

I prefer when you open up


---

### 2302. msg_7630

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:30:10

Why do you think I don’t?


---

### 2303. msg_7631

**You** - 2025-05-03T20:31:09

Because you are carrying enough and who wants someone weak\. It’s not even that it is what i said earlier I am completely isolated and alone\. I am a loner but not like this


---

### 2304. msg_7632

**You** - 2025-05-03T20:31:36

And


---

### 2305. msg_7633

**You** - 2025-05-03T20:31:46

I was more fine with it when I felt nothing


---

### 2306. msg_7634

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:31:53

Listen, I know you are not weak


---

### 2307. msg_7635

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:32:01

Like honestly


---

### 2308. msg_7636

**You** - 2025-05-03T20:32:06

If you do t know what you are missing you cannot miss it right


---

### 2309. msg_7637

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:32:28

Virgo perfectionism to a fault


---

### 2310. msg_7638

**You** - 2025-05-03T20:32:39

Just logic


---

### 2311. msg_7639

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:32:45

You are your own worst enemy


---

### 2312. msg_7640

**You** - 2025-05-03T20:32:49

I know


---

### 2313. msg_7641

**You** - 2025-05-03T20:33:02

I have been here before


---

### 2314. msg_7642

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:33:03

If you could see yourself through my eyes you would feel better I think


---

### 2315. msg_7643

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:33:37

If we met in a different time I would have dated you for sure\.


---

### 2316. msg_7644

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:33:55

I mean I remember liking you as a person in Florida that time


---

### 2317. msg_7645

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:34:11

Felt a little jealous of your happy little cutesie family


---

### 2318. msg_7646

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:34:21

Mine was not happy at that time


---

### 2319. msg_7647

**You** - 2025-05-03T20:34:37

Mer tbh I actually believe you like me and love me for who I am it isn’t\. Lack of confidence


---

### 2320. msg_7648

**You** - 2025-05-03T20:34:59

It is simple


---

### 2321. msg_7649

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:35:03

Then what is it


---

### 2322. msg_7650

**You** - 2025-05-03T20:35:11

What I just said


---

### 2323. msg_7651

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:35:26

You have been here before?


---

### 2324. msg_7652

**You** - 2025-05-03T20:35:37

Well that is true but not what I meant


---

### 2325. msg_7653

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:35:53

You feel like a burden?


---

### 2326. msg_7654

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:36:00

I’m guessing here


---

### 2327. msg_7655

**You** - 2025-05-03T20:36:04

I have blown up relationships all on my own by myself


---

### 2328. msg_7656

**You** - 2025-05-03T20:36:17

But no


---

### 2329. msg_7657

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:36:19

Ah k


---

### 2330. msg_7658

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:36:22

I get it


---

### 2331. msg_7659

**You** - 2025-05-03T20:36:29

This is just about being sad and lonely\.


---

### 2332. msg_7660

**You** - 2025-05-03T20:36:33

And weak


---

### 2333. msg_7661

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:36:40

I am too obsessed with you, you will not blow this up


---

### 2334. msg_7662

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:37:00

I mean unless you and Jaime rekindle


---

### 2335. msg_7663

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:37:01

lol


---

### 2336. msg_7664

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:37:04

Then maybe


---

### 2337. msg_7665

**You** - 2025-05-03T20:37:21

Sad lonely and weak and no interest whatsoever in looking backwards


---

### 2338. msg_7666

**You** - 2025-05-03T20:37:29

Zero


---

### 2339. msg_7667

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:37:39

You are not sad, lonely nor weak\.


---

### 2340. msg_7668

**You** - 2025-05-03T20:37:48

I feel that way


---

### 2341. msg_7669

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:38:26

I mean you are transitioning from one life to the next\. There will be moments in that transition but it doesn’t mean that is who you are


---

### 2342. msg_7670

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:38:31

It shouldn’t define you


---

### 2343. msg_7671

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:38:36

You just get thru it


---

### 2344. msg_7672

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:38:42

By whatever means…


---

### 2345. msg_7673

**You** - 2025-05-03T20:39:01

Sure sure lol


---

### 2346. msg_7674

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:39:13

For me, it is getting wasted\.


---

### 2347. msg_7675

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:39:20

For you, it is going to the gym\.


---

### 2348. msg_7676

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:39:22

lol


---

### 2349. msg_7677

**You** - 2025-05-03T20:39:30

It does t do it


---

### 2350. msg_7678

**You** - 2025-05-03T20:39:42

I still come home to the house and the basement


---

### 2351. msg_7679

**You** - 2025-05-03T20:39:46

And my brain


---

### 2352. msg_7680

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:39:55

But it isn’t forever


---

### 2353. msg_7681

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:40:05

It’s just probably too long


---

### 2354. msg_7682

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:40:08

But not forever


---

### 2355. msg_7683

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:40:25

Just consider yourself at war right now


---

### 2356. msg_7684

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:40:28

Haha


---

### 2357. msg_7685

**You** - 2025-05-03T20:40:35

I don’t see the end… not in sight…  trying
Trying


---

### 2358. msg_7686

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:40:46

Really?


---

### 2359. msg_7687

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:40:51

I do


---

### 2360. msg_7688

**You** - 2025-05-03T20:41:05

That’s the drugs talking


---

### 2361. msg_7689

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:41:10

It is a tad too far for my liking but I see it


---

### 2362. msg_7690

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:41:18

I have no drugs in me


---

### 2363. msg_7691

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:41:22

lol right


---

### 2364. msg_7692

**You** - 2025-05-03T20:41:28

From last night stilll


---

### 2365. msg_7693

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:41:34

I know lol


---

### 2366. msg_7694

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:42:02

I can kind of see the end but I see the midpoint more


---

### 2367. msg_7695

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:42:14

I have my own place and am out of here


---

### 2368. msg_7696

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:42:18

That’s my mid point


---

### 2369. msg_7697

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:42:25

Next couple of months


---

### 2370. msg_7698

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:43:38

https://open\.spotify\.com/track/0QEmGCfiMQjyDRnRogtMnM?si=oAeO5UbhTzaHbotGSScNFw


---

### 2371. msg_7699

**You** - 2025-05-03T20:44:07

Mid point is a couple of months?


---

### 2372. msg_7700

**You** - 2025-05-03T20:44:23

Rofl\!\!\!\!’n


---

### 2373. msg_7701

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:44:25

Hopefully have my own place July 1


---

### 2374. msg_7702

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:44:31

That is my midpoint


---

### 2375. msg_7703

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:44:40

Short term is literally surviving next week


---

### 2376. msg_7704

**You** - 2025-05-03T20:45:31

I got agreement from j I can take a vacation do whatever I want like her trip to Aruba cruise whatever\.\. fyi\.


---

### 2377. msg_7705

**You** - 2025-05-03T20:45:48

I am going to have a very difficult time I didn’t think I would\. But I will\.


---

### 2378. msg_7706

**You** - 2025-05-03T20:46:11

Btw if your shadow isn’t around we can talk instead of text I am going for a walk on a treadmill


---

### 2379. msg_7707

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:46:20

>
Does this mean we are going on a trip? Lol


---

### 2380. msg_7708

**You** - 2025-05-03T20:46:55

I was seeing what you wanted it really is your schedule that will dictate


---

### 2381. msg_7709

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:47:27

>
My shadow is at a bat mitzvah


---

### 2382. msg_7710

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:47:49

>
Difficult time with what?


---

### 2383. msg_7711

**You** - 2025-05-03T20:47:53

Kk well up to you walk starting


---

### 2384. msg_7712

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:48:13

Well you can call if you want


---

### 2385. msg_7713

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T20:48:41

Unless you are out of breathe lol


---

### 2386. msg_7714

**You** - 2025-05-03T21:03:36

I am really sad\.\. getting separated \.\. living in my basement\.\. my wife hates me kids not as bad\.  I am in love with someone else so hard, like nothing ever like it ever ever ever I cannot emphasize that enough\.  And she loves me too but we cannot find time and she has a busy life with her kids\.\. oh did I mention she works for me also and we have to keep it a secret\. Wtf do I do to deal with the sadness and absence\.\. we will be together eventually but this is physical pain


---

### 2387. msg_7715

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T21:26:26

I’m really struggling right now\. I’m separated and living in my basement\. Things with my wife are broken—she’s angry and distant—and while my kids are more forgiving, it’s still incredibly hard\.
The complicated part is… I’m in love\. Truly, deeply in love, in a way I’ve never experienced before\. It’s with someone extraordinary\. She sees me\. She knows me\. She brings out parts of me I thought were lost\. She loves me too—but life is complicated\.
She has a full life of her own—she’s a mother, with three kids, navigating her own separation\. She works for me, which adds even more layers to everything\. We have to be careful, and it’s so hard to keep something this real hidden\. We hardly get time together, and when we do, it’s amazing—but when we don’t, I feel this aching absence\.
I know in my bones that we’ll be together someday, and that helps me hold on\. But in the meantime, the sadness, the longing, the waiting—it hurts\. Physically, emotionally\.
How do I live with this in\-between? How do I \.\.\. \[truncated\]


---

### 2388. msg_7716

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T21:29:14

Scott, your pain is valid\. You’re navigating a profound emotional storm—letting go of one life while desperately wanting another that still feels out of reach\. It makes complete sense that you’re feeling this level of sadness and longing\. Separation alone is emotionally brutal\. Add in a love that has to remain hidden, limited time with someone who brings you joy, and the emotional fallout with your family—of course it feels overwhelming\.
What you’re experiencing isn’t just sadness\. It’s grief\. Grief for a relationship that’s ending, for the time you wish you had, for the version of your life you can’t fully live yet\. And when love feels this strong but can’t be fully expressed, it creates a kind of emotional limbo that’s incredibly painful\.
Here’s what I’d gently offer:
•	Don’t carry this alone\. This is too much for one person to process in isolation\. Talking to a therapist or counselor can help you move through this in a healthier way\.
•	Focus on anchoring yourself\. It’s easy to get p\.\.\. \[truncated\]


---

### 2389. msg_7717

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T21:49:13

I get concerned when you say you have to hide stuff from me because you think I can’t handle it or whatever\. I honestly think we might be soulmates and if that is the case, it means I uniquely understand you and hopefully even complete you\. I can’t do that if you hide stuff…… or hide who you are or what you’re going through\. You realize that?


---

### 2390. msg_7718

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T22:28:13

https://open\.spotify\.com/track/11EX5yhxr9Ihl3IN1asrfK?si=u3wOxo4bSL6bBVCfschn4g


---

### 2391. msg_7719

**You** - 2025-05-03T22:28:45

I listened to that earlier


---

### 2392. msg_7720

**You** - 2025-05-03T22:28:51

When you sent me the other one


---

### 2393. msg_7721

**You** - 2025-05-03T22:36:04

I will call you in a min brushing
Y teeth\.


---

### 2394. msg_7722

**You** - 2025-05-03T22:44:00

>
And I don’t think we are I am sure we are\.\. we just need the time and opportunity\.


---

### 2395. msg_7723

**You** - 2025-05-03T23:03:18

Love you xoxoxoxo ❤️❤️❤️❤️this better be the kind of thing where we come through stronger because of it\.


---

### 2396. msg_7724

**You** - 2025-05-03T23:09:19

>
And mer I think I have been quite a bit more open, but I am pretty patient\. Just saying you can open up too\.


---

### 2397. msg_7725

**You** - 2025-05-03T23:12:40

If you get bored before bed why don’t you leave one of your own open up notes like I leave you\.\. would love to read it and learn more about you\.


---

### 2398. msg_7726

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T23:33:15

I came home to a party 🙄


---

### 2399. msg_7727

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T23:33:41

>
Am I not opening up enough?


---

### 2400. msg_7728

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T23:37:00

It’s possible that his perception is based on how you open up\. You often take time to process and tend to share in ways that are thoughtful, measured, or analytical\. He, on the other hand, may express himself more spontaneously or directly—so to him, that might feel like he’s opening up more, even if you’re actually being just as emotionally present, but in a different style


---

### 2401. msg_7729

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T23:41:07

Marlowe won a Morgan Wallen t shirt at the bat mitzvah

*1 attachment(s)*


---

### 2402. msg_7730

**Meredith Lamb \(\+14169386001\)** - 2025-05-03T23:42:39

She’s going to sleep over at her friend’s 🎉🎉🎉


---

### 2403. msg_13852

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:15:51

Huh? Sorry, just sitting here\. I miss you\.


---

### 2404. msg_13853

**You** - 2025-05-01T22:16:12

You ok??


---

### 2405. msg_13854

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:16:23

Yah


---

### 2406. msg_13855

**You** - 2025-05-01T22:16:32

Miss you always could give you a great big hug right now


---

### 2407. msg_13856

**You** - 2025-05-01T22:16:59

Sucks being apart\.\. any chance
You have to go out in your own this weekend anywhere during the day\.


---

### 2408. msg_13857

**You** - 2025-05-01T22:17:24

I could meet you just to say hey give you that big hug and chat for a few mins only


---

### 2409. msg_13858

**You** - 2025-05-01T22:17:32

I am ok if not


---

### 2410. msg_13859

**You** - 2025-05-01T22:17:35

Just thinking


---

### 2411. msg_13860

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:18:15

Yeah not 100%\. I have to buy Maelle bday gifts\.


---

### 2412. msg_13861

**You** - 2025-05-01T22:18:27

I know you got shopping tommorrow night and prep for bday I am sure over the weekend


---

### 2413. msg_13862

**You** - 2025-05-01T22:18:46

Just thought there might be an hour no worries mer just trying to lighten your load lol not make it worse


---

### 2414. msg_13863

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:18:48

I also have to get Maelle to a bat mitzvah for 6\.30pm on Sat night and Marlowe to a bat mitzvah for 7pm on Sat night\. 😵‍💫


---

### 2415. msg_13864

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:18:53

Somehow


---

### 2416. msg_13865

**You** - 2025-05-01T22:18:55

Sok


---

### 2417. msg_13866

**You** - 2025-05-01T22:18:58

Dun worry


---

### 2418. msg_13867

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:19:03

I might see if Marlowe can carpool


---

### 2419. msg_13868

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:19:26

I have some planning to do


---

### 2420. msg_13869

**You** - 2025-05-01T22:20:13

Yep take care of your stuff all
Good


---

### 2421. msg_13870

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:20:38

Are you worried we are going to drift if we don’t get to see each other?


---

### 2422. msg_13871

**Meredith Lamb \(\+14169386001\)** - 2025-05-01T22:20:49

Is that what your head was thinking last night


---

### 2423. msg_13872

**You** - 2025-05-01T22:20:58

Nope


---

### 2424. msg_13873

**You** - 2025-05-01T22:21:10

I was worried you would think it not worth the trouble eventually


---

### 2425. msg_13874

**You** - 2025-05-01T22:21:30

Or maybe you might drift sure


---

### 2426. msg_13875

**You** - 2025-05-01T22:21:33

Possibly


---

