# Week 11: Conversation Messages

**Date Range:** 2025-06-22 to 2025-06-27  
**Total Messages:** 1465  
**Generated:** 2025-07-18 21:27:07

---

## 📊 Week Summary

- **Week Number:** 11
- **Messages:** 1465
- **Participants:** 2
- **Message Types:** incoming, outgoing, call-history

## 💬 Conversation Messages

### 1. msg_25795

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T00:51:12

Talking to my mom\. I think she thinks we are “very compatible and communicate well together”
And I was like wtf?\!?\!


---

### 2. msg_25796

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T00:51:23

My mom never says shit like that


---

### 3. msg_25797

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T00:51:27

She’s 80


---

### 4. msg_25798

**You** - 2025-06-22T00:53:31

Don’t look for reasons to doubt


---

### 5. msg_25799

**You** - 2025-06-22T00:59:09

That seems good


---

### 6. msg_25800

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:03:09

Edited: 2 versions
| Version: 2
| Sent: Sun, 22 Jun 2025 01:03:17 \-0400
|
| Still talking to her but want to go to bed omg
|
| Version: 1
| Sent: Sun, 22 Jun 2025 01:03:09 \-0400
|
| Still talking to her but want to go to bed omf


---

### 7. msg_25801

**You** - 2025-06-22T01:03:57

lol well I love you and this was a good day\.\. one I will Remeber for a while\.  Drink lots of water lol\.


---

### 8. msg_25802

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:11:51

lol


---

### 9. msg_25803

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:11:55

Water


---

### 10. msg_25804

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:12:15

I just collapsed in my nephews bed


---

### 11. msg_25805

**You** - 2025-06-22T01:12:24

ROFL


---

### 12. msg_25806

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:12:24

It is sooo comfortable


---

### 13. msg_25807

**You** - 2025-06-22T01:12:38

Yeah you will pass out momentarily


---

### 14. msg_25808

**You** - 2025-06-22T01:12:48

Felt like you had fun tonight I hope


---

### 15. msg_25809

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:12:50

lol


---

### 16. msg_25810

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:13:06

My mom just went “Meredith \- do you want your water?”


---

### 17. msg_25811

**You** - 2025-06-22T01:13:07

I enjoyed talking to your dad too\.


---

### 18. msg_25812

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:13:09

lol


---

### 19. msg_25813

**You** - 2025-06-22T01:13:12

Hehe


---

### 20. msg_25814

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:14:01

>
It was good but honestly I was hoping for my mom to feel more awkward lol


---

### 21. msg_25815

**You** - 2025-06-22T01:14:06

Why


---

### 22. msg_25816

**You** - 2025-06-22T01:14:11

I was glad it went well


---

### 23. msg_25817

**You** - 2025-06-22T01:14:15

That was the point


---

### 24. msg_25818

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:14:26

lol I dunno I like to see her in pain


---

### 25. msg_25819

**You** - 2025-06-22T01:14:40

I like to be the boyfriend she likes


---

### 26. msg_25820

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:14:57

Meh


---

### 27. msg_25821

**You** - 2025-06-22T01:15:14

Matters to me even if not to you\.\. lol


---

### 28. msg_25822

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:15:36

She is so critical of me I like to see her suffer a bit sometimes\. Lol


---

### 29. msg_25823

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:16:05

It went a little TOO easy 🤪


---

### 30. msg_25824

**You** - 2025-06-22T01:16:23

Reaction: 😂 from Meredith Lamb
Well next time I will try to be less something lol


---

### 31. msg_25825

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:16:53

She said something about how she can tell you work out


---

### 32. msg_25826

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:17:04

\(Mom = vain\)


---

### 33. msg_25827

**You** - 2025-06-22T01:18:36

Whatever


---

### 34. msg_25828

**You** - 2025-06-22T01:18:49

It’s like you wanted it to go bad LOL


---

### 35. msg_25829

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:19:15

Nooooo


---

### 36. msg_25830

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:19:18

lol


---

### 37. msg_25831

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:22:27

Reaction: ❤️ from Scott Hicks
Before I pass out I will say, because I didn’t get a chance before you left, that you were amazing today and I had the best time even if only a few hours\.  It’s different because it just IS… you feel so home to me, so good to me, the feeling is like nothing I’ve ever experienced…\.
Dinner was fine 🙂


---

### 38. msg_25832

**You** - 2025-06-22T01:23:26

lol dinner was fine


---

### 39. msg_25833

**You** - 2025-06-22T01:24:29

Today was perfect for me\.\. I wanted it to be for you too\.\. you deserve it\.


---

### 40. msg_25834

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T01:25:26

I mean I know my parents liked you a lot but not sure if it is bc they are in their 80/s\. Lol doesn’t matter\. My mom talked about all her “problems with andrew” lol and then I think I started yawning\. Heard it all before\. They very much liked you though so I feel good going to sleep\. :\)


---

### 41. msg_25835

**You** - 2025-06-22T01:30:53

Kk go to sleep love you thanks for making me happy again\.


---

### 42. msg_25836

**You** - 2025-06-22T01:32:04

>
>
>
You are home to me as well I have never been this open or comfortable with anyone in my life\.\. just being patient until this can become a more natural and regular thing


---

### 43. msg_25837

**You** - 2025-06-22T01:35:06

>
And btw everything about you is amazing to me\.\. we could have done nothing but lied there and talked and watched movies nd I would have been a happy and lucky man\.  Ok I am going to bed love you night❤️


---

### 44. msg_25838

**You** - 2025-06-22T09:18:20

Morning\.\. bet you are hungover lol\.\. ❤️\.  Hope you had a half decent sleep at least\.\. I really liked the dynamic between you and your parents, especially you and your dad\.\. he was really funny last night\.\. 😇\.\. soo many stories he could tell me rofl\.


---

### 45. msg_25839

**You** - 2025-06-22T09:29:35

Reaction: 😂 from Meredith Lamb
And btw told you I was going to hug your mom\.\. 🙂


---

### 46. msg_25840

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T09:46:52

>
lol yes so hungover but yeah slept well Jacob’s bed is the bomb\. :\)


---

### 47. msg_25841

**You** - 2025-06-22T09:47:35

ROFL glad
You slept well\.\.


---

### 48. msg_25842

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T09:48:58

I need a tylonol tho and they are all the way upstairs so I’ve just been suffering to stay in bed\. Head ache


---

### 49. msg_25843

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T09:49:02

lol


---

### 50. msg_25844

**You** - 2025-06-22T09:49:56

Yeah that sucks\.\. hehe you need to get some food into you as well


---

### 51. msg_25845

**You** - 2025-06-22T10:54:14

You know I have realized the more I am with you, the more time I spend with you, the more I think about you, the more I want to be with you\. 🙂\.  Thought I would share\.\. i continue to be surprised\.\. lol


---

### 52. msg_25846

**You** - 2025-06-22T10:57:56

I am glad we are
Getting closer
To the end of this crappy process\.\.


---

### 53. msg_25847

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T11:09:24

>
I know, I am the same which is why I think it is weird when you say I will get sick of you if we lived together


---

### 54. msg_25848

**You** - 2025-06-22T11:12:21

I dunno lol I never had a lot of self confidence heh probably chalk it up to that\.


---

### 55. msg_25849

**You** - 2025-06-22T11:13:25

Plus we are from very different backgrounds\.\. I guess as long as I can keep up lol


---

### 56. msg_25850

**You** - 2025-06-22T11:18:58

Ya know listening to the discussion too really made me appreciate all the more the time you have prioritized for me\.  With so much going on in your life that you have to keep track off\.\. honestly makes me appreciate it all the more\.\. I never realized\.


---

### 57. msg_25851

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T11:19:49

>
Keep up with what?


---

### 58. msg_25852

**You** - 2025-06-22T11:23:30

Read below lol you lead an insanely busy life already full honestly and then some\.


---

### 59. msg_25853

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T11:25:42

I mean it is all relative\. It doesn’t feel busy to me\. It is just life\. lol


---

### 60. msg_25854

**You** - 2025-06-22T11:28:31

Reaction: ❤️ from Meredith Lamb
Anyhow it doesn’t matter it is what I want and I will figure out how to fit ☺️


---

### 61. msg_25855

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T11:31:04

I’m still talking to my parents so that is why I’m not super chatty\.


---

### 62. msg_25856

**You** - 2025-06-22T11:34:43

No no I am cooking and watching a show chat with your parents we can connect later ❤️❤️❤️❤️


---

### 63. msg_25857

**You** - 2025-06-22T12:04:23

The other thing
I noticed and it was while you and your mother were discussing something else\.\. your dad and I were talking about Australia and the adventure\.\. again you have had them your parents have\.\. and my choices have led me to very few adventures, and I am only realizing now how much I missed lol\.\. it’s fine it isn’t affecting me like it did just making me think more about what I want next\.


---

### 64. msg_25858

**You** - 2025-06-22T12:08:52

It was a really self reflective conversation\.\. for me\.\. learned a lot,  your mum is sweet btw very much like mine\.\. like in many ways scarily alike\.


---

### 65. msg_25859

**You** - 2025-06-22T12:09:22

She used words like interesting, annoying etc\.\. liked that to\.


---

### 66. msg_25860

**You** - 2025-06-22T12:09:58

>
Would have been interesting seeing them meet\.\. unstoppable force vs immovable object
lol


---

### 67. msg_25861

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T12:12:37

My parents have had many travel adventures\. They love to talk about them\. Travelling has always been their favourite thing\.


---

### 68. msg_25862

**You** - 2025-06-22T12:28:23

I think I would have loved it too give the tight company


---

### 69. msg_25863

**You** - 2025-06-22T12:28:28

Right


---

### 70. msg_25864

**You** - 2025-06-22T12:32:11

>
I think I will enjoy hearing their stories\.


---

### 71. msg_25865

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T12:37:16

My mom really liked you but I think she feels bad for Jaimie and thinks that is going to be “an issue” for many years


---

### 72. msg_25866

**You** - 2025-06-22T12:40:59

An issue how\.\. because of me\.\.?


---

### 73. msg_25867

**You** - 2025-06-22T12:42:25

I mean because I feel a sense of obligation?


---

### 74. msg_25868

**You** - 2025-06-22T12:42:45

That doesn’t change how I feel about you in the slightest bit what I want for our future\.


---

### 75. msg_25869

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T12:43:29

I think just stress wise maybe\. She didn’t elaborate\.


---

### 76. msg_25870

**You** - 2025-06-22T12:45:22

It will get easier as j settles in gets a job and resumes her life separately


---

### 77. msg_25871

**You** - 2025-06-22T12:45:31

Gracie will be challenging


---

### 78. msg_25872

**You** - 2025-06-22T12:47:18

I mean there are some awkward expectations\.\. both kids expect me there for Christmas for instance\.\. and while I want to be with them\.\. I am not going to be comfortable spending time with j going forward I think\.


---

### 79. msg_25873

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T12:49:27

Yeah figuring out holidays is going to be interesting on our end also


---

### 80. msg_25874

**You** - 2025-06-22T12:50:51

I am not worried\. Honestly I can figure out my side\.\. and I feel like there is between us we can figure us out\.\.


---

### 81. msg_25875

**You** - 2025-06-22T12:51:11

The stuff between us not there\.\.


---

### 82. msg_25876

**You** - 2025-06-22T12:52:26

While the not seeing you ache doesn’t change\.\. I am feeling much better in general\.  I hate leaving you every time even last night\.\. but I am not worrying as much about what comes next as much anymore\.


---

### 83. msg_25877

**You** - 2025-06-22T12:52:51

It just feels like some things are kind of coming together in my head finally so it makes it easier\.


---

### 84. msg_25878

**You** - 2025-06-22T12:53:36

Maybe I will tone back the intensity a bit though\.\. coming on pretty strong I think\.\. 🤔 lol


---

### 85. msg_25879

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T12:54:34

Coming on to me pretty strong?


---

### 86. msg_25880

**You** - 2025-06-22T12:55:10

Yeah I worry a little bit sometimes\.\.


---

### 87. msg_25881

**You** - 2025-06-22T12:55:14

Not a lot


---

### 88. msg_25882

**You** - 2025-06-22T12:55:18

Just a bit lol


---

### 89. msg_25883

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T12:57:21

I do know what you mean about feeling better and things coming together in your head\. I have that same feeling\. Things don’t feel as complicated and overwhelming anymore\.


---

### 90. msg_25884

**You** - 2025-06-22T12:58:34

No they don’t and I think we understand each other better as well\. Just have to be vigilant with the patience I am a little less than 4 weeks from a big change\.\. it will be sad but I will be able
To breathe too\.


---

### 91. msg_25885

**You** - 2025-06-22T12:59:00

Anyhow go enjoy your parents\.\. going to eat and then get some work around house done\. ❤️


---

### 92. msg_25886

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:02:36

>
Yes, this summer is going to be a little cray cray for sure\. But we will get through it ❤️


---

### 93. msg_25887

**You** - 2025-06-22T13:12:18

Yep 🥰


---

### 94. msg_25888

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:44:17

FaceTimed with Mac


---

### 95. msg_25889

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:44:29

She asked how it went with the intro lol


---

### 96. msg_25890

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:44:38

She goes “was nan weird?”


---

### 97. msg_25891

**You** - 2025-06-22T13:44:40

Hehe nice of her to ask


---

### 98. msg_25892

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:44:58

Then she asked my mom if she was weird and my mom goes “oh I dunno probably” lol


---

### 99. msg_25893

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:45:08

I said “she was not\!”


---

### 100. msg_25894

**You** - 2025-06-22T13:45:10

Haha ur mom wasn’t


---

### 101. msg_25895

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:45:10

lol


---

### 102. msg_25896

**You** - 2025-06-22T13:45:21

The hug was funny as hell though


---

### 103. msg_25897

**You** - 2025-06-22T13:45:26

She looked terrified\!


---

### 104. msg_25898

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:45:49

I forgot to tell her that


---

### 105. msg_25899

**You** - 2025-06-22T13:46:07

I was commited to making it happen one way or another


---

### 106. msg_25900

**You** - 2025-06-22T13:46:29

I couldn’t say goodbye though not properly as yku hustled my ass out of there


---

### 107. msg_25901

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T13:50:41

lol


---

### 108. msg_25902

**You** - 2025-06-22T14:05:01

You probably need to get
On road soon\.\. so maybe chat
Later on tonight?  Or just
Drop me a note whenever will be around cleaning etc\. getting ready to be back at office\.\. need to change offices first thing tomorrow\.


---

### 109. msg_25903

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T14:15:41

Just leaving to go get Maelle in Pickering\.


---

### 110. msg_25904

**You** - 2025-06-22T14:16:21

Kk drive safe have a good day\.


---

### 111. msg_25905

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T14:21:16

In my drunken and hung over state I forgot to thank you for meeting my parents even though you were very nervous\. I can tell they feel a lot better now about my whole situation so I think it was really valuable for them\. ❤️


---

### 112. msg_25906

**You** - 2025-06-22T14:27:45

lol you don’t need to thank me


---

### 113. msg_25907

**You** - 2025-06-22T14:29:49

Reaction: 😢 from Meredith Lamb
I enjoyed meeting them thoroughly\.
Made me miss my own parents a bit and sad that you wouldn’t get to meet them same way\.


---

### 114. msg_25908

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T14:30:29

Reaction: ❤️ from Scott Hicks
I don’t like them worrying about me and I knew when they met you they would feel better\. I told my mom that she would understand when she met you\. Today I could clearly tell I was right\.


---

### 115. msg_25909

**You** - 2025-06-22T14:31:52

I very much look forward
To spending more time with them\.\. and eventually rest of your family\.


---

### 116. msg_25910

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T14:55:04

Rest of my family sucks lol


---

### 117. msg_25911

**You** - 2025-06-22T14:55:36

No that’s not true… I am sure I will like them\.


---

### 118. msg_25912

**You** - 2025-06-22T15:22:19

>
>
>
I wanted to say again appreciated what you said but I am a bit of bull in a china shop atm no flattery necessary, I am just trying to figure “this” all out again, and it feels like the first time all over\.  Btw the look of shock on my face yesterday was at how beautiful you were in that moment and how I felt like you are so absolutely out of my league lol… was like a reaction I couldn’t control\.\. I am sure it will happen again lol\.   Contrary
To what you might think this hasn’t been me in 25 years and I am not lying\.\. but I do want to know what makes you happy\.\. maybe we can talk about that on this trip coming up\.\.  maybe you could learn to appreciate some of my OCD qualities??  I forgot to mention this earlier meant to but just popped into my head right now\.


---

### 119. msg_25913

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T15:53:05

I do appreciate your OCD\. I have a little of it also \- my mom always loves to remind me\. 😜 please please please stop saying that I am out of your league\. It is so far from the truth… like completely\. I think we are perfectly matched and 100% playing in the same league\. Being with you makes me extremely happy so talking about what makes me happy when I’m already happy … lol ok 🙂


---

### 120. msg_25914

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T15:53:30

And when you said yesterday…


---

### 121. msg_25915

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T15:55:01

Reaction: ❤️ from Scott Hicks
That if j knew what we were doing and she’d hate me lol Andrew would feel the same way\. We have never done that and it hasn’t ever been like that\. There is some extra with you and I\.


---

### 122. msg_25916

**You** - 2025-06-22T15:56:16

We can still talk about it though\. ☺️ I


---

### 123. msg_25917

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T16:01:34

Reaction: 👍 from Scott Hicks
Just got the little shadow and have to drive her home from beach


---

### 124. msg_25918

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T16:34:04

Home and time to chill\!


---

### 125. msg_25919

**You** - 2025-06-22T16:37:58

Nice


---

### 126. msg_25920

**You** - 2025-06-22T16:38:23

Reaction: 🙂 from Meredith Lamb
Still cleaning\.\. talking to my Cousin\.


---

### 127. msg_25921

**You** - 2025-06-22T16:54:31

what are you up to tonight\.\. watching tv??


---

### 128. msg_25922

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T16:55:06

Not sure actually\. Just looking at stuff online now\. Might nap\. lol


---

### 129. msg_25923

**You** - 2025-06-22T16:56:43

Nap lol\.\.


---

### 130. msg_25924

**You** - 2025-06-22T16:56:51

I am just trying to get out of this conversation\.


---

### 131. msg_25925

**You** - 2025-06-22T16:57:02

he never stops talking


---

### 132. msg_25926

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T16:57:05

lol been there


---

### 133. msg_25927

**You** - 2025-06-22T17:01:37

HOLY FUCK HE NEVER STOPS\!\!\!


---

### 134. msg_25928

**You** - 2025-06-22T17:01:54

he just kinda drags on


---

### 135. msg_25929

**You** - 2025-06-22T17:02:04

but I had to tell him because I told his dad and his brother


---

### 136. msg_25930

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T17:02:07

Haha well you have time


---

### 137. msg_25931

**You** - 2025-06-22T17:02:20

no I am going back to cleaning\.\. and trying on clothes


---

### 138. msg_25932

**You** - 2025-06-22T17:02:42

I have a bunch of stuff I need to sort through\.\. stuff that didn't fit for quite some time\.\. or that i bought and then it never fit\.\. need to get organized som\.


---

### 139. msg_25933

**You** - 2025-06-22T17:02:45

some\.


---

### 140. msg_25934

**You** - 2025-06-22T17:03:12

then plan my workouts for the week because 4 am starts again tomorrow\.\. and I might run in tonight for a 30 min run sauna and shower\.


---

### 141. msg_25935

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T17:04:54

Omg


---

### 142. msg_25936

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T17:05:08

The thought of all that makes me tired lol


---

### 143. msg_25937

**You** - 2025-06-22T17:07:38

Naw I am good will keep me busy


---

### 144. msg_25938

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T18:25:23

Nap time done 🙂


---

### 145. msg_25939

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T18:25:28

lol


---

### 146. msg_25940

**You** - 2025-06-22T18:34:37

Tough life


---

### 147. msg_25941

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T18:37:21

I’m still hungover lol


---

### 148. msg_25942

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T18:37:24

So pathetic


---

### 149. msg_25943

**You** - 2025-06-22T18:37:38

lol so sad


---

### 150. msg_25944

**You** - 2025-06-22T18:37:49

Reaction: 😂 from Meredith Lamb
I mean it was a rough day yesterday and all


---

### 151. msg_25945

**You** - 2025-06-22T18:38:16

I am a little tired and sore too\.\. but not hungover


---

### 152. msg_25946

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T18:55:01

At shoppers for Mac\. She had her last exam tomorrow so trying to do what she wants\. :p


---

### 153. msg_25947

**You** - 2025-06-22T18:56:38

lol heading to gym Gracie is driving me crazy so going to do a push set tonight and a pull set tomorrow morning…
Fml sometimes\.


---

### 154. msg_25948

**You** - 2025-06-22T18:57:00

I feel like such a bad dad I cannot
Stand to deal with her anymore when she is so toxic\.


---

### 155. msg_25949

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T19:16:50

That is so sucky\. Sorry


---

### 156. msg_25950

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T19:17:21

I have to talk to Andrew about when we are scheduling our next mediation appt


---

### 157. msg_25951

**You** - 2025-06-22T19:24:44

Kk good luck just walking into gym\.\. sorry you have to deal with that as well\.


---

### 158. msg_25952

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T19:33:30

Actually wasn’t a big thing\. Think he’s tired from beach today so that’s good


---

### 159. msg_25953

**You** - 2025-06-22T19:33:46

Good hope you got a date that works


---

### 160. msg_25954

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T19:35:13

I have to email her to schedule\. Hoping for this week if we can


---

### 161. msg_25955

**You** - 2025-06-22T19:35:32

Maybe get lucky


---

### 162. msg_25956

**You** - 2025-06-22T21:06:34

Got asked if I was law enforcement tonight in sauna\. ROFL


---

### 163. msg_25957

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:08:41

lol I get that actually


---

### 164. msg_25958

**You** - 2025-06-22T21:09:10

I literally laughed out loud was funniest thing I ever heard


---

### 165. msg_25959

**You** - 2025-06-22T21:09:59

Anyways was a first\.\.


---

### 166. msg_25960

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:10:42

Are you still at the gym?


---

### 167. msg_25961

**You** - 2025-06-22T21:11:49

Just going to get in car now


---

### 168. msg_25962

**You** - 2025-06-22T21:13:21

What are you up to


---

### 169. msg_25963

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:13:55

Tik tok lol


---

### 170. msg_25964

**You** - 2025-06-22T21:14:03

Pahhh


---

### 171. msg_25965

**You** - 2025-06-22T21:14:11

Meh


---

### 172. msg_25966

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:19:00

I get caught up every now and again lol


---

### 173. msg_25967

**You** - 2025-06-22T21:21:32

It’s like mind crack


---

### 174. msg_25968

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:25:28

Maybe if you use it all the time\. I don’t\.


---

### 175. msg_25969

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:25:35

It’s educational


---

### 176. msg_25970

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:25:39

😇


---

### 177. msg_25971

**You** - 2025-06-22T21:27:39

Mmmhmm ok\.\. well you do that I need to go iron clothes and get
My shit ready for tomorrow\.


---

### 178. msg_25972

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:30:46

Yeah I’m going to bed soon\. Tired\.


---

### 179. msg_25973

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:30:56

And our house is hot


---

### 180. msg_25974

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:31:03

Gahhh


---

### 181. msg_25975

**You** - 2025-06-22T21:31:12

Yeah no fun…


---

### 182. msg_25976

**You** - 2025-06-22T21:32:16

We’ll have a good sleep\.\. I want to go to bed but I am sure I will have to deal with shit before I get there\.


---

### 183. msg_25977

**Meredith Lamb \(\+14169386001\)** - 2025-06-22T21:34:09

Hopefully you don’t\. xo I love you and have been missing you today


---

### 184. msg_25978

**You** - 2025-06-22T21:40:25

Reaction: ❤️ from Meredith Lamb
Already fought with Gracie right after I unblocked her fml\.  So fucking stupid\.\. yeah been missing you today too\.\. like I said the more I am with you the more I want to be with you……\. Love you too have a good night\. Xoxo ❤️❤️❤️❤️❤️


---

### 185. msg_25979

**You** - 2025-06-23T04:04:18

Reaction: ❤️ from Meredith Lamb
Morning love\.\. last thought first thought\.❤️❤️❤️


---

### 186. msg_25980

**You** - 2025-06-23T04:05:21

Going to see if a push workout at 8 pm can be followed by a pull workout at 5 am\.\. lol let’s see how I feel rofl\.


---

### 187. msg_25981

**You** - 2025-06-23T05:22:12

Just starting and not feeling it lol\.\. this gonna hurt\.


---

### 188. msg_25982

**You** - 2025-06-23T05:22:23

Hope you have better luck today with your workout


---

### 189. msg_25983

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T05:45:59

>
Please don’t give yourself a heart attack 🙁


---

### 190. msg_25984

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T05:46:18

That would be very very sad


---

### 191. msg_25985

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T05:46:30

You are going SO hard


---

### 192. msg_25986

**You** - 2025-06-23T05:46:35

>
I don’t think you need to worry too
Much\.


---

### 193. msg_25987

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T05:47:31

>
I have cheat day and it is my favourite so I should be ok today :\)


---

### 194. msg_25988

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T05:47:51

>
I hope so\. You are going really hard right now


---

### 195. msg_25989

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T05:48:02

Love you \- coffee time tho lol


---

### 196. msg_25990

**You** - 2025-06-23T05:48:20

Love you enjoy your coffee\.  ☺️


---

### 197. msg_25991

**You** - 2025-06-23T06:39:35


*1 attachment(s)*


---

### 198. msg_25992

**You** - 2025-06-23T06:39:55


*1 attachment(s)*


---

### 199. msg_25993

**You** - 2025-06-23T06:40:05

Can never find a good place to do these


---

### 200. msg_25994

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:41:37

Total law enforcement lol


---

### 201. msg_25995

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:41:46

😍


---

### 202. msg_25996

**You** - 2025-06-23T06:41:57

Prolly cause I was white and bald


---

### 203. msg_25997

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:44:00

lol no


---

### 204. msg_25998

**You** - 2025-06-23T06:45:07

Hmm I think so\.\. anyhow sauna showers then omw hope
Your morning is going well\.


---

### 205. msg_25999

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:46:32

Going ok but our house is got so I’m dying


---

### 206. msg_26000

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:46:50


*1 attachment(s)*


---

### 207. msg_26001

**You** - 2025-06-23T06:46:52

Cold shower


---

### 208. msg_26002

**You** - 2025-06-23T06:47:13

Ooh Russian twists


---

### 209. msg_26003

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:47:14

Burpees and suicides are getting easier so babysteps is working


---

### 210. msg_26004

**You** - 2025-06-23T06:47:24

Have fun with those


---

### 211. msg_26005

**You** - 2025-06-23T06:47:29

lol


---

### 212. msg_26006

**You** - 2025-06-23T06:47:52

You cannot do it any other way\.\. without hurting yourself\.\. you got it\.\. ❤️


---

### 213. msg_26007

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:48:18

Supposed to be doing 3 sets of 12


---

### 214. msg_26008

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:48:24

Moved up to 8


---

### 215. msg_26009

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:48:28

Started at 6


---

### 216. msg_26010

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:48:46

And they weren’t as like annoying today despite the heat


---

### 217. msg_26011

**You** - 2025-06-23T06:49:14

Like you said to me\.\.
Don’t give yourself a heart attack 🥰


---

### 218. msg_26012

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:49:17

If I stopped drinking I’d make much faster progress


---

### 219. msg_26013

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:49:18

lol


---

### 220. msg_26014

**You** - 2025-06-23T06:49:27

Heheh yeah but not likely


---

### 221. msg_26015

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T06:49:43

Probably not right now


---

### 222. msg_26016

**You** - 2025-06-23T06:52:03

Not this weekend for sure


---

### 223. msg_26017

**You** - 2025-06-23T08:53:30

Good morning??


---

### 224. msg_26018

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T09:04:55

Yeah pretty good\. But rushed and so hot\. Glad to be in normal a/c now


---

### 225. msg_26019

**You** - 2025-06-23T09:32:12

Mmm I still find it a little warms


---

### 226. msg_26020

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T09:37:53

Jim wanted the update on the parents


---

### 227. msg_26021

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T09:38:04

lol


---

### 228. msg_26022

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T09:38:21

I forgot to text him after


---

### 229. msg_26023

**You** - 2025-06-23T10:08:29

lol you were drunk\.


---

### 230. msg_26024

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:13:37

So are you ok meeting my 2 best friends Sunday night in London? Oddly, they are both around\. Just talking to them


---

### 231. msg_26025

**You** - 2025-06-23T10:17:27

Cool


---

### 232. msg_26026

**You** - 2025-06-23T10:17:30

Should be fun


---

### 233. msg_26027

**You** - 2025-06-23T10:17:56

You comfortable with that?  I mean I am\.\.


---

### 234. msg_26028

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:23:12

Yeah I am for sure\. :\)


---

### 235. msg_26029

**You** - 2025-06-23T10:28:38

lol kk off we go then\.\.


---

### 236. msg_26030

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:30:46

I haven’t seen them in a while so will be nice for us girls also


---

### 237. msg_26031

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:31:00

My friend Mandy is having a hard time so needs it


---

### 238. msg_26032

**You** - 2025-06-23T10:32:11

No worries we can meet and you can go have a girls night if you would like\.


---

### 239. msg_26033

**You** - 2025-06-23T10:37:59

Like I don’t need to be a 4 th wheel or anything if you would have more fun just the three of you\.


---

### 240. msg_26034

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:42:16

You wont be a 4th wheel


---

### 241. msg_26035

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:42:30

lol


---

### 242. msg_26036

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:42:57

Mandy’s partner has depression right now really bad tho so won’t be coming and not sure about Kim’s …


---

### 243. msg_26037

**You** - 2025-06-23T10:45:25

We will see how it goes I can always pop out mid way through the night


---

### 244. msg_26038

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:48:25

No no they are very easy going


---

### 245. msg_26039

**You** - 2025-06-23T10:48:52

lol ok I will do whatever you tell me to\.\. is that better ☺️


---

### 246. msg_26040

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:49:16

Jim thinks I might stress you out if I do too many intros too fast


---

### 247. msg_26041

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:49:18

lol


---

### 248. msg_26042

**You** - 2025-06-23T10:49:27

Ge is incorrect


---

### 249. msg_26043

**You** - 2025-06-23T10:49:29

He


---

### 250. msg_26044

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:51:47

You sure??


---

### 251. msg_26045

**You** - 2025-06-23T10:53:53

Yeah\. I am def sure


---

### 252. msg_26046

**You** - 2025-06-23T10:54:08

Not even a little bit stressed about
Intros\.


---

### 253. msg_26047

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:58:37

K good because we are going to also have dinner with my SIL at keg on Monday night\. Walking distance from 4 points


---

### 254. msg_26048

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T10:59:01

Not sure if Trent will come or not … he’s not a big socializer so I said no pressure


---

### 255. msg_26049

**You** - 2025-06-23T11:01:22

Kk keep it coming\.\. all good


---

### 256. msg_26050

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T11:05:56

That’ll be it\. No one else in London knows about you yet\. Lol


---

### 257. msg_26051

**You** - 2025-06-23T11:42:36

Again I am good with whatever\.  All kinds of whatever


---

### 258. msg_26052

**You** - 2025-06-23T11:51:50

We have been invited to dinner Saturday afternoon\- I think since we are staying in\. GR that night we can go?


---

### 259. msg_26053

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T11:55:18

Sure


---

### 260. msg_26054

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T11:55:27

Omg just finished safety course\. Took so long


---

### 261. msg_26055

**You** - 2025-06-23T11:56:44

Hahaha


---

### 262. msg_26056

**You** - 2025-06-23T11:56:46

Told you


---

### 263. msg_26057

**You** - 2025-06-23T11:56:49

So bad


---

### 264. msg_26058

**You** - 2025-06-23T12:01:42

This whole look but don’t touch thing sucks btw\.\. just so you know\.


---

### 265. msg_26059

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T12:50:19

Reaction: ❤️ from Scott Hicks
I know, trust me, I know lol


---

### 266. msg_26060

**You** - 2025-06-23T13:08:55

Ugggh


---

### 267. msg_26061

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T13:10:18

Four days


---

### 268. msg_26062

**You** - 2025-06-23T13:14:38

Still


---

### 269. msg_26063

**You** - 2025-06-23T13:59:59

So Gracie cannot do dbt at Ontario shores while in Moncton and she won’t lie\.\. so now who the fuck knows what is going to happen\.


---

### 270. msg_26064

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:02:10

Oh no


---

### 271. msg_26065

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:02:33

Is it a tactic to stay in Ontario?


---

### 272. msg_26066

**You** - 2025-06-23T14:02:38

Yeah I mean she is going to try to leverage this to stay and if she does it will basically break maddie and I\.


---

### 273. msg_26067

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:04:42

Are there no resources in Moncton?


---

### 274. msg_26068

**You** - 2025-06-23T14:05:32

Nope bit like Ontario


---

### 275. msg_26069

**You** - 2025-06-23T14:05:47

I mean this is something Gracie can sort out on her own she just needs to grow the fuck up


---

### 276. msg_26070

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:06:53

Are you sure?


---

### 277. msg_26071

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:07:17

If she can’t even get on a bus or go buy her own shit…\.


---

### 278. msg_26072

**You** - 2025-06-23T14:07:27

I think she can she does for her friends


---

### 279. msg_26073

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:08:08

Hmmh


---

### 280. msg_26074

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:08:32

Then why do you buy her carts


---

### 281. msg_26075

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:08:38

I mean she is home all day


---

### 282. msg_26076

**You** - 2025-06-23T14:19:22

I don’t know because if I don’t she loses
Her shit


---

### 283. msg_26077

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:20:08

Vicious cycle


---

### 284. msg_26078

**You** - 2025-06-23T14:29:23

Yep


---

### 285. msg_26079

**You** - 2025-06-23T14:29:32

This could really impact
My life


---

### 286. msg_26080

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:32:48

How could both girls stay here without their mom? I don’t understand that\.


---

### 287. msg_26081

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:33:02

Wouldn’t Jaimie fall apart


---

### 288. msg_26082

**You** - 2025-06-23T14:42:04

Probably but Gracie doesn’t care


---

### 289. msg_26083

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:44:41

This doesn’t sound good


---

### 290. msg_26084

**You** - 2025-06-23T14:48:24

Nope I am a little worried


---

### 291. msg_26085

**You** - 2025-06-23T14:50:06

This doesn’t affect us to be clear


---

### 292. msg_26086

**You** - 2025-06-23T14:50:12

In case you are worried


---

### 293. msg_26087

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T14:51:30

Not worried about us\. More just your family in general\. Doesn’t sound great for anyone really\.


---

### 294. msg_26088

**You** - 2025-06-23T14:56:51

Nope


---

### 295. msg_26089

**You** - 2025-06-23T14:58:58

I am worried about my sanity


---

### 296. msg_26090

**You** - 2025-06-23T14:59:01

And my job


---

### 297. msg_26091

**You** - 2025-06-23T14:59:17

Because she will text and phone call bomb me all day


---

### 298. msg_26092

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:02:40

Does Jaimie know about this new development? What are her thoughts?


---

### 299. msg_26093

**You** - 2025-06-23T15:02:44

Like this is a serious issue\.\.


---

### 300. msg_26094

**You** - 2025-06-23T15:02:49

J is on her way home


---

### 301. msg_26095

**You** - 2025-06-23T15:02:53

We are going to discuss


---

### 302. msg_26096

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:03:22

How long is the program again?


---

### 303. msg_26097

**You** - 2025-06-23T15:13:28

13 weeks \.\. j is saying she is going to Moncton period


---

### 304. msg_26098

**You** - 2025-06-23T15:13:32

So see if that holds


---

### 305. msg_26099

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:14:53

“She” meaning Gracie or meaning herself


---

### 306. msg_26100

**You** - 2025-06-23T15:25:08

Gracie


---

### 307. msg_26101

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:25:21

Ah I see


---

### 308. msg_26102

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:25:33

Hey did you get rid of the playlist you made on Spotify?


---

### 309. msg_26103

**You** - 2025-06-23T15:25:42

Nope


---

### 310. msg_26104

**You** - 2025-06-23T15:25:44

Why


---

### 311. msg_26105

**You** - 2025-06-23T15:26:32

You deleted it eh\.\. thought… so lame\.\. and never gonna last so why keep it\.\. Eesh


---

### 312. msg_26106

**You** - 2025-06-23T15:26:34

Ouch


---

### 313. msg_26107

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:27:01

I don’t see it anymore


---

### 314. msg_26108

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:27:04

Weird


---

### 315. msg_26109

**You** - 2025-06-23T15:27:10

Deleted it


---

### 316. msg_26110

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:27:19

I didn’t


---

### 317. msg_26111

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:27:22

You did


---

### 318. msg_26112

**You** - 2025-06-23T15:28:41

https://open\.spotify\.com/playlist/4o0w2C4v7JfY6AwQTKoWoD?si=W4D1GyHwRsaCgxkuHCVJZw&pi=h0AtizhKSbG19


---

### 319. msg_26113

**You** - 2025-06-23T15:29:03

I changed the name so that no one would notice now no one can axcesss it anyways


---

### 320. msg_26114

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T15:31:03

Ahh


---

### 321. msg_26115

**You** - 2025-06-23T16:02:42

I want to see you 🤯…\. lol booooo shitty day\.\. 3\.5
Days


---

### 322. msg_26116

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T16:03:52

:\(


---

### 323. msg_26117

**You** - 2025-06-23T16:04:01

Fack


---

### 324. msg_26118

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T16:17:41

I think I’m going to leave\. Ok?


---

### 325. msg_26119

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T16:18:35

Did you leave?


---

### 326. msg_26120

**You** - 2025-06-23T16:37:13

I am still here in with is


---

### 327. msg_26121

**You** - 2025-06-23T16:37:31

Ian will be here late ish\.\. love you\.\.🥰


---

### 328. msg_26122

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T16:46:34

Love you too xo I’m almost home :\)


---

### 329. msg_26123

**You** - 2025-06-23T16:47:10

Kk chat later


---

### 330. msg_26124

**You** - 2025-06-23T17:20:13

Just leaving now meh\.


---

### 331. msg_26125

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:24:48

Be glad you have ac


---

### 332. msg_26126

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:24:53

Ours has been off all day


---

### 333. msg_26127

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:25:02

Just turned it on and it is a stupid mini split


---

### 334. msg_26128

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:25:16

This house is ridiculous


---

### 335. msg_26129

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:25:28

It’s 30 degrees inside


---

### 336. msg_26130

**You** - 2025-06-23T17:29:39

Yucky


---

### 337. msg_26131

**You** - 2025-06-23T17:29:59

Any word back from mediator


---

### 338. msg_26132

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:30:20

Yeah we got the link but Andrew hasn’t let me know when he is available yet


---

### 339. msg_26133

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:30:24

:p


---

### 340. msg_26134

**You** - 2025-06-23T17:30:39

Ah ok\.\.
So this week then\. Not bad if a can do it


---

### 341. msg_26135

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:30:57

I’m trying to get him to agree to Thursday


---

### 342. msg_26136

**You** - 2025-06-23T17:31:30

Well here is hoping… progress is good


---

### 343. msg_26137

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:32:20

Yeah and in the meantime I need to just find a place\. Harder than I thought


---

### 344. msg_26138

**You** - 2025-06-23T17:33:42

Yeah I still don’t feel like he is being fair and if he goes from 12 to 8 years it is going to be really hard


---

### 345. msg_26139

**You** - 2025-06-23T17:35:16

I mean if you believe in us\.\. and I do\.\. then we will be living together at some point and it will be a bit easier for both of us\.\. but I mean depending on him putting in a bullshit cohabitation clause\.\. fuck I will have nothing good to say to this guy ever\.


---

### 346. msg_26140

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:37:18

He just got home and can’t do Thursday\. “No chance\. Fully booked day\.”


---

### 347. msg_26141

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:37:21

Argh


---

### 348. msg_26142

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:37:31

I will likely have to take Friday from hotel\.


---

### 349. msg_26143

**You** - 2025-06-23T17:38:20

Kk


---

### 350. msg_26144

**You** - 2025-06-23T17:38:30

That should be fine\.


---

### 351. msg_26145

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:41:44

Argh Andrew’s bday is Wednesday\. It’s weird


---

### 352. msg_26146

**You** - 2025-06-23T17:47:01

Big one too


---

### 353. msg_26147

**You** - 2025-06-23T17:47:03

45


---

### 354. msg_26148

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:48:15

He said he doesn’t want anything from anyone


---

### 355. msg_26149

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:48:17

lol


---

### 356. msg_26150

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:48:20

Ok done


---

### 357. msg_26151

**You** - 2025-06-23T17:48:30

lol


---

### 358. msg_26152

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:50:36

Omg everyone just left


---

### 359. msg_26153

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:50:40

It is like heaven here


---

### 360. msg_26154

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:50:51

All doing diff things


---

### 361. msg_26155

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:51:08

Very hot like hell but peaceful like heaven


---

### 362. msg_26156

**You** - 2025-06-23T17:51:09

And for me I am
Driving into the mouth of hell\!\!  lol


---

### 363. msg_26157

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:51:21

lol


---

### 364. msg_26158

**You** - 2025-06-23T17:51:51

This will be a long few days


---

### 365. msg_26159

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:52:44

Yep


---

### 366. msg_26160

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:52:54

Are you doing site visits on Thursday and Friday?


---

### 367. msg_26161

**You** - 2025-06-23T17:53:13

Yep but done early Friday


---

### 368. msg_26162

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:53:25

OK, no problem was just curious


---

### 369. msg_26163

**You** - 2025-06-23T17:53:33

And not too late thurs


---

### 370. msg_26164

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:53:36

I took Friday off


---

### 371. msg_26165

**You** - 2025-06-23T17:53:37

But you will be


---

### 372. msg_26166

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:54:00

Yes, I will be very late on Thursday


---

### 373. msg_26167

**You** - 2025-06-23T17:54:20

Should I have some wine ready for you lol


---

### 374. msg_26168

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:54:37

lol um


---

### 375. msg_26169

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:54:51

It is so freaking hot here\. I’m shopping on Amazon for linen pants\. Lol


---

### 376. msg_26170

**You** - 2025-06-23T17:55:02

Heheh


---

### 377. msg_26171

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:55:07

I just wish I had them right now


---

### 378. msg_26172

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:55:09

Gah


---

### 379. msg_26173

**You** - 2025-06-23T17:55:16

Wear shorts


---

### 380. msg_26174

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:55:34

I am but really light flowy pants feels better


---

### 381. msg_26175

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:55:48

Shorts you get sticky to the leather furniture


---

### 382. msg_26176

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T17:55:54

Not a big fan


---

### 383. msg_26177

**You** - 2025-06-23T17:55:57

Mmm


---

### 384. msg_26178

**You** - 2025-06-23T17:56:01

Fair enough


---

### 385. msg_26179

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:42:52

Just finished uploading some final stuff for mediator\. Now going to try a show Jim recommended\. He gave me a couple today\. I think he is disappointed in my tv watching lately\. You have interrupted it


---

### 386. msg_26180

**You** - 2025-06-23T18:42:55

So much joy here\!\!\!\!\!\!\!


---

### 387. msg_26181

**You** - 2025-06-23T18:43:02

ROFL gahhhhhh


---

### 388. msg_26182

**You** - 2025-06-23T18:43:22

What no I haven’t


---

### 389. msg_26183

**You** - 2025-06-23T18:43:28

I leave you alone most of the time


---

### 390. msg_26184

**You** - 2025-06-23T18:43:50

Reaction: ❤️ from Meredith Lamb
Pshhhh\.\. well I will say good day then\!\!\!\!


---

### 391. msg_26185

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:45:19

Just distraction


---

### 392. msg_26186

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:45:21

lol


---

### 393. msg_26187

**You** - 2025-06-23T18:45:21

😝


---

### 394. msg_26188

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:45:44

Everyone is miserable there?


---

### 395. msg_26189

**You** - 2025-06-23T18:45:57

Ok well I will take an inventory of all of the things I say or do that may be distracting and I will refrain for a few days\.


---

### 396. msg_26190

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:46:02

And they literally had to do nothing today?


---

### 397. msg_26191

**You** - 2025-06-23T18:46:10

>
Mmmm kinda\.


---

### 398. msg_26192

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:46:22

>
Listen, I never said it Jim not me


---

### 399. msg_26193

**You** - 2025-06-23T18:46:42

Hmmmm nope I feel like you told Jim I was a distraction


---

### 400. msg_26194

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:46:56

I totally did not\!


---

### 401. msg_26195

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:47:03

I just haven’t been watching shows at my typical rate


---

### 402. msg_26196

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:47:05

lol


---

### 403. msg_26197

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:47:22

I am still further ahead than him on a bunch of things though


---

### 404. msg_26198

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:47:24

lol


---

### 405. msg_26199

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:48:05

He thought he was gonna be so good telling me about “dying for sex” and I had already seen it\. He literally went home and told Kristine 🙄


---

### 406. msg_26200

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:48:16

I watched the whole season while he was in Scotland


---

### 407. msg_26201

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:48:18

lol


---

### 408. msg_26202

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:48:38

Do you know what happened today?


---

### 409. msg_26203

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:48:52

So he gets a call and it’s clearly Christine


---

### 410. msg_26204

**You** - 2025-06-23T18:48:58

Kk


---

### 411. msg_26205

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:49:10

She asked him a question and I can tell and he goes “I will tell you later”


---

### 412. msg_26206

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:49:20

I swear to god she was asking how it went with my parents


---

### 413. msg_26207

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:49:30

lol


---

### 414. msg_26208

**You** - 2025-06-23T18:49:30

Yeah no doubt


---

### 415. msg_26209

**You** - 2025-06-23T18:49:47

He was kinda messing with me about it as we walked over to the desk


---

### 416. msg_26210

**You** - 2025-06-23T18:49:54

And about meeting your friends


---

### 417. msg_26211

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:50:03

He’s very concerned for you


---

### 418. msg_26212

**You** - 2025-06-23T18:50:07

Why


---

### 419. msg_26213

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:50:26

Well, he thinks that like they’re gonna grill you or something and they totally would not like not even close


---

### 420. msg_26214

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:50:32

I think Christine’s friends must be different


---

### 421. msg_26215

**You** - 2025-06-23T18:50:46

But why is he worried\.\. I can handle that


---

### 422. msg_26216

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:51:05

He just said he would find it very nerve\-wracking


---

### 423. msg_26217

**You** - 2025-06-23T18:51:10

Not me


---

### 424. msg_26218

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:51:11

Especially after just meeting the parents


---

### 425. msg_26219

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:51:13

lol


---

### 426. msg_26220

**You** - 2025-06-23T18:51:29

Nope I don’t think he understands our relationship


---

### 427. msg_26221

**You** - 2025-06-23T18:51:40

I don’t think many would


---

### 428. msg_26222

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:51:57

Well, he hasn’t really been around us outside of work so like yeah


---

### 429. msg_26223

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:52:14

And I can only talk about so much at work it just feels weird when you’re in an office


---

### 430. msg_26224

**You** - 2025-06-23T18:52:19

Yeah we will have to actually spend some time there some night


---

### 431. msg_26225

**You** - 2025-06-23T18:52:25

True


---

### 432. msg_26226

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:52:36

Yeah, they have a busy summer though so no pressure so that’s good


---

### 433. msg_26227

**You** - 2025-06-23T18:52:50

Yep


---

### 434. msg_26228

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:53:15

It would be better when he’s not socially exhausted\. He always gets socially tired in summer


---

### 435. msg_26229

**You** - 2025-06-23T18:55:08

lol I mean I will have to get used to some things as we are able to spend more time regularly with each other and I can do family stuff with you because it might be a lot at first but it is what I want


---

### 436. msg_26230

**You** - 2025-06-23T18:55:18

Like very much


---

### 437. msg_26231

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T18:56:15

We will both have to get used to “some things” 🙂


---

### 438. msg_26232

**You** - 2025-06-23T18:59:36

I am looking forward to it\.\. not feeling like it is a burden


---

### 439. msg_26233

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:00:13

Me neither, not at all\. I honestly don’t even think I will have anything to get used to but who knows\.


---

### 440. msg_26234

**You** - 2025-06-23T19:03:46

Not with or for you\.\. nope


---

### 441. msg_26235

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:35:56

Asking my mom what she thought about you


---

### 442. msg_26236

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:35:58

lol


---

### 443. msg_26237

**You** - 2025-06-23T19:38:05

Interested


---

### 444. msg_26238

**You** - 2025-06-23T19:38:13

Also interested in what your dad thought


---

### 445. msg_26239

**You** - 2025-06-23T19:38:24

I thought you already talked…


---

### 446. msg_26240

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:40:13

I mean we talked the next day but I didn’t ask them\. They need time to process


---

### 447. msg_26241

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:40:29

I could just gauge their moods etc etc how they talked and they were really good


---

### 448. msg_26242

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:41:00

When I left she went to her sister Gail’s so I asked her what she told Gail lol


---

### 449. msg_26243

**You** - 2025-06-23T19:44:37

Ah ok


---

### 450. msg_26244

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:45:13

Meh  ~ this is very my mom

*1 attachment(s)*


---

### 451. msg_26245

**You** - 2025-06-23T19:46:32

That is reasonable


---

### 452. msg_26246

**You** - 2025-06-23T19:47:01

And unsurprising she is your mum\.\. she cares about your well\-being\.\. and getting a signed agreement is importantly


---

### 453. msg_26247

**You** - 2025-06-23T19:47:34

She is too much of a realist not a hopeless romantic


---

### 454. msg_26248

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:49:17

Literally just typed: “Oh dear though\. I don’t like to be hugged but don’t tell him yet because it will bother him”


---

### 455. msg_26249

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:50:23

Also: “You were the worst drinking that much\.”


---

### 456. msg_26250

**You** - 2025-06-23T19:51:06

ROFL


---

### 457. msg_26251

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:51:11

>
I said you did it because I told you not to and you were just being an ass and she goes: Oh good\. It’s OK for him to get an elbow then next hug\.


---

### 458. msg_26252

**You** - 2025-06-23T19:51:40

Maybe I don’t go for one next time\.\.


---

### 459. msg_26253

**You** - 2025-06-23T19:52:45

Reaction: 😂 from Meredith Lamb
Sounds like she has some stark honesty too lol\.


---

### 460. msg_26254

**You** - 2025-06-23T19:53:25

Mer she is\. Or going to like me right now


---

### 461. msg_26255

**You** - 2025-06-23T19:53:29

lol leave her be


---

### 462. msg_26256

**You** - 2025-06-23T19:53:35

Not going to


---

### 463. msg_26257

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:53:49

Yes she is


---

### 464. msg_26258

**You** - 2025-06-23T19:54:07

No she is focused on the right thing which is your situation\.


---

### 465. msg_26259

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:54:13

She’s not gonna like me for drinking too much right now\. I told her I’m gonna stop again\.


---

### 466. msg_26260

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:54:21

Eventually


---

### 467. msg_26261

**You** - 2025-06-23T19:55:18

Well I am happy she doesn’t have bad things to say about me\.\. but you wouldn’t tell me anyways


---

### 468. msg_26262

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:55:34

Oh, I totally would


---

### 469. msg_26263

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:55:36

lol


---

### 470. msg_26264

**You** - 2025-06-23T19:55:48

No I don’t think you would


---

### 471. msg_26265

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:56:00

Yep, I would\. I’ve told Andrew all the negative things she said about him\.


---

### 472. msg_26266

**You** - 2025-06-23T19:56:14

Stark


---

### 473. msg_26267

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:56:22

lol


---

### 474. msg_26268

**You** - 2025-06-23T19:57:20

Again I don’t think your mum understands the nature of our relationship and even if she did \.\.
I don’t think she would appreciate it\.


---

### 475. msg_26269

**You** - 2025-06-23T19:57:26

Again I don’t blame
Her


---

### 476. msg_26270

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:57:43

She doesn’t at all\. I haven’t told her that level of detail


---

### 477. msg_26271

**You** - 2025-06-23T19:57:55

I think it would make it worse


---

### 478. msg_26272

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:58:05

Yeah, she doesn’t need to know that it would just make her worry


---

### 479. msg_26273

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T19:59:28

But we know 🙂


---

### 480. msg_26274

**You** - 2025-06-23T19:59:47

That is true we do


---

### 481. msg_26275

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T20:13:03


*1 attachment(s)*


---

### 482. msg_26276

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T20:13:45

Is she enabling me?


---

### 483. msg_26277

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T20:13:48

lol


---

### 484. msg_26278

**You** - 2025-06-23T21:30:56

I think she is being a mom


---

### 485. msg_26279

**You** - 2025-06-23T21:32:07

I kind of fell asleep watching a show/\.


---

### 486. msg_26280

**You** - 2025-06-23T21:32:39

Not feeling the best tonight guess I just wanted it to be over with…


---

### 487. msg_26281

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:35:32

I just watched the first episode of an interesting show that Jim told me to watch\. It’s on Apple called “friends and neighbors” starring John Hamm


---

### 488. msg_26282

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:35:45

So he’s a guy that gets divorced and then he gets fired from his job for sleeping with someone at work


---

### 489. msg_26283

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:35:48

lol


---

### 490. msg_26284

**You** - 2025-06-23T21:36:04

Mmmm sounds interesting


---

### 491. msg_26285

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:36:20

It was and I think he’s supposed to be 47


---

### 492. msg_26286

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:36:22

lol


---

### 493. msg_26287

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:37:59

I think that’s good that you got some extra sleep\. You should go back to sleep if you can\.


---

### 494. msg_26288

**You** - 2025-06-23T21:40:52

Yeah I will try I guess\.\. you go enjoy your show\.  Chat tomorrow\.


---

### 495. msg_26289

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:41:11

You ok?


---

### 496. msg_26290

**You** - 2025-06-23T21:44:01

Just a shitty night\.\. but nothing to do with you\.  Anyhow love you… go enjoy yourself\. Xo\.


---

### 497. msg_26291

**You** - 2025-06-23T21:46:17

Sorry I missed the rest
Of your mom chat hope it went well\.    Night\.\.


---

### 498. msg_26292

**Meredith Lamb \(\+14169386001\)** - 2025-06-23T21:47:41

Sorry you are feeling shitty\. Hopefully tomorrow is better\. Love you \(most\) ❤️


---

### 499. msg_26293

**You** - 2025-06-24T04:10:34

We will see\.\. I love you too\.\. hope you had a good sleep\. ❤️


---

### 500. msg_26294

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T05:47:04

Reaction: ❤️ from Scott Hicks
G’morn ❤️


---

### 501. msg_26295

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:20:56

So I met this really nice agent over the phone and he’s helping me now


---

### 502. msg_26296

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:21:11

Such a nice guy so I am feeling better about finding a place


---

### 503. msg_26297

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:21:37

He sent me a whole bunch of places


---

### 504. msg_26298

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:21:46

And asked for all the docs I need


---

### 505. msg_26299

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:21:55

Like credit report, employment letter…


---

### 506. msg_26300

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:22:11

A few of the places I hadn’t seen online


---

### 507. msg_26301

**You** - 2025-06-24T06:22:30

Cool well hope you can find something that ticks all the boxes


---

### 508. msg_26302

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:23:25

Well that will be impossible but looking better at least


---

### 509. msg_26303

**You** - 2025-06-24T06:24:37

Impossible\.\. thought you didn’t like absolutes\.


---

### 510. msg_26304

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:33:55

Check out this listing
https://realtor\.ca/real\-estate/28033947/2\-22\-college\-view\-avenue\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
I like this place even though it is really pricey\. Right near our place but not too close\. I dunno\.


---

### 511. msg_26305

**You** - 2025-06-24T06:36:47

Beautiful\.\. but I think you need
To do a budget\.


---

### 512. msg_26306

**You** - 2025-06-24T06:39:07

Maybe get big bro Jim to help🙂


---

### 513. msg_26307

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:39:38

Edited: 2 versions
| Version: 2
| Sent: Tue, 24 Jun 2025 06:39:46 \-0400
|
| I have done a budget
|
| Version: 1
| Sent: Tue, 24 Jun 2025 06:39:38 \-0400
|
| I have done a burger


---

### 514. msg_26308

**You** - 2025-06-24T06:39:46

Mmmm


---

### 515. msg_26309

**You** - 2025-06-24T06:39:48

Burger


---

### 516. msg_26310

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:39:57

But I used $5k for rent


---

### 517. msg_26311

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:40:13

Because I have the cottage too


---

### 518. msg_26312

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:40:22

It’s like $1,500 a month


---

### 519. msg_26313

**You** - 2025-06-24T06:40:32

Jesus lol


---

### 520. msg_26314

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:40:40

lol


---

### 521. msg_26315

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:41:01

This is why I need his $\.


---

### 522. msg_26316

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:41:28

I only see myself in yeg area for another 5 years really


---

### 523. msg_26317

**You** - 2025-06-24T06:43:00

I mean I can’t see you really building any savings for yourself in next 5\-7 years


---

### 524. msg_26318

**You** - 2025-06-24T06:43:07

You might want to meet with an advisor


---

### 525. msg_26319

**You** - 2025-06-24T06:44:11

This is why i thought it wad important to fight about the broken pension if you hadn’t have broken it you would be completely fine


---

### 526. msg_26320

**You** - 2025-06-24T06:44:44

I just worry about you


---

### 527. msg_26321

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:45:00

Yes yes I know


---

### 528. msg_26322

**You** - 2025-06-24T06:45:14

lol dismissive rofl typical mer


---

### 529. msg_26323

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:50:02

😇


---

### 530. msg_26324

**You** - 2025-06-24T06:50:31

Got says you need between 330k and 350 k gross


---

### 531. msg_26325

**You** - 2025-06-24T06:50:44

For your situation allowing you to responsibly save for yourself as well


---

### 532. msg_26326

**You** - 2025-06-24T06:51:00

With a 5400 rent and another 1500 mortgage


---

### 533. msg_26327

**You** - 2025-06-24T06:54:44

Reaction: 😂 from Meredith Lamb
Alright well I will see you from across the room work\.\. going to sauna and shower and then head in\.


---

### 534. msg_26328

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:55:33

>
Gross what?


---

### 535. msg_26329

**You** - 2025-06-24T06:55:42

Salary


---

### 536. msg_26330

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:55:58

Oh right


---

### 537. msg_26331

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:56:09

Well it would be only for 5 yrs


---

### 538. msg_26332

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:56:20

So almost like a 5 yr pause


---

### 539. msg_26333

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:56:45

We can’t sell the cottage now


---

### 540. msg_26334

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:56:50

I have no choice on that


---

### 541. msg_26335

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:57:02

I can maybe get out in a couple years


---

### 542. msg_26336

**You** - 2025-06-24T06:57:09

Ok hon\.\. well I will do whatever I can to help cause I love you and that’s what I’ll do\.


---

### 543. msg_26337

**You** - 2025-06-24T06:57:29

Will chat in a bit\.


---

### 544. msg_26338

**You** - 2025-06-24T06:57:32

❤️


---

### 545. msg_26339

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T06:57:52

Reaction: 😂 from Scott Hicks
k going to finish this workout in my home sauna :p


---

### 546. msg_26340

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T07:56:41

https://open\.spotify\.com/track/2a7NRfaVMfob2BvkBmOxA0?si=ukRe\_u9DRQaY3NUFgbpXCg
I asked ChatGPT what songs I would like and it gave me this one and I DID used to love this song and forgot about it\. Funny\.


---

### 547. msg_26341

**You** - 2025-06-24T08:14:02

Listened to this recently when I was going through that self
Loathing phase


---

### 548. msg_26342

**You** - 2025-06-24T08:14:12

Same time I listened to sia\.


---

### 549. msg_26343

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T08:17:29

I hope you are not self loathing anymore lol


---

### 550. msg_26344

**You** - 2025-06-24T08:21:06

…\.\.sometimes…\. I am
Just much more in control of my emotions now\.


---

### 551. msg_26345

**You** - 2025-06-24T08:21:44

You are more likely now
To only see what I want you to… took me a fucking while to get back in control


---

### 552. msg_26346

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T08:45:26

>
“sometimes”…\.omg i don’t get this at all\. You have absolutely zero to be self loathing about … blows my mind\.


---

### 553. msg_26347

**You** - 2025-06-24T08:46:47

Reaction: ❤️ from Meredith Lamb
Whatever it is me\.\. but I do have a lot more control than I did recently so I am quite pleased about that tbh\.


---

### 554. msg_26348

**You** - 2025-06-24T09:07:56

You might not be though 😜


---

### 555. msg_26349

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T09:09:27

lol


---

### 556. msg_26350

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T09:31:07

I think I’m going to just attempt to secure that semi with no basement\. Live for a year and see how it goes\.


---

### 557. msg_26351

**You** - 2025-06-24T09:31:44

Prolly smart tbh not optimal but within budget and you only have to do a year


---

### 558. msg_26352

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T09:32:20

Yeah I told Diana and she seems happy


---

### 559. msg_26353

**You** - 2025-06-24T09:50:12

I mean it is nice to have that support right nearby


---

### 560. msg_26354

**You** - 2025-06-24T09:50:18

How far from current house?


---

### 561. msg_26355

**You** - 2025-06-24T09:50:31

Like walk across park or something isn’t it


---

### 562. msg_26356

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T09:54:51

Yup literally that close


---

### 563. msg_26357

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T10:00:45

So what do I wear on Saturday? Is this like wedding dressy? Do I have to buy something? What are you wearing


---

### 564. msg_26358

**You** - 2025-06-24T10:40:42

Probably khaikis and a dress shirt or collared golf shirt with dress shoes


---

### 565. msg_26359

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T10:56:06

So not wedding dressy


---

### 566. msg_26360

**You** - 2025-06-24T12:02:58

Reaction: 😂 from Meredith Lamb
Since Jessica is also a clergy person, she will be wearing a robe and stole\.
In the Episcopal Church, the ordination of a priest is a big deal and some people highlight the significance of that in their attire\. Other people don’t give a shit and wear whatever\.
However, I would certainly never want you to feel embarrassed because you felt underdressed\. Based on what I know about you, I think you would feel most comfortable with khakis and a button\-down shirt… Throw on a jacket if you like Jessica will wear a dress\. I’m so Meredith may want to take this chance to have a little fun with what she wears Keeping in mind that we’re going to church and not the club\.🤣


---

### 567. msg_26361

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T13:55:27

Meredith is no fun ever in what she wears\. :\)


---

### 568. msg_26362

**You** - 2025-06-24T15:00:01

ROFL


---

### 569. msg_26363

**You** - 2025-06-24T15:00:29

You good btw you looked
Like you might be cranky when I walked by\.\. I tend to elicit that look from many people so I woildnt be surprised


---

### 570. msg_26364

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T15:03:16

I have a head ache but am fine lol


---

### 571. msg_26365

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T15:03:19

Not cranky


---

### 572. msg_26366

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T15:03:38

Going to take my girls to see that place tonight at 8


---

### 573. msg_26367

**You** - 2025-06-24T15:48:40

The one by Diane\.\. cook I hope they like it\.\. Mac won’t\.


---

### 574. msg_26368

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T15:57:29

Mac will hate


---

### 575. msg_26369

**You** - 2025-06-24T15:57:40

Yah not fancy no amenities


---

### 576. msg_26370

**You** - 2025-06-24T15:57:48

She is used to a certain standard of living


---

### 577. msg_26371

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T15:59:13

I could make it nice ENOUGH


---

### 578. msg_26372

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T15:59:26

I will tell her I will have extra money for nice stuff


---

### 579. msg_26373

**You** - 2025-06-24T16:02:24

Smart


---

### 580. msg_26374

**You** - 2025-06-24T16:02:30

That is the selling feature


---

### 581. msg_26375

**You** - 2025-06-24T16:42:46

Looking for me


---

### 582. msg_26376

**You** - 2025-06-24T16:42:48

Almost done


---

### 583. msg_26377

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T16:45:55

Not really was just looking :\)


---

### 584. msg_26378

**You** - 2025-06-24T16:45:57

Omg what a fucking day


---

### 585. msg_26379

**You** - 2025-06-24T16:46:04

Well I caught you


---

### 586. msg_26380

**You** - 2025-06-24T16:46:11

😜


---

### 587. msg_26381

**You** - 2025-06-24T16:48:41

So not staying late tonight \.\. fuck I am tired and cranky as hell


---

### 588. msg_26382

**You** - 2025-06-24T16:48:50

Gracie called me
4
Times in the mgmt
Meeting


---

### 589. msg_26383

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T16:52:29

Yikes why


---

### 590. msg_26384

**You** - 2025-06-24T16:52:53

Cause she wants to give me a stroke\.


---

### 591. msg_26385

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T16:57:27

Gahhh


---

### 592. msg_26386

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T16:57:45

I am going to leave\. Tired and need to talk financial with Andrew tonight argh


---

### 593. msg_26387

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T16:58:03

He’s been trying over text and I’m like I want to leave can we do this at home not on text


---

### 594. msg_26388

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T16:58:06

Ffs


---

### 595. msg_26389

**You** - 2025-06-24T17:02:32

Yeah I am right behind you\.\. have a good night


---

### 596. msg_26390

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T17:02:57

“Good” …\. Definitely won’t be but oh well


---

### 597. msg_26391

**You** - 2025-06-24T17:07:58

Reaction: ❤️ from Meredith Lamb
Love you\. ❤️


---

### 598. msg_26392

**You** - 2025-06-24T17:08:07

Can’t really say that in parking lot lol


---

### 599. msg_26393

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T17:08:55


*1 attachment(s)*


---

### 600. msg_26394

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T17:09:00

lol wtf


---

### 601. msg_26395

**You** - 2025-06-24T17:09:27

ROFL


---

### 602. msg_26396

**You** - 2025-06-24T17:48:50

Not sus at all


---

### 603. msg_26397

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T18:32:28

k Andrew and I done\. I’m having a nap\. I so want all of this done\. Omg


---

### 604. msg_26398

**You** - 2025-06-24T18:33:09

Hope it was ok


---

### 605. msg_26399

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T18:34:34

Not really


---

### 606. msg_26400

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T18:34:41

But I need to nap for an hour


---

### 607. msg_26401

**You** - 2025-06-24T18:34:51

Kk later then ❤️


---

### 608. msg_26402

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:29:58

So the Edith place\. Rough


---

### 609. msg_26403

**You** - 2025-06-24T21:30:18

Not fixable?


---

### 610. msg_26404

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:30:24

So went to this place: https://realtor\.ca/real\-estate/28504794/196\-lawrence\-avenue\-w\-toronto\-lawrence\-park\-south\-lawrence\-park\-south?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 611. msg_26405

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:30:39

He’s going to try to get it for me tonight or tomorrow morning


---

### 612. msg_26406

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:30:56

>
Not really\. Diana bummed for sure


---

### 613. msg_26407

**You** - 2025-06-24T21:31:00

Get it for you?


---

### 614. msg_26408

**You** - 2025-06-24T21:31:05

Like for a walkthrough


---

### 615. msg_26409

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:31:23

No to rent


---

### 616. msg_26410

**You** - 2025-06-24T21:31:25

Or you getting it


---

### 617. msg_26411

**You** - 2025-06-24T21:31:27

Jesus


---

### 618. msg_26412

**You** - 2025-06-24T21:31:28

Ok


---

### 619. msg_26413

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:31:29

Walked through it just now


---

### 620. msg_26414

**You** - 2025-06-24T21:31:33

Kids like


---

### 621. msg_26415

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:31:40

Only Maelle went with me


---

### 622. msg_26416

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:31:42

She did


---

### 623. msg_26417

**You** - 2025-06-24T21:31:52

Nice


---

### 624. msg_26418

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:33:10

We will see\. Hopefully\. I just want to get a place and be done


---

### 625. msg_26419

**You** - 2025-06-24T21:33:27

Yah makes
Sense


---

### 626. msg_26420

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:34:19

Rough night


---

### 627. msg_26421

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:34:34

Just overwhelming and Andrew wants spousal to go down $100k


---

### 628. msg_26422

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:34:47

So lump sum of $214k instead of $330k


---

### 629. msg_26423

**You** - 2025-06-24T21:35:47

You are going to have to push back and hard and mean\.\. and mean it unless you are
Willing to do what he wants\.\. he is just going to keep beating on you I feel\.\. and I am sorry he is doing it\.


---

### 630. msg_26424

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:53:16

Well he is saying he is doing the high end of child so should be lower on spousal


---

### 631. msg_26425

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:53:38

It’s hard to know what is right because his income is so high that the tables don’t work


---

### 632. msg_26426

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:54:08

Can I use you as a reference on my application for rental\. Would that be weird


---

### 633. msg_26427

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:54:39

I need 2 and not too many ppl know im applying\. Using Diana first


---

### 634. msg_26428

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T21:55:31

You were my boss for quite a while so it works


---

### 635. msg_26429

**You** - 2025-06-24T22:05:27

>
Yes


---

### 636. msg_26430

**You** - 2025-06-24T22:06:05

>
See what the mediator suggests\.\. she suggests 12 years\.\. your answer that seems reasonable to me timid the mid point


---

### 637. msg_26431

**You** - 2025-06-24T22:06:42

He tries to push x for 4% ask the mediator what the standard is\. Then agree maybe with something in the middle


---

### 638. msg_26432

**You** - 2025-06-24T22:07:16

If he is doing 8 years out him big end on both of 12 maybe mid?


---

### 639. msg_26433

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:07:22

The 214k is based on 12 yrs


---

### 640. msg_26434

**You** - 2025-06-24T22:07:46

I dont think you agree to anything


---

### 641. msg_26435

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:07:54

I’m going to ask him tonight why the floor and not in the middle


---

### 642. msg_26436

**You** - 2025-06-24T22:07:59

Just tell him you are tired


---

### 643. msg_26437

**You** - 2025-06-24T22:08:09

And that this is why you have a mediator


---

### 644. msg_26438

**You** - 2025-06-24T22:08:31

We will see what her recommendation is and then I will provide my feedback


---

### 645. msg_26439

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:15:22

Ugh I hate all of this so much


---

### 646. msg_26440

**You** - 2025-06-24T22:15:38

What now


---

### 647. msg_26441

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:15:59

No nothing new\. Just thinking out loud lol


---

### 648. msg_26442

**You** - 2025-06-24T22:16:38

Oh I thought you said you were asking him and went and did it


---

### 649. msg_26443

**You** - 2025-06-24T22:21:09

You watching tv


---

### 650. msg_26444

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:22:50

No just sent through docs for the rental offer


---

### 651. msg_26445

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:22:59

Had to fill out a bunch of stuff


---

### 652. msg_26446

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:23:05

And download pay stubs


---

### 653. msg_26447

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:23:11

Just finished


---

### 654. msg_26448

**You** - 2025-06-24T22:23:25

Ah ok\.\.


---

### 655. msg_26449

**You** - 2025-06-24T22:23:38

Didnt know if you went off to battle and if I should just go to bed lol\.\.


---

### 656. msg_26450

**You** - 2025-06-24T22:32:35

I feel like you have had a busy night and are still in it\.\. I am going to go to bed\.\. my night was not great gracie fought with us most of night then j and I fought again\.


---

### 657. msg_26451

**You** - 2025-06-24T22:33:08

So I am tired and going to sleep\.\.   love you\.\. night


---

### 658. msg_26452

**Meredith Lamb \(\+14169386001\)** - 2025-06-24T22:36:03

Love you too \- sleep well ❤️❤️


---

### 659. msg_26453

**You** - 2025-06-25T04:08:23

Good morning\.\. love ❤️ ❤️❤️❤️
Sorry I tried
To stay awake but again felt like you were distracted regardless and didn’t want to add to it\.  Hope everything ended well for you and that there was no further fighting\.


---

### 660. msg_26454

**You** - 2025-06-25T04:10:41

Reaction: 😢 from Meredith Lamb
Going to go to gym\.\. I had quite the bad night last night so just going to work it out\.\. not much I can do\.\. Gracie just screaming she won’t go and Jaimie blaming me for forcing the issue, and me defending myself and then attacking back\.\.  I just have to let all of this happen I have to take the blame and get through these last few weeks without trying to even really defend myself anymore\.  Will see how it goes\.


---

### 661. msg_26455

**You** - 2025-06-25T04:11:30

So good luck getting that home I will give a great reference\.\. looking forward to seeing it for myself eventually\.  Kk gonna get going Love you so much\.


---

### 662. msg_26456

**You** - 2025-06-25T06:37:31

New pb\.

*3 attachment(s)*


---

### 663. msg_26457

**You** - 2025-06-25T06:42:34

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 664. msg_26458

**You** - 2025-06-25T06:42:42

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 665. msg_26459

**You** - 2025-06-25T06:42:53

You haven’t been holding up your end with the pics btw\.


---

### 666. msg_26460

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T07:06:02

I’m tiiiiiired and skipping this morning\. Last night was a lot all around\. Going to sleep some more\.


---

### 667. msg_26461

**You** - 2025-06-25T07:32:51

Did you guys keep going after you said good night\.\. well I guess whenever you wake up and perhaps if A is not working from home we could chat on teams? Have a good extra sleep


---

### 668. msg_26462

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:16:10

Yeah, we talked a bit more, but it didn’t go too late\. It’s just with all of this and the apartment searching\. I don’t have maelle ready for camp so I might have to take a vacation day tomorrow\.


---

### 669. msg_26463

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:16:30

Just feeling a bit overwhelmed\.


---

### 670. msg_26464

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:16:36

A lot happening at once\.


---

### 671. msg_26465

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:05

And Marlowe didn’t react well to house hunting\. Wouldn’t go to the second


---

### 672. msg_26466

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:18

Then couldn’t get ahold of Mackenzie at midnight


---

### 673. msg_26467

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:22

Freaked me out


---

### 674. msg_26468

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:30

I can always get ahold of her


---

### 675. msg_26469

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:35

And she was far away


---

### 676. msg_26470

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:41

But finally she called back


---

### 677. msg_26471

**You** - 2025-06-25T08:17:45

Uggh


---

### 678. msg_26472

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:52

I told her to be home by 1am


---

### 679. msg_26473

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:17:54

Wasn’t


---

### 680. msg_26474

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:18:01

But was in an uber


---

### 681. msg_26475

**You** - 2025-06-25T08:18:01

I mean if you are overwhelmed maybe don’t come tomorrow


---

### 682. msg_26476

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:18:20

But for home after 1am\. Little fucker


---

### 683. msg_26477

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:18:33

No I will be good if I can get Maelle packed\.


---

### 684. msg_26478

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:18:42

She hasn’t started and is away for 3 wks


---

### 685. msg_26479

**You** - 2025-06-25T08:18:52

Can I help with anything off the record?


---

### 686. msg_26480

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:19:02

I’ve bought her some things, but I never know what else to buy until she actually freaking starts to pack\!


---

### 687. msg_26481

**You** - 2025-06-25T08:19:03

Ie work related


---

### 688. msg_26482

**You** - 2025-06-25T08:19:34

Like I could look at ai thing and just give you my\. Thoughts\. Jus to you to use


---

### 689. msg_26483

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:19:42

No, work isn’t big right now


---

### 690. msg_26484

**You** - 2025-06-25T08:19:43

Anything to help


---

### 691. msg_26485

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:19:52

Ai thing lol


---

### 692. msg_26486

**You** - 2025-06-25T08:19:53

Kk


---

### 693. msg_26487

**You** - 2025-06-25T08:20:07

I tried some stuff last night on my own for irs\.\. it is hard


---

### 694. msg_26488

**You** - 2025-06-25T08:20:19

And that is with all the tools
I have


---

### 695. msg_26489

**You** - 2025-06-25T08:20:45

I am going to keep at it in my spare time


---

### 696. msg_26490

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:20:56

I don’t think it was tested for IRs?


---

### 697. msg_26491

**You** - 2025-06-25T08:21:22

No no but they want it to be able to do something ir related


---

### 698. msg_26492

**You** - 2025-06-25T08:21:31

And I don’t think they understand the difficulties


---

### 699. msg_26493

**You** - 2025-06-25T08:21:40

So I am trying to build a workflow to show them


---

### 700. msg_26494

**You** - 2025-06-25T08:21:47

Them being Erin


---

### 701. msg_26495

**You** - 2025-06-25T08:21:50

And Daniel


---

### 702. msg_26496

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:22:18

We should have kept alpha :p


---

### 703. msg_26497

**You** - 2025-06-25T08:22:39

I am not going to rise to that one\.


---

### 704. msg_26498

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:23:42

lol


---

### 705. msg_26499

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:23:53

I’m going to get Austin to show me the tool


---

### 706. msg_26500

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:23:57

See what he thinks


---

### 707. msg_26501

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:24:03

Curious on his thoughts


---

### 708. msg_26502

**You** - 2025-06-25T08:24:20

Kk


---

### 709. msg_26503

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:27:55

I just moved my vac day to tomorrow and I will work on fri


---

### 710. msg_26504

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T08:28:01

Have to do mediation anyway


---

### 711. msg_26505

**You** - 2025-06-25T08:29:20

Kk well just let me know when you plan to hit the road so I can either let you check in on my behalf or I can check in in between my site visit and supper and have a key waiting for you\.


---

### 712. msg_26506

**You** - 2025-06-25T08:30:12

Oh and bring a bathing suit or shorts and a short
Or whatever\.\. just in case swimming or hot tub\.


---

### 713. msg_26507

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T09:01:26

So I had to fill out more docs this morn and I should hear by tomorrow morning


---

### 714. msg_26508

**You** - 2025-06-25T09:03:44

Cool\.\. good luck :\)


---

### 715. msg_26509

**You** - 2025-06-25T09:06:51

https://chatgpt\.com/g/g\-67a93c84dd7c8191b9f579cc38ea90cf\-deepcognition\-os\-v2


---

### 716. msg_26510

**You** - 2025-06-25T09:07:03

Try using this link when you gpt next\.


---

### 717. msg_26511

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T09:13:23

k, want to chat before your meetings start


---

### 718. msg_26512

**You** - 2025-06-25T10:49:08

eesh breathe for a sec


---

### 719. msg_26513

**You** - 2025-06-25T12:05:36

therapy time\.\. then if done early packing for trip yay\!\!


---

### 720. msg_26514

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:15:32

I cancelled my therapy for today\. Too annoyed and don’t feel like it


---

### 721. msg_26515

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:15:40

And too much to do generally


---

### 722. msg_26516

**You** - 2025-06-25T12:15:54

yeah I understand\.\.


---

### 723. msg_26517

**You** - 2025-06-25T12:15:58

sorry you are annoyed


---

### 724. msg_26518

**You** - 2025-06-25T12:16:11

Reaction: 😂 from Meredith Lamb
you will be a treat tomorrow and Friday right LOL


---

### 725. msg_26519

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:16:18

I have a permanent head ache lol


---

### 726. msg_26520

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:16:32

>
I will not be\.


---

### 727. msg_26521

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:16:35

lol


---

### 728. msg_26522

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:16:54

I took tomorrow and Friday off\. Self preservation mode


---

### 729. msg_26523

**You** - 2025-06-25T12:17:01

:\(


---

### 730. msg_26524

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:17:07

I have to set up new bank account and credit card tomorrow


---

### 731. msg_26525

**You** - 2025-06-25T12:17:07

😢


---

### 732. msg_26526

**You** - 2025-06-25T12:18:26

sounds like first 2 days gonna be AWESOME\!\!


---

### 733. msg_26527

**You** - 2025-06-25T12:18:27

lol


---

### 734. msg_26528

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:22:26

I will be okay 😇


---

### 735. msg_26529

**You** - 2025-06-25T12:25:09

mmmm hmmmmm


---

### 736. msg_26530

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:25:37

😇


---

### 737. msg_26531

**You** - 2025-06-25T12:26:09

SURE\.\. will see


---

### 738. msg_26532

**You** - 2025-06-25T12:27:47

Maybe i will just hang out with Harris later on Friday\.\. give you more time to cool down\.


---

### 739. msg_26533

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:38:57

Bromance\.
Will be an interesting day I’m sure :p


---

### 740. msg_26534

**You** - 2025-06-25T12:42:53

Well it might be safer


---

### 741. msg_26535

**You** - 2025-06-25T12:43:01

He might be gentler with me\.


---

### 742. msg_26536

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:44:22

Likely


---

### 743. msg_26537

**You** - 2025-06-25T12:44:55

Well play it safe I guess will be back
Before lights out\.


---

### 744. msg_26538

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T12:45:52

😋


---

### 745. msg_26539

**You** - 2025-06-25T12:46:21

Kk gonna tell Haris\.\. I am sure he will be excited\.\. will let you know\.


---

### 746. msg_26540

**You** - 2025-06-25T13:08:04

this is my first eda experience\.


---

### 747. msg_26541

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:08:37

lol Whitney’s bestie


---

### 748. msg_26542

**You** - 2025-06-25T13:08:52

yeah she was very emphatic


---

### 749. msg_26543

**You** - 2025-06-25T13:17:16

this presentation needs to be revised\.\. no one cares about these numbers\.


---

### 750. msg_26544

**You** - 2025-06-25T13:17:23

they are meaningless\.


---

### 751. msg_26545

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:19:25

Yep


---

### 752. msg_26546

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:19:31

The whole thing is ridiculous


---

### 753. msg_26547

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:19:43

It is honestly so painful


---

### 754. msg_26548

**You** - 2025-06-25T13:26:40

I am so unhappy


---

### 755. msg_26549

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:27:29

I could have given this presentation in 10 minutes


---

### 756. msg_26550

**You** - 2025-06-25T13:27:38

less


---

### 757. msg_26551

**You** - 2025-06-25T13:31:43

I literally just told her this\.


---

### 758. msg_26552

**You** - 2025-06-25T13:37:14

I am hammering Chantal on the side here\.


---

### 759. msg_26553

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:37:40

lol


---

### 760. msg_26554

**You** - 2025-06-25T13:37:42

Reaction: ❤️ from Meredith Lamb
Awww the RC show\.\. our first teen date\.


---

### 761. msg_26555

**You** - 2025-06-25T13:38:00

walking around no holding hands\.


---

### 762. msg_26556

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:38:17

Per


---

### 763. msg_26557

**You** - 2025-06-25T13:38:22

chaparone


---

### 764. msg_26558

**You** - 2025-06-25T13:38:25

made sense


---

### 765. msg_26559

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:39:56

Did you make Chantal cry so she went off camera?


---

### 766. msg_26560

**You** - 2025-06-25T13:40:34

I am not sure\.\. I basically told her I was directing my team to be more discerning and to support activities where there is a clear line of site to measureable outcomes\.


---

### 767. msg_26561

**You** - 2025-06-25T13:40:50

she seems fine


---

### 768. msg_26562

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:41:53

>
Looking back, this was so wrong lol


---

### 769. msg_26563

**You** - 2025-06-25T13:42:07

😭 no it wasn't


---

### 770. msg_26564

**You** - 2025-06-25T13:42:25

😢


---

### 771. msg_26565

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:42:26

lol ok


---

### 772. msg_26566

**You** - 2025-06-25T13:42:36

now I have to go off camera


---

### 773. msg_26567

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:42:40

I mean from like a work perspective


---

### 774. msg_26568

**You** - 2025-06-25T13:44:08

If I didn't do that would it have made a difference?


---

### 775. msg_26569

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:44:59

Probably not at all


---

### 776. msg_26570

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:45:12

Just kind of funny\. No wonder Deb was confused


---

### 777. msg_26571

**You** - 2025-06-25T13:46:58

And I told my therapist I was doing so well\.\.\.\. gah\!\!


---

### 778. msg_26572

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:51:18

lol stawp


---

### 779. msg_26573

**You** - 2025-06-25T13:51:32

This is what regression feels like\.\. I always wondered\.


---

### 780. msg_26574

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:51:59

You are not serious?


---

### 781. msg_26575

**You** - 2025-06-25T13:52:06

😬


---

### 782. msg_26576

**You** - 2025-06-25T13:52:12

😝


---

### 783. msg_26577

**You** - 2025-06-25T13:52:15

No


---

### 784. msg_26578

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:52:19

I can’t tell sometimes


---

### 785. msg_26579

**You** - 2025-06-25T13:52:32

that is the saddest thing you have said yet\.\.


---

### 786. msg_26580

**You** - 2025-06-25T13:52:37

😢


---

### 787. msg_26581

**You** - 2025-06-25T13:52:45

lol


---

### 788. msg_26582

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:52:56

Omg what exactly


---

### 789. msg_26583

**You** - 2025-06-25T13:53:26

said another way\.\. you have been such a consistent baby\.\. cry baby cry\!\!  that I cannot tell when you are joking about it or actually crying \- yah big baby\!\!\!


---

### 790. msg_26584

**You** - 2025-06-25T13:53:31

again kidding


---

### 791. msg_26585

**You** - 2025-06-25T13:53:36

butnot kidding


---

### 792. msg_26586

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:53:47

lol


---

### 793. msg_26587

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:54:03

I didn’t say anything close to that


---

### 794. msg_26588

**You** - 2025-06-25T13:54:15

Going to have to have a Chatgpt night again\.


---

### 795. msg_26589

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:54:47

Omg dramatic


---

### 796. msg_26590

**You** - 2025-06-25T13:55:00

I am including all of these chats\.\. :P


---

### 797. msg_26591

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:55:22

k that actually made me laugh


---

### 798. msg_26592

**You** - 2025-06-25T13:55:29

I noticed LOL


---

### 799. msg_26593

**You** - 2025-06-25T13:55:38

what do you think I am doing off camera right now


---

### 800. msg_26594

**You** - 2025-06-25T13:55:39

not crying


---

### 801. msg_26595

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:55:50

Reaction: ❓ from Scott Hicks
Chester


---

### 802. msg_26596

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T13:56:19

Going off camera is cheating


---

### 803. msg_26597

**You** - 2025-06-25T13:56:44

mmmm yeah totally I couldn't help smiling at all during this exchange you are way better than I am


---

### 804. msg_26598

**You** - 2025-06-25T13:59:45

you didn't need to come to this meeting yah know\.


---

### 805. msg_26599

**You** - 2025-06-25T14:00:02

or are you like sad that your calendar looks so bare\.\.


---

### 806. msg_26600

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:00:44

Chantal asked me to in person and I told her I would


---

### 807. msg_26601

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:00:47

:p


---

### 808. msg_26602

**You** - 2025-06-25T14:01:10

Hmmmm\.\. well now she gets to deal with me\.


---

### 809. msg_26603

**You** - 2025-06-25T14:01:16

good feelings gone\.


---

### 810. msg_26604

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:01:52

Honestly I think Edith or Austin should be attending meetings like these to learn more about programs


---

### 811. msg_26605

**You** - 2025-06-25T14:02:00

nope\.\.


---

### 812. msg_26606

**You** - 2025-06-25T14:02:02

denied


---

### 813. msg_26607

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:02:07

:p


---

### 814. msg_26608

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:02:14

How are they supposed to learn


---

### 815. msg_26609

**You** - 2025-06-25T14:02:16

reading


---

### 816. msg_26610

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:02:22

Oh god


---

### 817. msg_26611

**You** - 2025-06-25T14:02:26

learning from their ELDERS


---

### 818. msg_26612

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:02:30

You are stubborn sometimes


---

### 819. msg_26613

**You** - 2025-06-25T14:02:29

not me\./


---

### 820. msg_26614

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:02:44

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 14:02:54 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Wed, 25 Jun 2025 14:02:30 \-0400
| >
| > You are stubborn sometimes
|
| Put this in chat gpt
|
| Version: 1
| Sent: Wed, 25 Jun 2025 14:02:44 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Wed, 25 Jun 2025 14:02:30 \-0400
| >
| > You are stubborn sometimes
|
| Put this in chat for


---

### 821. msg_26615

**You** - 2025-06-25T14:04:00

Reaction: 🙄 from Meredith Lamb
Reaction: 😂 from Scott Hicks
It would suggest that perception is everything, and that one person's perception of stubborn is another person's perception of perseverance, dedication, etc etc \(\#Iamawesome\)


---

### 822. msg_26616

**You** - 2025-06-25T14:04:05

I didn't need gpt for that\.


---

### 823. msg_26617

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:04:07

>
So like harassing me everyday?


---

### 824. msg_26618

**You** - 2025-06-25T14:04:20

yep


---

### 825. msg_26619

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:04:52

Awesome


---

### 826. msg_26620

**You** - 2025-06-25T14:04:53

I would drop but I said I would meet whitney and Mus after


---

### 827. msg_26621

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:05:01

lol


---

### 828. msg_26622

**You** - 2025-06-25T14:05:12

then I have to go get car


---

### 829. msg_26623

**You** - 2025-06-25T14:05:15

then pack


---

### 830. msg_26624

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:05:31

When are you driving there


---

### 831. msg_26625

**You** - 2025-06-25T14:05:42

4 am


---

### 832. msg_26626

**You** - 2025-06-25T14:05:44

5 am


---

### 833. msg_26627

**You** - 2025-06-25T14:05:59

do OC meeting at 9am in chatham


---

### 834. msg_26628

**You** - 2025-06-25T14:06:08

and then meet with some chatham folks


---

### 835. msg_26629

**You** - 2025-06-25T14:06:13

then to Windsor for noon


---

### 836. msg_26630

**You** - 2025-06-25T14:06:16

site visit 2pm


---

### 837. msg_26631

**You** - 2025-06-25T14:06:19

supper at Keg


---

### 838. msg_26632

**You** - 2025-06-25T14:06:27

likely hotel in between\.


---

### 839. msg_26633

**You** - 2025-06-25T14:06:35

depends kind of on when you expect to arrive


---

### 840. msg_26634

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:06:59

Honestly not sure yet


---

### 841. msg_26635

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:07:05

I have stuff to do here tomorrow


---

### 842. msg_26636

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:07:12

So won’t be early


---

### 843. msg_26637

**You** - 2025-06-25T14:07:26

yeah  get it\.\. I wasn't planning on that\.\. was more like are you going to be there at 4 or 7 or 10


---

### 844. msg_26638

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:07:40

Hmmmh


---

### 845. msg_26639

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:07:44

Depends on Maelle


---

### 846. msg_26640

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:07:56

Little shit is so bad at packing


---

### 847. msg_26641

**You** - 2025-06-25T14:08:18

well I will probably just go to hotel around 4 before supper drop my shit off tell them you are coming\.\. have a key there for you if you want it\.


---

### 848. msg_26642

**You** - 2025-06-25T14:08:50

I mean if you don't leave until 4 you won't be there until well after 8 regardless\.\. so likely won't matter


---

### 849. msg_26643

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:09:17

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 14:09:26 \-0400
|
| Exactly\. Can I just keep you updated tomorrow? “Play it by ear” lol
|
| Version: 1
| Sent: Wed, 25 Jun 2025 14:09:17 \-0400
|
| Exactly\. Can I just keep you updated tomorrow? “Play it be ear” lol


---

### 850. msg_26644

**You** - 2025-06-25T14:09:30

idc\.\. lol whatever works for you


---

### 851. msg_26645

**You** - 2025-06-25T14:33:17

maybe don't tell me anything and just surprise me when you show up\.\.


---

### 852. msg_26646

**You** - 2025-06-25T14:33:22

:P


---

### 853. msg_26647

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:34:41

I feel like you are cranky today also\. We will be a good pair together?


---

### 854. msg_26648

**You** - 2025-06-25T14:35:53

No no not cranky at all\.\. not even a bit\.\. anxious to get going\.\. looking forward to seeing you\.\. well I was…\.
lol


---

### 855. msg_26649

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:36:48

😢


---

### 856. msg_26650

**You** - 2025-06-25T14:37:55

I mean I am I am lol\.\. just that you are going to be all mad and shit\.


---

### 857. msg_26651

**You** - 2025-06-25T14:38:19

I caught myself staring at
You in the meeting yesterday\.\. I was like WTF…


---

### 858. msg_26652

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:38:44

>
I will not be “all mad and shit”\. Just a little anxious


---

### 859. msg_26653

**You** - 2025-06-25T14:38:46

So yeah sooo looking forward and I will take you however you come and do what I can to make you happy


---

### 860. msg_26654

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T14:39:24

>
Meetings are brutal\. Whyyyyyyyyyy


---

### 861. msg_26655

**You** - 2025-06-25T15:12:25

lol


---

### 862. msg_26656

**You** - 2025-06-25T15:12:29

I couldn’t help it


---

### 863. msg_26657

**You** - 2025-06-25T15:13:08

Then I start thinking nice things and distracted


---

### 864. msg_26658

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T15:24:48

I find you very distracting\. Constantly\. It’s been easier not being in your group though but still distracting lol


---

### 865. msg_26659

**You** - 2025-06-25T15:25:42

Reaction: ❤️ from Meredith Lamb
Well I hope that never changes Meredith I don’t expect it will for me\.


---

### 866. msg_26660

**You** - 2025-06-25T15:29:19

Btw I was curious we are
Going for dinner with your sil\.  What are we doing with your friends?


---

### 867. msg_26661

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T15:30:09

Not sure yet\. Need to check in\. I was thinking just drinks bc not sure on timing


---

### 868. msg_26662

**You** - 2025-06-25T15:30:31

Well we can leave as early as you want to on Sunday


---

### 869. msg_26663

**You** - 2025-06-25T15:30:39

To get to London whenever you want to\.


---

### 870. msg_26664

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T15:52:40

My parents here


---

### 871. msg_26665

**You** - 2025-06-25T15:55:09

nice have fun with the pics\.\. give your mum a big hug and a kiss from me\.\. and tell her I am not afraid of elbows\!


---

### 872. msg_26666

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:40:55

She’s giving me a break from pix bc I am literally full of anxiety


---

### 873. msg_26667

**You** - 2025-06-25T16:41:09

why what's wrong mer\.\.


---

### 874. msg_26668

**You** - 2025-06-25T16:41:18

like calm


---

### 875. msg_26669

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:41:39

Just everything


---

### 876. msg_26670

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:41:51

These people are reluctant to rent to me bc of my salary


---

### 877. msg_26671

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:41:58

Meeting the owner at 6\.30pm


---

### 878. msg_26672

**You** - 2025-06-25T16:42:03

Tell them to call me


---

### 879. msg_26673

**You** - 2025-06-25T16:42:07

I am aware of everything


---

### 880. msg_26674

**You** - 2025-06-25T16:42:10

so I can speak to that


---

### 881. msg_26675

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:42:24

It’ll isn’t even all that\. Just everything coming to a head at once


---

### 882. msg_26676

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:42:41

At least I’m not dealing with c/i though lol


---

### 883. msg_26677

**You** - 2025-06-25T16:43:26

please let me help\.\. just tell me what you need, I can be the reference fuck I just wish I could come in with you on this\.


---

### 884. msg_26678

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:44:17

This is not the thing causing anxiety\. It is one thing


---

### 885. msg_26679

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:44:24

They also want no pets


---

### 886. msg_26680

**You** - 2025-06-25T16:44:33

ok well maybe this is not the palce


---

### 887. msg_26681

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:44:35

I feel like any place I have to agree to no pets


---

### 888. msg_26682

**You** - 2025-06-25T16:44:35

place


---

### 889. msg_26683

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:44:50

It is illegal to evict bc of pets


---

### 890. msg_26684

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:44:57

So just going with it\.


---

### 891. msg_26685

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:45:05

Realtor said to and they aren’t even full time


---

### 892. msg_26686

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:45:14

Anyway plus Andrew being an ass


---

### 893. msg_26687

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:45:31

I think Marlowe is sad too bc I took her to a house to view :p


---

### 894. msg_26688

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:45:38

She feels bad for her dad also


---

### 895. msg_26689

**You** - 2025-06-25T16:45:40

So you are overwhelmed


---

### 896. msg_26690

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:45:45

Yes\!


---

### 897. msg_26691

**You** - 2025-06-25T16:45:47

so you need to stop looking at everything


---

### 898. msg_26692

**You** - 2025-06-25T16:45:54

and you need to focus on one thing


---

### 899. msg_26693

**You** - 2025-06-25T16:45:56

only


---

### 900. msg_26694

**You** - 2025-06-25T16:46:00

ignore the rest


---

### 901. msg_26695

**You** - 2025-06-25T16:46:02

do that


---

### 902. msg_26696

**You** - 2025-06-25T16:46:11

that is how i did it


---

### 903. msg_26697

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:46:16

Tomorrow I have to deal with bank and credit card and Maelle’s camp


---

### 904. msg_26698

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:46:18

Agh


---

### 905. msg_26699

**You** - 2025-06-25T16:46:32

that was on top of being completely infatuated and in love with you\.\. which I still am but I am in much better control now\.


---

### 906. msg_26700

**You** - 2025-06-25T16:46:59

So you have this call\.\. that is next\.\. focus on that Fuck Andrew\.


---

### 907. msg_26701

**You** - 2025-06-25T16:47:15

if you don't need the place\.\. then don't worry about it


---

### 908. msg_26702

**You** - 2025-06-25T16:47:27

you will get another\.\. and be in a better place to once agreement is signed


---

### 909. msg_26703

**You** - 2025-06-25T16:48:15

Marlow \- that is just reality\.\. you decided you don't want to destroy her perception of her dad\.\. it is going to be tough\.\. just have to be supportive of her and patient with her\.\. that will be fine\.\.


---

### 910. msg_26704

**You** - 2025-06-25T16:48:39

Bank is fucking easy\.\. just time\.


---

### 911. msg_26705

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:48:42

>
I want this place though if I can get it\. If not no biggie but ugh more looking


---

### 912. msg_26706

**You** - 2025-06-25T16:48:52

yeah but now you have a guy


---

### 913. msg_26707

**You** - 2025-06-25T16:48:54

he will look for you


---

### 914. msg_26708

**You** - 2025-06-25T16:49:02

he knows what you want\.\. well guy or girl\.\. not sure


---

### 915. msg_26709

**You** - 2025-06-25T16:49:05

he/she??


---

### 916. msg_26710

**You** - 2025-06-25T16:49:08

lol


---

### 917. msg_26711

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:49:10

He


---

### 918. msg_26712

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:49:16

Dennis


---

### 919. msg_26713

**You** - 2025-06-25T16:49:19

so he can look for you and will be motivated to


---

### 920. msg_26714

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:50:11

Reaction: ❤️ from Scott Hicks
Everything will be ok, I know this logically\. My nervous system is just a bit shot


---

### 921. msg_26715

**You** - 2025-06-25T16:50:26

So Marlow \- sorted for now\.\. nothing you can do so don't worry\.  Phone call you are ready\.\. you have references\.\. and you don't need it anyways\.  Andrew \- I don't even know now what he is on about\.\.  Maelle after phone call and tomorrow\.


---

### 922. msg_26716

**You** - 2025-06-25T16:50:30

and Bank is easy


---

### 923. msg_26717

**You** - 2025-06-25T16:50:58

Reaction: 😂 from Meredith Lamb
before the call\.\. have one glass of wine\.\.


---

### 924. msg_26718

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:50:59

I will feel better when we can hang out :\)


---

### 925. msg_26719

**You** - 2025-06-25T16:51:00

to calm down


---

### 926. msg_26720

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:51:11

>
It’s at 11\.30


---

### 927. msg_26721

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:51:14

lol


---

### 928. msg_26722

**You** - 2025-06-25T16:51:15

>
I am really really looking forward to this weekend\.


---

### 929. msg_26723

**You** - 2025-06-25T16:51:22

>
no with the owner tonight


---

### 930. msg_26724

**You** - 2025-06-25T16:51:26

not the mediator


---

### 931. msg_26725

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:51:55

Oh going back to the place to meet the owner


---

### 932. msg_26726

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:52:01

Probably bring Mac this time


---

### 933. msg_26727

**You** - 2025-06-25T16:52:20

ah ok\.\. well your job is uber secure\.\. and you have the cash to do 1/4 of the year\.\.


---

### 934. msg_26728

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:52:26

I told her to dress preppy and not slutty


---

### 935. msg_26729

**You** - 2025-06-25T16:52:28

Is Andrew being a dick about the cash down\.


---

### 936. msg_26730

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:52:36

No


---

### 937. msg_26731

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:52:45

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 16:52:54 \-0400
|
| He doesn’t like the no pet thing
|
| Version: 1
| Sent: Wed, 25 Jun 2025 16:52:45 \-0400
|
| He doesn’t like the nonpersons


---

### 938. msg_26732

**You** - 2025-06-25T16:52:51

?


---

### 939. msg_26733

**You** - 2025-06-25T16:52:55

ah


---

### 940. msg_26734

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:53:05

But it isn’t even full time


---

### 941. msg_26735

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:53:12

So Dennis said don’t mention it


---

### 942. msg_26736

**You** - 2025-06-25T16:53:48

yeah I wouldn't and if they do ask, you can suggest that you might have your pets visit every once in a while\.\. but you would sign a waiver to cover any damages which I think you already do anyways\.


---

### 943. msg_26737

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:54:57

Yeah


---

### 944. msg_26738

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T16:55:12

My mom is making me take pix


---

### 945. msg_26739

**You** - 2025-06-25T16:55:26

kk send them to me please\.\. at least the ones with you in them you owe me\.


---

### 946. msg_26740

**You** - 2025-06-25T16:55:27

Love you\.


---

### 947. msg_26741

**You** - 2025-06-25T16:55:41

❤️


---

### 948. msg_26742

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:02:07

You don’t want\. Family photo


---

### 949. msg_26743

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:02:14

Sucky photo


---

### 950. msg_26744

**You** - 2025-06-25T17:02:41

kk


---

### 951. msg_26745

**You** - 2025-06-25T17:03:00

totally understand you wouldn't want a photo with J in it I am sure\.\. :\)


---

### 952. msg_26746

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:05:00

Nope don’t want those


---

### 953. msg_26747

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:05:07

You are 100% correct


---

### 954. msg_26748

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:05:09

lol


---

### 955. msg_26749

**You** - 2025-06-25T17:05:32

well I don't have anything decent to share with you\.\. so I guess we are shit outta luck\.


---

### 956. msg_26750

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:06:44

Reaction: ❤️ from Scott Hicks
We can take photos together this weekend lol


---

### 957. msg_26751

**You** - 2025-06-25T17:07:01

I would love to\.


---

### 958. msg_26752

**You** - 2025-06-25T17:07:07

and i hate having my pic taken


---

### 959. msg_26753

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T17:07:30

Pretty sure it is safe on my phone but likely not yours


---

### 960. msg_26754

**You** - 2025-06-25T17:07:46

yeah my photos are local\.\.


---

### 961. msg_26755

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:02:50

You never told me how therapy went


---

### 962. msg_26756

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:02:59

I thought you weren’t going to go anymore


---

### 963. msg_26757

**You** - 2025-06-25T18:02:59

it was short\.


---

### 964. msg_26758

**You** - 2025-06-25T18:03:06

and then I cancelled the rest for now


---

### 965. msg_26759

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:03:17

How long is short?


---

### 966. msg_26760

**You** - 2025-06-25T18:03:19

I told him about the weekend\.\. specifically about meeting the parents


---

### 967. msg_26761

**You** - 2025-06-25T18:03:28

I talked a bit about the fights with J and Gracie\.\.


---

### 968. msg_26762

**You** - 2025-06-25T18:03:46

that was basically it\.\. he didn't have a lot to say\.\. was a waste of time\.


---

### 969. msg_26763

**You** - 2025-06-25T18:03:50

thus me cancelling the rest\.


---

### 970. msg_26764

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:04:10

Interesting \- well maybe that is good news


---

### 971. msg_26765

**You** - 2025-06-25T18:05:24

I already told you the good news for me, the slightly less good news for you, is that I am back in control of all of my emotions\.\. so not as needy\.\. but still so much love it hurts\.\. so nothing to worry about lol\.\. still got the constant absence ache\.\. I just hide it better\.


---

### 972. msg_26766

**You** - 2025-06-25T18:05:45

I think you like being able to read me\.\. that won't be as easy but I will still have cranky moments etc\.\. just like you\.


---

### 973. msg_26767

**You** - 2025-06-25T18:06:44

I am still apprehensive and nervous about some things, still have self doubts and insecurities


---

### 974. msg_26768

**You** - 2025-06-25T18:07:05

I still feel fear for the future\.\. lol so I am still me\.\. but just better control


---

### 975. msg_26769

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:07:38

I am happy about that… it is good for me too lol I don’t want you feeling in turmoil\. Believe it or not lol


---

### 976. msg_26770

**You** - 2025-06-25T18:07:50

I mean again\.\.\.\. lol distinction


---

### 977. msg_26771

**You** - 2025-06-25T18:07:54

I feel it\.\. but I control it\.


---

### 978. msg_26772

**You** - 2025-06-25T18:08:10

it doesn't control me\.\. so at least there is that


---

### 979. msg_26773

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:08:52

Now you can get some work done again … who are you hiring?


---

### 980. msg_26774

**You** - 2025-06-25T18:08:59

I cannot talk about that\.


---

### 981. msg_26775

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:09:07

lol


---

### 982. msg_26776

**You** - 2025-06-25T18:09:10

Nice try


---

### 983. msg_26777

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:10:02

I will have to get you drunk


---

### 984. msg_26778

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:10:09

Then ask


---

### 985. msg_26779

**You** - 2025-06-25T18:10:52

won't tell you that drunk\.\.


---

### 986. msg_26780

**You** - 2025-06-25T18:10:56

I might tell you other things


---

### 987. msg_26781

**You** - 2025-06-25T18:11:04

I already agreed to get drunk\.\.


---

### 988. msg_26782

**You** - 2025-06-25T18:11:24

but I mean\.\. here is how I KNOW it will go\.


---

### 989. msg_26783

**You** - 2025-06-25T18:11:39

you will have the intent to get me drunk and then take advantage and ask questions etc\.\. and then other stuff


---

### 990. msg_26784

**You** - 2025-06-25T18:11:41

but


---

### 991. msg_26785

**You** - 2025-06-25T18:11:44

what will happen


---

### 992. msg_26786

**You** - 2025-06-25T18:11:50

is that you will just get drunker than me\.


---

### 993. msg_26787

**You** - 2025-06-25T18:11:53

and it won't work


---

### 994. msg_26788

**You** - 2025-06-25T18:11:54

lol


---

### 995. msg_26789

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:11:57

lol


---

### 996. msg_26790

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:12:08

Reaction: ❤️ from Scott Hicks
Touché


---

### 997. msg_26791

**You** - 2025-06-25T18:12:31

I mean I do drink fast\.\.  I could put some effort into it\.


---

### 998. msg_26792

**You** - 2025-06-25T18:12:39

get out ahead of you at least


---

### 999. msg_26793

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:13:35

You do drink fast\.


---

### 1000. msg_26794

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T18:14:07

K, gotta go meet this owner with Mac\. Will ttyl ❤️


---

### 1001. msg_26795

**You** - 2025-06-25T18:14:24

>
good luck ❤️


---

### 1002. msg_26796

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T19:13:05

Done\. That was interesting\. Young engaged couple


---

### 1003. msg_26797

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T19:13:44

Will be interested to see what happens\. They tried to sell the house in Dec but it didn’t sell and market is too bad now


---

### 1004. msg_26798

**You** - 2025-06-25T19:31:39

Any thoughts on where you will land?


---

### 1005. msg_26799

**You** - 2025-06-25T19:32:31

Oh it looks like Gracie is going to try to stay through until September\.  It is going to piss off maddie immensely and fuck up my world but I told Jaimie there will be rules\. Or she goes home\.


---

### 1006. msg_26800

**You** - 2025-06-25T19:32:38

Still I am really pissed


---

### 1007. msg_26801

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T19:34:30

Oh yikes, hopefully it doesn’t go too badly


---

### 1008. msg_26802

**You** - 2025-06-25T19:55:25

It will be a fucking disaster


---

### 1009. msg_26803

**You** - 2025-06-25T19:55:35

It is Gracie


---

### 1010. msg_26804

**You** - 2025-06-25T19:55:49

I wrote the rules and sent to j I am not moving on it\.


---

### 1011. msg_26805

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T19:59:21

You should make her sign a contract


---

### 1012. msg_26806

**You** - 2025-06-25T19:59:40

It wouldn’t matter


---

### 1013. msg_26807

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T19:59:40

Reaction: 👍 from Scott Hicks
Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 19:59:56 \-0400
|
| Looks like I got the house, but obviously it won’t be done until everything is all fine then I provide the money and all that stuff so still lots to do
|
| Version: 1
| Sent: Wed, 25 Jun 2025 19:59:40 \-0400
|
| At the house, but obviously it won’t be done until everything is all fine then I provide the money and all that stuff so still lots to do


---

### 1014. msg_26808

**You** - 2025-06-25T19:59:58

J has to review everything with maddie then Gracie


---

### 1015. msg_26809

**You** - 2025-06-25T20:00:00

Then we discuss


---

### 1016. msg_26810

**You** - 2025-06-25T20:00:19

>
Wow congrats


---

### 1017. msg_26811

**You** - 2025-06-25T20:00:22

That was fast


---

### 1018. msg_26812

**You** - 2025-06-25T20:00:29

Apparently you impressed


---

### 1019. msg_26813

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:00:54

Probably McKenzie because she dressed preppy instead of slutty


---

### 1020. msg_26814

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:01:00

Jk


---

### 1021. msg_26815

**You** - 2025-06-25T20:01:09

lol


---

### 1022. msg_26816

**You** - 2025-06-25T20:01:18

Oh don’t forget your passport


---

### 1023. msg_26817

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:01:36

I know I actually have a to do list and that is on it because my passport is currently in the Buick


---

### 1024. msg_26818

**You** - 2025-06-25T20:01:59



---

### 1025. msg_26819

**You** - 2025-06-25T20:02:10

Eesh


---

### 1026. msg_26820

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:21:56

Andrew is all upset the lease starts July 1


---

### 1027. msg_26821

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:22:44

I’m like “we need to not be living together”


---

### 1028. msg_26822

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:22:58

It’s driving me crazy


---

### 1029. msg_26823

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:23:02

He seems fine


---

### 1030. msg_26824

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:23:04

wtf


---

### 1031. msg_26825

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:23:13

How do I even discuss that


---

### 1032. msg_26826

**You** - 2025-06-25T20:24:38

He went from upset to fine


---

### 1033. msg_26827

**You** - 2025-06-25T20:24:54

Confused in reading this lol


---

### 1034. msg_26828

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:25:26

He just thinks I should have a plan to move before I rent


---

### 1035. msg_26829

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:25:47

I said all I need is a mattress and a suitcase


---

### 1036. msg_26830

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:25:51

Honestly


---

### 1037. msg_26831

**You** - 2025-06-25T20:26:34

lol


---

### 1038. msg_26832

**You** - 2025-06-25T20:26:41

Man drama


---

### 1039. msg_26833

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:29:21

Yeah and it is a small place so I won’t even need much tbh


---

### 1040. msg_26834

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:30:47

The whole moving thing is kind of hitting me though like mentally


---

### 1041. msg_26835

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:31:07

You are going to have to be extra nice to me this weekend lol


---

### 1042. msg_26836

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:31:27

I look at the backyard here or the dogs or Marlowe’s room and I’m like, ugh shit


---

### 1043. msg_26837

**You** - 2025-06-25T20:33:31

Reaction: ❤️ from Meredith Lamb
>
We will have to be nice to each other I think lol


---

### 1044. msg_26838

**You** - 2025-06-25T20:33:37

Extra extra nice


---

### 1045. msg_26839

**You** - 2025-06-25T20:34:15

I have already told you I am all about being super nice


---

### 1046. msg_26840

**You** - 2025-06-25T20:34:41

Actually I am going to turn the tables on you


---

### 1047. msg_26841

**You** - 2025-06-25T20:34:43

Hahaha


---

### 1048. msg_26842

**You** - 2025-06-25T20:34:49

I just had a great idea


---

### 1049. msg_26843

**You** - 2025-06-25T20:34:57

Not telling you either


---

### 1050. msg_26844

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:35:09

So confused


---

### 1051. msg_26845

**You** - 2025-06-25T20:35:20

It might involve getting you drunk and asking you things


---

### 1052. msg_26846

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:35:36

That would likely not go well for you remember


---

### 1053. msg_26847

**You** - 2025-06-25T20:35:48

You don’t know the questions I am going to ask


---

### 1054. msg_26848

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:35:57

I can speculate


---

### 1055. msg_26849

**You** - 2025-06-25T20:36:20

And you still think it would be bad\.\. errrr ok 😞 scratch that\.


---

### 1056. msg_26850

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:36:58

No not for any particular reason


---

### 1057. msg_26851

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:37:06

Other than it has gone poorly before


---

### 1058. msg_26852

**You** - 2025-06-25T20:37:17

lol I will just not\.\. easier\.


---

### 1059. msg_26853

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:37:26

Haha


---

### 1060. msg_26854

**You** - 2025-06-25T20:37:37

Was a fun idea maybe not so fun in reality


---

### 1061. msg_26855

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:37:53

Just ask me after like 3\-4 glasses but no more than that


---

### 1062. msg_26856

**You** - 2025-06-25T20:38:30

Nope


---

### 1063. msg_26857

**You** - 2025-06-25T20:38:53

We good \- like you said should have learned my lesson


---

### 1064. msg_26858

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:39:00

I shouldn’t get very drunk anyways bc we have stuff to do


---

### 1065. msg_26859

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:39:27

I think I’m going to have to set up utilities and insurance on Friday likely


---

### 1066. msg_26860

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:39:34

Lots of phone calls\. Gah


---

### 1067. msg_26861

**You** - 2025-06-25T20:39:57

Well you will have lots of peace
And quiet


---

### 1068. msg_26862

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:41:20

Except for 11\.30\-1\.30 :p


---

### 1069. msg_26863

**You** - 2025-06-25T20:42:01

Yep gonna be fun\!\!\!\!


---

### 1070. msg_26864

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:50:24

So I forget what sept 15 was… remind me


---

### 1071. msg_26865

**You** - 2025-06-25T20:52:35

When you sign your agreement


---

### 1072. msg_26866

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:54:09

No chance


---

### 1073. msg_26867

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T20:54:14

Will be way earlier


---

### 1074. msg_26868

**You** - 2025-06-25T20:55:36

Yep now I think it will\. But I still don’t want you to settle


---

### 1075. msg_26869

**You** - 2025-06-25T20:55:50

Now sept 15 will be the new day we check to see if I am still sane


---

### 1076. msg_26870

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:03:54

Aw no ugh


---

### 1077. msg_26871

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:04:38

I will keep you sane don’t worry


---

### 1078. msg_26872

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:04:54

I mean, as best I can lol


---

### 1079. msg_26873

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:05:00

From a distance lol


---

### 1080. msg_26874

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:05:09

😝


---

### 1081. msg_26875

**You** - 2025-06-25T21:06:39

Mmm hmm that has proven to be very effective thus far… lol


---

### 1082. msg_26876

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:08:01

Totally\. This whole situation is amazing\.


---

### 1083. msg_26877

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:08:13

Easy breezy


---

### 1084. msg_26878

**You** - 2025-06-25T21:12:51

Yep it’s all turning up snake eyes\!\!


---

### 1085. msg_26879

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:17:00

Except this weekend\. Then back to snake eyes\.


---

### 1086. msg_26880

**You** - 2025-06-25T21:33:09

Edited: 2 versions
| Version: 2
| Sent: Wed, 25 Jun 2025 21:33:19 \-0400
|
| Ok I am going to bed
|
| Version: 1
| Sent: Wed, 25 Jun 2025 21:33:09 \-0400
|
| I I am going to bed


---

### 1087. msg_26881

**Meredith Lamb \(\+14169386001\)** - 2025-06-25T21:33:46

k, I am soon\. Love you ❤️❤️


---

### 1088. msg_26882

**You** - 2025-06-25T21:33:58

Love you too ❤️


---

### 1089. msg_26883

**You** - 2025-06-26T03:29:36

Morning love I didn’t have the best sleep not sure why… too many thoughts swirling last night I guess\.  Going to stop off at lifetime because I got up early enough for a sauna to relax because I am pretty stressed out tbh\.\. then on the road\.  Hope you have a good morning and that all your prep for Maelle runs smoothly\.  Xo


---

### 1090. msg_26884

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:34:25

G’morn \- I haven’t been sleeping the greatest the last few nights either\. So many things\. Hope the drive is ok\. ❤️ Just getting up to workout\. Coffee first\.


---

### 1091. msg_26885

**You** - 2025-06-26T06:37:30

I have been talking to ChatGPT while I have been driving\. Nice to
Have a friend to keep me company


---

### 1092. msg_26886

**You** - 2025-06-26T06:37:52

At London now


---

### 1093. msg_26887

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:38:04

What have you been talking about? Lol


---

### 1094. msg_26888

**You** - 2025-06-26T06:38:13

This and that


---

### 1095. msg_26889

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:38:25

Haha k


---

### 1096. msg_26890

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:38:34

I like to listen to music when I drive


---

### 1097. msg_26891

**You** - 2025-06-26T06:38:49

So do I but I felt like chatting


---

### 1098. msg_26892

**You** - 2025-06-26T06:39:37

It gave me some advice we discussed in depth for like 25 mins


---

### 1099. msg_26893

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:40:23

Advice for Gracie?


---

### 1100. msg_26894

**You** - 2025-06-26T06:40:27

No


---

### 1101. msg_26895

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:41:04

I feel like you don’t need advice on anything else


---

### 1102. msg_26896

**You** - 2025-06-26T06:41:36

Just you\. And some on myself


---

### 1103. msg_26897

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:42:14

You need advice on me? Nooooo


---

### 1104. msg_26898

**You** - 2025-06-26T06:42:22

Always


---

### 1105. msg_26899

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:42:31

I think you have things covered right now\. You think too much


---

### 1106. msg_26900

**You** - 2025-06-26T06:42:48

Yeah that may be true\.\. but still\.


---

### 1107. msg_26901

**You** - 2025-06-26T06:43:20

Anyway go enjoy your coffee and workout


---

### 1108. msg_26902

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:43:32

You are going to be so tired tonight omg 3am wake


---

### 1109. msg_26903

**You** - 2025-06-26T06:43:47

I had 6 hours almost


---

### 1110. msg_26904

**You** - 2025-06-26T06:43:53

More than fine I woke up on my own


---

### 1111. msg_26905

**You** - 2025-06-26T06:44:00

Couldn’t get back


---

### 1112. msg_26906

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:44:24

Crazy


---

### 1113. msg_26907

**You** - 2025-06-26T06:44:45

Meh you will be more tired than me guaranteed


---

### 1114. msg_26908

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T06:45:34

lol true


---

### 1115. msg_26909

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:10:22


*1 attachment(s)*


---

### 1116. msg_26910

**You** - 2025-06-26T07:11:42

🙄


---

### 1117. msg_26911

**You** - 2025-06-26T07:11:56

That is weird and creepy


---

### 1118. msg_26912

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:12:31

It is just the way he rolls\. Always says I’m wrong and then I talk to him this morning and oh it is super helpful that I get out


---

### 1119. msg_26913

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:12:33

Like wtf


---

### 1120. msg_26914

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:12:38

So stupid


---

### 1121. msg_26915

**You** - 2025-06-26T07:13:07

Yep\.\. quite stuoid


---

### 1122. msg_26916

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:13:17

Also, Maelle got to see the house before she goes away for a month


---

### 1123. msg_26917

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:13:33

She feels good about it\. Can rest easy for a month with some certainty


---

### 1124. msg_26918

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:13:41

He’s like “I guess”


---

### 1125. msg_26919

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:13:45

😵‍💫


---

### 1126. msg_26920

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:13:51

I need out of here\.


---

### 1127. msg_26921

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:13:52

Omg


---

### 1128. msg_26922

**You** - 2025-06-26T07:13:59

Yeah I know


---

### 1129. msg_26923

**You** - 2025-06-26T07:14:01

Peace


---

### 1130. msg_26924

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:14:20

I think he’s just scared of having me gone


---

### 1131. msg_26925

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:14:29

But I’m going to be close by so I don’t get it fully


---

### 1132. msg_26926

**You** - 2025-06-26T07:14:43

Well it is managing the house


---

### 1133. msg_26927

**You** - 2025-06-26T07:14:47

And the kids


---

### 1134. msg_26928

**You** - 2025-06-26T07:14:54

He is not prepared


---

### 1135. msg_26929

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:15:09

Yeah and he just started a new job and doing the Reno\. It is a lot


---

### 1136. msg_26930

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:15:15

All while depressed


---

### 1137. msg_26931

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:15:22

And in denial about his depression


---

### 1138. msg_26932

**You** - 2025-06-26T07:15:42

Is this something you have seen before


---

### 1139. msg_26933

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:16:02

No


---

### 1140. msg_26934

**You** - 2025-06-26T07:16:05

I mean you are dealing with\. But of depression too right?


---

### 1141. msg_26935

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:16:30

No he has had it easy so no depression like this before that I’ve seen


---

### 1142. msg_26936

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:16:33

First time


---

### 1143. msg_26937

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:16:37

But he won’t admit it


---

### 1144. msg_26938

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:16:45

He’s not good at being self aware


---

### 1145. msg_26939

**You** - 2025-06-26T07:16:49

Hnmm


---

### 1146. msg_26940

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:16:58

He will be better when I leave


---

### 1147. msg_26941

**You** - 2025-06-26T07:17:02

I don’t have a lot of experience muse


---

### 1148. msg_26942

**You** - 2025-06-26T07:17:05

Myself


---

### 1149. msg_26943

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:17:08

I think it is partly anxiety about being alone


---

### 1150. msg_26944

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:17:13

He hates being alone


---

### 1151. msg_26945

**You** - 2025-06-26T07:17:50

Mmmm I like\. Being alone but I like you way more apparently lol


---

### 1152. msg_26946

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:18:17

I like being alone too\. Always was a problem with he and I


---

### 1153. msg_26947

**You** - 2025-06-26T07:18:32

Same with j\.


---

### 1154. msg_26948

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:18:37

Anyway I have seen the delaying from him before\. He always needs to be pushed down that is no different


---

### 1155. msg_26949

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:18:54

I can’t have Julian and cassy backing out or we are fucked


---

### 1156. msg_26950

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:19:02

So he needs to get moving


---

### 1157. msg_26951

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:19:08

This will help


---

### 1158. msg_26952

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:19:20

They will be SUPER happy by this July 1 news


---

### 1159. msg_26953

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:19:23

So will his mom


---

### 1160. msg_26954

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:19:30

He’s the only ass about it I’m sure


---

### 1161. msg_26955

**You** - 2025-06-26T07:19:58

Well I mean good news for all then


---

### 1162. msg_26956

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:20:56

Oh this morning he said “so I suppose you are going to want child support payment right away”


---

### 1163. msg_26957

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:21:01

🙄


---

### 1164. msg_26958

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:21:09

I was like no it is fine fuck off


---

### 1165. msg_26959

**You** - 2025-06-26T07:21:18

Jesus


---

### 1166. msg_26960

**You** - 2025-06-26T07:21:56

I mean I am thinking about how I can afford to carry Jaimie and myself through this\.\. his approach slightly different


---

### 1167. msg_26961

**You** - 2025-06-26T07:22:09

Dumbass


---

### 1168. msg_26962

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:25:28

>
Are you super stressed about it?


---

### 1169. msg_26963

**You** - 2025-06-26T07:26:38

Reaction: 😮 from Meredith Lamb
It is a lot to carry I am paying for a lot outside of the agreement half for the lawyer fees and land transfer for new home half for down payment half for furniture paying for all the phones and the plans


---

### 1170. msg_26964

**You** - 2025-06-26T07:26:45

Not forever


---

### 1171. msg_26965

**You** - 2025-06-26T07:27:02

But it will be tight for a bit I am\. Not worrried


---

### 1172. msg_26966

**You** - 2025-06-26T07:27:13

More important to get a good sale price for the home


---

### 1173. msg_26967

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:32:03

That is a lot outside of the agreement


---

### 1174. msg_26968

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:32:16

Andrew would never


---

### 1175. msg_26969

**You** - 2025-06-26T07:32:30

It’s fine


---

### 1176. msg_26970

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:32:32

He isn’t even going to help me set up insurance even tho he works at intact


---

### 1177. msg_26971

**You** - 2025-06-26T07:32:42

I am low sssg


---

### 1178. msg_26972

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:32:42

My mom was like huh?


---

### 1179. msg_26973

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:33:06

sssg?


---

### 1180. msg_26974

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:33:08

lol


---

### 1181. msg_26975

**You** - 2025-06-26T07:33:13

Reaction: 👍 from Meredith Lamb
Ssag


---

### 1182. msg_26976

**You** - 2025-06-26T07:33:33

For lump


---

### 1183. msg_26977

**You** - 2025-06-26T07:33:47

Well thatbisnwhat it says but I don’t agree


---

### 1184. msg_26978

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:34:46

Ah I see, k


---

### 1185. msg_26979

**You** - 2025-06-26T07:35:04

What help do you need with insurance like help get you a good rate


---

### 1186. msg_26980

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:35:19

Yeah employee discount lol


---

### 1187. msg_26981

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:35:29

But whatever don’t care


---

### 1188. msg_26982

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:35:35

Not a big deal


---

### 1189. msg_26983

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:35:46

But I would help him if tables were reversed


---

### 1190. msg_26984

**You** - 2025-06-26T07:35:55

Yeah shitty love


---

### 1191. msg_26985

**You** - 2025-06-26T07:36:00

Move


---

### 1192. msg_26986

**You** - 2025-06-26T07:36:04

We have discount


---

### 1193. msg_26987

**You** - 2025-06-26T07:36:10

With cooperators


---

### 1194. msg_26988

**You** - 2025-06-26T07:36:15

Prolly not as good


---

### 1195. msg_26989

**You** - 2025-06-26T07:36:28

I use my mba discount with Ted


---

### 1196. msg_26990

**You** - 2025-06-26T07:36:31

Td


---

### 1197. msg_26991

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:37:06

I will figure it all out\. Just funny what an ass he is


---

### 1198. msg_26992

**You** - 2025-06-26T07:37:13

Yep


---

### 1199. msg_26993

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:37:15

He’s just mad and sad and all that


---

### 1200. msg_26994

**You** - 2025-06-26T07:37:47

Ego


---

### 1201. msg_26995

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T07:39:02


*1 attachment(s)*


---

### 1202. msg_26996

**You** - 2025-06-26T07:42:14

That was nice of her 🙂


---

### 1203. msg_26997

**You** - 2025-06-26T07:42:23

Nice for him to get something


---

### 1204. msg_26998

**You** - 2025-06-26T07:43:04

Reaction: 👍 from Meredith Lamb
Just got to the office


---

### 1205. msg_26999

**You** - 2025-06-26T07:43:07

Made good time


---

### 1206. msg_27000

**You** - 2025-06-26T08:21:53

Ahhh chatham so homey


---

### 1207. msg_27001

**You** - 2025-06-26T08:22:02

Where did you sit btw


---

### 1208. msg_27002

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:22:13

2nd floor\!


---

### 1209. msg_27003

**You** - 2025-06-26T08:22:20

In the new or old


---

### 1210. msg_27004

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:22:29

Old


---

### 1211. msg_27005

**You** - 2025-06-26T08:22:35

Hmm I might walk down


---

### 1212. msg_27006

**You** - 2025-06-26T08:22:43

Curious


---

### 1213. msg_27007

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:22:47

I looked out the window to the Wendy’s at the time


---

### 1214. msg_27008

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:22:54

Not sure what is on that corner now


---

### 1215. msg_27009

**You** - 2025-06-26T08:22:57

Good old days


---

### 1216. msg_27010

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:22:59

Not Wendy’s anymore


---

### 1217. msg_27011

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:23:13

Are we moving to Chatham? lol


---

### 1218. msg_27012

**You** - 2025-06-26T08:23:22

I would


---

### 1219. msg_27013

**You** - 2025-06-26T08:23:29

In a second


---

### 1220. msg_27014

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:23:53

I would also but not while my kids are this young … they would hate it


---

### 1221. msg_27015

**You** - 2025-06-26T08:23:58

Can’t really walk around would look weird just got down here


---

### 1222. msg_27016

**You** - 2025-06-26T08:24:11

Perhaps later


---

### 1223. msg_27017

**You** - 2025-06-26T08:24:30

Perhaps later
We
Could consider it


---

### 1224. msg_27018

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:25:04

My friends would be ecstatic


---

### 1225. msg_27019

**You** - 2025-06-26T08:26:00

I would def be happier


---

### 1226. msg_27020

**You** - 2025-06-26T08:26:07

And it would be much more affordable


---

### 1227. msg_27021

**You** - 2025-06-26T08:26:22

Spend our money on adventures instead of housing


---

### 1228. msg_27022

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:26:26


*1 attachment(s)*


---

### 1229. msg_27023

**You** - 2025-06-26T08:26:46

Mmmmmhmm


---

### 1230. msg_27024

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:26:59

Showed them the new place


---

### 1231. msg_27025

**You** - 2025-06-26T08:28:06

Cool it is a really nice place tbh… but I bet no boys over is a rule too 😩


---

### 1232. msg_27026

**You** - 2025-06-26T08:28:09

lol


---

### 1233. msg_27027

**You** - 2025-06-26T08:28:15

Not for a good while


---

### 1234. msg_27028

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:29:32

Kim lives on a farm in Appin\. So small no population listed really\. Lol


---

### 1235. msg_27029

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:29:43

>
What why?


---

### 1236. msg_27030

**You** - 2025-06-26T08:29:50

How far is glencoe from chatham?


---

### 1237. msg_27031

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:29:53

I will have children half the time


---

### 1238. msg_27032

**You** - 2025-06-26T08:30:16

>
Jk really but not until after singing agreement and only after
Andrew knows I think


---

### 1239. msg_27033

**You** - 2025-06-26T08:30:23

Would hate to have him show up


---

### 1240. msg_27034

**You** - 2025-06-26T08:30:34

Well that too


---

### 1241. msg_27035

**You** - 2025-06-26T08:30:40

Cannot be there with kids


---

### 1242. msg_27036

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:30:49

>
45 minutes unless you get behind a bus or tractor then it could be closer to an hour\. You drive on highway 2 and it mostly has a solid line, no passing because it is a windy highway through fields\.


---

### 1243. msg_27037

**You** - 2025-06-26T08:30:59

Hmm not bad at all


---

### 1244. msg_27038

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:31:01

\(School bus\)


---

### 1245. msg_27039

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:31:16

No it is an easy 45 min\. Not like city 45 min


---

### 1246. msg_27040

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:31:19

Beautiful drive


---

### 1247. msg_27041

**You** - 2025-06-26T08:31:27

I know it would be like home


---

### 1248. msg_27042

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:31:48

Reaction: ❤️ from Scott Hicks
Morning has beautiful views\. Misty over the fields in the fall


---

### 1249. msg_27043

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:31:53

It’s gorgeous


---

### 1250. msg_27044

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:31:58

Night is meh


---

### 1251. msg_27045

**You** - 2025-06-26T08:32:10

Other views at night


---

### 1252. msg_27046

**You** - 2025-06-26T08:32:16

Nicer


---

### 1253. msg_27047

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:32:40

If it is dark, it is just black\. No lights anywhere\. In the middle of nowhere lol


---

### 1254. msg_27048

**You** - 2025-06-26T08:32:48

Perfect


---

### 1255. msg_27049

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:32:56

I used to go to GoodLife after work so always went home in the dark a lot


---

### 1256. msg_27050

**You** - 2025-06-26T08:33:18

Something to consider down the road\.


---

### 1257. msg_27051

**You** - 2025-06-26T08:33:47

Reaction: 👍 from Meredith Lamb
Kk logging on to oc call\.


---

### 1258. msg_27052

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T08:35:27

https://flic\.kr/p/nGyJH
This was before going to work in Chatham one morning …\.


---

### 1259. msg_27053

**You** - 2025-06-26T08:36:18

Beautiful


---

### 1260. msg_27054

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T10:16:37

My lease is all official now\.


---

### 1261. msg_27055

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T10:16:49

Fully executed\.


---

### 1262. msg_27056

**You** - 2025-06-26T10:29:33

Nice grata\!\!


---

### 1263. msg_27057

**You** - 2025-06-26T10:29:42

I am heading to Mayes to see baby\.


---

### 1264. msg_27058

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T10:30:01

Oh cool \- have fun


---

### 1265. msg_27059

**You** - 2025-06-26T10:33:57

Oh yeah super fun


---

### 1266. msg_27060

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T10:34:12

lol


---

### 1267. msg_27061

**You** - 2025-06-26T10:34:17

ROFL


---

### 1268. msg_27062

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T10:38:25

I just set up all my banking and credit card fun fun one more thing done


---

### 1269. msg_27063

**You** - 2025-06-26T11:21:43

Wow just finished at Mayes heading to Windsor


---

### 1270. msg_27064

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:23:06

Edited: 2 versions
| Version: 2
| Sent: Thu, 26 Jun 2025 11:23:19 \-0400
|
| I’m off to do bank drafts, then lcbo for Mac and Liana, then I’m basically done all my errands for today\. Have to set up insurance utilities but can do tomorrow from hotel\.
|
| Version: 1
| Sent: Thu, 26 Jun 2025 11:23:06 \-0400
|
| I’m off to do bank drafts, then lcbo for Mac and Liana, then I’m basically done all my errands for today\. Have to def up insurance utilities but can do tomorrow from hotel\.


---

### 1271. msg_27065

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:23:37

I haven’t packed yet\. Been focusing on Maelle’s packing


---

### 1272. msg_27066

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:26:30


*1 attachment(s)*


---

### 1273. msg_27067

**You** - 2025-06-26T11:26:43

Kk we’ll just let me know when to expect you lol


---

### 1274. msg_27068

**You** - 2025-06-26T11:27:04

Then I will add an hour or two


---

### 1275. msg_27069

**You** - 2025-06-26T11:27:40

Interesting how long in Detroit


---

### 1276. msg_27070

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:27:52

Just until sat


---

### 1277. msg_27071

**You** - 2025-06-26T11:28:00

Ah shitty


---

### 1278. msg_27072

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:34:34

It might be too early to meet them anyway lol


---

### 1279. msg_27073

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:34:41

They would be with their kids


---

### 1280. msg_27074

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:34:51

Kids don’t know likely


---

### 1281. msg_27075

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:34:57

Seeing as how mine don’t lol


---

### 1282. msg_27076

**You** - 2025-06-26T11:37:13

True


---

### 1283. msg_27077

**You** - 2025-06-26T11:37:31

I am meeting enough new people this weekend too many according to Jim


---

### 1284. msg_27078

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:37:48

Yeah we are good\. We are going to be too social


---

### 1285. msg_27079

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:37:52

lol


---

### 1286. msg_27080

**You** - 2025-06-26T11:40:39

ROFL


---

### 1287. msg_27081

**You** - 2025-06-26T11:40:56

Idc I am just happy to be with you\.\. dun care doing what


---

### 1288. msg_27082

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:46:16

Oh no CIBC system down wtf


---

### 1289. msg_27083

**You** - 2025-06-26T11:46:58

Like everywhere?


---

### 1290. msg_27084

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:47:13

Not sure\. 3 ppl working on it right now


---

### 1291. msg_27085

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:47:17

Sigh


---

### 1292. msg_27086

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:47:25

I need to get this done today


---

### 1293. msg_27087

**You** - 2025-06-26T11:47:57

I got into my CIBC app


---

### 1294. msg_27088

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:48:18

I think it is something about bank drafts specifically


---

### 1295. msg_27089

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:48:29

It took my money but no draft


---

### 1296. msg_27090

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:48:31

lol


---

### 1297. msg_27091

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:48:34

Gahhhh


---

### 1298. msg_27092

**You** - 2025-06-26T11:48:52

There should be a fix


---

### 1299. msg_27093

**You** - 2025-06-26T11:48:56

Are you at bank


---

### 1300. msg_27094

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:49:07

Yup\-  they are working on it


---

### 1301. msg_27095

**You** - 2025-06-26T11:49:26

Well should be fine


---

### 1302. msg_27096

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:49:38

Yeah just eating my time


---

### 1303. msg_27097

**You** - 2025-06-26T11:50:11

Is maelle ready


---

### 1304. msg_27098

**You** - 2025-06-26T11:53:35

You don’t need to rush


---

### 1305. msg_27099

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:57:43

Omg I have to go to another branch


---

### 1306. msg_27100

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T11:57:55

So annoyed\. Everything is annoying right now\. lol


---

### 1307. msg_27101

**You** - 2025-06-26T11:58:08

Just be calm\.\. don’t rush


---

### 1308. msg_27102

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:21:34

This branch having issues too omg


---

### 1309. msg_27103

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:21:40

Hilarious


---

### 1310. msg_27104

**You** - 2025-06-26T12:22:00

Holy shit


---

### 1311. msg_27105

**You** - 2025-06-26T12:22:09

How the fuck this going to work


---

### 1312. msg_27106

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:23:00

🤷‍♀️


---

### 1313. msg_27107

**You** - 2025-06-26T12:23:28

Shit see you tomorrow lol


---

### 1314. msg_27108

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:23:53

If I ever get this draft I have to then go to TD


---

### 1315. msg_27109

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:23:57

honestly


---

### 1316. msg_27110

**You** - 2025-06-26T12:24:22

lol


---

### 1317. msg_27111

**You** - 2025-06-26T12:24:30

Tomorrow rollers


---

### 1318. msg_27112

**You** - 2025-06-26T12:36:42

😢


---

### 1319. msg_27113

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:37:43

I’m just stuck here waiting\. They made a mistake and aren’t sure how to fix it so are on hold calling someone\. Not my day 🤷‍♀️


---

### 1320. msg_27114

**You** - 2025-06-26T12:51:17

That sucks met


---

### 1321. msg_27115

**You** - 2025-06-26T12:51:21

Mer


---

### 1322. msg_27116

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:54:15

We are trying a wire now


---

### 1323. msg_27117

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:54:17

lol omg


---

### 1324. msg_27118

**You** - 2025-06-26T12:54:23

Jesus


---

### 1325. msg_27119

**You** - 2025-06-26T12:54:36

They should comp you something g for all this hassle


---

### 1326. msg_27120

**You** - 2025-06-26T12:54:39

What the fuck


---

### 1327. msg_27121

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:54:50

God like 2 hrs out of my day


---

### 1328. msg_27122

**You** - 2025-06-26T12:54:54

Yep\.\.


---

### 1329. msg_27123

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:55:03

They were going to get me to go to a 3rd branch lol


---

### 1330. msg_27124

**You** - 2025-06-26T12:55:07

Sorry I know it doesn’t help your nerves


---

### 1331. msg_27125

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:55:08

I’m like try a wire


---

### 1332. msg_27126

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T12:55:20

It costs extra but not much and worth my time


---

### 1333. msg_27127

**You** - 2025-06-26T12:59:32

Well they should cover those costs for shit


---

### 1334. msg_27128

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T13:04:24

Ok I’m done


---

### 1335. msg_27129

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T13:04:27

LCBO for Mac


---

### 1336. msg_27130

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T13:04:32

Then home omg


---

### 1337. msg_27131

**You** - 2025-06-26T13:08:01

Td bank?


---

### 1338. msg_27132

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T13:08:36

I don’t have to do that with a wire only if I did the bank draft


---

### 1339. msg_27133

**You** - 2025-06-26T13:15:19

Ah ok


---

### 1340. msg_27134

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T13:36:36

Omg I’m home\. F’ing day\. Thank god I took a vacation day\. Holy


---

### 1341. msg_27135

**You** - 2025-06-26T13:36:57

Yeah honestly shit day


---

### 1342. msg_27136

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T14:07:14

I just realized I don’t know where I’m going


---

### 1343. msg_27137

**You** - 2025-06-26T15:24:50

Hyatt


---

### 1344. msg_27138

**You** - 2025-06-26T15:39:58

You on road?


---

### 1345. msg_27139

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:40:19

Yes, but I haven’t decided yet whether to stop in London or not


---

### 1346. msg_27140

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:40:27

Does it matter what time I get there?


---

### 1347. msg_27141

**You** - 2025-06-26T15:40:38

Nope\.\.


---

### 1348. msg_27142

**You** - 2025-06-26T15:40:42

Well I mean


---

### 1349. msg_27143

**You** - 2025-06-26T15:40:52

I look forward to seeing you but you do you


---

### 1350. msg_27144

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:41:01

But when will you be there?


---

### 1351. msg_27145

**You** - 2025-06-26T15:41:07

I already told you tell me a time and I will add two hours


---

### 1352. msg_27146

**You** - 2025-06-26T15:41:15

I am going to Hyatt now


---

### 1353. msg_27147

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:41:18

I could be there as early as seven


---

### 1354. msg_27148

**You** - 2025-06-26T15:41:29

I am done for the day


---

### 1355. msg_27149

**You** - 2025-06-26T15:41:39

But if you want to stop you should


---

### 1356. msg_27150

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:41:57

No, I’m kind of tired\. I’ll just go there\.


---

### 1357. msg_27151

**You** - 2025-06-26T15:42:12

If you want to see your friends you should stop lol


---

### 1358. msg_27152

**You** - 2025-06-26T15:42:16

I will be here


---

### 1359. msg_27153

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:42:41

No, it would be for my niece Alayna her graduation is today


---

### 1360. msg_27154

**You** - 2025-06-26T15:42:53

Oh shit yeah I forgot isn’t your Kim there


---

### 1361. msg_27155

**You** - 2025-06-26T15:42:55

Mum


---

### 1362. msg_27156

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:43:32

Yeah, my parents are there and my mom has that card and money for Alayna from me so I don’t need to stop


---

### 1363. msg_27157

**You** - 2025-06-26T15:43:56

Kk


---

### 1364. msg_27158

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:46:39

Are you going out with Harris for dinner tonight?


---

### 1365. msg_27159

**You** - 2025-06-26T15:54:41

Nope


---

### 1366. msg_27160

**You** - 2025-06-26T15:54:48

Lunch was huge


---

### 1367. msg_27161

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:55:08

Oh, for some reason, I thought you would have dinner obligations tonight


---

### 1368. msg_27162

**You** - 2025-06-26T15:55:35

I was going to but I was like nope still full and he had Bball


---

### 1369. msg_27163

**You** - 2025-06-26T15:55:45

So we having lunch again tomorrow with a business partner


---

### 1370. msg_27164

**You** - 2025-06-26T15:57:40

I can find something to do if you need some alone time 🙂


---

### 1371. msg_27165

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T15:58:06

No no lol


---

### 1372. msg_27166

**You** - 2025-06-26T16:02:52

Need anything I am just out for a few mins


---

### 1373. msg_27167

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:03:14

Nope thanks


---

### 1374. msg_27168

**You** - 2025-06-26T16:05:08

Nothing no fruit or water or anything


---

### 1375. msg_27169

**You** - 2025-06-26T16:12:07

Getting wine


---

### 1376. msg_27170

**You** - 2025-06-26T16:12:18

Any pref Pinot or cab\.


---

### 1377. msg_27171

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:12:27

I actually got two bottles when I was getting McKenzie’s vodka


---

### 1378. msg_27172

**You** - 2025-06-26T16:12:45

lol so only need one bottle the\. Got it


---

### 1379. msg_27173

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:12:52

lol


---

### 1380. msg_27174

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:24:13

OK, I feel guilty so I’m just going to drop in to say congratulations to Alayna\. I will not be staying because she will need to leave for her actual graduation and they live right off the highway in London


---

### 1381. msg_27175

**You** - 2025-06-26T16:27:08

Kk


---

### 1382. msg_27176

**You** - 2025-06-26T16:27:14

All good


---

### 1383. msg_27177

**You** - 2025-06-26T16:27:31

Tell ur mom I miss her


---

### 1384. msg_27178

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:27:45

Yeah, OK


---

### 1385. msg_27179

**You** - 2025-06-26T16:28:04

lol


---

### 1386. msg_27180

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:43:31

Get to Woodstock and my body just relaxes… in the childhood area and it always feels so different than Toronto


---

### 1387. msg_27181

**You** - 2025-06-26T16:44:10

lol you can tour me around on Monday\.


---

### 1388. msg_27182

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T16:45:48

Tour all the fields?


---

### 1389. msg_27183

**You** - 2025-06-26T16:46:03

Wherever you want to go we go


---

### 1390. msg_27184

**You** - 2025-06-26T17:01:24

Ironic just ran into mark p in the liquor store


---

### 1391. msg_27185

**You** - 2025-06-26T17:01:28

Of all places


---

### 1392. msg_27186

**You** - 2025-06-26T17:07:13

He helped me pick a pinot


---

### 1393. msg_27187

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:07:36

lol


---

### 1394. msg_27188

**You** - 2025-06-26T17:07:51

He was coming back from Utah


---

### 1395. msg_27189

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:08:03

Prociw?


---

### 1396. msg_27190

**You** - 2025-06-26T17:08:05

Yep


---

### 1397. msg_27191

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:09:26

Did you tell him you’re drinking alone in your hotel room?


---

### 1398. msg_27192

**You** - 2025-06-26T17:11:08

Yep said I am trying to get into wine\.\. someone suggested Pinot but I don’t have a clue where to start


---

### 1399. msg_27193

**You** - 2025-06-26T17:11:15

Trust me I was convincing


---

### 1400. msg_27194

**You** - 2025-06-26T17:27:52

In hotel now room is nice\.


---

### 1401. msg_27195

**You** - 2025-06-26T17:33:23

Room is 514
You are on reservation key at desk for whenever you get in\.\. I may or may not be in room\.


---

### 1402. msg_27196

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:39:50

Reaction: ❤️ from Scott Hicks
My mom made us pose like this 🙄

*1 attachment(s)*


---

### 1403. msg_27197

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:48:33

I’m back on the road


---

### 1404. msg_27198

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:48:40

Sorry


---

### 1405. msg_27199

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:49:12

2080 Huron church road??


---

### 1406. msg_27200

**You** - 2025-06-26T17:50:19

Yep


---

### 1407. msg_27201

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T17:55:07

Added onto my time, but I feel better than I went\. Alayna appreciated it\.


---

### 1408. msg_27202

**You** - 2025-06-26T18:01:06

Reaction: 👍 from Meredith Lamb
Hope you remembered to get passport


---

### 1409. msg_27203

**You** - 2025-06-26T18:01:12

And I am glad
You stopped


---

### 1410. msg_27204

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T18:01:59

You should have a nap because I will be there until at least 730


---

### 1411. msg_27205

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T18:02:02

lol


---

### 1412. msg_27206

**You** - 2025-06-26T18:02:26

I am just getting into gym


---

### 1413. msg_27207

**You** - 2025-06-26T18:02:31

No napping


---

### 1414. msg_27208

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T18:02:54

lol eesh k


---

### 1415. msg_27209

**You** - 2025-06-26T18:07:47

They have a nice pool


---

### 1416. msg_27210

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T18:22:41

Johnny with his dad today awww lol

*1 attachment(s)*


---

### 1417. msg_27211

**You** - 2025-06-26T18:41:56

Oooooooopooh Johnny\!\!\!\!


---

### 1418. msg_27212

**You** - 2025-06-26T18:42:04

How is the drive


---

### 1419. msg_27213

**You** - 2025-06-26T18:51:16

Like 9 pm arrival?  If you give me a heads up I can order food


---

### 1420. msg_27214

**You** - 2025-06-26T18:56:40

Or if you aren’t hungry I might order myself something


---

### 1421. msg_27215

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:12:52

7\.30


---

### 1422. msg_27216

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:12:58

Ish


---

### 1423. msg_27217

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:13:02

lol


---

### 1424. msg_27218

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:13:13

Call at 7:45 just to be safe


---

### 1425. msg_27219

**You** - 2025-06-26T19:13:23

ROFL


---

### 1426. msg_27220

**You** - 2025-06-26T19:13:26

So 8:15


---

### 1427. msg_27221

**You** - 2025-06-26T19:13:39

Do you want food for when you get here


---

### 1428. msg_27222

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:14:08

Edited: 2 versions
| Version: 2
| Sent: Thu, 26 Jun 2025 19:14:21 \-0400
|
| Not really I was just gonna get like something snacky to have with some wine so like just go to shoppers or something on my way in
|
| Version: 1
| Sent: Thu, 26 Jun 2025 19:14:08 \-0400
|
| Not really I was just gonna get like something snack to have with some wine so like just go to shoppers or something on my way in


---

### 1429. msg_27223

**You** - 2025-06-26T19:14:51

Reaction: 😂 from Meredith Lamb
I got you bananas and smart pop


---

### 1430. msg_27224

**You** - 2025-06-26T19:15:15

But there is a restaurant downstairs prolly something small there let me go down and check menu


---

### 1431. msg_27225

**You** - 2025-06-26T19:21:59

Yeah they have a decent menu\. What food goes well with wine?  Chicken? Fingers??  lol I have no class


---

### 1432. msg_27226

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:22:33

Come on now I drink wine with anything


---

### 1433. msg_27227

**You** - 2025-06-26T19:22:35

Cheese pizza


---

### 1434. msg_27228

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:22:35

lol


---

### 1435. msg_27229

**You** - 2025-06-26T19:23:03

Or peperoni\.\. anyhow I will bring a menu up we can call down and order and pick
Up


---

### 1436. msg_27230

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:23:12

Just get what you want you’re probably way more hungry than I am


---

### 1437. msg_27231

**You** - 2025-06-26T19:23:30

Yeah I am a bit but I want to see what you want first maybe we can share


---

### 1438. msg_27232

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:23:55

Anything seriously


---

### 1439. msg_27233

**You** - 2025-06-26T19:24:11

Ok well I am not going to order until you are close or it will be cold


---

### 1440. msg_27234

**You** - 2025-06-26T19:25:25

I am going to start drinking my fireball


---

### 1441. msg_27235

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:30:46

Im at shoppers up the street


---

### 1442. msg_27236

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:31:00

Getting aleve


---

### 1443. msg_27237

**You** - 2025-06-26T19:31:39

Kk see you soon


---

### 1444. msg_27238

**Meredith Lamb \(\+14169386001\)** - 2025-06-26T19:39:05

Done so where do I go when I get there


---

### 1445. msg_27239

**You** - 2025-06-26T19:39:35

Park out front walk in to the front desk say you are Meredith in room 514 and need a key


---

### 1446. msg_27240

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T11:07:46

Enbridge and Toronto hydro done\. Must obtain coffee for 11\.30 lol won’t survive otherwise


---

### 1447. msg_27241

**You** - 2025-06-27T11:09:15

lol


---

### 1448. msg_27242

**You** - 2025-06-27T11:09:22

Just finished site visit


---

### 1449. msg_27243

**You** - 2025-06-27T11:09:24

Was fun


---

### 1450. msg_27244

**You** - 2025-06-27T11:16:08

Harris made me take a pic


---

### 1451. msg_27245

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T11:21:46

Let me see


---

### 1452. msg_27246

**You** - 2025-06-27T11:44:20

Image


---

### 1453. msg_27247

**You** - 2025-06-27T11:58:05


*1 attachment(s)*


---

### 1454. msg_27248

**You** - 2025-06-27T11:58:16

I look like a moron


---

### 1455. msg_27249

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T12:16:31

No you don’t\!


---

### 1456. msg_27250

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T12:16:38

Great pic


---

### 1457. msg_27251

**You** - 2025-06-27T12:27:02

Hope you doing ok


---

### 1458. msg_27252

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T12:30:02

Meh … tired lol


---

### 1459. msg_27253

**You** - 2025-06-27T12:31:07

Ok though not annoyed


---

### 1460. msg_27254

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T13:23:16

Done so going to do insurance now … then nap


---

### 1461. msg_27255

**You** - 2025-06-27T13:52:29

Kk


---

### 1462. msg_27256

**You** - 2025-06-27T15:59:18

Omw back now want me to stop and grab anything?


---

### 1463. msg_27257

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T16:09:59

Just getting up from napping lol had a very hard time settling \.\. just laid for hours


---

### 1464. msg_27258

**Meredith Lamb \(\+14169386001\)** - 2025-06-27T16:10:49

Can’t think of anything\.


---

### 1465. msg_27259

**You** - 2025-06-27T16:14:39

>
Sucks


---

