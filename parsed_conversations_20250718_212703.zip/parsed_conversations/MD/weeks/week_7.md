# Week 7: Conversation Messages

**Date Range:** 2025-05-25 to 2025-05-31  
**Total Messages:** 3039  
**Generated:** 2025-07-18 21:27:06

---

## 📊 Week Summary

- **Week Number:** 7
- **Messages:** 3039
- **Participants:** 2
- **Message Types:** outgoing, incoming, Effectively Non-committal (while she said "yes," the qualifier indicated she was not in a state to talk then)., call-history

## 💬 Conversation Messages

### 1. msg_13085

**You** - 2025-05-25T00:25:52

Jesus another Gracie meltdown j almost called cops\.


---

### 2. msg_13086

**You** - 2025-05-25T00:26:14

So tired cannot get this sorted fast enough


---

### 3. msg_13087

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:26:26

Oh no


---

### 4. msg_13088

**You** - 2025-05-25T00:26:31

Why are you still awake


---

### 5. msg_13089

**You** - 2025-05-25T00:26:46

This wax for tomorrow morning


---

### 6. msg_13090

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:26:49

Not sure\. Probably because I did nothing today


---

### 7. msg_13091

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:27:13

I am lying trying to sleep but no sleeping happening\.


---

### 8. msg_13092

**You** - 2025-05-25T00:27:14

Sigh I didn’t want to wake you up\.\. was just sharing


---

### 9. msg_13093

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:27:21

Was Gracie out and came home?


---

### 10. msg_13094

**You** - 2025-05-25T00:27:26

No


---

### 11. msg_13095

**You** - 2025-05-25T00:27:31

are you ok


---

### 12. msg_13096

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:27:40

Yeah I’m fine


---

### 13. msg_13097

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:27:52

Why’d the cops almost get called?


---

### 14. msg_13098

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:27:58

What’d she do


---

### 15. msg_13099

**You** - 2025-05-25T00:28:03

Hurting herself


---

### 16. msg_13100

**You** - 2025-05-25T00:28:07

Smashing shit


---

### 17. msg_13101

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:28:14

Oh man


---

### 18. msg_13102

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:28:50

How did it get resolved


---

### 19. msg_13103

**You** - 2025-05-25T00:29:09

Tired herself out


---

### 20. msg_13104

**You** - 2025-05-25T00:29:12

I think


---

### 21. msg_13105

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:29:33

Yikes


---

### 22. msg_13106

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:30:04

That sucks but she is probably really struggling extra with the separation and “stuff”


---

### 23. msg_13107

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:30:53

Just piles on


---

### 24. msg_13108

**You** - 2025-05-25T00:31:09

It is hard to see where nasty stops and mental health starts,, this fight started from not being able to get j give up her kindle


---

### 25. msg_13109

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T00:31:52

😵‍💫 doh \- that’s bad


---

### 26. msg_13110

**You** - 2025-05-25T00:32:01

Yep


---

### 27. msg_13111

**You** - 2025-05-25T00:36:10



---

### 28. msg_13112

**You** - 2025-05-25T00:37:52


*1 attachment(s)*


---

### 29. msg_13113

**You** - 2025-05-25T00:48:24


*1 attachment(s)*


---

### 30. msg_13114

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T08:29:01

Just got those now 🫠


---

### 31. msg_13115

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T09:27:42

So just for your mental peace of mind, I asked Andrew this morning if we talked a lot while I was messed up on fri night\. He said we talked about Maelle when we got home from work and I was already drunk\. He said we talked a bit later but he doesn’t even remember about what \(and he wasn’t drinking\)\. So it was very inconsequential…\.


---

### 32. msg_13116

**You** - 2025-05-25T09:53:30

I am glad you can put that to bed\.   At least you don’t have to wonder and worry\.


---

### 33. msg_13117

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:03:19

I mean I was 99% sure but I know you weren’t so thought I should ask\.


---

### 34. msg_13118

**You** - 2025-05-25T10:35:15

So I knew about the heart to heart with Andrew about maelle you mentioned that to me and explained  it\.  I knew maelle got home and you said something about the ring\. Then you said something about your mother thinking you were messed up\.  I told you a bunch of times to be careful, that people as
Messed up as you were then could make some really stupid decisions and not know it or remember it\.  When maelle got home you said “you need some of that” to me honestly I don’t think you actually thought you were talking to me at that point that was the last thing you said\.   So if Andrew suggests\. I nothing of consequence I guess you are good\.  I think as long as nothing he perceived as bad happened he should be fine\.


---

### 35. msg_13119

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:40:38

I think he is used to me\. If I said anything he isn’t sharing\. Also, he is not acting weird\.


---

### 36. msg_13120

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:41:02

You need some of that\. No idea what that meant\.


---

### 37. msg_13121

**You** - 2025-05-25T10:41:18

Yep no clue\.


---

### 38. msg_13122

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:49:23

Sorry talking to Mackenzie about her birthday


---

### 39. msg_13123

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:49:31

She wants to invite 2 more girls


---

### 40. msg_13124

**You** - 2025-05-25T10:49:42

Alright we can both remain clueless about that mysterious statement\. I am getting ready to go to gym\.\. maybe chat later\. Have fun with Mac\.


---

### 41. msg_13125

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:53:02

I tried to look back \(horrified\) and didn’t see it so can’t even speculate honestly\.


---

### 42. msg_13126

**You** - 2025-05-25T10:54:17

Doesn’t matter anyways\. Probably nothing\.


---

### 43. msg_13127

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:54:54

I feel like you think it was something\. I can guarantee you it was not\.


---

### 44. msg_13128

**You** - 2025-05-25T10:55:44

I don’t Mer all good\.  Just forget I mentioned anything not bringing anything up from that night again don’t worry\.


---

### 45. msg_13129

**You** - 2025-05-25T10:57:11



---

### 46. msg_13130

**You** - 2025-05-25T10:57:36

Just going to head out\.


---

### 47. msg_13131

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T10:59:47

Omg Marlowe says she took a video of me\. Gah\. She said bc Andrew was asleep she took it to show him\. She’s like “you were speaking gibberish” omg……\. Such a bad parent\.


---

### 48. msg_13132

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:01:05

Think I will take a break for a month or two 🙈


---

### 49. msg_13133

**You** - 2025-05-25T11:02:48

Don’t be too hard on yourself mer you are doing the best that you can\.  I am just going to drop all of this and not bring it up again\.\. I think you need to put it behind you but don’t let it change what you need to do to get by\.


---

### 50. msg_13134

**You** - 2025-05-25T11:04:11

I think not discussing it further might be helpful to you\.\. I don’t think you process
Stuff like this well anyways\. Kk so just move past it\.


---

### 51. msg_13135

**You** - 2025-05-25T11:05:20

I love you no matter what you know that right no matter what you do, silly stupid mistakes, any mistakes and all\.\. it is a package deal\.


---

### 52. msg_13136

**You** - 2025-05-25T11:06:55

My dealing with my own stuff is my own problem\.  Again I keep trying to tell you it is in my head and there is nothing that can be done about that except getting through this situation which will just take time, and my ability to deal with more of this as it comes up\.  So just relax ok\.


---

### 53. msg_13137

**You** - 2025-05-25T11:07:29

If we are in fact soul mates as I feel this shouldn’t be a problem right?


---

### 54. msg_13138

**You** - 2025-05-25T11:07:50



---

### 55. msg_13139

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:21:35

>
Right, but I do need to get my shit together\. I think it is time\. I’ve f\*cked off long enough probably\. Time to be an adult\.


---

### 56. msg_13140

**You** - 2025-05-25T11:23:43

I will support however you need me to\.


---

### 57. msg_13141

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:25:43

I know you will :\)


---

### 58. msg_13142

**You** - 2025-05-25T11:25:45

I don’t want you getting your shit together mean yku are miserable… what if the part of this that connected us was the carefree irresponsible side of you and the adult in you is more like what in the fuck am I doing right now\.  Anyhow I can’t worry about that already too much lol


---

### 59. msg_13143

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:26:25

Scott, I liked you even when I was responsible\.


---

### 60. msg_13144

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:26:28

lol


---

### 61. msg_13145

**You** - 2025-05-25T11:27:58

You liked the other me\.  But that’s fine will see how this goes\.\. like is said it might be better for me to bring the other me back for the next few months\.  I am looking for a therapist this afternoon that can help me disassociate\.\. specifically\.\. I think that would be hugely beneficial to be able to turn everything off for a bit\.


---

### 62. msg_13146

**You** - 2025-05-25T11:28:24

There has to be a way for me to do that\.


---

### 63. msg_13147

**You** - 2025-05-25T11:28:34

Maybe hypnosis or something


---

### 64. msg_13148

**You** - 2025-05-25T11:28:54

Open to trying anything at this point\.


---

### 65. msg_13149

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:29:27

Mac has some gummies that might do the trick\. 😜


---

### 66. msg_13150

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:30:51

>
There is no “other me”\. You are you with maybe different sides but it is still you\.


---

### 67. msg_13151

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:31:28

I think once I smarten up things might get easier\. My brain won’t be so fried and anxious\.


---

### 68. msg_13152

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:32:06

Going to plan my workouts for this week today based on my 2016 old stuff\.


---

### 69. msg_13153

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:32:27

No more gummies/thc\.


---

### 70. msg_13154

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:33:21

I missed marlowe’s beach vball tourn yday bc I was so sick


---

### 71. msg_13155

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:33:32

And didn’t go shopping with Mac\. Doing that shortly\.


---

### 72. msg_13156

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:33:42

Just let EVERYONE down including you…


---

### 73. msg_13157

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:33:48

Time to change


---

### 74. msg_13158

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:35:08

They won a silver in the premiere league and I missed it and it was pretty exciting and shocking I guess

*1 attachment(s)*


---

### 75. msg_13159

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:35:19


*1 attachment(s)*


---

### 76. msg_13160

**You** - 2025-05-25T11:38:23

Mer honestly you haven’t let me down\.  And I am not lying\.\. it might be scary to hear but I already know I want to spend the rest of my life with you\.  It scares the fuck out of me\.\. but I am 100% certain more than I have ever been of anything else\.  So yeah these are some shitty bumps along the way and yeah I am not going to lie it is going to hurt a lot over the next few weeks or months\. That is why I want to shit stuff down\.\. I have dreamt about this, thought about this\.\. and it makes me feel so happy\.\. bit the road
To get there will be like walking on glass barefoot I think\.\. totally worth it but going to suck a lot\.


---

### 77. msg_13161

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:40:21

Friday night did not give you A LITTLE pause on that feeling?


---

### 78. msg_13162

**You** - 2025-05-25T11:41:09

I was scared made a mistake\.\. but I think even if you had have, while it would have crushed me I was already relegated to never giving up on you\.


---

### 79. msg_13163

**You** - 2025-05-25T11:41:24

That is how strongly I feel\.


---

### 80. msg_13164

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:42:07

You know I don’t like Andrew right? No matter how messed I am, we are not going back there\.


---

### 81. msg_13165

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:42:37

>
Why does it scare you? Just because of our respective situations?


---

### 82. msg_13166

**You** - 2025-05-25T11:44:07

Reaction: ❤️ from Meredith Lamb
It scares me because I have never done this, even the pre version of me\.\. I have never loved this hard this much this unconditionally\.  I have never opened myself up this much\.  The risk is HUGE\.  And yes our respective situations are different and the potential outcomes terrify me\.


---

### 83. msg_13167

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:47:11

You don’t need to be scared\. I’m not going anywhere\. I’m in this just as deep as you are\.


---

### 84. msg_13168

**You** - 2025-05-25T11:47:15

>
It’s not that you go back it’s that you won’t have a choice\.  You will need to choose
Your children because you won’t be able to afford
To separate and not choose them\.


---

### 85. msg_13169

**You** - 2025-05-25T11:48:46

That is the nightmare scenario\. Mine is done\. Nothing for you to worry about we booked the moving pods downpaymebt on the house\. Closing date\. J and I had what I expect was our last shopping day tomorrow\.  And found some closure on a few things\.


---

### 86. msg_13170

**You** - 2025-05-25T11:49:13

Like this part is happening no matter what\.\. I feel there is still a ton of risk on your side\. Can’t help it\.\.


---

### 87. msg_13171

**You** - 2025-05-25T11:49:50

>
I am not sure mer\.  I know that isn’t fair to say\.\. but it is just a feeling\.\. not a judgement\. An insecurity\.


---

### 88. msg_13172

**You** - 2025-05-25T11:52:25

>
I also think that loneliness over a long period of time can have weird
Effects on people\.  Why you don’t need to worry is Jaimie hates me lol\.\. so at least there is that\.


---

### 89. msg_13173

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:57:47

>
ZERO chance of this happening\. Zero\.


---

### 90. msg_13174

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:58:56

Honestly I cannot emphasize that anymore\. Zero chance\.


---

### 91. msg_13175

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T11:59:17

We operate now as separated\. Talked about getting our bank accounts separated this morning\.


---

### 92. msg_13176

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:00:01

We are 100% done\. I did mention the cottage thing again this morning\. He doesn’t care if I can’t contribute as much\. Does not want that plan changing\.


---

### 93. msg_13177

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:01:01

>
And equally, I am no big fan of Andrew\.


---

### 94. msg_13178

**You** - 2025-05-25T12:14:31

Kk hope for the best 🤞


---

### 95. msg_13179

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:15:28

So j isnt going to come up to your office right?


---

### 96. msg_13180

**You** - 2025-05-25T12:21:28

No


---

### 97. msg_13181

**You** - 2025-05-25T12:22:09

Either you or I won’t be there for like 4 weeks\.


---

### 98. msg_13182

**You** - 2025-05-25T12:22:22

So nothing to worry about


---

### 99. msg_13183

**You** - 2025-05-25T12:22:24

Regardless


---

### 100. msg_13184

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:22:26

You are not going Monday Tuesday?


---

### 101. msg_13185

**You** - 2025-05-25T12:22:34

Not sure and even if I do


---

### 102. msg_13186

**You** - 2025-05-25T12:22:41

I am going to be somewhere else


---

### 103. msg_13187

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:22:54

Somewhere else? Huh?


---

### 104. msg_13188

**You** - 2025-05-25T12:23:11

I will find someplace else
To work out of\. And a valid reason for it


---

### 105. msg_13189

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:23:26

You do not need to do that\. Unnecessary


---

### 106. msg_13190

**You** - 2025-05-25T12:23:57

But I want to


---

### 107. msg_13191

**You** - 2025-05-25T12:24:31

I am going in early again will figure something out doing the early morning workout maybe go for a wall outside for a bit to cool off and then find a place to go\.


---

### 108. msg_13192

**You** - 2025-05-25T12:24:57

Same Tuesday


---

### 109. msg_13193

**You** - 2025-05-25T12:25:07

Or again I might just work from home not sure


---

### 110. msg_13194

**You** - 2025-05-25T12:25:27

Thinking about it today, among other things\.


---

### 111. msg_13195

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:27:05

I feel like we should consider getting together in the morning Monday or tuesday … I want to try because I know for sure it would help you a lot and maybe me too\. Don’t say no immediately right now\. Just let that sit for a while


---

### 112. msg_13196

**You** - 2025-05-25T12:28:08

I don’t need to let it sit\.\. we have talked about this and I know how you actually feel about it\.\. this is you trying to come to the rescue\.\. so I don’t think it is a good idea\.\. have tried this a number of times
Before\. I know what the honest feeling is here mer\.


---

### 113. msg_13197

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:29:13

I am not trying to come to the rescue\. I am thinking about what is best leading into a long absence\.


---

### 114. msg_13198

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:29:29

It is also called listening to you


---

### 115. msg_13199

**You** - 2025-05-25T12:29:36

I don’t think that would be good for you\.\. possibly not me either at this point\. Not sure


---

### 116. msg_13200

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:29:40

And caring about you too


---

### 117. msg_13201

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:30:36

Sometimes you make it feel like I am not allowed to care about what you need\.


---

### 118. msg_13202

**You** - 2025-05-25T12:32:35

I put your needs above mine\.  And honestly it is going to hurt like fuck\. It seeing you for so long\.\. like I don’t know if this makes it worse or not\.\. I am pretty emotional right now\.\. not sure I want you to see any of that\.


---

### 119. msg_13203

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:34:42

I am okay with that\. You don’t have to hide anything from me\. But I think we need to think about each other equally so you have to allow me to sometimes\.


---

### 120. msg_13204

**You** - 2025-05-25T12:35:20

Again not sure I decide to go tomorrow or not\.\. we’ll see\.  Again might be better to just stay home\.\. then no contact


---

### 121. msg_13205

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:36:19

I think we need to see each other\. This weekend was a mess\.


---

### 122. msg_13206

**You** - 2025-05-25T12:37:20

If I thought it might make shit better for both of us\.\. but yeah a 15 minute connect before going on to ignore each other at work for two days then 3\-4 weeks math not great there


---

### 123. msg_13207

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:37:37

Just think it over this afternoon\.


---

### 124. msg_13208

**You** - 2025-05-25T12:37:47

It’s fine mer just leave it\. Easier that way\.


---

### 125. msg_13209

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:38:04

I highly doubt we don’t see each other for 3\-4 wks


---

### 126. msg_13210

**You** - 2025-05-25T12:38:10

We won’t


---

### 127. msg_13211

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:38:13

You are talking a little extreme


---

### 128. msg_13212

**You** - 2025-05-25T12:38:18

I’m not


---

### 129. msg_13213

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:38:22

I don’t believe that


---

### 130. msg_13214

**You** - 2025-05-25T12:38:36

Ok I mean I think that works for you\.\.
It doesn’t for me\.


---

### 131. msg_13215

**You** - 2025-05-25T12:38:59

I just expect the worst plan for it\.\. and out hope in a box


---

### 132. msg_13216

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:39:05

We have been seeing each other pretty regularly no?


---

### 133. msg_13217

**You** - 2025-05-25T12:39:06

Put hope in a box


---

### 134. msg_13218

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:39:09

Making it happen?


---

### 135. msg_13219

**You** - 2025-05-25T12:39:26

That kind of changed golf day and the days that followed\.


---

### 136. msg_13220

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:40:29

Not necessarily…\. Things are changing at lightning speed\. Your family knows now, I will be in a new role soon, I need to move out, it is like living in fast forward\. S


---

### 137. msg_13221

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:40:41

All of the changes shift things and change things


---

### 138. msg_13222

**You** - 2025-05-25T12:41:49

Mer I love you and I am sorry but I cannot work that way\.\. it leads to expectation and disappointment\.\. the not necessarily or per se or solve it tomorrow\.\. it’s not me\. This situation crushes me I am not built for it\. Just trying to survive\.


---

### 139. msg_13223

**You** - 2025-05-25T12:42:04

Every time I am disappointed it hurts more


---

### 140. msg_13224

**You** - 2025-05-25T12:42:44



---

### 141. msg_13225

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:43:59

Did you tell your family that we have never hung out outside of work?


---

### 142. msg_13226

**You** - 2025-05-25T12:44:45

They don’t believe me


---

### 143. msg_13227

**You** - 2025-05-25T12:44:48

Chatham


---

### 144. msg_13228

**You** - 2025-05-25T12:45:25

Maybe I will just go tomorrow or not the park mon/tues morning you show up fine you don’t whatever that is fine to\.


---

### 145. msg_13229

**You** - 2025-05-25T12:45:53

Will think and see\. Just not sure I mean going to get run over one way or other\.


---

### 146. msg_13230

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:46:31

>
They only think Chatham tho?


---

### 147. msg_13231

**You** - 2025-05-25T12:47:00

Cottage


---

### 148. msg_13232

**You** - 2025-05-25T12:47:11

Yeah Jaimie pretty much does t trust anything


---

### 149. msg_13233

**You** - 2025-05-25T12:47:35

But she told me this morning she is going to put the mer thing away and compartmentalize I think she just hopes\. It to see you at the office


---

### 150. msg_13234

**You** - 2025-05-25T12:47:57

Just go in main door ms and leave main doors and she never will’s


---

### 151. msg_13235

**You** - 2025-05-25T12:48:36

She is taking the first week I am taking off as well


---

### 152. msg_13236

**You** - 2025-05-25T12:48:43

And then another in July


---

### 153. msg_13237

**You** - 2025-05-25T12:49:01

So I might not take the second week off unless
There is a lot of work I can do on my own


---

### 154. msg_13238

**You** - 2025-05-25T12:49:19

She is also gone to Moncton a few times twice in June


---

### 155. msg_13239

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:53:22

Sigh, yeah the work thing is going to be super awkward but tbh it has been for me for months


---

### 156. msg_13240

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:53:29

So not that much different


---

### 157. msg_13241

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T12:53:57

I’m sure we will be able to get together at some point in there somehow


---

### 158. msg_13242

**You** - 2025-05-25T12:55:40

Again\.\. I am just going to assume not mer\.


---

### 159. msg_13243

**You** - 2025-05-25T12:59:51

So yeah just going to do what I said earlier workout park work\.\. no expectations… and then will figure out work from there\.


---

### 160. msg_13244

**You** - 2025-05-25T13:00:28

And Wednesday forward\.\.  I don’t know… shit down and close off completely\.\.
Will have to see\.


---

### 161. msg_13245

**You** - 2025-05-25T13:00:37

Sit down\.


---

### 162. msg_13246

**You** - 2025-05-25T13:03:40

Maybe shut signal down for a bit\.\. I dunno been thinking about a lot of different options\.


---

### 163. msg_13247

**You** - 2025-05-25T13:04:04

But yeah might not be as long as I had planned if there isn’t enough work to take second week off ☹️


---

### 164. msg_13248

**You** - 2025-05-25T13:04:13

Will deal with that when it comes


---

### 165. msg_13249

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T13:05:32

That’s fine\. We need to turn this mood around though\. Gahhhh


---

### 166. msg_13250

**You** - 2025-05-25T13:06:09

You go turn your mood around\.


---

### 167. msg_13251

**You** - 2025-05-25T13:07:03

You can do that I know you can\.  Just avoid thinking about me\.\. I will leave you alone for the rest of the day and whatever happens tomorrow right\.\. probably best choice for you,


---

### 168. msg_13252

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T13:07:09

Shopping with Mac


---

### 169. msg_13253

**You** - 2025-05-25T13:07:14

Have fun


---

### 170. msg_13254

**You** - 2025-05-25T13:08:14

Just going to shut this down\. Finish my workout and go home\.  Enjoy your time out with her\. Cya


---

### 171. msg_13255

**You** - 2025-05-25T13:08:44



---

### 172. msg_13256

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T13:12:27

Reaction: ❤️ from Scott Hicks
I love you and will get you out of your funk\. ❤️❤️


---

### 173. msg_13257

**You** - 2025-05-25T13:13:35

I love you too mer\.\. no one else\. Not like you\. ❤️❤️


---

### 174. msg_13258

**You** - 2025-05-25T13:13:53

Reaction: ❤️ from Meredith Lamb
I wouldn’t go through this for anyone else for sure\.


---

### 175. msg_13259

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T14:58:02


*1 attachment(s)*


---

### 176. msg_13260

**You** - 2025-05-25T14:58:48

I can relate to the part in brackets


---

### 177. msg_13261

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T14:59:33

Same look


---

### 178. msg_13262

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T14:59:35

lol


---

### 179. msg_13263

**You** - 2025-05-25T15:19:43

I do have one topic we can talk about that isn't fucked up and depressing\.\. will have to wait for later\.  I have another Half Sister\.  Found out 2 days ago\.


---

### 180. msg_13264

**You** - 2025-05-25T15:21:04

I have just been pretty preoccupied with us and my head\.\.


---

### 181. msg_13265

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T15:35:43

Oh wow \- how’d you find out?


---

### 182. msg_13266

**You** - 2025-05-25T15:48:16

She reached out to me\.


---

### 183. msg_13267

**You** - 2025-05-25T15:48:23

Found me on ancestry\.ca


---

### 184. msg_13268

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T15:53:34

That’s cool \- maybe it will turn into something interesting


---

### 185. msg_13269

**You** - 2025-05-25T15:55:14

She lived in Dieppe\.\. she went to Mathieu Martin High School\.\. I went to HTHS in Moncton \- Rivals\.\. it will def turn into something interesting\.\. I probably new her friends\. could have run into her ffs\.  This will def be interesting\.


---

### 186. msg_13270

**You** - 2025-05-25T15:55:28

we grew up minutes from each other


---

### 187. msg_13271

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T15:56:12

Small world\. Wonder how many others?


---

### 188. msg_13272

**You** - 2025-05-25T15:56:25

Only one other I know of I mentioned her to you


---

### 189. msg_13273

**You** - 2025-05-25T15:56:36

no brothers :\(


---

### 190. msg_13274

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T15:58:56

I mean not yet


---

### 191. msg_13275

**You** - 2025-05-25T16:01:11

we shall see\.


---

### 192. msg_13276

**You** - 2025-05-25T16:01:26

There are a number of other curiosities lol I will tell you about those later\.


---

### 193. msg_13277

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T16:02:41

k


---

### 194. msg_13278

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:05:45

How are you?


---

### 195. msg_13279

**You** - 2025-05-25T20:08:27

Just doing a bit of work\.\. doing some calendar stuff\.\. planning next few days etc\.


---

### 196. msg_13280

**You** - 2025-05-25T20:09:04

hope you had a good day


---

### 197. msg_13281

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:09:08

Not what are you doing, HOW are you doing?


---

### 198. msg_13282

**You** - 2025-05-25T20:09:19

Why don't you tell me about your day\.


---

### 199. msg_13283

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:10:11

Mac and I went shopping and spent too much money\. But all useful stuff\. Lol


---

### 200. msg_13284

**You** - 2025-05-25T20:10:28

Good I am sure this is setup to be an awesome B\-day weekend\.


---

### 201. msg_13285

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:10:43

I got a rug for one of the rooms and your voice “but do you need it?” rang in my ear\. Lol


---

### 202. msg_13286

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:10:52

Mac said yes we need it\. I agreed


---

### 203. msg_13287

**You** - 2025-05-25T20:10:59

Of course you did\.\. no doubt about it\.


---

### 204. msg_13288

**You** - 2025-05-25T20:11:01

Good purchase


---

### 205. msg_13289

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:11:20

I honestly still felt hungover today tho


---

### 206. msg_13290

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:11:26

😵


---

### 207. msg_13291

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:11:39

Not alc hungover


---

### 208. msg_13292

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:11:44

Something different


---

### 209. msg_13293

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:12:03

So have been doing laundry, tv, not much


---

### 210. msg_13294

**You** - 2025-05-25T20:12:10

>
what is wrong


---

### 211. msg_13295

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:12:35

I think it is that stupid gummy\. Just after effect\.


---

### 212. msg_13296

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:12:43

Never doing that again


---

### 213. msg_13297

**You** - 2025-05-25T20:12:47

>
sure sure


---

### 214. msg_13298

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:12:51

No idea what the heck is in it


---

### 215. msg_13299

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:13:00

It said extra strength\. wtf


---

### 216. msg_13300

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:13:14

Jim’s are so tame by comparison


---

### 217. msg_13301

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:13:20

Like sooooooooooo tame


---

### 218. msg_13302

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:13:48

>
For real\. It’s like I had food poisoning\.


---

### 219. msg_13303

**You** - 2025-05-25T20:13:53

honestly if I could take something that would send me off into a black void I would\.\. man sign me up\.\. sounds like a vacation\.


---

### 220. msg_13304

**You** - 2025-05-25T20:13:54

anyways


---

### 221. msg_13305

**You** - 2025-05-25T20:14:04

my day consisted of some dfriving maddie to a baday party


---

### 222. msg_13306

**You** - 2025-05-25T20:14:12

and pickup\.\. then out to buy some moving boxes\.


---

### 223. msg_13307

**You** - 2025-05-25T20:14:25

but no one wanted to work\.\. so I am back in the basement for 2 hours then going to bed\.


---

### 224. msg_13308

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:14:41

And how is your head?


---

### 225. msg_13309

**You** - 2025-05-25T20:14:44

same


---

### 226. msg_13310

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:14:56

What time do I meet you tomorrow


---

### 227. msg_13311

**You** - 2025-05-25T20:15:00

You could ask me that question tomorrow next week next month


---

### 228. msg_13312

**You** - 2025-05-25T20:15:02

same answer


---

### 229. msg_13313

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:15:21

Stop thinking so far ahead


---

### 230. msg_13314

**You** - 2025-05-25T20:15:26

if I don't


---

### 231. msg_13315

**You** - 2025-05-25T20:15:28

it is worse


---

### 232. msg_13316

**You** - 2025-05-25T20:15:37

Far ahead is the only thing I can focus on


---

### 233. msg_13317

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:16:01

>
…\.


---

### 234. msg_13318

**You** - 2025-05-25T20:16:04

I don't know\.


---

### 235. msg_13319

**You** - 2025-05-25T20:16:17

I go early so it might not work for you anyways


---

### 236. msg_13320

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:16:37

I will get up early\. One day lol


---

### 237. msg_13321

**You** - 2025-05-25T20:17:19

I still don't know\.\. I still don't feel right about it\.\. let me think a bit more\.


---

### 238. msg_13322

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:18:02

No, you don’t have a choice on this\. Not after this weekend\.


---

### 239. msg_13323

**You** - 2025-05-25T20:18:37

Sure I do\.\. if this just hurts me more\.\.\.\.\.\. how is that gonna help?


---

### 240. msg_13324

**You** - 2025-05-25T20:19:59

I need to close an earlier conversation \- and I am good with everything that you said\.\. but listen\.\. if anything did happen \- even though you say it won't \- but if it did\.\. even if it was a mistake\.\. you would tell me right, I would never need to wonder\.


---

### 241. msg_13325

**You** - 2025-05-25T20:20:49

Like if it did or has already or whatever\.\. you get what I am saying\.


---

### 242. msg_13326

**You** - 2025-05-25T20:21:28

>
btw\.\. Is this "K"  would this do this?


---

### 243. msg_13327

**You** - 2025-05-25T20:21:50

sorry couple of stacked messages


---

### 244. msg_13328

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:23:12

Omg Scott…


---

### 245. msg_13329

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:23:18

First, I would never\.


---

### 246. msg_13330

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:23:31

Second, yes of course I would tell you\.


---

### 247. msg_13331

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:23:46

But I honestly would never\.


---

### 248. msg_13332

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:24:04

I could not even bring myself close\.


---

### 249. msg_13333

**You** - 2025-05-25T20:24:38

>
I just needed this\.\. I am good\.


---

### 250. msg_13334

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:24:41

We have not even touched or brushed by each other since the fall\.


---

### 251. msg_13335

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:25:04

This is a 100% truth\.


---

### 252. msg_13336

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:25:36

After that text happened in sept/oct, we did and I felt horrible\.


---

### 253. msg_13337

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:25:44

That was it for me\.


---

### 254. msg_13338

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:25:52

That was probably September


---

### 255. msg_13339

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:25:59

Maybe early October


---

### 256. msg_13340

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:26:24

I have no interest in being with someone who betrayed me\.


---

### 257. msg_13341

**You** - 2025-05-25T20:26:39

I understand Mer\. you don't need to go back into that\.\.


---

### 258. msg_13342

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:26:56

>
We are not doing k so not discussing\.


---

### 259. msg_13343

**You** - 2025-05-25T20:27:02

We aren't agreed


---

### 260. msg_13344

**You** - 2025-05-25T20:27:09

But I did a bit of research


---

### 261. msg_13345

**You** - 2025-05-25T20:27:15

There is Ketamine therapy


---

### 262. msg_13346

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:27:19

And…


---

### 263. msg_13347

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:27:24

Yeah


---

### 264. msg_13348

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:27:54

It is a dissociative


---

### 265. msg_13349

**You** - 2025-05-25T20:27:54

I was just thinking of what it does\.\. and how I want to dissasociate\.


---

### 266. msg_13350

**You** - 2025-05-25T20:28:44

I don't do drugs\.\. I don't like them\.\. but I have tried a number of different things to get my mind right\.


---

### 267. msg_13351

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:28:47

I started doing it after my friend killed herself\. Was a very emotional time\. A lot of ppl do it with e \(mdma\) also


---

### 268. msg_13352

**You** - 2025-05-25T20:29:06

and nothing is working\.\.


---

### 269. msg_13353

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:29:15

K is addictive\. Problem\.


---

### 270. msg_13354

**You** - 2025-05-25T20:29:31

well scratch that then\.\. I won't do that\.


---

### 271. msg_13355

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:30:27

Honestly everyone talks about how addictive cocaine is\. I did not find that\. K, yes\. But I like disassociatives bc my brain doesn’t shut off\.


---

### 272. msg_13356

**You** - 2025-05-25T20:30:59

well\.\. i do get addicted\.\. so while it probably is the perfect thing for me based on my brain


---

### 273. msg_13357

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:31:06

Why don’t we just plan a trip and have that to look forward to instead?


---

### 274. msg_13358

**You** - 2025-05-25T20:31:03

can't do it


---

### 275. msg_13359

**You** - 2025-05-25T20:31:36

>
too far out to consider planning\.\.\. and too soon puts you at risk so I won't


---

### 276. msg_13360

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:32:11

k, so medium term then :p


---

### 277. msg_13361

**You** - 2025-05-25T20:33:02

no I am sorry Mer\.\. I don't think that is a good idea\.


---

### 278. msg_13362

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:35:37

This new approach of yours is not working\. Your words are cutting and I know they are hurting you too\.


---

### 279. msg_13363

**You** - 2025-05-25T20:36:19

I am not trying to be that way\.\. but it feels like\.\.\.\.\. like a mirage\.


---

### 280. msg_13364

**You** - 2025-05-25T20:36:57

Ok mer\.\. let's do it your way\.


---

### 281. msg_13365

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:37:30

A mirage?


---

### 282. msg_13366

**You** - 2025-05-25T20:37:43

the closer I get I feel it will just fade away\.


---

### 283. msg_13367

**You** - 2025-05-25T20:37:57

and it is likely so far out into the future it won't really matter\.


---

### 284. msg_13368

**You** - 2025-05-25T20:38:03

but again\.\. let's try it\.\.


---

### 285. msg_13369

**You** - 2025-05-25T20:38:25

i cannot be like this again\.\. it just hurts you\.\. I will try to find some way to at least present as happy\.


---

### 286. msg_13370

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:39:39

You do not need to be happy\. Just be honest\. Don’t do things you don’t want to\. I do not need protecting\. If I’m uncomfortable with something I just won’t do it\.


---

### 287. msg_13371

**You** - 2025-05-25T20:40:07

I have been honest\.\. lol\.\.


---

### 288. msg_13372

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:41:12

So you really just want to cut off contact\. That is your truth?


---

### 289. msg_13373

**You** - 2025-05-25T20:43:55

I don't want\.\.\. I just don't know what to do\.  I don't know what will help\.\. when I did that GPT analysis of us after golf\.\. it made sense\.\. while we are great together\.\. we are not great in this situation \- we are fundamental opposites\.\. I just realized this was going to be really really horrible, as I wanted to respect your needs\.  I just don't want hurt\.\. these fucking emotions suck\.\. i wish they would turn off again, just for a little while ffs\.


---

### 290. msg_13374

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:45:14

I think we need to be able to talk about stuff without you going full blast on me in the other direction\.


---

### 291. msg_13375

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:45:41

I didn’t think of if I told you about how I was feeling you were just going to run in the opposite direction


---

### 292. msg_13376

**You** - 2025-05-25T20:50:20

You know\.\. I like puzzles\.\. I always have\.\. there is a logic to solving them\.\. an order a structure\.\. one\.\. or many solutions\.  I have come at this situation we are in both from a logical perspective\.\. and from a pure brute force passion perspective\.  I don't have an answer\.\. I am distracted, I am distraught, and I don't think there is a fix for this, not one that works for both of us, and certainly not one that will work for the long absences we are facing over the next few months\.  So I think not talking about it all is probably a good solution\.\. because then you won't hate or resent me for being a fucking shitty downer all the time\.\. and I don't have to feel bad about pushing back on your good intentions\.  I know you care\.\. I know you love me, but I just think our constant triyng to fix it won't I tried for a few weeks to figure out some shit\.\. none of it really took hold\.\. and I think we are at different places in what we need\.\. so that is why I kind of am withdrawing\.\. you are ver\.\.\. \[truncated\]


---

### 293. msg_13377

**You** - 2025-05-25T20:52:16

Sometimes your honesty is "stark"\.\. don't get me wrong, I love it, and I love you\.  But sometimes when you drop some knowledge it lands with a thud\.\. lol if you get my meaning\.  Sometimes it lands on me with a thud\.  That was golf\.


---

### 294. msg_13378

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:53:05

This doesn’t feel casual to me\.


---

### 295. msg_13379

**You** - 2025-05-25T20:53:10

I didn't say that\.


---

### 296. msg_13380

**You** - 2025-05-25T20:53:18

Think about how you state things\.


---

### 297. msg_13381

**You** - 2025-05-25T20:53:32

From your perspective \- you will say something that is to you not a big deal\.


---

### 298. msg_13382

**You** - 2025-05-25T20:53:38

so you just kind of throw it out that way\.


---

### 299. msg_13383

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:53:47

Like…\.\.


---

### 300. msg_13384

**You** - 2025-05-25T20:53:46

But you don't know that it is a big deal to me


---

### 301. msg_13385

**You** - 2025-05-25T20:53:56

that I think about things differently


---

### 302. msg_13386

**You** - 2025-05-25T20:54:41

I don't want to get into examples\.\. The only reason this is a problem between us is because of how raw this situation is making things\.\. that is the only problem


---

### 303. msg_13387

**You** - 2025-05-25T20:54:44

give me 60 days


---

### 304. msg_13388

**You** - 2025-05-25T20:54:47

I will be a new man


---

### 305. msg_13389

**You** - 2025-05-25T20:55:02

or you can take me back for a full refund


---

### 306. msg_13390

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:55:20

lol


---

### 307. msg_13391

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T20:55:44

I wish I could just kiss you right now\. Everything would be fine\.


---

### 308. msg_13392

**You** - 2025-05-25T20:56:44

Reaction: ❤️ from Meredith Lamb
From my perspective It would be amazing\.\. every time you have kissed me has been amazing\.\. from the first time to the last\.


---

### 309. msg_13393

**You** - 2025-05-25T20:57:22

I told you I think we will look back on this and I will feel like an idiot\.  But I have to deal with how I am feeling now and what is in front of me\.


---

### 310. msg_13394

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:01:01

So how have the conversations gone with your family in terms of how you are moving forward or not with us\.


---

### 311. msg_13395

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:01:13

Like that must have been discussed or asked


---

### 312. msg_13396

**You** - 2025-05-25T21:02:32

Reaction: ❓ from Meredith Lamb
I told them we haven't really talked very much since and that no plans have been made\.  essentially accurate\.


---

### 313. msg_13397

**You** - 2025-05-25T21:02:57

Jaimie seems to have calmed down a lot on you since day 1


---

### 314. msg_13398

**You** - 2025-05-25T21:03:28

I shared with her 2 texts from Gracie \- to me which suggested she didn't care if I went out with you as long as she could stay here\.  That changed J's perspective on Gracie in this\.


---

### 315. msg_13399

**You** - 2025-05-25T21:03:49

Yesterday morning \- we had a bit of a fight on the way to yorkdale\.\.


---

### 316. msg_13400

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:04:02

>
Hardly\. We talk all the time\.


---

### 317. msg_13401

**You** - 2025-05-25T21:04:30

>
we don't TALK\.\. we have been circling around this painful conversation since Thursday\.


---

### 318. msg_13402

**You** - 2025-05-25T21:04:37

which is what I want to get away from


---

### 319. msg_13403

**You** - 2025-05-25T21:04:44

because a\) it won'


---

### 320. msg_13404

**You** - 2025-05-25T21:04:47

wont be solved


---

### 321. msg_13405

**You** - 2025-05-25T21:04:55

and b\) it will keep dragging us down\.


---

### 322. msg_13406

**You** - 2025-05-25T21:05:14

If you can live through the next little while with what you have right now\.\.


---

### 323. msg_13407

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:05:18

>
About…\.


---

### 324. msg_13408

**You** - 2025-05-25T21:05:18

we shold just focus on that


---

### 325. msg_13409

**You** - 2025-05-25T21:05:23

we fought about you


---

### 326. msg_13410

**You** - 2025-05-25T21:05:46

I was trying to explain how the discussions began innocently\.\. there was no intent\.\.


---

### 327. msg_13411

**You** - 2025-05-25T21:05:50

it was just support\.


---

### 328. msg_13412

**You** - 2025-05-25T21:06:01

shit kind of happened\.\. but nothing "happened" until we separated


---

### 329. msg_13413

**You** - 2025-05-25T21:06:13

I wanted to confirm she was going to let this be\.


---

### 330. msg_13414

**You** - 2025-05-25T21:06:21

Which she has confirmed several times already


---

### 331. msg_13415

**You** - 2025-05-25T21:06:33

And she has told Gracie to fuck right off


---

### 332. msg_13416

**You** - 2025-05-25T21:06:43

So that was the morning\.\.


---

### 333. msg_13417

**You** - 2025-05-25T21:06:54

after that\.\. things were easy\.\. almost a little sad


---

### 334. msg_13418

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:07:03

Does she think this is not continuing?


---

### 335. msg_13419

**You** - 2025-05-25T21:07:06

No


---

### 336. msg_13420

**You** - 2025-05-25T21:07:11

She doesn't think that\.\.


---

### 337. msg_13421

**You** - 2025-05-25T21:07:26

She doesn't think I am going to be stupid enough to do something in front of her face\.


---

### 338. msg_13422

**You** - 2025-05-25T21:07:34

she isn't accepting of it\.\.


---

### 339. msg_13423

**You** - 2025-05-25T21:07:39

if that is what you are getting at\.


---

### 340. msg_13424

**You** - 2025-05-25T21:07:52

she doesn't want it to come out at work until after she has quit and gone\.


---

### 341. msg_13425

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:07:58

No I was just curious on your narrative


---

### 342. msg_13426

**You** - 2025-05-25T21:08:09

I said you were a wench\.\. and I didn't like you much anyways


---

### 343. msg_13427

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:08:22

lol


---

### 344. msg_13428

**You** - 2025-05-25T21:08:27

I tried to humanize you


---

### 345. msg_13429

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:08:42

By calling me a wench


---

### 346. msg_13430

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:08:43

lol


---

### 347. msg_13431

**You** - 2025-05-25T21:08:44

no not that


---

### 348. msg_13432

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:08:51

Kidding


---

### 349. msg_13433

**You** - 2025-05-25T21:08:59

she is the youngest of 3 \- oopsie baby\.


---

### 350. msg_13434

**You** - 2025-05-25T21:09:03

country kid


---

### 351. msg_13435

**You** - 2025-05-25T21:09:11

did not have the same parents or the same opportunities


---

### 352. msg_13436

**You** - 2025-05-25T21:09:27

but the situations in many ways were similar\.


---

### 353. msg_13437

**You** - 2025-05-25T21:09:37

She was introverted and quiet


---

### 354. msg_13438

**You** - 2025-05-25T21:09:40

most of her life


---

### 355. msg_13439

**You** - 2025-05-25T21:09:56

She grew up in a very small town\.\. smaller than Glencoe


---

### 356. msg_13440

**You** - 2025-05-25T21:09:59

Miscouche


---

### 357. msg_13441

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:10:09

Wait you didn’t try to tell her that I’m like her


---

### 358. msg_13442

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:10:14

That would drive her insane


---

### 359. msg_13443

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:10:21

I hope you didn’t do that


---

### 360. msg_13444

**You** - 2025-05-25T21:10:24

She didn't have a lot of boyfriends growing up or a lot of friends\.\. she turned to drugs in grade 12


---

### 361. msg_13445

**You** - 2025-05-25T21:10:30

and went hard for a few years


---

### 362. msg_13446

**You** - 2025-05-25T21:10:38

then hard again\.\. then hard on drinking and drugs


---

### 363. msg_13447

**You** - 2025-05-25T21:10:47

then just hard on drinking by the time I met her\.


---

### 364. msg_13448

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:11:16

Your type is troubled souls


---

### 365. msg_13449

**You** - 2025-05-25T21:11:15

She was engaged\.\. her fiance cheated on her\.\. before me there were 2 people the fiance\.\. and her best friend\.\. one night, and regretted it forever\.


---

### 366. msg_13450

**You** - 2025-05-25T21:11:33

She was scared of me\.\.  I was not her type\.


---

### 367. msg_13451

**You** - 2025-05-25T21:12:06

I was smart, educated, fast, confident\.\. and COLD \- well cold still in a welcoming , polite, and slightly charming way\.


---

### 368. msg_13452

**You** - 2025-05-25T21:12:43

She fell I didn't\.  To put it simply\.  We broke up because I didn't feel the connection\.


---

### 369. msg_13453

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:13:02

That is the reason?


---

### 370. msg_13454

**You** - 2025-05-25T21:13:11

Yeah\.\. I didn't but I didn't realize I couldn't


---

### 371. msg_13455

**You** - 2025-05-25T21:13:22

Not with her\.


---

### 372. msg_13456

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:13:44

Have you two ever talked about this?


---

### 373. msg_13457

**You** - 2025-05-25T21:13:50

Yeah\.


---

### 374. msg_13458

**You** - 2025-05-25T21:13:57

not always great conversations


---

### 375. msg_13459

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:14:09

Phew I bet


---

### 376. msg_13460

**You** - 2025-05-25T21:14:09

she resents me\.\. thinks I ruined her life\.


---

### 377. msg_13461

**You** - 2025-05-25T21:14:16

wishes we never met or got back together\.


---

### 378. msg_13462

**You** - 2025-05-25T21:14:19

and she means it


---

### 379. msg_13463

**You** - 2025-05-25T21:14:33

This hurt her badly\.\.


---

### 380. msg_13464

**You** - 2025-05-25T21:14:51

not this you and i


---

### 381. msg_13465

**You** - 2025-05-25T21:14:55

this me separating


---

### 382. msg_13466

**You** - 2025-05-25T21:15:22

She feels like I am the last in a long line of people that has found her unworthy and kicked her to the curb\.


---

### 383. msg_13467

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:15:43

Omg ouch ouch ouch 🤕


---

### 384. msg_13468

**You** - 2025-05-25T21:16:00

anyhow\.\. there are some similarities in your back stories\.\. she lost close friends\.\. turned to drugs\.\. etc etc\.


---

### 385. msg_13469

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:16:08

Does she get therapy?


---

### 386. msg_13470

**You** - 2025-05-25T21:16:11

She hates therapy


---

### 387. msg_13471

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:16:31

Oh that sucks


---

### 388. msg_13472

**You** - 2025-05-25T21:16:38

anyhow\.\. I tried to make some connections\.


---

### 389. msg_13473

**You** - 2025-05-25T21:16:51

Outwardly she was like are you fucking kidding me\.


---

### 390. msg_13474

**You** - 2025-05-25T21:17:27

but I think a lot got through\.\. she will never like you\.\. and I mean ever ever ever\.  But I think she has calmed down a lot and is more reasonable\.


---

### 391. msg_13475

**You** - 2025-05-25T21:17:36

still follow the instructions I gave you earlier lol


---

### 392. msg_13476

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:17:58

lol you had typos in your instructions


---

### 393. msg_13477

**You** - 2025-05-25T21:18:05

whatever you know what I meantr


---

### 394. msg_13478

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:18:11

I don’t think you need to make connections between us


---

### 395. msg_13479

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:18:23

Probably not helpful really


---

### 396. msg_13480

**You** - 2025-05-25T21:18:24

I wasn't doing it for you\.\.


---

### 397. msg_13481

**You** - 2025-05-25T21:18:39

She could relate to you I think a bit better though\.


---

### 398. msg_13482

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:18:41

Probably not helpful to HER I meant


---

### 399. msg_13483

**You** - 2025-05-25T21:18:48

again\.\. she was super calm today


---

### 400. msg_13484

**You** - 2025-05-25T21:18:51

anyhow


---

### 401. msg_13485

**You** - 2025-05-25T21:19:01

after yorkdale we went to outlets


---

### 402. msg_13486

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:19:29

It’s probably really hard to understand for her because we don’t even really understand it


---

### 403. msg_13487

**You** - 2025-05-25T21:19:28

walked around\.\. chatted like normal\.\. she bought a bunch of shit\.\. I bought nothing\.\. had a chuckle because that is always how it was\.


---

### 404. msg_13488

**You** - 2025-05-25T21:20:05

>
I think I understand it\.\. and if it happened in September\.\. we would be having an epic time right now I think\.


---

### 405. msg_13489

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:20:24

Wdym why?


---

### 406. msg_13490

**You** - 2025-05-25T21:20:44

Because I do believe we were meant to connect\.\. and if it had just happened a bit later\.\. so much easier\.


---

### 407. msg_13491

**You** - 2025-05-25T21:21:05

but I cannot have it both ways\.


---

### 408. msg_13492

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:21:12

Oh I thought you meant last September


---

### 409. msg_13493

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:21:21

I’m confused


---

### 410. msg_13494

**You** - 2025-05-25T21:21:42

If I believe we were meant to connect\.\. perhaps we were meant to connect when we did\.\. so that us going through all this shit would just show us how important we are to each other\.\.\. I dunno\.


---

### 411. msg_13495

**You** - 2025-05-25T21:22:07

fate and predestination are always annoying topics to think about\.


---

### 412. msg_13496

**You** - 2025-05-25T21:22:39

anyhow\. I don't need to "understand us"


---

### 413. msg_13497

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:23:02

Do you think part of your mood is grieving your marriage loss also?


---

### 414. msg_13498

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:23:09

Does that come in sometimes?


---

### 415. msg_13499

**You** - 2025-05-25T21:23:10

ok


---

### 416. msg_13500

**You** - 2025-05-25T21:23:12

so next


---

### 417. msg_13501

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:23:22

Maybe there is a lot going on and it isn’t just us


---

### 418. msg_13502

**You** - 2025-05-25T21:23:26

there is\.


---

### 419. msg_13503

**You** - 2025-05-25T21:23:31

don't get me wrong\.


---

### 420. msg_13504

**You** - 2025-05-25T21:23:52

but what I am feeling re: you and our situation is just that\.\. I keep those things separate\.\. they don't cross over\.


---

### 421. msg_13505

**You** - 2025-05-25T21:24:00

So we left the outlet mall\.


---

### 422. msg_13506

**You** - 2025-05-25T21:24:23

And I suggested we go to this little puzzle store up in georgetown that she found a few years ago that she loved\.\. and wouldn't be getting back there again\.


---

### 423. msg_13507

**You** - 2025-05-25T21:24:38

Everything was fine until we left\.


---

### 424. msg_13508

**You** - 2025-05-25T21:25:05

And then you are right\.\. I grieved right then and there\.


---

### 425. msg_13509

**You** - 2025-05-25T21:25:10

out of the blue\.


---

### 426. msg_13510

**You** - 2025-05-25T21:25:34

You cannot spend more than half your life with someone and not grieve that it is coming to an end\.


---

### 427. msg_13511

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:25:42

Not surprising


---

### 428. msg_13512

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:25:47

I have had my moments


---

### 429. msg_13513

**You** - 2025-05-25T21:25:50

especially when she didn't do anything horrible to bring it on\.


---

### 430. msg_13514

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:26:02

I know…


---

### 431. msg_13515

**You** - 2025-05-25T21:26:03

Like don't get me wrong\.\. it isn't me regretting my decision\.


---

### 432. msg_13516

**You** - 2025-05-25T21:26:08

or looking to flip\.\.


---

### 433. msg_13517

**You** - 2025-05-25T21:26:12

just realizing


---

### 434. msg_13518

**You** - 2025-05-25T21:26:26

ya know\.\. that this is over\.\. 25 years\.


---

### 435. msg_13519

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:26:40

Would it be easier to flip now?


---

### 436. msg_13520

**You** - 2025-05-25T21:26:43

no\.


---

### 437. msg_13521

**You** - 2025-05-25T21:26:57

No\.\. even if there was no you\.


---

### 438. msg_13522

**You** - 2025-05-25T21:27:20

I will still move forward\.\. I feel it is the right decisions for me ultimately\.\. and for her too\.\. even though she doesn't realize it\.


---

### 439. msg_13523

**You** - 2025-05-25T21:27:38

There wasn't a millisecond


---

### 440. msg_13524

**You** - 2025-05-25T21:27:41

meredith


---

### 441. msg_13525

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:27:59

Yeah, I understand… I get it really\.


---

### 442. msg_13526

**You** - 2025-05-25T21:28:46

She doesn't want to leave in july she wants to stay until september\.\. I told her we cannot wait that long with gracie here\.\. other than that if gracie wasn't here I wouldn't care if she stayed\.  It would cramp us a bit more\.\. but it would make maddie happy\.


---

### 443. msg_13527

**You** - 2025-05-25T21:29:20

But yeah\.\. I was really shocked when that happened\.\. I think she was too\.


---

### 444. msg_13528

**You** - 2025-05-25T21:29:31

anyhow I got sorted\.\. and we just went to uhaul


---

### 445. msg_13529

**You** - 2025-05-25T21:29:36

booked her pickup


---

### 446. msg_13530

**You** - 2025-05-25T21:29:43

Reaction: 😢 from Meredith Lamb
and came home to a Gracie fight,\.


---

### 447. msg_13531

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:30:09

>
I’m sure it won’t be the last time\.


---

### 448. msg_13532

**You** - 2025-05-25T21:30:13

It will not\.


---

### 449. msg_13533

**You** - 2025-05-25T21:30:16

I am sure of that too


---

### 450. msg_13534

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:30:32

I’m getting weird moments of knowing I’m leaving my kids alone here without me\.


---

### 451. msg_13535

**You** - 2025-05-25T21:30:32

Reaction: 😢 from Meredith Lamb
I am saying goodbye to my oldest\.\. and to my dog, who I might not see again,\.


---

### 452. msg_13536

**You** - 2025-05-25T21:30:43

I will definitely be a mess\.


---

### 453. msg_13537

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:30:55

I will be looking at the fucking hand soap and think “who is going to replace this now?”


---

### 454. msg_13538

**You** - 2025-05-25T21:31:15

yeah I can see


---

### 455. msg_13539

**You** - 2025-05-25T21:31:20

that happening


---

### 456. msg_13540

**You** - 2025-05-25T21:31:22

for you


---

### 457. msg_13541

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:31:30

Even though I will be close by


---

### 458. msg_13542

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:31:37

It’s weird


---

### 459. msg_13543

**You** - 2025-05-25T21:33:03

yeah that is where our situations are different\.  I tried to explain to her\.\. because she was being a bit harsh\.\. because she is hurt of course\.\. just because I made this choice doesn't mean I don't want her to be happy\.\. doesn't mean we won't stay in contact\.\. and doesn't mean I won't miss her\.  She said you will replace me with someone else fast enough, if not Meredith, then someone else\.  I explained again\.\. Mer and I were not planned, just happened\.\. I was fully ready to be alone\.\.


---

### 460. msg_13544

**You** - 2025-05-25T21:33:44

Regardless\.\. I feel like there is still a lot of stuff there\.\. but she is calmer now


---

### 461. msg_13545

**You** - 2025-05-25T21:33:59

and no she didn't ask if there was a chance\.\. or if I was having second thoughts\.


---

### 462. msg_13546

**You** - 2025-05-25T21:34:12

She doesn't want a chance, and she is not having second thoughts either\.


---

### 463. msg_13547

**You** - 2025-05-25T21:35:08

I am waiting for you to respond\.\. I am curious as to what you are thinking right now\.


---

### 464. msg_13548

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:35:37

Reaction: ❤️ from Scott Hicks
Just a lot


---

### 465. msg_13549

**You** - 2025-05-25T21:35:51

ok\.\. break out what you can\.


---

### 466. msg_13550

**You** - 2025-05-25T21:35:57

you just got a firehose of honesty


---

### 467. msg_13551

**You** - 2025-05-25T21:36:16

but I feel like you want that\.\. even if it makes you think\.\. you would rather know than not\.


---

### 468. msg_13552

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:38:34

This is just a lot on both sides\. Yours and mine\. It is so much to process\. I appreciate hearing about how it went between you two because I’ve been worrying about when Andrew finds out so it helps me a bit\. But reading that you will miss her, while I know that is natural and totally ok, it still stings a little\. But I don’t blame you or think it isn’t normal… just a lot\. This situation is weird\.


---

### 469. msg_13553

**You** - 2025-05-25T21:39:41

>
Look\.\. I am not naive\.\. Andrew will be a part of my life going forward\.\. or at least I hope he is\.\. because I want to be apart of your life, and your kids\.  Just like I hope somehow you can become a part of my kids' lives\.


---

### 470. msg_13554

**You** - 2025-05-25T21:40:47

Jaimie and I went through a lot of shit together\. We supported each other for a long time\.  But that relationships time has passed\.  It is done\.\. it doesn't mean I don't have feelings\.\.


---

### 471. msg_13555

**You** - 2025-05-25T21:40:54

But Meredith\.


---

### 472. msg_13556

**You** - 2025-05-25T21:41:07

Again\.\. the feelings I have for you aren't like anything I have experienced\.


---

### 473. msg_13557

**You** - 2025-05-25T21:41:45

Please take hope in that\.\. I have never loved anyone like you\.\. I have said it over and over again\.\. I believe it\.\. I want what I told you last night\.  I don't have doubts\.


---

### 474. msg_13558

**You** - 2025-05-25T21:42:07

and anyone like you is how much I love you\.\. not who you are\.\. lol


---

### 475. msg_13559

**You** - 2025-05-25T21:42:26

I just re read what I wrote\.\. and was like\.\. err


---

### 476. msg_13560

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:42:41

Errr lol why?


---

### 477. msg_13561

**You** - 2025-05-25T21:43:12

Reaction: 😂 from Meredith Lamb
well it can be read I have never loved anyone like you\.\. like you the person\.\. or someone like you\.\. not "loved" anyone like you\.\. as in the degree of love\.\.


---

### 478. msg_13562

**You** - 2025-05-25T21:43:16

ok that sounded geeky\.


---

### 479. msg_13563

**You** - 2025-05-25T21:43:21

whatever\.


---

### 480. msg_13564

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:43:47

Thanks for the clarification


---

### 481. msg_13565

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:43:49

lol


---

### 482. msg_13566

**You** - 2025-05-25T21:43:48

so yeah there is some residual after 25 years\.


---

### 483. msg_13567

**You** - 2025-05-25T21:43:54

I want more than 25 with you,\.


---

### 484. msg_13568

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:44:30

We are old\.


---

### 485. msg_13569

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:44:37

Boo :\(


---

### 486. msg_13570

**You** - 2025-05-25T21:44:37

It won't change how I feel\.


---

### 487. msg_13571

**You** - 2025-05-25T21:44:42

or how I behave


---

### 488. msg_13572

**You** - 2025-05-25T21:44:44

:\)


---

### 489. msg_13573

**You** - 2025-05-25T21:45:02

Reaction: ❤️ from Meredith Lamb
I have gotten 20 years younger\.\. since we have been together\.\. maybe more\.


---

### 490. msg_13574

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:46:08

Think it will last?


---

### 491. msg_13575

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:46:22

I worry you will get bored of me


---

### 492. msg_13576

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:46:26

lol


---

### 493. msg_13577

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:46:31

Not kidding


---

### 494. msg_13578

**You** - 2025-05-25T21:49:03

Every single kiss has been Amazing\.\. Everything we have "done" has been and felt Amazing\.\. and felt like an emotional explosion\.  Sitting with you watching TV, helping you clean, watching you from across the room\.\. because why not I can\.  Every time I look at you I feel nothing but love, or sadness\.\. when we cannot be together\.  I would be the one to lose you Mer not the other way around \- not kidding\.


---

### 495. msg_13579

**You** - 2025-05-25T21:50:11

I don't know even what there would be to get bored of\.  I don't think I could\.  I cannot stop thinking about you even if I want to\.\. even when I was with you\.


---

### 496. msg_13580

**You** - 2025-05-25T21:50:31

Now that needs to get under control\.\. lol but I cannot see me ever getting bored\.


---

### 497. msg_13581

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:51:02

Get bored of me beating you\.

*1 attachment(s)*


---

### 498. msg_13582

**You** - 2025-05-25T21:51:36

>
As much as I hate these next few months\.\. and I do\.\. I told you\.\. I don't doubt that I will spend the rest of my days with you if you will have me\.


---

### 499. msg_13583

**You** - 2025-05-25T21:52:04

>
mmmm\.\.\. I want you to enjoy these wins\.\.


---

### 500. msg_13584

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:52:26

>
lol


---

### 501. msg_13585

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:52:32

They won’t last long?


---

### 502. msg_13586

**You** - 2025-05-25T21:52:33

nope


---

### 503. msg_13587

**You** - 2025-05-25T21:52:37

nope nope nope


---

### 504. msg_13588

**You** - 2025-05-25T21:53:12

What do you think\.


---

### 505. msg_13589

**You** - 2025-05-25T21:53:14

btw


---

### 506. msg_13590

**You** - 2025-05-25T21:53:23

Think it will last?
I worry you will get bored of me
lol
Not kidding
6m


---

### 507. msg_13591

**You** - 2025-05-25T21:53:29

let me throw it back


---

### 508. msg_13592

**You** - 2025-05-25T21:54:00

I don't think you are as confident or as certain as I am\.\. you are more hope I am more I will make my own future\.


---

### 509. msg_13593

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:54:46

I find it incredibly odd that we had bath resigned ourselves to living alone and then all of a sudden


---

### 510. msg_13594

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:54:54

It causes me to worry at times


---

### 511. msg_13595

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:55:01

However I don’t when I’m with you


---

### 512. msg_13596

**You** - 2025-05-25T21:55:08

>
why\.


---

### 513. msg_13597

**You** - 2025-05-25T21:55:15

it proves the point


---

### 514. msg_13598

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:55:50

I just wonder if it is some reaction to separation/divorce\. It doesn’t feel like it but maybe we are naive\.


---

### 515. msg_13599

**You** - 2025-05-25T21:56:34

ok\.\. so you have dodged the questions again\.\. I think given this clarification\.\. my statement is accurate \- "don't think you are as confident or as certain as I am\.\. you are more hope I am more I will make my own future\." \.\. unless you want to provide a different answer\.\.


---

### 516. msg_13600

**You** - 2025-05-25T21:57:44

You are thinking too much\.\. which is usually my problem\.\. and it is usually how all my relationships worked\.\. when I changed\.\. I am being led by my heart here\.\. and I am going to just let it ride\.


---

### 517. msg_13601

**You** - 2025-05-25T21:57:57

well after the next few months\.\. right now I want to put it in a box


---

### 518. msg_13602

**You** - 2025-05-25T21:58:00

and step on the box


---

### 519. msg_13603

**You** - 2025-05-25T21:58:06

repeatedly


---

### 520. msg_13604

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:59:28

>
I am confident in how I feel about you and my attraction to you\. Was never this attracted to Andrew\. I’m not lying and there are various ways I know that as true\. I worry a bit more about you than me lol


---

### 521. msg_13605

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T21:59:42

Just because maybe you are rebounding hard


---

### 522. msg_13606

**You** - 2025-05-25T21:59:45

>
you think once this is all done and cleaned up\.\. you think I'll feel different\.\.\. I won't  but I think you will\.  I already told you that the other night\.\. I am just hoping it doesnt happen\.


---

### 523. msg_13607

**You** - 2025-05-25T22:00:12

This isn't a rebound\.\. it is a revelation\.


---

### 524. msg_13608

**You** - 2025-05-25T22:00:58

I think craig says this "It is like a come to jesus moment"  like I never realized\.\. A rebound is me feeling lonely and looking to fill a hole\.


---

### 525. msg_13609

**You** - 2025-05-25T22:01:49

The only\.\. yeah ok\.\. not saying that\.\. The loneliness I am trying to alleviate is my loneliness from you\.  I was fine before you came along and blew up my world\.


---

### 526. msg_13610

**You** - 2025-05-25T22:01:58

I wasn't looking to rebound or to meet anyone\.


---

### 527. msg_13611

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:02:14

Same…\. That’s for damn sure\.


---

### 528. msg_13612

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:02:33

I was getting ready to throw a “to hell with men” party


---

### 529. msg_13613

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:02:35

lol


---

### 530. msg_13614

**You** - 2025-05-25T22:02:41

well I wasn't there\.\.


---

### 531. msg_13615

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:02:50

Not sure what happened


---

### 532. msg_13616

**You** - 2025-05-25T22:02:48

but I sure as hell was not in a hurry


---

### 533. msg_13617

**You** - 2025-05-25T22:02:57

and I had zero confidence


---

### 534. msg_13618

**You** - 2025-05-25T22:03:06

so wasn't planning on looking anytime soon


---

### 535. msg_13619

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:04:20

Just looking at my calendar


---

### 536. msg_13620

**You** - 2025-05-25T22:04:24

Listen\.\. I am not worried about 4 months from now, or next year, or whenever\.\. at least not for me\.\. Again I cannot predict where you go or what you feel\.\. only that I want to do the best I can to be the only one you ever want to be with\.


---

### 537. msg_13621

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:04:39

I’m having a catch up with Haris g at 1pm to tell him \(not about you\)


---

### 538. msg_13622

**You** - 2025-05-25T22:04:38

I am worried about 2 weeks from now lol\.


---

### 539. msg_13623

**You** - 2025-05-25T22:04:59

well that should be an interesting conversation


---

### 540. msg_13624

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:05:15

Yeah…\.


---

### 541. msg_13625

**You** - 2025-05-25T22:05:22

I blocked my calendar\.


---

### 542. msg_13626

**You** - 2025-05-25T22:05:51

except for a few time slots this aft\.\. but you are opposite those so it works out well\.


---

### 543. msg_13627

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:06:58

So when you called me honesty “stark” or whatever, what did you mean?


---

### 544. msg_13628

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:07:08

I think you are more honest than me really


---

### 545. msg_13629

**You** - 2025-05-25T22:07:13

It isn't more or less


---

### 546. msg_13630

**You** - 2025-05-25T22:07:15

it is the delivery


---

### 547. msg_13631

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:07:20

I would say you are more that than me


---

### 548. msg_13632

**You** - 2025-05-25T22:07:29

it is very matter of factly\.


---

### 549. msg_13633

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:07:56

Oh I see, yeah I guess lol


---

### 550. msg_13634

**You** - 2025-05-25T22:07:58

You will say something that is true\.\. but I might frame it differently depending on who I am saying it to\.


---

### 551. msg_13635

**You** - 2025-05-25T22:08:09

or how I think they will receive it\.


---

### 552. msg_13636

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:08:13

\(Pauline\)


---

### 553. msg_13637

**You** - 2025-05-25T22:08:16

everyone


---

### 554. msg_13638

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:08:23

lol


---

### 555. msg_13639

**You** - 2025-05-25T22:08:21

That is how I deal with everyone


---

### 556. msg_13640

**You** - 2025-05-25T22:08:44

give me a second\.


---

### 557. msg_13641

**You** - 2025-05-25T22:15:04

just doing a little analysis


---

### 558. msg_13642

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:15:57

Looks like I’m on my own next weekend with the 8 girls


---

### 559. msg_13643

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:16:09

Just learned\. It’s ok


---

### 560. msg_13644

**You** - 2025-05-25T22:16:15

why I thought you were getting help


---

### 561. msg_13645

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:16:41

I just won’t be able to drink bc I will need to drive if there is an emergency… so it is actually a good thing\. I need to smarten up for a bit\.


---

### 562. msg_13646

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:17:01

>
Marlowe has another beach volleyball tourn, Maelle has work…


---

### 563. msg_13647

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:17:19

It’s good \- I’d rather be by myself honestly


---

### 564. msg_13648

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:17:30

I will have fun with the girls


---

### 565. msg_13649

**You** - 2025-05-25T22:18:27

I am sure you will\.


---

### 566. msg_13650

**You** - 2025-05-25T22:19:15

>
ROFL


---

### 567. msg_13651

**You** - 2025-05-25T22:19:35

>
I can't lol \.\.


---

### 568. msg_13652

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:20:35

What


---

### 569. msg_13653

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:20:38

Stop


---

### 570. msg_13654

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:20:40

lol


---

### 571. msg_13655

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:20:47

You don’t believe in me?


---

### 572. msg_13656

**You** - 2025-05-25T22:20:48

HAHAHAH


---

### 573. msg_13657

**You** - 2025-05-25T22:20:52

are you kidding me\.


---

### 574. msg_13658

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:21:00

LOL


---

### 575. msg_13659

**You** - 2025-05-25T22:20:58

that is what you think


---

### 576. msg_13660

**You** - 2025-05-25T22:21:05

Ok\.\. rewind\.\.


---

### 577. msg_13661

**You** - 2025-05-25T22:21:19

earlier today\.\. I gotta get my shit together\.\. etc etc \.\.\.


---

### 578. msg_13662

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:21:26

If something happens to one of the girls I have to drive to hospital in Huntsville\. I cannot be drunk


---

### 579. msg_13663

**You** - 2025-05-25T22:21:26

first thing you observe about the situation\.


---

### 580. msg_13664

**You** - 2025-05-25T22:21:29

damn I can't drink


---

### 581. msg_13665

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:21:36

lol


---

### 582. msg_13666

**You** - 2025-05-25T22:21:35

ROFLROFL RO


---

### 583. msg_13667

**You** - 2025-05-25T22:21:36

fbjvsdvbsjlb


---

### 584. msg_13668

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:22:01

Well no more thc is getting my shit together FIRST


---

### 585. msg_13669

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:22:05

Primarily


---

### 586. msg_13670

**You** - 2025-05-25T22:22:15

AHHH\.\.


---

### 587. msg_13671

**You** - 2025-05-25T22:22:17

so clarity


---

### 588. msg_13672

**You** - 2025-05-25T22:22:25

this is a step by step process


---

### 589. msg_13673

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:22:38

Now you are getting it


---

### 590. msg_13674

**You** - 2025-05-25T22:22:49

I mean\.\. it would be like too much to just go clean right away\.\. I get it\.


---

### 591. msg_13675

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:23:04

I will be next weekend\!


---

### 592. msg_13676

**You** - 2025-05-25T22:23:06

10$ says a shit ton of thc this weekend\.


---

### 593. msg_13677

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:23:24

What? No not even bringing any


---

### 594. msg_13678

**You** - 2025-05-25T22:23:26

it will be there\.


---

### 595. msg_13679

**You** - 2025-05-25T22:23:27

lol


---

### 596. msg_13680

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:23:32

I need to be ready to drive


---

### 597. msg_13681

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:23:53

I will be responsible for 8 girls


---

### 598. msg_13682

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:23:58

It’s stressing me out


---

### 599. msg_13683

**You** - 2025-05-25T22:24:03

there will be 9 girls there that weekend


---

### 600. msg_13684

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:24:15

Mac says 8


---

### 601. msg_13685

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:24:19

I thought 9


---

### 602. msg_13686

**You** - 2025-05-25T22:24:20

9


---

### 603. msg_13687

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:24:23

She says 8


---

### 604. msg_13688

**You** - 2025-05-25T22:24:23

I say 9


---

### 605. msg_13689

**You** - 2025-05-25T22:24:38

You\.\.


---

### 606. msg_13690

**You** - 2025-05-25T22:24:40

gawd


---

### 607. msg_13691

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:24:44

😜


---

### 608. msg_13692

**You** - 2025-05-25T22:24:45

eesh


---

### 609. msg_13693

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:25:01

I am not a girl, ADULT


---

### 610. msg_13694

**You** - 2025-05-25T22:25:04

mmmmmmhmmmmm


---

### 611. msg_13695

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:25:09

RESPONSIBLE ADULT IN CHARGE


---

### 612. msg_13696

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:25:17

😇


---

### 613. msg_13697

**You** - 2025-05-25T22:25:25

kk I stand by my statement\.\. and keeping expectations right where I think they should be\.


---

### 614. msg_13698

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:25:45

You could come up and help me


---

### 615. msg_13699

**You** - 2025-05-25T22:25:46

no


---

### 616. msg_13700

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:25:53

Haha


---

### 617. msg_13701

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:26:11

That was a quick no


---

### 618. msg_13702

**You** - 2025-05-25T22:26:36

stark wasn't the word I should have used\.\. but the analysis did suggest that when faced with challenges or constraints\.\. your communication style and well\.\. behaviour\.\. can be very direct, abrupt, and practical\.


---

### 619. msg_13703

**You** - 2025-05-25T22:26:56

your suggestion was a joke\.\. so the no was easy


---

### 620. msg_13704

**You** - 2025-05-25T22:28:33

Reaction: 😂 from Meredith Lamb
anyhow I will monitor this shift to adulthood with interest\.  Like I said\.\. you shouldn't make promises\.


---

### 621. msg_13705

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:28:55

It was a joke only because it would be risky\. Andrew feels guilty not going bc Mac wanted him there so might show up


---

### 622. msg_13706

**You** - 2025-05-25T22:29:21

risky because there are 8 girls there\.\. Meredith\.\. I wasn't thinking about Andrew jesus\.


---

### 623. msg_13707

**You** - 2025-05-25T22:29:35

you gonna keep me hidden in the boathouse?


---

### 624. msg_13708

**You** - 2025-05-25T22:29:36

lol


---

### 625. msg_13709

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:29:42

>
They wouldn’t care\.


---

### 626. msg_13710

**You** - 2025-05-25T22:29:54

holy shit\.\. no\.\. I wouldn't do that\.


---

### 627. msg_13711

**You** - 2025-05-25T22:30:05

Someday yeah


---

### 628. msg_13712

**You** - 2025-05-25T22:30:16

Reaction: 🙄 from Meredith Lamb
now \.\. absolutely not\.\.


---

### 629. msg_13713

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:30:26

>
I think I communicate this way even when not challenged\.


---

### 630. msg_13714

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:31:04

Direct, abrupt and practical


---

### 631. msg_13715

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:31:05

Wow


---

### 632. msg_13716

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:31:07

lol


---

### 633. msg_13717

**You** - 2025-05-25T22:31:05

well\.\. when you dismissed my attempts to connect\.\. a couple of times\.\. that was what I was trying to say earlier\.\. they don't mean anything to you\.\. or at least that is how it comes accross\.\. whereas they do for me\.


---

### 634. msg_13718

**You** - 2025-05-25T22:31:14

you had asked for an example earlier\.


---

### 635. msg_13719

**You** - 2025-05-25T22:31:25

it is why I said I was going to stop


---

### 636. msg_13720

**You** - 2025-05-25T22:31:51

it is why I still think tomorrow  or tuesday is a bad idea


---

### 637. msg_13721

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:31:59

It’s not that it doesn’t MEAN anything to me\. The logistics are more challenging for me than you\. You are up and awake and feeling great\. I’m asleep and in a fog\.


---

### 638. msg_13722

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:32:22

Nope tomorrow I am getting up early and making my coffee


---

### 639. msg_13723

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:32:28

lol


---

### 640. msg_13724

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:32:32

Committed


---

### 641. msg_13725

**You** - 2025-05-25T22:32:41

I think it feels like I want it more meredith\.\. I guess that is me being completely honest\.  kk\.\. nothing held back\.


---

### 642. msg_13726

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:33:07

Want “it” more…


---

### 643. msg_13727

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:33:16

Like this relationship?


---

### 644. msg_13728

**You** - 2025-05-25T22:33:16

no no'


---

### 645. msg_13729

**You** - 2025-05-25T22:33:19

fack


---

### 646. msg_13730

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:33:25

You can’t make that assumption


---

### 647. msg_13731

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:33:27

K good


---

### 648. msg_13732

**You** - 2025-05-25T22:33:25

no no


---

### 649. msg_13733

**You** - 2025-05-25T22:33:34

to be with you\.\. any way any time that I can\.


---

### 650. msg_13734

**You** - 2025-05-25T22:33:39

anywhere lol


---

### 651. msg_13735

**You** - 2025-05-25T22:33:40

even


---

### 652. msg_13736

**You** - 2025-05-25T22:33:51

just that\.\. not the relationship


---

### 653. msg_13737

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:34:10

Maybe, just maybe you have more morning energy than me and it is that simple\.


---

### 654. msg_13738

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:34:26

But I am going to turn back into a morning person


---

### 655. msg_13739

**You** - 2025-05-25T22:34:25

anyways\.\. I didn't want to dig into this\.\. not morning meredith\.\. morning\.\. after work\.\. anywhere any time\.


---

### 656. msg_13740

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:34:33

It will take some time tho


---

### 657. msg_13741

**You** - 2025-05-25T22:34:45

its fine\.\. I just want to be clear\.\. that is why I was pulling back\.


---

### 658. msg_13742

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:35:04

I know…


---

### 659. msg_13743

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:35:43

So what was your most recent analysis


---

### 660. msg_13744

**You** - 2025-05-25T22:35:45

It isn't top of mind for you\.\. you don't have the same need I do\.\. or it affects you negatively\. as I learned\.\. it isn't just the morning thing\.\. it is feeling like I am desprate or begging etc


---

### 661. msg_13745

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:35:49

🤔


---

### 662. msg_13746

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:36:45

>
I absolutely have the same need\. You don’t realize the time spent thinking about you/us before bed, in the morning, watching tv, driving etc etc


---

### 663. msg_13747

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:36:50

It’s constant


---

### 664. msg_13748

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:37:06

I just would prefer extended time


---

### 665. msg_13749

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:37:25

But beggars can’t be choosers\. I know


---

### 666. msg_13750

**You** - 2025-05-25T22:38:21

I get it\.\. I am not trying to make you feel anything or defend\.\. etc\.\. I just wanted to be completely honest\.\. there is nothing left to tell there now\.\. it is all out\.


---

### 667. msg_13751

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:39:59

Well I’m glad you were honest\. Next time just be more abrupt, direct and practical 🙃


---

### 668. msg_13752

**You** - 2025-05-25T22:40:20

If I were to do that\.\. it would come across as pushy and demanding\.


---

### 669. msg_13753

**You** - 2025-05-25T22:40:37

so I will just try to give you everything early on\.\.


---

### 670. msg_13754

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:41:16

I honestly don’t care if you are pushy and demanding sometimes\. Just not all the time\. You are allowed to be sometimes you know\.


---

### 671. msg_13755

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:41:36

Just means I might be occasionally


---

### 672. msg_13756

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:41:38

lol


---

### 673. msg_13757

**You** - 2025-05-25T22:42:34

Yeah no\.\. I think I will stick with being cautious\.\. and hesitant\.\. I tried to explain to you how it feels to me earlier\.\. it isn't your fault\.\. but right now that is how I feel\.


---

### 674. msg_13758

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:48:26

Cautious and hesitant is how you have to speak to me? 🙁


---

### 675. msg_13759

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:48:39

Stoooooop


---

### 676. msg_13760

**You** - 2025-05-25T22:51:53

it is\.\. I always think about what I say\.\. but I do that anyways\.\. I mean I am not just gonna throw out there


---

### 677. msg_13761

**You** - 2025-05-25T22:51:59

hey let's do this and this maybe later\.\.


---

### 678. msg_13762

**You** - 2025-05-25T22:52:00

lol


---

### 679. msg_13763

**You** - 2025-05-25T22:52:19

the No's pile up I told you\.\. better to not hope, not ask, not expect


---

### 680. msg_13764

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:52:59

But in terms of just speaking to me in general…\.


---

### 681. msg_13765

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:53:03

Like not asking stuff


---

### 682. msg_13766

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:53:13

The no’s have NOT piled up


---

### 683. msg_13767

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:53:19

Btw


---

### 684. msg_13768

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:53:22

They have not


---

### 685. msg_13769

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:53:27

We have done a lot


---

### 686. msg_13770

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:53:38

There have been a couple of no’s


---

### 687. msg_13771

**You** - 2025-05-25T22:54:05

see\.\. this is why I don't do this\.\. lol I don't want to fight\.\. I wasn't talking about our weekends\.\. that have been magical\.\. but have happened out of suggestions you have made right\.


---

### 688. msg_13772

**You** - 2025-05-25T22:54:10

all of them


---

### 689. msg_13773

**You** - 2025-05-25T22:54:29

Our dates\.\. happened at your suggestion\.


---

### 690. msg_13774

**You** - 2025-05-25T22:54:34

lol


---

### 691. msg_13775

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:54:40

I’m not fighting\. Just saying practically


---

### 692. msg_13776

**You** - 2025-05-25T22:54:38

I am not sure if you remember


---

### 693. msg_13777

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:54:54

And they were all good suggestions


---

### 694. msg_13778

**You** - 2025-05-25T22:55:08

I had a bigger hand in Detroit\.\. but when I say knows\.\. I say things I suggest or ask for Mer\.


---

### 695. msg_13779

**You** - 2025-05-25T22:55:09

lol


---

### 696. msg_13780

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:55:18

Rc show wasn’t me


---

### 697. msg_13781

**You** - 2025-05-25T22:55:15

no's


---

### 698. msg_13782

**You** - 2025-05-25T22:55:17

not knows


---

### 699. msg_13783

**You** - 2025-05-25T22:55:46

like I am ok if you disagree\.\. it is all good\.\. I am overly sensitive we have established this


---

### 700. msg_13784

**You** - 2025-05-25T22:56:02

I was just trying to explain what I mean by cautious and hesitant


---

### 701. msg_13785

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:56:16

Just to be clear you are talking about g about the park stuff only right?


---

### 702. msg_13786

**You** - 2025-05-25T22:56:33

yeah park or after work\.\. I think there were a few more things\.\. not sure\.\.


---

### 703. msg_13787

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:57:13

k…


---

### 704. msg_13788

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:57:20

I deleted some of that lol


---

### 705. msg_13789

**You** - 2025-05-25T22:57:20

>
uh oh\.


---

### 706. msg_13790

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:57:34

Didn’t want to be too abrupt


---

### 707. msg_13791

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:57:36

Haha


---

### 708. msg_13792

**You** - 2025-05-25T22:57:33

yeah figured\.\.


---

### 709. msg_13793

**You** - 2025-05-25T22:57:37

felt like a delete


---

### 710. msg_13794

**You** - 2025-05-25T22:57:47

just be abrupt


---

### 711. msg_13795

**You** - 2025-05-25T22:57:48

pls


---

### 712. msg_13796

**You** - 2025-05-25T22:57:54

in this situation it won't bother me\.


---

### 713. msg_13797

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:58:34

I was just going to give an excuse and I’d rather not\. I think your feelings on this are completely normal


---

### 714. msg_13798

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:58:46

And you aren’t being overly sensitive


---

### 715. msg_13799

**You** - 2025-05-25T22:58:57

why not the excuse


---

### 716. msg_13800

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:59:13

I’m actually happy that you want to spend time together


---

### 717. msg_13801

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T22:59:17

Would suck if you didn’t


---

### 718. msg_13802

**You** - 2025-05-25T23:00:01

I know\.\. and I will continue to want to\.\. but I am not going to ask anymore\.\. I told you that Thursday\.\. or at least tried to tell you\.\. you were in a mode on Thursday\.


---

### 719. msg_13803

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:00:22

My brother is an ass\.

*1 attachment(s)*


---

### 720. msg_13804

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:01:27

I was…


---

### 721. msg_13805

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:02:07

I felt something building, coming and then bam, woke up the next morning to it


---

### 722. msg_13806

**You** - 2025-05-25T23:03:26

kk well like I said\.\. don't take my lack of asking the wrong way\.\. my cautious and hesitant approach continues\.


---

### 723. msg_13807

**You** - 2025-05-25T23:03:30

glad we are in agreement


---

### 724. msg_13808

**You** - 2025-05-25T23:03:32

:\)


---

### 725. msg_13809

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:03:36

>
I was going to say after work is near impossible for me bc of kids and driving etc\. and then it felt like an excuse\. Because it probably is…


---

### 726. msg_13810

**You** - 2025-05-25T23:03:34

that was easy


---

### 727. msg_13811

**You** - 2025-05-25T23:03:44

oh shit\.\. the analysis


---

### 728. msg_13812

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:04:07

Andrew keeps packing our schedule with more volleyball


---

### 729. msg_13813

**You** - 2025-05-25T23:04:14

wait I have to cross reference


---

### 730. msg_13814

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:04:21

He comes in and is like Marlowe has some vball thing thurs


---

### 731. msg_13815

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:04:25

Why tell me?\!


---

### 732. msg_13816

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:04:30

I will be at cottage


---

### 733. msg_13817

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:05:00

I was all “why do you commit to things when you don’t even know if YOU can go?” He thinks I can do everything and just jump when told


---

### 734. msg_13818

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:05:20

So my after work nights are a mess right now


---

### 735. msg_13819

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:05:32

So unpredictable and I get told to just drive here and there


---

### 736. msg_13820

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:06:03

Tonight I get told Maelle is on some team in June now and I’m like “why can’t we have a break?\!”


---

### 737. msg_13821

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:06:05

Omg


---

### 738. msg_13822

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:06:13

It’s so annoying


---

### 739. msg_13823

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:06:28

>
Cross reference what?


---

### 740. msg_13824

**You** - 2025-05-25T23:06:26

kk I can appreciate that\.\.


---

### 741. msg_13825

**You** - 2025-05-25T23:07:56

just something I was looking into\.


---

### 742. msg_13826

**You** - 2025-05-25T23:11:04

kk I think it is bed time\.


---

### 743. msg_13827

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:10:50

Which was…\.


---

### 744. msg_13828

**You** - 2025-05-25T23:13:12

I was looking at our back and forth engagements over the last few months\.


---

### 745. msg_13829

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:14:22

k you can tell me about it in the morning :\) message me time and address\.


---

### 746. msg_13830

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:14:30

I should go to bed too


---

### 747. msg_13831

**You** - 2025-05-25T23:14:28

Okay, I've gone through your conversation with Meredith to identify and count the instances where you suggested connecting \(meeting, talking, etc\.\) and her response could be categorized as a rebuff \(a "no" to your immediate request, even if with a reason\) or non\-committal \(vague, deflecting, or an indefinite postponement\)\.
Here are the instances documented in chronological order:
Monday, April 14, 2025 \(\[snippet\_3\]\)
Your Suggestion: You asked if she was busy tomorrow and stated, "I want to see you\."
Meredith's Initial Response: "Depends," and then "You do? Why\."
Analysis: Her initial responses were probing and could be perceived as non\-committal or making you justify your desire before she eventually said, "I want to see you too\. No plans yet\." While this ultimately led to a positive indication for meeting, the initial replies were not a straightforward affirmation\.
Tuesday, April 15, 2025 \(\[snippet\_4\]\)
Your Suggestion: After she expressed it was hard not to see you, you offered, "I ca\.\.\. \[truncated\]


---

### 748. msg_13832

**You** - 2025-05-25T23:14:36

you can read it\.\. I am going to bed too\.\.


---

### 749. msg_13833

**You** - 2025-05-25T23:14:47

it isn't super accurate I think\.\.


---

### 750. msg_13834

**You** - 2025-05-25T23:16:08

Terraview Park Park on side of road after bridge near Caevhill Crescent\.


---

### 751. msg_13835

**You** - 2025-05-25T23:16:37

I will likely be there before 8 am not sure how much\.\. but you can just get there whenever\.


---

### 752. msg_13836

**You** - 2025-05-25T23:18:03

This is when I run away


---

### 753. msg_13837

**You** - 2025-05-25T23:18:07

zzzzzzzzzz


---

### 754. msg_13838

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:18:12

Wow I don’t even remember some of those


---

### 755. msg_13839

**You** - 2025-05-25T23:18:16

I remember all of them


---

### 756. msg_13840

**You** - 2025-05-25T23:18:19

lol


---

### 757. msg_13841

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:18:23

k, we can address this later\. Lol


---

### 758. msg_13842

**You** - 2025-05-25T23:18:26

sure we can


---

### 759. msg_13843

**You** - 2025-05-25T23:18:31

you know


---

### 760. msg_13844

**You** - 2025-05-25T23:18:43

the next time I do this analysis\.\. it is going to pick up on your response as another deflection


---

### 761. msg_13845

**You** - 2025-05-25T23:18:46

Reaction: 😂 from Meredith Lamb
just saying lol


---

### 762. msg_13846

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:19:10


*1 attachment(s)*


---

### 763. msg_13847

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:19:41

Mon may 12 you asked this?\!


---

### 764. msg_13848

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:20:11

That confuses me and it isn’t the only one


---

### 765. msg_13849

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:20:36


*1 attachment(s)*


---

### 766. msg_13850

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:20:53

Another confusing one


---

### 767. msg_13851

**You** - 2025-05-25T23:21:46



---

### 768. msg_13876

**You** - 2025-05-25T23:21:52

read that\.\. it is an actual


---

### 769. msg_13877

**You** - 2025-05-25T23:21:53

chat


---

### 770. msg_13878

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:22:02

k, will go to bed and talk later\. I need to look at my calendar and reconcile some of this lol


---

### 771. msg_13879

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:23:53

>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
I do remember this one


---

### 772. msg_13880

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:24:09

I get your point now…\.


---

### 773. msg_13881

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:26:05

k go to bed now \- you have to get up early


---

### 774. msg_13882

**You** - 2025-05-25T23:26:11

I love you Mer\.\. I wish I wasn't like this\.\. have a good night


---

### 775. msg_13883

**Meredith Lamb \(\+14169386001\)** - 2025-05-25T23:26:42

I love you too and I like you the way you are xoxoxo


---

### 776. msg_13884

**You** - 2025-05-26T04:36:11

Well off to the gym\.  Cya later\.


---

### 777. msg_13885

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T06:17:59

I’m getting up on time today\. 🎉


---

### 778. msg_13886

**You** - 2025-05-26T06:29:54

ROFL I hope you are feeling ok\.


---

### 779. msg_13887

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T06:42:33

I’m good\. I hope 2 recovery days was all I needed from Friday night\. :p


---

### 780. msg_13888

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T06:42:38

Good lord\.


---

### 781. msg_13889

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T06:51:43

I feel like I need to wear jeans if I’m going to be sitting in a park lol


---

### 782. msg_13890

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T06:51:53

🤔


---

### 783. msg_13891

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T07:07:04

In rare fashion I’m basically almost ready to go\. Am going to pack my stuff, stop for coffee but pretty much ready few minutes early


---

### 784. msg_13892

**You** - 2025-05-26T07:30:40

Heading out now should\. R there at 8


---

### 785. msg_13893

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T07:36:02

Should be similar


---

### 786. msg_13894

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T07:55:19

No idea where to park


---

### 787. msg_13895

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T07:56:11

I’m at penworth and caehville cres


---

### 788. msg_13896

**You** - 2025-05-26T07:56:59

I am just walking in


---

### 789. msg_13897

**You** - 2025-05-26T09:55:35

See not sus at all\.


---

### 790. msg_13898

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:23:16

You are going to have to tell Carolyn what is going on with you


---

### 791. msg_13899

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:23:20

She is going crazy


---

### 792. msg_13900

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:23:33

She knows something is wrong but doesn’t know what


---

### 793. msg_13901

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:23:45

She is wondering if she is driving you crazy


---

### 794. msg_13902

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:23:49

Not even kidding


---

### 795. msg_13903

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:24:12

Just tell her already pleassssse


---

### 796. msg_13904

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:28:37

Finally told all my friends today\. Not sure why I procrastinated on that…


---

### 797. msg_13905

**You** - 2025-05-26T10:36:34

Kk


---

### 798. msg_13906

**You** - 2025-05-26T10:38:42

Going to address
It now\.\. is Jim in today?


---

### 799. msg_13907

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:39:17

No he took vacay today to recover from jet lag\. Forgot\. He mentioned that


---

### 800. msg_13908

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T10:40:06

You didn’t have to address it ASAP\. Geez\. She goes “you didn’t tell him?”


---

### 801. msg_13909

**You** - 2025-05-26T11:06:00

All done


---

### 802. msg_13910

**You** - 2025-05-26T11:06:17

And by the way do you want to know how it ended?


---

### 803. msg_13911

**You** - 2025-05-26T11:06:51

She said she had some single friends in their 40’s that are also separated\.\. so yeah…… now there is that


---

### 804. msg_13912

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:07:00

LOL


---

### 805. msg_13913

**You** - 2025-05-26T11:07:08

I said yeah that is a ways off\.\.


---

### 806. msg_13914

**You** - 2025-05-26T11:07:29

Should be interesting right?


---

### 807. msg_13915

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:08:00

Super interesting:p


---

### 808. msg_13916

**You** - 2025-05-26T11:09:00

Maybe you wish I hadn’t told her now?? 😝


---

### 809. msg_13917

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:09:38

I was just like “put her out of her misery” lol


---

### 810. msg_13918

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:09:45

But man you did it quick


---

### 811. msg_13919

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:09:52

Now she knows I told you to tell her


---

### 812. msg_13920

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:12:26

Did she seem relieved?


---

### 813. msg_13921

**You** - 2025-05-26T11:26:34

She was


---

### 814. msg_13922

**You** - 2025-05-26T11:26:38

Very much so relieved


---

### 815. msg_13923

**You** - 2025-05-26T11:27:04

I think she will be able to focus more now on work, and in who she wants to set me up with


---

### 816. msg_13924

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:27:21

That’s good\. I could tell she was going nuts not knowing


---

### 817. msg_13925

**You** - 2025-05-26T11:27:44

Yeah I could tell too I was going to wait for a bit though\.\. but thank you for the push\.


---

### 818. msg_13926

**You** - 2025-05-26T11:28:07

You doing ok today\.


---

### 819. msg_13927

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:29:09

Yeah I’m okay\. You?


---

### 820. msg_13928

**You** - 2025-05-26T11:29:32

I am fine\.\. but be honest I was worried this morning would make your day worse


---

### 821. msg_13929

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:30:01

No it has not\. It was nice 😊


---

### 822. msg_13930

**You** - 2025-05-26T11:30:40

Ok good I am glad it worked out then and did not mess your day up\.\. and I agree I really enjoyed it\.\. a bit of reality before we go back to faking\.


---

### 823. msg_13931

**You** - 2025-05-26T11:30:44

Thank you\.


---

### 824. msg_13932

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:36:42

I am sorry I was dismissing your suggestions so many times\. I didn’t realize\. Life felt fast so I didn’t fully notice tbh\.


---

### 825. msg_13933

**You** - 2025-05-26T11:40:40

Mer it is fine\.\. I don’t expect some massive change because of this I am just glad we got to do it once\.


---

### 826. msg_13934

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:46:41

Reaction: ❤️ from Scott Hicks
It’s not fine for me to ignore you like that\. \(I do think the ai 12x is overstated but no matter the number…\. not great\.\) I will do better ❤️❤️


---

### 827. msg_13935

**You** - 2025-05-26T11:47:43

Pls don’t put any more pressure on yourself\.\.  not my intent I just wanted you to understand where I was coming from and not misinterpret it as losing interest or pulling away in some other form\.


---

### 828. msg_13936

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:53:13

Totally understand now\. Really wasn’t seeing it before\.


---

### 829. msg_13937

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:55:09

And all my friends know now… at least officially\. They were probably all gossiping behind my back because 3 knew\.


---

### 830. msg_13938

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:55:13

lol


---

### 831. msg_13939

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:55:18

I’m ok with that


---

### 832. msg_13940

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:55:41

Didn’t say anything about you to the extended group but 3 know


---

### 833. msg_13941

**You** - 2025-05-26T11:55:42

I have still haven’t told many in my family out of respect for Jaimie\.


---

### 834. msg_13942

**You** - 2025-05-26T11:55:49

Because they are back in Moncton


---

### 835. msg_13943

**You** - 2025-05-26T11:55:58

And they will torment her and bug her


---

### 836. msg_13944

**You** - 2025-05-26T11:56:07

We will be letting people know in coming weeks


---

### 837. msg_13945

**You** - 2025-05-26T11:56:14

I don’t have any other close friends to tell


---

### 838. msg_13946

**You** - 2025-05-26T11:56:33

I have only told Mike Katie and John about you\.


---

### 839. msg_13947

**You** - 2025-05-26T11:56:38

Oh and my family of course


---

### 840. msg_13948

**You** - 2025-05-26T11:56:41

lol


---

### 841. msg_13949

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:56:52

I have to tell this mom group I get together with… ugh


---

### 842. msg_13950

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T11:56:58

Haven’t yet


---

### 843. msg_13951

**You** - 2025-05-26T11:57:06

Should be easy enough\.\.


---

### 844. msg_13952

**You** - 2025-05-26T11:57:15

So glad I have no social life sometimes


---

### 845. msg_13953

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T12:04:09

I hate the pity messages tho\.

*1 attachment(s)*


---

### 846. msg_13954

**You** - 2025-05-26T12:29:05

lol looked like you were cranky when you walked by maybe this was why lol


---

### 847. msg_13955

**You** - 2025-05-26T12:29:38

Just helping Michelle with some gpt stuff\.


---

### 848. msg_13956

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T12:30:18

I think I’m getting a sore throat\. Carolyn gave me an emergen\-C for my water lol


---

### 849. msg_13957

**You** - 2025-05-26T12:30:35

I have this losanges yku
Liked in here


---

### 850. msg_13958

**You** - 2025-05-26T12:30:44

If you want to come in I can sneak some to you


---

### 851. msg_13959

**You** - 2025-05-26T12:31:04

I do not have a sore throat at all for the record\.\.


---

### 852. msg_13960

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T12:35:34

>
Give it a couple days


---

### 853. msg_13961

**You** - 2025-05-26T12:37:16

I guess I need to hit the vitamin c too\.\.


---

### 854. msg_13962

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T12:42:27

I’m not even 100% sure and Carolyn was like “here take this\!”


---

### 855. msg_13963

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T12:42:30

lol


---

### 856. msg_13964

**You** - 2025-05-26T12:55:30

Heh


---

### 857. msg_13965

**You** - 2025-05-26T14:01:18

Hope haris is doing well


---

### 858. msg_13966

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:05:03

Super frustrated with Deb but good otherwise\.


---

### 859. msg_13967

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:05:37

We hadn’t caught up in a while so had a good chat


---

### 860. msg_13968

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:06:03

He’s happy I’m going back lol he’s like “maybe you can help me with all this res crap”


---

### 861. msg_13969

**You** - 2025-05-26T14:06:09

Yeah I know he is pissed at dev


---

### 862. msg_13970

**You** - 2025-05-26T14:06:12

Deb


---

### 863. msg_13971

**You** - 2025-05-26T14:07:27

How did he react to your situation?


---

### 864. msg_13972

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:09:22

In a very Haris way 🙂


---

### 865. msg_13973

**You** - 2025-05-26T14:11:19

lol I will let you explain that later


---

### 866. msg_13974

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:18:41

You know Haris… very calm and respectful\.


---

### 867. msg_13975

**You** - 2025-05-26T14:41:14

I feel guilty about not telling bailey\. Ow these are my people\.


---

### 868. msg_13976

**You** - 2025-05-26T14:41:20

Arghhhhh


---

### 869. msg_13977

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:43:11

Telling Bailey about your separation?


---

### 870. msg_13978

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:43:18

You should feel guilty


---

### 871. msg_13979

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:43:24

I told her about mine


---

### 872. msg_13980

**You** - 2025-05-26T14:45:24

She is like my person for all things emotionally horrible we share everything


---

### 873. msg_13981

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T14:45:32

At least you told Carolyn\. I think you were causing her undue stress


---

### 874. msg_13982

**You** - 2025-05-26T14:45:32

I feel really bad I am telling her


---

### 875. msg_13983

**You** - 2025-05-26T14:45:43

Yeah well I didn’t mean to


---

### 876. msg_13984

**You** - 2025-05-26T15:15:46

Ok all done I can stop for a while\.


---

### 877. msg_13985

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T15:47:43

Stop what?


---

### 878. msg_13986

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T15:47:50

Telling ppl? Lol


---

### 879. msg_13987

**You** - 2025-05-26T15:48:15

Yeah\.\. I am exhausted\. Cancelled my meeting with haris


---

### 880. msg_13988

**You** - 2025-05-26T15:48:25

Couldn’t deal with him today


---

### 881. msg_13989

**You** - 2025-05-26T16:47:34

Going over very curious as to what Yolanda wants\.


---

### 882. msg_13990

**You** - 2025-05-26T18:30:23

Srry not trying to come down just worried about you\.


---

### 883. msg_13991

**You** - 2025-05-26T18:31:31

Will leave it alone\.\. I love you just the way you are anyways\.


---

### 884. msg_13992

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:36:07

>
? Not trying to come down?


---

### 885. msg_13993

**You** - 2025-05-26T18:37:01

I felt like I was being a sick about the drinking\.\. I should just shut up


---

### 886. msg_13994

**You** - 2025-05-26T18:37:38

None of my business anyways\.


---

### 887. msg_13995

**You** - 2025-05-26T18:38:07

Again sry\.\. can’t help it sometimes lol big mouth\.


---

### 888. msg_13996

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:38:35

It’s fine\. I’m completely aware that I’ve been going overboard\. Lol


---

### 889. msg_13997

**You** - 2025-05-26T18:40:39

Still I don’t need to pile on


---

### 890. msg_13998

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:40:50

I actually asked ChatGPT the other day why I do this and others don’t\. Lol


---

### 891. msg_13999

**You** - 2025-05-26T18:40:58

I am part of the reason for the stress you are dealing with anyways


---

### 892. msg_14000

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:40:59

Didn’t tell me anything I didn’t already know\.


---

### 893. msg_14001

**You** - 2025-05-26T18:41:31

I might do it if I wasn’t so focused on getting in shape… even low calorie alcohol can mess up a plan


---

### 894. msg_14002

**You** - 2025-05-26T18:41:38

That and I get addicted to shit


---

### 895. msg_14003

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:42:13

>
Possibly…\. \(That wasn’t abrupt was it? 😜\)


---

### 896. msg_14004

**You** - 2025-05-26T18:42:54

Nope just the truth lol I feel bad but i cannot help it\.


---

### 897. msg_14005

**You** - 2025-05-26T18:43:08

You could tell me to go away if it is too
Much you know\.


---

### 898. msg_14006

**You** - 2025-05-26T18:43:17

😜


---

### 899. msg_14007

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:45:20

Suuure


---

### 900. msg_14008

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:45:39

That definitely sounds LESS stressful


---

### 901. msg_14009

**You** - 2025-05-26T18:46:41

I mean less obligations


---

### 902. msg_14010

**You** - 2025-05-26T18:46:52

Less juggling


---

### 903. msg_14011

**You** - 2025-05-26T18:47:42

But I mean you are used to that what is one more thing 🙂


---

### 904. msg_14012

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:49:03

>
Omg just stop


---

### 905. msg_14013

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:49:05

lol


---

### 906. msg_14014

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:49:22

My stress is not obligation


---

### 907. msg_14015

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:49:29

Like not even close


---

### 908. msg_14016

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:50:48

My stress is not being able to be with you, not being able to work with you, secrecy secrecy secrecy, your family finding out


---

### 909. msg_14017

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:50:53

That’s about it


---

### 910. msg_14018

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:50:56

Minimal


---

### 911. msg_14019

**You** - 2025-05-26T18:51:16

I was joking mer\.\.


---

### 912. msg_14020

**You** - 2025-05-26T18:51:31

This the last sentence


---

### 913. msg_14021

**You** - 2025-05-26T18:51:38

Thus\.


---

### 914. msg_14022

**You** - 2025-05-26T18:51:56

>
I know will be over soon


---

### 915. msg_14023

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:52:07

I know\. I just felt like listing it out to refresh myself actually\.


---

### 916. msg_14024

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:52:21

Because that is only the stress related to us\.


---

### 917. msg_14025

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:52:27

Not to mention the rest


---

### 918. msg_14026

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:57:18

Biggest stress right now: can I get a settlement agreement before Andrew finds out


---

### 919. msg_14027

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:58:23

And: did I ruin my rep at work through all this


---

### 920. msg_14028

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T18:58:42

And: can I afford a place to rent in my area


---

### 921. msg_14029

**You** - 2025-05-26T18:59:18

Ruin your reputation?


---

### 922. msg_14030

**You** - 2025-05-26T18:59:23

That is manageable


---

### 923. msg_14031

**You** - 2025-05-26T18:59:27

Easily


---

### 924. msg_14032

**You** - 2025-05-26T18:59:45

Andrew won’t find out\. At least not from my side for sure


---

### 925. msg_14033

**You** - 2025-05-26T19:00:19

Did you have a hard time working with me today?


---

### 926. msg_14034

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T19:08:57

>
Omg you just jinxed it\.


---

### 927. msg_14035

**You** - 2025-05-26T19:09:05

No I didn’t


---

### 928. msg_14036

**You** - 2025-05-26T19:09:11

I have been saying that for days


---

### 929. msg_14037

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T19:09:21

>
Today was fine but the last month or so has been difficult\.


---

### 930. msg_14038

**You** - 2025-05-26T19:09:43

Reaction: 😂 from Meredith Lamb
Well only one thing was different 😛


---

### 931. msg_14039

**You** - 2025-05-26T19:09:49

Glad it went well


---

### 932. msg_14040

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T19:15:26

>
Yes, you win\.


---

### 933. msg_14041

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T19:15:33

I will give you this one\.


---

### 934. msg_14042

**You** - 2025-05-26T19:16:36

I appreciate that


---

### 935. msg_14043

**You** - 2025-05-26T19:16:57

Will take all the wins I can get\.\. you are a tough nut to get wins by\.


---

### 936. msg_14044

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T19:17:12

You deserve it I guess\.


---

### 937. msg_14045

**You** - 2025-05-26T19:17:52

I only see you deserve it\.\. rest is fuzzy\.


---

### 938. msg_14046

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T20:28:07

Driving done\. Dog walking done\. Making some neocitran for my throat and then watching documentary in bed\.


---

### 939. msg_14047

**You** - 2025-05-26T20:29:58

Nice had to run to get carts for Gracie


---

### 940. msg_14048

**You** - 2025-05-26T20:30:02

Heading home now


---

### 941. msg_14049

**You** - 2025-05-26T21:12:44

suspect you will be asleep soon if you aren't already\.\. Have a good night\.\. I will be up tomorrow same routine as always now\.\. will see you when I see you\.\. hope you get some rest\.


---

### 942. msg_14050

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T21:16:05

You doing your application tonight?


---

### 943. msg_14051

**You** - 2025-05-26T21:16:12

no got sidetracked


---

### 944. msg_14052

**Meredith Lamb \(\+14169386001\)** - 2025-05-26T21:39:12

Going to sleep super early\. Nite xoxo love you


---

### 945. msg_14053

**You** - 2025-05-26T21:41:57

Night love you too xoxo ❤️


---

### 946. msg_14054

**You** - 2025-05-27T04:20:09

Mmm another sun shiny day incoming… meh\.  Bit of a scrap last night\.\. j seems to be paranoid that people at work know about us even though I assured her no one did\.  Anyways not\. Super fun night\.\. if that becomes the norm I will need to leave for a bit I think we will see how it goes\.


---

### 947. msg_14055

**You** - 2025-05-27T04:20:31

Well off to gym hope you slept well since you got to bed early


---

### 948. msg_14056

**You** - 2025-05-27T06:42:38

Reaction: ❤️ from Meredith Lamb
Getting there will need to put together a timeline eventually\.

*1 attachment(s)*


---

### 949. msg_14057

**You** - 2025-05-27T06:51:25

Heading into sauna shower then going to my morning spot to do some thinking see you when I see you have a good morning\.❤️❤️


---

### 950. msg_14058

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:01:40

I don’t think I should go into work\. My throat is worse\. Ugh…


---

### 951. msg_14059

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:04:10

>
It is honestly crazy how fast you have done this 😍… timeline for ??


---

### 952. msg_14060

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:05:43

>
I get her paranoia\. Walking into work felt weirder for me yesterday\. Walking down to Haris’ office felt weirder\. Is what it is\.


---

### 953. msg_14061

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:13:48

>
Scrap that\. I’m going to go in\. It isn’t too bad\. It’s weird\.


---

### 954. msg_14062

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:13:54

I’m using that word a lot


---

### 955. msg_14063

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:13:58

Need coffee lol


---

### 956. msg_14064

**You** - 2025-05-27T07:13:59

>
Ur call


---

### 957. msg_14065

**You** - 2025-05-27T07:14:22

Just going to get dressed get a smooth and go see the birdies\.  Cheers\.


---

### 958. msg_14066

**You** - 2025-05-27T07:14:46

>
Yeah I know but she was fucking pissed at me last night\.


---

### 959. msg_14067

**You** - 2025-05-27T07:15:05

Anyways it is fine she is in and out\. I told her to quit now and I would cover her salary\.


---

### 960. msg_14068

**You** - 2025-05-27T07:15:16

But she won’t


---

### 961. msg_14069

**You** - 2025-05-27T07:15:43

Anyhow time for birdies and peace and happier thoughts\.\. or at least I will try for em\.  See you later\.


---

### 962. msg_14070

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T07:16:19

Sorry I won’t be there … just got out of shower so running a bit behind


---

### 963. msg_14071

**You** - 2025-05-27T07:17:37

I didn’t expect you to be all good\.


---

### 964. msg_14072

**You** - 2025-05-27T09:16:00

Going off teams


---

### 965. msg_14073

**You** - 2025-05-27T09:16:25

Yeah I feel like I need to, I feel you need it to\.  I think it makes it more real for both of us when someone else knows


---

### 966. msg_14074

**You** - 2025-05-27T09:16:38

Which I think is likely more reassuring as well


---

### 967. msg_14075

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:17:07

Chagpt said telling a trust work friend is good and ChatGPT knows everything sooooooo……


---

### 968. msg_14076

**You** - 2025-05-27T09:17:17

Yeah sure not biased at all


---

### 969. msg_14077

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:17:34

lol


---

### 970. msg_14078

**You** - 2025-05-27T09:17:41

Ask it to run a pro cons and risk bs reward analysis\.\. and then assess the overall upside vs downside


---

### 971. msg_14079

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:18:02

But it doesn’t even know Jim


---

### 972. msg_14080

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:18:05

lol


---

### 973. msg_14081

**You** - 2025-05-27T09:18:29

Characterize him an old and trusted friend\.\. like a mentor or big brother


---

### 974. msg_14082

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:20:29

Pros
1\. Emotional support and grounding perspective
A trusted colleague or mentor can offer wisdom, support, and a grounded outside view—especially helpful when you’re navigating the emotional complexity of your relationship and work dynamics\.
2\. Trusted sounding board
They may help you think through difficult decisions, like future disclosures, boundary\-setting, or how to protect your reputations\.
3\. Reduced sense of secrecy
If you’ve been carrying the relationship quietly, telling one trusted person can reduce the emotional burden of secrecy\.
4\. Safe test case
This can be a way to see how disclosure feels and gauge how someone outside the relationship reacts—before considering broader transparency, if ever\.
⸻
Cons
1\. Risk of unintentional spread
Even trusted colleagues can slip up or feel conflicted about keeping the information private, especially if they feel loyalty to others or organizational policies\.
2\. Change in perception
Even with good intentions, your mentor might view eith\.\.\. \[truncated\]


---

### 975. msg_14083

**You** - 2025-05-27T09:21:24

lol I don’t feel like I am worried about those cons


---

### 976. msg_14084

**You** - 2025-05-27T09:21:40

He is pretty mature and grounded he would never joke about it or make light


---

### 977. msg_14085

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:22:44

Yeah exactly\. He is literally the only person here I would ever consider telling \(after you lol\)


---

### 978. msg_14086

**You** - 2025-05-27T09:23:27

Agreed but I will need to reiterate this cannot get around it would have catastrophic affects on me\.


---

### 979. msg_14087

**You** - 2025-05-27T09:23:38

I will see how he feels before I decide


---

### 980. msg_14088

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:24:26

We can wait until I’m officially not reporting to you


---

### 981. msg_14089

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:24:30

I’m okay with that


---

### 982. msg_14090

**You** - 2025-05-27T09:26:25

I feel like this is going to happen today\.  I kind of need someone\.  With the stuff at home it makes everything else worse even more so than it already was\.  But I am trying to keep it all to myself\.


---

### 983. msg_14091

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:33:28

Yeah it sounds pretty bad at home\. :\(


---

### 984. msg_14092

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:34:25

I get all of her anger and feelings tho


---

### 985. msg_14093

**You** - 2025-05-27T09:34:27

Yep not good\.\. and no escape\.


---

### 986. msg_14094

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:35:50

I don’t really think anyone understands the depth of our relationship… even my family and friends seem to think it is this rebound fling


---

### 987. msg_14095

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:36:05

Jaimie may think that and hence the “don’t see her anymore”


---

### 988. msg_14096

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:36:21

If ppl understood things they wouldn’t bother suggesting that


---

### 989. msg_14097

**You** - 2025-05-27T09:36:36

No I could never explain to her how I really feel\.\. if I did it would completely break her and I don’t want that\.


---

### 990. msg_14098

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:36:58

I know\.


---

### 991. msg_14099

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:37:58

You have a strong protection instinct which is admirable and good


---

### 992. msg_14100

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:38:15

I likely won’t take that approach with Andrew but again, different situations


---

### 993. msg_14101

**You** - 2025-05-27T09:38:51

Yeah I get it\.\. it won’t matter when she eventually finds out our lines of communication will pretty
Much be zero until or if she decides to get over it\.


---

### 994. msg_14102

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:41:31

I’m sure she will move on to a new phase eventually but it may not be full acceptance but I think the anger will dull


---

### 995. msg_14103

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:41:48

I stayed in the anger phase with Andrew for a good couple months


---

### 996. msg_14104

**You** - 2025-05-27T09:42:00

Well she is a bit different


---

### 997. msg_14105

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:42:02

I got therapy tho


---

### 998. msg_14106

**You** - 2025-05-27T09:42:09

She can hold on to shit forever


---

### 999. msg_14107

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:42:14

That helped diffuse some of my anger I think


---

### 1000. msg_14108

**You** - 2025-05-27T09:42:14

So we will see


---

### 1001. msg_14109

**You** - 2025-05-27T09:42:23

Perhaps


---

### 1002. msg_14110

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:42:51

How will you be if she stays super angry forever?


---

### 1003. msg_14111

**You** - 2025-05-27T09:44:07

I will live with it\.


---

### 1004. msg_14112

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:46:49

As long as it doesn’t mess with your head too much\. You aren’t a horrible person for this\. I mean we probably could have moved a bit slower but the reality is that we didn’t but I don’t think we are horrible people\.


---

### 1005. msg_14113

**You** - 2025-05-27T09:48:12

I don’t think I am or you are\.\. again this happened it wasn’t planned and it is unique imho\.  It won’t mess with my head\.\. I want to be able to have my kids engage with you and your but it might just end up being maddie\.\.  not sure\.


---

### 1006. msg_14114

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:50:43

Just give it time\. I think we both see this being years so it is hard to predict how things will be years later…


---

### 1007. msg_14115

**You** - 2025-05-27T09:52:23

Meaning we see this lasting years\.\. yeah I don’t think about that because I don’t want to think about a potential end\.


---

### 1008. msg_14116

**You** - 2025-05-27T09:52:37

Just how my mind likes to work


---

### 1009. msg_14117

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:54:13

>
I’m not thinking about an end…\. But we will both be old and die eventually lol not getting any younger


---

### 1010. msg_14118

**You** - 2025-05-27T09:57:43

You are so morbid…\. I told you the other night I want more than 25\.\.  I just don’t think you can deal with my… I don’t know intensity commitment certainty\.\. we are built differently for sure\.


---

### 1011. msg_14119

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T09:58:43

lol I am not morbid\!


---

### 1012. msg_14120

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T10:00:19

Reaction: ❤️ from Scott Hicks
It we had 25 years together, I would feel very lucky\. Honestly I feel really lucky to be with you despite all the mess around us


---

### 1013. msg_14121

**You** - 2025-05-27T10:07:08

I am really looking forward to some sense of normalcy\.\. even just a bit\.\.


---

### 1014. msg_14122

**You** - 2025-05-27T12:15:11

Do you want to come down to 4105


---

### 1015. msg_14123

**You** - 2025-05-27T12:15:27

If you are available


---

### 1016. msg_14124

**You** - 2025-05-27T13:32:36

I feel very much better


---

### 1017. msg_14125

**You** - 2025-05-27T13:32:47

I hope you do too\.


---

### 1018. msg_14126

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T13:37:45

Uh yeah, super awkward but feel better\. I felt super awkward when I told him of my separation so I knew this would feel similar


---

### 1019. msg_14127

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T13:38:24

I didn’t like talking to him this morning and him not knowing\. Was starting to feel deceptive


---

### 1020. msg_14128

**You** - 2025-05-27T13:38:33

I didn’t find the conversation at lunch awkward


---

### 1021. msg_14129

**You** - 2025-05-27T13:38:38

Yeah I get it


---

### 1022. msg_14130

**You** - 2025-05-27T13:39:00

He was happy almost immediately


---

### 1023. msg_14131

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T13:39:06

>
I came in blind tho lol not knowing what you had said\!


---

### 1024. msg_14132

**You** - 2025-05-27T13:39:14

Nothing bad all good


---

### 1025. msg_14133

**You** - 2025-05-27T13:39:23

You are amazing what can I say that is bad


---

### 1026. msg_14134

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T13:39:53

Did he not know who was going to be walking in??


---

### 1027. msg_14135

**You** - 2025-05-27T13:49:19

No


---

### 1028. msg_14136

**You** - 2025-05-27T13:49:22

Not a clue


---

### 1029. msg_14137

**You** - 2025-05-27T13:49:40

I have 10 mins if you have any questions before my next meeting


---

### 1030. msg_14138

**You** - 2025-05-27T14:37:07

High point noon low point incoming lol\.


---

### 1031. msg_14139

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T14:40:55

?


---

### 1032. msg_14140

**You** - 2025-05-27T14:47:50

End of day low point see you in several weeks lol


---

### 1033. msg_14141

**You** - 2025-05-27T14:48:41

Think I am going to leave early getting a bit antsy\.


---

### 1034. msg_14142

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T14:50:27

We won’t see each other next week?


---

### 1035. msg_14143

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T14:50:32

Remind me


---

### 1036. msg_14144

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T14:50:42

I have to leave right at 4 today


---

### 1037. msg_14145

**You** - 2025-05-27T14:50:53

I am on vacation next week


---

### 1038. msg_14146

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T14:52:08

Oh right\.


---

### 1039. msg_14147

**You** - 2025-05-27T14:52:15

It’s fine you go nothing we can do about it anyways


---

### 1040. msg_14148

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:01:37

>
Didn’t really need this reminder… 😔


---

### 1041. msg_14149

**You** - 2025-05-27T15:02:11

Sorry I kind of lost track the realized \.\. fucked


---

### 1042. msg_14150

**You** - 2025-05-27T15:02:29

I am leaving at 4 too\.\. don’t feel like being here\.
Will do work from home later


---

### 1043. msg_14151

**You** - 2025-05-27T15:04:35

This is why I told you I might need to shut down the other night\.\. will see how it goes\.\. might still have to will see\.


---

### 1044. msg_14152

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:06:38

Please just wait and see\.


---

### 1045. msg_14153

**You** - 2025-05-27T15:36:02

With what is going on at home right now I don’t know that I have much of a choice regardless\.\. just trying to manage expectations\.\. but if I go offline and don’t come back on you will know why at least\.


---

### 1046. msg_14154

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:37:09

What the heck??


---

### 1047. msg_14155

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:37:17

Literally in a meeting


---

### 1048. msg_14156

**You** - 2025-05-27T15:37:19

Pocket dial


---

### 1049. msg_14157

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:37:27

Omg


---

### 1050. msg_14158

**You** - 2025-05-27T15:37:28

So am I


---

### 1051. msg_14159

**You** - 2025-05-27T15:37:33

I don’t know why it did that


---

### 1052. msg_14160

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:37:42

TWICE


---

### 1053. msg_14161

**You** - 2025-05-27T15:37:51

I am deleting this app right now


---

### 1054. msg_14162

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:38:03

What no


---

### 1055. msg_14163

**You** - 2025-05-27T15:39:01

We’ll see\.\. refer to earlier comment


---

### 1056. msg_14164

**You** - 2025-05-27T15:39:09

Leaving at 4 bet I beat you out of here


---

### 1057. msg_14165

**You** - 2025-05-27T15:39:20

So agitated


---

### 1058. msg_14166

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:55:58

My nerves are feeling a little tense also which is surprising\. Not sure if it is the Jim thing or the Jaimie telling you not to see me anymore thing


---

### 1059. msg_14167

**You** - 2025-05-27T15:56:57

Why is that surprising


---

### 1060. msg_14168

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:57:33

I thought I’d feel better telling Jim


---

### 1061. msg_14169

**You** - 2025-05-27T15:57:33

Packing up to leave now \.\. too much


---

### 1062. msg_14170

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:58:04

Oh and Andrew just asked me if I covered the ring on purpose


---

### 1063. msg_14171

**You** - 2025-05-27T15:58:29

Perfect


---

### 1064. msg_14172

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:58:46


*1 attachment(s)*


---

### 1065. msg_14173

**You** - 2025-05-27T15:59:12

Reaction: 😂 from Meredith Lamb
That was a weak ass ask


---

### 1066. msg_14174

**You** - 2025-05-27T15:59:19

Do you want me to wait for you


---

### 1067. msg_14175

**You** - 2025-05-27T15:59:23

Downstairs


---

### 1068. msg_14176

**You** - 2025-05-27T16:00:21

Reaction: 😢 from Meredith Lamb
I was going to run away without seeing you because\.\. hurts but if you want me to stay I can


---

### 1069. msg_14177

**You** - 2025-05-27T16:02:15

Frck shoulx have left


---

### 1070. msg_14178

**You** - 2025-05-27T16:03:37

Cya


---

### 1071. msg_14179

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:04:21

Cya :p


---

### 1072. msg_14180

**You** - 2025-05-27T16:21:17

>
It is the Jaimie thing and the next few weeks and now the ring camera nothing to worry about on your end


---

### 1073. msg_14181

**You** - 2025-05-27T16:31:11

You just need to focus on what is in front of you\.


---

### 1074. msg_14182

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:31:19

After I left did Jim say if he saw this coming?


---

### 1075. msg_14183

**You** - 2025-05-27T16:31:24

I need to do something else


---

### 1076. msg_14184

**You** - 2025-05-27T16:31:30

No


---

### 1077. msg_14185

**You** - 2025-05-27T16:31:45

But I essentially told him I was in love with you


---

### 1078. msg_14186

**You** - 2025-05-27T16:32:06

He didn’t bat an eye


---

### 1079. msg_14187

**You** - 2025-05-27T16:32:29

Totally engaged\.\. completely believed


---

### 1080. msg_14188

**You** - 2025-05-27T16:33:11

Sorry if you didn’t want me to do that


---

### 1081. msg_14189

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:33:56

I’m cool with that\. Just totally curious what he thought\. I will ask him lol


---

### 1082. msg_14190

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:34:05

You didn’t tell Jaimie that tho


---

### 1083. msg_14191

**You** - 2025-05-27T16:34:07

Kk


---

### 1084. msg_14192

**You** - 2025-05-27T16:34:10

No


---

### 1085. msg_14193

**You** - 2025-05-27T16:34:29

Mike knows


---

### 1086. msg_14194

**You** - 2025-05-27T16:34:32

Katie knows


---

### 1087. msg_14195

**You** - 2025-05-27T16:35:21

Jon knows


---

### 1088. msg_14196

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:38:49

Sorry just at my appt


---

### 1089. msg_14197

**You** - 2025-05-27T16:41:01

I know it’s fine


---

### 1090. msg_14198

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:51:52

I think I’m having ONE glass of wine tonight to calm my nerves lol


---

### 1091. msg_14199

**You** - 2025-05-27T16:52:12

Do what you need to\.  You are leaving early tomorrow right


---

### 1092. msg_14200

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:53:39

I think so yeah\. Another get up early


---

### 1093. msg_14201

**You** - 2025-05-27T16:54:08

Kk well just do your thing and go to bed


---

### 1094. msg_14202

**You** - 2025-05-27T16:54:28

You got vball wine bed


---

### 1095. msg_14203

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:55:07

Yeehaw


---

### 1096. msg_14204

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:55:26

I have therapy tomorrow\. Should be interest


---

### 1097. msg_14205

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:55:31

Interesting


---

### 1098. msg_14206

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:55:52

She was on vacay last week


---

### 1099. msg_14207

**You** - 2025-05-27T16:56:12

I am not going to bug you tonight so you should have a quiet night no stress\. Hope the therapy goes well\.  I still need to find one might look tonight\.


---

### 1100. msg_14208

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:56:36

You do not bug me\. Stop with that


---

### 1101. msg_14209

**You** - 2025-05-27T16:57:21

Yeah I do I know what kind of mood I will be in so staying offline


---

### 1102. msg_14210

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:57:28

Accident


---

### 1103. msg_14211

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T16:58:20

>
Things might ease off …\. Just give it some time\.


---

### 1104. msg_14212

**You** - 2025-05-27T16:59:22

Regardless I hope you have a good night


---

### 1105. msg_14213

**You** - 2025-05-27T17:13:21



---

### 1106. msg_14214

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T17:13:56

🤔


---

### 1107. msg_14215

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T15:34:30

What did you delete?


---

### 1108. msg_14216

**You** - 2025-05-27T17:58:52

It was nothing disregard\.


---

### 1109. msg_14217

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:35:58

Reaction: ❤️ from Scott Hicks
From Jim: Well I have to be honest\. I did not suspect anything between you too\. So no I did not see that coming\. lol\. Having said that I am happy for both of you\. I know you both have been going through some tough relationships and you both deserve to be happy\. I am flattered you both wanted to tell me and look forward to the day when we can hang out as couples\. That’s of course if you’re ok at hanging out with a couple of old folks\. 😂


---

### 1110. msg_14218

**You** - 2025-05-27T18:39:33

Jim is the best


---

### 1111. msg_14219

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:45:08

Omg get this


---

### 1112. msg_14220

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:45:18

lol\. Well we know he gets a bit anxious over things\. It was funny when I got back to my desk\. Carolyn sent me a chat asking me if Scott was meeting with me to talk about your role\. lol\.


---

### 1113. msg_14221

**You** - 2025-05-27T18:45:32

He told me that


---

### 1114. msg_14222

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:45:35

Carolyn was calendar stalking you


---

### 1115. msg_14223

**You** - 2025-05-27T18:45:36

Came in to see me


---

### 1116. msg_14224

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:45:37

Omg


---

### 1117. msg_14225

**You** - 2025-05-27T18:54:44

>
she was trying to book a time at 1pm for a meeting re: the rollover forecast and TRC calcs\.


---

### 1118. msg_14226

**You** - 2025-05-27T18:54:53

she would have seen me double book my lunch


---

### 1119. msg_14227

**You** - 2025-05-27T18:55:03

still it is very carolyn


---

### 1120. msg_14228

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:56:42

Ahhh I see


---

### 1121. msg_14229

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T18:56:49

That is pretty funny


---

### 1122. msg_14230

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:09:47

I told my mom what you did to Jim today\. She enjoyed that\. Lol she’s heard a lot about Jim


---

### 1123. msg_14231

**You** - 2025-05-27T19:14:30

Just got off with Cara Lynn


---

### 1124. msg_14232

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:14:50

Just catching up?


---

### 1125. msg_14233

**You** - 2025-05-27T19:20:17

I mean she likes me\.\.


---

### 1126. msg_14234

**You** - 2025-05-27T19:20:39

We connected when she was the boss\.\.


---

### 1127. msg_14235

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:21:38

Everyone likes you\.


---

### 1128. msg_14236

**You** - 2025-05-27T19:21:40

“Connected” even


---

### 1129. msg_14237

**You** - 2025-05-27T19:21:47

😜


---

### 1130. msg_14238

**You** - 2025-05-27T19:21:59

It can get interesting with bosses yah know


---

### 1131. msg_14239

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:22:19

I wouldn’t know anything about that\.


---

### 1132. msg_14240

**You** - 2025-05-27T19:22:39

Well not about me and Cara we were discreet unlike others…\.


---

### 1133. msg_14241

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:24:07

Hey, Jim had NO idea\. That is the definition of discreet\!


---

### 1134. msg_14242

**You** - 2025-05-27T19:24:35

He was just saying that to be nice to you


---

### 1135. msg_14243

**You** - 2025-05-27T19:24:55

I was talking to her about the eval mgr position\.


---

### 1136. msg_14244

**You** - 2025-05-27T19:25:29

I think sophear bent will likely get
It\.\. she is a high performer looking for an opportunity\.\. and has been trying to get back in dsm a while


---

### 1137. msg_14245

**You** - 2025-05-27T19:25:33

Net\.


---

### 1138. msg_14246

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:28:51

>
Really? You think he suspected?


---

### 1139. msg_14247

**You** - 2025-05-27T19:28:58

no fucking with you


---

### 1140. msg_14248

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:29:08

Oh


---

### 1141. msg_14249

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:29:10

Geez


---

### 1142. msg_14250

**You** - 2025-05-27T19:29:13

ez


---

### 1143. msg_14251

**You** - 2025-05-27T19:29:15

:P


---

### 1144. msg_14252

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:29:22

>
Really…\.


---

### 1145. msg_14253

**You** - 2025-05-27T19:29:33

yep\.\. she wanted your job and carolyns


---

### 1146. msg_14254

**You** - 2025-05-27T19:29:39

she told me she wants this one


---

### 1147. msg_14255

**You** - 2025-05-27T19:29:41

called me today\.


---

### 1148. msg_14256

**You** - 2025-05-27T19:29:48

Then it got funny


---

### 1149. msg_14257

**You** - 2025-05-27T19:29:55

I told her I was applying\.


---

### 1150. msg_14258

**You** - 2025-05-27T19:30:06

she was like \- well then maybe I am not applying afterall\.


---

### 1151. msg_14259

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:30:14

lol


---

### 1152. msg_14260

**You** - 2025-05-27T19:30:18

She said she doesn't want to get beat by me again


---

### 1153. msg_14261

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:30:40

Sounds like a popular role\!


---

### 1154. msg_14262

**You** - 2025-05-27T19:30:46

everyone is looking to escape


---

### 1155. msg_14263

**You** - 2025-05-27T19:30:55

daniel craig\.\. me


---

### 1156. msg_14264

**You** - 2025-05-27T19:31:03

Bailey wants to advance Sophear wants to advance


---

### 1157. msg_14265

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:32:11

Craig is applying you think?


---

### 1158. msg_14266

**You** - 2025-05-27T19:32:12

100%


---

### 1159. msg_14267

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:32:20

Oh wow


---

### 1160. msg_14268

**You** - 2025-05-27T19:33:26

hmmm I am not doing well with radio silence\.\. I will have to do a better job\.


---

### 1161. msg_14269

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:33:44

Radio silence from me??


---

### 1162. msg_14270

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:33:59

I’m multitasking


---

### 1163. msg_14271

**You** - 2025-05-27T19:33:59

well from you but not in the way you think\.


---

### 1164. msg_14272

**You** - 2025-05-27T19:34:11

again\.\. just trying to prepare\.\. it is like fasting\.


---

### 1165. msg_14273

**You** - 2025-05-27T19:34:43

nm\.\. fuck it\.\. I already know it will make you miserable\.\.


---

### 1166. msg_14274

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:35:09

You could come up to cottage tomorrow night


---

### 1167. msg_14275

**You** - 2025-05-27T19:35:08

you are gonna want to chat at me all weekend about the girls etc


---

### 1168. msg_14276

**You** - 2025-05-27T19:35:35

>
no you know I cannot \- I don't have an excuse to get away\.


---

### 1169. msg_14277

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:35:56

I know but just said it anyway


---

### 1170. msg_14278

**You** - 2025-05-27T19:36:18

see thing is sometime you are going to do that\.\. and I am going to say sure see you there\.\. and you are going to be like uhhhhhhhhhhhhh


---

### 1171. msg_14279

**You** - 2025-05-27T19:36:27

Andrew's driving kids up tomorrow night


---

### 1172. msg_14280

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:36:45

Andrew is driving kids up Thursday night


---

### 1173. msg_14281

**You** - 2025-05-27T19:37:20

Reaction: 🙁 from Meredith Lamb
still no logical excuse\. and SOOOOO Sus\.\. if I try to pull some bullshit\.


---

### 1174. msg_14282

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:37:45


*1 attachment(s)*


---

### 1175. msg_14283

**You** - 2025-05-27T19:38:22

9:45 check ring really close to make sure it is working and has a free view in all directions\.


---

### 1176. msg_14284

**You** - 2025-05-27T19:39:48

that kind of thing I will need advanced planning and notice\.


---

### 1177. msg_14285

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:40:04

I know


---

### 1178. msg_14286

**You** - 2025-05-27T19:40:08

and at best it would need to be weeknight\.


---

### 1179. msg_14287

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:40:13

I don’t actually expect anything\.


---

### 1180. msg_14288

**You** - 2025-05-27T19:40:19

no more weekends until this is done\.


---

### 1181. msg_14289

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:40:26

It is a weeknight


---

### 1182. msg_14290

**You** - 2025-05-27T19:40:38

but again\.\. we aren't planning shit anymore\.\. too risky\.\. especially for you\.


---

### 1183. msg_14291

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:41:03

Tomorrow would not be risky for me\. Just you\.


---

### 1184. msg_14292

**You** - 2025-05-27T19:41:34

yep\.\. the perception would be too obvious\.\. where do I need to go to be away overnight\.\. and what would I do thursday lol\.


---

### 1185. msg_14293

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:42:22

You would go to work Thursday afternoon\. Drive in the morning


---

### 1186. msg_14294

**You** - 2025-05-27T19:42:49

yeah\.\. too risky\.\. I would do it otherwise\.


---

### 1187. msg_14295

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:42:59

>
You just need to be with me\. That’s all\.


---

### 1188. msg_14296

**You** - 2025-05-27T19:43:02

I know


---

### 1189. msg_14297

**You** - 2025-05-27T19:44:07

The other thing is\.\. they call me and try to video me\.\. and shit\.\. well Gracie cannot anymore\.\. like we would need to go to a hotel\.\. not the cottage\.


---

### 1190. msg_14298

**You** - 2025-05-27T19:44:29

so if I did get a call or a video request I could show a hotel room\.


---

### 1191. msg_14299

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:45:19

Hotel would be hard\. I have 2 dogs\.


---

### 1192. msg_14300

**You** - 2025-05-27T19:45:22

I know\.


---

### 1193. msg_14301

**You** - 2025-05-27T19:46:53

Sry I don't see how I could spin it\.\. with J the way she is now\.\. it would need to be a clear work function\.\. and I would need to not be at risk on a video call\.


---

### 1194. msg_14302

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:47:24

Yeah I know\.


---

### 1195. msg_14303

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:47:56

It’s okay \- we will have lots of time together eventually\. Just get our agreements finalized\.


---

### 1196. msg_14304

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:48:06

Andrew has promised to do the taxes tonight


---

### 1197. msg_14305

**You** - 2025-05-27T19:50:29

hmmm


---

### 1198. msg_14306

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T19:58:23

Hmmm


---

### 1199. msg_14307

**You** - 2025-05-27T20:06:26

Maybe


---

### 1200. msg_14308

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:18:41

Excuse me?


---

### 1201. msg_14309

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:24:58

Please elaborate


---

### 1202. msg_14310

**You** - 2025-05-27T20:40:50

Saying I might come and sdo on Thursday\.


---

### 1203. msg_14311

**You** - 2025-05-27T20:41:16

But with the ring and everything seems risky still doesnt it


---

### 1204. msg_14312

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:47:00

What the heck would you tell your family? I feel like if you come you would basically be saying fuck it\.


---

### 1205. msg_14313

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:47:31


*1 attachment(s)*


---

### 1206. msg_14314

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:47:50

That is the ring\. It has blown over a bit


---

### 1207. msg_14315

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:48:01

I can’t go to dump wed or thurs\. Closed\.


---

### 1208. msg_14316

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:48:24

Have to go Friday so I have no excuse to remove that stuff right away


---

### 1209. msg_14317

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:49:24

See closed\.


---

### 1210. msg_14318

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:50:50

The ring is not the problem, your family is the challenge\. So I completely 180% understand that and wasn’t expecting you to swing it\.


---

### 1211. msg_14319

**You** - 2025-05-27T20:54:49

I have a narrative


---

### 1212. msg_14320

**You** - 2025-05-27T20:54:56

Believable


---

### 1213. msg_14321

**You** - 2025-05-27T20:55:01

Believed


---

### 1214. msg_14322

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:55:01

Hmmh


---

### 1215. msg_14323

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:55:26

Would love to hear it


---

### 1216. msg_14324

**You** - 2025-05-27T20:55:30

Later


---

### 1217. msg_14325

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:55:34

lol


---

### 1218. msg_14326

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:55:38

k


---

### 1219. msg_14327

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:56:13

Well I’m aiming to leave here at 6am 🥱🥱🥱🥱🥱


---

### 1220. msg_14328

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:56:33

I have a 9am with Pauline


---

### 1221. msg_14329

**You** - 2025-05-27T20:56:42

Nice


---

### 1222. msg_14330

**You** - 2025-05-27T20:58:31

When would you want me there


---

### 1223. msg_14331

**You** - 2025-05-27T20:58:52

and when would I leave noon ish?


---

### 1224. msg_14332

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:59:16

Whenever you want


---

### 1225. msg_14333

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:59:25

9am


---

### 1226. msg_14334

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T20:59:28

lol


---

### 1227. msg_14335

**You** - 2025-05-27T21:01:53

I could t leave till 2 pm earliest


---

### 1228. msg_14336

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:08:52

Wait what day were you asking about Wed and Thurs or just Wed?


---

### 1229. msg_14337

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:09:10

To me, honestly I didn’t think this had any chance so the time doesn’t matter to me


---

### 1230. msg_14338

**You** - 2025-05-27T21:09:15

Just wed Andrew is coming up third


---

### 1231. msg_14339

**You** - 2025-05-27T21:09:20

So I would leave


---

### 1232. msg_14340

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:09:42

Right but were you asking when you had to leave thurs?


---

### 1233. msg_14341

**You** - 2025-05-27T21:09:49

Yeah what time


---

### 1234. msg_14342

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:10:15

Oh I don’t care but I should go to Huntsville to get groceries


---

### 1235. msg_14343

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:10:20

In afternoon


---

### 1236. msg_14344

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:10:34

Andrew and girls won’t get there until 9\.30pm


---

### 1237. msg_14345

**You** - 2025-05-27T21:11:52

Ok


---

### 1238. msg_14346

**You** - 2025-05-27T21:11:57

I think I can manage it


---

### 1239. msg_14347

**You** - 2025-05-27T21:12:00

I think


---

### 1240. msg_14348

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:12:09

I still don’t understand how you can do this


---

### 1241. msg_14349

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:14:23

Are you sure it isn’t going to make things worse?


---

### 1242. msg_14350

**You** - 2025-05-27T21:32:28

things are already shit


---

### 1243. msg_14351

**You** - 2025-05-27T21:32:30

ok


---

### 1244. msg_14352

**You** - 2025-05-27T21:32:45

so I am taking next week and the week of the 19th of june off\.


---

### 1245. msg_14353

**You** - 2025-05-27T21:32:56

which is the week the team goes to chatham


---

### 1246. msg_14354

**You** - 2025-05-27T21:33:14

I suggested i should make that up tomorrow night before I head out on vacation \- she was in complete agreement


---

### 1247. msg_14355

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:33:34

Make up the Chatham trip?


---

### 1248. msg_14356

**You** - 2025-05-27T21:33:45

yeah because I never go enough\.\. I am missing the mgmt meeting in chatham


---

### 1249. msg_14357

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:34:01

But that makes no sense


---

### 1250. msg_14358

**You** - 2025-05-27T21:34:02

so I will go tomorrow to visit the team\.\.'


---

### 1251. msg_14359

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:34:08

There is no mgt meeting tomorrow


---

### 1252. msg_14360

**You** - 2025-05-27T21:34:08

ok step 1


---

### 1253. msg_14361

**You** - 2025-05-27T21:34:23

there is a mgmt team in 2 weeks that I will be missing \- it is in chatham for a reason


---

### 1254. msg_14362

**You** - 2025-05-27T21:34:29

step 2 I am missing it


---

### 1255. msg_14363

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:34:33

Ok ok


---

### 1256. msg_14364

**You** - 2025-05-27T21:34:32

so instead


---

### 1257. msg_14365

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:34:36

I get it


---

### 1258. msg_14366

**You** - 2025-05-27T21:34:35

I go tomorrow


---

### 1259. msg_14367

**You** - 2025-05-27T21:34:35

lol


---

### 1260. msg_14368

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:34:45

But like she believes that for real?


---

### 1261. msg_14369

**You** - 2025-05-27T21:34:54

yah


---

### 1262. msg_14370

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:34:59

Okey dokey


---

### 1263. msg_14371

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:35:19

What if you get a call tho?


---

### 1264. msg_14372

**You** - 2025-05-27T21:35:47

We had a bit of a fight about something else tonight\.\. I won't be taking calls


---

### 1265. msg_14373

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:36:10

😬


---

### 1266. msg_14374

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:36:18

k…


---

### 1267. msg_14375

**You** - 2025-05-27T21:36:22

I mean if you are nervous we don't have to do you brought it up lol


---

### 1268. msg_14376

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:36:32

Well if this goes badly I will feel bad


---

### 1269. msg_14377

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:36:52

No I want to but your family life seems like very thin ice right now


---

### 1270. msg_14378

**You** - 2025-05-27T21:37:34

I mean this whole thing is a shit show\.


---

### 1271. msg_14379

**You** - 2025-05-27T21:37:44

like it just is what it is at this point\.


---

### 1272. msg_14380

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:40:48

Well if you feel comfortable enough, I certainly am so kind of your final call


---

### 1273. msg_14381

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:41:15

Andrew and Mac just got home and I confirmed the plan and it still is the same


---

### 1274. msg_14382

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:41:50

Andrew has some town hall he needs to speak at from 1\-3pm Thursday aft and that won’t be changing


---

### 1275. msg_14383

**You** - 2025-05-27T21:43:00

ok


---

### 1276. msg_14384

**You** - 2025-05-27T21:43:05

so then this could work


---

### 1277. msg_14385

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:43:09

Then he is taking Marlowe to some vball thing in Markham right after school for her


---

### 1278. msg_14386

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:43:27

Then coming back to Yonge and Eg and packing and getting girls


---

### 1279. msg_14387

**You** - 2025-05-27T21:44:05

sec


---

### 1280. msg_14388

**You** - 2025-05-27T21:44:22

I think we are fine\.\. just need a few mins kl


---

### 1281. msg_14389

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T21:44:39

Yup watching a doc


---

### 1282. msg_14390

**You** - 2025-05-27T21:59:30

I am coming


---

### 1283. msg_14391

**You** - 2025-05-27T22:00:01

leaving 2:30 ish tomorrow\.\. planning on being back supper ish Thursday if that works for you\.


---

### 1284. msg_14392

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:00:46

Crazy\!


---

### 1285. msg_14393

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:00:56

And yes of course that works for me lol


---

### 1286. msg_14394

**You** - 2025-05-27T22:01:40

ok\.\.\. see you need to be careful what you say\.\. cause then crazy things happen\.


---

### 1287. msg_14395

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:02:30

lol I’m a little shocked \(pleasantly\)


---

### 1288. msg_14396

**You** - 2025-05-27T22:02:59

I am too\.\. but should be fine\.\. I am taking an SDO thursday\.\. so we will have most of thursday for whatever\.\. party prep etc\.


---

### 1289. msg_14397

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:04:24

I do have stuff to do for sure but will try to do some tomorrow on and off


---

### 1290. msg_14398

**You** - 2025-05-27T22:04:40

kk well now we have something to look forward to\.


---

### 1291. msg_14399

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:05:06

🎉


---

### 1292. msg_14400

**You** - 2025-05-27T22:05:12

hey listen though


---

### 1293. msg_14401

**You** - 2025-05-27T22:05:20

you sure you good\. this is not a guilt thing right?


---

### 1294. msg_14402

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:05:35

Omg no


---

### 1295. msg_14403

**You** - 2025-05-27T22:05:36

like if it isn't convenient


---

### 1296. msg_14404

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:06:10

I wouldn’t have put it out there if I didn’t want to\!


---

### 1297. msg_14405

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:07:49

I would see you everyday if we could


---

### 1298. msg_14406

**You** - 2025-05-27T22:11:10

yeah same I truly want to get there\.\. somehow


---

### 1299. msg_14407

**You** - 2025-05-27T22:14:20

well committed now


---

### 1300. msg_14408

**You** - 2025-05-27T22:14:23

Reaction: ❤️ from Meredith Lamb
SDO request in


---

### 1301. msg_14409

**You** - 2025-05-27T22:14:26

doing a wash


---

### 1302. msg_14410

**You** - 2025-05-27T22:14:34

not going to gym so I can stay up late\.\.


---

### 1303. msg_14411

**You** - 2025-05-27T22:14:40

all plans in motion :\)


---

### 1304. msg_14412

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:15:26

Well I’m excited ❤️


---

### 1305. msg_14413

**You** - 2025-05-27T22:15:31

and we are playing ticket to ride


---

### 1306. msg_14414

**You** - 2025-05-27T22:15:46

and maybe watching some shows\.\. and doing some other stuff\.


---

### 1307. msg_14415

**You** - 2025-05-27T22:16:09

and the dogs\!\!\! :\)


---

### 1308. msg_14416

**You** - 2025-05-27T22:16:20

very happy


---

### 1309. msg_14417

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:16:25

Reaction: 👍 from Scott Hicks
No Bo


---

### 1310. msg_14418

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:16:30

lol


---

### 1311. msg_14419

**You** - 2025-05-27T22:18:26

ok well you need to get up early\.\. so I will let you be\.\. go watch your doc and go to sleep\.\. Looking forward to seeing you tomorrow a lot alot a alot\.


---

### 1312. msg_14420

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:19:36

I’m going to watch 10 min more and get to bed\. Very excited for tomorrow but don’t want to jinx anything so will leave it at that xoxo


---

### 1313. msg_14421

**You** - 2025-05-27T22:19:42

oh I can bring some gummies if you want some\.


---

### 1314. msg_14422

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:19:56

🙄


---

### 1315. msg_14423

**You** - 2025-05-27T22:19:59

Love you\!\!\!\!\!\!


---

### 1316. msg_14424

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:20:03

Already packed my own


---

### 1317. msg_14425

**You** - 2025-05-27T22:20:02

XOXOXOXO


---

### 1318. msg_14426

**You** - 2025-05-27T22:20:08

Reaction: 😂 from Meredith Lamb
yeah NO DOUBT\!\!


---

### 1319. msg_14427

**You** - 2025-05-27T22:20:30

ok\.\. night\.\. ❤️❤️❤️


---

### 1320. msg_14428

**Meredith Lamb \(\+14169386001\)** - 2025-05-27T22:20:44

Nite ❤️


---

### 1321. msg_14429

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T06:07:17

Leaving and it is 6\.07am\.  Not bad\!


---

### 1322. msg_14430

**You** - 2025-05-28T06:10:54

Well played I am just getting up get shit done today so I have nothing to worry about


---

### 1323. msg_14431

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T08:41:46

Here with time to spare before 9am\!


---

### 1324. msg_14432

**You** - 2025-05-28T08:44:13

Well played probably leaving at noon now


---

### 1325. msg_14433

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T08:45:32

Just walking dogs and then logging on


---

### 1326. msg_14434

**You** - 2025-05-28T08:53:38

Kk


---

### 1327. msg_14435

**You** - 2025-05-28T10:52:24

I told Ian I am not applying for that role\.


---

### 1328. msg_14436

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T10:59:47

Huh why?


---

### 1329. msg_14437

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T10:59:58

I think that is good\. The team likes you\.


---

### 1330. msg_14438

**You** - 2025-05-28T11:33:39

Longer conversation\. Later probably\.


---

### 1331. msg_14439

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T11:35:49

kk


---

### 1332. msg_14440

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T13:05:10

Talked to Jim over the lunch hour\. He did have lots of questions\. LOL


---

### 1333. msg_14441

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T13:05:27

Have to go on a one on one with ahana now tho


---

### 1334. msg_14442

**You** - 2025-05-28T13:05:54

Kk I am leaving shortly


---

### 1335. msg_14443

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T13:06:21

🙂


---

### 1336. msg_14444

**You** - 2025-05-28T15:03:34

How is your afternoon


---

### 1337. msg_14445

**You** - 2025-05-28T15:10:30

Let me know if I need to stop and get anything wine lol or whatever


---

### 1338. msg_14446

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:11:45

There is wine here lol


---

### 1339. msg_14447

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:12:16

I had meetings all day today


---

### 1340. msg_14448

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:12:19

Annoying


---

### 1341. msg_14449

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:12:22

Taking a break


---

### 1342. msg_14450

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:12:30

Making coffee


---

### 1343. msg_14451

**You** - 2025-05-28T15:13:19

1:15 away


---

### 1344. msg_14452

**You** - 2025-05-28T15:13:33

4:30 arrival


---

### 1345. msg_14453

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:13:56

k I have no milk so no coffee :\(


---

### 1346. msg_14454

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:14:04

Going to do some bedding


---

### 1347. msg_14455

**You** - 2025-05-28T15:20:22

Kk I will pick some up


---

### 1348. msg_14456

**You** - 2025-05-28T15:20:33

Starbucks like and 1%


---

### 1349. msg_14457

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T15:20:53

Sure


---

### 1350. msg_14458

**You** - 2025-05-28T15:21:04

Unless you want something else


---

### 1351. msg_14459

**You** - 2025-05-28T16:26:15

Ok I am at the grocery


---

### 1352. msg_14460

**You** - 2025-05-28T16:26:23

Anything else you want


---

### 1353. msg_14461

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:27:11

Um


---

### 1354. msg_14462

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:27:36

Maybe a salad\. I literally brought nothing


---

### 1355. msg_14463

**You** - 2025-05-28T16:27:56

And I am going to text you when I leave so the when I back in I know where to stop\.  I can msg you when I get close


---

### 1356. msg_14464

**You** - 2025-05-28T16:28:03

What kind of salad


---

### 1357. msg_14465

**You** - 2025-05-28T16:28:08

Do you want bread


---

### 1358. msg_14466

**You** - 2025-05-28T16:28:10

For toast


---

### 1359. msg_14467

**You** - 2025-05-28T16:28:14

And eggs?


---

### 1360. msg_14468

**You** - 2025-05-28T16:28:33

Happy to just let me know\.


---

### 1361. msg_14469

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:28:45

Greek?


---

### 1362. msg_14470

**You** - 2025-05-28T16:28:51

Sure


---

### 1363. msg_14471

**You** - 2025-05-28T16:28:59

Let me know on the test


---

### 1364. msg_14472

**You** - 2025-05-28T16:29:02

Rest


---

### 1365. msg_14473

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:29:21

There is a half a loaf of bread here may 24 but looks fine lol


---

### 1366. msg_14474

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:29:26

Preservatives


---

### 1367. msg_14475

**You** - 2025-05-28T16:29:35

Getting bread too


---

### 1368. msg_14476

**You** - 2025-05-28T16:29:48

Eggs let me know and do you want popcorn


---

### 1369. msg_14477

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:30:03

Popcorn here


---

### 1370. msg_14478

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:30:10

Eggs here


---

### 1371. msg_14479

**You** - 2025-05-28T16:31:32

Kk avacado?


---

### 1372. msg_14480

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:32:18

No s’ok


---

### 1373. msg_14481

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:32:31

I have to do a big haul tomorrow at some point for Mac


---

### 1374. msg_14482

**You** - 2025-05-28T16:32:41

Ahh ok


---

### 1375. msg_14483

**You** - 2025-05-28T16:37:37

Ur microwave works right


---

### 1376. msg_14484

**You** - 2025-05-28T16:37:42

Don’t want to risk drove


---

### 1377. msg_14485

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:37:52

lol it SHOUKD


---

### 1378. msg_14486

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:37:54

SHOULD


---

### 1379. msg_14487

**You** - 2025-05-28T16:38:05

lol pizza pockets for the win


---

### 1380. msg_14488

**You** - 2025-05-28T16:41:02

No pike place want house blend \.\. medium


---

### 1381. msg_14489

**You** - 2025-05-28T16:41:13

Nm


---

### 1382. msg_14490

**You** - 2025-05-28T16:41:16

Found it


---

### 1383. msg_14491

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:50:25

Sorry didn’t get this


---

### 1384. msg_14492

**You** - 2025-05-28T16:50:45

Ok I am ready to come the rest of the way now


---

### 1385. msg_14493

**You** - 2025-05-28T16:50:56

Will leave the grocery when you tell me


---

### 1386. msg_14494

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:51:07

Just come whenever


---

### 1387. msg_14495

**You** - 2025-05-28T16:51:11

Park same place?


---

### 1388. msg_14496

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:51:16

Yeah


---

### 1389. msg_14497

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:51:25

Mosquitoes gah


---

### 1390. msg_14498

**You** - 2025-05-28T16:51:43

You should come out though right?  You don’t want me just to walk up or do you?


---

### 1391. msg_14499

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:52:03

I’m already out


---

### 1392. msg_14500

**You** - 2025-05-28T16:52:07

Ok


---

### 1393. msg_14501

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:52:09

Getting eaten alive


---

### 1394. msg_14502

**You** - 2025-05-28T16:52:24

Coming


---

### 1395. msg_14503

**Meredith Lamb \(\+14169386001\)** - 2025-05-28T16:56:19

Tell me when you are here\. Had to go in bc of bugs


---

### 1396. msg_14504

**You** - 2025-05-28T16:57:39

I can’t


---

### 1397. msg_14505

**You** - 2025-05-28T16:57:42

Here


---

### 1398. msg_14506

**You** - 2025-05-28T16:57:51

No connection at driveway


---

### 1399. msg_14507

**You** - 2025-05-28T16:57:59

Reaction: 👍 from Meredith Lamb
Backing in now


---

### 1400. msg_14508

**You** - 2025-05-28T17:00:18

Here


---

### 1401. msg_14509

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T09:24:04


*1 attachment(s)*


---

### 1402. msg_14510

**You** - 2025-05-29T15:32:54

I called her she didn’t let on to anything


---

### 1403. msg_14511

**You** - 2025-05-29T15:34:04

Don’t worry about me


---

### 1404. msg_14512

**You** - 2025-05-29T15:50:22

❤️ u amazing night


---

### 1405. msg_14513

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T16:07:38

Plan b obtained\. We really are acting like teenagers\. 😜


---

### 1406. msg_14514

**You** - 2025-05-29T16:08:14

Reaction: ❤️ from Meredith Lamb
🥰 feels good though


---

### 1407. msg_14515

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:14:28

Sigh just finished groceries and lcbo\. Holy crap\. $$ lol


---

### 1408. msg_14516

**You** - 2025-05-29T18:17:48

jesus that took a while


---

### 1409. msg_14517

**You** - 2025-05-29T18:17:58

I just got back to the safety of my basement


---

### 1410. msg_14518

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:39:21

I was asking Mac if I will be sick tonight\. She said nauseous lol at least I’m used to that


---

### 1411. msg_14519

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:39:23

:p


---

### 1412. msg_14520

**You** - 2025-05-29T18:39:43

from Plan B


---

### 1413. msg_14521

**You** - 2025-05-29T18:39:46

jesus


---

### 1414. msg_14522

**You** - 2025-05-29T18:39:56

you told Mac you took a Plan B??


---

### 1415. msg_14523

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:40:08


*1 attachment(s)*


---

### 1416. msg_14524

**You** - 2025-05-29T18:40:29

😵


---

### 1417. msg_14525

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:40:44

Yeah bc what if I’m sick tonight


---

### 1418. msg_14526

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:41:04

I took it before in my early 20s but forget the impact


---

### 1419. msg_14527

**You** - 2025-05-29T18:41:03

Reaction: 😂 from Meredith Lamb
\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.still processing\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


---

### 1420. msg_14528

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:41:43

I can’t have her asking me to do a bunch of shit tonight


---

### 1421. msg_14529

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:42:18


*1 attachment(s)*


---

### 1422. msg_14530

**You** - 2025-05-29T18:42:22

I got the note on the way home\.


---

### 1423. msg_14531

**You** - 2025-05-29T18:42:37

Also I am getting a doctors appointment this week\.


---

### 1424. msg_14532

**You** - 2025-05-29T18:42:44

Going to get it done\.


---

### 1425. msg_14533

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:45:38

I have a physical on thurs with my dr and will talk to her


---

### 1426. msg_14534

**You** - 2025-05-29T18:45:54

yeah but then you have to be "on" something\.\. when I can just do it and then it is just over\.


---

### 1427. msg_14535

**You** - 2025-05-29T18:46:35

I don't mind\.\. tbh\.\. I just don't think that is fair to have you do that when I could just do this\.


---

### 1428. msg_14536

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T18:48:46

It would probably be faster for me\. I will talk to her


---

### 1429. msg_14537

**You** - 2025-05-29T18:52:15

Faster for yku sure but still not fair in long run\. Talk to her and then maybe you and I could talk?


---

### 1430. msg_14538

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T19:38:14

Yeah k it’s fine honestly


---

### 1431. msg_14539

**You** - 2025-05-29T19:38:50

okie dokie\.\. look forward to chatting about it ☺️


---

### 1432. msg_14540

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T19:55:02


*1 attachment(s)*


---

### 1433. msg_14541

**You** - 2025-05-29T19:55:28

very cute


---

### 1434. msg_14542

**You** - 2025-05-29T19:55:42

I am sure they will love them and love you\!


---

### 1435. msg_14543

**You** - 2025-05-29T20:45:11

Oh and on the DL wish Mac a happy bday from me I look forward
To more officially meeting her\.


---

### 1436. msg_14544

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T20:52:08


*1 attachment(s)*


---

### 1437. msg_14545

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T20:52:18


*1 attachment(s)*


---

### 1438. msg_14546

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T20:53:06

Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 1439. msg_14547

**You** - 2025-05-29T20:58:38

Really impressive mer\.\.  Your girls are so lucky to have a mom like you\.


---

### 1440. msg_14548

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:02:38

Mac is complaining I forgot to get cocktail glasses


---

### 1441. msg_14549

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:02:39

Omg


---

### 1442. msg_14550

**You** - 2025-05-29T21:03:26

I am sure they can make do


---

### 1443. msg_14551

**You** - 2025-05-29T21:03:29

lol


---

### 1444. msg_14552

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:19:33

Right omg


---

### 1445. msg_14553

**You** - 2025-05-29T21:20:20

You just be exhausted despite your midday nap\.


---

### 1446. msg_14554

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:23:00

My country addition

*1 attachment(s)*


---

### 1447. msg_14555

**You** - 2025-05-29T21:24:03

Lol\.  So much effort into this\.  Looks great\.


---

### 1448. msg_14556

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:34:21

I’m done for the night\. I am exhausted ring cameras, clear\. Lol


---

### 1449. msg_14557

**You** - 2025-05-29T21:35:15

Well done mer\.\.  pretty impressive\.\. will be memorable for sure


---

### 1450. msg_14558

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:35:57


*1 attachment(s)*


---

### 1451. msg_14559

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:36:41

I got a thank u\!


---

### 1452. msg_14560

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:36:46

🙄


---

### 1453. msg_14561

**You** - 2025-05-29T21:37:26

lol did they all pile down into there space and leave you be?


---

### 1454. msg_14562

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:42:43

They aren’t here yet\!


---

### 1455. msg_14563

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:42:50

ETA 10\.15 I guess


---

### 1456. msg_14564

**You** - 2025-05-29T21:43:31

Ouch well I won’t be awake to get an update will have to read in the morning\.\. hopefully they and Andrew are in good moods\.


---

### 1457. msg_14565

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:43:58

Gym in morning?


---

### 1458. msg_14566

**You** - 2025-05-29T21:44:03

Of course


---

### 1459. msg_14567

**You** - 2025-05-29T21:44:20

No one said anything tonight btw


---

### 1460. msg_14568

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:44:29

That seems odd


---

### 1461. msg_14569

**You** - 2025-05-29T21:44:37

So I will just go back to my routine\.


---

### 1462. msg_14570

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:44:48

Were you surprised?


---

### 1463. msg_14571

**You** - 2025-05-29T21:45:23

A little


---

### 1464. msg_14572

**You** - 2025-05-29T21:45:32

But certainly not disappointed


---

### 1465. msg_14573

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:45:58

Thats good… so your head is ok and you are going to bed ok?


---

### 1466. msg_14574

**You** - 2025-05-29T21:46:42

My head?


---

### 1467. msg_14575

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:49:51

Like mentally


---

### 1468. msg_14576

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:50:00

Your mindset


---

### 1469. msg_14577

**You** - 2025-05-29T21:50:40

Sure it’s great\.


---

### 1470. msg_14578

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:50:54

Sarcasm?


---

### 1471. msg_14579

**You** - 2025-05-29T21:52:05

I am fine Mer\.  I told you not to worry about me\.


---

### 1472. msg_14580

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:52:40

k, I hope so ❤️


---

### 1473. msg_14581

**You** - 2025-05-29T21:53:10

❤️


---

### 1474. msg_14582

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:54:19

I’ve been missing you since you left but super thankful you came up\. xo


---

### 1475. msg_14583

**You** - 2025-05-29T21:56:41

Reaction: ❤️ from Meredith Lamb
Yeah honestly the more I see you and spend time with you the more I love you doesn’t make sense but it is true\.  It is easier mentally but I do miss you and that will be hard until this is over\.  I am glad I came too\.  Wish I could wake up next to you every morning like this morning\.\. or just watch you nap on the couch\.  All good stuff for me\.


---

### 1476. msg_14584

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T21:59:06

I feel the same way\. It is really wild and perplexing to me also at times but sometimes not because what’s not to love about you\. 🫠😉


---

### 1477. msg_14585

**You** - 2025-05-29T22:03:41

I will be ok Mer\.   I will find ways to stay busy over the next week\.\. will continue to do my workouts and my morning coffee and meditation at my park with my birds\.\. maybe find some time to talk to jim\.\. grab him for a beer or something after work\. Time will def not go by fast these next 60\-90 days\.\. but we will get through\.


---

### 1478. msg_14586

**You** - 2025-05-29T22:04:22

>
There are lots of things not to love\.\. you will find them I promise


---

### 1479. msg_14587

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:09:40

Sorry girls got here


---

### 1480. msg_14588

**You** - 2025-05-29T22:09:55

Send me all the pics and videos and shit that you want
To share as
Well\.\.
I am happy for you and hope
This turns out as you have envisioned it\.


---

### 1481. msg_14589

**You** - 2025-05-29T22:10:06

>
Figured


---

### 1482. msg_14590

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:10:22

Their mothers all sent wine


---

### 1483. msg_14591

**You** - 2025-05-29T22:10:30

Nice\.


---

### 1484. msg_14592

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:10:33

And Cinnabon


---

### 1485. msg_14593

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:10:37

And Craig’s cookies


---

### 1486. msg_14594

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:10:40

And chocolate


---

### 1487. msg_14595

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:10:43

Sheesh


---

### 1488. msg_14596

**You** - 2025-05-29T22:11:17

lol


---

### 1489. msg_14597

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:11:31

>
I hope so but if you are not, it is allowed\.


---

### 1490. msg_14598

**You** - 2025-05-29T22:12:53

If I am not well\.\. 🙂 I will figure it out\.


---

### 1491. msg_14599

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:13:25

\*We\* will\.


---

### 1492. msg_14600

**You** - 2025-05-29T22:17:32

We will later\.\. I will now\.   I want you to focus on Andrew taxes yourself and your situation\.\. it would suck for me to be all done and you still stuck there\.


---

### 1493. msg_14601

**You** - 2025-05-29T22:19:58

But for now I will figure me out\. I am going to try to keep as much away from you as I can\.\. I am not going to self destruct or anything and if anything serious happened and I was having a hard time or coming to grips, I would talk to you\.\. maybe lol\.


---

### 1494. msg_14602

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:22:25

🙄


---

### 1495. msg_14603

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:22:54

Everything is going to be okay so just have faith


---

### 1496. msg_14604

**You** - 2025-05-29T22:24:16

lol and in that I am going to go to bed\.\. I love you Meredith\.\. have a great time you deserve it\.\. and Remeber focus on you and your
Situation you can’t fix me\.\. and you can only be there with me if you are sorted\.


---

### 1497. msg_14605

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T22:25:34

Sweet dreams 😴 ❤️ I love you


---

### 1498. msg_14606

**You** - 2025-05-29T22:25:57

Nite I love you too\.\. xo ❤️❤️❤️❤️


---

### 1499. msg_14607

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T23:26:49


*1 attachment(s)*


---

### 1500. msg_14608

**You** - 2025-05-29T23:31:05

Cute


---

### 1501. msg_14609

**You** - 2025-05-29T23:31:13

Can’t sleep yet\.\. 🙁


---

### 1502. msg_14610

**You** - 2025-05-29T23:31:33

Watching my geeky gamer movie but I think you’d kinda like it maybe


---

### 1503. msg_14611

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T23:32:09

They are listening to country music :\)


---

### 1504. msg_14612

**You** - 2025-05-29T23:32:19

Well that’s something


---

### 1505. msg_14613

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T23:32:22

>
You aren’t done it yet?


---

### 1506. msg_14614

**You** - 2025-05-29T23:32:38

Nope was working earlier on the stupid thing I have to do tomorrow


---

### 1507. msg_14615

**Meredith Lamb \(\+14169386001\)** - 2025-05-29T23:33:07

Oh I forgot\! What time


---

### 1508. msg_14616

**You** - 2025-05-29T23:35:55

Reaction: 😂 from Meredith Lamb
10 am you will be asleep


---

### 1509. msg_14617

**You** - 2025-05-29T23:36:12

You don’t need to show up just enjoy your sleep in and day off


---

### 1510. msg_14618

**You** - 2025-05-30T04:11:54

Hope the rest of night was fun and uneventful\.  Up for the gym\.


---

### 1511. msg_14619

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:39:43

I went to sleep so it was great :\) woke up at 3\.30am and all was quiet \.\. I just shut lights off basically\. I love your 4am messages ❤️


---

### 1512. msg_14620

**You** - 2025-05-30T07:40:27

lol always something to wake up to
🥰


---

### 1513. msg_14621

**You** - 2025-05-30T07:40:34

Virtually at least


---

### 1514. msg_14622

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:42:54

With Andrew showing up, it got me thinking about you wondering if I would do anything with him when I was all messed up and/or drunk… it’s a big no, but I get the concern\. You know, we have never had a sexual relationship like you and I\. It has always been very different and hence not very fun most of the years/time\. Like even the beginning I remember when I was pregnant with Mac\. He had many expectations and made certain things feel very obligatory\. I don’t feel anything like that with you so our experience together is different\. I would never choose to go back, messed up, drunk or not\. FYI\.


---

### 1515. msg_14623

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:44:56

Just want you to know that I’m into you, not sex in general\. :p


---

### 1516. msg_14624

**You** - 2025-05-30T07:45:45

I appreciate that mer… tbh I have always been quite self
Conscious in this particular area\.\. I cannot possibly understand any word like obligation being associated with it\.\. completely foreign to me\.\. I would want to be with you because you want to be with me\.\. that’s it\.  I very much enjoy being with you it isn’t like anything I have experienced before\.\. very intimate\.\. literally blows my mind, heart and well everything else\.


---

### 1517. msg_14625

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:47:17

Some guys don’t care about obligation type feelings for women\. You are clearly different\. :\)


---

### 1518. msg_14626

**You** - 2025-05-30T07:47:29

You should never worry about me being bored\.\. you are what I want\.\. the watching movies,
The kissing, the working in shit together all of it\.
I will confide something in you\.\. while I am 1000% in favour of not having any more children\.\. I have
To confess for a second yesterday I thought about it lol… just bad timing\.


---

### 1519. msg_14627

**You** - 2025-05-30T07:48:01

No I was more the opposite I want to make you happy because that is what makes me the most happy\.


---

### 1520. msg_14628

**You** - 2025-05-30T07:48:23

>
And I did feel a tiny bit sad lol\.\.


---

### 1521. msg_14629

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:48:24

>
lol super bad timing, like only 10 years too late


---

### 1522. msg_14630

**You** - 2025-05-30T07:48:26

Irrational


---

### 1523. msg_14631

**You** - 2025-05-30T07:48:45

Hope you weren’t too sick from the pill


---

### 1524. msg_14632

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:49:00

I wasn’t at all actually\. Makes me think it didn’t work


---

### 1525. msg_14633

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:49:03

Ack


---

### 1526. msg_14634

**You** - 2025-05-30T07:49:26

lol don’t say that


---

### 1527. msg_14635

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:49:57

I think I was just so hung over and not eating a lot, I probably couldn’t get any sicker feeling\. Lol


---

### 1528. msg_14636

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:50:01

I’m just used to it


---

### 1529. msg_14637

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:50:15

Feel fine today


---

### 1530. msg_14638

**You** - 2025-05-30T07:50:18

ROFL\.\. what brought on all the thoughts btw in the first place?


---

### 1531. msg_14639

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:50:30

Andrew being here I think


---

### 1532. msg_14640

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:50:47

And you wondering if we did anything last weekend


---

### 1533. msg_14641

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:52:06

Like when I was pregnant with Mac, I had horrible nausea for the first 14 weeks\. I didn’t feel like sex at all so he thought I should just do “other stuff”… it began very early on and then I hated all that crap


---

### 1534. msg_14642

**You** - 2025-05-30T07:52:09

I guess it
Kind of came
Down to this\.\. consciously I don’t believe
You would ever do anything but the way you have talked about him and his lack of respect\.\. and that experience you had with that “friend” where you blacked out… that is more what concerned me


---

### 1535. msg_14643

**You** - 2025-05-30T07:52:43

>
For the record I have never been comfortable with other stuff\.


---

### 1536. msg_14644

**You** - 2025-05-30T07:52:49

It is very weird


---

### 1537. msg_14645

**You** - 2025-05-30T07:53:05

Now what you do\.\. umm


---

### 1538. msg_14646

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:53:19

>
Yeah I know\. I was just trying to reassure I guess\. Add some context


---

### 1539. msg_14647

**You** - 2025-05-30T07:53:23

Yeah… that is different but I think it is a trust thing among other things


---

### 1540. msg_14648

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:53:54

>
You more comfortable? Lol


---

### 1541. msg_14649

**You** - 2025-05-30T07:54:07

Like at risk of tmi I would never let J ever do that\.


---

### 1542. msg_14650

**You** - 2025-05-30T07:54:12

Ever


---

### 1543. msg_14651

**You** - 2025-05-30T07:54:31

In 25 years


---

### 1544. msg_14652

**You** - 2025-05-30T07:54:33

lol


---

### 1545. msg_14653

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:54:54

Interesting\. And Andrew was pissed because I stopped many years ago bc he made it no fun\.


---

### 1546. msg_14654

**You** - 2025-05-30T07:55:39

Deleted


---

### 1547. msg_14655

**You** - 2025-05-30T07:55:40

Eesh


---

### 1548. msg_14656

**You** - 2025-05-30T07:55:46

Not going down that road\.


---

### 1549. msg_14657

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:56:02

No go down that road… I’m curious


---

### 1550. msg_14658

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:56:23

I think you feel it is an obligation for women maybe


---

### 1551. msg_14659

**You** - 2025-05-30T07:56:23

It was more to spare me but ok


---

### 1552. msg_14660

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:56:45

I remember you saying once “you don’t have to” during the long weekend


---

### 1553. msg_14661

**You** - 2025-05-30T07:56:46

I feel like based on the text and what you have told me\.\. I can imagine his requirements


---

### 1554. msg_14662

**You** - 2025-05-30T07:57:06

>
I feel it is or isn’t


---

### 1555. msg_14663

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:57:40

Super non\-committal\. Nice


---

### 1556. msg_14664

**You** - 2025-05-30T07:57:55

Confused?????


---

### 1557. msg_14665

**You** - 2025-05-30T07:57:58

Lost


---

### 1558. msg_14666

**You** - 2025-05-30T07:58:20

Please restart\.\.


---

### 1559. msg_14667

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:58:24

>
Not exactly, he didn’t require what I know you are thinking\.


---

### 1560. msg_14668

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:58:50

>
You said “I feel like it is or it isn’t” … super non\-committal


---

### 1561. msg_14669

**You** - 2025-05-30T07:58:49

You don’t know what I am thinking


---

### 1562. msg_14670

**You** - 2025-05-30T07:58:50

lol


---

### 1563. msg_14671

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:59:20

I think I do


---

### 1564. msg_14672

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T07:59:24

I read the text


---

### 1565. msg_14673

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:00:07

Anyway, with you or any past people other than Andrew, never felt like an obligation\. FYI\.


---

### 1566. msg_14674

**You** - 2025-05-30T08:00:59

Ok let me back this up\.\. my comment o\. Andrew\.\. while I am not experience in this area personally I am also not ignorant\.\. lol I have friends k know all the shit they would try to have done to them\.\. so I have some idea\.


---

### 1567. msg_14675

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:01:09

I don’t want you to think I’m doing anything out of obligation\. Not starting that\. Isn’t healthy\.


---

### 1568. msg_14676

**You** - 2025-05-30T08:01:29

Oh ok\.\. yeah no sex isn’t obligatory at all\.


---

### 1569. msg_14677

**You** - 2025-05-30T08:01:47

It is totally a respect thing, mutually engaged hopefully enjoyed etc\.


---

### 1570. msg_14678

**You** - 2025-05-30T08:02:17

Nothing is obligatory


---

### 1571. msg_14679

**You** - 2025-05-30T08:02:44

I mean sure love support mutual respect\.\. I don’t
Like saying obligatory ever but it is foundational\.


---

### 1572. msg_14680

**You** - 2025-05-30T08:02:49

That is a better word


---

### 1573. msg_14681

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:03:14

>
So why haven’t you stopped me?


---

### 1574. msg_14682

**You** - 2025-05-30T08:03:25

Although… studies show a healthy sexual relationship can also lead to an overall healthy relationship\.


---

### 1575. msg_14683

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:04:06

>
Right but there are so many ways to have an unhealthy sexual relationship too\. Experienced that for sure\.


---

### 1576. msg_14684

**You** - 2025-05-30T08:04:06

>
1 it feels amazing, 2 it is you and I trust
You implicitly 3 I don’t think you would do it if you didn’t want to\.\. and I didn’t want you to think I wouldn’t want you to either\.


---

### 1577. msg_14685

**You** - 2025-05-30T08:04:26

>
Yeah I don’t have that experience with j or anyone else
For that matter


---

### 1578. msg_14686

**You** - 2025-05-30T08:04:37

Well unhealthy as in not having it nearly ever


---

### 1579. msg_14687

**You** - 2025-05-30T08:04:42

I mean yeah that\.\.


---

### 1580. msg_14688

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:05:17

>
Well this makes me happy because I feel like we really know each other\. I want to be a safe space for you bc you are for me\.


---

### 1581. msg_14689

**You** - 2025-05-30T08:06:17

You are a safe
Space\. Completely I have told you virtually everything without holding back and without regret


---

### 1582. msg_14690

**You** - 2025-05-30T08:06:34

Even the real embarrassing and insecure stuff


---

### 1583. msg_14691

**You** - 2025-05-30T08:07:43

Additionally there is the time factor


---

### 1584. msg_14692

**You** - 2025-05-30T08:08:10

While it is overwhelming I know how much I love you how\.\. and it is so far beyond anything I have experienced


---

### 1585. msg_14693

**You** - 2025-05-30T08:08:22

I don’t want it to take years


---

### 1586. msg_14694

**You** - 2025-05-30T08:08:30

For you to get to know me


---

### 1587. msg_14695

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:11:38

You have definitely helped move things along faster\. Very open :\)


---

### 1588. msg_14696

**You** - 2025-05-30T08:12:07

No regrets


---

### 1589. msg_14697

**You** - 2025-05-30T08:16:33

Kk I am getting home you might have gone back
To sleep or girls are up or whatever\.\. I have to go in and get maddie up\.\. and get her going to school then quick last prep for this stupid 10 am meeting\.\. I assume if Andrew made any progress on agreement you would have mentioned something\.\. I will share whatever I find out later todays


---

### 1590. msg_14698

**You** - 2025-05-30T08:16:41

Love you\!\!


---

### 1591. msg_14699

**You** - 2025-05-30T08:16:48

Xoxoxoxo ❤️❤️❤️❤️❤️


---

### 1592. msg_14700

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T08:19:47

I’m walking dogs\. Griffin got me up early today\. Weird\. I asked last night and Andrew started taxes but didn’t finish :p
k I will talk to you later\. Have a good morning ❤️


---

### 1593. msg_14701

**You** - 2025-05-30T08:21:55

I will you too❤️


---

### 1594. msg_14702

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:03:14


*1 attachment(s)*


---

### 1595. msg_14703

**You** - 2025-05-30T11:06:06

So tired


---

### 1596. msg_14704

**You** - 2025-05-30T11:06:16

How long were you in the call\.


---

### 1597. msg_14705

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:07:51

Almost the whole call\. Missed the beginning\. Then had to vacuum quick at one point but otherwise got it all


---

### 1598. msg_14706

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:08:25

It was good\. Erin said she needs something even simpler tho because she hasn’t used it at all :p I think most ppl have played around with it


---

### 1599. msg_14707

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:08:30

She is an anomaly


---

### 1600. msg_14708

**You** - 2025-05-30T11:08:47

It was tiring no energy


---

### 1601. msg_14709

**You** - 2025-05-30T11:09:02

You kissed the charicature fun time


---

### 1602. msg_14710

**You** - 2025-05-30T11:09:13

I took your brothers drawing kf me and improved on it lol


---

### 1603. msg_14711

**You** - 2025-05-30T11:09:22

Will send it to you in teams


---

### 1604. msg_14712

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:09:25

lol


---

### 1605. msg_14713

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:09:40

Of course you did


---

### 1606. msg_14714

**You** - 2025-05-30T11:09:53

Sent


---

### 1607. msg_14715

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:10:14

Shit my internet just disconnected


---

### 1608. msg_14716

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:10:28

Oh it’s back


---

### 1609. msg_14717

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:16:58

https://open\.spotify\.com/track/0qRR9d89hIS0MHRkQ0ejxX?si=X9JdyeGtRZyOho2gFEinww
Girls are blaring this and making brunch THEMSELVES\!


---

### 1610. msg_14718

**You** - 2025-05-30T11:19:06

Awesome\.\. like\.\. sounds like I am glad
You are there and not me\.\.


---

### 1611. msg_14719

**You** - 2025-05-30T11:19:22

But for you I would be there if you wanted me to and I could be lol\. Just for you though


---

### 1612. msg_14720

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:20:04

Of COURSE I would want you to be here\.


---

### 1613. msg_14721

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:23:25

Wifi is spotty now because of all the girls and Andrew in calls lol just clued in to that


---

### 1614. msg_14722

**You** - 2025-05-30T11:26:01

Ah well you shouldn’t be online anyways you should be resting or having fun etc


---

### 1615. msg_14723

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:26:36

Waiting for the twins to show up so I can go to store


---

### 1616. msg_14724

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:26:49

Mac wants me here bc their dad is dropping them off and apparently he is mean


---

### 1617. msg_14725

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:26:52

lol


---

### 1618. msg_14726

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:27:02

They are 15 min out


---

### 1619. msg_14727

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:28:11

They just asked me if I want a mimosa


---

### 1620. msg_14728

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:28:18

I said no thanks 😇


---

### 1621. msg_14729

**You** - 2025-05-30T11:28:51

Well if Andrew is staying you can have some fun\.\. you won’t need to drive


---

### 1622. msg_14730

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:29:33

He is leaving after the workday


---

### 1623. msg_14731

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:29:42

He doesn’t have a 3 hr window to drive


---

### 1624. msg_14732

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:29:53

AND he did the dump trip this morning 🎉🎉🎉🎉


---

### 1625. msg_14733

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:29:57

I didn’t have to


---

### 1626. msg_14734

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:30:29

The ring now :\(

*1 attachment(s)*


---

### 1627. msg_14735

**You** - 2025-05-30T11:32:17

lol nice


---

### 1628. msg_14736

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:32:50

I will not be partaking in the mimosas \(my mantra\)

*1 attachment(s)*


---

### 1629. msg_14737

**You** - 2025-05-30T11:34:04

No more coming to cottage for me\.


---

### 1630. msg_14738

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:34:44

Well once we confirm we are keeping cottage together somehow we need to get rid of ring\. We already talked about it\.


---

### 1631. msg_14739

**You** - 2025-05-30T11:34:54

Glad I got up there and saw dogs again


---

### 1632. msg_14740

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:35:18

>
And we both seem on the same page there\.


---

### 1633. msg_14741

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:35:32

It’s just when does that happen? Not sure


---

### 1634. msg_14742

**You** - 2025-05-30T11:36:10

Well wait until you see the numbers first


---

### 1635. msg_14743

**You** - 2025-05-30T11:36:17

Wrote you agree agree


---

### 1636. msg_14744

**You** - 2025-05-30T11:36:24

Before


---

### 1637. msg_14745

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:36:28

Yeah have to wait for a bit for sure


---

### 1638. msg_14746

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:37:01

My girlfriends confirmed they are coming up aug1\-3 weekend fyi


---

### 1639. msg_14747

**You** - 2025-05-30T11:37:06

Reaction: ❤️ from Meredith Lamb
September 15


---

### 1640. msg_14748

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:37:16

lol


---

### 1641. msg_14749

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:37:19

Probably


---

### 1642. msg_14750

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:37:24

Hopefully before


---

### 1643. msg_14751

**You** - 2025-05-30T11:37:31

>
Good I should be all quiet by then j and girls gone


---

### 1644. msg_14752

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:37:36

I still have faith in before sept 15


---

### 1645. msg_14753

**You** - 2025-05-30T11:37:39

Will just be me in house most of august


---

### 1646. msg_14754

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:38:25

Both girls gone?


---

### 1647. msg_14755

**You** - 2025-05-30T11:39:24

Yep


---

### 1648. msg_14756

**You** - 2025-05-30T11:39:29

Everyone


---

### 1649. msg_14757

**You** - 2025-05-30T11:39:30

Just me


---

### 1650. msg_14758

**You** - 2025-05-30T11:39:40

All alone in a big house


---

### 1651. msg_14759

**You** - 2025-05-30T11:39:50

I am pretty sure but who knows it could change


---

### 1652. msg_14760

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:40:00

Yaye new music doc coming

*1 attachment(s)*


---

### 1653. msg_14761

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:40:30

>
So August could be interesting


---

### 1654. msg_14762

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:40:42

We’ll see


---

### 1655. msg_14763

**You** - 2025-05-30T11:42:46

Yep could be interesting just need to get there lol


---

### 1656. msg_14764

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T11:50:15

So the dad wasn’t mean\. Probably just doesn’t like teen girls


---

### 1657. msg_14765

**You** - 2025-05-30T11:50:47

ROFL yeah they can be challenging


---

### 1658. msg_14766

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T13:22:19

They are fun so far tho\. At least for me lol


---

### 1659. msg_14767

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T13:22:31


*1 attachment(s)*


---

### 1660. msg_14768

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T13:23:05

Making them an Oreo lasagna for dessert tonight


---

### 1661. msg_14769

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T13:23:26

My friends switched to Aug 7\-10


---

### 1662. msg_14770

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T13:24:01

Our friend that has a hubby with cancer can’t go Aug 1\-3 and everyone really wants her there\. She can go Aug 7\-10 so people are shifting plans for her


---

### 1663. msg_14771

**You** - 2025-05-30T13:48:41

They look pretty happy\.


---

### 1664. msg_14772

**You** - 2025-05-30T13:49:20

>
So far out I have no clue what is going on\.\. but glad you will get your weekend\.


---

### 1665. msg_14773

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T13:53:29

They are so happy\. In their bikinis and off to hick rock to jump off the cliff


---

### 1666. msg_14774

**You** - 2025-05-30T14:02:19

This will
Be memorable for all of them I am sure


---

### 1667. msg_14775

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:18:15

Forgot to show you that\. Right afterwards she was complaining about something\. :p

*1 attachment(s)*


---

### 1668. msg_14776

**You** - 2025-05-30T14:33:19

ROFL


---

### 1669. msg_14777

**You** - 2025-05-30T14:33:37

Appreciate you sharing


---

### 1670. msg_14778

**You** - 2025-05-30T14:33:39

With her


---

### 1671. msg_14779

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:38:55

They just made me do a photo shoot at high rock


---

### 1672. msg_14780

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:38:58

lol


---

### 1673. msg_14781

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:40:10

They all jumped off and said the water “stung”\. I was like “it IS may\!”


---

### 1674. msg_14782

**You** - 2025-05-30T14:40:47

Yeah like 60 degree water


---

### 1675. msg_14783

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:52:44

So Andrew knew about the oven\. Just told me\. He thinks it works fine on convection though so I will have to tell him no at some point\.


---

### 1676. msg_14784

**You** - 2025-05-30T14:52:56

ROFL


---

### 1677. msg_14785

**You** - 2025-05-30T14:53:00

Least it wasn’t me


---

### 1678. msg_14786

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:55:46

lol can’t believe he never mentioned it to me


---

### 1679. msg_14787

**You** - 2025-05-30T14:56:21

Maybe he was scared of you


---

### 1680. msg_14788

**You** - 2025-05-30T14:56:28

You can be scary\!\!


---

### 1681. msg_14789

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:56:50

Haha or maybe we just have a lot going on :p


---

### 1682. msg_14790

**You** - 2025-05-30T14:58:11

Maybe I think the fear factor though


---

### 1683. msg_14791

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T14:59:08

lol whatever


---

### 1684. msg_14792

**You** - 2025-05-30T15:02:47

Whatever


---

### 1685. msg_14793

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T15:03:43

I am the furthest thing from scary\. It’s laughable to even think about


---

### 1686. msg_14794

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T15:03:57

Pretty sure at work ppl are scared of YOU


---

### 1687. msg_14795

**You** - 2025-05-30T15:22:13

I am scared of you you are the boss\!\!\!


---

### 1688. msg_14796

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T15:56:25

I think you just want me to be the boss


---

### 1689. msg_14797

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T15:56:27

lol


---

### 1690. msg_14798

**You** - 2025-05-30T15:57:35

Yep


---

### 1691. msg_14799

**You** - 2025-05-30T15:57:44

I am all about that\.


---

### 1692. msg_14800

**You** - 2025-05-30T15:57:53

😋


---

### 1693. msg_14801

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T15:59:33

Tired of being the boss at work


---

### 1694. msg_14802

**You** - 2025-05-30T16:02:46

You are\.\. I am\.\.


---

### 1695. msg_14803

**You** - 2025-05-30T16:03:01

Just tired honestly long day\. And now I get to work


---

### 1696. msg_14804

**You** - 2025-05-30T16:03:16

More


---

### 1697. msg_14805

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:04:29

Really at 4?


---

### 1698. msg_14806

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:04:34

Work work or house work?


---

### 1699. msg_14807

**You** - 2025-05-30T16:05:09

House work no one did anything today\.\.


---

### 1700. msg_14808

**You** - 2025-05-30T16:05:27

So going to build
Some dump runs in the garage\.


---

### 1701. msg_14809

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:07:49

I’m at the grocery store for the third time today yay


---

### 1702. msg_14810

**You** - 2025-05-30T16:09:49

Jesus wow


---

### 1703. msg_14811

**You** - 2025-05-30T16:09:59

Hopefully local not the far away one


---

### 1704. msg_14812

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:13:34

Yeah for sure


---

### 1705. msg_14813

**You** - 2025-05-30T16:14:22

Well I am just going to be in here listening to music and ripping shit apart yay\!\!\! Kids won’t help nothing it’s awesome


---

### 1706. msg_14814

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:40:14

I can’t take it

*1 attachment(s)*


---

### 1707. msg_14815

**You** - 2025-05-30T16:41:06

Reaction: ❤️ from Meredith Lamb
I fucking TOLD YOU SO\!\!\!\!\!


---

### 1708. msg_14816

**You** - 2025-05-30T16:41:08

Ahh


---

### 1709. msg_14817

**You** - 2025-05-30T16:41:11

That felt
Good


---

### 1710. msg_14818

**You** - 2025-05-30T16:41:16

Was holding that in


---

### 1711. msg_14819

**You** - 2025-05-30T16:41:31

Now it’s out I feel better


---

### 1712. msg_14820

**You** - 2025-05-30T16:41:48

Gummies are next


---

### 1713. msg_14821

**You** - 2025-05-30T16:41:52

Just text me when


---

### 1714. msg_14822

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:43:22

Oh stop acting like you know me


---

### 1715. msg_14823

**You** - 2025-05-30T16:44:02

ROFL I do know you\!\!\! And love every bit of it\.\. even this slightly silly part\.


---

### 1716. msg_14824

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T16:51:59

🙈


---

### 1717. msg_14825

**You** - 2025-05-30T16:56:17

Have fun I am around puttering still going to bed early and gym tomorrow\.\. very disappointed in people around here no one willing to work\.


---

### 1718. msg_14826

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:17:02

I’m going to sit for a bit and continue my doc\. Girls had apps at 4 so we are doing dinner late thank goodness


---

### 1719. msg_14827

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:17:57

What’s the excuse for not helping?


---

### 1720. msg_14828

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:18:09

“It’s all your fault” ?


---

### 1721. msg_14829

**You** - 2025-05-30T17:21:11

Yeah


---

### 1722. msg_14830

**You** - 2025-05-30T17:21:13

It is


---

### 1723. msg_14831

**You** - 2025-05-30T17:21:19

I guess


---

### 1724. msg_14832

**You** - 2025-05-30T17:21:43

It’s fine hopefully tomorrow j will be more motivated and in turn motivate kids\.


---

### 1725. msg_14833

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:25:06

You should just relax tonight\.


---

### 1726. msg_14834

**You** - 2025-05-30T17:27:02

And do what\.\.


---

### 1727. msg_14835

**You** - 2025-05-30T17:27:10

Don’t say watch docs…\.\.


---

### 1728. msg_14836

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:27:15

lol


---

### 1729. msg_14837

**You** - 2025-05-30T17:27:18

Negative


---

### 1730. msg_14838

**You** - 2025-05-30T17:28:02

Might go to the gym


---

### 1731. msg_14839

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:28:11

We need an online version of ticket to ride :p


---

### 1732. msg_14840

**You** - 2025-05-30T17:28:24

lol
For iPhone yku mean


---

### 1733. msg_14841

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:28:48

I only have my iPhone and work laptop right now


---

### 1734. msg_14842

**You** - 2025-05-30T17:29:23

https://apps\.apple\.com/ca/app/ticket\-to\-ride\-the\-board\-game/id6463616555


---

### 1735. msg_14843

**You** - 2025-05-30T17:29:46

lol


---

### 1736. msg_14844

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:30:22

I’m I did not know that existed


---

### 1737. msg_14845

**You** - 2025-05-30T17:30:39

Most of those board games have been ported to iPhone in some form


---

### 1738. msg_14846

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:31:06

Do you think it’s bad


---

### 1739. msg_14847

**You** - 2025-05-30T17:31:59

Great question\. While Ticket to Ride iOS is a faithful adaptation of the board game, there are a few key differences—some subtle, some impactful—between the digital version and the physical tabletop version\.
⸻
🎯 Core Gameplay – Same
•	Rules, objectives, and mechanics are identical to the board game\.
•	Train routes, destination tickets, scoring system, and gameplay flow are all preserved\.
⸻
🔁 What’s Different
1\. Setup & Scoring
•	✅ iOS: Setup is instant, and scoring is automated \(including longest route detection and completed tickets\)\.
•	🧩 Board Game: Manual setup takes time, and scoring is done by hand \(can be error\-prone\)\.
2\. Game Speed
•	✅ iOS: Much faster turns, especially in solo play\. No shuffling, counting, or disputes\.
•	🧩 Board Game: Slower pace, especially with new players or when double\-checking rules\.
3\. Rule Enforcement
•	✅ iOS: Strict rules are enforced by the app; no accidental cheating or missed rules\.
•	🧩 Board Game: Players can make mistakes in rules or scoring \(espec\.\.\. \[truncated\]


---

### 1740. msg_14848

**You** - 2025-05-30T17:32:50

The iOS version of Ticket to Ride has generally been well\-received, praised for its faithful adaptation of the board game and its convenience\. However, it has also faced criticism, particularly following a significant overhaul\. Here’s an overview of its reception:
⸻
✅ Strengths
•	Faithful Adaptation: The app closely mirrors the physical board game, maintaining its core mechanics and strategic depth\.
•	User\-Friendly Interface: The digital format streamlines gameplay with automated scoring, tutorials, and intuitive controls, making it accessible to both new and seasoned players\.
•	Multiplayer Options: Offers various modes including solo play against AI, online multiplayer, and pass\-and\-play, catering to different playstyles\.
⸻
⚠️ Criticisms
•	Transition to New App: The shift from the original app to a new version developed by Marmalade Game Studio led to user dissatisfaction\. Players were required to repurchase the game and its expansions, and previous progress or purchases did not carry\.\.\. \[truncated\]


---

### 1741. msg_14849

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:34:17

Rule enforcement?\!?


---

### 1742. msg_14850

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:34:23

🤪


---

### 1743. msg_14851

**You** - 2025-05-30T17:34:24

lol


---

### 1744. msg_14852

**You** - 2025-05-30T17:34:26

Hahaha


---

### 1745. msg_14853

**You** - 2025-05-30T17:34:30

Thought you would like that


---

### 1746. msg_14854

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:34:39

Love


---

### 1747. msg_14855

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:34:42

Not


---

### 1748. msg_14856

**You** - 2025-05-30T17:35:06

I might dl and try it is only 7


---

### 1749. msg_14857

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:35:28

k we can play it later tonight?


---

### 1750. msg_14858

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:35:45

I don’t want to think quite yet


---

### 1751. msg_14859

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:35:51

lol


---

### 1752. msg_14860

**You** - 2025-05-30T17:36:02

Reaction: 👍 from Meredith Lamb
Sure I am going to dl now though just to see


---

### 1753. msg_14861

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:36:46

Girls are going in boat across lake so I need to go down and make sure they all have lifejackets


---

### 1754. msg_14862

**You** - 2025-05-30T17:37:40

Kk


---

### 1755. msg_14863

**You** - 2025-05-30T17:37:57

Think about any other games you might be interested in playing card games crib whatever lol


---

### 1756. msg_14864

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:49:58

I forget how to play crib but would totally play


---

### 1757. msg_14865

**You** - 2025-05-30T17:50:37

Reaction: 👍 from Meredith Lamb
I will find a good platform


---

### 1758. msg_14866

**You** - 2025-05-30T17:50:48

Ticket to ride is easy to play different rules


---

### 1759. msg_14867

**You** - 2025-05-30T17:51:04

And playing with ai players is pretty cut throat


---

### 1760. msg_14868

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T17:53:53

But can you not play with ai players?


---

### 1761. msg_14869

**You** - 2025-05-30T17:54:07

https://apps\.apple\.com/ca/app/cribbage\-pro/id409644287


---

### 1762. msg_14870

**You** - 2025-05-30T17:54:26

Yes


---

### 1763. msg_14871

**You** - 2025-05-30T17:54:31

You can just play you and I


---

### 1764. msg_14872

**You** - 2025-05-30T17:54:40

The crib one is free


---

### 1765. msg_14873

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:02:13

Downloaded crib but I will need to do the tutorial


---

### 1766. msg_14874

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:02:19

Waiting for Andrew to leave :p


---

### 1767. msg_14875

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:02:38

Ticket to ride is downloading and taking a long time


---

### 1768. msg_14876

**You** - 2025-05-30T18:06:46

lol you will want to do the tutorial for it as well


---

### 1769. msg_14877

**You** - 2025-05-30T18:07:06

It isn’t as bad for me on an iPad\.


---

### 1770. msg_14878

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:10:35

For crib reading in ChatGPT


---

### 1771. msg_14879

**You** - 2025-05-30T18:10:38

lol


---

### 1772. msg_14880

**You** - 2025-05-30T18:10:41

cmon it is easy


---

### 1773. msg_14881

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:11:49

I haven’t played since I was a kid


---

### 1774. msg_14882

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:11:52

Not easy


---

### 1775. msg_14883

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:12:37

Omg Mac wants me to start making dinner


---

### 1776. msg_14884

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:12:44

This doesn’t feel “late”


---

### 1777. msg_14885

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:12:54

She just texted me from the middle of the lake


---

### 1778. msg_14886

**You** - 2025-05-30T18:13:02

rofl ah well a mothers work is never done


---

### 1779. msg_14887

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:24:19

I’m having a second glass of wine but this is not going to go south\. Don’t worry


---

### 1780. msg_14888

**You** - 2025-05-30T18:25:02

uh huh\.


---

### 1781. msg_14889

**You** - 2025-05-30T18:26:12

in a little while\.\. \- on glass four\.\. it is all good, because I can still only see two glasses\.\. it hasn't gotten worse\.\. lol


---

### 1782. msg_14890

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:31:05

Andrew stayed bc he was worried Mac would wreck the motor at the beach across the lake


---

### 1783. msg_14891

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:31:22

She got home and he is outside and I’m like “did you wreck the motor?”


---

### 1784. msg_14892

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:31:27

Her: almost


---

### 1785. msg_14893

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:31:42

She’s like “I had to dig it out of the sand\. Don’t tell him”


---

### 1786. msg_14894

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:31:47

Sigh…\.\.


---

### 1787. msg_14895

**You** - 2025-05-30T18:33:10

lol


---

### 1788. msg_14896

**You** - 2025-05-30T18:33:15

Good times


---

### 1789. msg_14897

**You** - 2025-05-30T18:40:27

Well if he is staying tonight we can try playing tomorrow all good


---

### 1790. msg_14898

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:41:37

He just left :\)


---

### 1791. msg_14899

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:43:37

Almost done dinner\. They are just having a taco night so super easy


---

### 1792. msg_14900

**You** - 2025-05-30T18:44:10

Yeah I used to make that all the time… good for my diet too but I have as a salad


---

### 1793. msg_14901

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:45:13

LOL


---

### 1794. msg_14902

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:45:09

You love these kind of photos right

*1 attachment(s)*


---

### 1795. msg_14903

**You** - 2025-05-30T18:56:39

Reaction: 😂 from Meredith Lamb
Cmon mer\.\.


---

### 1796. msg_14904

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T18:56:28

k walking dogs briefly in bugs and then going to watch tutorial lol


---

### 1797. msg_14905

**You** - 2025-05-30T18:56:52

Kk


---

### 1798. msg_14906

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:01:06

I had a glass of water so I feel sharper


---

### 1799. msg_14907

**You** - 2025-05-30T19:01:33

I mean you will feel
Sharper only though right??


---

### 1800. msg_14908

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:04:57

K I need to concentrate


---

### 1801. msg_14909

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:06:31

This tutorial is shit\. Can you just give me one?


---

### 1802. msg_14910

**You** - 2025-05-30T19:10:51

Which one for crib


---

### 1803. msg_14911

**You** - 2025-05-30T19:10:53

Or ticket


---

### 1804. msg_14912

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:12:54

Crib\. Seems complicated


---

### 1805. msg_14913

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:12:55

lol


---

### 1806. msg_14914

**You** - 2025-05-30T19:13:30

Try get cards to add up to 15 pairs or runs of 3 or more also flush of 4
Or more


---

### 1807. msg_14915

**You** - 2025-05-30T19:13:37

Two cards to the crib each hand


---

### 1808. msg_14916

**You** - 2025-05-30T19:13:43

Take turns getting it\.


---

### 1809. msg_14917

**You** - 2025-05-30T19:13:57

Cut to flip the top card and everyone can use it as a community card


---

### 1810. msg_14918

**You** - 2025-05-30T19:14:05

Then you peg


---

### 1811. msg_14919

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:14:41

>
But how do you know which ones? Throwaways? Ones that don’t add to 15


---

### 1812. msg_14920

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:14:53

Peg?


---

### 1813. msg_14921

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:16:00

Reading\.   …,\.

*1 attachment(s)*


---

### 1814. msg_14922

**You** - 2025-05-30T19:16:15

ROFL


---

### 1815. msg_14923

**You** - 2025-05-30T19:16:30

I think you just need to play\.\. maybe?


---

### 1816. msg_14924

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:17:44

Dealing with this omg

*1 attachment(s)*


---

### 1817. msg_14925

**You** - 2025-05-30T19:18:03

sooooo sad


---

### 1818. msg_14926

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:18:21

>
I can try but this sounds like a lot of math


---

### 1819. msg_14927

**You** - 2025-05-30T19:18:44

you have to set up username and password


---

### 1820. msg_14928

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:19:03

I did


---

### 1821. msg_14929

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:19:11

lamberrym


---

### 1822. msg_14930

**You** - 2025-05-30T19:24:30

sent you an invite


---

### 1823. msg_14931

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:25:18

Wait where don’t see anything?


---

### 1824. msg_14932

**You** - 2025-05-30T19:30:34

hmm


---

### 1825. msg_14933

**You** - 2025-05-30T19:31:00

just sent it again


---

### 1826. msg_14934

**You** - 2025-05-30T19:31:21

You downloaded cribbage pro right


---

### 1827. msg_14935

**You** - 2025-05-30T19:31:59

if you did you actually have to click on multiplayer and log in


---

### 1828. msg_14936

**You** - 2025-05-30T19:36:42

and you have to activate your account under the email in which you set it up


---

### 1829. msg_14937

**You** - 2025-05-30T19:37:57

you might be better off with ticket honestly\.\. lol


---

### 1830. msg_14938

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:38:19

Ok I accepted your friend request\. Sorry had to clean dinner up


---

### 1831. msg_14939

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:38:25

Girls are done


---

### 1832. msg_14940

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:38:30

Doing dessert later


---

### 1833. msg_14941

**You** - 2025-05-30T19:38:29

ah ok\.\. no worries\.\. just wondered if you got confused


---

### 1834. msg_14942

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:38:43

lol no


---

### 1835. msg_14943

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:38:48

I mean NOT YET


---

### 1836. msg_14944

**You** - 2025-05-30T19:39:47

lol


---

### 1837. msg_14945

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:39:55

Wait so what do you select for your crib


---

### 1838. msg_14946

**You** - 2025-05-30T19:39:50

your crivb


---

### 1839. msg_14947

**You** - 2025-05-30T19:39:55

build you hand


---

### 1840. msg_14948

**You** - 2025-05-30T19:40:02

discard to crib


---

### 1841. msg_14949

**You** - 2025-05-30T19:40:28

try to get 15 or 21 or pairs or runs


---

### 1842. msg_14950

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:40:35

I’m clueless


---

### 1843. msg_14951

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:40:36

lol


---

### 1844. msg_14952

**You** - 2025-05-30T19:40:30

in this phase


---

### 1845. msg_14953

**You** - 2025-05-30T19:40:58

disconnected lol\.\.


---

### 1846. msg_14954

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:41:18

What is this 3diamonds

*1 attachment(s)*


---

### 1847. msg_14955

**You** - 2025-05-30T19:41:36

it is community card


---

### 1848. msg_14956

**You** - 2025-05-30T19:41:41

for when you cout hand


---

### 1849. msg_14957

**You** - 2025-05-30T19:42:07

you have a timer lol


---

### 1850. msg_14958

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:42:21

I can’t play this online I have no idea what I’m doing lol


---

### 1851. msg_14959

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:42:31

I need someone to teach me irl


---

### 1852. msg_14960

**You** - 2025-05-30T19:42:46

just play out the hand you will see


---

### 1853. msg_14961

**You** - 2025-05-30T19:43:04

so person who doesnt have crib counts first


---

### 1854. msg_14962

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:44:39

Too confusing online


---

### 1855. msg_14963

**You** - 2025-05-30T19:44:52

try ticket or is that too much for you\.\. 2 glasses in\.\. well 3 now


---

### 1856. msg_14964

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:45:02

I played it with my dad as a kid so I know it isn’t too complicated


---

### 1857. msg_14965

**You** - 2025-05-30T19:45:09

and a gummy


---

### 1858. msg_14966

**You** - 2025-05-30T19:45:11

I bet


---

### 1859. msg_14967

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:45:20

But the online thing is weird


---

### 1860. msg_14968

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:45:29

>
No


---

### 1861. msg_14969

**You** - 2025-05-30T19:45:30

what about the wine count


---

### 1862. msg_14970

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:45:45

Hmm


---

### 1863. msg_14971

**You** - 2025-05-30T19:45:42

LOL


---

### 1864. msg_14972

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:46:09

Stop


---

### 1865. msg_14973

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:46:20

I have 8 girls partying beside me\. It is so hard


---

### 1866. msg_14974

**You** - 2025-05-30T19:46:33

I mean I know\.\. it is\.\.


---

### 1867. msg_14975

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:46:45

lol


---

### 1868. msg_14976

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:46:55

Maybe there is an EASY game


---

### 1869. msg_14977

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:47:05

I feel like ticket to ride is going to be weird online


---

### 1870. msg_14978

**You** - 2025-05-30T19:47:14

it actually wasn;t


---

### 1871. msg_14979

**You** - 2025-05-30T19:47:32

you have to set up this account thing\.\. on right of main secreen called bubble something


---

### 1872. msg_14980

**You** - 2025-05-30T19:47:38

but the rules are diff


---

### 1873. msg_14981

**You** - 2025-05-30T19:47:55

like for instance if you take one of those rainbow train cards\.\. you can only take 1 card that round\.


---

### 1874. msg_14982

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:49:38

😣


---

### 1875. msg_14983

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:50:00

Everytime I open it I can’t get out of it without turning my phone off


---

### 1876. msg_14984

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:50:02

wtf


---

### 1877. msg_14985

**You** - 2025-05-30T19:51:42

lol


---

### 1878. msg_14986

**You** - 2025-05-30T19:52:06

It just slides from the bottom up like any other app\.


---

### 1879. msg_14987

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:52:30

Hi\! I'm playing Ticket To Ride\!\. Get the app here:
https://get\.bubbleplay\.com/TicketToRide
Once you've installed it, sign up to Bubble and be my friend\!
My Friend Code is C90AAC3B623C1FA3
https://invites\.bubbleplay\.com/Bubble/eyJyb3V0ZSI6IkFkZEZyaWVuZCIsIkZyaWVuZENvZGUiOiJDOTBBQUMzQjYyM0MxRkEzIn0=


---

### 1880. msg_14988

**You** - 2025-05-30T19:56:24

ROFL\!\!\!\!


---

### 1881. msg_14989

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:56:44

I have no idea what just happened lol


---

### 1882. msg_14990

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:56:50

It played and I didn’t mean to


---

### 1883. msg_14991

**You** - 2025-05-30T19:56:48

kk I can restart


---

### 1884. msg_14992

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:57:02

It’s fine


---

### 1885. msg_14993

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:57:04

Learning


---

### 1886. msg_14994

**You** - 2025-05-30T19:57:00

no


---

### 1887. msg_14995

**You** - 2025-05-30T19:57:04

it will be an excuse if you lose


---

### 1888. msg_14996

**You** - 2025-05-30T19:57:07

unacceptable


---

### 1889. msg_14997

**You** - 2025-05-30T19:57:08

lol


---

### 1890. msg_14998

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:57:20

No stop


---

### 1891. msg_14999

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:57:27

It won’t be the only learning I’m sure


---

### 1892. msg_15000

**You** - 2025-05-30T19:57:29

kk


---

### 1893. msg_15001

**You** - 2025-05-30T19:57:44

pull cards from the right


---

### 1894. msg_15002

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:58:04

I can’t find my routes\. Gimme a minute


---

### 1895. msg_15003

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T19:58:07

Studying


---

### 1896. msg_15004

**You** - 2025-05-30T19:58:25

the routes are actually reflects on the map with little icons


---

### 1897. msg_15005

**You** - 2025-05-30T19:58:34

and they match each other


---

### 1898. msg_15006

**You** - 2025-05-30T20:03:32

bullshit rainbows\.\.\.


---

### 1899. msg_15007

**You** - 2025-05-30T20:03:52

they hate me


---

### 1900. msg_15008

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:04:00

I don’t get it


---

### 1901. msg_15009

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:04:02

lol


---

### 1902. msg_15010

**You** - 2025-05-30T20:09:05

you are so going to beat me LOL


---

### 1903. msg_15011

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:09:33

Nope I have a shitty hand tbh but we will see :\)


---

### 1904. msg_15012

**You** - 2025-05-30T20:13:05

look at you\!\!


---

### 1905. msg_15013

**You** - 2025-05-30T20:13:11

all completed


---

### 1906. msg_15014

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:15:22

They were dumb tho


---

### 1907. msg_15015

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:15:27

What is happening right now


---

### 1908. msg_15016

**You** - 2025-05-30T20:19:29

:P


---

### 1909. msg_15017

**You** - 2025-05-30T20:19:35

risky


---

### 1910. msg_15018

**You** - 2025-05-30T20:19:37

lol


---

### 1911. msg_15019

**You** - 2025-05-30T20:19:50

hoping for an already completed one for free points


---

### 1912. msg_15020

**You** - 2025-05-30T20:20:42

errrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr


---

### 1913. msg_15021

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:21:03

Oh I wasn’t paying attention to your trains


---

### 1914. msg_15022

**You** - 2025-05-30T20:20:57

you win


---

### 1915. msg_15023

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:21:05

Man


---

### 1916. msg_15024

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:21:06

Shit


---

### 1917. msg_15025

**You** - 2025-05-30T20:21:04

you got 7 completes


---

### 1918. msg_15026

**You** - 2025-05-30T20:21:13

I got 5


---

### 1919. msg_15027

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:21:24

How do you know that


---

### 1920. msg_15028

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:21:28

Mine were small tho


---

### 1921. msg_15029

**You** - 2025-05-30T20:21:24

because it shows on your avatar


---

### 1922. msg_15030

**You** - 2025-05-30T20:21:56

so you have one final play\.\. because I am laying down next turn


---

### 1923. msg_15031

**You** - 2025-05-30T20:22:48

I love you\.\. just saying


---

### 1924. msg_15032

**You** - 2025-05-30T20:22:52

A whole big bunch


---

### 1925. msg_15033

**You** - 2025-05-30T20:23:10

❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️ that much and more


---

### 1926. msg_15034

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:23:19

lol you suck


---

### 1927. msg_15035

**You** - 2025-05-30T20:23:36

I do not


---

### 1928. msg_15036

**You** - 2025-05-30T20:23:53

well\.\.


---

### 1929. msg_15037

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:24:08

I did lose my first turn


---

### 1930. msg_15038

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:24:10

lol


---

### 1931. msg_15039

**You** - 2025-05-30T20:24:05

LOL


---

### 1932. msg_15040

**You** - 2025-05-30T20:24:07

Reaction: 😂 from Meredith Lamb
I knew it


---

### 1933. msg_15041

**You** - 2025-05-30T20:24:25

or it is the 4 or 5 glasses of wine


---

### 1934. msg_15042

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:24:50

I think it is just the online thing PLUS a bad hand


---

### 1935. msg_15043

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:25:00

I had a shitty first hand


---

### 1936. msg_15044

**You** - 2025-05-30T20:24:56

I mean\.\. ok\.\. it could be that


---

### 1937. msg_15045

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:25:20

My thing is “reconnecting”


---

### 1938. msg_15046

**You** - 2025-05-30T20:25:22

your "thing"


---

### 1939. msg_15047

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:25:34

Game


---

### 1940. msg_15048

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:25:42

I think too many girls are online maybe


---

### 1941. msg_15049

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:25:54


*1 attachment(s)*


---

### 1942. msg_15050

**You** - 2025-05-30T20:26:10

perhaps\.\. we don't have to play again\.\.\. you can go watch your show if you want\.


---

### 1943. msg_15051

**You** - 2025-05-30T20:26:21

you might just feel like relaxing and not thinking\.\. I figure\.


---

### 1944. msg_15052

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:27:04

I will play again if it reconnects


---

### 1945. msg_15053

**You** - 2025-05-30T20:31:51

no worries\.\.\. I am good either way\.


---

### 1946. msg_15054

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:33:11

You totally could have come back up here\. Lol just like drive all the time\. They are in the other cottage door shut by themselves\.


---

### 1947. msg_15055

**You** - 2025-05-30T20:33:20

Yeah I would have if this didn't exist down here\.


---

### 1948. msg_15056

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:34:00

😕


---

### 1949. msg_15057

**You** - 2025-05-30T20:34:00

who knows maybe Jaimie and I get in a huge fight tomorrow and I fuck off\.\. lol not likely so don't get hopes up rofl\.


---

### 1950. msg_15058

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:34:45

I could get the girls to disconnect  the side ring in some drunken state\. Believable lol


---

### 1951. msg_15059

**You** - 2025-05-30T20:34:55

totally


---

### 1952. msg_15060

**You** - 2025-05-30T20:34:58

rofl


---

### 1953. msg_15061

**You** - 2025-05-30T20:35:22

again unlikely\.\. I think J is going to have to engage and we need to actually fucking get this cleaning going\.


---

### 1954. msg_15062

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:35:24

🍸🍸🍸


---

### 1955. msg_15063

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:35:45

At dinner they were discussing what kind of drunk they were going to get tonight


---

### 1956. msg_15064

**You** - 2025-05-30T20:35:42

rofl


---

### 1957. msg_15065

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:35:51

Apparently “silly” won


---

### 1958. msg_15066

**You** - 2025-05-30T20:35:45

kids


---

### 1959. msg_15067

**You** - 2025-05-30T20:35:53

was stupid on the table


---

### 1960. msg_15068

**You** - 2025-05-30T20:36:06

wrekt?


---

### 1961. msg_15069

**You** - 2025-05-30T20:36:15

they probably don't know that one


---

### 1962. msg_15070

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:36:23

I was in another room so not sure but there were several options


---

### 1963. msg_15071

**You** - 2025-05-30T20:36:19

I know that one well


---

### 1964. msg_15072

**You** - 2025-05-30T20:36:34

I mean messy, sloppy


---

### 1965. msg_15073

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:36:47

>
When are you thinking of listing?


---

### 1966. msg_15074

**You** - 2025-05-30T20:36:46

asap


---

### 1967. msg_15075

**You** - 2025-05-30T20:36:53

but I have decided I will likely rent


---

### 1968. msg_15076

**You** - 2025-05-30T20:36:58

a condo out of port whitby


---

### 1969. msg_15077

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:37:08

Oh then yeah maybe get going


---

### 1970. msg_15078

**You** - 2025-05-30T20:37:02

right by where I live


---

### 1971. msg_15079

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:37:16

“Port” Whitby?


---

### 1972. msg_15080

**You** - 2025-05-30T20:37:16

The Port


---

### 1973. msg_15081

**You** - 2025-05-30T20:37:23

the Yaht Club


---

### 1974. msg_15082

**You** - 2025-05-30T20:37:30

it is right on top of it


---

### 1975. msg_15083

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:37:52

Renting bc of us or you?


---

### 1976. msg_15084

**You** - 2025-05-30T20:38:04

Reaction: ❤️ from Meredith Lamb
Us\.\. I have to admit\.\. mostly\.


---

### 1977. msg_15085

**You** - 2025-05-30T20:38:11

hopeful


---

### 1978. msg_15086

**You** - 2025-05-30T20:38:28

tbh though what I was thinking\.\.


---

### 1979. msg_15087

**You** - 2025-05-30T20:38:39

was buying somewhere that you might like to live after you are done there


---

### 1980. msg_15088

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:39:08

Like


---

### 1981. msg_15089

**You** - 2025-05-30T20:39:05

I dunno


---

### 1982. msg_15090

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:39:12

lol


---

### 1983. msg_15091

**You** - 2025-05-30T20:39:19

you would have to tell me\.\. It would likely be slightly country\-ish


---

### 1984. msg_15092

**You** - 2025-05-30T20:39:32

problem would be I couldn't afford what I would really want\.\.


---

### 1985. msg_15093

**You** - 2025-05-30T20:39:41

but still I could figure something out'


---

### 1986. msg_15094

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:40:09

We could maybe figure something out together


---

### 1987. msg_15095

**You** - 2025-05-30T20:40:30

we have time for sure\.\. Summer of 2026 would be when I would start looking\.


---

### 1988. msg_15096

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:41:00

So you don’t want to live beside Jim?


---

### 1989. msg_15097

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:41:05

LOL


---

### 1990. msg_15098

**You** - 2025-05-30T20:41:05

No\.\. I want to go where you would want to be\.


---

### 1991. msg_15099

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:41:43

Reaction: ❤️ from Scott Hicks
I mean, currently, I could be anywhere with you and be amazing


---

### 1992. msg_15100

**You** - 2025-05-30T20:41:43

I mean do you want to be closer to parents\.\. north west east??


---

### 1993. msg_15101

**You** - 2025-05-30T20:42:03

>
feel same\.\. wouldn't matter\.\. would be awesome\.


---

### 1994. msg_15102

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:42:40

Are you worried of that blowing up?


---

### 1995. msg_15103

**You** - 2025-05-30T20:42:38

no


---

### 1996. msg_15104

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:42:47

I was reading on ChatGPT


---

### 1997. msg_15105

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:42:50

And


---

### 1998. msg_15106

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:43:16

It said sometimes the secrecy and the manager/employee thjnf can amplify things


---

### 1999. msg_15107

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:43:21

\*thing


---

### 2000. msg_15108

**You** - 2025-05-30T20:43:20

it amplifies anxiety


---

### 2001. msg_15109

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:43:28

Omg drunk girls in my kitchen


---

### 2002. msg_15110

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:43:32

Haha


---

### 2003. msg_15111

**You** - 2025-05-30T20:43:51

honestly\.\. the way I feel isn't a function of secrecy\.\. do you know how much I would like to share this with others \- given I don't get in shit at work\.


---

### 2004. msg_15112

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:44:01

They keep talking about smores


---

### 2005. msg_15113

**You** - 2025-05-30T20:44:17

I am excited about this\.\. proud isn't the right word\.\. but I want people to know\.


---

### 2006. msg_15114

**You** - 2025-05-30T20:44:43

Reaction: 😵‍💫 from Meredith Lamb
Just not J or any of her relations


---

### 2007. msg_15115

**You** - 2025-05-30T20:44:49

:P


---

### 2008. msg_15116

**You** - 2025-05-30T20:45:08

naw she will know soon enough\.\. then we will see what happens\.


---

### 2009. msg_15117

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:45:16

I just keep hearing “can we open these?” I’m in my room and I go “you can open anything you want\!”


---

### 2010. msg_15118

**You** - 2025-05-30T20:45:14

if I get invited home for christmas or not


---

### 2011. msg_15119

**You** - 2025-05-30T20:45:25

>
LOL


---

### 2012. msg_15120

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:46:09

>
She has to know eventually


---

### 2013. msg_15121

**You** - 2025-05-30T20:46:07

yep


---

### 2014. msg_15122

**You** - 2025-05-30T20:46:16

she did ask me if I was coming home for xmas with Maddie


---

### 2015. msg_15123

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:46:32

My therapist said there is no good time\. But yeah get your shit settled first obviously


---

### 2016. msg_15124

**You** - 2025-05-30T20:46:30

Right now I think I am invited\.\. not sure after this though


---

### 2017. msg_15125

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:46:51

>
Omg you will be


---

### 2018. msg_15126

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:47:24

“Meredith?\! Are these cupcakes for tomorrow??”


---

### 2019. msg_15127

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:47:27

lol


---

### 2020. msg_15128

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:47:33

I like teen girls


---

### 2021. msg_15129

**You** - 2025-05-30T20:47:36

she told me to wake her up first thing when I get back from gym and we crushing the garage\.\. that will be really good start\.


---

### 2022. msg_15130

**You** - 2025-05-30T20:47:50

>
I think you want to be a teen girl


---

### 2023. msg_15131

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:48:04

Yes\.


---

### 2024. msg_15132

**You** - 2025-05-30T20:47:59

I mean we are acting like teenagers


---

### 2025. msg_15133

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:48:12

Mid life crisis?


---

### 2026. msg_15134

**You** - 2025-05-30T20:48:14

the making out\.\. all the\.\. other stuff\.


---

### 2027. msg_15135

**You** - 2025-05-30T20:48:32

I already had my mid life crisis at 40


---

### 2028. msg_15136

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:48:45

I’m pretty sure there are some adults doing that stuff too tho lol but yeah teen stuff


---

### 2029. msg_15137

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:48:56

>
For real?


---

### 2030. msg_15138

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:49:02

Did you tell me about this?


---

### 2031. msg_15139

**You** - 2025-05-30T20:49:01

Really\.\. again\.\. I have been so out of touch with all of that\.\. making out was like what???\!\!\!


---

### 2032. msg_15140

**You** - 2025-05-30T20:49:14

Yeah I think I did\.\. mortality issues\.


---

### 2033. msg_15141

**You** - 2025-05-30T20:49:17

went on welbutrin


---

### 2034. msg_15142

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:49:29

Oh right


---

### 2035. msg_15143

**You** - 2025-05-30T20:49:24

but it was all about rationalizing it


---

### 2036. msg_15144

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:49:33

You mentioned that


---

### 2037. msg_15145

**You** - 2025-05-30T20:49:28

and I am fine now


---

### 2038. msg_15146

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:50:17

>
lol sort of the same\. I mean I haven’t liked Andrew for a long time but he tried :p doesn’t work when you have no connection or like


---

### 2039. msg_15147

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:50:56

I think we could continue to make out for quite a while :\)


---

### 2040. msg_15148

**You** - 2025-05-30T20:51:02

Yeah\.\. I mean\.\. there was no trying here\.\.


---

### 2041. msg_15149

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:51:11

Luck maybe\.


---

### 2042. msg_15150

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:51:46

My bro was texting today


---

### 2043. msg_15151

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:51:54

He was surprised my fam doesn’t know about you


---

### 2044. msg_15152

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:52:00

I was all “whaaa?”


---

### 2045. msg_15153

**You** - 2025-05-30T20:52:01

>
I mean yeah\.\. but the other night\.\. on the couch\.\. there was no way I could continue that\.\. like it was crazy\.\. you laughed at me when I said something like "passionate much" lol


---

### 2046. msg_15154

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:52:15

Reaction: ❤️ from Scott Hicks
I told him I will introduce you to mom and dad soon tho


---

### 2047. msg_15155

**You** - 2025-05-30T20:52:24

does he think we look alike?


---

### 2048. msg_15156

**You** - 2025-05-30T20:52:27

lol


---

### 2049. msg_15157

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:52:38

>
Honestly don’t remember that comment


---

### 2050. msg_15158

**You** - 2025-05-30T20:52:44

yeah that was when I got up and said I am going to the other room


---

### 2051. msg_15159

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:52:52

>
Did not ask\. Will not ask\. Because it isn’t true\.


---

### 2052. msg_15160

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:53:12

>
I remember that part


---

### 2053. msg_15161

**You** - 2025-05-30T20:53:15

but yeah\.\. mer I could make out with you or just sit and cuddle\.\. wouldn't matter\.\. it's all good to me\.\.


---

### 2054. msg_15162

**You** - 2025-05-30T20:53:24

but yeah honestly the making out is super fun\.


---

### 2055. msg_15163

**You** - 2025-05-30T20:53:29

tbh


---

### 2056. msg_15164

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:53:48

>
Same\. I could just sit and watch you do ai talks… lol


---

### 2057. msg_15165

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:54:13

I was like “too bad I can’t start everyday like this”


---

### 2058. msg_15166

**You** - 2025-05-30T20:54:58

:\) yeah or end every day\.\.\. or sometimes after lunch\.\. ☺️


---

### 2059. msg_15167

**You** - 2025-05-30T20:55:21

>
what\.\. no


---

### 2060. msg_15168

**You** - 2025-05-30T20:55:39

that sounds wrong\.\.\. lol\.\. I sucked today\.


---

### 2061. msg_15169

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:57:07

>
What… yeah


---

### 2062. msg_15170

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:57:16

>
No


---

### 2063. msg_15171

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:57:28

I FaceTimed Mac to see if she was passed out


---

### 2064. msg_15172

**You** - 2025-05-30T20:57:29

there is nothing hot about me presenting about AI\.


---

### 2065. msg_15173

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:57:56

I’m like “why aren’t you in the kitchen?”
She goes “they are shit faces and we are painting shot glasses”


---

### 2066. msg_15174

**You** - 2025-05-30T20:57:59

hehe


---

### 2067. msg_15175

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:58:05


*1 attachment(s)*


---

### 2068. msg_15176

**You** - 2025-05-30T20:58:06

well done


---

### 2069. msg_15177

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:58:23

>
well…\.


---

### 2070. msg_15178

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:58:38

I was glad she wasn’t passed out


---

### 2071. msg_15179

**You** - 2025-05-30T20:58:32

I especially like the pic of you in the bottom right


---

### 2072. msg_15180

**You** - 2025-05-30T20:58:52

I like when you look genuinely happy\.


---

### 2073. msg_15181

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:59:35

They are good girls\. But call each other bitch and slut too much lol


---

### 2074. msg_15182

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T20:59:54

>
I think it depends on the audience


---

### 2075. msg_15183

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:00:09

Literally the only reason I logged on


---

### 2076. msg_15184

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:00:11

lol


---

### 2077. msg_15185

**You** - 2025-05-30T21:00:57

>
Next time I will give you a private AI presentation\.\. just talk about random AI nonsense\.\. lol see what happens ROFL\.


---

### 2078. msg_15186

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:04:35

Promise?


---

### 2079. msg_15187

**You** - 2025-05-30T21:04:35

I will need wine


---

### 2080. msg_15188

**You** - 2025-05-30T21:04:40

and a cowboy hat\.


---

### 2081. msg_15189

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:04:49

Deal


---

### 2082. msg_15190

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:04:51

Deal


---

### 2083. msg_15191

**You** - 2025-05-30T21:04:47

LOL


---

### 2084. msg_15192

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:04:59

I can do both of those easily


---

### 2085. msg_15193

**You** - 2025-05-30T21:05:05

hmm\.\. I will have to think of something else then


---

### 2086. msg_15194

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:06:17

Wdym


---

### 2087. msg_15195

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:06:19

Why


---

### 2088. msg_15196

**You** - 2025-05-30T21:07:23

to make it more nonsensical\.\. Hmm\.\. I will ask you did you know Ai questions mid makeout while wearing a cowboy hat and no shirt\.


---

### 2089. msg_15197

**You** - 2025-05-30T21:07:36

Also had an idea\.


---

### 2090. msg_15198

**You** - 2025-05-30T21:07:38

fyi


---

### 2091. msg_15199

**You** - 2025-05-30T21:07:47

Reaction: ❓ from Meredith Lamb
you know those plans I said I wouldn't make


---

### 2092. msg_15200

**You** - 2025-05-30T21:07:53

cannot help it\.


---

### 2093. msg_15201

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:08:28

>
I don’t want it to be nonsensical\!


---

### 2094. msg_15202

**You** - 2025-05-30T21:08:30

well it will be real\.\.


---

### 2095. msg_15203

**You** - 2025-05-30T21:08:54

you might not get it though\.\. unless you understand python, and claude, and gemini and some of the new things they can do\.


---

### 2096. msg_15204

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:09:28

Unlikely… I think I need a session


---

### 2097. msg_15205

**You** - 2025-05-30T21:09:21

when is the school year over?


---

### 2098. msg_15206

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:09:45

Usually June 28ish


---

### 2099. msg_15207

**You** - 2025-05-30T21:09:55

kk\.\. well I had an idea we can do a few different ways\.\. which I think you would be into\.


---

### 2100. msg_15208

**You** - 2025-05-30T21:09:59

well maybe\.


---

### 2101. msg_15209

**You** - 2025-05-30T21:10:35

We could do something with Jim\.\. and family\.\.


---

### 2102. msg_15210

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:10:43

>
Probably


---

### 2103. msg_15211

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:10:57

Family?


---

### 2104. msg_15212

**You** - 2025-05-30T21:10:54

well friends


---

### 2105. msg_15213

**You** - 2025-05-30T21:10:55

I guess


---

### 2106. msg_15214

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:11:09

Not computing\. Elaborate


---

### 2107. msg_15215

**You** - 2025-05-30T21:11:28

ok\.\. i can sell going to Jims, drinking and staying the night there and most of the next day easily\.


---

### 2108. msg_15216

**You** - 2025-05-30T21:11:33

so I will start with that\.


---

### 2109. msg_15217

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:11:41

I feel like if I gave you a good cowboy hat you would have nowhere to keep it\. Birthday\.


---

### 2110. msg_15218

**You** - 2025-05-30T21:11:52

I cannot keep anything atm


---

### 2111. msg_15219

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:12:05

I know


---

### 2112. msg_15220

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:12:18

There is a really great place for country stuff in London


---

### 2113. msg_15221

**You** - 2025-05-30T21:12:14

except for the rock because I can hide it at work


---

### 2114. msg_15222

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:12:41

>
Yes I could do this too bc it is near my parents


---

### 2115. msg_15223

**You** - 2025-05-30T21:12:35

btw I don't tink you are ever reconnecting\.\. going to turn the game off\.\. the music is driving me\.


---

### 2116. msg_15224

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:12:44

Kind of


---

### 2117. msg_15225

**You** - 2025-05-30T21:12:44

well that was the next phase


---

### 2118. msg_15226

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:13:02

>
Oh I wasn’t even trying sorry


---

### 2119. msg_15227

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:13:04

lol


---

### 2120. msg_15228

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:13:07

\!\!\!


---

### 2121. msg_15229

**You** - 2025-05-30T21:13:01

after we are done there\.\. we could hotel, bnb, or basement?? lol


---

### 2122. msg_15230

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:13:14

Listening to girls in my kitchen


---

### 2123. msg_15231

**You** - 2025-05-30T21:13:13

>
lol


---

### 2124. msg_15232

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:13:41

>
If I intro you to my parents we could likely stay there in a less awkward way


---

### 2125. msg_15233

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:13:55

>
Fine with any


---

### 2126. msg_15234

**You** - 2025-05-30T21:13:57

Could do that before going to Jims? or whatever\.


---

### 2127. msg_15235

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:14:08

Kristine liked my bra pong


---

### 2128. msg_15236

**You** - 2025-05-30T21:14:04

just need to do a weekend when Jaimie is home\.


---

### 2129. msg_15237

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:14:24

Kristine said I’m a “cool mom”


---

### 2130. msg_15238

**You** - 2025-05-30T21:14:27

because like as she is away next weekend\.\. if I went out for the night she would lose her goddamn mind\.


---

### 2131. msg_15239

**You** - 2025-05-30T21:14:31

>
you are


---

### 2132. msg_15240

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:14:52

Yeah we wouldn’t when she is away


---

### 2133. msg_15241

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:14:55

Of course


---

### 2134. msg_15242

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:15:34

Jim started texting me more\. I think he REALLY was flattered


---

### 2135. msg_15243

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:15:42

Like “wow they consider me a friend”


---

### 2136. msg_15244

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:15:44

Haha


---

### 2137. msg_15245

**You** - 2025-05-30T21:15:39

he won't text me at all\.\. so sad\.


---

### 2138. msg_15246

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:15:54

Seriously?


---

### 2139. msg_15247

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:15:57

lol


---

### 2140. msg_15248

**You** - 2025-05-30T21:15:58

yeah I invited him to signal and everything\.\.


---

### 2141. msg_15249

**You** - 2025-05-30T21:16:15

he did say he was too busy to connect this aft with everything going on with residential\.\. I completely understood


---

### 2142. msg_15250

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:16:35

lol well he probably doesn’t like new apps\. He isn’t good with tech


---

### 2143. msg_15251

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:16:49

Apparently their rec is 0\.4


---

### 2144. msg_15252

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:16:54

\*trc


---

### 2145. msg_15253

**You** - 2025-05-30T21:16:53

good stuff


---

### 2146. msg_15254

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:20:42

Does Gracie post on social media?


---

### 2147. msg_15255

**You** - 2025-05-30T21:20:44

Sometimes not much though why


---

### 2148. msg_15256

**You** - 2025-05-30T21:20:55

actually almost never


---

### 2149. msg_15257

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:21:10

Just some drunk girls asking


---

### 2150. msg_15258

**You** - 2025-05-30T21:21:04

she is too paranoid


---

### 2151. msg_15259

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:21:11

lol


---

### 2152. msg_15260

**You** - 2025-05-30T21:21:14

why they want to see her?


---

### 2153. msg_15261

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:21:28

Yeah


---

### 2154. msg_15262

**You** - 2025-05-30T21:21:21

like a pic or something?


---

### 2155. msg_15263

**You** - 2025-05-30T21:21:24

sec


---

### 2156. msg_15264

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:21:32

Yeah


---

### 2157. msg_15265

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:21:41

I’m drinking in kitchen with them now


---

### 2158. msg_15266

**You** - 2025-05-30T21:21:49

don't show them any pics of me\.\. only the young one\.


---

### 2159. msg_15267

**You** - 2025-05-30T21:21:51

:P


---

### 2160. msg_15268

**You** - 2025-05-30T21:21:55

with hair lol


---

### 2161. msg_15269

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:22:22

Haha


---

### 2162. msg_15270

**You** - 2025-05-30T21:22:18

and none of those other ones from gym either\.\. behave\.


---

### 2163. msg_15271

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:22:55

lol


---

### 2164. msg_15272

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:26:24

So I just learned that Johnnie’s gummies are indigenous


---

### 2165. msg_15273

**You** - 2025-05-30T21:26:36

Jim literally told you that


---

### 2166. msg_15274

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:26:41

Apparently there is an indigenous place at Yonge and Eglinton


---

### 2167. msg_15275

**You** - 2025-05-30T21:26:41

in the breakout room


---

### 2168. msg_15276

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:26:43

lol


---

### 2169. msg_15277

**You** - 2025-05-30T21:26:46

when we talked to him


---

### 2170. msg_15278

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:30:39

I knooow I didn’t believe it


---

### 2171. msg_15279

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:30:54

So the girls are on board to disable the ring if required


---

### 2172. msg_15280

**You** - 2025-05-30T21:30:58

ok I am still looking for images\.\.


---

### 2173. msg_15281

**You** - 2025-05-30T21:31:15

I don't think it will happen Mer\.\. honestly\.\. I cannot find a reason\.\. j would kick my fucking ass\.


---

### 2174. msg_15282

**You** - 2025-05-30T21:31:27

we would have to get in a massive fight\.\. and I would rather not


---

### 2175. msg_15283

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:31:40

I honestly was kidding


---

### 2176. msg_15284

**You** - 2025-05-30T21:31:37

would love to see you don't get me wrong


---

### 2177. msg_15285

**You** - 2025-05-30T21:31:40

kk


---

### 2178. msg_15286

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:31:54

I probably couldn’t handle you coming\. Stay up too late etc


---

### 2179. msg_15287

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:32:08

I have a lot to take care of after these girls


---

### 2180. msg_15288

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:32:16

And Andrew has to come back Sunday


---

### 2181. msg_15289

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:34:02

>
Can you stop\. They don’t even care who you are\. They are happy for Meredith\.


---

### 2182. msg_15290

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:34:04

lol


---

### 2183. msg_15291

**You** - 2025-05-30T21:34:05


*1 attachment(s)*


---

### 2184. msg_15292

**You** - 2025-05-30T21:34:18

>
I am good with that


---

### 2185. msg_15293

**You** - 2025-05-30T21:34:32

Gracie is in Green


---

### 2186. msg_15294

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:34:46

And who is in black


---

### 2187. msg_15295

**You** - 2025-05-30T21:34:47

Demon Woman


---

### 2188. msg_15296

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:35:01

Hannah


---

### 2189. msg_15297

**You** - 2025-05-30T21:34:56

Hanah\.\.


---

### 2190. msg_15298

**You** - 2025-05-30T21:34:58

yeah


---

### 2191. msg_15299

**You** - 2025-05-30T21:36:57

maddie is a little more shy

*1 attachment(s)*


---

### 2192. msg_15300

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:42:00

Like my daughter Maelle


---

### 2193. msg_15301

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:42:01

:\)


---

### 2194. msg_15302

**You** - 2025-05-30T21:42:16

lol


---

### 2195. msg_15303

**You** - 2025-05-30T21:42:28

I thought there were more pics but cannot find\.


---

### 2196. msg_15304

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:49:19

Sorry took a gummy but it is a tame one\. Not one of johnnys


---

### 2197. msg_15305

**You** - 2025-05-30T21:49:40


*1 attachment(s)*


---

### 2198. msg_15306

**You** - 2025-05-30T21:49:43

ROFL


---

### 2199. msg_15307

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:49:49


*1 attachment(s)*


---

### 2200. msg_15308

**You** - 2025-05-30T21:49:47

I am right about everything


---

### 2201. msg_15309

**You** - 2025-05-30T21:49:48

forever


---

### 2202. msg_15310

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:50:13

Johnny had promised tonight\. He wanted Mac and I to come over


---

### 2203. msg_15311

**You** - 2025-05-30T21:50:15

I do worry about you\.\. though\.


---

### 2204. msg_15312

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:50:22

This is him with his parents\. Aw


---

### 2205. msg_15313

**You** - 2025-05-30T21:50:36

he's a good looking kid\.\. they look proud\.


---

### 2206. msg_15314

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:51:03

>
The his is why I like you 🤮


---

### 2207. msg_15315

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:51:31

>
Did I mention he’s 6’7” lol


---

### 2208. msg_15316

**You** - 2025-05-30T21:52:17

>
You did mer\.\. you said you like them big remember\.\. or maybe you don't  heheh


---

### 2209. msg_15317

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:52:54

I didn’t necessarily mean tall


---

### 2210. msg_15318

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:53:00

But tall is good yes


---

### 2211. msg_15319

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:53:13

But I consider 6’ tall


---

### 2212. msg_15320

**You** - 2025-05-30T21:53:07

>
you should probably leave this one alone\.


---

### 2213. msg_15321

**You** - 2025-05-30T21:53:14

lol


---

### 2214. msg_15322

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:53:42

Oh stop


---

### 2215. msg_15323

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:53:47

You are tall


---

### 2216. msg_15324

**You** - 2025-05-30T21:54:01

maddie dressed\.\. well more like Mac and her friends LOL\.

*1 attachment(s)*


---

### 2217. msg_15325

**You** - 2025-05-30T21:54:09

She was Grade 10 there\.


---

### 2218. msg_15326

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:54:45

They are gr 10 now :\)


---

### 2219. msg_15327

**You** - 2025-05-30T21:54:40

>
I think this kind of sailed past you\.


---

### 2220. msg_15328

**You** - 2025-05-30T21:54:46

sok though


---

### 2221. msg_15329

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:55:12

>
Leave what alone?


---

### 2222. msg_15330

**You** - 2025-05-30T21:55:20

Nothing\.\. nm\.\. oh look it is almost bed time\.


---

### 2223. msg_15331

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:55:43

No you can’t do that


---

### 2224. msg_15332

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:56:15

Come on


---

### 2225. msg_15333

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:56:29

No oh look squirrel


---

### 2226. msg_15334

**You** - 2025-05-30T21:56:28

Naw\.\. it is too awkward\.\. and you are likely now drunk with a bunch of teens around\.


---

### 2227. msg_15335

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:56:52

I’m actually in my room alone


---

### 2228. msg_15336

**You** - 2025-05-30T21:56:45

plus we did this once before\.\.


---

### 2229. msg_15337

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:56:57

They are in other cottage


---

### 2230. msg_15338

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:05

>
Huh?


---

### 2231. msg_15339

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:10

I’m so confused


---

### 2232. msg_15340

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:13

Come on


---

### 2233. msg_15341

**You** - 2025-05-30T21:57:08

I know hon its ok\.


---

### 2234. msg_15342

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:19

Put me out of my misery


---

### 2235. msg_15343

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:22

Clarify


---

### 2236. msg_15344

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:30

I am not too drunk


---

### 2237. msg_15345

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:57:35

Bottle is not gone


---

### 2238. msg_15346

**You** - 2025-05-30T21:58:01

You said you like them big\.\. lol\.\. has so many meanings\.\. and you were drunk last time\.\. and you just kept going on\.\. lol I tried to drop the line on you again to see if you would react but I guess you forgot\.


---

### 2239. msg_15347

**You** - 2025-05-30T21:58:06

brb


---

### 2240. msg_15348

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:58:41

Oh I didn’t mean like appendage big\. I meant like I don’t like skinny guys


---

### 2241. msg_15349

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T21:58:43

God


---

### 2242. msg_15350

**You** - 2025-05-30T21:58:36

bio will just be a min\.\. and I am turning game off lol bedtime shortly\.


---

### 2243. msg_15351

**You** - 2025-05-30T22:05:02

>
mmmmmm hmmmmmm\.\.\. I can be a little skeptical on that right\.\. and please no further explanation necessary LOL\.


---

### 2244. msg_15352

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:05:28

I’m being serious


---

### 2245. msg_15353

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:05:46

Like 150%


---

### 2246. msg_15354

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:05:56

Ask anyone who knows me


---

### 2247. msg_15355

**You** - 2025-05-30T22:06:04

You want me to ask people that know you about appendages?


---

### 2248. msg_15356

**You** - 2025-05-30T22:06:10

lol


---

### 2249. msg_15357

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:06:29

I’ve always dated like bigger guys\. Not skinny guys


---

### 2250. msg_15358

**You** - 2025-05-30T22:06:24

I mean\.\. hey I'm Scott


---

### 2251. msg_15359

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:06:40

Has nothing to do with anything else


---

### 2252. msg_15360

**You** - 2025-05-30T22:06:33

and I would like to ask you a question about appendages


---

### 2253. msg_15361

**You** - 2025-05-30T22:06:39

heheh


---

### 2254. msg_15362

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:06:57

When I say that it doesn’t have to do with that


---

### 2255. msg_15363

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:07:04

Seriously


---

### 2256. msg_15364

**You** - 2025-05-30T22:07:25

now did you actually like chubby me better\.\. ??


---

### 2257. msg_15365

**You** - 2025-05-30T22:07:56

I am a bit confused if big is dad bod or big is just\.\.\. hmm


---

### 2258. msg_15366

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:08:26

I mean it is flexible, I like you as long as you don’t go anorexic


---

### 2259. msg_15367

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:09:06

I guess it is contextual


---

### 2260. msg_15368

**You** - 2025-05-30T22:09:09

again\.\. shooting for this still my goal :\)

*1 attachment(s)*


---

### 2261. msg_15369

**You** - 2025-05-30T22:09:12

:P


---

### 2262. msg_15370

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:09:32

I mean that is “big”


---

### 2263. msg_15371

**You** - 2025-05-30T22:09:36

believe it or not he isn't even 200 lbs there


---

### 2264. msg_15372

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:09:52

It’s definitely not skinny


---

### 2265. msg_15373

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:10:37

I think I’m attracted to so much more than just physical but don’t like skinny people generally lol


---

### 2266. msg_15374

**You** - 2025-05-30T22:10:34

actually nm he fluctuates from 200\-220 and he is 6'1


---

### 2267. msg_15375

**You** - 2025-05-30T22:10:40

I can definitely pull this off\.


---

### 2268. msg_15376

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:10:53

lol


---

### 2269. msg_15377

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:11:17

We talk a lot about things I like … hmmh


---

### 2270. msg_15378

**You** - 2025-05-30T22:11:58

what are you curious about?


---

### 2271. msg_15379

**You** - 2025-05-30T22:12:27

We talk about it because I am focused on it\.\. like to a fault\.


---

### 2272. msg_15380

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:12:57

Why


---

### 2273. msg_15381

**You** - 2025-05-30T22:13:08

That pic there\.\. I wanted to look like that pic since I saw the movie\.


---

### 2274. msg_15382

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:13:53

I’m curious how you have just completely disregarded your needs and desires for like 20 years? How that happens?


---

### 2275. msg_15383

**You** - 2025-05-30T22:13:53

what needs


---

### 2276. msg_15384

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:14:20

I dunno, whatever they are


---

### 2277. msg_15385

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:14:30

They obviously are not being met


---

### 2278. msg_15386

**You** - 2025-05-30T22:14:55

I didn't disregard them\.\. the whole needs thing turning off happened when I met you\.  Like I explained\.\. i took care of myself\.\. when I met you\.\. that just kind of turned off\.\. completely\.\. it was like nope\.\. that isn't good enough\.\. just you\.\. that is what I need\.


---

### 2279. msg_15387

**You** - 2025-05-30T22:15:10

but before that yeah I obviously had to deal with what I was going through\.


---

### 2280. msg_15388

**You** - 2025-05-30T22:15:20

and no cheating or anything else\.\. so it is what it is\.


---

### 2281. msg_15389

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:15:48

🤔


---

### 2282. msg_15390

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:15:56

That’s weird response


---

### 2283. msg_15391

**You** - 2025-05-30T22:16:07

how so?


---

### 2284. msg_15392

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:16:24

Because you were in a marriage


---

### 2285. msg_15393

**You** - 2025-05-30T22:16:19

what do you think single people do?


---

### 2286. msg_15394

**You** - 2025-05-30T22:16:21

lol


---

### 2287. msg_15395

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:16:39

You were in a marriage though


---

### 2288. msg_15396

**You** - 2025-05-30T22:16:37

just pretend I was single 95% of my marriage


---

### 2289. msg_15397

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:16:53

Huh no


---

### 2290. msg_15398

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:17:06

That is not normal


---

### 2291. msg_15399

**You** - 2025-05-30T22:17:00

I know it is hard for you to understand\.\. your situation was 180 degrees the other direciton\.


---

### 2292. msg_15400

**You** - 2025-05-30T22:17:08

just our situations were different


---

### 2293. msg_15401

**You** - 2025-05-30T22:17:30

after a while the needs kind of go away\.


---

### 2294. msg_15402

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:17:43

Your situation is really confusing


---

### 2295. msg_15403

**You** - 2025-05-30T22:17:53

yeah\.\. well\.\. I didn't envy you yours either\.


---

### 2296. msg_15404

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:18:09

Me neither


---

### 2297. msg_15405

**You** - 2025-05-30T22:18:15

I think you are wondering how am I like this now maybe?


---

### 2298. msg_15406

**You** - 2025-05-30T22:18:22

because so am I


---

### 2299. msg_15407

**You** - 2025-05-30T22:18:30

I think it is you


---

### 2300. msg_15408

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:18:38

I’m just wondering how you and j lasted so long?


---

### 2301. msg_15409

**You** - 2025-05-30T22:18:33

that is about it


---

### 2302. msg_15410

**You** - 2025-05-30T22:18:44

because I felt obligated towards her\.


---

### 2303. msg_15411

**You** - 2025-05-30T22:18:49

I brought her here\.


---

### 2304. msg_15412

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:18:58

https://open\.spotify\.com/track/2QQ0lfEAu3ncUHM3C6Rkg3?si=5\-COHErFQK65ZYLI2B8VYg


---

### 2305. msg_15413

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:19:12

I’m doing an OLP night tonight


---

### 2306. msg_15414

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:19:27

>
But like she was ok with it?


---

### 2307. msg_15415

**You** - 2025-05-30T22:19:24

I meant to pla foo fighters the other night\.


---

### 2308. msg_15416

**You** - 2025-05-30T22:19:33

>
well we didn't have a lot of options\.


---

### 2309. msg_15417

**You** - 2025-05-30T22:19:39

but she always wanted to move home


---

### 2310. msg_15418

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:20:46

Ok well I look forward to the day where we we can tell our respective families the truth\. I know it is a ways out


---

### 2311. msg_15419

**You** - 2025-05-30T22:21:31

>
again\.\. sex isn't the only thing in a relationship\.\. I think it is important\.\. but I don't think it is like Glue\.\.  in fact I think it can be toxic and shitty in many cases\.


---

### 2312. msg_15420

**You** - 2025-05-30T22:21:53

>
I mean\.\. J will find out eventually\.\.\. likely before christmas


---

### 2313. msg_15421

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:23:47

>
Andrew thinks it is \#1 so to each their own I guess


---

### 2314. msg_15422

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:24:17

>
This still bothers you


---

### 2315. msg_15423

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:24:50


*1 attachment(s)*


---

### 2316. msg_15424

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:25:01

I heard them playing a game so ran down


---

### 2317. msg_15425

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:25:12

They are playing “the vape game”


---

### 2318. msg_15426

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:25:19

The bag is full of vapes


---

### 2319. msg_15427

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:25:20

LOL


---

### 2320. msg_15428

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:25:28

I got them to give me a real one


---

### 2321. msg_15429

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:25:37

Reaction: ❤️ from Scott Hicks
I’m such a pathetic mom lol


---

### 2322. msg_15430

**You** - 2025-05-30T22:27:56

Reaction: 😂 from Meredith Lamb
>
Def not number one\.  But like I said\.\. it has been so long since any sense of normalcy and beyond that since I was happy about it\.\. I mean\.\. I probably don't have a lot of perspective on this\.  And again\.\. you don't even register for me like I don't even know how to explain it\.\. but it is unique in an extremely good, happy, comforting, safe way\.\. all of those things\.\. and more\.  I don't see these feelings changing\.\. but I would never oblige you to do anything\.\. like there aren't quota's or required things you must do to or for me lol\.\. that is fucking nonsense\.  There are things I would happily do to or for you though\.\. just so you know\.\. I am kind of more built that way\.


---

### 2323. msg_15431

**You** - 2025-05-30T22:28:09

sounds like best game ever


---

### 2324. msg_15432

**You** - 2025-05-30T22:28:16

>
it doesn


---

### 2325. msg_15433

**You** - 2025-05-30T22:28:21

no


---

### 2326. msg_15434

**You** - 2025-05-30T22:28:24

it doesn't


---

### 2327. msg_15435

**You** - 2025-05-30T22:28:39

i just would prefer it to be when she is back in Moncton\.\. and slightly established


---

### 2328. msg_15436

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:29:02

>
I think it does


---

### 2329. msg_15437

**You** - 2025-05-30T22:28:58

>
it's true\.\.\. :P


---

### 2330. msg_15438

**You** - 2025-05-30T22:29:33

>
No\.\. I am not afraid of her finding out we are together\.\. but I cannot tell her how I feel about you\.\.


---

### 2331. msg_15439

**You** - 2025-05-30T22:29:35

not the extent


---

### 2332. msg_15440

**You** - 2025-05-30T22:29:42

I don't want to break her\.


---

### 2333. msg_15441

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:29:56

>
It’s okay\. I know you care\. She is the mom to your kids etc etc etc etc\. been there for you through a lot etc


---

### 2334. msg_15442

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:30:00

All valid


---

### 2335. msg_15443

**You** - 2025-05-30T22:30:28

>
I think we are talking about different things\.\. let's set this aside and you can go back and think about the things I want to do to you instead\.\. happier thoughts before bed


---

### 2336. msg_15444

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:31:06

I think we are talking the same things but okay lol


---

### 2337. msg_15445

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:31:28

You can go to bed Yunno


---

### 2338. msg_15446

**You** - 2025-05-30T22:31:53

>
Can you explain what your concern / focus is on tis particular thing\.\. like are you going to tell Andrew\.\. I am dating Scott\.\. and I love him more than I ever loved you\.


---

### 2339. msg_15447

**You** - 2025-05-30T22:32:02

like no\.\.


---

### 2340. msg_15448

**You** - 2025-05-30T22:32:04

you aren't


---

### 2341. msg_15449

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:32:28

I probably will actually


---

### 2342. msg_15450

**You** - 2025-05-30T22:32:28

Jaimie will know we are dating\.\. and that is the extent to which we would need to discuss it\.


---

### 2343. msg_15451

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:32:40

But I’m different than you


---

### 2344. msg_15452

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:32:43

It’s ok


---

### 2345. msg_15453

**You** - 2025-05-30T22:32:36

she would want to know if and when you met Maddie\.


---

### 2346. msg_15454

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:33:14

I don’t tend to lie to Andrew


---

### 2347. msg_15455

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:33:22

I omit sometimes


---

### 2348. msg_15456

**You** - 2025-05-30T22:33:23

But she wouldn't want to hear how so soon after I basically divorced her, I actually met my soulmate\.  and completely fell for her so hard that I don't even know how to deal with it most of the time\.


---

### 2349. msg_15457

**You** - 2025-05-30T22:33:31

Like that kind of truth


---

### 2350. msg_15458

**You** - 2025-05-30T22:33:37

would crush her\.


---

### 2351. msg_15459

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:33:59

I dont think it needs to be articulated that way


---

### 2352. msg_15460

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:34:05

I won’t articulate it that way


---

### 2353. msg_15461

**You** - 2025-05-30T22:34:12

I will let her know it is serious\.


---

### 2354. msg_15462

**You** - 2025-05-30T22:34:22

I think beyond that she doesn't need any details\.


---

### 2355. msg_15463

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:34:40

Agree


---

### 2356. msg_15464

**You** - 2025-05-30T22:34:40

I mean she has Guessed half the shit already


---

### 2357. msg_15465

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:34:54

But it is more than discussions and we hardly talk anymore


---

### 2358. msg_15466

**You** - 2025-05-30T22:35:22

she said something sarcastically the other night\.\. fishing I think more than anything else\.\. but saying something about how I would never even touch her let alone have sex with her\.\. and she said I bet you don't have any problems having sex with Meredith\.


---

### 2359. msg_15467

**You** - 2025-05-30T22:35:34

I obviously didn't respond\.\. but she was right\.\. :/


---

### 2360. msg_15468

**You** - 2025-05-30T22:35:54

There is a connection and a psychological component to it\.


---

### 2361. msg_15469

**You** - 2025-05-30T22:36:03

and an emotional one for me


---

### 2362. msg_15470

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:36:19

Of course\. Exact same for me


---

### 2363. msg_15471

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:37:16

Jim asked my relationship history bc he was like “Scott had never experienced this before”


---

### 2364. msg_15472

**You** - 2025-05-30T22:37:25

the feelings\.\.


---

### 2365. msg_15473

**You** - 2025-05-30T22:37:29

yeah he is right


---

### 2366. msg_15474

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:38:38

I told him basically I’ve had 3 prior longer term relationships but only one where maybe some emotional component was involved but honestly it became unstable and always felt a little shifty and what I have with you feels unbreakable


---

### 2367. msg_15475

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:39:12

But basically it was because too many drugs were involved \(in retrospect\)


---

### 2368. msg_15476

**You** - 2025-05-30T22:40:56

Yeah that is unfortunate\.\. like I want to be honest\.\. it isn't that I haven't had long term relationships where there weren't emotions\.\. I had very emotional relationships\. with a couple of people\.\. again\.\. nothing like this\.\. nothing even close\.\. but I would say much stronger than what i had with Jaimie nonetheless\.\.


---

### 2369. msg_15477

**You** - 2025-05-30T22:41:20

So I haven't fallen in love this hard\.\. ever\.\. and am a little afraid\.\. but I am not completely inexperienced at protecting myself\.


---

### 2370. msg_15478

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:41:52

I do feel kind of bad for Jaimie


---

### 2371. msg_15479

**You** - 2025-05-30T22:41:57

I know you do\.


---

### 2372. msg_15480

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:42:07

But I feel bad for me too so


---

### 2373. msg_15481

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:42:10

lol\!


---

### 2374. msg_15482

**You** - 2025-05-30T22:42:09

yes there is that\.


---

### 2375. msg_15483

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:42:37

We all have our stories


---

### 2376. msg_15484

**You** - 2025-05-30T22:42:31

it comes back to do we deserve to be happy


---

### 2377. msg_15485

**You** - 2025-05-30T22:42:46

I feel like yes\.\.


---

### 2378. msg_15486

**You** - 2025-05-30T22:43:12

I have gone through 25 years\.\.  and I have been a good boy\.\. even though it wasn't what I really wanted or hoped for\.


---

### 2379. msg_15487

**You** - 2025-05-30T22:43:18

So yeah\.\. I want some happiness


---

### 2380. msg_15488

**You** - 2025-05-30T22:43:37

and before you say some nonsense\.


---

### 2381. msg_15489

**You** - 2025-05-30T22:43:42

You will always make me happy


---

### 2382. msg_15490

**You** - 2025-05-30T22:43:49

I will always want to come home to you\.


---

### 2383. msg_15491

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:44:05

>
I want you to have some too


---

### 2384. msg_15492

**You** - 2025-05-30T22:44:25

well I have some\.\. so we are already there\.\. :\)


---

### 2385. msg_15493

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:45:16

https://open\.spotify\.com/track/2gz6rDUWhKn1XWi7iapbpm?si=OzVnyG29RSu50mVzGOZJdw
One of my favourite songs just came on


---

### 2386. msg_15494

**You** - 2025-05-30T22:45:33

>
>
I wore that cd down to nothing I played it so much


---

### 2387. msg_15495

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:46:39

>
Me…\. Nonsense?


---

### 2388. msg_15496

**You** - 2025-05-30T22:46:52

you always worry


---

### 2389. msg_15497

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:47:01

>
Good boy? 🫤


---

### 2390. msg_15498

**You** - 2025-05-30T22:46:59

about some nonsense shit


---

### 2391. msg_15499

**You** - 2025-05-30T22:47:08

and I wish you could get in my head


---

### 2392. msg_15500

**You** - 2025-05-30T22:47:17

because you would see how silly it is


---

### 2393. msg_15501

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:48:02

So can I confess something bc I’m almost a bottle in?


---

### 2394. msg_15502

**You** - 2025-05-30T22:47:57

Reaction: 🙄 from Meredith Lamb
>
i\.e\. true to J\.


---

### 2395. msg_15503

**You** - 2025-05-30T22:48:02

>
sure


---

### 2396. msg_15504

**You** - 2025-05-30T22:48:16

like a bad confession or a good confession or a neutral


---

### 2397. msg_15505

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:48:40

>
No idea what you would think


---

### 2398. msg_15506

**You** - 2025-05-30T22:48:45

>
you think I broke that with you?


---

### 2399. msg_15507

**You** - 2025-05-30T22:49:05

>
sure fire away


---

### 2400. msg_15508

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:49:18

https://open\.spotify\.com/track/06O0ARnlFjcI6U2uIe6rMU?si=NHqcslAnQOSEwRRMd\_q6MQ


---

### 2401. msg_15509

**You** - 2025-05-30T22:50:46

deleted?


---

### 2402. msg_15510

**You** - 2025-05-30T22:50:56

if deleted


---

### 2403. msg_15511

**You** - 2025-05-30T22:51:01

you must share the original copy


---

### 2404. msg_15512

**You** - 2025-05-30T22:51:10

in addition to the updated


---

### 2405. msg_15513

**You** - 2025-05-30T22:51:14

that is the rule


---

### 2406. msg_15514

**You** - 2025-05-30T22:51:18

you deleted again I bet


---

### 2407. msg_15515

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:51:25

So before AD \(Andrew lol\) I acted a lot differently in relationships and even physically was more into trying different things etc and then with Andrew, nothing ever\. Not sure why\.
But with you I feel safe to be pre\-AD and wonder if you feel similar


---

### 2408. msg_15516

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:51:32

I don’t delete anything


---

### 2409. msg_15517

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:51:42

I’m it as fast as typer as you apparently


---

### 2410. msg_15518

**You** - 2025-05-30T22:51:52

so\.\. hmmm\.\.\.


---

### 2411. msg_15519

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:52:05

Honestly no deleting


---

### 2412. msg_15520

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:52:11

I just don’t type as fast


---

### 2413. msg_15521

**You** - 2025-05-30T22:52:11

well I am on comp


---

### 2414. msg_15522

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:52:21

And I swear to god the girls just broke something in


---

### 2415. msg_15523

**You** - 2025-05-30T22:52:14

so it is easier


---

### 2416. msg_15524

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:52:41

I’m on my phone so yeah slower


---

### 2417. msg_15525

**You** - 2025-05-30T22:52:49

>
please go back to this and comment\.\. I am curious\.\. sounded like you disagreed with the good boy\.\. want to know if that is because of us?


---

### 2418. msg_15526

**You** - 2025-05-30T22:54:05

>
>
>
Like\.\. hmm\.\. so you know I am slightly insecure\.\. in general\.\. I wasn't as much in my 20's and late teens\.\. I had no problems trying different things\.\. but I will be honest\.\. I was usually the one being tossed around lol\.


---

### 2419. msg_15527

**You** - 2025-05-30T22:55:12

>
I mean\.\. lol\.\. I need a fucking drink\.


---

### 2420. msg_15528

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:55:42

>
I don’t think you broke it with me\. I think you broke it LONG before\. You were never all in with her it sounds\. But this is someone on the outside looking in…\. I just mean it doesn’t sound like you let yourself go with her\. You just saved her and took care of her\. Didn’t sound like a mutual thing but maybe it was at times and just isn’t now\.


---

### 2421. msg_15529

**You** - 2025-05-30T22:55:54

yeah that is fair\.


---

### 2422. msg_15530

**You** - 2025-05-30T22:55:57

I can accept that


---

### 2423. msg_15531

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:56:05

At the end of the day, the two of you are the only ones that truly know your relationship


---

### 2424. msg_15532

**You** - 2025-05-30T22:56:18

well it was different for her than me\.


---

### 2425. msg_15533

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:56:45

>
Tossed around? Lol wtf?


---

### 2426. msg_15534

**You** - 2025-05-30T22:56:46

TMI


---

### 2427. msg_15535

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:57:07

No it’s not


---

### 2428. msg_15536

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:57:08

lol


---

### 2429. msg_15537

**You** - 2025-05-30T22:57:42

I feel like it is\.\. like talking about other sexual partners\.\. is awkward talking details\.\. eeesh much more so\.  Let's say I am flexible\.\. and will go with pretty much anything


---

### 2430. msg_15538

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:57:52

Where does your insecurity come from?


---

### 2431. msg_15539

**You** - 2025-05-30T22:58:04

I dunno\.\. just always felt kind of meh


---

### 2432. msg_15540

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:58:15

>
I don’t find it awkward at all


---

### 2433. msg_15541

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:58:28

You have a past


---

### 2434. msg_15542

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:58:34

You are 47


---

### 2435. msg_15543

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:58:39

\(Basically\)


---

### 2436. msg_15544

**You** - 2025-05-30T22:59:12

It is just we might have slightly different comfort levels there\.\. \+ we have established my past is a bit more checkered in that respect from yours\.\. not a proud thing to be sure\.  more of a misguided youth thing\.


---

### 2437. msg_15545

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:59:40

But I have no issues with that


---

### 2438. msg_15546

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T22:59:46

Mine isn’t great either


---

### 2439. msg_15547

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:00:06

I mean, not proud of some scenarios


---

### 2440. msg_15548

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:00:16

But it is done\. Can’t control


---

### 2441. msg_15549

**You** - 2025-05-30T23:00:51

yeah\.\. I think for me it is looking back is like reliving some of it\.\. hmm\.\. let me put it to you another way\.\. this is going to sound really weird ok\.\. so just let me get through it\.


---

### 2442. msg_15550

**You** - 2025-05-30T23:02:52

I always wanted to connect with someone\.\. at some level even if it was \.\.\.\. fleeting\.\. that is a nice way to say it\.\. I never liked feeling like I was "fucking" someone\.\. that really didn't do anything for me except make me feel bad\.  I would go along with whatever a person wanted\.\. because again\.\. if it made them happy I would be all for it\.\. but I never really liked the way it made me feel\.\. now with you\.\. I think that could be different again\.\. more just from how much I do feel\.\. and well how much we have communicated about these kinds of things\.


---

### 2443. msg_15551

**You** - 2025-05-30T23:04:59

And I mean let's be honest\.\. I am 47\.\. I am shocked I can even do what I am doing atm\.\. with all the shit that was wrong with me\.  So just a little cautious\.\. but again with you I would be up for pretty much whatever would make you happy\.


---

### 2444. msg_15552

**You** - 2025-05-30T23:05:49

Plus as I said previously\.\. you are hard to read\.\.\. you internalize everything \- and I mean everything\.\.\.\.\. lol  so it is kind of difficult to know what is going on happy, engaged, not so much\.\. again\.\. kind of challenging\.


---

### 2445. msg_15553

**You** - 2025-05-30T23:06:08

>
I have lot's and lot's of these\.


---

### 2446. msg_15554

**You** - 2025-05-30T23:11:06

Curious to see your response\.\. you vanished\.\. lol


---

### 2447. msg_15555

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:11:43

Just had to clean up a broken glass\. One sec need to read


---

### 2448. msg_15556

**You** - 2025-05-30T23:11:40

also curious what brought the confession on\.\.


---

### 2449. msg_15557

**You** - 2025-05-30T23:11:44

when you get through this


---

### 2450. msg_15558

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:12:33

They were going to watch a horror movie


---

### 2451. msg_15559

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:12:45

I walk by “what are you watching?”


---

### 2452. msg_15560

**You** - 2025-05-30T23:12:44

lol


---

### 2453. msg_15561

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:12:55

Them: Superstore


---

### 2454. msg_15562

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:12:59

😳


---

### 2455. msg_15563

**You** - 2025-05-30T23:12:53

haha


---

### 2456. msg_15564

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:13:06

So weird


---

### 2457. msg_15565

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:14:55

>
Why didn’t Jaimie just tell you to take viagara?


---

### 2458. msg_15566

**You** - 2025-05-30T23:15:04

I basically am on a version of that\.\.


---

### 2459. msg_15567

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:15:11

Would you two still be together had you done that?


---

### 2460. msg_15568

**You** - 2025-05-30T23:15:36

just a low dose every day\.\. I tried Viagara\.\. it was far less effective by far than what I am experiencing with you\.\. on a quarter of the dosage\.


---

### 2461. msg_15569

**You** - 2025-05-30T23:15:44

>
No\.\.\.\. LOL


---

### 2462. msg_15570

**You** - 2025-05-30T23:16:05

I told you sex for me isn't the same as perhaps other people\.


---

### 2463. msg_15571

**You** - 2025-05-30T23:16:16

more sex in an unhappy relationship solves nothing


---

### 2464. msg_15572

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:16:25

I do think there is so much more than “intercourse”


---

### 2465. msg_15573

**You** - 2025-05-30T23:16:21

when the underlying problems/


---

### 2466. msg_15574

**You** - 2025-05-30T23:16:38

>
there probably is\.\. I haven't chatgpt'd that yet


---

### 2467. msg_15575

**You** - 2025-05-30T23:16:40

I will now


---

### 2468. msg_15576

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:17:30

>
I have experienced a relationship of this nature\. I think you think it is all you “performing” …?


---

### 2469. msg_15577

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:17:57

>
Don’t ChatGPT


---

### 2470. msg_15578

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:18:00

lol


---

### 2471. msg_15579

**You** - 2025-05-30T23:18:47

That's a beautiful place to be — when two people feel deeply connected, trust each other, and are open to exploration\. The phrase \*“there is so much more than intercourse”\* speaks to a broader, richer experience of intimacy that goes beyond just penetration\. It sounds like your partner is expressing a desire to deepen your sensual connection and explore the full spectrum of pleasure, which can actually heighten the experience of sex as a whole\.
Here’s how to think about this:
\#\#\# 1\. \*\*Emotional and Erotic Intimacy\*\*
When partners feel safe and deeply connected, the possibilities for exploration multiply\. Intimacy can involve:
\* Prolonged eye contact
\* Emotional vulnerability
\* Non\-verbal communication
\* Playfulness and shared fantasies
This emotional groundwork can make physical intimacy feel more profound and satisfying\.
\#\#\# 2\. \*\*Sensual Touch and Body Worship\*\*
Exploring each other's bodies without a goal of climax or penetration can lead to incredible discoveries\. Try:
\* Sensate foc\.\.\. \[truncated\]


---

### 2472. msg_15580

**You** - 2025-05-30T23:18:49

there you go


---

### 2473. msg_15581

**You** - 2025-05-30T23:18:56

100% I was going to do that


---

### 2474. msg_15582

**You** - 2025-05-30T23:19:00

Reaction: 😂 from Meredith Lamb
you knew it too\.\.\. lol


---

### 2475. msg_15583

**You** - 2025-05-30T23:19:28

>
I don't understand this statement\.\. sorry\.\.


---

### 2476. msg_15584

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:21:17

I think \(and may be wrong\) that you used to worry about performing during sex\.


---

### 2477. msg_15585

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:21:29

Rather than actually connecting


---

### 2478. msg_15586

**You** - 2025-05-30T23:21:36

>
if by used to you mean currently and forever more then yes\.\. nailed it\.


---

### 2479. msg_15587

**You** - 2025-05-30T23:21:40

lol


---

### 2480. msg_15588

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:22:14

You don’t worry about performing for me tho?


---

### 2481. msg_15589

**You** - 2025-05-30T23:22:10

but you read the other stuff right\.\.


---

### 2482. msg_15590

**You** - 2025-05-30T23:22:21

the earlier stuff\.\. because that is relevant too\.


---

### 2483. msg_15591

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:22:52

>
What earlier stuff exactly lol


---

### 2484. msg_15592

**You** - 2025-05-30T23:23:07

>
this and


---

### 2485. msg_15593

**You** - 2025-05-30T23:23:15

>
this


---

### 2486. msg_15594

**You** - 2025-05-30T23:23:28

>
and that second one should answer this\.


---

### 2487. msg_15595

**You** - 2025-05-30T23:23:29

lol


---

### 2488. msg_15596

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:24:01

>
Why did you feel bad?


---

### 2489. msg_15597

**You** - 2025-05-30T23:23:56

I told you\.\. I am a pleaser\.\. that is basically who I am\.


---

### 2490. msg_15598

**You** - 2025-05-30T23:24:37

>
because I didn't feel the connection the same way\.\. I mean I enjoyed\.\. it \.\. most of it\.\. some was fucking wierd and some I was like nope nope nope\.\.


---

### 2491. msg_15599

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:24:50

>
Am I still hard to read?


---

### 2492. msg_15600

**You** - 2025-05-30T23:24:46

Reaction: ❓ from Meredith Lamb
yes


---

### 2493. msg_15601

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:25:19

>
I’m sure other ppl couldn’t have formed connections at that point


---

### 2494. msg_15602

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:25:26

Same on both sides


---

### 2495. msg_15603

**You** - 2025-05-30T23:25:34

it's fine\.\. I feel you love me, and i feel you are happy\.\. so I kind of go with that\.\. but I think you understand what I am saying\.\.


---

### 2496. msg_15604

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:25:58

>
I don’t believe this\.


---

### 2497. msg_15605

**You** - 2025-05-30T23:26:00

>
mmm they weren't looking for connections  and yes you are\.


---

### 2498. msg_15606

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:26:32

>
“It’s fine\.\.” LOL is it?


---

### 2499. msg_15607

**You** - 2025-05-30T23:26:41

Reaction: 😂 from Meredith Lamb
I am saying I can read the love and happiness\.\.


---

### 2500. msg_15608

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:26:59

>
Yeah but I had my situations many yrs ago where I was not\.


---

### 2501. msg_15609

**You** - 2025-05-30T23:27:10

>
I mean I don't judge to each their own\.


---

### 2502. msg_15610

**You** - 2025-05-30T23:28:31

Like\.\. I dunno\.\. for me it was all about making the other person happy\.\. I don't know how to explain it\.\. that is just how I work\.\. it didn't matter if it was 1 year or 1 night\.  And I never treated anyone like well\.\. like they didn't matter\.


---

### 2503. msg_15611

**You** - 2025-05-30T23:28:51

I think it surprised a lot of people\.


---

### 2504. msg_15612

**You** - 2025-05-30T23:30:42

I really hope nothing I am saying bothers you\.\.


---

### 2505. msg_15613

**You** - 2025-05-30T23:30:51

this is a pretty honest conversation


---

### 2506. msg_15614

**You** - 2025-05-30T23:30:51

lol


---

### 2507. msg_15615

**You** - 2025-05-30T23:30:57

but when don't we


---

### 2508. msg_15616

**You** - 2025-05-30T23:31:00

hehe


---

### 2509. msg_15617

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:31:23

Not at all\. But I think you can make someone else happy and let them make you happy\.


---

### 2510. msg_15618

**You** - 2025-05-30T23:32:05

>
But I am happy when they are happy\.\. I let you do "stuff" lol and I never let my wife do that in 25 years\.\. so I mean\.\. I am open to it\.\. I cannot help being polite though\.


---

### 2511. msg_15619

**You** - 2025-05-30T23:32:14

the tap on the shoulder etc\.\. LOL


---

### 2512. msg_15620

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:34:38

So you don’t like it? 🤔


---

### 2513. msg_15621

**You** - 2025-05-30T23:34:32

but hey I am interested in whatever you are interested in\.\.  Mer I have done pretty much everything\.\. from whatever they fuck idea someone has\.\. to public, very public, to dangerous\.\. like holy fuck dangerous\.\.  so I am not like an "innocent" I just feel certain ways about certain things\. And honestly the high I get, especially well at the end\.\. being with you loving you this much\.\. jesus better than anything ever\.


---

### 2514. msg_15622

**You** - 2025-05-30T23:35:38

lol no you need to read what I just wrote first\.\. of course I like it\.\. of course I was up for almost anything, any time, dares it didn't matter\.\. but fundamentally my motivation was the same\.


---

### 2515. msg_15623

**You** - 2025-05-30T23:35:52

let's do this\.\.


---

### 2516. msg_15624

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:36:06

You are weird


---

### 2517. msg_15625

**You** - 2025-05-30T23:36:00

tell me what you want to do\.\.


---

### 2518. msg_15626

**You** - 2025-05-30T23:36:04

you want honesty


---

### 2519. msg_15627

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:36:18

So what was your reasoning to Jaimie for being so closed off


---

### 2520. msg_15628

**You** - 2025-05-30T23:36:15

tell me what you would like\.\. and we will make it happen\.


---

### 2521. msg_15629

**You** - 2025-05-30T23:36:28

why i was closed off to her


---

### 2522. msg_15630

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:36:55

Well you said you didn’t let her do things


---

### 2523. msg_15631

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:37:03

I think that is closed off\. Not sure


---

### 2524. msg_15632

**You** - 2025-05-30T23:37:38

well there wasn't a connection for one\.\. I didn't want her to\.\. I am not sure how to explain why\.\. but I didn't, and she didn't have any experience in that respect anyways as I understood it\.


---

### 2525. msg_15633

**You** - 2025-05-30T23:37:51

We never talked about this\.


---

### 2526. msg_15634

**You** - 2025-05-30T23:38:01

I tried a few times early on but she wouldn't


---

### 2527. msg_15635

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:38:35

Ok…\.


---

### 2528. msg_15636

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:39:01

Processing


---

### 2529. msg_15637

**You** - 2025-05-30T23:38:56

>
having a hard time following where you are going\.\. lol you are circling


---

### 2530. msg_15638

**You** - 2025-05-30T23:40:42

Cmon mer\.\. you have dug enough\.\. time for you to circle back \- tell me what brought the question on\.\. or the suggestion or confession I guess you called it\.\.  let's start with that\.


---

### 2531. msg_15639

**You** - 2025-05-30T23:40:52

Reaction: 😂 from Meredith Lamb
then I am going to start asking you the questions\.\. lol


---

### 2532. msg_15640

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:42:07

Sorry girls called


---

### 2533. msg_15641

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:42:12

Back


---

### 2534. msg_15642

**You** - 2025-05-30T23:42:15

ok\.\. read last two from me\.


---

### 2535. msg_15643

**You** - 2025-05-30T23:42:25

then you get to answer some questions


---

### 2536. msg_15644

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:43:13

>
Sure\.


---

### 2537. msg_15645

**You** - 2025-05-30T23:43:14

no\.\.\.\.\.


---

### 2538. msg_15646

**You** - 2025-05-30T23:43:23

>
this one first


---

### 2539. msg_15647

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:43:52

>
I am circling\. You should go to bed for gym


---

### 2540. msg_15648

**You** - 2025-05-30T23:43:50

Reaction: 😂 from Meredith Lamb
HAHAHA


---

### 2541. msg_15649

**You** - 2025-05-30T23:43:58

way past my bedtime


---

### 2542. msg_15650

**You** - 2025-05-30T23:44:05

just pushing gym forward\.


---

### 2543. msg_15651

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:44:13

It totally is


---

### 2544. msg_15652

**You** - 2025-05-30T23:44:12

don't worry about it\.


---

### 2545. msg_15653

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:44:39

\(Not worried\)


---

### 2546. msg_15654

**You** - 2025-05-30T23:45:05

ok\.\. so\.\. to my question above\.\.


---

### 2547. msg_15655

**You** - 2025-05-30T23:45:26

it wasn't just the wine talking :\)  what prompted the question\.


---

### 2548. msg_15656

**You** - 2025-05-30T23:45:36

or confession or whatever


---

### 2549. msg_15657

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:46:14

Am I going to regret this tomorrow


---

### 2550. msg_15658

**You** - 2025-05-30T23:46:16

I doubt it


---

### 2551. msg_15659

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:46:25

😒


---

### 2552. msg_15660

**You** - 2025-05-30T23:46:22

but you started it


---

### 2553. msg_15661

**You** - 2025-05-30T23:46:30

and I was honest\.\.


---

### 2554. msg_15662

**You** - 2025-05-30T23:46:37

and you kept digging\.\. so now it is my turn


---

### 2555. msg_15663

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:46:49

I’ve been honest also


---

### 2556. msg_15664

**You** - 2025-05-30T23:47:02

yeah\.\. but mostly questions\.\. and I haven't probed any of your answers\.


---

### 2557. msg_15665

**You** - 2025-05-30T23:47:10

>
like this one


---

### 2558. msg_15666

**You** - 2025-05-30T23:48:03

>
I kind of felt these were one and the same\.\. but my ultimate goal\.\. let's say one way or the other was for the other person to be "happy"


---

### 2559. msg_15667

**You** - 2025-05-30T23:48:13

ok\.\.


---

### 2560. msg_15668

**You** - 2025-05-30T23:48:30

so no more from me\.\. only answers from you\.\. if you want I can itemize and list the questions again


---

### 2561. msg_15669

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:48:59

>
I mean, your POV


---

### 2562. msg_15670

**You** - 2025-05-30T23:49:02

yep


---

### 2563. msg_15671

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:49:37

>
I mean I’m unlikely to address anything unless directly asked or I feel like it\. Lol


---

### 2564. msg_15672

**You** - 2025-05-30T23:49:50

really\.\. is that how it is\.


---

### 2565. msg_15673

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:50:18

>
You had a one night stand to make the other person happy? 🤔


---

### 2566. msg_15674

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:51:04

>
I’m just saying I go with the flow


---

### 2567. msg_15675

**You** - 2025-05-30T23:51:26

Reaction: 🙂 from Meredith Lamb
>
>
>
ok this was where this started\.\. or we could go back and discuss Big Men again\. :\)


---

### 2568. msg_15676

**You** - 2025-05-30T23:51:42

>
No


---

### 2569. msg_15677

**You** - 2025-05-30T23:52:18

I had a one night stand\.\. and in the process of that\.\. my goal was always to make the other person happy\.\. invariably I was degrees of happy\.\. I guess\.\. the connection wasn't there so it was different\.


---

### 2570. msg_15678

**You** - 2025-05-30T23:52:57

And like I said it was generally unexpected\.


---

### 2571. msg_15679

**You** - 2025-05-30T23:53:27

ok I will not be deterred\!\!\! lol


---

### 2572. msg_15680

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:53:39

lol


---

### 2573. msg_15681

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:53:54

I was just listening…\.


---

### 2574. msg_15682

**You** - 2025-05-30T23:53:51

What brought us down this path Mer\.


---

### 2575. msg_15683

**You** - 2025-05-30T23:54:15

You might be surprised with how I respond if you are at all concerned\.


---

### 2576. msg_15684

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:55:11

>
I think I just like you and was … sigh I dunno


---

### 2577. msg_15685

**Meredith Lamb \(\+14169386001\)** - 2025-05-30T23:55:21

>
Concerned?


---

### 2578. msg_15686

**You** - 2025-05-30T23:56:27

Reaction: ❤️ from Meredith Lamb
>
I thought you might be worried I wouldn't be open to it\.\. so let's clear this up\.\. I am up for anything with you Mer\.\. because it is you\.\. and because I love you that much, and because I am happy to go on any adventure with you\.


---

### 2579. msg_15687

**You** - 2025-05-30T23:56:40

>
so back to this\.\.


---

### 2580. msg_15688

**You** - 2025-05-30T23:56:50

can you expand?


---

### 2581. msg_15689

**You** - 2025-05-30T23:56:51

lol


---

### 2582. msg_15690

**You** - 2025-05-30T23:57:01

Reaction: 🙃 from Meredith Lamb
ask chatgpt maybe on how to be more articulate?


---

### 2583. msg_15691

**You** - 2025-05-31T00:01:51

lol did you run away


---

### 2584. msg_15692

**You** - 2025-05-31T00:05:36

or go to sleep


---

### 2585. msg_15693

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:07:00

Sorry bea in bathroom


---

### 2586. msg_15694

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:07:03

:p


---

### 2587. msg_15695

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:07:25

I took fresh towels into guest cottage and bea like hunched over\. Gah


---

### 2588. msg_15696

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:07:32

The others all watching a movie


---

### 2589. msg_15697

**You** - 2025-05-31T00:08:04

ah ok


---

### 2590. msg_15698

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:10:17

>
I think you said it above\. I guess I’m curious where you see this going in all senses\. I’m being cryptic\. Hmmh\. I’m not sure how to say thing ms without being starkly honest


---

### 2591. msg_15699

**You** - 2025-05-31T00:10:25

be starkly honest


---

### 2592. msg_15700

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:11:24

Was stark the word?


---

### 2593. msg_15701

**You** - 2025-05-31T00:11:27

yep


---

### 2594. msg_15702

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:11:44

k couldn’t remember


---

### 2595. msg_15703

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:13:50

Stark honesty: So before Andrew I had a relationship \(or 2\) that was \(were\) really good and different\. Very much more open\. Anyway I would be happy if you were that way\. I feel like you might be but I’m not you\.


---

### 2596. msg_15704

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:14:06

And yes I deleted and retypes here and there


---

### 2597. msg_15705

**You** - 2025-05-31T00:15:42

ok so I have already answered that above\.\. leaving no room for uncertainty\.\.  I do not know what "open" means\.\. it could be a lot of things\.\. some yep\.\. I am good with\.\. others\.\. err no\.\.


---

### 2598. msg_15706

**You** - 2025-05-31T00:16:04

So tell me specifically what do you want to do\.\. stark honesty set to on\.\.\.


---

### 2599. msg_15707

**You** - 2025-05-31T00:16:52

>
also were these the relationships with the drugs?


---

### 2600. msg_15708

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:18:01

I just mean like do you want to try different things sometimes in the future when we are like together together… games, etc


---

### 2601. msg_15709

**You** - 2025-05-31T00:17:54

If i had to guess


---

### 2602. msg_15710

**You** - 2025-05-31T00:18:29

probably J and C likely the two you were very comfortable with\.


---

### 2603. msg_15711

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:18:53

\(I will ChatGPT the rest\.\.\)


---

### 2604. msg_15712

**You** - 2025-05-31T00:18:49

>
Again you are being cryptic\.\. you can come right out and say it\.


---

### 2605. msg_15713

**You** - 2025-05-31T00:19:16

>
I think you know who I mean\.\. I also feel like you are getting uncomfortable with these questions\.\. lol


---

### 2606. msg_15714

**You** - 2025-05-31T00:20:04

only reason I ask is because that might be something impossible for me to replicate for you\.


---

### 2607. msg_15715

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:20:38

>
I’m curious if in the future, obviously not now you see things evolving\. Say, couple board game\. Would that be weird or no\. Just an example\.


---

### 2608. msg_15716

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:21:04

>
I’m not looking to replicate\. Those were left for a reason\.


---

### 2609. msg_15717

**You** - 2025-05-31T00:20:59

ahhhh that "open"


---

### 2610. msg_15718

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:21:19

It isn’t replication, it is more mindset\.


---

### 2611. msg_15719

**You** - 2025-05-31T00:22:58

ok gpt didn't help me here


---

### 2612. msg_15720

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:24:31

k, I just put Ben folds five on and am a bit stoned now so have to listen…


---

### 2613. msg_15721

**You** - 2025-05-31T00:27:36

kk


---

### 2614. msg_15722

**You** - 2025-05-31T00:28:05

you are going to need to focus in here Mer\.\. I really need you to


---

### 2615. msg_15723

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:28:15

You should go to bed


---

### 2616. msg_15724

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:28:19

:\)


---

### 2617. msg_15725

**You** - 2025-05-31T00:28:12

omg


---

### 2618. msg_15726

**You** - 2025-05-31T00:28:15

I cannot go to bed


---

### 2619. msg_15727

**You** - 2025-05-31T00:28:17

jesus


---

### 2620. msg_15728

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:28:31

What? Why?


---

### 2621. msg_15729

**You** - 2025-05-31T00:28:27

you cannot drop that and tell me to go to bed


---

### 2622. msg_15730

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:29:04

Drop what omg\. I explained


---

### 2623. msg_15731

**You** - 2025-05-31T00:29:05

So define "open" because GPT defines it two ways\.


---

### 2624. msg_15732

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:29:33

>
This was an example


---

### 2625. msg_15733

**You** - 2025-05-31T00:29:45

One way is you and I play an interesting board game that we play together to engage differently etc\.


---

### 2626. msg_15734

**You** - 2025-05-31T00:29:49

the other definition


---

### 2627. msg_15735

**You** - 2025-05-31T00:29:57

was about us playing a couples\.\.\.\. board game\.\.


---

### 2628. msg_15736

**You** - 2025-05-31T00:30:06

Reaction: 😂 from Meredith Lamb
which is different\.\. lol


---

### 2629. msg_15737

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:30:12

>
Open to things maybe you have done the past 25 yrs


---

### 2630. msg_15738

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:30:20

\*have not


---

### 2631. msg_15739

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:30:50

>
They seem the same actually


---

### 2632. msg_15740

**You** - 2025-05-31T00:30:51

I already told you I was\.\. but it depends\.\. on what they are\.\.


---

### 2633. msg_15741

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:31:17

Ok very fair good answer


---

### 2634. msg_15742

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:31:18

lol


---

### 2635. msg_15743

**You** - 2025-05-31T00:31:11

Am I willing to have an Open relationship\.\. is that what you are asking


---

### 2636. msg_15744

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:31:23

No


---

### 2637. msg_15745

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:31:28

Not even close


---

### 2638. msg_15746

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:31:55

You think I could do that?


---

### 2639. msg_15747

**You** - 2025-05-31T00:31:56

ok\.\. that is what I thought you meant with the game\.


---

### 2640. msg_15748

**You** - 2025-05-31T00:32:00

well Mer\.\.


---

### 2641. msg_15749

**You** - 2025-05-31T00:32:02

again


---

### 2642. msg_15750

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:32:11

Nope


---

### 2643. msg_15751

**You** - 2025-05-31T00:32:09

you have shared some drunken stories


---

### 2644. msg_15752

**You** - 2025-05-31T00:32:12

stark truth and all


---

### 2645. msg_15753

**You** - 2025-05-31T00:32:14

lol


---

### 2646. msg_15754

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:32:28

Bed time


---

### 2647. msg_15755

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:32:32

lol


---

### 2648. msg_15756

**You** - 2025-05-31T00:32:27

and you have suggested some situations where the lines got a little fuzzy\.


---

### 2649. msg_15757

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:32:38

You can sleep now


---

### 2650. msg_15758

**You** - 2025-05-31T00:32:46

I think you and Jeremy and kind of even with the drugs you guys were like wtf\!\!


---

### 2651. msg_15759

**You** - 2025-05-31T00:32:55

sorry the memory thing


---

### 2652. msg_15760

**You** - 2025-05-31T00:33:01

I hear it I rarely forget


---

### 2653. msg_15761

**You** - 2025-05-31T00:33:24

I think it was you Jeremey Chris and friends\.


---

### 2654. msg_15762

**You** - 2025-05-31T00:33:29

if I recall\.


---

### 2655. msg_15763

**You** - 2025-05-31T00:33:39

so yeah that is why I asked about the "open"


---

### 2656. msg_15764

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:33:59

No no no no I haven’t done anything like that


---

### 2657. msg_15765

**You** - 2025-05-31T00:34:37

after you


---

### 2658. msg_15766

**You** - 2025-05-31T00:34:43

you were going to say something


---

### 2659. msg_15767

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:35:14

Not sure


---

### 2660. msg_15768

**You** - 2025-05-31T00:35:13

that is not true


---

### 2661. msg_15769

**You** - 2025-05-31T00:35:23

you wouldn't let me get away with that


---

### 2662. msg_15770

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:35:46

🫩


---

### 2663. msg_15771

**You** - 2025-05-31T00:35:58

what is that?


---

### 2664. msg_15772

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:36:22

lol


---

### 2665. msg_15773

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:37:07

https://open\.spotify\.com/track/3Uvx1TO0Kg5HgGPk58lHXv?si=hp\_R8i76Ri2eKghgGFVUAQ
Does this song make you feel sad for your marriage?


---

### 2666. msg_15774

**You** - 2025-05-31T00:37:05

ok I feel like you are really resisting\.\.


---

### 2667. msg_15775

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:37:26

I can hardly remember honestly


---

### 2668. msg_15776

**You** - 2025-05-31T00:37:40

so maybe we should just call it\.\. it is too bad I am really curious


---

### 2669. msg_15777

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:37:56

Yes Jeremy and I … and Chris and I, did a lot of drugs\. But then it ended\.


---

### 2670. msg_15778

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:38:16

>
I don’t even know what I’m not responding to


---

### 2671. msg_15779

**You** - 2025-05-31T00:39:42

I am trying to understand what you want\.\. board games\.\.\. role playing\.\.\. I haven't ever done those things\.\. or whatever else you might be referring to\.\.\. that is what I am curious about\.\. specifics\.\. but I can tell you YES I would definitely be interested\.\. but doesn't help my curiosity\.


---

### 2672. msg_15780

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:40:38

I don’t really have super specifics atm\. Just curious if you see things evolving


---

### 2673. msg_15781

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:40:56

I’m honestly good either way but was just curious


---

### 2674. msg_15782

**You** - 2025-05-31T00:41:20

I mean I have never "evolved" I thought you had specific examples you were going to reference from those 2 past relationships you mentioned \- yo said they were more open\.\. I was just looking for details lol


---

### 2675. msg_15783

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:41:30

Sorry wasn’t actually like making a PLAN with a specific roadmap :p


---

### 2676. msg_15784

**You** - 2025-05-31T00:41:36

Reaction: 😂 from Meredith Lamb
well then examples\.\. more than board game examples\.


---

### 2677. msg_15785

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:43:05

I just am not sure if you have ever thought about it? That’s probably cryptic right?


---

### 2678. msg_15786

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:43:36

For instance, other than making someone happy have you ever thought about what you want?


---

### 2679. msg_15787

**You** - 2025-05-31T00:47:29

I tried to explain\.\. how can I say this differently


---

### 2680. msg_15788

**You** - 2025-05-31T00:48:27

If I understand your wants outside of let's say climax\.\. then I would know what to do\.  But I told you I am simple\.\. if I know I am making you happy sexually or any other way\.\. it actually gives me happiness\.


---

### 2681. msg_15789

**You** - 2025-05-31T00:49:08

>
yeah you have been really really cryptic tonight\.\. I am guessing you had way more than 1 gummy\.


---

### 2682. msg_15790

**You** - 2025-05-31T00:49:21

:\(


---

### 2683. msg_15791

**You** - 2025-05-31T00:49:43

>
I want to be with you for the rest of my life\.


---

### 2684. msg_15792

**You** - 2025-05-31T00:49:55

that is it


---

### 2685. msg_15793

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:50:08

>
No \- one\!


---

### 2686. msg_15794

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:50:15

Few hrs ago


---

### 2687. msg_15795

**You** - 2025-05-31T00:50:15

you said you were stoned


---

### 2688. msg_15796

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:50:21

Bottle of wine tho


---

### 2689. msg_15797

**You** - 2025-05-31T00:50:21

you don't get stoned off one gummyt


---

### 2690. msg_15798

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:50:49

I actually did for like a while\. Surprising


---

### 2691. msg_15799

**You** - 2025-05-31T00:50:47

lol


---

### 2692. msg_15800

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:51:04

It’s gone now :\(


---

### 2693. msg_15801

**You** - 2025-05-31T00:51:03

anyways\.\. you have my thoughts above\.\. I would give you more if I had more to give you


---

### 2694. msg_15802

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:51:27

Did I scare you tonight? Lol


---

### 2695. msg_15803

**You** - 2025-05-31T00:51:25

hardly


---

### 2696. msg_15804

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:51:45

k good


---

### 2697. msg_15805

**You** - 2025-05-31T00:51:41

I mean I was more concerned with your focus on my relationship with Jaimie


---

### 2698. msg_15806

**You** - 2025-05-31T00:51:51

less about me and safe words\.\.


---

### 2699. msg_15807

**You** - 2025-05-31T00:51:56

:\)


---

### 2700. msg_15808

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:52:08

I’m not FOCUSED on it


---

### 2701. msg_15809

**You** - 2025-05-31T00:52:08

I feel like you might be a bit


---

### 2702. msg_15810

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:52:21

It is simple a part of the story


---

### 2703. msg_15811

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:52:24

Right now


---

### 2704. msg_15812

**You** - 2025-05-31T00:52:29

you asked a lot of questions about my sexual relationship with jaimie or lack there of\.\. and why\.\. and and lol


---

### 2705. msg_15813

**You** - 2025-05-31T00:52:33

I mean I am happy to answer\.


---

### 2706. msg_15814

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:52:52

Just trying to understand you more


---

### 2707. msg_15815

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:53:01

Context


---

### 2708. msg_15816

**You** - 2025-05-31T00:53:21

I am an enigma, wrapped in a riddle\.\. wrapped in a rhyme\.


---

### 2709. msg_15817

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:53:36

Nothing is really tmi for me to hear\. More just context


---

### 2710. msg_15818

**You** - 2025-05-31T00:53:34

KK then


---

### 2711. msg_15819

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:53:48

>
I would agree


---

### 2712. msg_15820

**You** - 2025-05-31T00:53:41

give like you get\. lol


---

### 2713. msg_15821

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:53:58

Hmmh probably not


---

### 2714. msg_15822

**You** - 2025-05-31T00:53:54

you are super cagey and super cryptic


---

### 2715. msg_15823

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:54:13

lol


---

### 2716. msg_15824

**You** - 2025-05-31T00:54:22

why can't you put yourself out there\.\. take a risk\.\. trust that I love everything about you no matter what\.


---

### 2717. msg_15825

**You** - 2025-05-31T00:54:36

tell me what you want\.\.


---

### 2718. msg_15826

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:56:16

My feelings are as I expressed them\. I don’t have your ability to explain things…\. So super cagey it might be\.


---

### 2719. msg_15827

**You** - 2025-05-31T00:56:36

ok


---

### 2720. msg_15828

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:56:44

Just bear with me…


---

### 2721. msg_15829

**You** - 2025-05-31T00:56:49

let me ask the question a different way\.\. very specifically\.


---

### 2722. msg_15830

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:57:05

I am not so\!


---

### 2723. msg_15831

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:57:11

\*ai\!


---

### 2724. msg_15832

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:57:16

lol


---

### 2725. msg_15833

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:57:24

I went to your session today


---

### 2726. msg_15834

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T00:57:28

Did you forget


---

### 2727. msg_15835

**You** - 2025-05-31T00:59:08

Initially you references 2 relationships\. I knew who they were\. easy guess for me based on what you have shared\.\. I did suggest earlier\.\. that if these were the drug related relationships I might not be able to replicate the experiences\. Now you talked about how those relationships were much more open than that between you and Andrew\.\. and I can see why who likes to be told how to service their partner all the time\.  Certainly wouldn't make me want to be super open for fun and stuff\.  So you made the reference to the 2 previous relationships\.\. then to this couples board\.\. game\.\. gpt suggested games like \-  Monogamy
Our Moments \(for couples\)
The Discovery Game
Talk Flirt Dare
Let's Talk About Sex \(conversation card decks\)


---

### 2728. msg_15836

**You** - 2025-05-31T00:59:15

But that is one example\.


---

### 2729. msg_15837

**You** - 2025-05-31T00:59:31

I am asking if you can provide other specific examples from those relationships that you would like us to explore together\.


---

### 2730. msg_15838

**You** - 2025-05-31T00:59:58

activities\.\. sexual or otherwise\.\. games, anything\.\. I would like to get my mind around it\.


---

### 2731. msg_15839

**You** - 2025-05-31T01:00:41

then I might just need to get a little drunk\.\.\. 🥰 and we should be good to go\.


---

### 2732. msg_15840

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:01:16

I don’t have anything specific to share atm … maybe later\.


---

### 2733. msg_15841

**You** - 2025-05-31T01:01:11

like I don't know what you mean positions\.\. drugs\.\. I will do some\.


---

### 2734. msg_15842

**You** - 2025-05-31T01:01:18

>
no you wont


---

### 2735. msg_15843

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:01:28

No drugs\.


---

### 2736. msg_15844

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:01:35

Bad drugs\.


---

### 2737. msg_15845

**You** - 2025-05-31T01:01:28

I promise it would be better for both if you shared now\.\.


---

### 2738. msg_15846

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:01:41

Hearts attacks and stuff


---

### 2739. msg_15847

**You** - 2025-05-31T01:01:44

it will be easier for you\.\. and you might be pleasantly surprised later\.


---

### 2740. msg_15848

**You** - 2025-05-31T01:02:09

like\.\. aids?? toys??


---

### 2741. msg_15849

**You** - 2025-05-31T01:02:12

other stuff?


---

### 2742. msg_15850

**You** - 2025-05-31T01:02:13

lol


---

### 2743. msg_15851

**You** - 2025-05-31T01:02:19

I read books you know\!\!


---

### 2744. msg_15852

**You** - 2025-05-31T01:02:22

rofl


---

### 2745. msg_15853

**You** - 2025-05-31T01:02:37

are you embarassed\.


---

### 2746. msg_15854

**You** - 2025-05-31T01:02:39

or shy


---

### 2747. msg_15855

**You** - 2025-05-31T01:02:41

or nervous


---

### 2748. msg_15856

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:03:53

Maybe I’m not thinking specific stuff but wondering… sigh … not embarrassed, shy\. I have nothing I want to replicate so it isn’t an easy question to answer\. Stuff will come up and I was just curious how you felt about us and if you think we will always be like this\.


---

### 2749. msg_15857

**You** - 2025-05-31T01:04:09

when you say be like this\.\. do you mean vanilla?


---

### 2750. msg_15858

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:04:48

Nope\. I mean super obsessed with each other\. Like literally cannot get enough


---

### 2751. msg_15859

**You** - 2025-05-31T01:04:45

sorry I am trying to use an analogy


---

### 2752. msg_15860

**You** - 2025-05-31T01:04:50

oh shit


---

### 2753. msg_15861

**You** - 2025-05-31T01:04:52

again


---

### 2754. msg_15862

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:05:17

lol


---

### 2755. msg_15863

**You** - 2025-05-31T01:05:12

you are worried I am going to get bored\.\. OR you are worried you will


---

### 2756. msg_15864

**You** - 2025-05-31T01:05:37

Let me tell you something in all honesty ok\.\.


---

### 2757. msg_15865

**You** - 2025-05-31T01:07:02

Being with you feels better than being with anyone else previously\.\. hand down no comparison\.\. not even close\.\. I will never get bored of you\.\. you will never need to do anything kinky or crazy to keep my interest\.\. that said I am also willing to do whatever you want\.\. because I love you, and I will always want to make you happy\.  That means trying new things\.\. taking risks etc\.


---

### 2758. msg_15866

**You** - 2025-05-31T01:08:26

So I am happy to evolve if that is what you want\.\. or I am happy to keep doing this\.\. or I am happy to do about anything\.  But with you it feels like electricity\.\. best way to explain it\.\. so again\.\. happy with anything and everything\.


---

### 2759. msg_15867

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:09:56

❤️❤️


---

### 2760. msg_15868

**You** - 2025-05-31T01:10:05

>
And while I do love you to death\.\. I think you are dodging here because it might be uncomfortable to talk about\.\. you might be comfortable listening to all my "stuff" but not sure you are equally comfortable sharing certain things\.


---

### 2761. msg_15869

**You** - 2025-05-31T01:10:33

remember what I said about a week ago


---

### 2762. msg_15870

**You** - 2025-05-31T01:10:35

tonight


---

### 2763. msg_15871

**You** - 2025-05-31T01:10:40

oh wait no you don't


---

### 2764. msg_15872

**You** - 2025-05-31T01:10:41

LOL


---

### 2765. msg_15873

**You** - 2025-05-31T01:10:46

well played scott


---

### 2766. msg_15874

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:10:56

lol


---

### 2767. msg_15875

**You** - 2025-05-31T01:11:08

I was telling you what Deb warned me about\.


---

### 2768. msg_15876

**You** - 2025-05-31T01:11:11

do you remember


---

### 2769. msg_15877

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:11:31

😔


---

### 2770. msg_15878

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:11:35

Nope


---

### 2771. msg_15879

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:11:45

Moving on too quickly?


---

### 2772. msg_15880

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:11:51

Or was that my aunt?


---

### 2773. msg_15881

**You** - 2025-05-31T01:12:44

She said some people when they get in our situations\.\. tend to look backwards at what they had and yearn for it\.\. for the excitement, the adventure, the freedom\.  They want to feel that again\.\. sometimes that means going back to the people that they used to be with to experience that\.\. sometimes that means something else\.\. she just said be careful if that is what she wants, and you don't fit that mold for her\.


---

### 2774. msg_15882

**You** - 2025-05-31T01:13:22

Reaction: ❤️ from Meredith Lamb
I am willing to be whoever you want me to be with you \- I will always be me\.\. but with you I can be whatever you need me to be\.


---

### 2775. msg_15883

**You** - 2025-05-31T01:13:52

You just on your own are more than enough for me\.\. making you happy makes me happy\. And that is sustainable btw\.


---

### 2776. msg_15884

**You** - 2025-05-31T01:14:07

the rest of my life thing\.\. that is real\.\. even though it terrifies you to hear it\.


---

### 2777. msg_15885

**You** - 2025-05-31T01:15:07

but yeah the rest of my life hopefully is a long time\.\. and we can do all kinds of fun things but I think you need to reflect specifically on what it is you are looking for\.\. I still don't understand what prompted you to raise it whether it is out of something you desire, or out of concern for something else\.


---

### 2778. msg_15886

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:15:23

>
Doesn’t terrify me\!


---

### 2779. msg_15887

**You** - 2025-05-31T01:16:18

So I gave you a shit ton of examples\.\. if you could now or later\.\. but sometime soon\.\. please clarfiy specifically what you are interested in\.\. without worry\.\. the sooner I know the sooner I can get my head around it and the sooner, we can begin our adventures :\)


---

### 2780. msg_15888

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:17:11

https://open\.spotify\.com/track/6liaHE9iHh23PLVvw7lK8V?si=cwlzdj0nRAeGditUWAWagg
After this song I’m passing our


---

### 2781. msg_15889

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:17:28

\*out


---

### 2782. msg_15890

**You** - 2025-05-31T01:17:26

ok\.\. i guess we can pick this up another time\.\. :\)


---

### 2783. msg_15891

**You** - 2025-05-31T01:17:34

Go to bed\.


---

### 2784. msg_15892

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:18:43

>
This is really interesting insight that I have never heard talked about\. Wonder if it is true?  I can see myself a BIT in that but not fully\. Those were some dysfunctional times…\.


---

### 2785. msg_15893

**You** - 2025-05-31T01:19:02

It is true for many people


---

### 2786. msg_15894

**You** - 2025-05-31T01:19:05

I have seen it


---

### 2787. msg_15895

**You** - 2025-05-31T01:19:14

it is the reason a lot of people get divorced


---

### 2788. msg_15896

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:19:29

Huh?


---

### 2789. msg_15897

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:19:32

No


---

### 2790. msg_15898

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:19:35

Can’t be true


---

### 2791. msg_15899

**You** - 2025-05-31T01:19:33

People get tired of who they are with\.\. want to go back


---

### 2792. msg_15900

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:19:43

Finances and kids


---

### 2793. msg_15901

**You** - 2025-05-31T01:19:37

feel like they missed out


---

### 2794. msg_15902

**You** - 2025-05-31T01:19:39

made a bad decision


---

### 2795. msg_15903

**You** - 2025-05-31T01:19:45

want a do over


---

### 2796. msg_15904

**You** - 2025-05-31T01:19:49

it happens


---

### 2797. msg_15905

**You** - 2025-05-31T01:19:57

it is happening to my friend mark back home right now


---

### 2798. msg_15906

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:20:10

I don’t want to go back though\. Don’t want to go back to bat shit crazy land\.


---

### 2799. msg_15907

**You** - 2025-05-31T01:20:19

but you want to feel like it without the side effects\.


---

### 2800. msg_15908

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:20:53

Perhaps… not sure\. I should talk to ChatGPT about it


---

### 2801. msg_15909

**You** - 2025-05-31T01:20:47

so again\.\. you will need to work with me and share with me\.\. and we can see what we can do together\.


---

### 2802. msg_15910

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:21:51

To be crystal clear, I am so in love with you and love every second of our time together and ache for the next time\. Just thinking about the future


---

### 2803. msg_15911

**You** - 2025-05-31T01:22:34

I appreciate it\.\. and I didn't take it the wrong way Mer\.\. I took it 100% the right way\.  And yeah I really would like to "explore" for lack of a better term\.\. and tbh I wouldn't have been comfortable doing this with anyone else\.


---

### 2804. msg_15912

**You** - 2025-05-31T01:23:27

now go to bed\.\. relax\.\. kind of intense conversation\.\. but at least I kind of think I know a little about what you want\.\. so just give me some ideas\.\. or at least of all of the things I mentioned\.\. tell me what you aren't interested in\.


---

### 2805. msg_15913

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:25:13

https://open\.spotify\.com/track/5aDpULK8MbJmHl42kR5KNI?si=xIX\-sfHeRMao8guMe1U0ZA
Listen to this before you go to bed\. Oldie xo


---

### 2806. msg_15914

**You** - 2025-05-31T01:25:36

is a good song\.\.


---

### 2807. msg_15915

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:26:00

k, I’m passing out slowly


---

### 2808. msg_15916

**You** - 2025-05-31T01:25:54

I love you Mer\.\. get some sleep\.\. xoxo


---

### 2809. msg_15917

**You** - 2025-05-31T01:26:00

❤️❤️❤️


---

### 2810. msg_15918

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:26:08

Reaction: ❤️ from Scott Hicks
Need to go to bed\. Love you


---

### 2811. msg_15919

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T01:26:14

❤️


---

### 2812. msg_15920

**You** - 2025-05-31T09:32:23

Well I did not
Get up to a happy morning I was up till 2:30 am Gracie decided
To have another go j got involved another fight\.  I think I am going to spend a bit knife and rent a three bedroom townhouse\.\. Gracie seems to think unless I have three bedrooms it will be impossible for her to visit\.  So I will need to do some math\.\. the rent
Will be about half my take home\.\. so should be interesting\.\. with all the other expenses\.\. will basically be a year where I cannot save much except my bonus and ltip\.  After that I am doing what we talked about last night\.\. assuming you remember the very very interesting conversation we had
Last night ❤️


---

### 2813. msg_15921

**You** - 2025-05-31T09:34:04

Taking teddy to groomer at 10:30 then doing some house work picking her up gym and/or more housework\.\. need to review the roll
Over content\.\. would like to try
Playing ticket
To ride with you again tonight or something else if
You are up for it\.\. wish I could come up but that is just not doable\.  Maybe we can find a morning this week where I go to the park or maybe next
Weekend we can find just a bit of time\.\. not planning just hoping as you say\.


---

### 2814. msg_15922

**You** - 2025-05-31T09:35:49

Anyhow hope you are not too hung over\- fucking called it\!\! And I very much want to revisit the “open” conversation last night\.\. not because I want to make you feel uncomfortable, but I feel there is something there you are hoping for, and I if I am able, lol, I am willing\.\. but I do need a bit more info lol\.\.
Preferably from sober Meredith\.


---

### 2815. msg_15923

**You** - 2025-05-31T09:37:04

Ok back to work\.\. I love you mer xoxo dreamt about us last night,  it was great because it was nothing more than a normal future looking dream of us spending time together, just talking sitting ins couch somewhere in front of a fire\.\. it was winter out\.  All I remember


---

### 2816. msg_15924

**You** - 2025-05-31T09:37:11

❤️❤️❤️❤️


---

### 2817. msg_15925

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T10:19:58

Um, little hungover lol but I don’t have to do too much today\. A couple meals and cleaning\. Probably napping\. lol going to make girls bacon, sausage, eggs, hashbrowns this morning\. I will likely need it myself LOL


---

### 2818. msg_15926

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T10:20:16

>
I wish I had this dream\! 😍


---

### 2819. msg_15927

**You** - 2025-05-31T10:20:21

You I\. Bed


---

### 2820. msg_15928

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T10:30:49

Yep\. I took griffin out at like 7\.30 and then went back to bed\.


---

### 2821. msg_15929

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T11:35:38

After breakfast I’m going to reread  last night\. Lol I wasn’t expecting for that conversation to go the way it went I don’t think\. 🤔 but I do love how you latch on to things and not let them go actually\. It can be annoying but I love that part of your personality 🙂


---

### 2822. msg_15930

**You** - 2025-05-31T11:37:35

It is only because I believe it is important to you\.  And while I don’t understand, I want to\.\. I don’t want you to shy away from sharing or being anxious, I am as here for you as much as you are for me\.  And mer I was honest I would love to try pretty much anything with you just because it is you ☺️


---

### 2823. msg_15931

**You** - 2025-05-31T11:37:47

So have a reread\.


---

### 2824. msg_15932

**You** - 2025-05-31T11:40:53

And please please ask questions and please please try to get comfortable enough to share with me what you are interested in\.  I want to know you as much as you want to know me\. And remember we are 47 time is a factor so let’s not waste any 😋


---

### 2825. msg_15933

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:17:08

Omg just finished brunch making and cleaning\. Phewwwwww


---

### 2826. msg_15934

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:18:13


*1 attachment(s)*


---

### 2827. msg_15935

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:18:51


*1 attachment(s)*


---

### 2828. msg_15936

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:25:01

This is challenging to process\.

*1 attachment(s)*


---

### 2829. msg_15937

**You** - 2025-05-31T13:31:42

Holy shit


---

### 2830. msg_15938

**You** - 2025-05-31T13:32:00

What is challenging


---

### 2831. msg_15939

**You** - 2025-05-31T13:32:05

Reading back through?


---

### 2832. msg_15940

**You** - 2025-05-31T13:33:05

Reaction: 👍 from Meredith Lamb
You understand the context of that statement right… because it was part of a larger discussion\.


---

### 2833. msg_15941

**You** - 2025-05-31T13:39:45

Single was a reference to how I handled needs that was what you were asking about\. I went in to say that isn’t relevant anymore\.


---

### 2834. msg_15942

**You** - 2025-05-31T13:41:19

Reaction: ❤️ from Meredith Lamb
So confused not sure you you are processing things or from what angle I feel like you are trying to predict how I will behave with you when a\. I never behaved like that with anyone before and I had several long term relationships and b m\. You are my soulmate\.\. I believe it I am comfortable saying it\.\. it is like comparing apples and airplanes\.\. no point of comparison


---

### 2835. msg_15943

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:44:44

>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
I don’t think I fully read this last night but it is sort of what I was thinking\. I just was worried that if whatever is happening between us physically doesn’t last or stops for some reason, you’re not going to hole yourself up in the basement and shut me out\. Like there is other ways to connect and be intimate\. Really all I was trying to articulate in a really horrible manner LOL


---

### 2836. msg_15944

**You** - 2025-05-31T13:57:07

What are you doing atm?


---

### 2837. msg_15945

**You** - 2025-05-31T13:57:53

Driving to gym call if you want easier to express this directly


---

### 2838. msg_15946

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:59:29

I just reread it all\!


---

### 2839. msg_15947

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T13:59:34

Holy\. Long


---

### 2840. msg_15948

**You** - 2025-05-31T13:59:45

Kk


---

### 2841. msg_15949

**You** - 2025-05-31T13:59:57

Avail if you are lol


---

### 2842. msg_15950

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T14:00:17

I am, back in bed


---

### 2843. msg_15951

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T14:00:19

lol


---

### 2844. msg_15952

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T14:00:28

Took and aleve and then started reading


---

### 2845. msg_15953

**You** - 2025-05-31T14:01:04

Kk if you want to text I can try when I get to gym driving now


---

### 2846. msg_15954

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T14:01:38

>
Okay, you may have a point\.


---

### 2847. msg_15955

**You** - 2025-05-31T15:43:22

Maybe update photo today\.\. feeling good 😜


---

### 2848. msg_15956

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T15:43:47

🙂


---

### 2849. msg_15957

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T15:47:12

I’m not sure I could handle it but am happy to try\. :\) You were worried of me projecting on you and that I might be getting bored\. Furthest thing from the truth…\. I literally logged in yesterday just to hear you speak and your voice\. Today, just talking to you… honestly just that and I can’t stop thinking about you… so the projecting thing was kind of funny tbh\.
k, I have to go into town for the umpteenth time and then Mac wants me to set up a “photo wall” for them lol
I will wait patiently for your progress photo\. ⏳


---

### 2850. msg_15958

**You** - 2025-05-31T15:51:06

Reaction: 😋 from Meredith Lamb
God I love you\.\. Nuff said\.


---

### 2851. msg_15959

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T16:37:42

I forgot to tell you when I was hanging out with the girls last night they go “who is Scott?” And Mac goes “oh just her boyfriend”\. LOL


---

### 2852. msg_15960

**You** - 2025-05-31T16:47:49

Reaction: 😍 from Meredith Lamb
Pg

*1 attachment(s)*


---

### 2853. msg_15961

**You** - 2025-05-31T16:48:22

Reaction: 😍 from Meredith Lamb
Pg 2

*1 attachment(s)*


---

### 2854. msg_15962

**You** - 2025-05-31T16:49:11

One more coming just hanging on for bit happy with my progress need to compare back


---

### 2855. msg_15963

**You** - 2025-05-31T16:53:41

>
You can show them a safe pic if you haven’t already\.\. or who knows what you showed them lol\. You tend to go above and beyond sometimes lol\.


---

### 2856. msg_15964

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:09:43

>
What is happening to you… god, so hot\. I’m feeling extremely slacky now for not starting to work out yet\.


---

### 2857. msg_15965

**You** - 2025-05-31T17:25:57

Last one


---

### 2858. msg_15966

**You** - 2025-05-31T17:26:55

A

*1 attachment(s)*


---

### 2859. msg_15967

**You** - 2025-05-31T17:27:41

Not quite Henry yet but I will get there\.


---

### 2860. msg_15968

**You** - 2025-05-31T17:32:19

>
Pshhh not hot don’t kid yourself just\. Try hard old man\.


---

### 2861. msg_15969

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:41:29

>
Oh Whatever…\. No wonder why Jaimie is upset at you


---

### 2862. msg_15970

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:42:42

Got my stupid wall done for their photos\. Gotta walk dogs now

*1 attachment(s)*


---

### 2863. msg_15971

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:42:53

Now they want ANOTHER wall omg


---

### 2864. msg_15972

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:43:27

>
Am I above and beyond? No one has ever told me that before\. :p


---

### 2865. msg_15973

**You** - 2025-05-31T17:43:38

You are extra


---

### 2866. msg_15974

**You** - 2025-05-31T17:44:00

J doesnt see me anymore so she doesn’t know


---

### 2867. msg_15975

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:45:28

>
Oh whatever\. Anyone can tell\. And you guys go “driving” places\. She sees you


---

### 2868. msg_15976

**You** - 2025-05-31T17:45:33

I don’t send her the pics either 😜


---

### 2869. msg_15977

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:45:43

I’m not being jealous\. Just saying


---

### 2870. msg_15978

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:45:45

lol


---

### 2871. msg_15979

**You** - 2025-05-31T17:45:51

Not the same as shirtless stuff only you see that


---

### 2872. msg_15980

**You** - 2025-05-31T17:46:06

Not the same at all


---

### 2873. msg_15981

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:46:37

You can tell shirtless or not


---

### 2874. msg_15982

**You** - 2025-05-31T17:46:51

N uh uh


---

### 2875. msg_15983

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:47:09

Just trust me


---

### 2876. msg_15984

**You** - 2025-05-31T17:47:46

Reaction: 🙄 from Meredith Lamb
Nope I prefer to think my way\.\. I mean if it is no diff I could send her the shirtless pic I just sent you\.\.  shouldn’t matter right


---

### 2877. msg_15985

**You** - 2025-05-31T17:48:38

Reaction: ❤️ from Meredith Lamb
That emoji doesnt scare me lol


---

### 2878. msg_15986

**You** - 2025-05-31T17:49:25

Reaction: 😂 from Meredith Lamb
Besides you just don’t like logic traps\.


---

### 2879. msg_15987

**You** - 2025-05-31T17:50:00

>
I could always send this to Cote… ok done teasing……\.😈


---

### 2880. msg_15988

**You** - 2025-05-31T17:50:09

All done


---

### 2881. msg_15989

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:50:11

That was MEAN


---

### 2882. msg_15990

**You** - 2025-05-31T17:50:12

Luv luv luv


---

### 2883. msg_15991

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:50:20

lol


---

### 2884. msg_15992

**You** - 2025-05-31T17:50:21

Luv luv luv


---

### 2885. msg_15993

**You** - 2025-05-31T17:50:23

lol


---

### 2886. msg_15994

**You** - 2025-05-31T17:50:50

Ok
Going to go get groceries then I have to cook
Supper
Then more
Work\.\.
Yay


---

### 2887. msg_15995

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:51:17

I have to make girls dinner soon also


---

### 2888. msg_15996

**You** - 2025-05-31T17:51:47

Cool\. Well j say and watched tv all day\.\. so so far she has been super helpful with the moving etc… Fack


---

### 2889. msg_15997

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:52:11

:\(


---

### 2890. msg_15998

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T17:58:00

Getting ready slowly for the special event dinner

*1 attachment(s)*


---

### 2891. msg_15999

**You** - 2025-05-31T18:00:11

lol man Mac better give you a huge I love you and a hug and mean the hell out of it she is so lucky\.


---

### 2892. msg_16000

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T18:08:06

She will probably give constructive feedback ;\)


---

### 2893. msg_16001

**You** - 2025-05-31T18:10:25

lol 😆 man


---

### 2894. msg_16002

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T18:10:55

Always room for improvement


---

### 2895. msg_16003

**You** - 2025-05-31T18:13:46

>
Not for you\.\. not from my perspective\.


---

### 2896. msg_16004

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T18:32:55

I have a million things to improve on… \#1\. Getting my act together :\)


---

### 2897. msg_16005

**You** - 2025-05-31T18:34:56

Again you can do whatever you want you are already perfect for me\.


---

### 2898. msg_16006

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T18:50:30


*1 attachment(s)*


---

### 2899. msg_16007

**You** - 2025-05-31T19:03:31

You baked all that amazing\!\!\!\!


---

### 2900. msg_16008

**You** - 2025-05-31T19:03:41

❤️❤️❤️❤️❤️❤️❤️❤️❤️


---

### 2901. msg_16009

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:06:48

No no no\. Baked their desserts yday\. Not all that


---

### 2902. msg_16010

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:07:04

Can’t you wait until your 50th? \(I like milestone bdays\)


---

### 2903. msg_16011

**You** - 2025-05-31T19:07:18

You in a birthday suit\.\.


---

### 2904. msg_16012

**You** - 2025-05-31T19:07:22

All I need


---

### 2905. msg_16013

**You** - 2025-05-31T19:10:46

I don’t like bdays\. I do love you\.\. you in a suit checks that box, checks our “fun” box\.  Checks all the good boxes\. lol


---

### 2906. msg_16014

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:14:12

Well if I am the boss then you will like your birthday going forward\. New rule\.


---

### 2907. msg_16015

**You** - 2025-05-31T19:19:02

I will like it but I get the birthday suit deal\.\. :\) agreed?


---

### 2908. msg_16016

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:21:24

It’s your birthday\. Whatever you want 🙂


---

### 2909. msg_16017

**You** - 2025-05-31T19:21:24

Oh


---

### 2910. msg_16018

**You** - 2025-05-31T19:21:27

One more thing


---

### 2911. msg_16019

**You** - 2025-05-31T19:21:36

Have you ever seen the movie true lies?


---

### 2912. msg_16020

**You** - 2025-05-31T19:24:03

Google true lies dance scene\. It is classic Jaimie Lee Curtis\. See I can play\.\. 🥰


---

### 2913. msg_16021

**You** - 2025-05-31T19:24:13

But that is 50


---

### 2914. msg_16022

**You** - 2025-05-31T19:24:18

To be clear


---

### 2915. msg_16023

**You** - 2025-05-31T19:24:21

Not 47


---

### 2916. msg_16024

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:24:27

Yes but haven’t seen it in years


---

### 2917. msg_16025

**You** - 2025-05-31T19:24:31

Cause I am still 46


---

### 2918. msg_16026

**You** - 2025-05-31T19:24:41

Well check
Out the dance scene you will know


---

### 2919. msg_16027

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:25:25

K making dinner\. Will later\. Girls are getting gussied up


---

### 2920. msg_16028

**You** - 2025-05-31T19:26:03

Nice have fun take pics\.


---

### 2921. msg_16029

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:26:43

Mac goes “don’t worry mom you don’t have to dress up”


---

### 2922. msg_16030

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:26:45

LOL


---

### 2923. msg_16031

**You** - 2025-05-31T19:26:59

Rofl 🙁


---

### 2924. msg_16032

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:49:32

They won’t let me make the pasta bc they want to take photos first\. So I’m like on call waiting \(with a glass of wine\)\. Getting late for me lol

*1 attachment(s)*


---

### 2925. msg_16033

**You** - 2025-05-31T19:54:16

>
yeah they can't expect you to sit on glass number 4 very much longer


---

### 2926. msg_16034

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:54:53

lol 3


---

### 2927. msg_16035

**You** - 2025-05-31T19:55:03

shit I started with 3


---

### 2928. msg_16036

**You** - 2025-05-31T19:55:13

but then I thought\.\. that is too optimistic


---

### 2929. msg_16037

**You** - 2025-05-31T19:55:14

LOL:


---

### 2930. msg_16038

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:57:55

It’s been a long afternoon


---

### 2931. msg_16039

**You** - 2025-05-31T19:58:10

It was a long weekend


---

### 2932. msg_16040

**You** - 2025-05-31T19:58:22

actually it has been a long month


---

### 2933. msg_16041

**You** - 2025-05-31T19:58:32

you have been building up for this for more than a month\.


---

### 2934. msg_16042

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:58:30


*1 attachment(s)*


---

### 2935. msg_16043

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:58:45

Those gummies won’t stop looking at me


---

### 2936. msg_16044

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T19:58:51

🤮


---

### 2937. msg_16045

**You** - 2025-05-31T19:59:09

I don't even want to think about whether or not you will take even some of that tonight\.


---

### 2938. msg_16046

**You** - 2025-05-31T19:59:21

cause I don't want to make a prediction lol


---

### 2939. msg_16047

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:18:07

I will not


---

### 2940. msg_16048

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:18:12

150%


---

### 2941. msg_16049

**You** - 2025-05-31T20:19:38

hmmm


---

### 2942. msg_16050

**You** - 2025-05-31T20:20:16

I will have to think about that\.\. one trait you do have\.\. is a penchant for liking to tread a little on the the naughty side\.\. you cannot seem to help it with regards to these kinds of things


---

### 2943. msg_16051

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:20:35


*1 attachment(s)*


---

### 2944. msg_16052

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:20:50


*1 attachment(s)*


---

### 2945. msg_16053

**You** - 2025-05-31T20:21:35

nice pic walls\.\. mom


---

### 2946. msg_16054

**You** - 2025-05-31T20:21:37

well done


---

### 2947. msg_16055

**You** - 2025-05-31T20:21:51

your talents are wasted you should be in event planning\.


---

### 2948. msg_16056

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:25:42

>
Always been a bit of a fault\. 🤷‍♀️


---

### 2949. msg_16057

**You** - 2025-05-31T20:26:27

I know which is why in this I am slightly skeptical lol


---

### 2950. msg_16058

**You** - 2025-05-31T20:27:16

You have no safe gummies\.\.\.  I feel like 70% chance Mac breaks you off an appropriate piece and you trust her to do that and therefore ok to take\.


---

### 2951. msg_16059

**You** - 2025-05-31T20:27:50

Post supper cleanup\.\. my guess\.


---

### 2952. msg_16060

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:33:14

>
Nope\!


---

### 2953. msg_16061

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:33:27

>
No they are eating actually


---

### 2954. msg_16062

**You** - 2025-05-31T20:33:36

no no


---

### 2955. msg_16063

**You** - 2025-05-31T20:33:51

I am saying you will have your bite post supper cleanup after glass  6


---

### 2956. msg_16064

**You** - 2025-05-31T20:34:30

It's ok I will miss most of your fun tonight unfortuntately\.


---

### 2957. msg_16065

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:42:17

>
Does this bother you?


---

### 2958. msg_16066

**You** - 2025-05-31T20:43:04

Only insofar as I worry about you\.\. nothing more than that\.\. I assure you\.


---

### 2959. msg_16067

**You** - 2025-05-31T20:44:08

I was like that too\.\. that is why we would have gotten along famously\.\. and probably gotten into some shit together too\.  I wasn't Jeremy or Chris\.\. but I was fun in my own ways\.\. and crossed all kinds of lines\.


---

### 2960. msg_16068

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:44:10

I mean I have made it to 47 so there is that


---

### 2961. msg_16069

**You** - 2025-05-31T20:45:24

I know look\.\. I will drop it\.\. like you said\.\. you are 47 and can make your own decisions\.  I love you all the same just as you are, but it doesn't mean I won't worry\.


---

### 2962. msg_16070

**You** - 2025-05-31T20:46:09

Go ahead and have fun\.\. I am sure  you and the girls will have a blast\.


---

### 2963. msg_16071

**You** - 2025-05-31T20:50:30

I am just going to play my game for a bit\.\. maybe watch a show and go to bed early\.


---

### 2964. msg_16072

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:56:39

Have to do happy birthday cake and then I think I get a break lol


---

### 2965. msg_16073

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:56:55

Just walking dogs bc griffin was growling at me


---

### 2966. msg_16074

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:56:58

Neglected


---

### 2967. msg_16075

**You** - 2025-05-31T20:57:35

Cool have fun\!  Enjoy the break you have certainly earned one\.


---

### 2968. msg_16076

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T20:59:57

Omg they are talking about all their plans for tonight\. It is going to be a late night\. Oh my God\.


---

### 2969. msg_16077

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:00:07

Not sure I will be able to handle it lol


---

### 2970. msg_16078

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:01:08

I heard from them should we get fried and drunk before we do the chocolate fountain or after?


---

### 2971. msg_16079

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:01:26

🥱


---

### 2972. msg_16080

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:01:31

Yawn


---

### 2973. msg_16081

**You** - 2025-05-31T21:03:10

Yeah sounds like you are in for some fun for sure\.


---

### 2974. msg_16082

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:08:18

Mackenzie made me send this\.

*1 attachment(s)*


---

### 2975. msg_16083

**You** - 2025-05-31T21:09:22

Eesh\. Like a boss\.


---

### 2976. msg_16084

**You** - 2025-05-31T21:09:31

Impressive


---

### 2977. msg_16085

**You** - 2025-05-31T21:10:07

I would go straight shots with the little monkey and see how well she would do lol\.


---

### 2978. msg_16086

**You** - 2025-05-31T21:10:20

Cause I am a responsible adult\.


---

### 2979. msg_16087

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:11:03

She was wondering where the shot glasses came from and when I told her she had to take a video for u lol


---

### 2980. msg_16088

**You** - 2025-05-31T21:11:40

Heheh glad
She made good use of them\.


---

### 2981. msg_16089

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:19:56

I was doing dishes and I hear this Mom so I turn around and she goes\. We just took half of a gummy\.


---

### 2982. msg_16090

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:19:59

FACK


---

### 2983. msg_16091

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:20:10

Fucking Bea Again


---

### 2984. msg_16092

**You** - 2025-05-31T21:20:20

Let the good times roll\.


---

### 2985. msg_16093

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:20:21

She didn’t know they were extra strength


---

### 2986. msg_16094

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:20:28

Like didn’t look at the package


---

### 2987. msg_16095

**You** - 2025-05-31T21:20:29

Oh she is fucked


---

### 2988. msg_16096

**You** - 2025-05-31T21:20:40

Tell her no drinking


---

### 2989. msg_16097

**You** - 2025-05-31T21:20:42

No more


---

### 2990. msg_16098

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:20:51

I told her water water water


---

### 2991. msg_16099

**You** - 2025-05-31T21:20:58

Do you have any of the cbd?


---

### 2992. msg_16100

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:21:07

Not here


---

### 2993. msg_16101

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:21:10

In Toronto


---

### 2994. msg_16102

**You** - 2025-05-31T21:21:14

Water


---

### 2995. msg_16103

**You** - 2025-05-31T21:21:15

Then


---

### 2996. msg_16104

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:21:51

Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 2997. msg_16105

**You** - 2025-05-31T21:22:50

Mission accomplished best mom ever


---

### 2998. msg_16106

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:23:42

Done\.

*1 attachment(s)*


---

### 2999. msg_16107

**You** - 2025-05-31T21:26:22

Great pic for the record books\.\. this is what Gracie wanted\.\. j and I were jist never big on parties\.\. maddie didnt care but Gracie did\.\. glad Mac had a great weekend\.


---

### 3000. msg_16108

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:28:50

Well if she doesn’t hate me I will throw her a party someday\. 😜


---

### 3001. msg_16109

**You** - 2025-05-31T21:29:28

Mmm hmmm


---

### 3002. msg_16110

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:31:06

https://www\.instagram\.com/lamberrybakes?igsh=MW1oangyZDQ2cWtsNQ%3D%3D&utm\_source=qr


---

### 3003. msg_16111

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:32:26

How do you not like parties?


---

### 3004. msg_16112

**You** - 2025-05-31T21:32:29

You are so extra\.\.
I am def not good enough for you\.\. Jesus\.\.
lol


---

### 3005. msg_16113

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:32:30

I don’t get that


---

### 3006. msg_16114

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:35:01

>
Because you don’t plan parties? 🙄


---

### 3007. msg_16115

**You** - 2025-05-31T21:39:08

Just because you are amazing and I don’t measure up\. You are just a fantastic person\.\. your family is lucky\.


---

### 3008. msg_16116

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:40:28

Well I think you are fantastic so…\. :\)


---

### 3009. msg_16117

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:40:53

\(My friends all tease me for being extra btw\.  I know it isn’t normal\.\)


---

### 3010. msg_16118

**You** - 2025-05-31T21:41:38

Hard to keep up with\. Hard expectations to meet\. lol


---

### 3011. msg_16119

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:42:35

🫤


---

### 3012. msg_16120

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:42:38

No\.


---

### 3013. msg_16121

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:43:13

You have high expectations also\.  It is part of why I like you so much\.


---

### 3014. msg_16122

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:43:35

People that don’t are boring\.


---

### 3015. msg_16123

**You** - 2025-05-31T21:48:16

lol\. I have high expectations for work\.  I try to take people as they come\.


---

### 3016. msg_16124

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:51:12

I mean, I think if you have high expectations in one place you do everywhere\.


---

### 3017. msg_16125

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:51:31

You just dismiss them elsewhere because no one lives up to your standards lol


---

### 3018. msg_16126

**You** - 2025-05-31T21:51:51

Agree to disagree


---

### 3019. msg_16127

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:51:58

lol


---

### 3020. msg_16128

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T21:52:27

Maybe I need to get to know you better


---

### 3021. msg_16129

**You** - 2025-05-31T21:52:44

Perhaps\.


---

### 3022. msg_16130

**You** - 2025-05-31T21:53:06

I think I know you better than you know me\.\. and I think I have told you more…\. Ironic


---

### 3023. msg_16131

**You** - 2025-05-31T21:58:15

In in bed not sure what you have on the go but I can chat for a bit quietly if you want fam is watching survivor above me and I turned the fan on down here\.  You might have your hands full with chocolate fountains etc\.\. if so I will probably  turn on something and call it a night\.


---

### 3024. msg_16132

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T22:18:10


*1 attachment(s)*


---

### 3025. msg_16133

**You** - 2025-05-31T22:43:40


*1 attachment(s)*


---

### 3026. msg_16134

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T22:45:18


*1 attachment(s)*


---

### 3027. msg_16135

**You** - 2025-05-31T23:30:34

Nite love you talk to
You tomorrow\.\.
Hope it is smooth sailing for you\. ❤️❤️❤️❤️❤️❤️❤️


---

### 3028. msg_16136

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T23:41:47

More throwing up so she is here now\. No other girl is in this condition\. They are all watching jumanji

*1 attachment(s)*


---

### 3029. msg_16137

**You** - 2025-05-31T23:42:24

Hope she is ok\.\.☹️


---

### 3030. msg_16138

**You** - 2025-05-31T23:42:34

Still she had an epic weekend


---

### 3031. msg_16139

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T23:43:15

If this bowl stays clear all night it will be a win\. 😐


---

### 3032. msg_16140

**You** - 2025-05-31T23:49:23

Well take care of her\.\. she is a little you after all\.\. she needs to grow up find someone like me and drive them crazy\.


---

### 3033. msg_16141

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T23:50:57

Gah\. Lol


---

### 3034. msg_16142

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T23:51:22

I don’t drive you crazy\. You drive ME crazy\. 🙃


---

### 3035. msg_16143

**You** - 2025-05-31T23:52:25

No… I just love you like crazy\.\. and I really still don’t see what you see that would drive you crazy\.\. lol just simple guy with a lot of love
For you mer\.\.


---

### 3036. msg_16144

**You** - 2025-05-31T23:52:28

❤️


---

### 3037. msg_16145

**Meredith Lamb \(\+14169386001\)** - 2025-05-31T23:57:59

I love you like crazy too 🤠 This next week will be interesting\. Sweet dreams\. 💤 ❤️


---

### 3038. msg_16146

**You** - 2025-05-31T23:58:58

Yeah it sure will be\!\!\! \*sarcasm\* love you too hon sleep well\.


---

### 3039. msg_16147

**You** - 2025-05-31T23:59:09

🥰🥰


---

