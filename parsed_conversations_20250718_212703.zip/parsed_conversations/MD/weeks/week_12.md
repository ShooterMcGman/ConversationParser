# Week 12: Conversation Messages

**Date Range:** 2025-06-29 to 2025-07-05  
**Total Messages:** 1500  
**Generated:** 2025-07-18 21:27:08

---

## 📊 Week Summary

- **Week Number:** 12
- **Messages:** 1500
- **Participants:** 2
- **Message Types:** outgoing, incoming, call-history

## 💬 Conversation Messages

### 1. msg_27260

**You** - 2025-06-29T18:24:33

Going out, wine store, dispensary and then picking up supper for me to bring back\.\. if there is anything specific you want a brand or anything just let me know\.


---

### 2. msg_27261

**You** - 2025-06-29T18:51:38

Reaction: 😂 from Meredith Lamb
Too late got 3 bottles of wine and the dispensary was next door


---

### 3. msg_27262

**You** - 2025-06-29T19:16:40

Yeah you will have more than enough I think for tonight and likely tomorrow


---

### 4. msg_27263

**You** - 2025-06-29T19:18:58

Have fun\!  Will def chat
More with your friends on another occasion lots of questions they can answer for me\. I hope they didn’t take my not coming as anything other than wanting you guys to enjoy your time together\.


---

### 5. msg_27264

**You** - 2025-06-29T21:25:20

I may be asleep when you get back feel free to wake me up\.


---

### 6. msg_27265

**Meredith Lamb \(\+14169386001\)** - 2025-06-29T21:27:01

Should be done soon


---

### 7. msg_27266

**Meredith Lamb \(\+14169386001\)** - 2025-06-29T21:58:45

What is the room number again


---

### 8. msg_27267

**You** - 2025-07-01T14:02:19

Careful there\. Lot of ghost cars out today


---

### 9. msg_27268

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T15:08:19

Yeah noticed\. Typical Canada Day :p


---

### 10. msg_27269

**You** - 2025-07-01T15:40:16

Well safe drive\.\.
I am home… back to reality\.\.
Sigh lol


---

### 11. msg_27270

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T15:51:34

Same just got home and back to it\. Empty house though fortunately\. I haven’t had a weekend that good in forever I don’t think\. 🤔 🤔🤔 Can’t think of one in years ❤️❤️❤️


---

### 12. msg_27271

**You** - 2025-07-01T15:55:56

Reaction: ❤️ from Meredith Lamb
I never have\.  Nothing that even comes close\. No one comes close to you Mer\.\. so makes sense\. Love you ❤️❤️❤️


---

### 13. msg_27272

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:17:39

Salmon in the oven and lying watching tv with a heating pad on my abdomen\. I might have something internal bruising lol 🤪


---

### 14. msg_27273

**You** - 2025-07-01T19:19:32

ahh fack Mer\.\. we will tone that way back\.\. I am really really sorry\.\.\. 😟


---

### 15. msg_27274

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:20:29

I’m good it is honestly a little humorous


---

### 16. msg_27275

**You** - 2025-07-01T19:20:29

that was definitely not my intent\.\. really no clue\.


---

### 17. msg_27276

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:20:56

Reaction: ❤️ from Scott Hicks
All worth it 😋😍


---

### 18. msg_27277

**You** - 2025-07-01T19:21:21

still\.\. I will calm it down\.\. or something\.\. will figure it out\.


---

### 19. msg_27278

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:22:17

No \- we maybe just don’t go constantly for hours and days on end all the time lol I am probably more to blame than u haha


---

### 20. msg_27279

**You** - 2025-07-01T19:22:58

yeah it was a little out of hand\.\. perhaps\.


---

### 21. msg_27280

**You** - 2025-07-01T19:23:27

Sorry\.\. again that hasn't quite happened to me\.\. at least not that way, that intense, etc\.\.


---

### 22. msg_27281

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:25:45

Is your house relatively drama free?


---

### 23. msg_27282

**You** - 2025-07-01T19:27:51

Yeah\.\. honestly straight to basement doing laundry, doing a bit of AI work\.\. show on TV\.\. still you know\.\.\.\. meh


---

### 24. msg_27283

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:28:32

I napped lol


---

### 25. msg_27284

**You** - 2025-07-01T19:28:53

yeah I am fine\.\. I want to be able to go to bed early\.\.\. so I can get back on my routine\.


---

### 26. msg_27285

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:31:24

It might take me a day before I get back at it lol


---

### 27. msg_27286

**You** - 2025-07-01T19:31:52

No I have to get back into my routine\.\. quickly\.\. it will help me re\-adapt back to this situation\.


---

### 28. msg_27287

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T19:48:46

Yeah will be an interesting week to see the aftermath\. Maybe the time together will make it easier this week


---

### 29. msg_27288

**You** - 2025-07-01T19:55:32

For me I am not sure how I will feel this week, maybe it will make it easier for you\.  I mean\.\. am I more sure of us\.\. I have been for a while, I don't question that in the least anymore\.  As you said, I haven't loved anyone quite like I love you, or nearly as much, and I feel that from you as well\.  I have never been more clear or sure of what I want, or of what I am willing to give, than I am with you\.


---

### 30. msg_27289

**You** - 2025-07-01T19:57:45

I think this will come down to me being able to manage time apart\.\. find distractions stay busy\.  I don't have nearly as many obligations or things to keep me busy as you do\.\. so I will need to find something, especially for when Maddie is gone\.\. then it will just be me by myself\.  It will make it easier on both of us if I can find something to fill my time so that I am not well\.\. always thinking about you\.\.


---

### 31. msg_27290

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:00:26

There is always work to fill your time 😜\. I’m honestly not expecting this week to be “easier” but who knows\. I certainly have a lot of logistical crap to organize this week and next which will keep me distracted…\. somewhat\. It does feel like such a huge waste that we can’t just be together but patience\.


---

### 32. msg_27291

**You** - 2025-07-01T20:02:00

I know\.\. I am being patient\.\. just would like to fill my time with something meaningful and enjoyable in the times we cannot be together \- which will be a lot for a number of years\.\. so it is kind of important for me to figure this out right\.


---

### 33. msg_27292

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:06:30

“a lot” 😭


---

### 34. msg_27293

**You** - 2025-07-01T20:08:21

well it will be right?  I mean 6 years until all kids in university\.\. at least one week on and off with kids\.\. I mean at some point there is the possibility that we could live together\.\. I would be all for that sooner than later\.\. but there is a LOT to consider\.\. and much more on your side of the fence before that happens\.


---

### 35. msg_27294

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:10:48

It won’t be 6 years that’s for damn sure


---

### 36. msg_27295

**You** - 2025-07-01T20:18:54

Yeah I know\.\. but you know what I mean\.\. this is early on\.\. but feels very different which is what makes it so awkward\.  Look while I do care about the situation\.\. I don't care about it more than I care about you\.\. this could proceed just like this \(bit of a planning shitshow nightmare\)  for the next two years, trying to squeak out times to see each other \(I know it won't once everyone \(not work\) knows\)  but for the sake of argument\.\. I would take the "shitshow" scenario for the rest of my life \- because there aren't any other alternatives or choices for me to make\.\. I have made mine\.  Again, I think the important thing will be for me to build some kind of disposable life\.\. I don't know what you want to call it\.\. but something for when you aren't around\.\. because I don't have family or friends here, and honestly while I think you worry that I will make the wrong kind of friends\.\. or something about oats ffs\.\. I think it will just be easier for both of us if I am a little self sufficien\.\.\. \[truncated\]


---

### 37. msg_27296

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:21:28

“Something about oats ffs” 😂


---

### 38. msg_27297

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:21:36

LOL


---

### 39. msg_27298

**You** - 2025-07-01T20:21:39

that is all you\.\. and is all nonsense


---

### 40. msg_27299

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:22:08

So funny \(and a real thing btw \- the saying exists for a reason\)


---

### 41. msg_27300

**You** - 2025-07-01T20:24:34

I never ascribed anything to what I did when I was younger beyond trying to fill a void\.\. I wasn't happy\.\. companionship gave me a bit of a purpose\.\. made me happy, while making someone else happy\.\. but it was very fleeting mostly\.\. there and gone again\.\. then rinse and repeat\.  Doing what I did wasn't about notches, or sowing seeds, it was about connecting with someone, and feeling connected\.\. at the time I just didn't want a relationship\.  If you were not in the picture, I am not sure how this would have progressed, but it definitely wouldn't be me turning into a 20 year old idiot and sleeping with a bunch of people\.


---

### 42. msg_27301

**You** - 2025-07-01T20:25:48

I feel connected with you more than anyone else ever\.\. since even when we started chatting and kind of realizing what we believed we had, and were walking into together\.\. I haven't so much as thought about another woman in anyway remotely resembling interest\.


---

### 43. msg_27302

**You** - 2025-07-01T20:25:53

Henry doesn't count\.\. fyi


---

### 44. msg_27303

**You** - 2025-07-01T20:26:17

So there will be no Sowing of Oats\.\.


---

### 45. msg_27304

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:26:24

Yes I’m aware of Henry’s positioning in the priority list


---

### 46. msg_27305

**You** - 2025-07-01T20:26:28

near the top


---

### 47. msg_27306

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:26:37

Noted


---

### 48. msg_27307

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:26:38

lol


---

### 49. msg_27308

**You** - 2025-07-01T20:26:41

but not above you\.\. let's be clear


---

### 50. msg_27309

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:26:49

Mmm hmm


---

### 51. msg_27310

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:26:57

Such a liar


---

### 52. msg_27311

**You** - 2025-07-01T20:27:01

true story\.\. would pcik you 10/10 vs Henry


---

### 53. msg_27312

**You** - 2025-07-01T20:27:25

listen I know you would pick Morgan 10/10 vs me\.\. it's ok\.\. I am comfortable in my decision\.


---

### 54. msg_27313

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:27:46

I would not\!


---

### 55. msg_27314

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:28:14

However, if there were such a thing as a hall pass 🤔


---

### 56. msg_27315

**You** - 2025-07-01T20:29:27

mmmm\.\. I don't think there is\.  At least not that I have heard of\.\. I could chatgpt it, and see what it thinks about the idea\.


---

### 57. msg_27316

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:29:43

There totally is


---

### 58. msg_27317

**You** - 2025-07-01T20:30:14

yeah no


---

### 59. msg_27318

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:31:28

lol


---

### 60. msg_27319

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:32:24

You obviously need to look it up


---

### 61. msg_27320

**You** - 2025-07-01T20:34:25

I read what GPT had to say\.\.


---

### 62. msg_27321

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:34:54

If gpt knows, it’s a thing


---

### 63. msg_27322

**You** - 2025-07-01T20:35:13

Oh no\.\. it's a thing\.\. the yeah no was actually after I read what GPT said lol


---

### 64. msg_27323

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:35:28

lol


---

### 65. msg_27324

**You** - 2025-07-01T20:37:06

well I was thinking about getting tickets to his concert\.\.\. but hell no now\.\.


---

### 66. msg_27325

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:37:43

Too $$$$


---

### 67. msg_27326

**You** - 2025-07-01T20:38:25

pshh\.\. I have never spent anything on myself to do anything like that\.\. I dun care\.  worth\.\.\. well was worth 😝


---

### 68. msg_27327

**You** - 2025-07-01T20:38:43

I was looking at seats last night actually\.


---

### 69. msg_27328

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:39:38

Stop\. Stop\. Stop\.


---

### 70. msg_27329

**You** - 2025-07-01T20:39:48

Why?


---

### 71. msg_27330

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:40:25

Because we are going to be smart with our money bc things will be a little dicey for a while


---

### 72. msg_27331

**You** - 2025-07-01T20:45:35

ok :\(


---

### 73. msg_27332

**You** - 2025-07-01T20:45:59

was my birthday present to me \- and by extension you\.\.\.\.\.\.


---

### 74. msg_27333

**You** - 2025-07-01T20:46:11

kidding \- but it could have been\.\. and then you would have felt bad\.


---

### 75. msg_27334

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:46:57

Your bday is sept 11 right


---

### 76. msg_27335

**You** - 2025-07-01T20:47:19

ep


---

### 77. msg_27336

**You** - 2025-07-01T20:47:21

yep


---

### 78. msg_27337

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:48:53

We were both born on the 11th\. Interesting\. Wonder what that means


---

### 79. msg_27338

**You** - 2025-07-01T20:49:59

I already noted that\.\. but was not sure there was an implication\.


---

### 80. msg_27339

**You** - 2025-07-01T20:50:10

I was born at lunch time\.\. does that mean anything? :\)


---

### 81. msg_27340

**You** - 2025-07-01T20:50:50

>
the other idea i had was bringing maddie too\.\. her birthday is the 15th\.\. still wasn;t sure how I would manage that\.\. but would have worked on it\.


---

### 82. msg_27341

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:51:00

That’s a lovely little connection — sharing the same day of the month, even if your birthdays are in different months, can feel meaningful, especially when you’re emotionally close\. Here’s a gentle take on what it might suggest or symbolize:
🌗 Numerological Vibe – The Number 11
In numerology, 11 is considered a “master number”, associated with:
•	intuition
•	spiritual insight
•	emotional depth
•	a desire for meaningful connection
Two people who both have the 11 as a core part of their birthdate may:
•	feel a strong, often inexplicable emotional connection
•	mirror each other’s emotional intensity or internal worlds
•	share a quiet understanding or mutual respect for each other’s complexity
🌸 Symbolically
Same\-day birthdays \(different months\) can create a feeling of cosmic alignment or kinship\. It’s one of those things that makes people go, “Oh wow, that’s special\!” — and in relationships, those little sparks of synchronicity can feel like fate gently brushing your shoulders\.
💫 Astrolog\.\.\. \[truncated\]


---

### 83. msg_27342

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:51:14

>
Everything means something\.


---

### 84. msg_27343

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:51:54

>
Wait, like with me there?


---

### 85. msg_27344

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:52:02

That seems early


---

### 86. msg_27345

**You** - 2025-07-01T20:52:05

yeah I know


---

### 87. msg_27346

**You** - 2025-07-01T20:52:09

it was more notional


---

### 88. msg_27347

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:52:13

Sept isn’t that far away really


---

### 89. msg_27348

**You** - 2025-07-01T20:52:13

I really wanted to bring you


---

### 90. msg_27349

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:52:33

Does maddie like Morgan also?


---

### 91. msg_27350

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:52:51

The answer is probably: duh of course, who doesn’t


---

### 92. msg_27351

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:52:53

lol


---

### 93. msg_27352

**You** - 2025-07-01T20:53:12

no


---

### 94. msg_27353

**You** - 2025-07-01T20:53:25

her friend is into country\.\. I am not sure she is


---

### 95. msg_27354

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:54:43

Was just reading and got to this: Aries can be too blunt; Virgo too critical\.


---

### 96. msg_27355

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:54:46

LOL


---

### 97. msg_27356

**You** - 2025-07-01T20:55:14

sounds about right


---

### 98. msg_27357

**You** - 2025-07-01T20:57:56

where are the best seats for these kinds of concerts?


---

### 99. msg_27358

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:58:41

Depends\. Roger’s centre and scotiabank very different


---

### 100. msg_27359

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:58:58

Scotiabank you are almost good anywhere bc it is smaller


---

### 101. msg_27360

**You** - 2025-07-01T20:59:09

he is playing rogers


---

### 102. msg_27361

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:59:15

Rogers \- apparently in the 500s you can’t even hear sometimes


---

### 103. msg_27362

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:59:34

When we were at Jonas bros ppl in 500s couldn’t hear


---

### 104. msg_27363

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:59:41

They were tweeting it


---

### 105. msg_27364

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T20:59:57

Rogers is so massive the acoustics get lost


---

### 106. msg_27365

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:00:56

What are you looking on?


---

### 107. msg_27366

**You** - 2025-07-01T21:01:41

stubhub


---

### 108. msg_27367

**You** - 2025-07-01T21:05:24

I tried looking for other locations\.\. next nearest is an 8 hour drive to Mass\.\. in last weekend of August\.\. so nope\.\.


---

### 109. msg_27368

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:05:59

It won’t be the only time to see him


---

### 110. msg_27369

**You** - 2025-07-01T21:06:05

Also Jelly Roll


---

### 111. msg_27370

**You** - 2025-07-01T21:06:34

Montreal Aug 15\-16  still not do able\.\. boo\.\. stopping looking\.


---

### 112. msg_27371

**You** - 2025-07-01T21:07:03

>
I think that is girls weekedn anyways


---

### 113. msg_27372

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:07:17

Aug 8 is I believe


---

### 114. msg_27373

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:08:06

Kim Mandy and I planning now actually lol


---

### 115. msg_27374

**You** - 2025-07-01T21:08:09

Ah well was a fun idea for a bit\.


---

### 116. msg_27375

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:08:48

Reaction: ❤️ from Scott Hicks
I think I might do towels like this

*1 attachment(s)*


---

### 117. msg_27376

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:09:27

Do you think you would be able to come back to the cottage at some point relatively soon if I figured it out


---

### 118. msg_27377

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:09:45

I say relatively because… well Yunno lol


---

### 119. msg_27378

**You** - 2025-07-01T21:11:39

Depends on what soon is


---

### 120. msg_27379

**You** - 2025-07-01T21:11:59

Before the 20th might be a challenge unless it was a weekday


---

### 121. msg_27380

**You** - 2025-07-01T21:13:28

>
Those are really cute


---

### 122. msg_27381

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:13:51

Mandy is doing some sort of goodie bag so that’s out for me I guess


---

### 123. msg_27382

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:14:07

>
20th of what


---

### 124. msg_27383

**You** - 2025-07-01T21:23:06

20th July


---

### 125. msg_27384

**You** - 2025-07-01T21:23:23

That’s when everyone should be gone


---

### 126. msg_27385

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:23:38

I didn’t mean that soon


---

### 127. msg_27386

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:23:43

That’s really soon lol


---

### 128. msg_27387

**You** - 2025-07-01T21:24:03

End of July or sometime in august


---

### 129. msg_27388

**You** - 2025-07-01T21:24:06

Should be doable


---

### 130. msg_27389

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:24:07

>
Everyone but maybe not Gracie?


---

### 131. msg_27390

**You** - 2025-07-01T21:24:17

Dunno


---

### 132. msg_27391

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:25:28

k, we will play it by ear 🙂


---

### 133. msg_27392

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:25:37

Are you going to bed soon?


---

### 134. msg_27393

**You** - 2025-07-01T21:28:50

mm sometime soon\.\. not super tired yet clothes still in laundry


---

### 135. msg_27394

**You** - 2025-07-01T21:28:54

you got kids back yet?


---

### 136. msg_27395

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:29:59

Not yet


---

### 137. msg_27396

**You** - 2025-07-01T21:30:01

oooh my


---

### 138. msg_27397

**You** - 2025-07-01T21:30:06

that will be spicy


---

### 139. msg_27398

**You** - 2025-07-01T21:30:15

I am sure they will be super happy


---

### 140. msg_27399

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:30:23

lol


---

### 141. msg_27400

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:30:37

They had to go to a Canada Day thing


---

### 142. msg_27401

**You** - 2025-07-01T21:30:57

ah well maybe they had a bit of fun


---

### 143. msg_27402

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:32:18


*1 attachment(s)*


---

### 144. msg_27403

**You** - 2025-07-01T21:33:31

little shadow


---

### 145. msg_27404

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:33:42

Yeah\. She’s worried for sure


---

### 146. msg_27405

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:34:03

Been listening to Mac who is excited ugh


---

### 147. msg_27406

**You** - 2025-07-01T21:35:43

yeah\.\. there was a bit of drama upstairs\.\. gracie asked me something about where I was thinking of living this year\.\. and I suggested an area that is near a couple of Maddie's friends, apparently Maddie gets everything\.\. Gracie gets nothing\.\. Jaimie kinda started in on me and I was like nope\.\. nope\.\. I have heard enough about Gracie\.\. if you want to call this something call it logical consequences\.


---

### 148. msg_27407

**You** - 2025-07-01T21:35:51

anyhow I didn't stick around to discuss


---

### 149. msg_27408

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:37:49

Oh boy… yeah there is still a ton of transition to get through\. After renting this place, it has kind of hit me like a ton of bricks how big it will be initially for Marlowe\. Not as self sufficient as the other 2 in getting around etc


---

### 150. msg_27409

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:38:15

But once her volleyball starts up I think she will be ok


---

### 151. msg_27410

**You** - 2025-07-01T21:38:15

yeah it always was going to be a bit more of a challenge for her\.


---

### 152. msg_27411

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:38:34

She’s obsessed with vball and has tons of it planned for summer and fall


---

### 153. msg_27412

**You** - 2025-07-01T21:38:33

well sure the busier she is the less she has to think about


---

### 154. msg_27413

**You** - 2025-07-01T21:38:49

I am trying to adopt the same approach\.\.   Maybe I should get back into sports\!\! lo


---

### 155. msg_27414

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:38:57

Reaction: 👍 from Scott Hicks
Yeah the vball should help her a lot


---

### 156. msg_27415

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:41:44

>
I thought you were going to arm wrestle lol


---

### 157. msg_27416

**You** - 2025-07-01T21:44:25

Well that’s only 2 nights a week


---

### 158. msg_27417

**You** - 2025-07-01T21:44:41

I need to find something where I can be busy on a regular basis\.


---

### 159. msg_27418

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:47:45

I told Marlowe she can have the big room when she is there and she goes: That room looks like the room a YouTuber had when I was younger that I wanted so badly lol


---

### 160. msg_27419

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:47:51

So that’s good I guess


---

### 161. msg_27420

**You** - 2025-07-01T21:51:08

Yep little things\.\. it will be fine eventually\.\. 6 years only


---

### 162. msg_27421

**You** - 2025-07-01T21:51:21

Reaction: 😂 from Meredith Lamb
It goes by fast it’s like a short prison sentence


---

### 163. msg_27422

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:51:36

>
Omg


---

### 164. msg_27423

**You** - 2025-07-01T21:51:39

And we get
Conjugal visits every once in awhile


---

### 165. msg_27424

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:52:04

lol you are feeling really good tonight eh? I can tell


---

### 166. msg_27425

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:52:05

Not


---

### 167. msg_27426

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:52:07

lol


---

### 168. msg_27427

**You** - 2025-07-01T21:54:36

Am I not feeling good?


---

### 169. msg_27428

**You** - 2025-07-01T21:54:52

No just my typical jaded self


---

### 170. msg_27429

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:55:27

You are just speaking kind of dark


---

### 171. msg_27430

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T21:55:38

Like I’m back to sucky reality dark


---

### 172. msg_27431

**You** - 2025-07-01T21:58:31

Well there is the sarcasm if course it kinda can sound dark\.


---

### 173. msg_27432

**You** - 2025-07-01T21:59:02

I dunno maybe it’s dark?? It feels different for sure\.


---

### 174. msg_27433

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:00:17

It will be better tomorrow\.


---

### 175. msg_27434

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:00:27

Getting back to the daily …\.


---

### 176. msg_27435

**You** - 2025-07-01T22:00:54

Mmm hmm perhaps\.


---

### 177. msg_27436

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:01:20

When it will suck is the weekend upcoming\.


---

### 178. msg_27437

**You** - 2025-07-01T22:01:53

All weekends suck when we aren’t together what is special about this one


---

### 179. msg_27438

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:02:25

This one is just going to happen very soon bc it is already tues


---

### 180. msg_27439

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:02:33

That’s all


---

### 181. msg_27440

**You** - 2025-07-01T22:04:04

Oh well yeah it is what it is… I mean honestly week is not much better tbh\.\. meh doesn’t matter just grind forward\.


---

### 182. msg_27441

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:04:39

Do you remember saying one night that you think I’m going to regret getting together with you?


---

### 183. msg_27442

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:04:47

Like you said it in a serious way


---

### 184. msg_27443

**You** - 2025-07-01T22:04:55

Yeah


---

### 185. msg_27444

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:05:02

You do remember?


---

### 186. msg_27445

**You** - 2025-07-01T22:05:05

Yes


---

### 187. msg_27446

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:05:11

I thought maybe you wouldn’t


---

### 188. msg_27447

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:05:26

You don’t still feel like that though


---

### 189. msg_27448

**You** - 2025-07-01T22:05:30

Nope i remember


---

### 190. msg_27449

**You** - 2025-07-01T22:07:08

It will depend on me I think\.\. partly why I am trying to get sorted no one needs an anchor you want a partner\.\. so I guess I  concerned about my ability to really kind of become more self
Sufficient etc as I mentioned earlier\.


---

### 191. msg_27450

**You** - 2025-07-01T22:08:06

I fell like the perfect person for you is someone who when you are apart needs like no maintenance but is there to have an awesome time when the time is available\.


---

### 192. msg_27451

**You** - 2025-07-01T22:08:31

I just know I am not that lol not even close


---

### 193. msg_27452

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:09:39

You do not need to change for me\. I’ve known you for a while now and know you don’t need to change


---

### 194. msg_27453

**You** - 2025-07-01T22:10:11

I need to change for me too Mer\.\.
But the regret thing was about more than me if you remember\.


---

### 195. msg_27454

**You** - 2025-07-01T22:11:11

It was about having the freedom to kind of go out have fun no consequences or ties more like your undergrad years I guess\.  I think we were watching bad moms maybe?


---

### 196. msg_27455

**You** - 2025-07-01T22:11:18

Or maybe it was night before


---

### 197. msg_27456

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:11:31

Sow oats kind of thing lol


---

### 198. msg_27457

**You** - 2025-07-01T22:12:23

Well I guess if you like that saying\.\. but I think the way I framed it is more how I felt


---

### 199. msg_27458

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:14:20

And my answer to that still stands


---

### 200. msg_27459

**You** - 2025-07-01T22:14:41

Yeah I know\.\. all your friends are married so it wouldn’t work anyways:


---

### 201. msg_27460

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:15:25

😜


---

### 202. msg_27461

**You** - 2025-07-01T22:16:55

I mean it is understandable\.


---

### 203. msg_27462

**You** - 2025-07-01T22:17:27

I think you mentioned something about a fork in the road or something maybe I was drunk\.\. I don’t think you completely discounted it right?


---

### 204. msg_27463

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:17:47

I definitely completely discounted it\!


---

### 205. msg_27464

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:18:10

Even if there was that fork in the road, I wouldn’t take that road


---

### 206. msg_27465

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:18:47

I mean, I have you but even if I didn’t I have 3 kids and a life


---

### 207. msg_27466

**You** - 2025-07-01T22:18:51

lol ok mer\.\.  no bad moms action for you\.


---

### 208. msg_27467

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:18:59

I’m not just going to do a complete 180


---

### 209. msg_27468

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:19:20

Marlowe would literally kill me


---

### 210. msg_27469

**You** - 2025-07-01T22:19:22

Anyhow who knows what you will regret or you won’t\.\. we will have to see


---

### 211. msg_27470

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:19:35

I won’t regret anything


---

### 212. msg_27471

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:19:42

I don’t have major regrets


---

### 213. msg_27472

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:19:51

Some but not too many


---

### 214. msg_27473

**You** - 2025-07-01T22:20:24

Well I do\.\. lol\. Anyhow we can stop talking about this\.\. not sure why you raise it anyways\.


---

### 215. msg_27474

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:20:50

I was just wondering if you remembered\. Only reason I raised it


---

### 216. msg_27475

**You** - 2025-07-01T22:22:24

Ah ok… I remember almost everything just not all of the grand rapids night


---

### 217. msg_27476

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:23:44

Oh right lol yes I remember that now


---

### 218. msg_27477

**You** - 2025-07-01T22:25:44

Ok well I am going to try to go to bed\.\.


---

### 219. msg_27478

**Meredith Lamb \(\+14169386001\)** - 2025-07-01T22:26:20

k I love you ❤️ sleep well xo


---

### 220. msg_27479

**You** - 2025-07-01T22:26:34

Love you too\.


---

### 221. msg_27480

**You** - 2025-07-02T04:28:41

Good morning love\.  I have to tell you this does in fact suck\.  On my bucket list is going to bed and waking up with only you for the rest of my life\.  This weekend I caught myself watching you sleep thinking of how lucky I was and how much I loved you and how much that continued be more than I thought was previously possible\.  I watched dream and rubbed your forehead\.\. wanting to wake you up just to talk to you but also wanting to let you sleep as long as I could because I know you needed it\.  I would try to tell you how much I loved you loud enough so that you heard it but not loud enough to wake you up\.  So overall take the positive from this message\.\. there is no one else, and there never will be because I have never felt like this… and as such, this situation does in fact suck a lot lol\.  I love you Mer\.\. I hope you and the kids had a nice reunion, that Andrew wasn’t a dick, and they you had a good sleep\.  ❤️❤️❤️❤️


---

### 222. msg_27481

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T07:12:01

Reaction: ❤️ from Scott Hicks
Just lying here in awe of that message and kind of have no words\. ❤️ I love you so much and reading stuff like this confirms a lot\. Agree, this sucks, it feels like so much time is being wasted and I don’t like that feeling\. I want to go to sleep and wake up with you too\. xoxo


---

### 223. msg_27482

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:39:22

Reaction: 🎉 from Scott Hicks
Ok \- keys obtained, place is officially mine\. 😬


---

### 224. msg_27483

**You** - 2025-07-02T11:40:47

Awesome\.\. you should be excited


---

### 225. msg_27484

**You** - 2025-07-02T11:40:51

I would be


---

### 226. msg_27485

**You** - 2025-07-02T11:40:52

lol


---

### 227. msg_27486

**You** - 2025-07-02T11:40:56

get me the fuck outta here


---

### 228. msg_27487

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:43:57

I am but I feel bad leaving my kids with Andrew 50% of the time\. I was asking ChatGPT how to ease my head about that\. I got home to a very messy place, laundry all over\. He just doesn’t know how or do anything\. I feel bad for the girls


---

### 229. msg_27488

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:44:13

I won’t be here to fix it


---

### 230. msg_27489

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:44:25

Having major anxiety about that


---

### 231. msg_27490

**You** - 2025-07-02T11:44:51

>
as I said you will be picking them up with garbage bags filled with dirty clothes\.


---

### 232. msg_27491

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:45:28

Reaction: 😢 from Scott Hicks
😢


---

### 233. msg_27492

**You** - 2025-07-02T11:46:16

I am sorry Mer\.\. you cannot fix everything for everyone\.


---

### 234. msg_27493

**You** - 2025-07-02T11:48:25

And it isn't your responsibility tbh\.\. you didn't cause this, Andrew did\.\. and not with one act\.


---

### 235. msg_27494

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:50:20

Yeah it will just take some time to adjust I think\.


---

### 236. msg_27495

**You** - 2025-07-02T11:50:34

It will\.\. but you need to take care of you as well\.


---

### 237. msg_27496

**You** - 2025-07-02T11:50:59

I know you are\.\. just don't let that go by the wayside because Andrew cannot get his act together\.


---

### 238. msg_27497

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:51:53

That’s an incredibly hard emotional place to be in, and it makes sense you’re feeling unsettled\. You’re trying to protect your kids and adjust to your own new life — it’s a lot to carry at once\. Here are a few ways to help your head \(and heart\) work through this:
⸻
1\. Accept that “Good Enough” Might Look Different
It’s painful to know your kids may not have the same standards of cleanliness or care at their dad’s\. But try to remind yourself that kids are surprisingly resilient\. A less\-than\-ideal environment doesn’t automatically mean harm — it just means different\. Your home can still anchor them in warmth, structure, and stability\.
⸻
2\. Focus on What You Can Control
You can’t micromanage his household, but you can:
•	Send the kids with clean clothes and maybe a backup bag\.
•	Teach them simple things — like how to notice when clothes need washing or how to speak up for their needs\.
•	Create open space for them to talk about how things feel, without putting them in the middle\.
⸻
3\. Trus\.\.\. \[truncated\]


---

### 239. msg_27498

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:52:00

I like the last sentence\.


---

### 240. msg_27499

**You** - 2025-07-02T11:54:36

yeah\.\. it is definitely scary\.\. I am feeling it too tbh\.\. a lot of uncertainty\.\. but more simplicity if Gracie actually acclimates to NB\.\. Even with this last sentence, with you, I think your routines and solitude is going to get overrun, because Andrew won't be able to do this, and will still want the kids to stay there, and I can see you getting drug in to rescue them either by cleaning the house, doing their laundry at the house, or any other number of things\.


---

### 241. msg_27500

**You** - 2025-07-02T11:54:49

I am not sure you will be able to create that separate but connected life\.


---

### 242. msg_27501

**You** - 2025-07-02T11:56:12

I think you are an amazing Mom\.\. and you will do what you have to for your kids\.\. you will sacrifice your time, your happiness and your sanity for them lol\.\. which while amazing is equally scary\.


---

### 243. msg_27502

**You** - 2025-07-02T11:56:32

There has to be repercussions in the parenting agreement if Andrew cannot hold up


---

### 244. msg_27503

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:56:37

He just never does what he says he will so it is concerning for the kids\.


---

### 245. msg_27504

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:57:00

Example\.

*1 attachment(s)*


---

### 246. msg_27505

**You** - 2025-07-02T11:57:10

again\.\. in the parenting agreement \- there needs to be something for self determination if he cannot keep a household that is functional\.


---

### 247. msg_27506

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:57:27

He promised to groom the dogs\. I reminded him 3x over the weekend


---

### 248. msg_27507

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:57:41

Mac said he waited until the last minute so had no time to find the clippers


---

### 249. msg_27508

**You** - 2025-07-02T11:57:52

yeah\.\. I kind of thought it might be like that


---

### 250. msg_27509

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:58:05

I don’t really care if he doesn’t do it but fucking tell me so I can make appts


---

### 251. msg_27510

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T11:58:22

Just never does what he says unless it is volleyball related lol


---

### 252. msg_27511

**You** - 2025-07-02T11:59:09

Well it cannot remain that way\.\. what did you say to me at dinner again??


---

### 253. msg_27512

**You** - 2025-07-02T11:59:14

I enable Jaimie\.


---

### 254. msg_27513

**You** - 2025-07-02T12:00:20

That is a word you should think about over the next little while\.\. you might find you are more like me\.\. enabling as an alternative to a fucking shit show\.  I am not saying you should do that long term\.\. I sure as hell am not\.\. and where i am providing support, it requires minimal time and effort\.


---

### 255. msg_27514

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:05:20

I know I enable BS all the time with all 4 of them\.


---

### 256. msg_27515

**You** - 2025-07-02T12:09:33

Yeah something about that will need to change a bit


---

### 257. msg_27516

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:11:53

Supposed to be why he changed jobs so we will see once he’s been in it a bit more\.


---

### 258. msg_27517

**You** - 2025-07-02T12:15:26

I mean the working from home should technically allow for that flexibility


---

### 259. msg_27518

**You** - 2025-07-02T12:15:50

But I mean his job is a lot more higher up than mine so hard for me to understand his accountabilities etc


---

### 260. msg_27519

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:17:35

🤷‍♀️ what he wanted\. But yeah regardless of the job he has, it will be a struggle\. He wants to do what HE wants to do and nothing beyond that\.


---

### 261. msg_27520

**You** - 2025-07-02T12:19:18

Well that isn’t how it works with kids\.\. I know what I am capable of because I have done it all at various points in time\.\. again he is just going to have to reassess his priorities\.


---

### 262. msg_27521

**You** - 2025-07-02T12:19:25

I will be doing same


---

### 263. msg_27522

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:20:44

Yeah


---

### 264. msg_27523

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:21:57

Evvvvvvverything\.

*1 attachment(s)*


---

### 265. msg_27524

**You** - 2025-07-02T12:22:25

lol I am sorry you sound like you are having a rough day a lot to think about maybe try not to think on it all at
Once pick a small thing think only about it then move on to next understanding you can only really set your boundaries and expectations with Andrew\.\. and then beyond that you need to decide what you are willing to sacrifice\.


---

### 266. msg_27525

**You** - 2025-07-02T12:23:18

Yeah j is same for me I push on everything\.  Today was pharmacy and eyeglasses for Gracie…\.


---

### 267. msg_27526

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:25:45

Everytime I book something he makes me reschedule\. Sometimes I have shad to reschedule 3x\! So frustrating\. I’m like book it yourself\. Geez


---

### 268. msg_27527

**You** - 2025-07-02T12:29:56

He seems pretty passive\.\. a lot of apologies\.


---

### 269. msg_27528

**You** - 2025-07-02T12:30:06

passive and disconnected perhaps/


---

### 270. msg_27529

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:38:32

He doesn’t normally apologize\. Not sure what is going on\.


---

### 271. msg_27530

**You** - 2025-07-02T12:38:50

Maybe he is not trying to antagonize you anymore\.\.


---

### 272. msg_27531

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:39:04

Why tho


---

### 273. msg_27532

**You** - 2025-07-02T12:40:42

He doesn't want a fight at the parental thing with the mediator?


---

### 274. msg_27533

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:41:20

No way that is the reason\. There is something else going on


---

### 275. msg_27534

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:41:24

I’m just not sure yet


---

### 276. msg_27535

**You** - 2025-07-02T12:41:27

he wants you back?


---

### 277. msg_27536

**You** - 2025-07-02T12:41:38

so he is going to be super nice?


---

### 278. msg_27537

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:41:43

lol no


---

### 279. msg_27538

**You** - 2025-07-02T12:42:12

unsure\.\. afraid I cannot help with this particular mystery\.


---

### 280. msg_27539

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:43:15

I will talk to him in person eventually and probably find out


---

### 281. msg_27540

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:43:29

Didn’t even see him last night and he was gone early this morning to work


---

### 282. msg_27541

**You** - 2025-07-02T12:44:03

I will be interested in how that conversation goes\.  He might know he is going to need your continued help around the house\.\. etc\.\.


---

### 283. msg_27542

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:44:47

Not sure\. Doubt that is it either


---

### 284. msg_27543

**You** - 2025-07-02T12:44:56

what does your gut tell you?


---

### 285. msg_27544

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:45:04

I think it is something more obvious


---

### 286. msg_27545

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:45:11

Or like explicit


---

### 287. msg_27546

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:45:16

Like maybe an ask or something


---

### 288. msg_27547

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:45:19

I dunno


---

### 289. msg_27548

**You** - 2025-07-02T12:45:47

mmm\.\. well my money is on more help around the house despite the fact that you won't be there and don't actually have an ownership stake in it\.


---

### 290. msg_27549

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:48:10

Well I just got an ask but it is small


---

### 291. msg_27550

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:48:29

He can’t take Marlowe to her beach tourn on Sunday


---

### 292. msg_27551

**You** - 2025-07-02T12:49:02

well perhaps that is all\.


---

### 293. msg_27552

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:59:49

He’s starting back at hockey tonight


---

### 294. msg_27553

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T12:59:55

On his regular team


---

### 295. msg_27554

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:00:09

He rejoined the “text” team \(mon/tues\)


---

### 296. msg_27555

**You** - 2025-07-02T13:00:11

ahhh


---

### 297. msg_27556

**You** - 2025-07-02T13:00:17

good timing\.


---

### 298. msg_27557

**You** - 2025-07-02T13:00:18

for sure


---

### 299. msg_27558

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:00:21

He left it because of the text and said he just rejoined it


---

### 300. msg_27559

**You** - 2025-07-02T13:01:07

well I am sure you have feelings about this\.\. I am guessing they are roiling\.\. and I am sorry if they are\.


---

### 301. msg_27560

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:01:20

Nah I’m fine\. Don’t care honestly


---

### 302. msg_27561

**You** - 2025-07-02T13:01:55

I was thinking more practically\.\. haven't gotten this living thing sorted\.\. do you think rejoining now is the best time when you cannot find the time to do the things that absolutely matter\.


---

### 303. msg_27562

**You** - 2025-07-02T13:02:21

I guess he needs a release\.\. if that is all he has\.\.


---

### 304. msg_27563

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:04:34

Oh\! He will never be practical


---

### 305. msg_27564

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:04:40

Reaction: 😢 from Scott Hicks
lol I have no hope for that


---

### 306. msg_27565

**You** - 2025-07-02T13:04:55

that will just weigh on you and add to your stress


---

### 307. msg_27566

**You** - 2025-07-02T13:05:13

kind of like how the Gracie situation will never seemingly get resolved for me\.


---

### 308. msg_27567

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:06:04

If he is out at hockey every Mon, tues and Wed night until 2am on his week with kids I will be pissed


---

### 309. msg_27568

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:06:15

I will have to talk about that at mediation


---

### 310. msg_27569

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:06:21

Mon 12\-2 :p


---

### 311. msg_27570

**You** - 2025-07-02T13:06:27

fun times


---

### 312. msg_27571

**You** - 2025-07-02T13:07:42

Reaction: 😮 from Meredith Lamb
Last day for benefits for Jaimie\.\. and Gracie won't leave the house to go get glasses\.\. huge fight ensued\.\. basically pissing away $300 if she doesn't go\.\. so stupid\.  That is my day\.\. and J wants to spend a few hours with me working on the basement\.\. so I am super excited\.


---

### 313. msg_27572

**You** - 2025-07-02T13:08:00

oh shit you are in a meeting sorry\.  will leave you alone\.


---

### 314. msg_27573

**You** - 2025-07-02T13:08:15

mentioned the data strategy thing to Daniel\.\. that and i want to see the AI scope of work\.


---

### 315. msg_27574

**You** - 2025-07-02T13:43:10

had an interesting meeting with Daniel\.\. :\)


---

### 316. msg_27575

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:46:29

Interesting how?


---

### 317. msg_27576

**You** - 2025-07-02T13:48:10

Just interesting


---

### 318. msg_27577

**You** - 2025-07-02T13:48:23

Different you might say\.\.


---

### 319. msg_27578

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T13:48:43

Huh?? So confused


---

### 320. msg_27579

**You** - 2025-07-02T13:48:54

I mean you know\.\. different\.  It's kind of obvious\.


---

### 321. msg_27580

**You** - 2025-07-02T13:49:37

This is unfair to you\.\. your mind is all reeling with everything going on so the joke is not landing :\(


---

### 322. msg_27581

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:06:13

I am so confused\. Honestly


---

### 323. msg_27582

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:06:18

Daniel j?


---

### 324. msg_27583

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:06:21

Different?


---

### 325. msg_27584

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:06:24

Huh?


---

### 326. msg_27585

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:06:31

Why are you confusing me?


---

### 327. msg_27586

**You** - 2025-07-02T14:07:32

LOL\.\. remember the weekend


---

### 328. msg_27587

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:07:53

Omg that went over my head


---

### 329. msg_27588

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:07:54

lol


---

### 330. msg_27589

**You** - 2025-07-02T14:07:55

I told you I was going to be more vague with you because you used the word different with me and then would never explain what that meant


---

### 331. msg_27590

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:07:56

Got it


---

### 332. msg_27591

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:08:06

🙄


---

### 333. msg_27592

**You** - 2025-07-02T14:08:06

kk


---

### 334. msg_27593

**You** - 2025-07-02T14:08:09

all is good now\.


---

### 335. msg_27594

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:08:20

Wow I was so confused


---

### 336. msg_27595

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:08:24

Good joke


---

### 337. msg_27596

**You** - 2025-07-02T14:08:28

:P


---

### 338. msg_27597

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:08:34

😐


---

### 339. msg_27598

**You** - 2025-07-02T14:08:42

😊


---

### 340. msg_27599

**You** - 2025-07-02T14:08:45

that is how I feel\.


---

### 341. msg_27600

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:08:55

lol


---

### 342. msg_27601

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:09:01

Reaction: ❤️ from Scott Hicks
I’m glad


---

### 343. msg_27602

**You** - 2025-07-02T14:09:49

>
fyi I love all of your faces \- the eyeroll, the disinterested, the flat\-line, the dismissive \- all of em\.\. love em all\!\!


---

### 344. msg_27603

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:11:34

>
I mean, for now you say that\. It will get added to your annoying list\. \#3


---

### 345. msg_27604

**You** - 2025-07-02T14:12:04

your face is not annoying Mer\!\!


---

### 346. msg_27605

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T14:42:34

Mm hmm


---

### 347. msg_27606

**You** - 2025-07-02T14:46:35

Stop being dumb\. I would never ever think that\. fack


---

### 348. msg_27607

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T15:21:57

😇


---

### 349. msg_27608

**You** - 2025-07-02T15:38:02

\.\.\.\.\. pls don't say that\.\. I love the way you look\.\.\. :/


---

### 350. msg_27609

**You** - 2025-07-02T15:46:08

>
thus the laying there staring at you comment from this morning\.\. the annoying list is dumb\.\. I am not doing that\.\. was meant as a joke anyways\.


---

### 351. msg_27610

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T15:57:07

I’m having Scott withdrawal knowing we are not hanging out tonight\. Feels weird\.


---

### 352. msg_27611

**You** - 2025-07-02T15:58:41

tonight, tomorrow night, etc for a while\.\. yeah I am feeling a bit lost too\.  It is not pleasant\.


---

### 353. msg_27612

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:01:27

Hmmm


---

### 354. msg_27613

**You** - 2025-07-02T16:04:54

>
what are you "hmm"ing about\.


---

### 355. msg_27614

**You** - 2025-07-02T16:06:45

oh want to chat at all\.\. I have focus time blocked for a workshop I am developing for tomorrow\.


---

### 356. msg_27615

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:09:07

Workshop?


---

### 357. msg_27616

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:09:22

Sure I’m just hanging out


---

### 358. msg_27617

**You** - 2025-07-02T16:09:22

training for PD\.


---

### 359. msg_27618

**You** - 2025-07-02T16:46:43

sorry I am not my usual chipper self\.\. I still love speaking to you and seeing you\.\. just kinda sorta not the same right\.\. hope your meeting goes well and that you have fun shopping tonight\.


---

### 360. msg_27619

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:52:55

Yeah same\. Weird day


---

### 361. msg_27620

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:53:04

Very different 😝


---

### 362. msg_27621

**You** - 2025-07-02T16:53:20

>
not good different\. to be clear


---

### 363. msg_27622

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:54:19

Correct


---

### 364. msg_27623

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:54:21

lol


---

### 365. msg_27624

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T16:57:52

Mentally taxing …\. Better?


---

### 366. msg_27625

**You** - 2025-07-02T16:58:08

>
you never responded to my question\.\.


---

### 367. msg_27626

**You** - 2025-07-02T16:58:25

Emotionally Taxing\.\.is more accurate for me\.


---

### 368. msg_27627

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T17:11:47

>
I was hmm’ing because it is just difficult to think about…\. No real solutions\. It’s getting tiring but I think I’m just tired still from the weekend\.


---

### 369. msg_27628

**You** - 2025-07-02T17:12:33

>
ah ok\.\. I will have to remember that hmmm\.\.\. noted\.


---

### 370. msg_27629

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T17:40:35

I think I might need to make you a dictionary for me\.


---

### 371. msg_27630

**You** - 2025-07-02T17:42:28

I don’t think that’s possible\.


---

### 372. msg_27631

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T17:45:08

You’re probably right\.


---

### 373. msg_27632

**You** - 2025-07-02T17:45:43

I am destined to forever muddle through life guessing at meanings behind grunts and vague statements\.\.\. rofl\.


---

### 374. msg_27633

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T17:58:30

Reaction: 🤮 from Scott Hicks
I just saw Ravi and a friend walking across the street\. She lives in my hood\. Totally forgot\.


---

### 375. msg_27634

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T17:58:58

Maybe good thing you weren’t with me lol


---

### 376. msg_27635

**You** - 2025-07-02T17:59:07

for multiple reasons\.


---

### 377. msg_27636

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T17:59:29

lol


---

### 378. msg_27637

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T18:32:19

So he came home and is going shopping tomorrow instead\. Anyway, I think he was being nice because he was worried I was going to push hard and move out fully this weekend\. I was like no, I told Marlowe it will be gradual because I don’t want to stress her out\. He seemed very happy with that\. So I think that is why I was getting apologies\.


---

### 379. msg_27638

**You** - 2025-07-02T18:56:55

I mean whatever decreases stress in the house must be a good thing\.


---

### 380. msg_27639

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:00:25

I’m just worried about my kids, not him\. But I understand the niceness now\. I think he’s just concerned about kids ultimately also bc when I’m gone he has to step it up\.


---

### 381. msg_27640

**You** - 2025-07-02T19:02:47

I am just glad it was something as simple and straightforward as that\.  You don't need any more stress or shit to argue about\.


---

### 382. msg_27641

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:03:43

Edited: 2 versions
| Version: 2
| Sent: Wed, 2 Jul 2025 19:03:50 \-0400
|
| Agree\. Bit of a relief\.
|
| Version: 1
| Sent: Wed, 2 Jul 2025 19:03:43 \-0400
|
| Agree\. But of a relief\.


---

### 383. msg_27642

**You** - 2025-07-02T19:04:12

well now you can go shopping\.\. and drink wine\.\. there is that at least


---

### 384. msg_27643

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:04:52

I don’t feel like shopping :\( ugh… watching a doc lol and having a glass 🙃


---

### 385. msg_27644

**You** - 2025-07-02T19:05:40

kk have fun with that\.\. still finishing ppt then packing\.


---

### 386. msg_27645

**You** - 2025-07-02T19:05:44

FML


---

### 387. msg_27646

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:05:58

🫩


---

### 388. msg_27647

**You** - 2025-07-02T19:06:13

you know that emoticon looks like a piece of paper\.\. no clue what it is


---

### 389. msg_27648

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:06:28

A piece of paper?


---

### 390. msg_27649

**You** - 2025-07-02T19:06:35

the image doesn't come out right forme


---

### 391. msg_27650

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:06:55

It is an unamused, worn down face


---

### 392. msg_27651

**You** - 2025-07-02T19:07:01

well that is me\.\.


---

### 393. msg_27652

**You** - 2025-07-02T19:07:04

accurate


---

### 394. msg_27653

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:07:22

That’s why I sent it :\)


---

### 395. msg_27654

**You** - 2025-07-02T19:07:59

still true


---

### 396. msg_27655

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:26:59

😢


---

### 397. msg_27656

**You** - 2025-07-02T19:30:35

Don't give me the sad crying face\.\. Just go have 🍷 and watch your 📺, you don't need to be sad for me\.\. my situation is what is, so is ours\.\. filled with absolutely amazing and awesome ups\.\. that give me hope for the future\.\. and the fucking holes in between\.\. that's life for now\.\. I am not being dark\.\. that is reality right?  But yeah you were wondering if it would be better lol\.\. I just want you worse\.\.\. there is your answer\.\. lol better and worse at the same time\!\!\! who'd a thunk\.


---

### 398. msg_27657

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:40:41

Yeah, same\. I believe the long weekend together made things harder for me\. I guess it is worth it but …\. definitely more difficult\. It is also just driving my brain nuts that my family doesn’t know\. Honestly, if it weren’t for Mac I probably would have exploded by now and said something at some impulsive time\.


---

### 399. msg_27658

**You** - 2025-07-02T19:42:37

I don't understand the desire to tell people\.\. I have no interest in that until the timing is much more favorable for everyone\.  Otherwise it just create chaos\.\. makes the situation worse all around\.


---

### 400. msg_27659

**You** - 2025-07-02T19:43:37

I mean yeah it is definitely worth it\.\. because if I thought we were just not going to see each other again, based on the fact that it makes things more challenging\.\.\. I would literally curl up in a ball right now\.\. and say wake me the fuck up in September\.


---

### 401. msg_27660

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:45:29

>
I’m not sure\. I guess I don’t like the feeling of living a double life\.


---

### 402. msg_27661

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:47:20

>
I know\. I just am feeling withdrawal\. lol it will be “fine” in a day or two\.


---

### 403. msg_27662

**You** - 2025-07-02T19:50:44

>
I am not sure how it will be for me\.\. it has never been "fine" it has just been easier to suppress\.\. but the feeling is still really shitty to live with\.


---

### 404. msg_27663

**You** - 2025-07-02T19:51:30

>
I know\.\. that is something that bothers you\.\. I wish we didn't have to do things this way\.


---

### 405. msg_27664

**You** - 2025-07-02T19:52:57

Let's park this conversation maybe? \- I can put my shit in a box\.\. won't mention it\.\. you can go enjoy your show and the rest of your night\.


---

### 406. msg_27665

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T19:59:07

k… going to go to bed early also


---

### 407. msg_27666

**You** - 2025-07-02T20:03:33

>
sorry not trying to be abrupt or bossy\.\. but we have been here before\.\. this discussion doesn't lead anywhere except making both of us feel like shit for various reasons\.\. just didn't want you to have a bad night\.


---

### 408. msg_27667

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T20:09:06

Yeah right, you’re just trying to get rid of me\. That’s fine, go off and have your special packing time\. :p


---

### 409. msg_27668

**You** - 2025-07-02T20:09:15

there is no packing tonight


---

### 410. msg_27669

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T20:09:19

\(That was not serious\.\)


---

### 411. msg_27670

**You** - 2025-07-02T20:09:19

she didn't want to


---

### 412. msg_27671

**You** - 2025-07-02T20:09:30

I am just working\.


---

### 413. msg_27672

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T20:09:37

Ew


---

### 414. msg_27673

**You** - 2025-07-02T22:08:33

Alright mer not sure whether you are still awake or not but I am going to bed\.


---

### 415. msg_27674

**You** - 2025-07-02T22:16:13

Edited: 3 versions
| Version: 3
| Sent: Wed, 2 Jul 2025 22:17:33 \-0400
|
| Well as expected was a rough day\.\. but you must be out already\.\.
| So hope you had a good night yourself at least\. Cya tomorrow xo\.
|
| Version: 2
| Sent: Wed, 2 Jul 2025 22:17:17 \-0400
|
| Well as expected was a rough day\.\. but you just be out already\.\.
| So hope you had a good night yourself at least\. Cya tomorrow xo\.
|
| Version: 1
| Sent: Wed, 2 Jul 2025 22:16:13 \-0400
|
| Alright well you must be out already\.\. night\. Xo


---

### 416. msg_27675

**Meredith Lamb \(\+14169386001\)** - 2025-07-02T22:18:54

Gnite ❤️❤️ love you


---

### 417. msg_27676

**You** - 2025-07-02T22:20:50

Love you too…\. ❤️


---

### 418. msg_27677

**You** - 2025-07-03T04:13:52

Well awake\.\. not happy, not looking forward to today\.  It’s a self doubt kinda day, and I sure don’t want to go to work\. Still have all the feelings from yesterday morning and the weekend though lol that’ll never change I suspect\.  Anyhow love you Mer hope you had a good sleep and a good morning\. Will see you at work I am sure\.


---

### 419. msg_27678

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T07:12:54

Yeah same\. I’m in a weird place mentally and didn’t sleep well\. Boo\. Trrrrrying to get up\. :p do not want to go to work either\. Gahh
Hope you had a good workout xo


---

### 420. msg_27679

**You** - 2025-07-03T09:59:19

Sorry not chatty today in a bad mood\.😒


---

### 421. msg_27680

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T10:06:55

Yeah same…\. no worries\. Sigh


---

### 422. msg_27681

**You** - 2025-07-03T10:56:55

Just want to go home and go to sleep I have no desire to do any of this shit today\.  I might leave early I have to come in tomorrow anyways\.


---

### 423. msg_27682

**You** - 2025-07-03T10:57:46

This is going to be bad… 🙁\.  lol


---

### 424. msg_27683

**You** - 2025-07-03T11:00:10

That was one of your sad lol’s btw not a real one\.


---

### 425. msg_27684

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T11:07:20

I feel like I’m bi\-polar now\. \(sad lol\)


---

### 426. msg_27685

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:14:08

Ps\. Pauline messed up the midstream reporting in March and never mentioned to me anything about it so…\.\. ughhhh


---

### 427. msg_27686

**You** - 2025-07-03T12:14:33

>
Yeah this isn’t good\.  I am not sure how to deal\.


---

### 428. msg_27687

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:14:45

So who figures it out? Musarrat? Me? Pauline? What a shit show


---

### 429. msg_27688

**You** - 2025-07-03T12:14:55

Pauline


---

### 430. msg_27689

**You** - 2025-07-03T12:14:59

If she did it she fixes it


---

### 431. msg_27690

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:15:26

“I remember a conversation where I was told that I was not a good fit for this work\.”


---

### 432. msg_27691

**You** - 2025-07-03T12:15:30

She can work with mus to do that but she needs to fix her own stuff


---

### 433. msg_27692

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:15:36

Case in point Pauline\.


---

### 434. msg_27693

**You** - 2025-07-03T12:15:43

……\.


---

### 435. msg_27694

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:15:50

She messed up April too but not as material\.


---

### 436. msg_27695

**You** - 2025-07-03T12:16:35

I mean I was going to ask
Messed up how but honestly I don’t care\.\. she just needs to fix it\. If you need me to tell her I will\.


---

### 437. msg_27696

**You** - 2025-07-03T12:18:16

Honestly how can this be this fucking bad\.\. fuck stuck here till 330


---

### 438. msg_27697

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:18:27

She didn’t reconcile the numbers to the invoice properly so the numbers coded to large/small are incorrect


---

### 439. msg_27698

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:18:37

Not sure of the impact really


---

### 440. msg_27699

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:18:44

I honestly don’t care lol


---

### 441. msg_27700

**You** - 2025-07-03T12:18:58

So do I need to tell her…… just let me know\.


---

### 442. msg_27701

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:19:10

Let me talk to mus


---

### 443. msg_27702

**You** - 2025-07-03T12:19:28

K


---

### 444. msg_27703

**You** - 2025-07-03T12:23:01

I already warned her you might reach out\.  Really should pave the way for an easier request


---

### 445. msg_27704

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T12:58:15

😵‍💫 she doesn’t like me so Musarrat might reach out lol


---

### 446. msg_27705

**You** - 2025-07-03T12:58:43

K


---

### 447. msg_27706

**You** - 2025-07-03T13:03:14

Shouldn’t be your problem anyways\.\. let mus push her and I will intervene if I must\.  Just don’t worry about it you should be done with your old job now regardless\.


---

### 448. msg_27707

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T13:44:44

Some things never change\. A year ago…

*1 attachment(s)*


---

### 449. msg_27708

**You** - 2025-07-03T13:46:59

lol kids…


---

### 450. msg_27709

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T13:57:34

2\.20am god…


---

### 451. msg_27710

**You** - 2025-07-03T13:58:36

Harmless I wish I was them instead of me\.


---

### 452. msg_27711

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T14:19:36

Musarrat didn’t want to contact Pauline so I did… we will see what happens\. Will go to you if Pauline doesn’t respond\.


---

### 453. msg_27712

**You** - 2025-07-03T14:33:30

I don’t understand this at all… I should have just done it if mus wouldn’t\.\. again you shouldn’t have to be involved anymore\.  Thanks for doing it though and for the heads up\.


---

### 454. msg_27713

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T14:34:12

Musarrat isn’t comfortable enough with the reporting yet\. It is a really annoying reporting process\.


---

### 455. msg_27714

**You** - 2025-07-03T14:35:51

I am going to fix it it sounds stupid\.  We shouldn’t be doing it it is what we pay CR for\.


---

### 456. msg_27715

**You** - 2025-07-03T14:36:11

I should engage today\.\. that would be a good experience for Matthew\.


---

### 457. msg_27716

**You** - 2025-07-03T15:30:26

And fucking done meetings for the day to go or not to go…\. Blech


---

### 458. msg_27717

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T15:40:01

Well you lucked out on PO4


---

### 459. msg_27718

**You** - 2025-07-03T15:40:26

Not really


---

### 460. msg_27719

**You** - 2025-07-03T15:40:31

Octavian


---

### 461. msg_27720

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T15:40:57

But I mean you relative to Craig


---

### 462. msg_27721

**You** - 2025-07-03T15:41:13

Yeah they took a complex route\.


---

### 463. msg_27722

**You** - 2025-07-03T15:41:29

Whatever I will be happy to be left alone\.


---

### 464. msg_27723

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T16:18:33

I’m heading out\. Marlowe had given me instructions on things to pick up on way home\.
Love you\. Great day\. 🙃❤️🫤


---

### 465. msg_27724

**You** - 2025-07-03T16:21:40

Sorry will not be returning the enthusiasm but love you and have a good night\.


---

### 466. msg_27725

**You** - 2025-07-03T17:39:28



---

### 467. msg_27726

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T17:44:19

🤔


---

### 468. msg_27727

**You** - 2025-07-03T17:52:50

Botched apology\.\. ignore


---

### 469. msg_27728

**You** - 2025-07-03T18:20:38



---

### 470. msg_27729

**You** - 2025-07-03T18:20:49

omg ffs


---

### 471. msg_27730

**You** - 2025-07-03T18:22:13

attempt 3:  Sorry this took long to get back to, have been fighting with Jaimie for last 30 mins\.\. super fun\.  Basically I thought limiting communication would make it easier\.\. but you know it made it worse\.  When I talk to you I can't stop thinking about you, and that causes its own pain and frustration\.\. but not talking to you at all is way worse 😥


---

### 472. msg_27731

**You** - 2025-07-03T18:24:07

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 18:51:29 \-0400
|
| I wanted to ask how your night was last night, how much wine you ended up having, as you were going to go to bed early lol, if you and Andrew had any parental planning discussions and how those went wanted to know about your day\.\. but yeah\.\. moron\.  I mean I was back to back all day, just annoying\.\. maybe it will level out to just general disappointment like it was before last Thursday\. Here’s hoping\.
|
| Version: 1
| Sent: Thu, 3 Jul 2025 18:24:07 \-0400
|
| I wanted to ask how your night was last night, how much wine you ended up having, as you were going to go to bed early lol, wanted to know about your day\.\. but yeah\.\. moron\.  I mean I was back to back all day, just annoying\.\. maybe it will level out to just general disappointment like it was before last Thursday\.


---

### 473. msg_27732

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:19:36

Just getting this\. Had a nap……\. So tired\. Ugh


---

### 474. msg_27733

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:19:56

You do not need to apologize to me\. Geez


---

### 475. msg_27734

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:21:07

I am not feeling like myself and not particularly chatty either


---

### 476. msg_27735

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:21:20

I knew you had a busy day also


---

### 477. msg_27736

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:21:23

Etc etc


---

### 478. msg_27737

**You** - 2025-07-03T20:21:50

I just felt really disconnected and I didn’t like it and I felt like I caused it\.


---

### 479. msg_27738

**You** - 2025-07-03T20:22:27

It’s fine doesn’t matter like I said hoping this will just level out


---

### 480. msg_27739

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:24:44

Yeah felt / feeling that way also\. Also don’t like it\. 🙁


---

### 481. msg_27740

**You** - 2025-07-03T20:26:22

How do we make this work Mer any thoughts?


---

### 482. msg_27741

**You** - 2025-07-03T20:26:53

I don’t have any more ideas tbh\.  Except wait


---

### 483. msg_27742

**You** - 2025-07-03T20:27:40

I am also worried you won’t be able to deal with the stress of all this\.


---

### 484. msg_27743

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:29:40

Wrt to your question: i am not sure… waiting seems to be the only thing right now\.


---

### 485. msg_27744

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:30:40

I am finding the swing between the weekend and the back to reality quite a large shift this time for sure\.


---

### 486. msg_27745

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:30:58

It is honestly a little like taking e …\. lol


---

### 487. msg_27746

**You** - 2025-07-03T20:31:17

Sorry typo at end?


---

### 488. msg_27747

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:31:25

Maybe I just need to eat more potassium 🍌


---

### 489. msg_27748

**You** - 2025-07-03T20:31:30

Oh


---

### 490. msg_27749

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:31:31

Not a typo


---

### 491. msg_27750

**You** - 2025-07-03T20:31:31

Nm


---

### 492. msg_27751

**You** - 2025-07-03T20:34:16

I mean the upside is we are compatible I think in a lot of different ways and for the future that bodes well\.\. I have to tell you though I am worried you might change direction\.\. you have so much responsibility so much you are worried about\.  Honestly I thought about it a lot on the weekend\.\. just concerned\.  In addition to me feeling you would want your freedom this the other part to me suggesting you would regret being with me\.


---

### 493. msg_27752

**You** - 2025-07-03T20:35:07

I don’t know I keep thinking the longer this goes the closer this gets to something it will get easier but I am less sure\.\. maybe I am messing with my own head


---

### 494. msg_27753

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:38:10

You are definitely messing with your head\. But I’ve been having weird thoughts too\. So many thoughts in my head since getting my new place, discussions about that here, etc etc then just with work today and since the weekend and everything\. It’s just all so weird feeling\.
I have not thought about changing direction at all but my head is certainly wondering if the direction we are on is even sustainable but I really hope it is\. All I can do


---

### 495. msg_27754

**You** - 2025-07-03T20:38:49

😢


---

### 496. msg_27755

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:40:43

My head has never even once considered taking a pause until today\. But I don’t want to but shit it was /is difficult in a way that is really hard to explain


---

### 497. msg_27756

**You** - 2025-07-03T20:44:06

>
Honestly last thing I wanted to hear not sure how to respond\.


---

### 498. msg_27757

**You** - 2025-07-03T20:45:12

Appreciate the honesty though\.\. still feels like I am about to be dropped lol pretty awful feeling\.\. but if that is what you need to do I would understand\.


---

### 499. msg_27758

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:45:27

Not even close


---

### 500. msg_27759

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:45:44

Just struggling


---

### 501. msg_27760

**You** - 2025-07-03T20:47:00

I never thought this kind of love would cause this kind of pain\. Honestly\.


---

### 502. msg_27761

**You** - 2025-07-03T20:47:12

Not your fault\.\. just this situation


---

### 503. msg_27762

**You** - 2025-07-03T20:47:37

Anyhow I do t want to bug you about it we don’t need to discuss it\.


---

### 504. msg_27763

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:14

I really just don’t understand it but I think it has to do with the secrecy everywhere\. Work, home… I mean it helps that Jim and my extended family and friends I can be open and honest with for sure\. Helps a lot but it feels so challenging elsewhere\. Once I get our agreement signed, perhaps I will feel like I have a bit more freedom/flexibility to make my own decision about telling Andrew/kids but I feel very strapped atm\. And it also causes me to feel pretty limited about where we can actually spend time together in future


---

### 505. msg_27764

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:25

Learned of Andrew’s Reno plan after work


---

### 506. msg_27765

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:27

Omg


---

### 507. msg_27766

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:36

He and girls to move into basement in August


---

### 508. msg_27767

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:51

And no access to upper two floors for 8 months


---

### 509. msg_27768

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:56

I got mad at him


---

### 510. msg_27769

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:52:58

Like wtf


---

### 511. msg_27770

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:53:04

The girls will be miserable


---

### 512. msg_27771

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:53:11

They will have to be with me


---

### 513. msg_27772

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:53:30

There isn’t even a proper kitchen down there\. It is tiny


---

### 514. msg_27773

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:53:50

So I have a feeling I may have kids or partial kids full time


---

### 515. msg_27774

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:54:19

He’s a moron and thinks people can live in squalor conditions


---

### 516. msg_27775

**You** - 2025-07-03T20:54:22

I figured that would be the case when you said it the other night


---

### 517. msg_27776

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:54:24

And stay mentally sane


---

### 518. msg_27777

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:54:50

The original plan was to live in basement but have access to upper kitchen and living room


---

### 519. msg_27778

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:54:53

Not anymore


---

### 520. msg_27779

**You** - 2025-07-03T20:54:58

I also know what that means for you and for us\.\. it is what it is


---

### 521. msg_27780

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:56:03

Yeah and then I booked time off to go to cottage bc I am babysitting Bo\. But of course girls want to come with me even tho Marlowe has vball\. She wants to skip vball


---

### 522. msg_27781

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:56:05

All good


---

### 523. msg_27782

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:56:08

I don’t mind


---

### 524. msg_27783

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:56:14

But just another thing


---

### 525. msg_27784

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:56:17

Yunno


---

### 526. msg_27785

**You** - 2025-07-03T20:56:58

I already told you though I don’t plan on walking away from you or this for any reason\. So unless you have other ideas\.\. we’ll just have to figure it out as best we can until there is enough flexibility to be more normal\.


---

### 527. msg_27786

**You** - 2025-07-03T20:57:30

>
Was this why you asked me about the cottage?


---

### 528. msg_27787

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:57:38

No


---

### 529. msg_27788

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:57:43

I just booked it today


---

### 530. msg_27789

**You** - 2025-07-03T20:57:50

Ah ok


---

### 531. msg_27790

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:58:08

Before the PO tho lol


---

### 532. msg_27791

**You** - 2025-07-03T20:58:37

When did you book


---

### 533. msg_27792

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:59:13

Week of tech conf\. That is the second week I have bo\. Can’t the week before bc Andrew in Montreal for work


---

### 534. msg_27793

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:59:27

I didn’t book off Wed and Fri\. Just office days


---

### 535. msg_27794

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T20:59:58

>
You don’t plan on walking away but you can’t talk to me either\. Lol 🧐


---

### 536. msg_27795

**You** - 2025-07-03T21:00:31

I can


---

### 537. msg_27796

**You** - 2025-07-03T21:00:40

I will figure it out\.


---

### 538. msg_27797

**You** - 2025-07-03T21:01:10

You have to understand just like I understand your situation


---

### 539. msg_27798

**You** - 2025-07-03T21:02:10

When they leave I will be alone\.\. it will be a bit tough\.\. dealing with everything in my head that last week of July\.\. then most of august likely alone\.\. so i will try my best


---

### 540. msg_27799

**You** - 2025-07-03T21:07:11

I guess the issue you have is you are actually looking at a few months where we don't see each other right\.


---

### 541. msg_27800

**You** - 2025-07-03T21:07:18

is that the problem you are having


---

### 542. msg_27801

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:08:07

I honestly can’t see when we see each other next… isn’t the full issue but it is an issue for sure


---

### 543. msg_27802

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:08:18

Like literally don’t see it


---

### 544. msg_27803

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:08:28

And if work sucks as bad as it did today


---

### 545. msg_27804

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:08:32

On top of that


---

### 546. msg_27805

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:08:53

I mean maybe if you ever move offices it changes somewhat… unlikely


---

### 547. msg_27806

**You** - 2025-07-03T21:09:14

I am going into the office tomorrow\.\. to fill my boxes\.\. I will be in new office Monday\.


---

### 548. msg_27807

**You** - 2025-07-03T21:09:52

I mean I thought it would be easier when you had a place, and signed the agreement\.\. but I guess now that won't be the case\.\. I guess that changes things for you\.


---

### 549. msg_27808

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:10:45

It doesn’t “change things”


---

### 550. msg_27809

**You** - 2025-07-03T21:11:52

I am not sure even you believe that\.\. lol


---

### 551. msg_27810

**You** - 2025-07-03T21:13:14

anyhow like I said\.\. not going anywhere\.\. never found this before, I couldn't leave if I wanted to\.\. and if I ever did I would be the biggest fool ever\.  Again like I said at the beginning of this\.\. I got a sense that this became "different" for you in past few days\.  thus the "changed things"


---

### 552. msg_27811

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:15:10

It is just a strange way to live and is wearing I think\. Nothing has changed per se…\. Just time is passing


---

### 553. msg_27812

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:15:18

I’m not leaving or going anywhere


---

### 554. msg_27813

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:15:38

But that doesn’t make the situation “easier”


---

### 555. msg_27814

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:15:51

If anything that realization makes it more difficult


---

### 556. msg_27815

**You** - 2025-07-03T21:16:47

Well\.\. I mean I was hoping for some kind of once a week or once every couple of weeks\.\. but hey will have to try to work with once every couple of months for a while I guess\.


---

### 557. msg_27816

**You** - 2025-07-03T21:17:33

See I told you the universe wanted to fucking destroy me\.\. lol


---

### 558. msg_27817

**You** - 2025-07-03T21:19:36

It's fine\.\. will get a life\.\. and see what that does for me, maybe it makes the waiting easier\.  With this new revelation I don't think I have a choice at this point\.


---

### 559. msg_27818

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:20:31

I honestly don’t think the universe is against you


---

### 560. msg_27819

**You** - 2025-07-03T21:22:25

I don't see how you think it is not\.\. everything in my life was literally going to shit\.\. then I found you, literally my one person\.\. and then tells me sorry can't have her\.  Like it definitely wants me to just break into pieces lol\.\. like you were suggesting a while back hehe\.


---

### 561. msg_27820

**You** - 2025-07-03T21:25:23

I also think Jim thinks this is a huge mistake too\.\. like I feel like we might be the only ones that want this to work\.\. and nothing is lining up to make it any easier\.\. everything is a fight\.\. and when we win\.\. god is it worth it\.\. but holy fuck\.\.\.\.\.\.\. gah maybe we should stop talking about it\.\. I am sure this isn't making you feel better\. And we have a long fucking time between now and whenever\.\. we definintely cannot keep talking like this\.


---

### 562. msg_27821

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:25:53

>
I was suggesting???


---

### 563. msg_27822

**You** - 2025-07-03T21:26:20

you said you felt like i was going to fall apart in front of yo


---

### 564. msg_27823

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:26:22

>
I don’t think Jim thinks that\.


---

### 565. msg_27824

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:26:37

Oh like a long time ago?


---

### 566. msg_27825

**You** - 2025-07-03T21:26:39

>
I don't believe you\.\. lol\.\.


---

### 567. msg_27826

**You** - 2025-07-03T21:26:45

>
yeah a while back


---

### 568. msg_27827

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:26:46

Why?


---

### 569. msg_27828

**You** - 2025-07-03T21:27:04

because you wouldn't tell me if he did, because you know it would hurt me\.\. he already doesn't talk to me at all anymore\./


---

### 570. msg_27829

**You** - 2025-07-03T21:27:12

literally not at all


---

### 571. msg_27830

**You** - 2025-07-03T21:27:16

since we told him


---

### 572. msg_27831

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:27:55

Well that is interesting but there must be some other reason behind it because I don’t think he thinks that


---

### 573. msg_27832

**You** - 2025-07-03T21:27:55

I guess I feel pretty isolated no matter where I am at anymore\.\. here, work\.\. anywhere really\.


---

### 574. msg_27833

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:28:30

And if Jim did think that and I was aware, I would tell you


---

### 575. msg_27834

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:28:45

He might just find the whole thing awkward?


---

### 576. msg_27835

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:28:48

No idea


---

### 577. msg_27836

**You** - 2025-07-03T21:28:54

anyway, we should agree to try to put this discussion to bed tonight\.\. if I just have to fake it I will for as long as I have to\.


---

### 578. msg_27837

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:29:02

Maybe we put him in an awkward position


---

### 579. msg_27838

**You** - 2025-07-03T21:29:16

>
doesn't seem to stop him from talking to you\.


---

### 580. msg_27839

**You** - 2025-07-03T21:29:20

just saying


---

### 581. msg_27840

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:29:42

I feel like we talked more to begin with tho


---

### 582. msg_27841

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:29:55

Just saying


---

### 583. msg_27842

**You** - 2025-07-03T21:30:17

no\.\. before you came on Jim and I talked all the time\. like ALL the time\.\. even a lot after I took the Manager role\.  But after we told him\.\. it went to zero\.


---

### 584. msg_27843

**You** - 2025-07-03T21:30:36

its fine it doesn't matter\.


---

### 585. msg_27844

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:30:39

Hmmh


---

### 586. msg_27845

**You** - 2025-07-03T21:30:58

it really doesn't nothing really matters\.\. everything just is\.\. and there is nothing I can do\.


---

### 587. msg_27846

**You** - 2025-07-03T21:31:07

not something I am used to to be honest


---

### 588. msg_27847

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:31:23

What aren’t you used to?


---

### 589. msg_27848

**You** - 2025-07-03T21:31:50

Not being able to do anything to improve my situation\.  I can always do something, solve a problem figure something out\.  There is literally nothing I can do here\.\. I have no control\.


---

### 590. msg_27849

**You** - 2025-07-03T21:32:49

again I will figure something out\.\. a combination of faking it, distracting myself, continuing to work out insane amounts\.\. and just hoping for an opportunity\.


---

### 591. msg_27850

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:34:28

I honestly don’t think this will ever be better until our families know the truth\.


---

### 592. msg_27851

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:34:37

And that just is what it is\.


---

### 593. msg_27852

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:34:41

Maybe not on your end


---

### 594. msg_27853

**You** - 2025-07-03T21:34:40

Jaimie already knows


---

### 595. msg_27854

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:34:49

But certainly on mine


---

### 596. msg_27855

**You** - 2025-07-03T21:34:53

like she knows knows


---

### 597. msg_27856

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:35:15

Knows knows?


---

### 598. msg_27857

**You** - 2025-07-03T21:35:15

that was part of what we fought about tonight


---

### 599. msg_27858

**You** - 2025-07-03T21:35:32

she knows suspects and has convinced herself about my trips the past few weeks\.


---

### 600. msg_27859

**You** - 2025-07-03T21:35:36

she knows I am seeing you\.


---

### 601. msg_27860

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:35:38

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 21:35:58 \-0400
|
| I don’t get why you get to have these discussions and I don’t
|
| Version: 1
| Sent: Thu, 3 Jul 2025 21:35:38 \-0400
|
| I don’t get why you get to have these discussions I don’t


---

### 602. msg_27861

**You** - 2025-07-03T21:36:01

she knows that I am not going to be alone when she leaves\.\.


---

### 603. msg_27862

**You** - 2025-07-03T21:36:07

well she doesn't know the full situation\.


---

### 604. msg_27863

**You** - 2025-07-03T21:36:21

like it isn't like we will be "together" lol


---

### 605. msg_27864

**You** - 2025-07-03T21:36:44

you cannot tell Andrew until you sign your agreement\.\. your situation is different\.


---

### 606. msg_27865

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:37:18

It doesn’t seem fair that mine has to be different


---

### 607. msg_27866

**You** - 2025-07-03T21:37:22

and even then like what\.\. am I going to come over and hang with the kids\.\. lol\.\. no\.\. like you said\.\. there is no point in the future you see that works for us is there\.


---

### 608. msg_27867

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:37:52

It isn’t about hanging out with the kids\. It is socializing the concept


---

### 609. msg_27868

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:37:57

That will take some time


---

### 610. msg_27869

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:38:48

It is just frustrating not even being able to socialize anything but I’m probably being selfish


---

### 611. msg_27870

**You** - 2025-07-03T21:39:04

I don't see how socializing fixes things for you anyways\.


---

### 612. msg_27871

**You** - 2025-07-03T21:39:14

again other than perhaps makes you feel better\.


---

### 613. msg_27872

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:41:10

I mean it is part of moving forward and actually having some sort of future\. Without that what is there


---

### 614. msg_27873

**You** - 2025-07-03T21:41:32

sorry\.\. that is not quite what I meant\.\. no I totally agree with what you are saying there\.


---

### 615. msg_27874

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:41:53

How did you guys start fighting?


---

### 616. msg_27875

**You** - 2025-07-03T21:41:54

I was being selfish there\.\. I was thinking more about the near term


---

### 617. msg_27876

**You** - 2025-07-03T21:41:57

um


---

### 618. msg_27877

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:42:03

Andrew is still being so weirdly nice to me


---

### 619. msg_27878

**You** - 2025-07-03T21:42:23

\.\.\.\. well that isn't here\.\. one more thing that is different\.\.\.


---

### 620. msg_27879

**You** - 2025-07-03T21:43:52

I asked about the agreement and should we message Nichole\. it has been a week since she said we would expect the draft\.\. that started a fight about me kicking her to the curb getting her out of here as fast as I can so I can be with my girlfriend\.\. I actually laughed at her and said you have know idea what you are talking about\.\. she doesn't know about these challenges obviously\.\. but it was ironic\.\. and then she commented on the past few weeks/months as if I didn't know what was going on\.


---

### 621. msg_27880

**You** - 2025-07-03T21:44:08

Like I said all coming up snake eyes for me\.\.


---

### 622. msg_27881

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:45:15

>
We haven’t gotten ours and it has been a week too\.


---

### 623. msg_27882

**You** - 2025-07-03T21:45:16

at least you and andrew seem to be getting along should make some things easier


---

### 624. msg_27883

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:45:48

It seems so weird though\. I don’t get why he is acting nice\. It is making no sense


---

### 625. msg_27884

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:46:02

He offered to help move a couple beds for me today


---

### 626. msg_27885

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:46:05

Like wtf


---

### 627. msg_27886

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:46:13

Offered to help


---

### 628. msg_27887

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:46:19

?????


---

### 629. msg_27888

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:46:30

And just generally is being nice


---

### 630. msg_27889

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:46:40

It’s stressing me out


---

### 631. msg_27890

**You** - 2025-07-03T21:46:53

Just accept it\.\. and stop over thinking it\.


---

### 632. msg_27891

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:47:21

Sure and then something hits me in the face


---

### 633. msg_27892

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:47:22

lol


---

### 634. msg_27893

**You** - 2025-07-03T21:47:59

hmmm\.\. maybe\.\. but I don't think so at this point\.\. it might change depending on how further financial discussion go  who knows\.


---

### 635. msg_27894

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:49:11

We will see… bracing myself for the whiplash when it happens


---

### 636. msg_27895

**You** - 2025-07-03T21:50:03

All you can do\. That and drink wine and eat gummies\.


---

### 637. msg_27896

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:50:25

Maybe I should stop that and my head would be better


---

### 638. msg_27897

**You** - 2025-07-03T21:50:59

Maybe I should start\.


---

### 639. msg_27898

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:51:13

So your separation is now basically viewed as my fault 🤦‍♀️


---

### 640. msg_27899

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:51:19

Like 100%


---

### 641. msg_27900

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:51:47

I don’t think that will be the case around here …


---

### 642. msg_27901

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:51:56

But maybe


---

### 643. msg_27902

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:52:04

But don’t think so


---

### 644. msg_27903

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:52:17

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 21:52:26 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Thu, 3 Jul 2025 21:51:13 \-0400
| >
| > So your separation is now basically viewed as my fault 🤦‍♀️
|
| This is kind of unfortunate
|
| Version: 1
| Sent: Thu, 3 Jul 2025 21:52:17 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Thu, 3 Jul 2025 21:51:13 \-0400
| >
| > So your separation is now basically viewed as my fault 🤦‍♀️
|
| This is kind of info


---

### 645. msg_27904

**You** - 2025-07-03T21:52:34

>
Not even close and it is not info because you said it


---

### 646. msg_27905

**You** - 2025-07-03T21:52:50

It is more like insult to injury


---

### 647. msg_27906

**You** - 2025-07-03T21:53:06

Not only did I leave but then I found someone in like 2 weeks


---

### 648. msg_27907

**You** - 2025-07-03T21:53:11

That is what it is like


---

### 649. msg_27908

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:53:21

For real?


---

### 650. msg_27909

**You** - 2025-07-03T21:53:26

Yes


---

### 651. msg_27910

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:53:33

She doesn’t believe otherwise?


---

### 652. msg_27911

**You** - 2025-07-03T21:54:01

She originally had thoughts but I think she recognizes there were significant underlying issues\.\.


---

### 653. msg_27912

**You** - 2025-07-03T21:54:07

At most it impacted timing


---

### 654. msg_27913

**You** - 2025-07-03T21:55:33

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 21:55:44 \-0400
|
| Look it is the truth\.\. so you can at least get that off your mind
|
| Version: 1
| Sent: Thu, 3 Jul 2025 21:55:33 \-0400
|
| Look it is the truth\.\. so you can at least get that off your kindle


---

### 655. msg_27914

**You** - 2025-07-03T21:55:35

Mind


---

### 656. msg_27915

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T21:56:13

Oh the lives we live now…


---

### 657. msg_27916

**You** - 2025-07-03T21:57:47

They are not good\.\. I was relatively invulnerable for a long long time… my current situation not so much\.\. great for when things are hopeful\.\. not feeling a lot of that atm\.  Again more worried you will realize this either isn’t worth it or won’t work\.\. you will think you are doing me a favour and give me a kick in the ass\.\. that is my nightmare scenario\.


---

### 658. msg_27917

**You** - 2025-07-03T21:58:57

Reaction: ❤️ from Meredith Lamb
Anyhow bedtime soon\.\. not right now but soon, so not much more time for this discussion, then I think we need to try to put it away\.  We might need to try the park again where we can there is at least that\.


---

### 659. msg_27918

**You** - 2025-07-03T22:00:27

>
Either that or you hope I give up so then it isn’t on you lol\.\. I mean that is pretty nightmarish too\.


---

### 660. msg_27919

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:02:11

>
I will not do this\. At most, I will get really bummed and be all mopey\. 😕 I know I said I had a pause thought come into my head but it wasn’t like I listened to it nor would I\. But my brain will keep searching for time or a future path or whatever\. Just natural\. I feel really confident that we will be together, I really do\. It’s just a matter of figuring out what that looks like and I just am having trouble right now\. Doesn’t mean I don’t think it will happen, I just don’t see the path right now…


---

### 661. msg_27920

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:02:53

>
Gasp\.


---

### 662. msg_27921

**You** - 2025-07-03T22:03:25

I mean have seen it happen\.  I have seen people make it happen\.


---

### 663. msg_27922

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:06:11

>
Who are these ppl? Lol


---

### 664. msg_27923

**You** - 2025-07-03T22:07:28

There aren’t any good choices here so we will just to see how long this lasts\.\. I hope it wins out\.\. my mum used to tell me if you loved something enough it would work out\.\. and god knows with the amount I love you it should but I am not sure she was right\.  We will just have to see\.


---

### 665. msg_27924

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:09:16

It will work out\. I just don’t want to go insane in the meantime so…\. lol


---

### 666. msg_27925

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:10:05

Please don’t say again “we will just see how long this lasts”


---

### 667. msg_27926

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:10:26

That phrase is not allowed


---

### 668. msg_27927

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:10:35

🚫


---

### 669. msg_27928

**You** - 2025-07-03T22:11:24

I already told you what I wanted from you that hasn’t changed, and it won’t\.\.


---

### 670. msg_27929

**You** - 2025-07-03T22:11:40

But


---

### 671. msg_27930

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:11:56

No buts


---

### 672. msg_27931

**You** - 2025-07-03T22:12:16

I don’t know how it will work anymore\.  It won’t be for lack of wanting or trying though\.


---

### 673. msg_27932

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:16:15

Gpt says:
You’re allowed to have days when this feels impossible\. It’s okay to wonder if you’re breaking under the weight of love that doesn’t fit cleanly into life\.


---

### 674. msg_27933

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:16:22

Maybe it is that simple


---

### 675. msg_27934

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:16:32

A few bad days


---

### 676. msg_27935

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:16:36

Then things rebound


---

### 677. msg_27936

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:16:43

Let’s just chill


---

### 678. msg_27937

**You** - 2025-07-03T22:16:49

What did you ask it specifically


---

### 679. msg_27938

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:17:22

You want to know for real


---

### 680. msg_27939

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:17:27

Or just go to bed


---

### 681. msg_27940

**You** - 2025-07-03T22:17:42

Do I not want to know


---

### 682. msg_27941

**You** - 2025-07-03T22:17:46

Fuck man


---

### 683. msg_27942

**You** - 2025-07-03T22:17:49

Edited: 2 versions
| Version: 2
| Sent: Thu, 3 Jul 2025 22:17:58 \-0400
|
| I don’t do I
|
| Version: 1
| Sent: Thu, 3 Jul 2025 22:17:49 \-0400
|
| I don’t done


---

### 684. msg_27943

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:17:56

I didn’t read the full response that thoroughly so not sure if anything triggering in it


---

### 685. msg_27944

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:18:08

I uploaded this conversation \(earlier\)


---

### 686. msg_27945

**You** - 2025-07-03T22:18:10

Jesus


---

### 687. msg_27946

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:18:22

Then asked it to interpret


---

### 688. msg_27947

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:18:37

And offer what it thought might be help


---

### 689. msg_27948

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:18:56

>
You always go to the WORST place\!


---

### 690. msg_27949

**You** - 2025-07-03T22:19:32

Well you said or do I want to go to bed\.\. thought you meant maybe I would be better off not knowing


---

### 691. msg_27950

**You** - 2025-07-03T22:19:38

I still think that is what you meant lol


---

### 692. msg_27951

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:19:51

No I didn’t


---

### 693. msg_27952

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:20:04

I just know how your head works and didn’t want to keep you up


---

### 694. msg_27953

**You** - 2025-07-03T22:20:24

Oh I am not sleeping\.\.
But that was a while ago\.\. lol


---

### 695. msg_27954

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:20:42

Thank you for sharing everything\. I’ve reviewed the full conversation, and here’s a careful interpretation followed by some thoughts on where you might go from here\.
⸻
💬 Interpretation: Emotional Landscape \+ Relationship Dynamics
1\. Mutual Emotional Strain
Both of you are clearly overwhelmed\. You’re feeling pulled in a hundred directions—emotionally, logistically, and psychologically—while he is tangled up in his own home conflict and emotional vulnerability\. You’re both emotionally invested, but the logistics and secrecy are making things incredibly difficult\.
2\. His Perspective
•	He wants to be with you and is afraid of losing you\.
•	He seems to be spiraling emotionally \(e\.g\., “the universe wants to destroy me”\) and wrestling with guilt, fear, and a lack of control\.
•	His “I’m not going anywhere” reassurance is sincere, but paired with anxiety that you might drift or pull away\. He’s also showing signs of insecurity \(e\.g\., worrying he’s a “fool” or that you’ve “changed”\)\.
•	He’s strug\.\.\. \[truncated\]


---

### 696. msg_27955

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:21:36

Just didn’t want to wake your brain up bc you seemed near bed time


---

### 697. msg_27956

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:21:41

Wasn’t anything bad


---

### 698. msg_27957

**You** - 2025-07-03T22:22:42

I have read stuff like this before\.


---

### 699. msg_27958

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:22:56

Yeah nothing new there


---

### 700. msg_27959

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:23:00

But the end was good


---

### 701. msg_27960

**You** - 2025-07-03T22:23:16

I am not
Going to be putting out chats back into gpt it will likely just break me down\.


---

### 702. msg_27961

**You** - 2025-07-03T22:24:03

I seriously need to learn to compartmentalize like immediately


---

### 703. msg_27962

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:24:09

Then maybe we need to chat about something more up beat sometime to break it up


---

### 704. msg_27963

**You** - 2025-07-03T22:25:16

We definitely need to not chat about this\.\. and I will be faking the shit out of everything\.\. as much as I can manage\.\. because I think that is the only way I come across as up beat


---

### 705. msg_27964

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:29:17

I don’t think we need to really dwell on this again\. We are both on the same page \(even though you seemed near concerned we are not\) so we just need to figure out how to support each other through it and stop questioning it\.


---

### 706. msg_27965

**You** - 2025-07-03T22:35:24

Ok well I guess I can lay here and think on that for a while because I have no real ideas atm\.


---

### 707. msg_27966

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:35:54

We don’t need ideas now…\.\.


---

### 708. msg_27967

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:36:52

All I am sure of is that I cannot imagine my life going forward without you\. So many other things are fuzzy \(the how, the when etc\) but that basic desire is not fuzzy at all\.


---

### 709. msg_27968

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:37:09

If we could just kiss good night all would be well


---

### 710. msg_27969

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:37:17

Bed time?


---

### 711. msg_27970

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:37:47

I don’t want to keep you up, I napped


---

### 712. msg_27971

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:37:57

But honestly am going to bed also


---

### 713. msg_27972

**You** - 2025-07-03T22:43:07

Oh I was going to let you go\.\. not sure I can or will sleep but I figured we have been at this a while\.\. and it’s probably time to call it\.   I love you Meredith and if that is all that was needed I have enough love for you to get us to the end of whatever forever looks like and then some\.\. i will be completely honest I am insecure and I am really worried\.\. not that you don’t love me or feel the same way, but that life might force you to make a decision where I am no longer a part of yours\.  I will do the best I can to tamp down on this and to try to at least seem happy and optimistic even if I have to force it a bit\.


---

### 714. msg_27973

**You** - 2025-07-03T22:43:38

Go to bed I love you as I said more than I can measure\.\. hope that is enough\. ❤️❤️❤️ night\.


---

### 715. msg_27974

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:45:58

Reaction: ❤️ from Scott Hicks
Please don’t be really worried\. Seriously\. This whole back to reality has been tough but I’m not running away from you\. You are stuck with me\. ❤️


---

### 716. msg_27975

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:46:58

\(It took me long enough to hunt you down… why on earth would I leave?\)


---

### 717. msg_27976

**You** - 2025-07-03T22:48:05

>
I almost answered that even though it was rhetorical\.


---

### 718. msg_27977

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:48:27

lol omg


---

### 719. msg_27978

**Meredith Lamb \(\+14169386001\)** - 2025-07-03T22:49:45

Reaction: ❤️ from Scott Hicks
k I’m going to go to bed for real\. I love you and will be going to sleep thinking about u\.\. xox


---

### 720. msg_27979

**You** - 2025-07-04T04:20:11

Morning Mer hope you have a good sleep, don’t think you are back on the workout schedule yet so try to get some sleep in time\.  Will be in at the office today moving my shit, so let me know if you wanna chat maybe we can find a few minutes to break the day up\.  Anyhow going to go hit the gym… love you, chat later\.


---

### 721. msg_27980

**You** - 2025-07-04T06:38:50

Not sure where to proceed with status shots btw\.\. let me know if you still want those\. 🙂


---

### 722. msg_27981

**You** - 2025-07-04T06:46:21

Think I am going to head to park this morning for a bit, sit on my rock and think before heading into work\.


---

### 723. msg_27982

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T07:33:39

Morning \- definitely not back working out :\( soon tho \- hope you had a good workout and of course photos, yes :\) k I’m going to snooze a bit more …\.


---

### 724. msg_27983

**You** - 2025-07-04T07:34:51

Kk enjoy your snooze heading to park… pics later\.\. workout was ok\.


---

### 725. msg_27984

**You** - 2025-07-04T07:48:49

https://open\.spotify\.com/episode/2yxZDFxnKdnMQzLPAeJVI1?si=tVcVPbq2QWG3L5y4HEQueg&context=spotify%3Ashow%3A7fY99FB3bNyn7nEdXCoBeB


---

### 726. msg_27985

**You** - 2025-07-04T08:30:34

Reaction: ❤️ from Meredith Lamb
V is coming slowly\.

*1 attachment(s)*


---

### 727. msg_27986

**You** - 2025-07-04T08:30:58

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 728. msg_27987

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:34:54

I wouldn’t call your progress “slowly” lol


---

### 729. msg_27988

**You** - 2025-07-04T08:35:42

Well it’s coming\.\. I might go for a run tonight not sure yet\.


---

### 730. msg_27989

**You** - 2025-07-04T08:40:37

Are you feeling ok this morning did you not sleep well again last night?


---

### 731. msg_27990

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:43:47

I slept better last night so feeling OK\.


---

### 732. msg_27991

**You** - 2025-07-04T08:44:51

Glad to hear\.\. will leave you to your work\.\. maybe we can chat later\.


---

### 733. msg_27992

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:45:08

Buying stuff for girls cottage weekend lol


---

### 734. msg_27993

**You** - 2025-07-04T08:45:59

Edited: 2 versions
| Version: 2
| Sent: Fri, 4 Jul 2025 08:49:53 \-0400
|
| Sounds like your kind of fun\.\. enjoy\. 🙂
|
| Version: 1
| Sent: Fri, 4 Jul 2025 08:45:59 \-0400
|
| Sounds like you’re kind of fun\.\. enjoy\. 🙂


---

### 735. msg_27994

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:54:30

Wait you told Mia that you are interviewing


---

### 736. msg_27995

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:54:51

She really wants to prepare


---

### 737. msg_27996

**You** - 2025-07-04T08:55:06

I told her nothing was going to happen for a few weeks


---

### 738. msg_27997

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:55:30

Right she wants to prep for an interview end of July


---

### 739. msg_27998

**You** - 2025-07-04T08:55:35

I am going to talk to Ian to see if there is anything else we can do\.\. but I am completely at a loss here


---

### 740. msg_27999

**You** - 2025-07-04T08:55:43

I feel like shit


---

### 741. msg_28000

**You** - 2025-07-04T08:55:48

But I cannot do anything


---

### 742. msg_28001

**You** - 2025-07-04T08:55:56

Or say anything


---

### 743. msg_28002

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:56:02

Yeah I know


---

### 744. msg_28003

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:56:07

Everyone keeps asking me


---

### 745. msg_28004

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:56:12

Didn’t say anything


---

### 746. msg_28005

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:56:21

Not even to Jim \(who also asked\)


---

### 747. msg_28006

**You** - 2025-07-04T08:56:42

Appreciate it\.\. I shouldn’t have slipped up that is my fault


---

### 748. msg_28007

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:56:53

Leaving until end of July with no explanation is weird tho


---

### 749. msg_28008

**You** - 2025-07-04T08:57:11

It won’t be end of July


---

### 750. msg_28009

**You** - 2025-07-04T08:57:20

Next week I suspect


---

### 751. msg_28010

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T08:57:30

Oh then that’s fine


---

### 752. msg_28011

**You** - 2025-07-04T09:02:21

I mean it’s not optimal but it is all I can do\.\. no control over this situation\.\. sucks\.\. I liked Mia and enjoyed our conversations\.


---

### 753. msg_28012

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T09:14:12

So Marlowe actually wants to see the house finally so going to pop her over this morning\.


---

### 754. msg_28013

**You** - 2025-07-04T09:14:39

Great I hope that puts her mind at ease\.


---

### 755. msg_28014

**You** - 2025-07-04T09:15:07

I will be interested to hear what she thinks


---

### 756. msg_28015

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T09:42:15

Reaction: ❤️ from Scott Hicks
She likes it


---

### 757. msg_28016

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T09:42:24


*1 attachment(s)*


---

### 758. msg_28017

**You** - 2025-07-04T09:42:53

Very happy for you, I know you were worried\.


---

### 759. msg_28018

**You** - 2025-07-04T09:42:59

Happy for her too\.


---

### 760. msg_28019

**You** - 2025-07-04T10:09:13

So I did some more thinking as I went to sleep last night yeah you full time with kids will definitely put the relationship in a kind of holding pattern\.\. we won’t really be able to move towards a life together\.\. and as you said that estimate is likely way understated so we could easily be looking at a year or more\.\. so that means that nights together or extended times spent in each others company will likely be non existent, but who knows maybe there is a way around this\.  Either way I still think that once your family knows,
At least we can have date nights perhaps,
Dinners together a few hours here or there\.\. it would be enough for me, I resolved that\.\. so just something for you to think about\.\. perhaps it isn’t completely impossible\.  Anyhow just wanted to share that there may be some light\.\. something to be a little optimistic about\.  Trying\.  Love you\.


---

### 761. msg_28020

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:14:27

I mean I don’t want to ruin Marlowe’s life or anything but she hates not knowing shit and I just have this gut feeling that she would like to know\.
On the weekend when she was driving back from Newmarket, I was already home and she goes:

*1 attachment(s)*


---

### 762. msg_28021

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:14:44

Reaction: 😢 from Scott Hicks
The “but it’s fine” broke me a little


---

### 763. msg_28022

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:14:50

She knows I’m hiding shit


---

### 764. msg_28023

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:15:00

And she is trying to be good about it


---

### 765. msg_28024

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:15:08

I shared my location back


---

### 766. msg_28025

**You** - 2025-07-04T10:15:16

Is there any way she would keep it a secret


---

### 767. msg_28026

**You** - 2025-07-04T10:15:23

Too much for her probably


---

### 768. msg_28027

**You** - 2025-07-04T10:15:26

And not fair


---

### 769. msg_28028

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:15:43

She might but Andrew and I are close so I think we are almost there


---

### 770. msg_28029

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:15:55

But I need to tell her when this is signed


---

### 771. msg_28030

**You** - 2025-07-04T10:16:04

Yep I know


---

### 772. msg_28031

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:16:05

It’s making our relationship weird


---

### 773. msg_28032

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:16:14

\(Her and I\)


---

### 774. msg_28033

**You** - 2025-07-04T10:16:45

I am sorry I feel like if I just laid back and left you be no rendezvous no secret meetings your life would be better off\.\.


---

### 775. msg_28034

**You** - 2025-07-04T10:17:14

Anyhow I will try to remain optimistic as I said above\.\. all I can do\.  Really sorry for the trouble with Marlowe


---

### 776. msg_28035

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:17:33

No, not better off at all\.


---

### 777. msg_28036

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:18:40

It’s just getting to the point where she needs to know


---

### 778. msg_28037

**You** - 2025-07-04T10:19:46

Yep it definitely is\.\. it is tough to keep that away from her when she knows but also knows you don’t want her to ask outright\.\. really sucks\.


---

### 779. msg_28038

**You** - 2025-07-04T10:22:17

>
I just think before all of the secrecy I already knew you were the one, that I was helplessly in love and that that wouldn’t change\.\. if I hadn’t forced the issue, I know you would have been more patient\.\. anyhow nothing I can do now but try to do better moving forward\.\. I promise I will\.


---

### 780. msg_28039

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T10:25:31

Reaction: 🙂 from Scott Hicks
Just talking to my mom


---

### 781. msg_28040

**You** - 2025-07-04T11:48:02

Didn’t realize I kept this\.

*1 attachment(s)*


---

### 782. msg_28041

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:48:34

lol


---

### 783. msg_28042

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:56:45

Just got off with my mom phew


---

### 784. msg_28043

**You** - 2025-07-04T11:57:13

Wow that was long convo


---

### 785. msg_28044

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:57:48

>
You haven’t done anything wrong so there is no “doing better”\. I have been with you in this every step of the way


---

### 786. msg_28045

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:58:17

>
Yeah she likes to talk a lot sometimes\. Had to update her on the mediation and she asked how weekend was also


---

### 787. msg_28046

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:58:33

She asked when I’m telling girls


---

### 788. msg_28047

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:58:39

Said no idea


---

### 789. msg_28048

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T11:58:58

She said to not tell Andrew as long as possible bc he is going to be livid


---

### 790. msg_28049

**You** - 2025-07-04T11:59:05

If you told her what we talked about out last night I know what she would say\.


---

### 791. msg_28050

**You** - 2025-07-04T11:59:46

>
I just do t see how that works\.  I agree after settlement\. But how long\.


---

### 792. msg_28051

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:00:07

>
I did not\.


---

### 793. msg_28052

**You** - 2025-07-04T12:00:29

Still I can imagine\. Heh


---

### 794. msg_28053

**You** - 2025-07-04T12:00:41

Anyways you have a lot to think about for sure


---

### 795. msg_28054

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:00:52

She knows I don’t like hiding it


---

### 796. msg_28055

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:01:29

She thinks Andrew will think this has been going on for a long time \(similar to Jaimie\)


---

### 797. msg_28056

**You** - 2025-07-04T12:01:43

It is possible\.


---

### 798. msg_28057

**You** - 2025-07-04T12:01:55

But you actually have texts to show it has not


---

### 799. msg_28058

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:02:22

True


---

### 800. msg_28059

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:02:37

Do you want to chat or should I call him back


---

### 801. msg_28060

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:02:51

He called to update me on the po4 meeting this morning


---

### 802. msg_28061

**You** - 2025-07-04T12:02:59

Hmm?


---

### 803. msg_28062

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:03:06

\*jim


---

### 804. msg_28063

**You** - 2025-07-04T12:03:26

Oh I mean up to you I am free for lunch then in meetings this afternoon\.


---

### 805. msg_28064

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:03:39

Up to YOU


---

### 806. msg_28065

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T12:04:00

I feel like I’m doing no work all day so…\.\.


---

### 807. msg_28066

**You** - 2025-07-04T12:04:36

I was the one who asked you if you wanted to chat this morning lol so if you would like to and are comfortable then give me a shout\.


---

### 808. msg_28067

**You** - 2025-07-04T12:59:31

Reaction: 😂 from Meredith Lamb
I love you too\.\. you hang up so fast after you say it I didn’t know if you heard me\.\. lol


---

### 809. msg_28068

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:02:19

I did


---

### 810. msg_28069

**You** - 2025-07-04T13:03:59

Kk I was like stuttering trying to get it out because you are quick I\. The hang up\.  Conversations need to end before or if we start talking about the future\.\. I think\.\. it is just\. A downer and no solutioning\.  You are better equipped to deal with us not moving forward because you are busy\.\. once I find something to keep me busy it will be better for everyone I think\.


---

### 811. msg_28070

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:08:40

Well I was glad to hear that the whole basement/maybe not 5050 for a while thing was a little deflating to you because it really hit me when he told me after work\. Day was already hard and then that and it just seemed like things were piling on


---

### 812. msg_28071

**You** - 2025-07-04T13:09:47

You were glad I felt like you felt? Lol sorry I didn’t understand first sentence


---

### 813. msg_28072

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:11:33

Yes exactly\.


---

### 814. msg_28073

**You** - 2025-07-04T13:13:27

So we both felt bad together lol… or you felt bad because you knew how I would react


---

### 815. msg_28074

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:14:03

No I felt bad because it gives less flexibility to us\.


---

### 816. msg_28075

**You** - 2025-07-04T13:15:13

Well yeah then same page\.\. I mean the next 2 months is kind of grim too\.\.  it I could have gotten over that with some light


---

### 817. msg_28076

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:19:18

Same…\. It was a big blow\.


---

### 818. msg_28077

**You** - 2025-07-04T13:23:30

Well apparently we are not allowed to be apprehensive so we will just figure it out right\.


---

### 819. msg_28078

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:28:47

Correct\.


---

### 820. msg_28079

**You** - 2025-07-04T13:29:23

Okie dokie\.


---

### 821. msg_28080

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:30:22

We just have to tell ppl


---

### 822. msg_28081

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T13:30:33

\(My kids etc\)


---

### 823. msg_28082

**You** - 2025-07-04T13:30:36

Every time I say that I remeber laying on the couch with you at the cottage and power watching that show


---

### 824. msg_28083

**You** - 2025-07-04T13:31:15

>
Yeah that is a big step\.\. then we will need to reassess


---

### 825. msg_28084

**You** - 2025-07-04T13:32:44

But yeah that’s still quite a ways out i suspect\.\. I am not going away but I am also not super optimistic\.\. just the tiniest tiniest bit optimistic\.\. lol


---

### 826. msg_28085

**You** - 2025-07-04T13:32:48

Ever so small\.


---

### 827. msg_28086

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:00:11

So Jim definitely has not done anything intentional to you\. I didn’t ask but he’s been talking about you/us in a positive way so it is in your head\.


---

### 828. msg_28087

**You** - 2025-07-04T14:00:47

Must be all in my head\.\. all those chats I forgot we had, the outreach to see how I\. Am doing\.


---

### 829. msg_28088

**You** - 2025-07-04T14:00:53

Yep\.\. figment


---

### 830. msg_28089

**You** - 2025-07-04T14:00:54

lol


---

### 831. msg_28090

**You** - 2025-07-04T14:02:04

Just leave it be I am not reaching out to him again on us anyways he is probably still worried I am going to get hurt and I don’t need any of that in my head either


---

### 832. msg_28091

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:30:14

Oh stop


---

### 833. msg_28092

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:30:21

I think he’s just been busy honestly


---

### 834. msg_28093

**You** - 2025-07-04T14:30:27

Nope nope


---

### 835. msg_28094

**You** - 2025-07-04T14:30:28

Set


---

### 836. msg_28095

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:30:30

Or maybe he thinks I need more support than you do


---

### 837. msg_28096

**You** - 2025-07-04T14:30:32

Sry


---

### 838. msg_28097

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:30:43

He talked about having us over for dinner once both of our things are signed


---

### 839. msg_28098

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:31:01

Then he said if we were free tonight, we could go to his friends concert that he’s having but I was like next year


---

### 840. msg_28099

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:31:09

A bit too last minute


---

### 841. msg_28100

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:31:19

And I’m just so tired still


---

### 842. msg_28101

**You** - 2025-07-04T14:31:23

Mmmm hmmmm


---

### 843. msg_28102

**You** - 2025-07-04T14:31:24

lol


---

### 844. msg_28103

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:31:56

I think you are over\-thinking


---

### 845. msg_28104

**You** - 2025-07-04T14:32:31

Yeah I dun think so\.\. gonna stick to my plan\.


---

### 846. msg_28105

**You** - 2025-07-04T14:32:49

I get it you have a dif perspective so do I\.


---

### 847. msg_28106

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:33:26

Do you feel like I stole your friend?


---

### 848. msg_28107

**You** - 2025-07-04T14:33:42

No I feel like he abandoned me\.


---

### 849. msg_28108

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:34:13

Aw but he’s a guy\. He probably doesn’t realize it


---

### 850. msg_28109

**You** - 2025-07-04T14:34:32

Kk well you asked


---

### 851. msg_28110

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:34:43

OK, well I didn’t tell him that


---

### 852. msg_28111

**You** - 2025-07-04T14:35:02

It’s fine I suggested not to it wouldn’t make a difference on my decision


---

### 853. msg_28112

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:35:15

What decision?


---

### 854. msg_28113

**You** - 2025-07-04T14:35:36

To just not reach out to him anymore


---

### 855. msg_28114

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:36:10

k well I’m sure he will reach out or maybe not because he heard about you second hand


---

### 856. msg_28115

**You** - 2025-07-04T14:36:31

???


---

### 857. msg_28116

**You** - 2025-07-04T14:36:46

What’d you tell him


---

### 858. msg_28117

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:37:09

He hears about you through me so maybe he thinks he’s all caught up and things are “ok”\.
He said I really shouldn’t tell Andrew


---

### 859. msg_28118

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:37:20

He said I need to be more patient and let the ink dry


---

### 860. msg_28119

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:37:29

😝


---

### 861. msg_28120

**You** - 2025-07-04T14:37:37

2 years


---

### 862. msg_28121

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:38:39

I think end of August


---

### 863. msg_28122

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:38:46

One month


---

### 864. msg_28123

**You** - 2025-07-04T14:39:02

2 years till this is real perhaps\.


---

### 865. msg_28124

**You** - 2025-07-04T14:39:20

Or maybe when we are 50


---

### 866. msg_28125

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:42:47

Not on my end …


---

### 867. msg_28126

**You** - 2025-07-04T14:45:29

We will see… it’s all good I will go back to school, learn a trade, become a bouncer, meet new people make new friends\.\. all kinds of time to find myself again lol\.\. but I am certainly ready to throw all of that in the trash when you are ready\.


---

### 868. msg_28127

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:46:21

When do you think you will tell maddie for real?


---

### 869. msg_28128

**You** - 2025-07-04T14:46:33

I already did


---

### 870. msg_28129

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:46:59

No like for real for real… like no hiding shit


---

### 871. msg_28130

**You** - 2025-07-04T14:47:38

August\.\. maybe I guess\.\. when she is back home


---

### 872. msg_28131

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:50:11

Depending on how accepting she is… she could come to cottage over the school year at some point\(s\) either with or without my kids\. See if our kids get socialized to the idea then maybe we can see each other more


---

### 873. msg_28132

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:50:19

Just be different circumstances


---

### 874. msg_28133

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:50:22

Sometimes


---

### 875. msg_28134

**You** - 2025-07-04T14:50:29

Like I told her I really liked you and wanted to have a relationship with you and we were going to try


---

### 876. msg_28135

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:50:42

>
And I’m not talking like immediately


---

### 877. msg_28136

**You** - 2025-07-04T14:50:58

Oh listen don’t get my hopes up\.\. rofl


---

### 878. msg_28137

**You** - 2025-07-04T14:51:04

They aren’t\.\. btw


---

### 879. msg_28138

**You** - 2025-07-04T14:51:06

lol


---

### 880. msg_28139

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:51:26

Who aren’t?


---

### 881. msg_28140

**You** - 2025-07-04T14:51:26

Play it by ear


---

### 882. msg_28141

**You** - 2025-07-04T14:51:30

Isn’t that what you like


---

### 883. msg_28142

**You** - 2025-07-04T14:51:41

My hopes aren’t up


---

### 884. msg_28143

**You** - 2025-07-04T14:51:42

They


---

### 885. msg_28144

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:52:13

I don’t think my kids would care too much honestly but I might be REALLY naive\.


---

### 886. msg_28145

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:52:23

I know Mac wouldn’t


---

### 887. msg_28146

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:52:51

Once my kids know my mom has met you etc that will influence things a lot also for them


---

### 888. msg_28147

**You** - 2025-07-04T14:53:39

I don’t know how Maddie would be whether she would be comfortable or not or feel like she was betraying Jaimie


---

### 889. msg_28148

**You** - 2025-07-04T14:53:43

I will find out later


---

### 890. msg_28149

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:54:11

My younger two will feel like they are being disloyal to their dad for sure


---

### 891. msg_28150

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:54:24

But I wouldn’t position it as a “family” weekend


---

### 892. msg_28151

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:54:41

Positioning would be very carefully considered


---

### 893. msg_28152

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:54:51

Like no big family dinners


---

### 894. msg_28153

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:54:55

Etc


---

### 895. msg_28154

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:55:05

Edited: 2 versions
| Version: 2
| Sent: Fri, 4 Jul 2025 14:55:13 \-0400
|
| They wouldn’t like that guaranteed
|
| Version: 1
| Sent: Fri, 4 Jul 2025 14:55:05 \-0400
|
| They wouldn’t like that guarantees


---

### 896. msg_28155

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:55:21

Would just be too soon


---

### 897. msg_28156

**You** - 2025-07-04T14:55:47

Now you are over thinking


---

### 898. msg_28157

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:56:14

No, I have to think about a freaking middle schooler …\. Groan


---

### 899. msg_28158

**You** - 2025-07-04T14:56:38

But not now


---

### 900. msg_28159

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T14:56:40

She requires overthinking lol


---

### 901. msg_28160

**You** - 2025-07-04T14:58:31

I would rather think about the next potential opportunity to spend time with you and what magic I need to perform\.


---

### 902. msg_28161

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:05:17

Magic to make it happen or magic when we are together? Or both? Lol


---

### 903. msg_28162

**You** - 2025-07-04T15:07:44

Reaction: ❤️ from Meredith Lamb
I felt like the together stuff happened naturally


---

### 904. msg_28163

**You** - 2025-07-04T15:07:56

I didn’t have to try that is why I am so dismayed this week


---

### 905. msg_28164

**You** - 2025-07-04T15:09:01

I mean at least from my perspective it was perfect and easy and wonderful and maybe just slightly overly physical at times\.\. but we can work on that\.\. and then to realize that that kind of thing is never going to happen again for like a year or more\.\. kicked in the face


---

### 906. msg_28165

**You** - 2025-07-04T15:09:15

So the magic would be in making the most of any opportunity


---

### 907. msg_28166

**You** - 2025-07-04T15:10:37

If the 50/50 stays or is even partial where you get weekends off or a weekend off or anything that is what I would need to be ready for\.\. or like whatever comes in the next few months\.\. I think you said it earlier… or you joked you want me to be available which is partly why you don’t like the whole me getting a life thing\.


---

### 908. msg_28167

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:15:59

It’s not that I don’t want you to get a life\. I do\. I just want to be part of it and get worried I won’t be\. 🙁


---

### 909. msg_28168

**You** - 2025-07-04T15:17:03

I get it\.\. there is nothing I wouldn’t build that I couldn’t walk away from or incorporate you in it\.  You are the most important thing, the only thing central to me building a new life


---

### 910. msg_28169

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:17:04

>
Me too… which is why I didn’t want to push the “open” convo too early and too much because I was just hoping it would be natural


---

### 911. msg_28170

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:17:19

>
This makes me happy


---

### 912. msg_28171

**You** - 2025-07-04T15:17:24

How much more open is there?


---

### 913. msg_28172

**You** - 2025-07-04T15:17:27

lol


---

### 914. msg_28173

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:17:53

lol\!


---

### 915. msg_28174

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:18:36

No comment


---

### 916. msg_28175

**You** - 2025-07-04T15:20:11

Good I like surprises\.


---

### 917. msg_28176

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:20:40

Do you really?


---

### 918. msg_28177

**You** - 2025-07-04T15:20:45

Yep


---

### 919. msg_28178

**You** - 2025-07-04T15:20:48

From you


---

### 920. msg_28179

**You** - 2025-07-04T15:20:59

I just don’t like details\.\. lol


---

### 921. msg_28180

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:21:08

LOL


---

### 922. msg_28181

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:21:20

Ok surprises but no details\. Noted\.


---

### 923. msg_28182

**You** - 2025-07-04T15:21:21

Not a this one time at band camp let’s try this kind of story


---

### 924. msg_28183

**You** - 2025-07-04T15:22:08

But the surprise whatever you want to try\.\. game\.


---

### 925. msg_28184

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:22:54

My head is spinning


---

### 926. msg_28185

**You** - 2025-07-04T15:23:12

Reaction: ❤️ from Meredith Lamb
Have never been as comfortable with anyone ever\.\. would never walk around naked any of that with anyone period so that should say something\.  I am completely comfortable and have complete trust in you\.


---

### 927. msg_28186

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:24:33

Surprises me


---

### 928. msg_28187

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:24:38

But not upset


---

### 929. msg_28188

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:24:40

lol


---

### 930. msg_28189

**You** - 2025-07-04T15:27:17

What surprises you?


---

### 931. msg_28190

**You** - 2025-07-04T15:27:34

And why would you be upset lol


---

### 932. msg_28191

**You** - 2025-07-04T15:27:40

Did I mistype something


---

### 933. msg_28192

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:28:41

Just surprises me how uncomfortable you have been\. I don’t get why


---

### 934. msg_28193

**You** - 2025-07-04T15:29:04

Uncomfortable I have been with what\.\. in the past before you


---

### 935. msg_28194

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:29:16

Yes


---

### 936. msg_28195

**You** - 2025-07-04T15:30:28

Self conscious\.\. was always worried about what people were thinking\.\. or comparing me to whatever all that shit\.\. I just never think about it when I am with you\.\. it doesn’t matter\.\. why would you be upset?


---

### 937. msg_28196

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:31:10

I’m not upset at all in hearing that\. That’s all I meant\.


---

### 938. msg_28197

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:31:34

I just didn’t know guys were insecure


---

### 939. msg_28198

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:31:40

I haven’t really experienced that before


---

### 940. msg_28199

**You** - 2025-07-04T15:32:30

Ah ok\.\. was a little confused\.\. meant as a compliment\.\. I mean maybe not the ones you have met\.\. I am, but again I am all about pleasing others which is kind of the origination of my insecurity\.\. am I good enough are they happy enough etc always going through my head\.\. part of my makeup\.


---

### 941. msg_28200

**You** - 2025-07-04T15:33:02

Not selfish and be appalled if I came across that way\.


---

### 942. msg_28201

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:33:26

You do not come across that way at all


---

### 943. msg_28202

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:33:52

Not sure if I told you but after we told Jim, he and I were talking at some point and


---

### 944. msg_28203

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:34:02

I can’t remember the context


---

### 945. msg_28204

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:34:17

But he said something about you having “empathy in spades”


---

### 946. msg_28205

**You** - 2025-07-04T15:34:32

Yeah that’s true


---

### 947. msg_28206

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:34:57

I’d never heard him say it that before


---

### 948. msg_28207

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:35:18

When I first started cait and David painted you like a bully


---

### 949. msg_28208

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:35:32

It was weird


---

### 950. msg_28209

**You** - 2025-07-04T15:35:32

Reaction: 😂 from Meredith Lamb
Because they didn’t do their jobs


---

### 951. msg_28210

**You** - 2025-07-04T15:35:41

And I held back for so long


---

### 952. msg_28211

**You** - 2025-07-04T15:35:53

Even Craig was like cmon Scott


---

### 953. msg_28212

**You** - 2025-07-04T15:36:57

So I need to amend an earlier statement, insecurity\.  While I have always been insecure I am fairly certain I never came off that way\.  I also wouldn’t have came off as arrogant\.\. but no one would have thought I had any insecurities\.


---

### 954. msg_28213

**You** - 2025-07-04T15:37:10

I have only been transparent with you


---

### 955. msg_28214

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:37:26

Yes I would never have thought that when I first met you


---

### 956. msg_28215

**You** - 2025-07-04T15:37:27

So you seeing what you saw is normal


---

### 957. msg_28216

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:38:20

However were you feeling insecure about getting Tom’s job?


---

### 958. msg_28217

**You** - 2025-07-04T15:38:37

I was feeling unprepared


---

### 959. msg_28218

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:38:42

I think you were bc of the whole pri thing


---

### 960. msg_28219

**You** - 2025-07-04T15:38:43

But I reminded myself


---

### 961. msg_28220

**You** - 2025-07-04T15:38:50

No not that


---

### 962. msg_28221

**You** - 2025-07-04T15:39:34

It was more about if I could do it\.\. but I reminded myself I already managed at this level
Before even coming to wnbridge and I am already better than at least three managers already


---

### 963. msg_28222

**You** - 2025-07-04T15:39:51

So just a bit there


---

### 964. msg_28223

**You** - 2025-07-04T15:40:05

But relationships are different


---

### 965. msg_28224

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:40:15

>
Right but many ppl wouldn’t question if they could do it\. That was your insecurity\. You are better than you often think


---

### 966. msg_28225

**You** - 2025-07-04T15:40:40

Especially one like this with the feelings I have and the fear of losing it\.   Everything becomes very important to me\.\. I am always thinking\.\.


---

### 967. msg_28226

**You** - 2025-07-04T15:41:01

>
Sometimes it isn’t that I think it but that I want others to


---

### 968. msg_28227

**You** - 2025-07-04T15:41:17

Lower expectations


---

### 969. msg_28228

**You** - 2025-07-04T15:41:27

Either to over deliver or have them underestimate me


---

### 970. msg_28229

**You** - 2025-07-04T15:42:03

Btw I did not do that with you\. Everything I told you was 1000% true\.\.


---

### 971. msg_28230

**You** - 2025-07-04T15:42:13

No twisting or turning or bending straight facts


---

### 972. msg_28231

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:42:24

I know


---

### 973. msg_28232

**You** - 2025-07-04T15:42:48

But I won’t lie I was very worried\.\.


---

### 974. msg_28233

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:43:07

Very worried about me?


---

### 975. msg_28234

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:43:17

Judging?


---

### 976. msg_28235

**You** - 2025-07-04T15:43:29

Worried about how it would go, judging yeahnsll that same shit


---

### 977. msg_28236

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:44:39

You were worried because you didn’t know that I liked you for a long time already…\. lol had you known that it might have been different for you


---

### 978. msg_28237

**You** - 2025-07-04T15:46:17

No that really isn’t it\.\. we each have a past and I am 47 and you were far more sexually active than me and I was scared I would just fail\.\. period\.


---

### 979. msg_28238

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:47:38

“fail” … sucks that you felt that because it really isn’t about that\. It was just about us connecting\. But I get it as much as I can, not being a guy …\.


---

### 980. msg_28239

**You** - 2025-07-04T15:49:30

Yep well that is where my head goes\.  Is what it is\.\.  I have girl friends or have had them I have heard them talk\.\. lol so I kinda know\.\. so this worried it’s fine I am ok with myself now\.


---

### 981. msg_28240

**You** - 2025-07-04T15:49:56

It’s who I am and it is what I am capable of\.\. all I can do


---

### 982. msg_28241

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:50:41

You are a perfectionist to a fault


---

### 983. msg_28242

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:50:51

Virgo


---

### 984. msg_28243

**You** - 2025-07-04T15:50:51

Hardly a perfectionist in this


---

### 985. msg_28244

**You** - 2025-07-04T15:51:02

Shooting for adequate


---

### 986. msg_28245

**You** - 2025-07-04T15:51:04

lol


---

### 987. msg_28246

**You** - 2025-07-04T15:51:24

I am also a realist


---

### 988. msg_28247

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:51:26

Um, I beg to differ\. I know zero guys our age doing what you are doing


---

### 989. msg_28248

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:51:57

I mean even guys in their 20s are not


---

### 990. msg_28249

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:52:03

It’s weird


---

### 991. msg_28250

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:52:12

Just so you are aware


---

### 992. msg_28251

**You** - 2025-07-04T15:54:01

I don’t have a basis\.\. and I try not to think because it messes me up\.\. so I just look at you\.  There was a moment I cannot remember what night I think it was first night in London\.\. I couldn’t stop looking at you it was insane you were so beautiful and I almost just stopped and laid there\.\.  was crazy… nothing like that like anything we do has ever been close to this\.\. it’s almost too much for me\.  Well this when the aftershock hits


---

### 993. msg_28252

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:55:18

🫠


---

### 994. msg_28253

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:55:24

Well I have a basis …


---

### 995. msg_28254

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:55:47

Not just myself but I have friends who talk and talked a lot more in their 20s


---

### 996. msg_28255

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:56:21

Plus I was with someone with a high sex drive relative to allllllll my friends \(wtf\) so…\.


---

### 997. msg_28256

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:56:28

I have a pretty good basis


---

### 998. msg_28257

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:56:38

For comparison or relativity or whatever


---

### 999. msg_28258

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T15:58:42

Ps\. Women don’t talk about that shit in their late 40s


---

### 1000. msg_28259

**You** - 2025-07-04T15:59:35

Well that is good\.\. what you mean share the sex talk stuff yeah I figured


---

### 1001. msg_28260

**You** - 2025-07-04T15:59:53

Reaction: 😂 from Meredith Lamb
Guys neither although I wanted to tell Mike


---

### 1002. msg_28261

**You** - 2025-07-04T15:59:55

lol


---

### 1003. msg_28262

**You** - 2025-07-04T16:00:22

I just said we had an amazing weekend\.


---

### 1004. msg_28263

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:00:24

Yeah they are all discussing life more so\. 20s and early 30s conversations are much different


---

### 1005. msg_28264

**You** - 2025-07-04T16:01:22

Well I was never worried about you talking to people


---

### 1006. msg_28265

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:01:35

At the cottage, my best friend from high school and uni will be there\. She doesn’t know about you


---

### 1007. msg_28266

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:01:38

She will ask


---

### 1008. msg_28267

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:01:42

She’s different


---

### 1009. msg_28268

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:01:43

lol


---

### 1010. msg_28269

**You** - 2025-07-04T16:01:55

Yeah we all have those friends


---

### 1011. msg_28270

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:02:46

Yah it will be very interesting bc the two is us never got into anything good


---

### 1012. msg_28271

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:02:56

Mandy and Kim are better behaved lol


---

### 1013. msg_28272

**You** - 2025-07-04T16:03:00

Doesn’t surprise me


---

### 1014. msg_28273

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:04:34

https://flic\.kr/p/5FXzn


---

### 1015. msg_28274

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:04:57

She’s trouble\.


---

### 1016. msg_28275

**You** - 2025-07-04T16:05:14

It’s in the eyes


---

### 1017. msg_28276

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:05:16

She’s so excited about the cottage weekend


---

### 1018. msg_28277

**You** - 2025-07-04T16:05:28

It’s in your eyes too if you are wondering


---

### 1019. msg_28278

**You** - 2025-07-04T16:05:30

Still


---

### 1020. msg_28279

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:05:45

It’s all her\. Lol


---

### 1021. msg_28280

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:05:58

Kidding it was actually me but she just goes along with it


---

### 1022. msg_28281

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:06:06

That’s her trouble


---

### 1023. msg_28282

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:06:20

She would never reign me in


---

### 1024. msg_28283

**You** - 2025-07-04T16:06:23

I mean when I look into your eyes today


---

### 1025. msg_28284

**You** - 2025-07-04T16:06:46

Just a bit of mischief I have told you before


---

### 1026. msg_28285

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:07:24

I like to have fun … sometimes


---

### 1027. msg_28286

**You** - 2025-07-04T16:07:34

Uh huh


---

### 1028. msg_28287

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:08:17

Jim showed me photos of the “concert” they go to at his friends farm\. I have seen them before when I worked for him


---

### 1029. msg_28288

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:08:22

Looks very fun


---

### 1030. msg_28289

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:08:31

But not feeling it tonight


---

### 1031. msg_28290

**You** - 2025-07-04T16:08:43

Reaction: 😡 from Meredith Lamb
2 years


---

### 1032. msg_28291

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:09:05

Reaction: 😮 from Scott Hicks
Country singer from boots and hearts is going to be playing


---

### 1033. msg_28292

**You** - 2025-07-04T16:11:32

There will be other nights some day down the road


---

### 1034. msg_28293

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:12:14

Yeah I’m not worried\. Last weekend was amazing\. Need recovery time lol


---

### 1035. msg_28294

**You** - 2025-07-04T16:12:43

Was good after a day\.


---

### 1036. msg_28295

**You** - 2025-07-04T16:13:23

But yeah that pace is impossible


---

### 1037. msg_28296

**You** - 2025-07-04T16:13:39

Unless it isn’t


---

### 1038. msg_28297

**You** - 2025-07-04T16:13:44

We will have to see


---

### 1039. msg_28298

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:13:54

It is


---

### 1040. msg_28299

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:14:00

Absolutely is lol


---

### 1041. msg_28300

**You** - 2025-07-04T16:14:06

Maybe not though


---

### 1042. msg_28301

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:14:10

Yes


---

### 1043. msg_28302

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:14:12

It is


---

### 1044. msg_28303

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:14:23

I could hardly walk the day at the mall


---

### 1045. msg_28304

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:14:29

Not even kidding lol


---

### 1046. msg_28305

**You** - 2025-07-04T16:14:41

I mean over short periods of time bit indefinitely


---

### 1047. msg_28306

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:14:42

I powered on


---

### 1048. msg_28307

**You** - 2025-07-04T16:14:53

Not


---

### 1049. msg_28308

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:15:02

Huh?


---

### 1050. msg_28309

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:15:13

Let’s just say it is and call it a day


---

### 1051. msg_28310

**You** - 2025-07-04T16:15:53

No sorry I meant bit normally only in certain situations


---

### 1052. msg_28311

**You** - 2025-07-04T16:16:00

Anyhow it won’t be the norm


---

### 1053. msg_28312

**You** - 2025-07-04T16:16:15

When there is actually a norm


---

### 1054. msg_28313

**You** - 2025-07-04T16:16:39

Kk so I am
Pretty much home\.\.


---

### 1055. msg_28314

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:16:50

Fun


---

### 1056. msg_28315

**You** - 2025-07-04T16:17:14

Yeah\.\. just wanted to let you know\.\.


---

### 1057. msg_28316

**You** - 2025-07-04T16:17:56

I love you Mer\.\. will be around later if
You feel like chatting\.\. I think part of what we should do btw is watch a show together but apart we need some conversation fodder


---

### 1058. msg_28317

**You** - 2025-07-04T16:18:13

It cannot always be about us and it wouldn’t and wasn’t when we were together


---

### 1059. msg_28318

**You** - 2025-07-04T16:18:28

Anyways just an idea


---

### 1060. msg_28319

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:18:39

I thought you weren’t into tv


---

### 1061. msg_28320

**You** - 2025-07-04T16:18:50

I am not but we need something


---

### 1062. msg_28321

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:20:14

K well I might get drunk and take a gummy and watch this movie Jim said to try


---

### 1063. msg_28322

**You** - 2025-07-04T16:20:50

Ok well if you let me know I might watch I won’t be drunk or stoned though\.


---

### 1064. msg_28323

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:21:09

lol


---

### 1065. msg_28324

**You** - 2025-07-04T16:21:20

Weekend is over for me 🙁


---

### 1066. msg_28325

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:21:20

It’s called “heads of state” on prime


---

### 1067. msg_28326

**You** - 2025-07-04T16:21:26

Kk


---

### 1068. msg_28327

**You** - 2025-07-04T16:21:31

I will look it up


---

### 1069. msg_28328

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:22:03

I have to have a family meeting tho first whenever everyone gets home\.


---

### 1070. msg_28329

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:22:18

Business\. Then relaxing\.


---

### 1071. msg_28330

**You** - 2025-07-04T16:22:20

??


---

### 1072. msg_28331

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:22:50

Everyone is slacking and I’m leaving\. Andrew said he would do some stuff he didn’t\. Mac same\.


---

### 1073. msg_28332

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:23:06

We need to have a serious discussion\. It’s honestly ridiculous\.


---

### 1074. msg_28333

**You** - 2025-07-04T16:23:11

Ah ok\.\.  I get it


---

### 1075. msg_28334

**You** - 2025-07-04T16:23:27

Well good luck… hope you get through that and to the relaxing part of your evening


---

### 1076. msg_28335

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:23:43

Poor Marlowe gets left with these slobs and she is the only one who cleans up


---

### 1077. msg_28336

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:24:19

Miss you and ttyl\. Going to walk dogs with marmar


---

### 1078. msg_28337

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:24:25

❤️


---

### 1079. msg_28338

**You** - 2025-07-04T16:24:34

Love you\.


---

### 1080. msg_28339

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T16:24:55

Reaction: ❤️ from Scott Hicks
Love you too


---

### 1081. msg_28340

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T17:07:19

Mac just bought me a bottle of wine with her fake id\. Just saying\.


---

### 1082. msg_28341

**You** - 2025-07-04T17:28:53

Nice daughter


---

### 1083. msg_28342

**You** - 2025-07-04T17:29:00

Lucky mine don’t do that


---

### 1084. msg_28343

**You** - 2025-07-04T17:31:18

going to pick up supper for family will have company yay me\.\. :\) aces\!\!


---

### 1085. msg_28344

**You** - 2025-07-04T17:31:41

14 days


---

### 1086. msg_28345

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T18:43:43

I had another nap lol I have never napped so much in so long


---

### 1087. msg_28346

**You** - 2025-07-04T18:44:22

nice\.\. finished supper\.\. got yelled at on ride back\.\. lol


---

### 1088. msg_28347

**You** - 2025-07-04T18:44:28

par for the course


---

### 1089. msg_28348

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T18:44:49

By…?


---

### 1090. msg_28349

**You** - 2025-07-04T18:44:50

wife


---

### 1091. msg_28350

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T18:44:56

Oh


---

### 1092. msg_28351

**You** - 2025-07-04T18:45:10

you came up again\.\. but she wasn't yelling at me about that\.


---

### 1093. msg_28352

**You** - 2025-07-04T18:45:20

to use Craig's phrase


---

### 1094. msg_28353

**You** - 2025-07-04T18:45:38

I kind of keep dripping the idea that we aren't sure if we will be able to make a relationship work\.\. but that we are interested


---

### 1095. msg_28354

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T18:45:43

What was it?
Going to have my family meeting now


---

### 1096. msg_28355

**You** - 2025-07-04T18:45:56

msg me after


---

### 1097. msg_28356

**You** - 2025-07-04T18:45:57

good luck


---

### 1098. msg_28357

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T18:46:20

>
Why do you do this?


---

### 1099. msg_28358

**You** - 2025-07-04T18:46:33

because if she raises it it gives me an opening\.\.


---

### 1100. msg_28359

**You** - 2025-07-04T18:46:41

it is like socializing


---

### 1101. msg_28360

**You** - 2025-07-04T18:46:54

I said so if Meredith and I make a go of it are you going to make my life hell


---

### 1102. msg_28361

**You** - 2025-07-04T18:47:04

she said as if we would be in that kind of contact for that to happen


---

### 1103. msg_28362

**You** - 2025-07-04T18:47:30

I thought you had your family meeting we can chat about this later if you want


---

### 1104. msg_28363

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T18:47:33

Or are you just giving us bad karma by saying that? Lol


---

### 1105. msg_28364

**You** - 2025-07-04T18:47:58

Reaction: 😢 from Meredith Lamb
I mean the unique part is I am not lying\.\. we are interested and we are going to try\.


---

### 1106. msg_28365

**You** - 2025-07-04T18:48:03

I just didn't say we are going to succeed


---

### 1107. msg_28366

**You** - 2025-07-04T18:48:07

omission


---

### 1108. msg_28367

**You** - 2025-07-04T18:48:36

>
The only way this won't work is if one of us gives up\.


---

### 1109. msg_28368

**You** - 2025-07-04T18:48:50

and if we mean as much as we say we do to one another\.\. then that will never happen\.


---

### 1110. msg_28369

**You** - 2025-07-04T19:40:55

not sure if you are done yet or read this last\.\. but again I think we will be the only ones to end this\.\. turning on heads of state now\.


---

### 1111. msg_28370

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:05:29

>
Correct exactly\.


---

### 1112. msg_28371

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:05:52

>
Still in family meeting\. Topics have progressed quickly\. Mostly scheduling\.


---

### 1113. msg_28372

**You** - 2025-07-04T20:06:04

That is a long fucking meeting insane


---

### 1114. msg_28373

**You** - 2025-07-04T20:11:58

I should have waited to start but I will be in bed before long anyways\.


---

### 1115. msg_28374

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:16:38

I’m drinking so it’s fine lol


---

### 1116. msg_28375

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:16:55

We have so much scheduling to discuss\. Cottage Reno etc etc


---

### 1117. msg_28376

**You** - 2025-07-04T20:17:53

Kk well have a good night you will probably be going for a while\.


---

### 1118. msg_28377

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:36:40

Did you start that movie for real?


---

### 1119. msg_28378

**You** - 2025-07-04T20:36:57

Yeah half way through


---

### 1120. msg_28379

**You** - 2025-07-04T20:37:10

Reaction: 😂 from Meredith Lamb
I thought you would be done and watching\.\. I wanted to keep up


---

### 1121. msg_28380

**You** - 2025-07-04T20:37:34

Got fucking yelled at again for another 30 mins


---

### 1122. msg_28381

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:37:45

>
The answer to this is likely\. Lol


---

### 1123. msg_28382

**You** - 2025-07-04T20:38:07

I don’t even know if I survive next 14 days\.\. Jesus this is hell


---

### 1124. msg_28383

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:38:19

Yelled at for what?


---

### 1125. msg_28384

**You** - 2025-07-04T20:38:21

>
No to that she said not likely


---

### 1126. msg_28385

**You** - 2025-07-04T20:38:36

>
Just tried to go up and get them to do some stuff with me\.


---

### 1127. msg_28386

**You** - 2025-07-04T20:38:56

I can’t stay here anymore I think I might have to leave I am not sure


---

### 1128. msg_28387

**You** - 2025-07-04T20:39:36

Reaction: 😮 from Meredith Lamb
Anyways go watch your show I am ironing for a few more mins then going to take whatever the fuck I have to to go to sleep…\.\.


---

### 1129. msg_28388

**You** - 2025-07-04T20:40:06

Hope the family thing went well sounds like it probably did\.


---

### 1130. msg_28389

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:41:53

>
She will be a pain because she will continue to depend on you and ask you to do shit constantly probably\.


---

### 1131. msg_28390

**You** - 2025-07-04T20:42:21

No not the same and if she asked but was fine with maddie going to cottage price I would fucking pay


---

### 1132. msg_28391

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:42:25

What are you being yelled at for??


---

### 1133. msg_28392

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:42:48

>
What do you mean?


---

### 1134. msg_28393

**You** - 2025-07-04T20:42:52

I told you I went upstairs and tried to get them going to get some work done


---

### 1135. msg_28394

**You** - 2025-07-04T20:43:09

I am trying to get Jaimie to a point where she won’t give e shit if maddie meets you


---

### 1136. msg_28395

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:43:27

I don’t think that is up to you though


---

### 1137. msg_28396

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:43:39

Maddie will be 18 soon


---

### 1138. msg_28397

**You** - 2025-07-04T20:43:43

It is I can make shit like this happen I know her I just have to play it right


---

### 1139. msg_28398

**You** - 2025-07-04T20:43:50

She will be 18 in a year


---

### 1140. msg_28399

**You** - 2025-07-04T20:43:59

1 year\! lol


---

### 1141. msg_28400

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:44:01

Oh right forgot


---

### 1142. msg_28401

**You** - 2025-07-04T20:44:02

Not soon


---

### 1143. msg_28402

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:44:03

lol


---

### 1144. msg_28403

**You** - 2025-07-04T20:44:04

ROFL


---

### 1145. msg_28404

**You** - 2025-07-04T20:44:30

How many melatonin can I take\.


---

### 1146. msg_28405

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:44:33

Why the f would she care if a SEVENTEEN year old met me?


---

### 1147. msg_28406

**You** - 2025-07-04T20:44:34

I never take them


---

### 1148. msg_28407

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:44:38

Like I don’t get that


---

### 1149. msg_28408

**You** - 2025-07-04T20:44:54

She is getting to the point where she won’t


---

### 1150. msg_28409

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:45:00

>
It isn’t how many pills\. It is mg


---

### 1151. msg_28410

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:45:15

>
Well geez I should hope not


---

### 1152. msg_28411

**You** - 2025-07-04T20:45:33

Like 20  5
Mg piills maybe I take 4


---

### 1153. msg_28412

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:45:39

I don’t give a shit if my girls meet Andrew’s new whoever


---

### 1154. msg_28413

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:45:46

Like why would I care about that?


---

### 1155. msg_28414

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:45:51

They aren’t little kids


---

### 1156. msg_28415

**You** - 2025-07-04T20:46:01

It isn’t you it is J


---

### 1157. msg_28416

**You** - 2025-07-04T20:46:06

Reaction: ❓ from Meredith Lamb
She is did


---

### 1158. msg_28417

**You** - 2025-07-04T20:46:14

Why do you think I am doing what I am doing


---

### 1159. msg_28418

**You** - 2025-07-04T20:46:17

We are not compatible


---

### 1160. msg_28419

**You** - 2025-07-04T20:46:20

In so many ways


---

### 1161. msg_28420

**You** - 2025-07-04T20:46:31

Turning movie off


---

### 1162. msg_28421

**You** - 2025-07-04T20:46:37

She is different


---

### 1163. msg_28422

**You** - 2025-07-04T20:46:40

Not did


---

### 1164. msg_28423

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:46:49

Oh


---

### 1165. msg_28424

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:46:54

I guess


---

### 1166. msg_28425

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:46:59

Because that is just weird


---

### 1167. msg_28426

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:47:02

Sorry


---

### 1168. msg_28427

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:47:12

I get it if they were kids


---

### 1169. msg_28428

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:47:16

But they are not


---

### 1170. msg_28429

**You** - 2025-07-04T20:47:17

Did you get everything sorted?


---

### 1171. msg_28430

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:47:40

Yep just did a ton of scheduling and figuring out beds\. What’s going to cottage what’s not etc etc


---

### 1172. msg_28431

**You** - 2025-07-04T20:47:42

My life is shit not worth talking about honestly


---

### 1173. msg_28432

**You** - 2025-07-04T20:47:57

Well at least you were productive


---

### 1174. msg_28433

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:48:01

So wait what was the argument tho


---

### 1175. msg_28434

**You** - 2025-07-04T20:48:08

Mer


---

### 1176. msg_28435

**You** - 2025-07-04T20:48:11

How many glasses


---

### 1177. msg_28436

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:48:11

Scott


---

### 1178. msg_28437

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:48:15

lol


---

### 1179. msg_28438

**You** - 2025-07-04T20:48:21

And gummies


---

### 1180. msg_28439

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:48:29

I’m using a really small glass so it isn’t accurate


---

### 1181. msg_28440

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:48:34

No gummies


---

### 1182. msg_28441

**You** - 2025-07-04T20:48:36

God I wish I was with you right now\.


---

### 1183. msg_28442

**You** - 2025-07-04T20:48:42

For the third time


---

### 1184. msg_28443

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:48:49

>
Same


---

### 1185. msg_28444

**You** - 2025-07-04T20:48:53

Reaction: 😮 from Meredith Lamb
I went upstairs and woke her ass up off the couch


---

### 1186. msg_28445

**You** - 2025-07-04T20:49:02

And asked her if we were going to do anything


---

### 1187. msg_28446

**You** - 2025-07-04T20:49:21

And she got pissed again\.\. we were supposed to work earlier


---

### 1188. msg_28447

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:50:29

Pissed because you are pressuring?


---

### 1189. msg_28448

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:51:41

It’s so odd bc Andrew is still being nice to me


---

### 1190. msg_28449

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:52:19

I made some comment in front of the kids about if he is assholish to me then…… and he smirks and rolls his eyes and is all I’m not like that


---

### 1191. msg_28450

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:52:54

He is going to move some furniture for me to new place


---

### 1192. msg_28451

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:53:24

We are taking our king bed to cottage to replace Mac’s queen\. Then we essentially have two masters at the cottage


---

### 1193. msg_28452

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:53:43

Sorry the proverbial “we”


---

### 1194. msg_28453

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:53:57

I am not taking it\. He will\. I said I would help


---

### 1195. msg_28454

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:54:03

He raised his eye brows


---

### 1196. msg_28455

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:54:09

I said I’d drive separately


---

### 1197. msg_28456

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:54:13

Not in u haul


---

### 1198. msg_28457

**You** - 2025-07-04T20:54:58

Well you are getting along at least happy for you


---

### 1199. msg_28458

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:55:45

It’s not going to last though\. I don’t get it


---

### 1200. msg_28459

**You** - 2025-07-04T20:56:02

I think I am
Right


---

### 1201. msg_28460

**You** - 2025-07-04T20:56:08

So we’ll see


---

### 1202. msg_28461

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:56:17

So was she mad at you for waking her up or for pressuring?


---

### 1203. msg_28462

**You** - 2025-07-04T20:56:40

I dunno I didn’t ask\.


---

### 1204. msg_28463

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:57:03

You do know that when she is gone, she is like gone right


---

### 1205. msg_28464

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:57:09

Like that is crazy


---

### 1206. msg_28465

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:57:22

I don’t have that situation


---

### 1207. msg_28466

**You** - 2025-07-04T20:57:26

Like I said will I make it…\. That is the question\.


---

### 1208. msg_28467

**You** - 2025-07-04T20:57:29

lol


---

### 1209. msg_28468

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:57:41

So you are going through pain but then there will be this huge void


---

### 1210. msg_28469

**You** - 2025-07-04T20:57:52

Yeah that will feel better for sure


---

### 1211. msg_28470

**You** - 2025-07-04T20:58:03

Surrounded by nothing but my own failure lol


---

### 1212. msg_28471

**You** - 2025-07-04T20:58:07

SCORE\!\!


---

### 1213. msg_28472

**You** - 2025-07-04T20:58:12

lol


---

### 1214. msg_28473

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:58:23

No not failure, progress


---

### 1215. msg_28474

**You** - 2025-07-04T20:58:57

It doesn’t feel that way it feels like I have been obliterated\. And I am too tired to keep going on like this tbh


---

### 1216. msg_28475

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:59:25

I don’t get why they are being so awful to you still


---

### 1217. msg_28476

**You** - 2025-07-04T20:59:40

Because I am a bastard\.\. I broke the family\.\.


---

### 1218. msg_28477

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:59:41

Isn’t it time to just accept


---

### 1219. msg_28478

**You** - 2025-07-04T20:59:45

Never


---

### 1220. msg_28479

**You** - 2025-07-04T20:59:49

Grudge forever


---

### 1221. msg_28480

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T20:59:53

Did you? It takes 2 to tango


---

### 1222. msg_28481

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:00:03

I don’t blame Andrew fully


---

### 1223. msg_28482

**You** - 2025-07-04T21:00:08

She will fuck off for sure but she will always throw it at me


---

### 1224. msg_28483

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:00:08

I played a role


---

### 1225. msg_28484

**You** - 2025-07-04T21:00:16

Again different people


---

### 1226. msg_28485

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:00:23

Ughhh


---

### 1227. msg_28486

**You** - 2025-07-04T21:00:55

It’s fine not your problem\.\. I told you earlier my my life is shit not worth discussing I just have to get through this as intact as I can get through it\.\.


---

### 1228. msg_28487

**You** - 2025-07-04T21:01:04

Will see what kind of shape I am in then


---

### 1229. msg_28488

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:01:17

Well it is my indirect problem lol


---

### 1230. msg_28489

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:01:28

Your problems are my problems now


---

### 1231. msg_28490

**You** - 2025-07-04T21:01:46

We aren’t going to really see each other likely until after they are gone or well beyond that\.\. so you don’t really need to worry\.


---

### 1232. msg_28491

**You** - 2025-07-04T21:01:59

>
No mer they aren’t\.\.


---

### 1233. msg_28492

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:02:10

If we are in a relationship and it is affecting you, it affects me


---

### 1234. msg_28493

**You** - 2025-07-04T21:02:42

…\.\.


---

### 1235. msg_28494

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:05:11

What is that?


---

### 1236. msg_28495

**You** - 2025-07-04T21:05:35

I don’t know i started to say different things deleted them and then didn’t know what to do


---

### 1237. msg_28496

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:06:01

So are all 3 of them really mad at you or mostly 2?


---

### 1238. msg_28497

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:06:16

Do you want to just go to bed?


---

### 1239. msg_28498

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:06:51

Take 10\-20 mg of melatonin and sleep\. But it will make you drowsy in morning\.  Only shitty part


---

### 1240. msg_28499

**You** - 2025-07-04T21:07:44

I don’t know what I am going to do\.\. you just go do your thing\.


---

### 1241. msg_28500

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:09:52

I’m just sitting drinking


---

### 1242. msg_28501

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:09:54

lol


---

### 1243. msg_28502

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:10:05

Haven’t had dinner so waiting for a piece of pizza


---

### 1244. msg_28503

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:10:27

Oh so Mac cried on Andrew today


---

### 1245. msg_28504

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:10:29

Was great


---

### 1246. msg_28505

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:11:01

She is stressed about Reno and he responds to crying\. She didn’t CRY but was almost\. Wiping her eyes


---

### 1247. msg_28506

**You** - 2025-07-04T21:11:10

Awkward


---

### 1248. msg_28507

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:12:27

He just thinks she is so strong all the time and she is only human too


---

### 1249. msg_28508

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:12:43

I also had to tell him to tell his bro to cool it with the teasing of her


---

### 1250. msg_28509

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:12:57

Reaction: 😢 from Scott Hicks
All he does is tease her about her style etc etc


---

### 1251. msg_28510

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:13:04

He never takes her seriously


---

### 1252. msg_28511

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:13:14

Andrew’s going to talk to him


---

### 1253. msg_28512

**You** - 2025-07-04T21:13:23

I like Mac’s style just feel uncomfortable
Sometimes lol


---

### 1254. msg_28513

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:13:38

Julian just does it to feel close to her but she feels like he is so judgy


---

### 1255. msg_28514

**You** - 2025-07-04T21:13:52

Dumb boys


---

### 1256. msg_28515

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:13:53

>
You likely will all the time


---

### 1257. msg_28516

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:13:55

lol


---

### 1258. msg_28517

**You** - 2025-07-04T21:14:02

We’ll
See


---

### 1259. msg_28518

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:14:16

She just doesn’t like 100% teasing


---

### 1260. msg_28519

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:14:21

And that’s what Julian does


---

### 1261. msg_28520

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:14:27

Never takes her seriously


---

### 1262. msg_28521

**You** - 2025-07-04T21:14:41

Some people are
Like that because they don’t know how
To communicate


---

### 1263. msg_28522

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:15:00

I tease her a lot but I try to take her seriously also


---

### 1264. msg_28523

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:15:53

I think the meeting tonight was helpful to set some expectations for the Reno


---

### 1265. msg_28524

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:16:05

But too bad Maelle isn’t around


---

### 1266. msg_28525

**You** - 2025-07-04T21:16:12

Will see how Monday goes


---

### 1267. msg_28526

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:16:38

What is Monday?


---

### 1268. msg_28527

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:16:43

Ohhhh


---

### 1269. msg_28528

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:16:45

Mediation


---

### 1270. msg_28529

**You** - 2025-07-04T21:16:51

Mediation 50/50 all that shit


---

### 1271. msg_28530

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:17:14

Tonight he was talking as if they will be here 50%


---

### 1272. msg_28531

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:17:31

But then he’s like “no one can be here during water proofing or electrical etc etc”


---

### 1273. msg_28532

**You** - 2025-07-04T21:17:33

That will change


---

### 1274. msg_28533

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:17:33

lol


---

### 1275. msg_28534

**You** - 2025-07-04T21:17:43

So he will be with you


---

### 1276. msg_28535

**You** - 2025-07-04T21:17:45

lol


---

### 1277. msg_28536

**You** - 2025-07-04T21:17:51

Called it


---

### 1278. msg_28537

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:18:00

No he will be here but no kids


---

### 1279. msg_28538

**You** - 2025-07-04T21:18:12

Mm hm


---

### 1280. msg_28539

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:18:19

When we rebuilt the COTTAGE, there was a month or two where he basically lived there full\-time and I was at home with the kids full\-time


---

### 1281. msg_28540

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:19:00

It was tricky because there were some major contractor issues that he was struggling with, so I had to call the contractors and give them shit because he was getting frustrated at not being able to come back to Toronto, and then that kind of helped speed things along


---

### 1282. msg_28541

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:19:16

He is fine with giving me shit and people at work shit but not contractors for some reason


---

### 1283. msg_28542

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:19:25

It’s weird


---

### 1284. msg_28543

**You** - 2025-07-04T21:20:06

I would need to meet him to see
If
I could guage him\. Dunno


---

### 1285. msg_28544

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:20:24

It will be so weird like I can’t even tell you there is no other word for me to describe it


---

### 1286. msg_28545

**You** - 2025-07-04T21:20:34

Different


---

### 1287. msg_28546

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:20:43

Edited: 2 versions
| Version: 2
| Sent: Fri, 4 Jul 2025 21:20:53 \-0400
|
| You guys will meet at volleyball guaranteed
|
| Version: 1
| Sent: Fri, 4 Jul 2025 21:20:43 \-0400
|
| You guys wanna meet at volleyball guaranteed


---

### 1288. msg_28547

**You** - 2025-07-04T21:21:00

Maybe


---

### 1289. msg_28548

**You** - 2025-07-04T21:21:08

Reaction: 😂 from Meredith Lamb
Maybe we never meet


---

### 1290. msg_28549

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:21:10

It will be very  a propos


---

### 1291. msg_28550

**You** - 2025-07-04T21:21:30

I mean who knows


---

### 1292. msg_28551

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:21:38

No, you will have to be around each other sorry


---

### 1293. msg_28552

**You** - 2025-07-04T21:22:05

I feel like you are getting a better break\.


---

### 1294. msg_28553

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:22:14

I totally am


---

### 1295. msg_28554

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:22:25

100%


---

### 1296. msg_28555

**You** - 2025-07-04T21:22:47

Like I am I\. Such a fucking hole and then on the other side\.\. all kinds of bad stuff


---

### 1297. msg_28556

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:23:06

?


---

### 1298. msg_28557

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:23:20

Edit that


---

### 1299. msg_28558

**You** - 2025-07-04T21:24:41

Like I will worry about kids about Andrew about us our relationship being able to see you etc etc \.
Lol\. Here then gone\.\. like it is going to be rough\.\.
You still have a family\.\. and no Jaimie and me available pretty well 24/7 lol\.


---

### 1300. msg_28559

**You** - 2025-07-04T21:25:34

Anyhow not getting into this again\.\. I am going to go to bed before we start
Digging\.


---

### 1301. msg_28560

**You** - 2025-07-04T21:25:55

I am sure you have pizza wine and other things to do more fun than this anyways


---

### 1302. msg_28561

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:29:40

I do have a family but you do too\. And my family will be very accepting of you\. They have been so far\. So I don’t see any issues on my end once I can freaking tell them\. It is going to be on your end\. With Jaimie being upset if I meet your kids\.
Ok you can go to bed ❤️ love you


---

### 1303. msg_28562

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:41:08

For the record, worried about you\. 🙁


---

### 1304. msg_28563

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:47:20

Scott…\.\.


---

### 1305. msg_28564

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T21:54:40

You are reading my messages and not responding


---

### 1306. msg_28565

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:02:53

Scott……\.


---

### 1307. msg_28566

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:11:48

k what is happening, I know you aren’t likely sleeping\.


---

### 1308. msg_28567

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:12:17

I had a gummy 45 min ago\. Put me out of my confused misery


---

### 1309. msg_28568

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:12:22

lol


---

### 1310. msg_28569

**You** - 2025-07-04T22:25:14

Mmm


---

### 1311. msg_28570

**You** - 2025-07-04T22:25:29

I don’t think I was reading hon


---

### 1312. msg_28571

**You** - 2025-07-04T22:25:43

Since I was sleeping sorry


---

### 1313. msg_28572

**You** - 2025-07-04T22:27:24

Reaction: ❤️ from Meredith Lamb
I think you might be a bit something sorry wasn’t ignoring\.\. pulled a you and had a nap\.\. who knows what you are up to now so might not get a response


---

### 1314. msg_28573

**You** - 2025-07-04T22:28:10

Reaction: 😢 from Meredith Lamb
Anyways I am worried about me to Mer honestly glad you took a gummy that always helps\.


---

### 1315. msg_28574

**You** - 2025-07-04T22:28:45

Well have a good night ❤️ firing on all cylinders tonight aren’t we…\.\.


---

### 1316. msg_28575

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:31:07

Ok I’m glad you were asleep\. All good\. Xoxo


---

### 1317. msg_28576

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:31:21

You only have 2 weeks


---

### 1318. msg_28577

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:31:25

You can do that


---

### 1319. msg_28578

**You** - 2025-07-04T22:32:34

Yep all is well lol night xo\.


---

### 1320. msg_28579

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:34:20

Nite 😢❤️❤️


---

### 1321. msg_28580

**You** - 2025-07-04T22:38:54

Same


---

### 1322. msg_28581

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:42:14

Just know that I wish I was with you right now too


---

### 1323. msg_28582

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T22:45:46

And I wish you were in a better mood before bed


---

### 1324. msg_28583

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T23:17:42

Heads of state = 👎


---

### 1325. msg_28584

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T23:17:52

Just finished


---

### 1326. msg_28585

**Meredith Lamb \(\+14169386001\)** - 2025-07-04T23:43:14

Reaction: ❤️ from Scott Hicks
I’m going to bed now\. Gpt helped me write this for you:
Scott is sleeping on a Friday night,
While Mer drinks wine, avoiding a fight\.
The distance between them is plain in sight,
The longing swelling with quiet might\.
She lies on the couch in dim, soft light,
Craving his hands to make it right\.
The ache is more than just desire—
It’s needing him to stoke the fire\.
The night drips slow like candle wax,
Memories playing on heart\-worn tracks\.
She wonders if he dreams of her too—
Or if she’s fading in his view\.
But even through silence, space, and time,
Their hearts stay tethered, still in rhyme\.
No matter the distance, storm, or weather—
They’re bound by love, always, forever\.


---

### 1327. msg_28586

**You** - 2025-07-05T00:15:04

I will be forever in love with you Mer\.\. it’s true… and the movie was meh\.


---

### 1328. msg_28587

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:16:33

Reaction: ❤️ from Scott Hicks
❤️
Bad movie\. Lol I’m passing out momentarilyZzzzz…\.


---

### 1329. msg_28588

**You** - 2025-07-05T00:16:59

I will be going back to sleep soon


---

### 1330. msg_28589

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:17:53

Soon …\. You only have 4 hrs hop to it 😛


---

### 1331. msg_28590

**You** - 2025-07-05T00:18:51

>
I have slept already I will be fine


---

### 1332. msg_28591

**You** - 2025-07-05T00:21:34

Go to sleep knowing that what happened last weekend will only ever happen with you\.\. and that I always have the image of your face from that night in my mind\.\. I love only you\.\. we just have to figure out a few small details before we can chase forever together\.


---

### 1333. msg_28592

**You** - 2025-07-05T00:21:44

❤️❤️❤️


---

### 1334. msg_28593

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:22:38

Reaction: ❤️ from Scott Hicks
I had a bottle and a half of wine and a gummy so being reminded about last weekend isn’t helpful right now lol but I love you


---

### 1335. msg_28594

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:23:09


*1 attachment(s)*


---

### 1336. msg_28595

**You** - 2025-07-05T00:23:59

Just go with wherever the thoughts take you and have a good sleep\.


---

### 1337. msg_28596

**You** - 2025-07-05T00:24:04

Boo


---

### 1338. msg_28597

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:25:28

lol


---

### 1339. msg_28598

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:28:18

k, I’m going to go to bed for real unless you are awake and can’t sleep lol


---

### 1340. msg_28599

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:28:36

🤔


---

### 1341. msg_28600

**You** - 2025-07-05T00:28:59

lol why the thinking face


---

### 1342. msg_28601

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:29:15

Just wondering if you are awake or going back to sleep


---

### 1343. msg_28602

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:29:32

Seriously curious


---

### 1344. msg_28603

**You** - 2025-07-05T00:29:38

I can do either was waiting on you tbh


---

### 1345. msg_28604

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:29:54

Because when we are together and we go to sleep, we go to sleep


---

### 1346. msg_28605

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:30:00

No waking


---

### 1347. msg_28606

**You** - 2025-07-05T00:30:18

I know except when I wake up early


---

### 1348. msg_28607

**You** - 2025-07-05T00:30:29

And watch you sleep


---

### 1349. msg_28608

**You** - 2025-07-05T00:30:42

And say nice things to you


---

### 1350. msg_28609

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:30:30

Well yeah given


---

### 1351. msg_28610

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:30:50

Used to that now


---

### 1352. msg_28611

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:31:01

I mean I don’t hate it


---

### 1353. msg_28612

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:31:06

You bring coffee


---

### 1354. msg_28613

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:31:08

lol


---

### 1355. msg_28614

**You** - 2025-07-05T00:31:17

I try lol


---

### 1356. msg_28615

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:31:37

Watching 😵‍💫


---

### 1357. msg_28616

**You** - 2025-07-05T00:31:56

It isn’t weird it is a love thing


---

### 1358. msg_28617

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:32:07

k…


---

### 1359. msg_28618

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:32:32

<nods head>


---

### 1360. msg_28619

**You** - 2025-07-05T00:33:06

lol it is you are peaceful and beautiful and just\.\. you\.


---

### 1361. msg_28620

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:33:29

Very peaceful


---

### 1362. msg_28621

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:33:45

Reaction: ❤️ from Scott Hicks
Dreaming of murder or something probably


---

### 1363. msg_28622

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:33:47

lol


---

### 1364. msg_28623

**You** - 2025-07-05T00:33:59

And very beautiful Mer\. Don’t forget that\.


---

### 1365. msg_28624

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:34:59

Wanna come over?


---

### 1366. msg_28625

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:35:05

Kidding lol


---

### 1367. msg_28626

**You** - 2025-07-05T00:35:12

lol


---

### 1368. msg_28627

**You** - 2025-07-05T00:35:36

Wish\.\. some other time


---

### 1369. msg_28628

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:35:41

Marlowe in my room\. Andrew downstairs lol


---

### 1370. msg_28629

**You** - 2025-07-05T00:37:35

Reaction: ❤️ from Meredith Lamb
Listen you go to sleep… I am going to try to shut back down again\.\. might be a bit challenging given our discussion but I will figure it out\.


---

### 1371. msg_28630

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T00:38:19

k I’m passing out for sure zzzz … gnite miss u 😢


---

### 1372. msg_28631

**You** - 2025-07-05T00:38:54

Night I love you and miss you always\.🥲


---

### 1373. msg_28632

**You** - 2025-07-05T05:01:35

Well wine and gummies to the rescue again\.  Thanks for picking me up out of my hole Mer\.  I wish it would be the last one, but my life sure has not been blessed outside of my time with you\.


---

### 1374. msg_28633

**You** - 2025-07-05T05:09:43

I guess I better get going to get my morning run in\. This won’t be a heavy workout day because that is tomorrow\.  I asked j to get up early this morning to work so will see how that goes\.\. not sure what your day looks like but I hope it is a good one\.  If timing and weather allow would love to see you Monday and/or Tuesday for a few mins at park\.\. because again I think we might be in store for a drought as it relates to seeing each other and it might be by far the worst one yet\.  I always seem to fair worse in those\.  We’ll see\.  Anyway up I get seize the day and all that shit\.  Love you Mer\. Will be thinking about you today no matter what I am doing or where I am at\.


---

### 1375. msg_28634

**You** - 2025-07-05T07:14:13

Fasted 40 min interval sprint / jog / walk program 850 cals \+ core workout… absolutely done…\.\.


---

### 1376. msg_28635

**You** - 2025-07-05T07:22:47

Down to 220\.\. but lost a bit of muscle mass\.\. no surprise after last weekend and all
The wine lol


---

### 1377. msg_28636

**You** - 2025-07-05T07:36:15

Reaction: ❤️ from Meredith Lamb
Tomorrow should be better

*1 attachment(s)*


---

### 1378. msg_28637

**You** - 2025-07-05T07:36:57

Could use a pic of you\.\. just saying\.  Hope you slept well\.


---

### 1379. msg_28638

**You** - 2025-07-05T08:25:29

Hey one other thing\.\. I feel a bit weird but the Andrew thing is bothering me too… would it bother you if Jaimie was suddenly really nice to me like that\.\. am I in my own head again on this?


---

### 1380. msg_28639

**You** - 2025-07-05T08:29:40

Lots to read no skipping\.


---

### 1381. msg_28640

**You** - 2025-07-05T08:58:16

And now off to taxi my wife around\.\. who wouldn’t want to stay in my life atm god I don’t know\. Eeesh


---

### 1382. msg_28641

**You** - 2025-07-05T09:00:03

Edited: 2 versions
| Version: 2
| Sent: Sat, 5 Jul 2025 09:08:03 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Sat, 5 Jul 2025 08:25:29 \-0400
| >
| > Hey one other thing\.\. I feel a bit weird but the Andrew thing is bothering me too… would it bother you if Jaimie was suddenly really nice to me like that\.\. am I in my own head again on this?
|
| I know you want to be amicable I get it just weird feeling…………\.\.
|
| Version: 1
| Sent: Sat, 5 Jul 2025 09:00:03 \-0400
|
| > From: Scott Hicks \(\+14165572392\)
| > Sent: Sat, 5 Jul 2025 08:25:29 \-0400
| >
| > Hey one other thing\.\. I feel a bit weird but the Andrew thing is bothering me too… would it bother you if Jaimie was suddenly really nice to me like that\.\. am I in my own head again on this?
|
| I know you want to be amicable I get it just weird feeling\.


---

### 1383. msg_28642

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:13:31


*1 attachment(s)*


---

### 1384. msg_28643

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:16:08


*1 attachment(s)*


---

### 1385. msg_28644

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:18:22

>
Happy to do park Monday


---

### 1386. msg_28645

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:20:43

I’m just waking up lol


---

### 1387. msg_28646

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:29:46


*1 attachment(s)*


---

### 1388. msg_28647

**You** - 2025-07-05T10:31:09

Reaction: 😬 from Meredith Lamb
Just at sparkle
Light now


---

### 1389. msg_28648

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:34:18

My towels from Etsy

*1 attachment(s)*


---

### 1390. msg_28649

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T10:35:24

>
Maybe try Home Depot or lowes lol


---

### 1391. msg_28650

**You** - 2025-07-05T10:42:41

>
lol cute


---

### 1392. msg_28651

**You** - 2025-07-05T10:42:49

>
Nope done here


---

### 1393. msg_28652

**You** - 2025-07-05T10:43:14

Will have some questions for you later hard to read and do this


---

### 1394. msg_28653

**You** - 2025-07-05T10:43:48

Sorry bout all the shit you had not resd


---

### 1395. msg_28654

**You** - 2025-07-05T12:05:20

Read was what I meant


---

### 1396. msg_28655

**You** - 2025-07-05T12:05:24

At Costco now


---

### 1397. msg_28656

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T12:06:56

You guys and your Costco …\.


---

### 1398. msg_28657

**You** - 2025-07-05T12:07:58

No this whole day has been shot


---

### 1399. msg_28658

**You** - 2025-07-05T12:08:00

Shit


---

### 1400. msg_28659

**You** - 2025-07-05T12:08:04

Hope yours is better


---

### 1401. msg_28660

**You** - 2025-07-05T12:08:10

Hard to tell from your messages


---

### 1402. msg_28661

**You** - 2025-07-05T12:08:41

Back to it will text
You when I get home and have a moment to rest before working in basement


---

### 1403. msg_28662

**You** - 2025-07-05T12:08:48

Love you\.


---

### 1404. msg_28663

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T12:12:41

My day is fine\. Just hanging with Mac\. But now Mac mar and I are going to structube and homesense


---

### 1405. msg_28664

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T12:12:59

Reaction: ❤️ from Scott Hicks
Love u too and just miss u


---

### 1406. msg_28665

**You** - 2025-07-05T13:13:22

Just got home you are probably out


---

### 1407. msg_28666

**You** - 2025-07-05T13:16:46

So butchers bill 2300


---

### 1408. msg_28667

**You** - 2025-07-05T13:16:51

From sparkle light


---

### 1409. msg_28668

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T13:16:57

Huh?????


---

### 1410. msg_28669

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T13:17:24

At Marshall’s getting Mac a business casual outfit\. She is doing a law course at u of t next week


---

### 1411. msg_28670

**You** - 2025-07-05T13:17:30

Bought new entry way dining and kitchen lights 4 pendants and a light above the bath\.


---

### 1412. msg_28671

**You** - 2025-07-05T13:17:36

Cool


---

### 1413. msg_28672

**You** - 2025-07-05T13:17:41

Needs to look sharp


---

### 1414. msg_28673

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T13:17:50

Wow quite a bill


---

### 1415. msg_28674

**You** - 2025-07-05T13:17:54

Yeah


---

### 1416. msg_28675

**You** - 2025-07-05T13:17:57

There will
Be more


---

### 1417. msg_28676

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T13:18:05

😬


---

### 1418. msg_28677

**You** - 2025-07-05T13:18:10

Reaction: ❤️ from Meredith Lamb
Glad
You don’t love me
For my money


---

### 1419. msg_28678

**You** - 2025-07-05T13:18:19

Cause I don’t have any anymore


---

### 1420. msg_28679

**You** - 2025-07-05T13:18:20

lol


---

### 1421. msg_28680

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T13:47:02


*1 attachment(s)*


---

### 1422. msg_28681

**You** - 2025-07-05T14:35:20

yep accurate


---

### 1423. msg_28682

**You** - 2025-07-05T14:35:23

well played


---

### 1424. msg_28683

**You** - 2025-07-05T14:35:56

wierd I am just getting this now but it says it was sent 48 min ago


---

### 1425. msg_28684

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:30:51

We bought lots of “getting started” stuff and dropped it off at house\. Girls seemed in good spirits


---

### 1426. msg_28685

**You** - 2025-07-05T15:31:24

awesome\.\. what kind of spirits are you in


---

### 1427. msg_28686

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:40:37

Just busy mode\. Grocery shopping now\. Gotta walk dogs


---

### 1428. msg_28687

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:40:49

You?


---

### 1429. msg_28688

**You** - 2025-07-05T15:41:16

just finished a movie\.\. messing around with GPT\.\. J is going out to drive maddie somewhere coming back and basement work\.


---

### 1430. msg_28689

**You** - 2025-07-05T15:41:31

and of course thinking about you\.\. like I said this morning\.\., all day


---

### 1431. msg_28690

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:42:08

I’m looking forward to chilling soon\. Bit hungover today lol


---

### 1432. msg_28691

**You** - 2025-07-05T15:42:19

yeah you were pretty messed last night\.


---

### 1433. msg_28692

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:42:23

I have to get up early tomorrow so no shenanigans tonight


---

### 1434. msg_28693

**You** - 2025-07-05T15:42:36

yeah vball outside half the day


---

### 1435. msg_28694

**You** - 2025-07-05T15:42:37

fun


---

### 1436. msg_28695

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:43:11

>
“Messed” or “perfectly relaxed” lol


---

### 1437. msg_28696

**You** - 2025-07-05T15:43:20

you were messed up


---

### 1438. msg_28697

**You** - 2025-07-05T15:43:22

sry


---

### 1439. msg_28698

**You** - 2025-07-05T15:43:30

but mostly in a good way


---

### 1440. msg_28699

**You** - 2025-07-05T15:43:32

you helped me\.


---

### 1441. msg_28700

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:43:58

lol that’s a sign\. You should have had a few drinks


---

### 1442. msg_28701

**You** - 2025-07-05T15:44:10

no\.\. it won't help me if I do that Mer\.\.


---

### 1443. msg_28702

**You** - 2025-07-05T15:44:14

it will be like the drugs


---

### 1444. msg_28703

**You** - 2025-07-05T15:44:23

I feel too alone\.\. it will drag me down


---

### 1445. msg_28704

**You** - 2025-07-05T15:44:30

sry\.\. I am not like you that way


---

### 1446. msg_28705

**You** - 2025-07-05T15:44:35

wish I was


---

### 1447. msg_28706

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:45:38

Nothing wrong with being alone\. Lol


---

### 1448. msg_28707

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:45:53

I actually stayed in the room with Andrew and Marlowe for that whole awful movie


---

### 1449. msg_28708

**You** - 2025-07-05T15:46:04

there wasn't about 5 months ago


---

### 1450. msg_28709

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:46:14

Got drunker and drunker and drunker lol


---

### 1451. msg_28710

**You** - 2025-07-05T15:46:39

well at least it was fun\.\. I cannot be in room with them without a fight\.\.


---

### 1452. msg_28711

**You** - 2025-07-05T15:46:48

Reaction: 😮 from Meredith Lamb
fight in car today all the way to lighting store\.\. so tired\.


---

### 1453. msg_28712

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:46:56

Used to be that way but Andrew is diff now


---

### 1454. msg_28713

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:47:07

Why so much fighting?


---

### 1455. msg_28714

**You** - 2025-07-05T15:47:20

I am glad for you it must make it easier\.\. still makes me feel all weird but cannot help it\.


---

### 1456. msg_28715

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:47:23

Just like final day anxiety?\!


---

### 1457. msg_28716

**You** - 2025-07-05T15:47:39

I dunno mer\.\. I have given up trying to figure it out\.


---

### 1458. msg_28717

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:47:46

>
You’d rather he be nasty to me? Lol


---

### 1459. msg_28718

**You** - 2025-07-05T15:48:00

No but you would be equally sketched if J were doing same thing\.


---

### 1460. msg_28719

**You** - 2025-07-05T15:48:11

I just want you to understand not for it to change


---

### 1461. msg_28720

**You** - 2025-07-05T15:48:35

anyhow go do your stuff\. you are busy\.\. get it all done so you can chill etc\.


---

### 1462. msg_28721

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:51:18

>
But u guys do so much together


---

### 1463. msg_28722

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T15:51:38

We do like zero together ever


---

### 1464. msg_28723

**You** - 2025-07-05T15:52:09

>
it is not because I want to\.\. it is because I feel like I have to\.\. and then I get tortured\.\. I don't have a choice\. If I say no it blows up if I go it blows up\.\. it will likely blow up again in basement this aft\.


---

### 1465. msg_28724

**You** - 2025-07-05T15:52:56

Reaction: 😮 from Meredith Lamb
We talked about kids again\.\. she is telling me they both now might be staying\.\. I am like how do I get the house done, the renos, staging, work etc and deal with Gracie and her stuff\.\. like there is no plan no thought no consideration\.


---

### 1466. msg_28725

**You** - 2025-07-05T15:53:31

Anyhow you go do your stuff\.\. I am going to sign off for now\.\. maybe I will check in later\.\. I won't have anything good to share I am sure anyways\.


---

### 1467. msg_28726

**You** - 2025-07-05T15:53:33

ttyl


---

### 1468. msg_28727

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T16:10:15

>
When you say “staying” do you mean sept onwards or like staying for the summer even\.


---

### 1469. msg_28728

**You** - 2025-07-05T16:11:46

Summer sept I dunno I pushed back\.


---

### 1470. msg_28729

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T16:15:01

Well hopefully it works out\. Time is running out so you will be there soon and at least know what is going on


---

### 1471. msg_28730

**You** - 2025-07-05T16:24:20

All I am looking for is a path forward for my life and for Maddie’s to be slightly easier and I don’t see one\. It’s fine just
Going to work now\.


---

### 1472. msg_28731

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T16:33:40

Even if it isn’t clear now it will work out \- especially because we will be in it together\. You won’t be alone
I’m going to try to have a nap before dinner lol


---

### 1473. msg_28732

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T18:34:54

Everything good?


---

### 1474. msg_28733

**You** - 2025-07-05T18:42:44

Still here


---

### 1475. msg_28734

**You** - 2025-07-05T18:45:10

Eating and leaving soon though


---

### 1476. msg_28735

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T18:46:11

Well hope it’s going ok


---

### 1477. msg_28736

**You** - 2025-07-05T18:57:43

Super 👍


---

### 1478. msg_28737

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:16:02

A word you use often…


---

### 1479. msg_28738

**You** - 2025-07-05T19:19:31

Yep especially when I mean it\.


---

### 1480. msg_28739

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:26:31

Sigh\. You are half way through the weekend\. 🙃


---

### 1481. msg_28740

**You** - 2025-07-05T19:35:04

Deleted…\.\. instead… yep\.


---

### 1482. msg_28741

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:42:06

The deleted was some down in a hole depressing message?


---

### 1483. msg_28742

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:42:22

“Yep” is the cheerier response?


---

### 1484. msg_28743

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:42:26

lol


---

### 1485. msg_28744

**You** - 2025-07-05T19:42:40

Yep is as good as it gets


---

### 1486. msg_28745

**You** - 2025-07-05T19:43:51

Actually yep is more like it doesn’t really matter\.\. to be more accurate


---

### 1487. msg_28746

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:48:32

Zero response\. Sorry lol


---

### 1488. msg_28747

**You** - 2025-07-05T19:49:02

Yeah I know why don’t you got enjoy yourself I am taxing kids then gym sauna shower home and fuck it\.


---

### 1489. msg_28748

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T19:53:11

I don’t like it when you always tell me to go “enjoy myself” :p I will go but I may not enjoy myself…\.


---

### 1490. msg_28749

**You** - 2025-07-05T20:05:35

Sure you will I know and have faith in you\.\.


---

### 1491. msg_28750

**You** - 2025-07-05T20:06:02

I only tell you to go because I am a miserable sack and you don’t need any of this\.


---

### 1492. msg_28751

**You** - 2025-07-05T20:07:25

When I don’t see a light it gets like this


---

### 1493. msg_28752

**You** - 2025-07-05T20:07:32

And that is where I am


---

### 1494. msg_28753

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T20:12:11

Okay\. Well maybe gym sauna will make you feel better xo


---

### 1495. msg_28754

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T21:41:58

Reaction: ❤️ from Scott Hicks
This is my I’m worried about Scott photo\. He’s been short and pushing me away all day and I just want him to know that I’m here even if he doesn’t want to talk\. ❤️ going to bed soon…\. So saying g’nite xo

*1 attachment(s)*


---

### 1496. msg_28755

**You** - 2025-07-05T21:42:35

Mer if you want to talk about anything but me\.\. I am for it\.


---

### 1497. msg_28756

**You** - 2025-07-05T21:44:14

But there is nothing here to talk about\.\. talk about your day, what you bought how the kids are, what the fuck were those texts this morning and how did that start up\.\. but how I am feeling is shitty\.\. I don't feel optimistic, I don't feel happy, and this environment is just getting worse\.\. so again\.\. me piling my problems onto you only makes you feel worse and I don't want that\.


---

### 1498. msg_28757

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T21:44:17

Edited: 2 versions
| Version: 2
| Sent: Sat, 5 Jul 2025 21:44:24 \-0400
|
| It’s okay
|
| Version: 1
| Sent: Sat, 5 Jul 2025 21:44:17 \-0400
|
| It’s oksy


---

### 1499. msg_28758

**Meredith Lamb \(\+14169386001\)** - 2025-07-05T21:45:03

I am going to bed soon so I can survive the heat tomorrow


---

### 1500. msg_28759

**You** - 2025-07-05T21:45:11

Reaction: ❤️ from Meredith Lamb
kk well if you going to bed I guess I will say good night too\.\. xo


---

