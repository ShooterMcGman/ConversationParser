# Week 6: Conversation Messages

**Date Range:** 2025-05-18 to 2025-05-24  
**Total Messages:** 1438  
**Generated:** 2025-07-18 21:27:05

---

## 📊 Week Summary

- **Week Number:** 6
- **Messages:** 1438
- **Participants:** 2
- **Message Types:** incoming, outgoing, call-history

## 💬 Conversation Messages

### 1. msg_11647

**Meredith Lamb \(\+14169386001\)** - 2025-05-18T11:41:50

Thankful to everyone except me because I made things harder\. :p

*1 attachment(s)*


---

### 2. msg_11648

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T17:50:27

Just leaving for home now ❤️


---

### 3. msg_11649

**You** - 2025-05-19T18:31:31

I just got home now\.\. talked the whole way had some interesting conversations will share later\.\. if you have any energy and don’t fall straight to sleep\.


---

### 4. msg_11650

**You** - 2025-05-19T18:31:41

I hope I didn’t leave yku with too much to do…


---

### 5. msg_11651

**You** - 2025-05-19T18:33:34

Love you too btw had the best time with you\.\. all of it\.\. I hope there are many more years of that in front of us\.


---

### 6. msg_11652

**You** - 2025-05-19T18:33:41

❤️


---

### 7. msg_11653

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T21:10:34

Home and waiting for bo’s parents and talking to my parents\.


---

### 8. msg_11654

**You** - 2025-05-19T21:35:39

glad you got home ok\.\. just puttering around here\.


---

### 9. msg_11655

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T21:53:59

So who did you talk to?


---

### 10. msg_11656

**You** - 2025-05-19T21:54:07

Straight to it eh\.\.


---

### 11. msg_11657

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T21:54:26

lol


---

### 12. msg_11658

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T21:54:29

Just sat down


---

### 13. msg_11659

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T21:54:56

Watching Conan OBrien Must Go


---

### 14. msg_11660

**You** - 2025-05-19T21:56:15

I am just doing a bit of research\.\. got my shit all good to go for tomorrow morning\.


---

### 15. msg_11661

**You** - 2025-05-19T21:56:31

trying to plan my day tomorrow\.\. and then the rest of the week\.


---

### 16. msg_11662

**You** - 2025-05-19T22:07:17

I spoke with Katie, Michael, And Deborah\.


---

### 17. msg_11663

**You** - 2025-05-19T22:09:45

Katie and I spoke for a while\.\. she asked a lot of questions, liked the answers\.\. and was genuinely happy for me\.  She is not a fan of Jaimie, and never really was, always thought a bad match\.  She was curious as to what next\.\. I advised we are all just trying to figure that out\.\. but first and foremost we have to get our own shit out of the way\.  She creeped you on my facebook friends, and gave a thumbs up\.


---

### 18. msg_11664

**You** - 2025-05-19T22:10:37

Mike and I chatted for about 15\-20 minutes\.\. he just wanted to catch up\.\. was curious how the weekend, went, was happy for me\.\. we talked about my potential living situation options that I should consider for later on this year, and depending on what I want to do in the long term\.


---

### 19. msg_11665

**You** - 2025-05-19T22:11:39

Deborah spoke for about 1\.5 hours\.\. Deb is Mikes mom\.\. and is as close to a second mom as I have\.  She knows me almost as well as Shawnee and her and I were really close all through my teenage years, up until I essentially married Jaimie\.\. again she did not approve\.


---

### 20. msg_11666

**You** - 2025-05-19T22:13:25

Deb had a lot to say about my situation\.\. we went into a lot of detail about my relationship at home, how it got to where it got to, our history, how we got to where we got to, she also creeped you lol\.\. says you are beautiful, and can tell your personality from your smile lines\.  She says if I described you accurately, she is not surprised I connected with you the way I did\.  However\.


---

### 21. msg_11667

**You** - 2025-05-19T22:16:15

She is very worried\.\. we talked a lot about pre 17 year old me and post\.\. again she knew everything about me back then\.\. She says she remembers the change in me and what triggered it, and remembers how hurt I was prior to making that change\.  She said she was happy for me at the time, because I had had some really bad luck, and I got hurt pretty horribly\.\. she felt that I was better off protecting myself for a while\.  When she heard me talking to her tonight\.\. and sharing with her what we had talked about\.\. she is worried I am going to get hurt again\.  I told her she had nothing to worry about\.\. she said I was being naive, and needed to be more careful\.  I asked her if she believed in soul mates, and she said she did\.\. I said this is mine\.


---

### 22. msg_11668

**You** - 2025-05-19T22:19:30

We talked for a while longer\.\. she is still worried\.\. she said everyone has history and stories, and other lives they have lived previously\.\. she said everything is much more complicated than I am trying to make it seem\.  For instance\.\. following the death of Ian, instead of moving forward with someone new, who she was beginning to get involved with, she reconnected with a high school sweetheart and lived with him for about 10 years\.\. before he passed\.  Neither death was attributed to her\.\. and she felt that was a mistake looking back but people tend to go to what is familiar she said\.  Anyways, I am sure she is just really concerned for me, she remembers what I was like, so I get it\.  But I told her we were fine, we were plotting through this, and as time progressed I felt more comfortable and less concerned about getting hurt\.  Anyways deep conversations\.\. kept me busy pretty much the entire drive\.


---

### 23. msg_11669

**You** - 2025-05-19T22:20:08

KK I am done typing lol you either went to sleep or got busy\.\. I will wait until you read before getting into anything else\.


---

### 24. msg_11670

**You** - 2025-05-19T22:20:32

If I don't hear back from you in 10 mins though, going to go to bed\.\. don't want to be up too late\.


---

### 25. msg_11671

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:23:15

Sorry was cleaning kitchen and got distracted


---

### 26. msg_11672

**You** - 2025-05-19T22:25:24

All good\.\. just didn’t want you to come back and wonder where I went\.


---

### 27. msg_11673

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:27:08

Wow that was a lot of conversations


---

### 28. msg_11674

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:27:11

Holy


---

### 29. msg_11675

**You** - 2025-05-19T22:27:22

Reaction: ❤️ from Meredith Lamb
Well you like details


---

### 30. msg_11676

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:27:44

I feel like I should check what ppl can see on my Facebook\. A few years ago I deleted a lot so I don’t have much to ppl that aren’t friends


---

### 31. msg_11677

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:27:49

\(I don’t think\)


---

### 32. msg_11678

**You** - 2025-05-19T22:28:07

I don’t think there is anything there to be concerned with


---

### 33. msg_11679

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:28:19

I’m not understanding the familiar thing


---

### 34. msg_11680

**You** - 2025-05-19T22:28:36

Hrmmm what familiar thing


---

### 35. msg_11681

**You** - 2025-05-19T22:29:24

There was a lot there lol you will need to be specific


---

### 36. msg_11682

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:29:51

Deborah said she went with what was familiar and regrets it


---

### 37. msg_11683

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:29:59

Was she warning you of that?


---

### 38. msg_11684

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:30:18

Everyone is like REBOUND


---

### 39. msg_11685

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:30:21

lol


---

### 40. msg_11686

**You** - 2025-05-19T22:31:29

Yes she said many people tend to look back at what was comforting prior to the last
Relationship to reconnect with something that was happier\.\. that was how her and Chet connected\.  I cannot Remeber who she was seeing when Chet came back on the scene\.  But he was gone pretty quick lol


---

### 41. msg_11687

**You** - 2025-05-19T22:32:00

>
Not sure what you meant here


---

### 42. msg_11688

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:32:14

I feel like she was warning you of rebounding


---

### 43. msg_11689

**You** - 2025-05-19T22:32:19

No


---

### 44. msg_11690

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:32:21

Just different words


---

### 45. msg_11691

**You** - 2025-05-19T22:32:42

Rebounding is jumping in too fast she warned me of that too but I rebuffed her there this is different


---

### 46. msg_11692

**You** - 2025-05-19T22:33:21

This is about getting in too fast people having second thoughts which is what she did\.\. admittedly regretting it also lol


---

### 47. msg_11693

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:34:08

>
What did you say to this? Curious


---

### 48. msg_11694

**You** - 2025-05-19T22:34:08

That is the looking back piece she meant I think\. Anyways\.\. she just worries about me is all\.


---

### 49. msg_11695

**You** - 2025-05-19T22:35:18

She asked me about what I knew of you previous\.\. I said you had been pretty open and to some degree had a similarly adventurous time for a number of years\.\. which we agreed so did I even though it was a bit different and a bit younger than you\.


---

### 50. msg_11696

**You** - 2025-05-19T22:36:21

She did not ask if I thought you would do what she did\.\. she just warned me to be careful and maybe not to be so open\.\. which again I said I wasn’t sure I could do that\.\. I feel what I feel and I am where I am\.  And honestly I don’t want to change it even if I do get hurt\.


---

### 51. msg_11697

**You** - 2025-05-19T22:37:08

She just thinks that usually after a big split people can do crazy things\.\. she has seen it happen\. And sometimes others get hurt\.\. it didn’t really phase me tbh\.


---

### 52. msg_11698

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:38:47

Interesting\. Yeah it doesn’t phase me either\. Our situation feels different because we have gotten to know each other slowly over 3 years\.


---

### 53. msg_11699

**You** - 2025-05-19T22:38:48

I did tell her you might be feeling same way as me\.


---

### 54. msg_11700

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:38:59

I might be? Lol


---

### 55. msg_11701

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:39:10

You’re a good


---

### 56. msg_11702

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:39:17

Goof


---

### 57. msg_11703

**You** - 2025-05-19T22:39:28

I meant insecure and worried


---

### 58. msg_11704

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:39:55

Ah yeah


---

### 59. msg_11705

**You** - 2025-05-19T22:40:20

And I did tell here that was a huge difference that we are friends\.\. and that having that as a base is a big deal\.


---

### 60. msg_11706

**You** - 2025-05-19T22:41:04

Anyways she loves me, and is just worried\.\. she had was saw everything close
Up for years and years\.  She wasn’t overly happy when I changed


---

### 61. msg_11707

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:41:24

Is your sister worried?


---

### 62. msg_11708

**You** - 2025-05-19T22:43:51

Umm


---

### 63. msg_11709

**You** - 2025-05-19T22:44:07

She is happy for me but yeah
Worried\.


---

### 64. msg_11710

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:44:42

Worried specifically about you getting hurt?


---

### 65. msg_11711

**You** - 2025-05-19T22:44:44

I mean don’t take it personally lol


---

### 66. msg_11712

**You** - 2025-05-19T22:44:47

Yeah


---

### 67. msg_11713

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:44:51

lol wow


---

### 68. msg_11714

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:45:04

No one is worried about me in that specific way lol


---

### 69. msg_11715

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:45:14

What’s that say?


---

### 70. msg_11716

**You** - 2025-05-19T22:45:15

Mer they had a front row seat to me getting run over three times I\. A row


---

### 71. msg_11717

**You** - 2025-05-19T22:45:25

Before I shut down


---

### 72. msg_11718

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:45:29

Okay makes sense then


---

### 73. msg_11719

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:45:40

I will not run you over


---

### 74. msg_11720

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:45:49

😜


---

### 75. msg_11721

**You** - 2025-05-19T22:46:50

Mer I don’t think you would ever do anything intentionally to hurt me but I’ve is very complicated and you have priorities\.  You might feel like there is a better choice given your circumstances, I couldn’t hold
It against you if you were doing the best you could for you and the kids\.


---

### 76. msg_11722

**You** - 2025-05-19T22:47:48

I am not worried\.\. I am just being honest\.


---

### 77. msg_11723

**You** - 2025-05-19T22:47:57

Not whining either


---

### 78. msg_11724

**You** - 2025-05-19T22:48:02

Just sighing


---

### 79. msg_11725

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:48:52

Listen, a person can have multiple priorities in life and you have become one of mine\.


---

### 80. msg_11726

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:49:05

So just understand that


---

### 81. msg_11727

**You** - 2025-05-19T22:50:00

No I appreciate it\.\. you are def in my priority list\.  Look if this whole conversation thing bothers you… please just reference the one thing that mattered that I said to deb\.


---

### 82. msg_11728

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:51:26

It doesn’t bother me at all\. I’m glad you have people that care about your well being\.


---

### 83. msg_11729

**You** - 2025-05-19T22:54:16

She was impressed
When I described your choices
For your children, how you behaved how in many ways you were like Shawnee\.  She
Said that always bothered her about j and I because she was nothing like that\.\. Katie said same thing\.\. so I think she is cautiously hopeful for us\.


---

### 84. msg_11730

**You** - 2025-05-19T22:55:03

>
I am not sure we had similar experiences\.\. maybe we did and you just
Dealt better\.


---

### 85. msg_11731

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:58:18

I don’t think we did in that area\.


---

### 86. msg_11732

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T22:58:41

I’m glad there is cautious hope\. Better than no hope I guess\! Lol


---

### 87. msg_11733

**You** - 2025-05-19T22:59:54

I didn’t say I had no hope\.\. they are just worried about me and they don’t know you\. I have lots of hope\.\.


---

### 88. msg_11734

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:03:36

They won’t spill the beans I assume\.


---

### 89. msg_11735

**You** - 2025-05-19T23:03:58

No


---

### 90. msg_11736

**You** - 2025-05-19T23:04:28

None of them really like Jaimie anyways\.  But regardless they wouldn’t


---

### 91. msg_11737

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:04:52

Does Jaimie know this?


---

### 92. msg_11738

**You** - 2025-05-19T23:05:13

No


---

### 93. msg_11739

**You** - 2025-05-19T23:05:39

Katie knows her best and was most vocal


---

### 94. msg_11740

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:05:40

Has no idea they thought bad match?


---

### 95. msg_11741

**You** - 2025-05-19T23:06:04

I mean they didn’t push on me hard but mum and Katie did ask if I was sure when we got back togethrr


---

### 96. msg_11742

**You** - 2025-05-19T23:06:22

They thought the reason I made the decision in the first place hadn’t changed


---

### 97. msg_11743

**You** - 2025-05-19T23:06:25

They were right


---

### 98. msg_11744

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:07:05

And now, greener pastures 😍


---

### 99. msg_11745

**You** - 2025-05-19T23:07:17

lol


---

### 100. msg_11746

**You** - 2025-05-19T23:07:35

Greener pastures interesting way to put it\.\.


---

### 101. msg_11747

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:07:53

Reaction: ❤️ from Scott Hicks
Country bumpkin


---

### 102. msg_11748

**You** - 2025-05-19T23:08:10

Hardly


---

### 103. msg_11749

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:08:43

lol


---

### 104. msg_11750

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:09:17

Bed time?


---

### 105. msg_11751

**You** - 2025-05-19T23:10:07

Unless
You want to keep
Talking otherwise sure I am not that tired but could do whatever\.


---

### 106. msg_11752

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:11:28

I’m sooooooooooooo exhausted\.


---

### 107. msg_11753

**You** - 2025-05-19T23:11:31

I mean curious \- did you watch the rest of fallout\.\. did you and Andrew trade any more fun chatter\.


---

### 108. msg_11754

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:11:42

I finished fallout yes


---

### 109. msg_11755

**You** - 2025-05-19T23:11:47

Kk then go to bed


---

### 110. msg_11756

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:11:53

I have not spoken with Andrew no


---

### 111. msg_11757

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:12:38

I got this on my drive home\. Weird

*1 attachment(s)*


---

### 112. msg_11758

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:13:27

How was it for you and the fam tonight?


---

### 113. msg_11759

**You** - 2025-05-19T23:13:36

Maybe he is giving her a hard time about the money\.


---

### 114. msg_11760

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:13:48

My house is lovely\. Only Maelle and I


---

### 115. msg_11761

**You** - 2025-05-19T23:14:07

Mm it was meh I came home mowed the lawn cause I one else did\. Then I cleaned up a bunch of shit made my supper ate\.


---

### 116. msg_11762

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:14:14

>
Maybe\. Not sure\. Think he is just in a bad mood generally\.


---

### 117. msg_11763

**You** - 2025-05-19T23:14:17

Prepped for tomorrow


---

### 118. msg_11764

**You** - 2025-05-19T23:14:39

We tried to talk to Gracie about Crandall university in Moncton she was having nine of it\.


---

### 119. msg_11765

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:15:00

That’s too bad


---

### 120. msg_11766

**You** - 2025-05-19T23:15:00

Still wants to go tonight radio tech\.\. I think that is straight ticket to fail\.\. I doubt she makes it through the semester


---

### 121. msg_11767

**You** - 2025-05-19T23:15:05

Yeah it sucks\.


---

### 122. msg_11768

**You** - 2025-05-19T23:15:59

Well I am glad
You have a good week ahead of you and when he gets back you can just go back out to the cottage lol\.


---

### 123. msg_11769

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:16:55

Seems like I may be ordered to\. We will see\. I didn’t make beds or the bra long but there is still time\.


---

### 124. msg_11770

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:17:33

I told my parents I am unsure about keeping cottage\. Andrew and I will have to talk about it again


---

### 125. msg_11771

**You** - 2025-05-19T23:18:23

Are you unsure because of finances?


---

### 126. msg_11772

**You** - 2025-05-19T23:18:30

Or the ongoing\. Connection


---

### 127. msg_11773

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:18:42

So many things\. All of the above\.


---

### 128. msg_11774

**You** - 2025-05-19T23:19:16

Sorry to hear that
You are in\. Tough situation and I don’t think he is trying to make it any easier on you\.


---

### 129. msg_11775

**You** - 2025-05-19T23:28:07

Alright honey go to bed \- I love
You\.\. I know you are tired\.\. and the last few nights… well as super fun as they were, and I would def go again tonight given the opportunity\.\. you need to sleep\.


---

### 130. msg_11776

**You** - 2025-05-19T23:28:24

❤️❤️❤️❤️❤️


---

### 131. msg_11777

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:30:07

Yeah I am super exhausted and I also had super fun\. Best weekend in a long time even if I feel kind of irresponsible for getting so wasted\. Lol I am going to sleep now\. Xoxox


---

### 132. msg_11778

**Meredith Lamb \(\+14169386001\)** - 2025-05-19T23:30:30

See you tomorrow \- love you


---

### 133. msg_11779

**You** - 2025-05-19T23:30:55

Same love
You too\.
See you at the office\.\. will be sure to wave lol\.


---

### 134. msg_11780

**You** - 2025-05-20T04:27:08

Reaction: ❤️ from Meredith Lamb
Morning sunshine hope you actually went to sleep and got a good one\.❤️❤️❤️


---

### 135. msg_11781

**You** - 2025-05-20T04:32:36

Reaction: 😂 from Meredith Lamb
Also I miss the dogs…\.\. 😢 well Rosie and Grif tbh\.


---

### 136. msg_11782

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T06:30:03

Yeah I was happy to say bye to Bo lol


---

### 137. msg_11783

**You** - 2025-05-20T06:30:33

Rofl bark bark bark holy fuck bark\.


---

### 138. msg_11784

**You** - 2025-05-20T06:44:44

Phew well that was fun see you in at work when I see
You\.\. going to check out that terra park this morning to cool off for a walk after this… brutal\.


---

### 139. msg_11785

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:00:32

Omg I fell back asleep and just woke up lol was supposed to take Maelle to school at 8\.10\. Argh


---

### 140. msg_11786

**You** - 2025-05-20T08:01:43

Oops


---

### 141. msg_11787

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:01:55

Getting her an uber now :p


---

### 142. msg_11788

**You** - 2025-05-20T08:03:32

lol


---

### 143. msg_11789

**You** - 2025-05-20T08:03:38

Eesh


---

### 144. msg_11790

**You** - 2025-05-20T08:06:56

Maybe if I had have been there to wake you up\.


---

### 145. msg_11791

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:07:53

Yes, make that happen please\. Lol


---

### 146. msg_11792

**You** - 2025-05-20T08:09:31

2 years


---

### 147. msg_11793

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:15:19

Omg fuck off


---

### 148. msg_11794

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:16:35

Not allowed to say that joke before I’ve had my coffee


---

### 149. msg_11795

**You** - 2025-05-20T08:18:45

At park now honey\.\.


---

### 150. msg_11796

**You** - 2025-05-20T08:21:57

Couple of nice spots

*5 attachment(s)*


---

### 151. msg_11797

**You** - 2025-05-20T08:22:15

Bout 2 min walk in from where I parked\.


---

### 152. msg_11798

**You** - 2025-05-20T08:23:11

And haven’t seen a soul


---

### 153. msg_11799

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:24:33

Nice\. I will look later\. I am soooooooooooo late for Mia\.


---

### 154. msg_11800

**You** - 2025-05-20T08:24:49

lol I know


---

### 155. msg_11801

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:31:49

I’m cool lol

*1 attachment(s)*


---

### 156. msg_11802

**You** - 2025-05-20T08:32:45

You are def cool\.😎


---

### 157. msg_11803

**You** - 2025-05-20T08:33:18

Back to the me sleeping with you\.\. I mean I would only be a good influence\.\. 😇


---

### 158. msg_11804

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:34:17

Yeah let’s keep it real\. That is totally not true at all\.


---

### 159. msg_11805

**You** - 2025-05-20T08:34:41



---

### 160. msg_11806

**You** - 2025-05-20T08:34:49



---

### 161. msg_11807

**You** - 2025-05-20T08:34:50



---

### 162. msg_11808

**You** - 2025-05-20T08:35:29

I think you would be better off on the whole\.


---

### 163. msg_11809

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:37:01

Whoah 3 deleted msgs


---

### 164. msg_11810

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:37:05

Super unfair


---

### 165. msg_11811

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T08:52:22

Did you fall in some water or something?


---

### 166. msg_11812

**You** - 2025-05-20T08:52:46

Just in can explain after


---

### 167. msg_11813

**You** - 2025-05-20T09:10:30

Reaction: 😂 from Meredith Lamb
So I had said I think you would be better off and it corrected two words on turned into in and whole turned into hole\.\. the other two messages after were omg on and whole, and then Jesus\!\!\!\! And when I realized you hadn’t read I deleted immediately lol


---

### 168. msg_11814

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T09:16:47

Arrived\. Going straight to 3rd floor


---

### 169. msg_11815

**You** - 2025-05-20T09:20:46

Kk have fun\.


---

### 170. msg_11816

**You** - 2025-05-20T11:55:38

What a fucking day so far\. Jesus\.


---

### 171. msg_11817

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T11:56:04

Why?


---

### 172. msg_11818

**You** - 2025-05-20T11:56:19

Meetings stupid


---

### 173. msg_11819

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T11:57:36

Oh…\.


---

### 174. msg_11820

**You** - 2025-05-20T12:02:58

What did you think


---

### 175. msg_11821

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T12:04:54

Who knows honestly\. Could be anything lol


---

### 176. msg_11822

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T12:05:30

Tell me when you have a minute


---

### 177. msg_11823

**You** - 2025-05-20T12:39:39

Listen it takes me at least 24\-48 hours to get depressed about us again gawd give me some
Credit ffs\. 😜


---

### 178. msg_11824

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T13:57:30

You know what would be really awesome? Just going home together after work\.
😢😭


---

### 179. msg_11825

**You** - 2025-05-20T14:05:13

Yeah agreed\.


---

### 180. msg_11826

**You** - 2025-05-20T14:05:27

There’s always the park 😊


---

### 181. msg_11827

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:09:47

lol we can try that


---

### 182. msg_11828

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:10:07

Back and forth with Andrew on text\. Stopping now :p


---

### 183. msg_11829

**You** - 2025-05-20T14:10:27

Hope it isn’t frustrating yku too
Much\.


---

### 184. msg_11830

**You** - 2025-05-20T14:11:32

>
>
I would actually like to talk to you about this at
Some point in time\.\. there are some decisions I will need to make about my living situation that might be impacted by that conversation\.


---

### 185. msg_11831

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:22:46

I mean, I’m not actually expecting anything for years in that regard\. It would be nice but…\.\. complicated\.


---

### 186. msg_11832

**You** - 2025-05-20T14:27:32

I know\.\. if it is many many years the\. That makes my decision easy\.


---

### 187. msg_11833

**You** - 2025-05-20T14:28:08

We don’t even need to have the chat 👍


---

### 188. msg_11834

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:28:26

I mean I don’t want it to be but I am a realist\.


---

### 189. msg_11835

**You** - 2025-05-20T14:32:36

>
Yeah totally agree\.


---

### 190. msg_11836

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:52:40

Omg I can’t even explain the words spewing out of his mouth today\. ……\.


---

### 191. msg_11837

**You** - 2025-05-20T14:53:28

Gah I wish he would just stop fighting and work towards a solution\.


---

### 192. msg_11838

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:53:56

He’s all mad that the separation agreement won’t include anything I have to do for him:


---

### 193. msg_11839

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:53:59

The separation agreement will include things that I need to do for you over the next 8 years \- essentially pay child support and spousal support\.  And it will have mutual obligations about sharing the kids\.  It will not have any things you need to do for me\.   Which is just the way it is\.  So you won’t need to resent me or feel unappreciated by me any more, which will be helpful I hope\.


---

### 194. msg_11840

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:54:09

I told you \- he is very transactional


---

### 195. msg_11841

**You** - 2025-05-20T14:55:07

Yeah that seems kind of fecked up\.\. here I am offering to help j with any ongoing documentation and shit for the home anyways\.\.


---

### 196. msg_11842

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:55:06

First time he has ever said he appreciates something from me\. I’m kind of shell shocked tbh\.

*1 attachment(s)*


---

### 197. msg_11843

**You** - 2025-05-20T14:55:45

lol yeah because it is what he wants\!\!\! lol sorry in this I am a cynic


---

### 198. msg_11844

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T14:59:34


*1 attachment(s)*


---

### 199. msg_11845

**You** - 2025-05-20T15:00:32

I am never going to get in a fight with you\.  Ever\.


---

### 200. msg_11846

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T15:01:00

I get the “please stop taking… blahblahblah” all the time now


---

### 201. msg_11847

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T15:01:08

I told him he had to stop saying that


---

### 202. msg_11848

**You** - 2025-05-20T15:01:29

Well like you said you were just clarifying and correcting


---

### 203. msg_11849

**You** - 2025-05-20T17:08:53

Have to Remeber where I can say what


---

### 204. msg_11850

**You** - 2025-05-20T17:09:05

A long way down from the weekend to fall…\.


---

### 205. msg_11851

**You** - 2025-05-20T17:09:13

It will hit me soon enough\.


---

### 206. msg_11852

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T17:13:59

Weekend to fall?


---

### 207. msg_11853

**You** - 2025-05-20T17:14:40

I responded in teams and deleted it\.  A long way to fall from the happy weekend to the sad state we are in now\.


---

### 208. msg_11854

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T17:19:48

I knoooooooow\. Emotional whiplash


---

### 209. msg_11855

**You** - 2025-05-20T17:20:31

Very sucky\.  I am trying not to think about the next 3\-5 weeks or more like 6\-10


---

### 210. msg_11856

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T17:46:49

Reaction: ❤️ from Scott Hicks
Just don’t get in your head about all the “be cautious” advice\. You are everything to me and have no reason for caution\.


---

### 211. msg_11857

**You** - 2025-05-20T18:07:01

I am not slowing mer\.


---

### 212. msg_11858

**You** - 2025-05-20T18:07:20

But I am hanging out with cm after hours\. 😝


---

### 213. msg_11859

**You** - 2025-05-20T18:11:42

Reaction: ❤️ from Meredith Lamb
But in all seriousness I am all in, I already told you\.\. I am so in love with every aspect of you\.  I have never fallen in love like this and won’t again\.\. I know officially living together is a ways off but spending more regular evenings or let’s just say time in general with each other might not be that far away\.\. and I think that is what I am going to focus on\.  And getting whatever reasonable chance to spend minutes with you wherever I can because it all means something to me\.


---

### 214. msg_11860

**You** - 2025-05-20T18:13:12

I think it is because I have fallen in like with you as much as I have fallen in love with you\.  Which might sound funny but I think it is one of those things that you need for it to be truly real and lasting\.


---

### 215. msg_11861

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:20:43

Yeah I get it\. Ok, just didn’t want the caution caution ⚠️ alerts to get to you\. Lol


---

### 216. msg_11862

**You** - 2025-05-20T18:21:42

No no I am already past the point of no return I think I was months ago to be honest\.\. even before Detroit\.


---

### 217. msg_11863

**You** - 2025-05-20T18:23:44

Reaction: ❤️ from Meredith Lamb
This was like “you had me at hello” lol… 🥰


---

### 218. msg_11864

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:30:12

Ditto\. So same page still\. Phew


---

### 219. msg_11865

**You** - 2025-05-20T18:33:38

Yeah mer \-  nothing is going to change I am not
Looking backwards to relive old flings or explore what could have been or any shit like that\.\. I am not looking sideways because in either case no one can come close to what I believe we have\.  And I am assuming we are on the same page on everything honestly so even though I have irrational fears sometimes I try not to let it bother me too much\.


---

### 220. msg_11866

**You** - 2025-05-20T18:36:56

I am also sorry if sharing what dev said caused you to worry… you have enough going on\.


---

### 221. msg_11867

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:38:59

Didn’t worry per se 😉


---

### 222. msg_11868

**You** - 2025-05-20T18:54:03

Per se lol


---

### 223. msg_11869

**You** - 2025-05-20T18:54:24

Deleted??


---

### 224. msg_11870

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:55:08

No was just doing volleyball drop off and then had to walk dogs\.


---

### 225. msg_11871

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:55:16

Gah non stop crap to do


---

### 226. msg_11872

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:55:33

Now I’m lying down for an hour until volleyball pick up lol


---

### 227. msg_11873

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:55:46

Anyway I maybe did worry a bit but feel better now\.


---

### 228. msg_11874

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:56:13

I wasn’t sure how much you would listen to the caution speakers\. 🙃


---

### 229. msg_11875

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T18:56:31

If it might change anything or not


---

### 230. msg_11876

**You** - 2025-05-20T19:23:17

No like I said no listening\.\. Just going to try trusting and leaning on each other to get through this to what is next\.


---

### 231. msg_11877

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T19:48:49

Shortest nap ever :\(


---

### 232. msg_11878

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T19:49:03

Back to 🏐


---

### 233. msg_11879

**You** - 2025-05-20T20:17:13

Well I had more Gracie bullshit tonight\.\. so yay\.


---

### 234. msg_11880

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T20:22:44

😬 same old or new content?


---

### 235. msg_11881

**You** - 2025-05-20T20:24:38

Same shit different day\.\.


---

### 236. msg_11882

**You** - 2025-05-20T20:24:47

If we are getting closer and closer to me signing off


---

### 237. msg_11883

**You** - 2025-05-20T20:24:51

But


---

### 238. msg_11884

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T20:30:01

But…\.?


---

### 239. msg_11885

**You** - 2025-05-20T20:34:00

But we are getting closer to me just signing off\.\. I have been trying to connect and find ways\.\. but I mean she is 18 and she literally won’t stop fighting about everything including still wanting to live here and go to university but she actually wants to force the issue and live with me and maddie who hates her\.\. like it is impossible\. J was going to fly her up to see her friends and I am saying no now because she might refuse to get in the return flight back\.


---

### 240. msg_11886

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T20:36:39

No words…\. It sounds impossible but hopefully she relents eventually


---

### 241. msg_11887

**You** - 2025-05-20T20:37:18

I don’t think she will she has created all of these scenarios\.\.  I cannot even explain it to try to justify what she wants and none of them make sense


---

### 242. msg_11888

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T21:20:29

:\(


---

### 243. msg_11889

**You** - 2025-05-20T21:29:50

I have to go watch something g with fam for 10 mins then I coming downstairs if you want to chat for a few mins then I am going to bed\.


---

### 244. msg_11890

**Meredith Lamb \(\+14169386001\)** - 2025-05-20T21:30:47

k, watching handmaids tale and then going to bed too xo


---

### 245. msg_11891

**You** - 2025-05-20T21:32:31

I will message you when I am back down if you still up


---

### 246. msg_11892

**You** - 2025-05-20T21:59:21

Wow that was quite offensive


---

### 247. msg_11893

**You** - 2025-05-20T21:59:25

Even for snl


---

### 248. msg_11894

**You** - 2025-05-20T22:10:57

Must have missed you\.\. nite xo


---

### 249. msg_11895

**You** - 2025-05-21T04:14:09

Reaction: ❤️ from Meredith Lamb
Morning 💕\.   Nothing like waking up to Morgan and thinking about the person that got me addicted to his magical mustache\!\!\!  Love you mer\. Off to the gym I go 😋


---

### 250. msg_11896

**You** - 2025-05-21T06:24:22

Reaction: 😢 from Meredith Lamb
Going into office today cannot deal with home\. 😣


---

### 251. msg_11897

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T07:02:24

I woke up at 6am to a dream of us kissing\. First time I think\. 🫠


---

### 252. msg_11898

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T07:03:19

Went back to sleep for an hour thinking of that\. Sigh\. Up now


---

### 253. msg_11899

**You** - 2025-05-21T07:09:50

lol nice dream… I would take that dream every day for sure\.


---

### 254. msg_11900

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T07:14:46

Yes and now I get to chauffeur again\. 🤦‍♀️ fml


---

### 255. msg_11901

**You** - 2025-05-21T07:15:31

Yeah that’s right early day for you\.\. have fun\.\. I have to go home get my work shit wait to drive Maddy at 9 then in to work


---

### 256. msg_11902

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T08:30:21

WHMIS done\. 😝


---

### 257. msg_11903

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T08:30:36

Did it with coffee this morning


---

### 258. msg_11904

**You** - 2025-05-21T08:33:00

The excitement continues\!\!\!


---

### 259. msg_11905

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T08:33:29

Super boring but was easy fortunately


---

### 260. msg_11906

**You** - 2025-05-21T08:33:55

I will do later I think kind of not overly motivated today\.


---

### 261. msg_11907

**You** - 2025-05-21T09:12:20

There my chauffeuring is done driving into office now


---

### 262. msg_11908

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T09:37:31

My internet just randomly went out


---

### 263. msg_11909

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T09:37:40

No idea why


---

### 264. msg_11910

**You** - 2025-05-21T09:49:58

That sucks\.\. maybe work in area\.


---

### 265. msg_11911

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T09:55:14

Neighbours is down too\. And 310\-BELL number isn’t even working\.


---

### 266. msg_11912

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T09:55:23

Something major must be wrong


---

### 267. msg_11913

**You** - 2025-05-21T09:55:36

Carolyn’s was down too


---

### 268. msg_11914

**You** - 2025-05-21T09:55:40

Works in here lol


---

### 269. msg_11915

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T09:56:15


*1 attachment(s)*


---

### 270. msg_11916

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T09:56:29

At least it isn’t just me\. Thought it was just me\.


---

### 271. msg_11917

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:09:34

How many people are offline?


---

### 272. msg_11918

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:09:42

It isn’t coming back on argh


---

### 273. msg_11919

**You** - 2025-05-21T10:10:11

I think Carolyn is off too


---

### 274. msg_11920

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:12:56

That’s it?\!


---

### 275. msg_11921

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:13:14

Hmm should I come into office?


---

### 276. msg_11922

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:13:29

Oh wait


---

### 277. msg_11923

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:13:40

I thought it was back on but no


---

### 278. msg_11924

**You** - 2025-05-21T10:25:33

Maybe you should come in 🙂


---

### 279. msg_11925

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T10:31:16

lol will decide in a minute


---

### 280. msg_11926

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T15:13:51


*1 attachment(s)*


---

### 281. msg_11927

**You** - 2025-05-21T15:14:45

Max replacement lucky you didnt get more than bruh\.\.


---

### 282. msg_11928

**You** - 2025-05-21T15:14:50

lol


---

### 283. msg_11929

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T15:15:21

😇


---

### 284. msg_11930

**You** - 2025-05-21T15:15:27

lol


---

### 285. msg_11931

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T15:15:30

I mean we all know it is true


---

### 286. msg_11932

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T15:15:37

I just said it out loud


---

### 287. msg_11933

**You** - 2025-05-21T15:15:52

I know she prolly doesn’t want to hear it lol


---

### 288. msg_11934

**You** - 2025-05-21T15:16:27



---

### 289. msg_11935

**You** - 2025-05-21T17:38:40

Pouring rain\.\. awesome\!


---

### 290. msg_11936

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T17:56:37

All day basically


---

### 291. msg_11937

**You** - 2025-05-21T17:56:53



---

### 292. msg_11938

**You** - 2025-05-21T17:57:05



---

### 293. msg_11939

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:18:53

Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 294. msg_11940

**You** - 2025-05-21T18:20:23

Miss dogs


---

### 295. msg_11941

**You** - 2025-05-21T18:20:27

Reaction: 😂 from Meredith Lamb
Not bo


---

### 296. msg_11942

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:35:15

So today you called me bossy \(on the weekend\) at least twice\. You are going to have to clarify if this was a negative thing\. I’m not sure I was “bossy” per se……


---

### 297. msg_11943

**You** - 2025-05-21T18:35:41

You weren’t at all\.  Sarcasm


---

### 298. msg_11944

**You** - 2025-05-21T18:35:47

You never are


---

### 299. msg_11945

**You** - 2025-05-21T18:35:51

It is a carryover


---

### 300. msg_11946

**You** - 2025-05-21T18:36:05

From when you said you were the boss outside of work


---

### 301. msg_11947

**You** - 2025-05-21T18:36:42

And in the context you used it\.\. you can be the boss of me whenever


---

### 302. msg_11948

**You** - 2025-05-21T18:38:40

Should have been more jokey I guess


---

### 303. msg_11949

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:39:09

Okay, just clarifying … thought it might be important


---

### 304. msg_11950

**You** - 2025-05-21T18:39:38

No\.\. you do focus in on interesting things\.


---

### 305. msg_11951

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:40:50

Again, is this negative feedback? Lol I can’t tell


---

### 306. msg_11952

**You** - 2025-05-21T18:44:39

Errrrrrrrr no mer\.\. everything ok?  Just an observation we talk about all kinds of shit and joke back and forth just hard to predict what you focus in on sometimes\. I don’t think you are bossy\.\. man I need to be careful with my sarcasm and jokes lol\.


---

### 307. msg_11953

**You** - 2025-05-21T18:45:16

I told you last night I thought or maybe today\.\. or some time recently I love everything about you\.\. there isn’t anything I don’t like\.


---

### 308. msg_11954

**You** - 2025-05-21T18:46:26

I do promise if I have a real problem I would never hesitate to tell you\.\. not these stupid insecurities and shit I mentioned earlier today, but something real\.  If it bothers me I will tell you, and I hope you do likewise because that kind of communication is really important\.


---

### 309. msg_11955

**You** - 2025-05-21T18:47:07

Sorry if I said something to bother you you\.\. wasn’t intended\.


---

### 310. msg_11956

**You** - 2025-05-21T18:47:41

What even triggered the thought?


---

### 311. msg_11957

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:48:55

No I’m fine… I just equate bossy to bad so was just checking


---

### 312. msg_11958

**You** - 2025-05-21T18:49:18

Could you share with me your bad words?


---

### 313. msg_11959

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:49:27

lol


---

### 314. msg_11960

**You** - 2025-05-21T18:49:31

Just so I can avoid them


---

### 315. msg_11961

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:49:51

Omg I will start a list and share later


---

### 316. msg_11962

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:49:55

:p


---

### 317. msg_11963

**You** - 2025-05-21T18:50:00

So you know I am thinking bossy like the safe word is…


---

### 318. msg_11964

**You** - 2025-05-21T18:50:37

Sooooooo plus, I literally had to beg you to let me do work on the weekend lol


---

### 319. msg_11965

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:51:56

Whatever you did tons


---

### 320. msg_11966

**You** - 2025-05-21T18:55:28

Still you didnt boss me around ever\.


---

### 321. msg_11967

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T18:59:52

Well you don’t have to change your story now\. As long as it didn’t bother you I’m good\. 🙂 lol


---

### 322. msg_11968

**You** - 2025-05-21T19:06:53

Reaction: 😂 from Meredith Lamb
Ohhhhhhh come onnnnnnnnn


---

### 323. msg_11969

**You** - 2025-05-21T19:14:03

>
There are all kinds of things you do that bother me\.\. but none of them are in bad ways\. 🤪


---

### 324. msg_11970

**You** - 2025-05-21T19:19:07

btw there is another aspect to this younger more sensitive me\.\. I don't think the Sailor song does it justice\. I just think you need some happier things to focus on / look forward to\.


---

### 325. msg_11971

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T19:23:35

>
We are still very much getting to know each other so it’s a bit weird \(for lack of a better word sorry\) and just want to ensure I’m not bothering you for real\. Negative bothering you\.


---

### 326. msg_11972

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T19:23:51

>
Of course I do\. Don’t we all?


---

### 327. msg_11973

**You** - 2025-05-21T19:37:46

>
Ok\.\. so we can get this part of the getting to know each other out of the way\.  I have made a LOT of mistakes throughout my life, throughout this relationship and previous\.  Some of those I am hard wired for\.\. can't change\.\. I am intense, sometimes people find that \- stifling, overbearing, smothering etc\.\.\. and with this kind of love, it is a whole new thing, and I really am trying to hold it back\.  But other things, like not communicating when things are tough, like really tough, or when something happens that really bothers or hurts me, I will never hold that back from you\.  I have already told you and shared things with you that haven't and would never be comfortable sharing with anyone else ever\. I know we are new \- and there are going to be quirks and things that pop up over time\.\. but the really big things\.\. the, can you trust me to be patient, to wait this out, to support you through this process, to not hurt you, while I know you still need to believe on your end, I cannot be\.\.\. \[truncated\]


---

### 328. msg_11974

**You** - 2025-05-21T19:42:12

you should take a min I don't say any of that lightly\.\. and if you have any questions as I have told you before\.\. I will answer anything\.


---

### 329. msg_11975

**You** - 2025-05-21T19:45:55

That was a lot\.\. I hope I didn't say something wrong LOL


---

### 330. msg_11976

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T19:47:01

Reaction: ❤️ from Scott Hicks
That was looong but I appreciate it\. I’m not sure if I’ve been marginalized but I’ve certainly dealt with a major um, complainer I guess is the right word\. I mean even when we were dating\. I didn’t listen to that red flag\. Doh\. So I am probably a little sensitive to things that could be construed as complaining or critiquing maybe is a better word\. Not sure\. I didn’t complain about anything until 3 yrs ago when I said fuck it\. I grew up with my mom being a constant nag to my dad and complaining all the time so I vowed not to be like that\. My therapist says I went too far to the extreme to my detriment\. But whatever\. Done now\. So yeah I’m probably overly sensitive to negative connotation words like bossy\. lol


---

### 331. msg_11977

**You** - 2025-05-21T19:50:27

You deserve a lot more \- please just understand you can ask me anything\.\. you will get an answer\.\. and you do not need to reciprocate\.\. we are different people will different levels of comfort in sharing, but I think similar in some ways of needing reassurance or understanding\. So any time, on any topic, do not hesitate to ask, even if you think it might bother me etc\.


---

### 332. msg_11978

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T19:53:44

I asked\. We resolved\. And we are still apart\. 😒


---

### 333. msg_11979

**You** - 2025-05-21T19:54:01

Not tomorrow morning we aren't 😊


---

### 334. msg_11980

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T19:54:57

lol k\.\.


---

### 335. msg_11981

**You** - 2025-05-21T19:58:04

Look I want everything\.\. I think you know that right?  I don't know if that scares you a bit\.\. it scares me a lot\.\. I want everything but I am willing to take whatever we can have at whatever time we can have it\. It is almost june\.\. time will hopefully get going faster or feel like it once we start making legal progress\.\. most of july I will be focused on moving\.\. but then there is august\.\. so some potential?  And whatever we can find in the meantime, is fine by me\.  I hope it is enough for you as well\.


---

### 336. msg_11982

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:03:03

I’m not really scared by that no\. More scared by us getting annoyed at the whole thing\. Not if we can find time but if we can’t I guess\. But it doesn’t occupy my mind a whole lot really\.


---

### 337. msg_11983

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:03:43

But I think after the weekend things get a tad more difficult…


---

### 338. msg_11984

**You** - 2025-05-21T20:03:57

even if we couldn't find a minute together for the rest of this year\.\. as miserable as that would make me\.\. it wouldn't change anything that matters to me\.


---

### 339. msg_11985

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:04:12

But it is okay… lots to sort through\.


---

### 340. msg_11986

**You** - 2025-05-21T20:04:12

>
what do you mean?


---

### 341. msg_11987

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:05:12

Just knowing it will not be an even semi\-regular occurrence, if at all\. That’s all


---

### 342. msg_11988

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:05:26

>
Somehow I doubt this\. lol


---

### 343. msg_11989

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:05:39

You don’t think you would explode


---

### 344. msg_11990

**You** - 2025-05-21T20:06:38

>
Mer come on\.\. seriously\.\. whatever explosions occur wouldn't change how I feel\.\. I think as long as we reassured each other\.\. we would be fine\.  And we just might need that more often than not, if we had to be apart that long\.  And trust would be pretty big too\.\. which I have\.


---

### 345. msg_11991

**You** - 2025-05-21T20:07:42

>
we sure as hell won't get 4 days together like that\.\. but I have to believe we will find some time\.\. date nights at the water would be good enough for me or like I said, park in the morning\.  I mean I am speaking for me\.\. I cannot speak for you\.


---

### 346. msg_11992

**You** - 2025-05-21T20:12:58

Listen if you feel differently\.\. please don't be afraid to say so Mer\.\. I mean if you are worried about me \- I think you said it earlier\.\. I hope I haven't given you any reason to think I would ever walk away from this for any reason\.


---

### 347. msg_11993

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:14:20

No not worried about you at all\. Just the situation\. But honestly, there is so much going on and things seem to have been just falling into place so far, hopefully it will continue that way\.


---

### 348. msg_11994

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:15:08

So we can put a pin in this and continue to do what we do… hope for the best\. More time, opportunities, whatever…\.


---

### 349. msg_11995

**You** - 2025-05-21T20:15:36

>
Honestly Mer, I will do the best I can\.


---

### 350. msg_11996

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:16:00

Same :\)


---

### 351. msg_11997

**You** - 2025-05-21T20:17:47

>
But again\.\. and I am just being honest\.\. I am not built this way\.\. so please be patient with me, because I know this is going to be hard\.\. and I definitely will slip up now and then\.


---

### 352. msg_11998

**You** - 2025-05-21T20:18:26

Anyhow\.\. we can drop it, I know it is too heavy\.\.\.\.


---

### 353. msg_11999

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:21:33

You have not slipped up\.


---

### 354. msg_12000

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T20:39:10

I feel bad if I caused unnecessary drama tonight\. I know you don’t need it with your drama at home\. Just know, I love you\. ❤️


---

### 355. msg_12001

**You** - 2025-05-21T20:42:54

Reaction: ❤️ from Meredith Lamb
>
There is nothing to feel bad about \- we lean on each other, we pick each other up, we find our moments, and then we maximize the minutes, hours or days we have, until that isn't an issue anymore\.  Rinse and repeat until then\.  Just know I love you too ❤️ \- you are everything to me, my home, and my friend\.


---

### 356. msg_12002

**Meredith Lamb \(\+14169386001\)** - 2025-05-21T21:43:24

Off to bed\. Sweet dreams\. 💤 see you tomorrow\. Xoxo


---

### 357. msg_12003

**You** - 2025-05-21T22:06:08

Reaction: 😢 from Meredith Lamb
Massive fight here really bad hope your night was better\.  Nite ❤️😩


---

### 358. msg_12004

**You** - 2025-05-22T05:13:29

Hey heading into gym\. Looks like it is going to be miserable today\. As
Much as I would like to see you I know you aren’t feeling well already and don’t want to make it worse so feel free to skip today if you want\.  Love you\.


---

### 359. msg_12005

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:09:49

Ok so what am I doing? It is pouring here lol


---

### 360. msg_12006

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:09:59

And freezing\. 🥶


---

### 361. msg_12007

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:10:09

Letting my dogs outside …\.


---

### 362. msg_12008

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:11:34

I got back in bed lol


---

### 363. msg_12009

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:12:17

Getting up at 7\.30 :\)


---

### 364. msg_12010

**You** - 2025-05-22T07:24:36

Says no denim there\.\. going to have to go home and change\.\. 5 cancellations yesterday 1 this morning not sure\.  You decide what you want to do mer\.\.


---

### 365. msg_12011

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:30:42

5 cancellations yesterday?


---

### 366. msg_12012

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:31:22

I figured likely no jeans at golf course\.


---

### 367. msg_12013

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:31:35

You are in a bad mood :\(


---

### 368. msg_12014

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:42:27

Ok so no park in the rain\. Not sure if you were expecting that but I’d also like to drive Maelle to school now at like 8\.45


---

### 369. msg_12015

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:42:51

I don’t want you to be frustrated today tho


---

### 370. msg_12016

**You** - 2025-05-22T07:52:40

I think it would be better for you to head in to work, or feel free to work from home if you want\. Not worth going up there for no reason\.


---

### 371. msg_12017

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:54:21

And just not tell my team?\!


---

### 372. msg_12018

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:54:57

I feel like you are upset


---

### 373. msg_12019

**You** - 2025-05-22T07:55:19

I don’t think they thought you were going did they?  Not a big deal, I can tell them something came up\.


---

### 374. msg_12020

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:56:23

Yes, they knew I was going\. Why are you not addressing my you are upset comments?


---

### 375. msg_12021

**You** - 2025-05-22T07:57:17

Skillfully dodging them\.\.


---

### 376. msg_12022

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T07:57:25

Sigh


---

### 377. msg_12023

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T08:02:12

I made you THAT angry?


---

### 378. msg_12024

**You** - 2025-05-22T08:09:02

Hmmm?  No I am in a hurry I had to change completely and now I am back in the car\.


---

### 379. msg_12025

**You** - 2025-05-22T08:10:04

And you per se didnt make
Me angry but I am allowed to be disappointed on top of the shitty day ahead\. But I don’t want you getting sick out in this you probably have a busy weekend etc\.


---

### 380. msg_12026

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T08:11:47

k, just making sure\. I have to go\.\. I told the team I would be there incl Pauline\. Musarrat is new\. Never met Matthew etc


---

### 381. msg_12027

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T11:49:50

You have heard of sombr\.

*1 attachment(s)*


---

### 382. msg_12028

**You** - 2025-05-22T11:49:56

I am not mad I don’t want you to read my body language or tone wrong


---

### 383. msg_12029

**You** - 2025-05-22T11:50:05

Just in case


---

### 384. msg_12030

**You** - 2025-05-22T11:50:17

Preempting any concern


---

### 385. msg_12031

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T11:50:27

lol k


---

### 386. msg_12032

**You** - 2025-05-22T11:50:44

Thought you might be worried


---

### 387. msg_12033

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T11:51:10

Not worried but you look really grumpy\.


---

### 388. msg_12034

**You** - 2025-05-22T11:51:33

Reaction: 😢 from Meredith Lamb
Ok that is fair\. And accurate


---

### 389. msg_12035

**You** - 2025-05-22T11:55:11

Like I said universe, not a fan\.


---

### 390. msg_12036

**You** - 2025-05-22T13:00:03

You leaving


---

### 391. msg_12037

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T13:19:12

I want to


---

### 392. msg_12038

**You** - 2025-05-22T13:19:41

Same I am in front area needed to get away from people


---

### 393. msg_12039

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T13:21:05

K coming out there\. Think I’m going to leave


---

### 394. msg_12040

**You** - 2025-05-22T13:21:13

K


---

### 395. msg_12041

**You** - 2025-05-22T13:26:09

Yeah I am going to leave too shortly fucking don’t want to be here today anyways\.


---

### 396. msg_12042

**You** - 2025-05-22T15:32:04

Our song guess what I am thinking about now


---

### 397. msg_12043

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T15:38:12

lol


---

### 398. msg_12044

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T15:38:16

Yeah heard it


---

### 399. msg_12045

**You** - 2025-05-22T15:38:20



---

### 400. msg_12046

**You** - 2025-05-22T16:28:56



---

### 401. msg_12047

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T16:32:35

? I’m sure you will tell me later when I ask and I’m not driving\.


---

### 402. msg_12048

**You** - 2025-05-22T16:33:05

Reaction: 😂 from Meredith Lamb
Just disregard\.\. was stupid anyways\. Just a musing\.


---

### 403. msg_12049

**You** - 2025-05-22T16:33:16

We don’t need to revisit
Drive safe


---

### 404. msg_12050

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T16:37:31

I’m home\. That drive sucked\.


---

### 405. msg_12051

**You** - 2025-05-22T16:39:05

Reaction: 😵‍💫 from Meredith Lamb
Yeah same at metro getting food for people that apparently don’t go out to get food even though they just drove by the place\.


---

### 406. msg_12052

**You** - 2025-05-22T16:39:39

Gonna be a good night\.  Hope yours is better than mine\.


---

### 407. msg_12053

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T16:43:35

Bailey is asking me to confirm if p4p will have a cohort in 2026\. Am I supposed to know this? Lol


---

### 408. msg_12054

**You** - 2025-05-22T16:44:00

Tell her we haven’t decided yet


---

### 409. msg_12055

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T16:44:09

Ok


---

### 410. msg_12056

**You** - 2025-05-22T16:45:23

I don’t even know what to do with that pos offer\.  I know I left the last meeting with a couple of
Requests from mark not sure if they got done but since ahana is gone I guess I will wait till she gets back


---

### 411. msg_12057

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T16:46:35

Adding a new cohort is a 3\-4 yr commitment\.


---

### 412. msg_12058

**You** - 2025-05-22T16:47:41

Yeah I know\.  But what is the reason not to


---

### 413. msg_12059

**You** - 2025-05-22T16:47:44

Other than that


---

### 414. msg_12060

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T16:48:47

Communication with school boards too challenging\.


---

### 415. msg_12061

**You** - 2025-05-22T16:59:46

Was going to answer in teams but you logged off\. I think we consider a response like the filing that we put forward contemplated p4p but not in its current format, the congruency of the program design and delivery did not align with the budget, and the results remain unaudited\. With the commitment associated with another cohort possibly extending even beyond the next plan horizon we thought it prudent not to extend\.


---

### 416. msg_12062

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:08:30

That’s a good start


---

### 417. msg_12063

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:08:41

Needs some ChatGPTing


---

### 418. msg_12064

**You** - 2025-05-22T17:09:04

Will leave it to someone else


---

### 419. msg_12065

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:09:35

I can help draft something but is Carolyn’s team doing it?


---

### 420. msg_12066

**You** - 2025-05-22T17:09:59

Yeah I will paste it over to her\.  You can ignore\.


---

### 421. msg_12067

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:10:36

k if she had questions about the program design and delivery specifics I can fill in the blanks there


---

### 422. msg_12068

**You** - 2025-05-22T17:11:29

We won’t be putting this in the rollover this would be likely for the next filing when they realize in the rollover we fucked
Off
With a new p4p cohort\.


---

### 423. msg_12069

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:11:42

Ohhhh


---

### 424. msg_12070

**You** - 2025-05-22T17:11:48

So like a future ir down the road


---

### 425. msg_12071

**You** - 2025-05-22T17:11:57

And a response to Ian


---

### 426. msg_12072

**You** - 2025-05-22T17:12:02

When he challenges


---

### 427. msg_12073

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:12:06

Gotcha “okey dokey”


---

### 428. msg_12074

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:12:46

I’m chilling for a bit and going online later


---

### 429. msg_12075

**You** - 2025-05-22T17:12:56

Enjoy


---

### 430. msg_12076

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:13:57

I’d rather be chilling with you but… the lives we live 😜


---

### 431. msg_12077

**You** - 2025-05-22T17:14:58

Yep not much chance of that for a while\.  Gotta find something to keep myself busy\.


---

### 432. msg_12078

**You** - 2025-05-22T17:17:31

But you go chill I think I am going to change and just start tearing apart the basement\.


---

### 433. msg_12079

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:18:04

Tearing apart?


---

### 434. msg_12080

**You** - 2025-05-22T17:18:37

Going through stuff throwing it out\.\. just aggressively cleaning whatever you want to call it\.


---

### 435. msg_12081

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:19:30

Ah k, sounds amazing :p


---

### 436. msg_12082

**You** - 2025-05-22T17:20:09

Yep I have lots of amazing to look forward to :p


---

### 437. msg_12083

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:38:00

You know how you are getting kind of antsy and can’t sit and binge watch tv or do ai or whatever anymore? I’m becoming the opposite\. Lol


---

### 438. msg_12084

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:38:50

What you’re describing makes a lot of emotional sense\. Being around Scott in a professional setting while maintaining the appearance that your relationship is strictly professional—when it’s actually something much more—can be incredibly draining\. Here’s why it likely feels exhausting:
1\. Emotional Suppression
You’re actively managing and suppressing feelings that are otherwise natural and real\. That takes effort and mental energy—especially when you’re near someone you care deeply about\.
2\. Hyper\-awareness
You’re probably highly tuned in to:
•	How close you’re standing to him
•	What tone you’re using
•	Whether anyone is noticing subtle cues
That heightened vigilance can be mentally exhausting and physically stressful\.
3\. Discomfort with Inauthenticity
If you value being honest and emotionally congruent, having to “perform” a role or hide a significant part of your life can feel fake or even painful\. It may also feel unfair that others get to just be themselves openly while you have to\.\.\. \[truncated\]


---

### 439. msg_12085

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:39:22

Here’s my question: So today I was at a work event with co workers and external business partners\. I was around Scott much of the day and am finding it increasingly exhausting to be around him around coworkers who don’t know about us\. Why?


---

### 440. msg_12086

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:39:40

I need in a new job el pronto\.


---

### 441. msg_12087

**You** - 2025-05-22T17:40:34

Now maybe you can find a fox for my problem\[s\]


---

### 442. msg_12088

**You** - 2025-05-22T17:40:37

fix


---

### 443. msg_12089

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T17:41:47

I’m too drained\. Lol


---

### 444. msg_12090

**You** - 2025-05-22T19:48:36

Another fight tonight… so I probably won’t be to fun later\.\. feel free to just call it a day\.\. you probably aren’t having fun either although I hope it is better than here\.  We talked about me moving out until September into a short term rental\.


---

### 445. msg_12091

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:07:46

Sorry to hear that\. Not having a fun time either, no\.


---

### 446. msg_12092

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:09:20

This just sucks\.


---

### 447. msg_12093

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:11:22

I don’t think I can do days like today again, especially after last weekend\. It’s getting more difficult


---

### 448. msg_12094

**You** - 2025-05-22T20:23:41

What spending time with me around work people?


---

### 449. msg_12095

**You** - 2025-05-22T20:24:19

I have a prompt have baked that I want to share with you similar to yours\.


---

### 450. msg_12096

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:26:36

Just everything is getting more difficult\. We spend an amazing weekend together… aftermath = more difficult \(for me\)\. And yeah today was weird\. I don’t like seeing you in a bad mood and I can’t say anything bc work ppl and then just all the secrecy, it’s driving me nuts\. Like literally nuts\.


---

### 451. msg_12097

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:29:00

I shouldn’t have gone today


---

### 452. msg_12098

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:29:09

Wanted to for Musarrat and team tho


---

### 453. msg_12099

**You** - 2025-05-22T20:29:45

Ok so what do we need to do\.\. like I told you last night if we cannot see each other even for the next four months I will be sad\. But I will never stop loving you\.  Do you want to pause?


---

### 454. msg_12100

**You** - 2025-05-22T20:30:06

>
I told you not to come


---

### 455. msg_12101

**You** - 2025-05-22T20:31:17

I am really sorry you had a bad day\.\.


---

### 456. msg_12102

**You** - 2025-05-22T20:31:34

My bad day was much more to do with the fight that is still ongoing\.


---

### 457. msg_12103

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:32:42

>
This sucks and I’m sorry it is still happening gahhh


---

### 458. msg_12104

**You** - 2025-05-22T20:36:04

Please don't skip the tough parts mer\.\.


---

### 459. msg_12105

**You** - 2025-05-22T20:36:50

If we have to have a difficult conversation it is better to just have it\.  I don't want you to go through anything that causes you pain


---

### 460. msg_12106

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:41:00

I’m not skipping\.\.\. I am just saying everyday gets increasingly more difficult and I feel like it is building up\. Im probably just overwhelmed and worried


---

### 461. msg_12107

**You** - 2025-05-22T20:41:16

>
this comment


---

### 462. msg_12108

**You** - 2025-05-22T20:42:29

deleted\.


---

### 463. msg_12109

**You** - 2025-05-22T20:42:43

yeah I am having a hard time continuing that thought\.


---

### 464. msg_12110

**You** - 2025-05-22T20:43:38

Maybe I should take a vacation then you wouldn't have to see me\.


---

### 465. msg_12111

**You** - 2025-05-22T20:44:01

Or I can stop using signal for a while\.\. if that would make you feel less stressed


---

### 466. msg_12112

**You** - 2025-05-22T20:44:42

It is just "annoying" that us having an amazing weekend leads to this kind of outcome\.


---

### 467. msg_12113

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:45:23

Yeah, super annoying\. Agreed\.


---

### 468. msg_12114

**You** - 2025-05-22T20:45:33

So you let me know what you need\.\. I will do it\.


---

### 469. msg_12115

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:47:08

I can’t have what I need\. This is an impossible situation that seems to get more so instead of less\.


---

### 470. msg_12116

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:47:21

But maybe once I switch roles…\.


---

### 471. msg_12117

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:47:35

Just curious if I’ll last that long sanity\-wise


---

### 472. msg_12118

**You** - 2025-05-22T20:47:50

Mer this doesn't sound healthy\.


---

### 473. msg_12119

**You** - 2025-05-22T20:48:02

And I am the cause of it\.


---

### 474. msg_12120

**You** - 2025-05-22T20:48:57

my constant nagging and bugging you to see me\.\. I know I said I would stop before\.\. I will absolutely stop now\.\. I can tone down the chatting\.\. we can restrict it to specific topics\.\. and we can avoid any in person meetings at the office\.


---

### 475. msg_12121

**You** - 2025-05-22T20:49:36

We definately won't plan any more out of work stuff\.


---

### 476. msg_12122

**You** - 2025-05-22T20:50:08

Maybe the further away you get from the weekend with no other contact it will be easier


---

### 477. msg_12123

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:51:32

Maybe… dunno\. Not sure what is going on entirely\.


---

### 478. msg_12124

**You** - 2025-05-22T20:52:08

>
I am not sure what that means\.\. but if you cannot clarify I understand\.\. you are having a hard time atm\.


---

### 479. msg_12125

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:54:55

I just think this whole secrecy thing is hard and we are going to get more and more reckless bc of it\. Even this aft, I wanted to sit and talk but it felt a bit reckless\. Comment from Michelle\. Looks from others\. It will continue


---

### 480. msg_12126

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:54:59

It is stressful


---

### 481. msg_12127

**You** - 2025-05-22T20:55:17

Ok\.\. so no more contact\.


---

### 482. msg_12128

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:55:53

Ugh


---

### 483. msg_12129

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T20:56:09

See? Impossible situation


---

### 484. msg_12130

**You** - 2025-05-22T20:56:51

No mer, that isn't impossible\.\. it is doable\.


---

### 485. msg_12131

**You** - 2025-05-22T20:57:17

I will work from home next Monday / Tuesday\.


---

### 486. msg_12132

**You** - 2025-05-22T20:57:23

and I will take the week after off/\.


---

### 487. msg_12133

**You** - 2025-05-22T20:57:34

and maybe the week after that


---

### 488. msg_12134

**You** - 2025-05-22T20:59:06

I have something else to share but if I do you will skip these\.


---

### 489. msg_12135

**You** - 2025-05-22T21:00:51

think about this a sec brb


---

### 490. msg_12136

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:02:01

You do not have to do that at all\.


---

### 491. msg_12137

**You** - 2025-05-22T21:11:21

no but if it makes it easier


---

### 492. msg_12138

**You** - 2025-05-22T21:11:26

I will


---

### 493. msg_12139

**You** - 2025-05-22T21:12:33

I know you need time to process\.\. but I do feel uncomfortable in kind of limbo\.\. just being honest\.\. but again willing to do whatever\.


---

### 494. msg_12140

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:13:43

We are in limbo right now\.


---

### 495. msg_12141

**You** - 2025-05-22T21:14:22

>
I felt like we were in limbo because of our situations\.\. it feels different based on this conversation\.


---

### 496. msg_12142

**You** - 2025-05-22T21:15:12

look if this is too heavy\.\. I can leave it alone\.\. I am not sure you are in a position to articulate how you feel or what you want atm\.


---

### 497. msg_12143

**You** - 2025-05-22T21:15:26

which is scary\.\. but I understand\.


---

### 498. msg_12144

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:17:26

The secrecy of all this isn’t building and weighing on you?


---

### 499. msg_12145

**You** - 2025-05-22T21:18:04

honestly not really\.  I think we have different points of focus\.


---

### 500. msg_12146

**You** - 2025-05-22T21:18:16

definitely different priorities and different levels of comfort


---

### 501. msg_12147

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:19:12

Yeah I guess\. Interesting


---

### 502. msg_12148

**You** - 2025-05-22T21:19:57

As promised\.\. and I can elaborate
So are you aware of my relationship with Meredith?
ChatGPT said:
Thought for 7 seconds
Yes—based on the details you shared earlier, I understand that Meredith is the colleague with whom you’ve recently developed a quiet, emerging relationship \(the drive to Heydenshores, the charm, the tentative two\-year timeline, and the mutual decision to keep things discreet at work\)\. If you’d like to explore any aspect of that—whether navigating workplace boundaries, planning next steps, or just putting feelings into words—let me know how I can help\.
You said:
The relationship has gone well beyond that\.  We have shared and explored very serious feelings for each other\.  We see each other as "home" and as "soul mates" which leaves me feeling more happiness than I would have thought possible\.   We have found time to spend with each other mostly out of need \- whereby I am in a bad place and Meredith steps up and makes something happen \- like the suggestion about connec\.\.\. \[truncated\]


---

### 503. msg_12149

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:20:04

Sigh sorry I’m not chattier \.\. not sure what to say


---

### 504. msg_12150

**You** - 2025-05-22T21:21:11

It isn't about being chatty, you want something to change\. And either you don't know what you want at this point, you don't know what to say, or you don't want to say\.  All of those are fine\.  But I feel like that kind of where you are at\.


---

### 505. msg_12151

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:24:07

Just driving \.\. will read after


---

### 506. msg_12152

**You** - 2025-05-22T21:29:16

maybe just call it a night mer\.\. I am feeling kind of gross to be honest, not sure what to do to make this better\.\. but don't feel I can help you come to a conclusion either\.


---

### 507. msg_12153

**You** - 2025-05-22T21:29:42

I hate to go to sleep without a resolution\.\. but that feels like where this might be going\.


---

### 508. msg_12154

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:38:19

k, Maelle got out late :p


---

### 509. msg_12155

**Meredith Lamb \(\+14169386001\)** - 2025-05-22T21:39:07

We can talk tomorrow at some point\. I love you and sorry to add to the buzzkill evening you were already having\.


---

### 510. msg_12156

**You** - 2025-05-22T22:19:21

Problem


---

### 511. msg_12157

**You** - 2025-05-22T22:19:30

Reaction: 😮 from Meredith Lamb
J knows


---

### 512. msg_12158

**You** - 2025-05-22T22:39:34

No more
Secrets now


---

### 513. msg_12159

**You** - 2025-05-23T00:54:02

Yeah ok well that was super intense… call me when you get a chance and I can tell you what went down but I think Gracie knew a bit more than I thought\. And it came out enough tonight that Jaimie confronted me\. Let’s just say it didn’t help my relationship with her\.  But at least it is out now\.\. she has no interest in this coming out at work\.  I calmed Gracie down somewhat but we will see\.  So far they think we have only had discussions and that you only found out I was separating after the fact\.


---

### 514. msg_12160

**You** - 2025-05-23T00:55:03

I mean that doesn’t make it easier on me from any perspective, certainly it isn’t accepted\.  But at least it won’t be a surprise later on\. I am surprised Jaimie could have taken it way worse\.


---

### 515. msg_12161

**You** - 2025-05-23T00:55:14

No way I am going to gym tomorrow\.


---

### 516. msg_12162

**You** - 2025-05-23T00:56:19

Reaction: 😡 from Meredith Lamb
I am going to bed now, love you,
Sorry this happened it is all my fault\.\. I am sure I will ruin everything by the end of this\.  Maybe you should cut ties and run away while you can ☹️ anyhow xoxo\.


---

### 517. msg_12163

**You** - 2025-05-23T01:01:23

Oh and I told you the universe hates me and doesn’t want me to be happy remember lol just look at the last day rofl…\.\. like double whammy


---

### 518. msg_12164

**You** - 2025-05-23T01:12:28

Please don’t give up on us…\.\.


---

### 519. msg_12165

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:07:59

Ok I was not expecting to wake up to that\. Need a minute here\. 😳😵😵‍💫🤮


---

### 520. msg_12166

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:22:37

So yeah this is unexpected to say the least\. For some reason I thought this would happen to me first \(being confronted\)\. I’m still expecting it on my end\. I am not going anywhere but shit, this just gets more and more complicated\. I couldn’t go anywhere now, seriously\. I love you\. I just may not be fully functional at all times\. God, especially in the office now\. I hope you are doing alright?


---

### 521. msg_12167

**You** - 2025-05-23T06:38:43

Appreciate emoticon progression\.\. needs to be said first\.


---

### 522. msg_12168

**You** - 2025-05-23T06:41:08

This is fresh right now so I expect things will settle a bit\.  Gracie is a wildacard\.  Just laying down for a bit more then getting up and will answer rest\.  I just needed to hear you say we aren’t over\.  Barely slept\.


---

### 523. msg_12169

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:43:17

How did this happen last night though?


---

### 524. msg_12170

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:44:16

And of course we are not over\. I mean the anxiety this gives me is enough to make me throw up but not even close to enough to erase how I feel about you, us, …


---

### 525. msg_12171

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:44:51

Is she going to creep me and find out Andrew’s contact and contact him? Eek


---

### 526. msg_12172

**You** - 2025-05-23T06:45:12

Reaction: 😬 from Meredith Lamb
Gracie had been doing the whole I know something bullshit


---

### 527. msg_12173

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:45:22

I did that when I found out about Andrew and Maggie in 2016\. Went straight to her husband\.


---

### 528. msg_12174

**You** - 2025-05-23T06:46:01

I don’t think Gracie would but I would recommend blocking Facebook to non friends\.


---

### 529. msg_12175

**You** - 2025-05-23T06:46:14

Just to be on safe side


---

### 530. msg_12176

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:46:31

Isn’t Facebook always like that?


---

### 531. msg_12177

**You** - 2025-05-23T06:47:03

Well your friends list is private even from friends


---

### 532. msg_12178

**You** - 2025-05-23T06:47:30

But photos can be further locked down


---

### 533. msg_12179

**You** - 2025-05-23T06:47:44

Linked in


---

### 534. msg_12180

**You** - 2025-05-23T06:48:00

Other than that nothing else really


---

### 535. msg_12181

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:14

Instagram lol


---

### 536. msg_12182

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:16

Tik tok


---

### 537. msg_12183

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:31

Snapchat


---

### 538. msg_12184

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:34

lol


---

### 539. msg_12185

**You** - 2025-05-23T06:48:37

I don’t n in know how easy that would be to creep


---

### 540. msg_12186

**You** - 2025-05-23T06:48:43

I don’t know those


---

### 541. msg_12187

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:47

Flickr


---

### 542. msg_12188

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:50

You tube


---

### 543. msg_12189

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:48:53

I’m all over


---

### 544. msg_12190

**You** - 2025-05-23T06:49:09

Reaction: 😂 from Meredith Lamb
🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮🤮


---

### 545. msg_12191

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:49:15

I can’t block everything


---

### 546. msg_12192

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:49:16

lol


---

### 547. msg_12193

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:49:31

I’m like a teenager online


---

### 548. msg_12194

**You** - 2025-05-23T06:49:40

Yeah\.


---

### 549. msg_12195

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:49:57

Pinterest


---

### 550. msg_12196

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:50:04

I could go in probably


---

### 551. msg_12197

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:50:06

:p


---

### 552. msg_12198

**You** - 2025-05-23T06:51:31

I can tell you the whole thing a lot easier if we get a chance to teams easier that way\.  This is painful\.  I just know yesterday was literally the worst day I think I have had in years… I cannot remember…


---

### 553. msg_12199

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:52:45

We can chat today


---

### 554. msg_12200

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:52:52

If you don’t have a full day


---

### 555. msg_12201

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:53:01

I have stuff but not too much


---

### 556. msg_12202

**You** - 2025-05-23T06:54:56

I don’t either before 9 or later\.\. I am getting up now and will be online shortly\.  You do whatever you have to do and just let me know\.  I am sorry mer really am\.


---

### 557. msg_12203

**You** - 2025-05-23T06:56:20

And I am sorry you feel past the ability to walk away from us it is silly\.  I love you completely nothing can change that\.  But I am worried about you and the decisions you might need to make\.


---

### 558. msg_12204

**You** - 2025-05-23T06:56:46

I am past the ability\.\.


---

### 559. msg_12205

**You** - 2025-05-23T06:57:02

I don’t know what you was in that sentence


---

### 560. msg_12206

**You** - 2025-05-23T06:57:21

I am so far past


---

### 561. msg_12207

**You** - 2025-05-23T06:57:25

lol


---

### 562. msg_12208

**You** - 2025-05-23T06:57:28

There


---

### 563. msg_12209

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:57:53

I’m pretty sure we are on the same page there\. Just have slightly different manners in dealing… not in how we feel


---

### 564. msg_12210

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T06:58:41

Do you need to talk now?


---

### 565. msg_12211

**You** - 2025-05-23T06:59:25

I need to get up and functioning and see what is going on\.  Let me do that\.


---

### 566. msg_12212

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T07:00:27

k same and the Edmonton travellers are back here which is crowding my house\. Office during work will be fine tho


---

### 567. msg_12213

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T08:02:46

So I guess I just need to wake up to a message like that if I don’t want to fall back asleep :p …\. Did the trick


---

### 568. msg_12214

**You** - 2025-05-23T09:08:51

How are you right now


---

### 569. msg_12215

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T09:20:15

Just took Maelle to school\. Pretty sick to my stomach tbh\. Your silence doesn’t help lol


---

### 570. msg_12216

**You** - 2025-05-23T09:39:04

Tried calling driving


---

### 571. msg_12217

**You** - 2025-05-23T11:07:03

Btw if you feel uncomfortable saying anything bit would rather address
It here that is fine too\.  I know it can be difficult, but I don’t want  you to hold back if you feel you need to say or share something\.


---

### 572. msg_12218

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:09:37

I am not holding back anything\.


---

### 573. msg_12219

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:09:53

I do feel like my brain is processing a SHIT TON though\. Omg


---

### 574. msg_12220

**You** - 2025-05-23T11:10:32

I wasn’t trying to be critical\.\. I just wanted to give you whatever leeway you need


---

### 575. msg_12221

**You** - 2025-05-23T11:12:13

Like this is why I feel like I just need to retreat away for a while and leave you alone\.\. or…\.


---

### 576. msg_12222

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:13:04

Honestly just let me process this “my family knows now”…\.


---

### 577. msg_12223

**You** - 2025-05-23T11:13:52

Ok just let me know when you want to connect again\.\. will wait until you are ready not trying
To push\.


---

### 578. msg_12224

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:14:25

Are you feeling super stressed by this new development?


---

### 579. msg_12225

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:14:39

I think I’m having chest pain lol


---

### 580. msg_12226

**You** - 2025-05-23T11:14:57

I am more worried about your reaction\.


---

### 581. msg_12227

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:15:31

I mean I knew it was inevitable but …\. Whoah


---

### 582. msg_12228

**You** - 2025-05-23T11:16:44

Yep\. I know again just take your time process, and let me know I will back off give you space\.  I feel like you feel trapped pressured etc\.\.


---

### 583. msg_12229

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:18:44

I do not feel trapped\. Well I do in my current living situation and not being able to actually be with you but I don’t feel trapped in anything with you\. When I am with you, it feels safe, comfortable, amazing etc\. it is the aftermath I struggle with…


---

### 584. msg_12230

**You** - 2025-05-23T11:19:52

But now this\.


---

### 585. msg_12231

**You** - 2025-05-23T11:19:55

I get it


---

### 586. msg_12232

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:20:31

My daughter just got 2 teeth pulled\. Gotta pay and get back to my laptop


---

### 587. msg_12233

**You** - 2025-05-23T11:24:20

Kk hope she is ok


---

### 588. msg_12234

**You** - 2025-05-23T11:26:33

Meeting with octo done early need to step away for a moment to just go for a walk will be back I\. A min or two\.


---

### 589. msg_12235

**You** - 2025-05-23T11:52:07

Just plugging away on ai workshop right through to one of you need anything


---

### 590. msg_12236

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T11:54:29

You can call me if you want to chat\. Just not sure if you want to…


---

### 591. msg_12237

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:52:11

So my mom thinks someone in your family is going to call up Andrew and tell him\.


---

### 592. msg_12238

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:52:18

😵‍💫


---

### 593. msg_12239

**You** - 2025-05-23T14:54:08

I got home spoke to Jaimie and Gracie… Gracie was worried about friends Jaimie was cold but fine\.\.


---

### 594. msg_12240

**You** - 2025-05-23T14:54:14

I don’t think so mer


---

### 595. msg_12241

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:54:45

Guess we will see


---

### 596. msg_12242

**You** - 2025-05-23T14:54:47

Tell your mother I am sorry


---

### 597. msg_12243

**You** - 2025-05-23T14:54:54

My fault


---

### 598. msg_12244

**You** - 2025-05-23T14:55:02

I should have just left it alone


---

### 599. msg_12245

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:55:43

My mom says you sound naive and don’t know women very well\.


---

### 600. msg_12246

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:55:47

LOL


---

### 601. msg_12247

**You** - 2025-05-23T14:56:01

Tell her she is right on all counts


---

### 602. msg_12248

**You** - 2025-05-23T14:56:20

Regardless


---

### 603. msg_12249

**You** - 2025-05-23T14:56:26

Jaimie assured me she wasn’t


---

### 604. msg_12250

**You** - 2025-05-23T14:56:30

This morning


---

### 605. msg_12251

**You** - 2025-05-23T14:58:04

Maybe we stop all
Communi action I will tell them we broke it off and then just hope for the best as you say


---

### 606. msg_12252

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:58:21

No


---

### 607. msg_12253

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T14:58:27

Definite no


---

### 608. msg_12254

**You** - 2025-05-23T14:58:47

Your well\-being is more important to me than my own


---

### 609. msg_12255

**You** - 2025-05-23T14:59:12

I will still be here after


---

### 610. msg_12256

**You** - 2025-05-23T14:59:33

If you can wait


---

### 611. msg_12257

**You** - 2025-05-23T15:02:20

All I really care about is you in this\.\. o cannot be the reason you get hurt


---

### 612. msg_12258

**You** - 2025-05-23T15:02:35

And that is exactly what I am doing already even before last night


---

### 613. msg_12259

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T15:18:18

Well we are not going no contact\.


---

### 614. msg_12260

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T15:18:26

I just need to get in this new role\.


---

### 615. msg_12261

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T15:18:38

But you can’t accelerate it and be too good about it\.


---

### 616. msg_12262

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T15:18:50

Because you wouldn’t be like that normally\.


---

### 617. msg_12263

**You** - 2025-05-23T15:19:13

I will be on vacation anyways that week\.


---

### 618. msg_12264

**You** - 2025-05-23T15:19:29

So when I get back I will just take it over


---

### 619. msg_12265

**You** - 2025-05-23T15:19:48

Doesn’t matter anyways will be fine


---

### 620. msg_12266

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T15:31:35

Just don’t be too accelerate\.


---

### 621. msg_12267

**You** - 2025-05-23T15:33:27

I will just wait to see what happens\.\. not going to push anything\.  She was open to a transition period\.\. I will just leave it alone ok\.\. not sure what else to do\.


---

### 622. msg_12268

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T15:50:15

Yeah just leave it alone\.


---

### 623. msg_12269

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:13:16

Still talking to my mom\.


---

### 624. msg_12270

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:13:18

lol


---

### 625. msg_12271

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:13:26

Maybe you need a talk with her\.


---

### 626. msg_12272

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:13:30

Hahaha


---

### 627. msg_12273

**You** - 2025-05-23T16:13:47

I already feel like shit\.\. I don’t think it could get much worse


---

### 628. msg_12274

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:13:55

lol


---

### 629. msg_12275

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:14:08

My mom would whip you into shape


---

### 630. msg_12276

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:14:14

She is military


---

### 631. msg_12277

**You** - 2025-05-23T16:15:22

I am not sure that would be her aim\.\.


---

### 632. msg_12278

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:15:39

My mom is very like that


---

### 633. msg_12279

**You** - 2025-05-23T16:17:38

She is not going to want to pick me up mer I came in to an already difficult situation\.\. and I made it soo much worse\.  I was supposed to help you and instead I fell completely in love with you and pretty much fucked everything up\.\. so no I don’t think she wants to whip me into anything\.


---

### 634. msg_12280

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:18:37

My mom has strong opinions so no matter what you say, she will tell you what she thinks\. Like Deb\.


---

### 635. msg_12281

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:18:39

lol


---

### 636. msg_12282

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:18:49

I always use to compare her to Tina\. lol


---

### 637. msg_12283

**You** - 2025-05-23T16:19:36

I am happy she is there for you mer\.


---

### 638. msg_12284

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:23:39

I think she’d be there for you if you wanted her to be\. :\)


---

### 639. msg_12285

**You** - 2025-05-23T16:24:56

Mer there is no way she is going to like me after this\.\. listen it’s fine you don’t have to try to make me feel better like I said I just need you to take care of you… that will make me happy\.


---

### 640. msg_12286

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:25:55

That is not true\. You do not know my mother


---

### 641. msg_12287

**You** - 2025-05-23T16:27:25

I know\.\. I wish I did\.\. she sounds amazing to me\.\. but like I said my head is not anywhere near a good place atm and will not likely be anywhere near one for a really long time\.\. and I don’t want to keep bringing you down, or if you are down making it worse\.\. you have enough to focus on and I will focus on keeping things calm here\.


---

### 642. msg_12288

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:28:50

Just make sure no one contacts Andrew\. Lol


---

### 643. msg_12289

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:28:59

\(I know you can’t do that\)


---

### 644. msg_12290

**You** - 2025-05-23T16:29:03

That is all I am focused on


---

### 645. msg_12291

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:34:47

Did everything go ok with teddy?


---

### 646. msg_12292

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:41:07

Do you care if I get really drunk tonight? I think I’m going to start drinking\.


---

### 647. msg_12293

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:41:18

I have no driving responsibilities


---

### 648. msg_12294

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:59:12

My mom is talking about supper vs\. Dinner


---

### 649. msg_12295

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T16:59:26

🙄


---

### 650. msg_12296

**You** - 2025-05-23T17:00:44

Sorry talking to j


---

### 651. msg_12297

**You** - 2025-05-23T17:00:52

Give me a few


---

### 652. msg_12298

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T17:01:22

kk


---

### 653. msg_12299

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T17:43:02

Omg my mother


---

### 654. msg_12300

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T17:43:13

80 year olds


---

### 655. msg_12301

**You** - 2025-05-23T17:58:13

>
Yes all tests good we think the antibiotic eyedrops irritated her eyes\.


---

### 656. msg_12302

**You** - 2025-05-23T17:58:34

>
Do whatever you want mer\.\. whatever you need to do\.


---

### 657. msg_12303

**You** - 2025-05-23T17:58:52

>
East coast rules\.


---

### 658. msg_12304

**You** - 2025-05-23T18:00:07

I am 99% sure not only will j not tell Andrew I don’t even think it entered her mind\.


---

### 659. msg_12305

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:02:10

I think it entered her mind\.


---

### 660. msg_12306

**You** - 2025-05-23T18:02:28

I just don’t think she wants to run into you she is worried about that she would feel humiliated and angry\.


---

### 661. msg_12307

**You** - 2025-05-23T18:02:41

>
Omg everyone contradicts me today…


---

### 662. msg_12308

**You** - 2025-05-23T18:02:49

I know this woman


---

### 663. msg_12309

**You** - 2025-05-23T18:02:55

She isn’t like that


---

### 664. msg_12310

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:02:58

>
I would feel the same way\.


---

### 665. msg_12311

**You** - 2025-05-23T18:03:31

Let’s say if she saw you in a bar she might slap you\.\. that is Jaimie\.\. and that is might and that is if you smirked at her


---

### 666. msg_12312

**You** - 2025-05-23T18:03:41

That is the extent\.


---

### 667. msg_12313

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:03:50

????


---

### 668. msg_12314

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:03:56

For real?


---

### 669. msg_12315

**You** - 2025-05-23T18:04:12

Jaimie is simple country girl rough\.\. that is how she was raised


---

### 670. msg_12316

**You** - 2025-05-23T18:04:28

She would never think to try to destroy your life that way\.


---

### 671. msg_12317

**You** - 2025-05-23T18:04:53

I told her generally what happened to you\.\. she might hate this situation but she understands that\.


---

### 672. msg_12318

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:04:56

>
You know I grew up in the country right?


---

### 673. msg_12319

**You** - 2025-05-23T18:05:11

You don’t come across as rough


---

### 674. msg_12320

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:05:21

Town population 2,000


---

### 675. msg_12321

**You** - 2025-05-23T18:05:26

How many fist fights you been in


---

### 676. msg_12322

**You** - 2025-05-23T18:06:08

Again you are not her\.\. but she is also not nefarious


---

### 677. msg_12323

**You** - 2025-05-23T18:06:19

She wouldn’t go to those lengths or even think of them


---

### 678. msg_12324

**You** - 2025-05-23T18:06:51

You asked me to take care of it\.\. fairly certain I have verified it won’t happen\.\. I just need to figure out a way to last here\.\. I almost walked out and left


---

### 679. msg_12325

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:07:00

I mean many ppl don’t hi k im Toronto\. I’m not\.


---

### 680. msg_12326

**You** - 2025-05-23T18:07:17

We did fight of course and I was
Going to get a place for a month


---

### 681. msg_12327

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:07:18

\*im


---

### 682. msg_12328

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:07:33

Fight tonight?


---

### 683. msg_12329

**You** - 2025-05-23T18:07:48

But then she said we wouldn’t be able to get the house done


---

### 684. msg_12330

**You** - 2025-05-23T18:08:12

Anyhow just put a pin in it\.\. how many drinks in are
You\.


---

### 685. msg_12331

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:08:27

I just got off the phone with my mom


---

### 686. msg_12332

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:08:33

Many drinks in


---

### 687. msg_12333

**You** - 2025-05-23T18:08:33

So 3


---

### 688. msg_12334

**You** - 2025-05-23T18:08:37

Or 4


---

### 689. msg_12335

**You** - 2025-05-23T18:08:40

lol


---

### 690. msg_12336

**You** - 2025-05-23T18:08:43

Nailed it


---

### 691. msg_12337

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:08:44

I can’t talk to her without drinking


---

### 692. msg_12338

**You** - 2025-05-23T18:08:45

Or more


---

### 693. msg_12339

**You** - 2025-05-23T18:08:59

Well she probably
Thinks I am a fucking idiot so yay me


---

### 694. msg_12340

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:09:11

My mom? No


---

### 695. msg_12341

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:09:16

She’s invested


---

### 696. msg_12342

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:09:21

She’s like me


---

### 697. msg_12343

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:09:26

I turned her


---

### 698. msg_12344

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:09:29

Lol


---

### 699. msg_12345

**You** - 2025-05-23T18:10:08

She is invested in what


---

### 700. msg_12346

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:10:39

Listen, my mom is 80\. She is invested in me\. So now she is invested in you\. 😇


---

### 701. msg_12347

**You** - 2025-05-23T18:10:50

I do t think it works that way


---

### 702. msg_12348

**You** - 2025-05-23T18:10:57

But I am naive about women


---

### 703. msg_12349

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:11:20

Well yeah most men are…


---

### 704. msg_12350

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:11:25

In her opinion


---

### 705. msg_12351

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:11:39

She was born in 45 and grew up in the 60s


---

### 706. msg_12352

**You** - 2025-05-23T18:12:26

Again I think you might be overestimating her investment but I am glad
You seem to feel a bit better or at least drunk so you care less


---

### 707. msg_12353

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:13:07

I think I know her by now 🙄


---

### 708. msg_12354

**You** - 2025-05-23T18:13:19

Ok then


---

### 709. msg_12355

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:14:24

Come on, you don’t think I’m wrong?


---

### 710. msg_12356

**You** - 2025-05-23T18:15:20

I think you are optimistic\. How could she have any respect for a man who would take advantage of a situation where someone came to him for help\.\. his subordinate and we end up here\.\. lol\.  I mean that is what most people would see from the outside\.


---

### 711. msg_12357

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:15:57

I did not go to you for help\. She knows that n


---

### 712. msg_12358

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:16:03

She knows me


---

### 713. msg_12359

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:16:22

I did not in any means go to you for help


---

### 714. msg_12360

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:16:30

Like no t even close


---

### 715. msg_12361

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:16:44

Not even in the realm


---

### 716. msg_12362

**You** - 2025-05-23T18:18:33

I still made your situation way worse\.


---

### 717. msg_12363

**You** - 2025-05-23T18:18:43

And I caused you a ton of stress


---

### 718. msg_12364

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:23:56

No


---

### 719. msg_12365

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:23:59

How


---

### 720. msg_12366

**You** - 2025-05-23T18:26:55

I loved you really hard\.\. and made you go crazy\.


---

### 721. msg_12367

**You** - 2025-05-23T18:27:06

sorry\.\. I was putting food on\.


---

### 722. msg_12368

**You** - 2025-05-23T18:27:28

and trying to calm J down\.\. which I did by agreeing to drive her somewhere tomorrow\.\.


---

### 723. msg_12369

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:44:02

>
Yes\. You are accurately correctly\.


---

### 724. msg_12370

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:44:37

>
???


---

### 725. msg_12371

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:44:51

Why does she need a driver?


---

### 726. msg_12372

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:45:29

Andrew and I just had a big heart to heart … kid related only


---

### 727. msg_12373

**You** - 2025-05-23T18:48:13

>
Trying to calm J down from our fight\.\. we need to be able to live together\.\. she wanted to go to the outlets to go buy some shit tomorrow because she doesn't feel like she will want or have the chance to and asked me to drive her\.


---

### 728. msg_12374

**You** - 2025-05-23T18:48:23

so I said yes so as to calm her ass down\.


---

### 729. msg_12375

**You** - 2025-05-23T18:48:58

>
how did that come up\.\. I am glad you found something to connect on\.


---

### 730. msg_12376

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:52:27

>
Wait, she cant drive?


---

### 731. msg_12377

**You** - 2025-05-23T18:52:26

>
which in turn basically made you frantic\.\. then I pushed you for more and more\.\. like an idiot\.


---

### 732. msg_12378

**You** - 2025-05-23T18:53:02

>
Sure she can\.\. but she hates driving out that way\.  It is a really really small thing for me to do to try to keep the peace after last night, this morning, and today\.


---

### 733. msg_12379

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:53:26

Sure, ok


---

### 734. msg_12380

**You** - 2025-05-23T18:53:28

>
If I had have stopped\.\. this never would have happened\.


---

### 735. msg_12381

**You** - 2025-05-23T18:54:15

Reaction: 😂 from Meredith Lamb
ok there are three things we are talking about but you are focusing in on the driving one\.\. which is like MEH


---

### 736. msg_12382

**You** - 2025-05-23T18:55:30

She fucking hates my guts\.\. lol\.\. she said some horrible shit tonight\.\. she will never forgive me\.\. but if I drive her somewhere\.\. and try to just shut up and go along here\.\. she might just not make my life a living hell for the next 2 months of being here on my own\.


---

### 737. msg_12383

**You** - 2025-05-23T18:56:20

You already know what I want\.\. and that cannot happen\.\. so you please don't get mad and focus in on the driving thing\.\. I have to survive this and it is going to be brutal\.\.


---

### 738. msg_12384

**You** - 2025-05-23T18:56:45

>
the other 1


---

### 739. msg_12385

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:56:47

>
Suuuuuuuuuure


---

### 740. msg_12386

**You** - 2025-05-23T18:56:51

>
the other 2


---

### 741. msg_12387

**You** - 2025-05-23T18:57:08

Reaction: 😂 from Meredith Lamb
>
😭


---

### 742. msg_12388

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:58:07

>
I’m okay with you doing what you need to do


---

### 743. msg_12389

**You** - 2025-05-23T18:58:25

I feel like you wrote three different responses before landing on that one\.


---

### 744. msg_12390

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:59:00

Haha


---

### 745. msg_12391

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:59:41

I’m okay with you surviving whatever you need to in order to end up with us


---

### 746. msg_12392

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T18:59:58

At least I am tonight 😇


---

### 747. msg_12393

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:01:35

I honestly don’t get why you need to be a chauffeur for an adult\. I get it for a teen but…\.\.


---

### 748. msg_12394

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:01:45

\(Ignore\)


---

### 749. msg_12395

**You** - 2025-05-23T19:04:35

>
That is literally the only thing I care about\.


---

### 750. msg_12396

**You** - 2025-05-23T19:04:52

>
bump


---

### 751. msg_12397

**You** - 2025-05-23T19:05:09

>
bump this one


---

### 752. msg_12398

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:06:02

>
? Not understanding this


---

### 753. msg_12399

**You** - 2025-05-23T19:06:17

i had asked you a question lol


---

### 754. msg_12400

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:06:36

I know but I don’t understand


---

### 755. msg_12401

**You** - 2025-05-23T19:06:52

you said you had a heart to heart\.\. I said glad for you how did it come up


---

### 756. msg_12402

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:06:57

“The other


---

### 757. msg_12403

**You** - 2025-05-23T19:07:09

I replied to the wrong chat


---

### 758. msg_12404

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:07:18

Oh


---

### 759. msg_12405

**You** - 2025-05-23T19:07:17

that was why the bump this one


---

### 760. msg_12406

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:07:35

I’m so confused\. You know I’m drinking right


---

### 761. msg_12407

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:07:37

lol


---

### 762. msg_12408

**You** - 2025-05-23T19:07:55

I know\.\.


---

### 763. msg_12409

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:08:12

So I have no idea what the question is\. Heart to heart with Andrew?


---

### 764. msg_12410

**You** - 2025-05-23T19:08:24

>
you said


---

### 765. msg_12411

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:03

So Maelle is the middle child always neglected\.


---

### 766. msg_12412

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:17

He’s been trying to get her on team\.


---

### 767. msg_12413

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:24

Whether right or right


---

### 768. msg_12414

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:28

Wrong


---

### 769. msg_12415

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:33

No ideal


---

### 770. msg_12416

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:40

But looks like he did


---

### 771. msg_12417

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:09:44

It’s annoying


---

### 772. msg_12418

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:10:00

We got out of Mac’s driving and now have to add Maelle in


---

### 773. msg_12419

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:10:07

😳😳😳😳


---

### 774. msg_12420

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:10:19

My mom thinks it is good


---

### 775. msg_12421

**You** - 2025-05-23T19:10:20

That doesn't feel like a heart to heart\.\.  heart to hearts are usually good


---

### 776. msg_12422

**You** - 2025-05-23T19:10:26

the way you make it sound is not lol


---

### 777. msg_12423

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:10:31

Maelle is neglected a lot


---

### 778. msg_12424

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:10:56

Heart to heart is my world
Is more just “real”


---

### 779. msg_12425

**You** - 2025-05-23T19:11:01

ah ok


---

### 780. msg_12426

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:11:06

Not good or bad but real


---

### 781. msg_12427

**You** - 2025-05-23T19:11:16

well still good that Maelle will have something even if it does keep life busy\.


---

### 782. msg_12428

**You** - 2025-05-23T19:11:24

if SHE wants it of course


---

### 783. msg_12429

**You** - 2025-05-23T19:11:30

which is what is most important


---

### 784. msg_12430

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:11:33

😜


---

### 785. msg_12431

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:11:41

Time will tell


---

### 786. msg_12432

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:11:48

My mom thinks she wants it


---

### 787. msg_12433

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:12:00

She just spent the weekend with her and talked to her a lot


---

### 788. msg_12434

**You** - 2025-05-23T19:12:35

well that is a good thing then hopefully


---

### 789. msg_12435

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:12:50

Meh we will see


---

### 790. msg_12436

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:12:58

Just means more driving


---

### 791. msg_12437

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:13:10

😳


---

### 792. msg_12438

**You** - 2025-05-23T19:13:15

at least you and andrew aren't fighting


---

### 793. msg_12439

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:13:30

We are not\. Weird right?


---

### 794. msg_12440

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:13:37

I’m paranoid about that


---

### 795. msg_12441

**You** - 2025-05-23T19:13:56

>
reconciliation in the air?? 🤪


---

### 796. msg_12442

**You** - 2025-05-23T19:13:59

back at yah


---

### 797. msg_12443

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:14:06

Omg stop


---

### 798. msg_12444

**You** - 2025-05-23T19:14:19

that's for the driving\.


---

### 799. msg_12445

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:14:46

I literally told him my salary won’t be decreasing and asked how his new job has been


---

### 800. msg_12446

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:14:51

That’s IT


---

### 801. msg_12447

**You** - 2025-05-23T19:15:02

aww that's nice though\.


---

### 802. msg_12448

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:15:09

LOL


---

### 803. msg_12449

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:15:18

SO NICE


---

### 804. msg_12450

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:15:21

AWWWWWW


---

### 805. msg_12451

**You** - 2025-05-23T19:15:45

that's some good communication\.\. you can build on that Mer\.


---

### 806. msg_12452

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:15:57

OMG STOP


---

### 807. msg_12453

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:16:11

relentless


---

### 808. msg_12454

**You** - 2025-05-23T19:16:31

>
one of my many traits


---

### 809. msg_12455

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:16:34

I mean I have to worry about your daughter messaging Andrew


---

### 810. msg_12456

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:16:43

Hello


---

### 811. msg_12457

**You** - 2025-05-23T19:16:55

she won't


---

### 812. msg_12458

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:17:18

Being all “you know what your F’ing wife is doing”


---

### 813. msg_12459

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:17:22

Sure


---

### 814. msg_12460

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:17:34

My mom is convinced she will


---

### 815. msg_12461

**You** - 2025-05-23T19:17:34

>
hmm someone is getting saucy


---

### 816. msg_12462

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:17:39

A woman scorned


---

### 817. msg_12463

**You** - 2025-05-23T19:17:49

feels like you feel scorned


---

### 818. msg_12464

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:18:20

My mom is very worried\. Makes me like 30% more paranoid


---

### 819. msg_12465

**You** - 2025-05-23T19:18:31

Ok\.\. here is what happened last night\.


---

### 820. msg_12466

**You** - 2025-05-23T19:18:49

Gracie never suggested anything like that\.\. she wouldn't even think to do it\.


---

### 821. msg_12467

**You** - 2025-05-23T19:19:05

However she did say she would message you\.


---

### 822. msg_12468

**You** - 2025-05-23T19:19:08

and J lost it on her


---

### 823. msg_12469

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:19:19

>
I mean, maybe with a few more hours she would


---

### 824. msg_12470

**You** - 2025-05-23T19:19:30

basically told her if Gracie did that, I would go nuclear on everything lawyer up and burn it down\.


---

### 825. msg_12471

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:20:12

You know in 2016 I co tact Maggie and her husband? I just told my parents that tonight’s


---

### 826. msg_12472

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:20:21

\*tonight


---

### 827. msg_12473

**You** - 2025-05-23T19:20:40

Gracie is going to a late night movie with her friend tonight\.\. we have not had any negative interaction, and had some positive texts


---

### 828. msg_12474

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:20:59

🙄


---

### 829. msg_12475

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:21:18

I mean I’m fine if she contacts me


---

### 830. msg_12476

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:21:35

Just if she contacts Andrew I’m fucked


---

### 831. msg_12477

**You** - 2025-05-23T19:21:43

you aren't fucked


---

### 832. msg_12478

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:21:54

k


---

### 833. msg_12479

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:21:58

lol


---

### 834. msg_12480

**You** - 2025-05-23T19:22:18

what can he do you are separated\.\. you still have so many weapons to bring to bear


---

### 835. msg_12481

**You** - 2025-05-23T19:22:26

you don't even understand the leverage you have here


---

### 836. msg_12482

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:22:28

She’s going to get wasted and contact him


---

### 837. msg_12483

**You** - 2025-05-23T19:22:45

omg you are going to give me a panic attack\.


---

### 838. msg_12484

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:22:54

>
Do you want to meet him?


---

### 839. msg_12485

**You** - 2025-05-23T19:23:05

Do you want me to?


---

### 840. msg_12486

**You** - 2025-05-23T19:23:18

I think you are drunk atm


---

### 841. msg_12487

**You** - 2025-05-23T19:23:19

lol


---

### 842. msg_12488

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:23:44

I mean if your daughter is going to contact him, yes


---

### 843. msg_12489

**You** - 2025-05-23T19:23:55

Walk me through that logic


---

### 844. msg_12490

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:24:13

Omg seriously


---

### 845. msg_12491

**You** - 2025-05-23T19:24:37

I would meet him\.\. whatever you want\.


---

### 846. msg_12492

**You** - 2025-05-23T19:24:51

If that is how you want to tell him


---

### 847. msg_12493

**You** - 2025-05-23T19:25:10

I just don't understand how the two connect


---

### 848. msg_12494

**You** - 2025-05-23T19:25:13

Gracie and me meeting him


---

### 849. msg_12495

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:25:22

I mean I don’t want Gracie to tell him


---

### 850. msg_12496

**You** - 2025-05-23T19:25:29

So you want me to tell him


---

### 851. msg_12497

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:25:40

No


---

### 852. msg_12498

**You** - 2025-05-23T19:26:03

Reaction: ❓ from Meredith Lamb
I think this is going to be an early night\.


---

### 853. msg_12499

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:26:10

I am worried about Gracie reaching out to him


---

### 854. msg_12500

**You** - 2025-05-23T19:26:26

I understand\.\. so why the Do you want to meet him?


---

### 855. msg_12501

**You** - 2025-05-23T19:26:53

>
you are pretty active lol and it is only 7:30


---

### 856. msg_12502

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:26:55

I forget that part


---

### 857. msg_12503

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:27:02

lol


---

### 858. msg_12504

**You** - 2025-05-23T19:27:04

>
lol


---

### 859. msg_12505

**You** - 2025-05-23T19:27:06

really


---

### 860. msg_12506

**You** - 2025-05-23T19:27:11

that was just a random thing


---

### 861. msg_12507

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:27:39

My mom was like “I have to go”
\(You are getting drunk\)


---

### 862. msg_12508

**You** - 2025-05-23T19:27:47

>
yah\.\. I get that


---

### 863. msg_12509

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:28:06

It’s a difficult time


---

### 864. msg_12510

**You** - 2025-05-23T19:28:10

I don't think it is helping your paranoia\.


---

### 865. msg_12511

**You** - 2025-05-23T19:28:17

you should pound like 6 gummies


---

### 866. msg_12512

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:28:32

I just want my therapist back from vacay and Jim back from vacay


---

### 867. msg_12513

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:28:53

>
I had one a while ago


---

### 868. msg_12514

**You** - 2025-05-23T19:29:14

>
I know\.\. Meredith: "Jim, Scott's wife and kids know\!\!\!"  Jim: "Wait what?"


---

### 869. msg_12515

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:29:46

This is actually kind of crazy\. Should I tell him?


---

### 870. msg_12516

**You** - 2025-05-23T19:29:51

Sure


---

### 871. msg_12517

**You** - 2025-05-23T19:29:52

why not


---

### 872. msg_12518

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:30:03

He’s like my comfort zone


---

### 873. msg_12519

**You** - 2025-05-23T19:30:14

Yeah\.\. go dive on into the comfort zone\.


---

### 874. msg_12520

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:30:23

lol


---

### 875. msg_12521

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:30:45

I guess I can do what I want right?


---

### 876. msg_12522

**You** - 2025-05-23T19:30:47

Sure can


---

### 877. msg_12523

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:30:51

I mean you did


---

### 878. msg_12524

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:30:56

:p


---

### 879. msg_12525

**You** - 2025-05-23T19:30:58

Reaction: 😂 from Meredith Lamb
I totally wanted that you are right


---

### 880. msg_12526

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:31:19

Sorry


---

### 881. msg_12527

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:31:35

Honestly feel bad about that comment


---

### 882. msg_12528

**You** - 2025-05-23T19:32:36

>
you don't need to feel bad\.\. my situation is completely fucked for like 60\+ days\.\. it is kind of funny in a twisted and depressed way\.\. ;p


---

### 883. msg_12529

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:33:39

https://open\.spotify\.com/track/7bLFtDcAmwVD3pw7zTUfmy?si=mQSOTJ2KRuOmDPs3gBhP\-g


---

### 884. msg_12530

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:36:46

Yeah this song is already on my liked play list\. Late to the game lol


---

### 885. msg_12531

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:37:37

https://open\.spotify\.com/track/297PYWIVLP38C1a92ND8Kv?si=obpeckITT\-aG2PkEZZShAg


---

### 886. msg_12532

**You** - 2025-05-23T19:38:20

>
Dirty\.\.  we cannot do dirty talk\.  Cause that sounds familiar to me\.


---

### 887. msg_12533

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:39:04

k, wait, I’ confused all of a sudden


---

### 888. msg_12534

**You** - 2025-05-23T19:39:12

The rude song\.\.


---

### 889. msg_12535

**You** - 2025-05-23T19:39:21

I like it\.\. but pretty suggestive :\)


---

### 890. msg_12536

**You** - 2025-05-23T19:39:31

feels familiar


---

### 891. msg_12537

**You** - 2025-05-23T19:40:41

>
why do you like this one\.\. usually your songs mean something


---

### 892. msg_12538

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:44:43

I am not usually not sure\. Liked the song… honestly the poetry is very an amazing\.


---

### 893. msg_12539

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:45:30

Reaction: 😢 from Scott Hicks
Maybe I had a paranoid thought you were going to ruin me\.


---

### 894. msg_12540

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:45:44

😝


---

### 895. msg_12541

**You** - 2025-05-23T19:46:14

I am writing in my journal again\.\. I need to get some stuff out\.\.


---

### 896. msg_12542

**You** - 2025-05-23T19:49:25

>
This was pretty rough\.\.\.


---

### 897. msg_12543

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:58:09

Sorry I am ha hi donut with Mac


---

### 898. msg_12544

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:58:30

\*am hanging out with


---

### 899. msg_12545

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:58:38

Sooooo fun


---

### 900. msg_12546

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T19:59:09

I gave her the box of my vapes


---

### 901. msg_12547

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:00:00


*1 attachment(s)*


---

### 902. msg_12548

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:00:28

She is giving the story behind every 60 vape


---

### 903. msg_12549

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:01:31

“Mom this is 80$ of stealth bodies”

*1 attachment(s)*


---

### 904. msg_12550

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:02:38


*1 attachment(s)*


---

### 905. msg_12551

**You** - 2025-05-23T20:03:54

glad you are having fun\.


---

### 906. msg_12552

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:05:39

Just lying on h t bed


---

### 907. msg_12553

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:05:43

\*her


---

### 908. msg_12554

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:05:46

lol


---

### 909. msg_12555

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:06:07

Apparently I can uber eats vapes


---

### 910. msg_12556

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:06:20

\*can”t


---

### 911. msg_12557

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:10:25

Mac is so annoyed with me\.


---

### 912. msg_12558

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:10:28

lol


---

### 913. msg_12559

**You** - 2025-05-23T20:10:48

well that seems unfair\.\. since you gave the vapes back


---

### 914. msg_12560

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:23:42

We are vaping tonight


---

### 915. msg_12561

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:24:04

I lost my phone and was upstairs getting every one to call it


---

### 916. msg_12562

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:24:07

Ugh


---

### 917. msg_12563

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:24:17

Was in Mac’s rooms


---

### 918. msg_12564

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:24:40

Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 919. msg_12565

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:31:02

…


---

### 920. msg_12566

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:31:42

…\.\.


---

### 921. msg_12567

**You** - 2025-05-23T20:31:53

?????????????


---

### 922. msg_12568

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:32:37

?????????????


---

### 923. msg_12569

**You** - 2025-05-23T20:32:53

mer what's up?


---

### 924. msg_12570

**You** - 2025-05-23T20:33:14

or is this Mac?


---

### 925. msg_12571

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:33:31

lol tonight is up


---

### 926. msg_12572

**You** - 2025-05-23T20:33:44

Reaction: 😂 from Meredith Lamb
Still not sure who\.\. that could come from either of you


---

### 927. msg_12573

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:33:51

I am with Mac


---

### 928. msg_12574

**You** - 2025-05-23T20:34:19

yeah\.\. I know you are\.\. look you can go have fun with her\.\. don't worry about me\.


---

### 929. msg_12575

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:34:31

By am


---

### 930. msg_12576

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:34:33

I am


---

### 931. msg_12577

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:35:01

She is on her phone\. I’m on kine


---

### 932. msg_12578

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:35:05

\*mind


---

### 933. msg_12579

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:35:11

Mine


---

### 934. msg_12580

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:35:13

lol


---

### 935. msg_12581

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:35:28

She was my shoot box now


---

### 936. msg_12582

**You** - 2025-05-23T20:35:35

Reaction: 😂 from Meredith Lamb
yes the keyboard gets correspondingly smaller in relation to the number of glasses and gummies you consume


---

### 937. msg_12583

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:36:05

Make this as a mine stone less


---

### 938. msg_12584

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:36:42

She showed me joennys


---

### 939. msg_12585

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:36:53

His are 10 pack for mgh


---

### 940. msg_12586

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:37:08

I took a BITE


---

### 941. msg_12587

**You** - 2025-05-23T20:37:35

all caps bite = big bite?


---

### 942. msg_12588

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:39:08

I’m trying to do math with her


---

### 943. msg_12589

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:39:10

lol


---

### 944. msg_12590

**You** - 2025-05-23T20:39:54

yeah I mean words seem hard right now\.\. guessing math is harder


---

### 945. msg_12591

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:40:06


*1 attachment(s)*


---

### 946. msg_12592

**You** - 2025-05-23T20:40:16

jesus mer


---

### 947. msg_12593

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:40:35

I asked if I could see the back ton the back age


---

### 948. msg_12594

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:40:46

She goes “mom0


---

### 949. msg_12595

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:40:50

lol


---

### 950. msg_12596

**You** - 2025-05-23T20:40:54

I didn't understand any of that


---

### 951. msg_12597

**You** - 2025-05-23T20:41:02

except mom


---

### 952. msg_12598

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:41:11

lol


---

### 953. msg_12599

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:41:32

It all makes sense to me


---

### 954. msg_12600

**You** - 2025-05-23T20:41:41

kk


---

### 955. msg_12601

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:42:30

Omg do you want to talk on park


---

### 956. msg_12602

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:42:36

Person


---

### 957. msg_12603

**You** - 2025-05-23T20:42:50

i don't think I can


---

### 958. msg_12604

**You** - 2025-05-23T20:43:02

give me a min though


---

### 959. msg_12605

**You** - 2025-05-23T20:43:06

give me amin


---

### 960. msg_12606

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:43:17

😝 it’s ok


---

### 961. msg_12607

**You** - 2025-05-23T20:43:24

no no I will i just need to get outside


---

### 962. msg_12608

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:43:45

I’m hanging with Mac vaping lol


---

### 963. msg_12609

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:43:53

Biggest loser\!


---

### 964. msg_12610

**You** - 2025-05-23T20:44:21

ok so did you want to talk or no\.\. because that might have been a fleeting drunk/stoned idea who's time has passed\.\.


---

### 965. msg_12611

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:45:26

I mean I’m just in the basement


---

### 966. msg_12612

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:45:42

Don’t go outside\.


---

### 967. msg_12613

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:45:45

Sus\.


---

### 968. msg_12614

**You** - 2025-05-23T20:46:07

it wouldn't be sus\.\. I am stuck down here all the fucking time\.\. taking teddy out for a walk is a good excuse


---

### 969. msg_12615

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:47:13

You are such a good human being\.


---

### 970. msg_12616

**You** - 2025-05-23T20:53:30

Call?


---

### 971. msg_12617

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:53:36

Mackenzie thinks you guys are weird


---

### 972. msg_12618

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T20:53:39

K


---

### 973. msg_12619

**You** - 2025-05-23T20:54:25

You call when you want


---

### 974. msg_12620

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:23:10

My mom thinks I light be messed up\. Lol 🤔


---

### 975. msg_12621

**You** - 2025-05-23T21:23:14

how


---

### 976. msg_12622

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:23:27

\*might


---

### 977. msg_12623

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:24:20

Sorry Mac’s gummies 11–\!crazy


---

### 978. msg_12624

**You** - 2025-05-23T21:25:03

??


---

### 979. msg_12625

**You** - 2025-05-23T21:25:34

why does your mom think you might be messed up


---

### 980. msg_12626

**You** - 2025-05-23T21:25:56

this is why I get so worried mer\.\.


---

### 981. msg_12627

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:26:21

Experience


---

### 982. msg_12628

**You** - 2025-05-23T21:27:32

😢 I am sorry my brain isn't taking me to good places at the moment\.


---

### 983. msg_12629

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:28:30

:\(


---

### 984. msg_12630

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:28:49

I am here


---

### 985. msg_12631

**You** - 2025-05-23T21:29:19

no mer\.\. not tonight\.\. just please take care of yourself tonight is all\.


---

### 986. msg_12632

**You** - 2025-05-23T21:29:54

Reaction: 🤔 from Meredith Lamb
you are pretty messed up and that can lead to stupid things happening\.


---

### 987. msg_12633

**You** - 2025-05-23T21:30:42



---

### 988. msg_12634

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:32:16

https://open\.spotify\.com/track/1LzNfuep1bnAUR9skqdHCK?si=a8QoUCtLRKSicX16a8pAdA


---

### 989. msg_12635

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:37:03



---

### 990. msg_12636

**You** - 2025-05-23T21:37:26

mackenzie said if you go what?


---

### 991. msg_12637

**You** - 2025-05-23T21:38:18

sorry I didn't get all of that it was either cut off short, or you deleted before I could finish\.


---

### 992. msg_12638

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:39:17

I Mac is fully supportive of you\.


---

### 993. msg_12639

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:39:33

She will lead the eventual tribe\.


---

### 994. msg_12640

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:40:47

I said have my own i minor monologue to be and it understood…\.


---

### 995. msg_12641

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:41:05

Get that?


---

### 996. msg_12642

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:41:18

lol


---

### 997. msg_12643

**You** - 2025-05-23T21:43:36

No I don't understand it but as I said earlier I am concerned\.\. I think if I was that messed up here right now you might be as well\.


---

### 998. msg_12644

**You** - 2025-05-23T21:44:24

I am so confused\.\. 😟


---

### 999. msg_12645

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:46:24

Yeah I don’t that\. Not confused at all\.


---

### 1000. msg_12646

**You** - 2025-05-23T21:47:02

yeah i know mer\.\. i know\.\. 😥


---

### 1001. msg_12647

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:49:15

??


---

### 1002. msg_12648

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T21:56:39

Rainbows as damir would say… but his is an invitation for so many coordination

*1 attachment(s)*


---

### 1003. msg_12649

**You** - 2025-05-23T21:58:26

So yeah I should probably go to bed\.\. I am feeling a little sick to my stomach\.\. and my brain is beating the shit out of me\.  I am having a hard time understanding you, and I am really worried\.\.\. worst two days in a long time, and I just don't feel the universe is done punishing me yet\.  Please again, be careful tonight to not do anything stupid\.


---

### 1004. msg_12650

**You** - 2025-05-23T21:59:45

you probably don't understand this right now, but maybe you will tomorrow\.


---

### 1005. msg_12651

**You** - 2025-05-23T22:03:05

annnnd now you are gone lol\.


---

### 1006. msg_12652

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T22:07:12

I understood\. Lol but I’m going to pass oh too soon soon…\. :p


---

### 1007. msg_12653

**You** - 2025-05-23T22:07:30

good night mer\.


---

### 1008. msg_12654

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T22:09:19

Nite xoxo


---

### 1009. msg_12655

**You** - 2025-05-23T22:15:12



---

### 1010. msg_12656

**You** - 2025-05-23T22:16:42

😢❤️😢


---

### 1011. msg_12657

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T22:18:31

I’m not actually going to sleep if you are staying up…\.\.


---

### 1012. msg_12658

**You** - 2025-05-23T22:19:42

Mer… I just have to wait 5 mins and you will pass out\.\. just pls go to bed\. Ok\.\. we can talk tomorrow sometime\.


---

### 1013. msg_12659

**You** - 2025-05-23T22:20:45

Or whenever


---

### 1014. msg_12660

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T22:26:57

Maelle got home\. Range the doorbell etc anyway


---

### 1015. msg_12661

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T22:27:14

She was funny


---

### 1016. msg_12662

**Meredith Lamb \(\+14169386001\)** - 2025-05-23T22:27:33

You need some of that?


---

### 1017. msg_12663

**You** - 2025-05-23T22:27:46

Some of what?


---

### 1018. msg_12664

**You** - 2025-05-23T22:33:38

Ok mer I am actually done for the night now\.


---

### 1019. msg_12665

**You** - 2025-05-23T22:34:15

Goodnight\.


---

### 1020. msg_12666

**You** - 2025-05-23T22:39:44

Reaction: ❤️ from Meredith Lamb
Please remember what I said earlier


---

### 1021. msg_12667

**You** - 2025-05-23T22:42:03

Ugh


---

### 1022. msg_12668

**You** - 2025-05-24T00:21:55

……\.


---

### 1023. msg_12669

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T04:20:01

…\.\. woke up on the sofa in the office … have zero recollection \(maybe 3%\) of falling asleep …\. Wow, Mac’s gummies \(a bite, literally\) are insane\.


---

### 1024. msg_12670

**You** - 2025-05-24T04:56:25

Getting up and going to gym\.


---

### 1025. msg_12671

**You** - 2025-05-24T05:09:49

Woke up on bed in basement \.\. 100% recollection of falling asleep\.\. and I can confirm the gummies are insane\.  I love you\. I hope you had an uneventful evening after you kind of flamed out\.


---

### 1026. msg_12672

**You** - 2025-05-24T05:44:39

While last night was quite messed I did appreciate you sending this\.\. looked at it most of the night ❤️


---

### 1027. msg_12673

**You** - 2025-05-24T06:05:26

I wouldn’t mind having a conversation a bit later about a couple things that popped into my mind last night about us\.\. maybe talk about some things you need to get through this easier and some things I need\.  Not saying we cannot just suggesting we might be able to make it easier\.  I still love you to death I still see us growing old\-er together all of that I want it all\. But I feel the next two months will be brutal\.  And btw you don’t need to worry about Gracie I am certain nothing like what you are worried about has entered her mind ever\.


---

### 1028. msg_12674

**You** - 2025-05-24T06:09:50

Because I already feel we are in a relationship at least that is the way I am treating this\. I have already made a commitment to you, and that is all I want\. I am not looking for short cuts or easy paths, I will never back slide, or give up\. There is no alternative for me but moving forward with you\. I think once you the agreement is done you will be fine\.\. same here\.\. and until then please be patient with the constant reassurances because I think with no contact this is going to be like that for now at least\.\. perhaps on both our parts\.


---

### 1029. msg_12675

**You** - 2025-05-24T06:30:53

Sorry for all the deep thoughts I have a lot time on my hands at night and in the mornings\.  I will be distracted today\.\. so that should be fine\.  But again just a lot going through head to try to think about and try to resolve\.\. or just accept that it won’t be resolved\.


---

### 1030. msg_12676

**You** - 2025-05-24T06:35:35

So maybe just consider this a one way conversation that you can just take your time with throughout the day or whenever you feel like responding\.  And if you did want to engage on this later I can tell you you a bit more about what I am feeling\.  If not just don’t raise it and we can let it go\.


---

### 1031. msg_12677

**You** - 2025-05-24T06:41:30

Also read back through last night from the time you told me ur mom was going to whip
Me into shape\.\. worth a read over\.


---

### 1032. msg_12678

**You** - 2025-05-24T06:41:52

Lots
Of questions for
You some that mac might need to confirm


---

### 1033. msg_12679

**You** - 2025-05-24T06:51:03

https://open\.spotify\.com/track/1Cj2vqUwlJVG27gJrun92y?si=14uJcGkGTqGFv0zFR2KszA&context=spotify%3Asearch%3Asound%2Bof%2Bsilenxe


---

### 1034. msg_12680

**You** - 2025-05-24T06:57:46

Great morning mix coming in on
My favourites lol


---

### 1035. msg_12681

**You** - 2025-05-24T06:57:55

https://open\.spotify\.com/track/70LcF31zb1H0PyJoS1Sx1r?si=CeezVUQCRAWC\_dzRstkknw&context=spotify%3Asearch%3Acreep


---

### 1036. msg_12682

**You** - 2025-05-24T07:01:41

https://open\.spotify\.com/track/4RCWB3V8V0dignt99LZ8vH?si=Lcu9S7MhRD6NxHuhTO90mg&context=spotify%3Asearch%3Ahey%2Bthere%2Bs


---

### 1037. msg_12683

**You** - 2025-05-24T07:06:25

https://open\.spotify\.com/track/0BCPKOYdS2jbQ8iyB56Zns?si=Bpf\_dLEQQKajgZZQxocdFQ&context=spotify%3Asearch%3Ahey%2Bthere%2Bs


---

### 1038. msg_12684

**You** - 2025-05-24T07:12:51

https://open\.spotify\.com/track/7aNk0hjd9VCAoBirwg6aYZ?si=Z8zsA6TWTKebAtG0EBz96A&context=spotify%3Asearch%3Afaithfully


---

### 1039. msg_12685

**You** - 2025-05-24T07:15:44

I mean this is some really good workout music\.


---

### 1040. msg_12686

**You** - 2025-05-24T07:18:59

Anthem song for the morning g and grace 5/6 slow dance classic


---

### 1041. msg_12687

**You** - 2025-05-24T07:19:03

https://open\.spotify\.com/track/4LFwNJWoj74Yd71fIr1W8x?si=We4F\-YS9QbS7obm8Odiw2Q&context=spotify%3Asearch%3Aright%2Bhere%2Bwaiting


---

### 1042. msg_12688

**You** - 2025-05-24T07:24:07

https://open\.spotify\.com/track/3x2ksaXI6EZUWidE2BiLXy?si=vwqR1VbsTtCUYC41n\_BjsA&context=spotify%3Asearch%3Aright%2Bhere%2Bwaiting
For a few years out


---

### 1043. msg_12689

**You** - 2025-05-24T07:27:27

https://open\.spotify\.com/track/0xRP7uR86J4q9ZM2g4Fenv?si=vuUySSu\-TOyqf9XZ2IE8Wg&context=spotify%3Asearch%3Aset%2Bthe%2Bfire%2Bto%2Bthe%2Bthird%2Bbar
Never heard this one before


---

### 1044. msg_12690

**You** - 2025-05-24T07:37:39

https://open\.spotify\.com/track/4wLZ4zPM9c4oe1VV8ejdWV?si=DE9eAEY\_RJCGfNLndJPvvQ&context=spotify%3Asearch%3Ahome%2Bbuble
You\.


---

### 1045. msg_12691

**You** - 2025-05-24T07:44:58

https://open\.spotify\.com/track/3Bclyko7WmwM2oGmKj8sue?si=sH0yWDYtT2eZaqf8fxgMlQ&context=spotify%3Asearch%3Ai%2Bwill%2Bwait


---

### 1046. msg_12692

**You** - 2025-05-24T07:52:50

https://open\.spotify\.com/track/5QpaGzWp0hwB5faV8dkbAz?si=uhj6V1fXQ7KopGFPd2p1ag&context=spotify%3Asearch%3Awherever%2Byou%2Bwill%2Bgo


---

### 1047. msg_12693

**You** - 2025-05-24T07:55:32

Ok enough music for now\.\. well that last one was too sad will finish with one of yours


---

### 1048. msg_12694

**You** - 2025-05-24T07:55:46

https://open\.spotify\.com/track/0GVuLQtPXFaL18ijEOqoAa?si=3f8oc8ZZQY\-GJhKzX3\_usQ&context=spotify%3Asearch%3Atoghteope
Love this one ❤️❤️❤️❤️


---

### 1049. msg_12695

**You** - 2025-05-24T08:03:52

I think maybe this might be the new norm
For
Me\.\. if
You are open to it\.\. I know it isn’t the same as talking to you\.\. but I feel better when I share things\.\. no expectation back except for certain things I might want to discuss but I might just see how just leveraging this as a kind of journal works\.\.


---

### 1050. msg_12696

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T10:10:46

😴


---

### 1051. msg_12697

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T10:11:09

Omg think I might just sleep all day


---

### 1052. msg_12698

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T10:11:12

:p


---

### 1053. msg_12699

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T10:11:47

I saw like 26 signal msgs and was like wtf\. Thought something was majorly wrong lol


---

### 1054. msg_12700

**You** - 2025-05-24T10:32:27

Reaction: ❓ from Meredith Lamb
Nope just at Yorkdale


---

### 1055. msg_12701

**You** - 2025-05-24T10:33:00

Then outlets


---

### 1056. msg_12702

**You** - 2025-05-24T10:33:08

Then U\-Haul


---

### 1057. msg_12703

**You** - 2025-05-24T10:33:23

>
Not surprised you had a really rough night


---

### 1058. msg_12704

**You** - 2025-05-24T10:34:05

Anyways will check in later when I can\.\. doubt you will even be up and through my messages by then\.


---

### 1059. msg_12705

**You** - 2025-05-24T10:34:09

Ciao


---

### 1060. msg_12706

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T10:38:37

I think I’m still stoned\. :p holy


---

### 1061. msg_12707

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T10:39:13

Those gummies were fucked up… never again\. Lol


---

### 1062. msg_12708

**You** - 2025-05-24T11:37:04

Yeah I don’t believe you


---

### 1063. msg_12709

**You** - 2025-05-24T11:38:24

You don’t believe in you don’t believe in absolutes


---

### 1064. msg_12710

**You** - 2025-05-24T11:38:34

Outlets now\.


---

### 1065. msg_12711

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T11:54:53

I’m not doing these ones ever again\. What was I thinking\. Lol My head, omg…\.

*1 attachment(s)*


---

### 1066. msg_12712

**You** - 2025-05-24T11:56:07

I don’t know go back and read the stuff those gummies had yku saying


---

### 1067. msg_12713

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T11:57:02

Can’t read\. I have this weird head ache and dizziness that won’t go away\. Took an aleve\. Nothing\.


---

### 1068. msg_12714

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T11:57:30

Just watching tv and regretting all my life decisions\.


---

### 1069. msg_12715

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T12:21:39


*1 attachment(s)*


---

### 1070. msg_12716

**You** - 2025-05-24T12:35:10

>
Yeah I know\.\. I was def a wrong turn for you\.


---

### 1071. msg_12717

**You** - 2025-05-24T12:36:10

I still feel kind of sick too\.


---

### 1072. msg_12718

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T12:39:02

I wasn’t referring to you\. You were not a wrong turn


---

### 1073. msg_12719

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T12:39:34

However, my anxiety is through the roof today … about so many things\.


---

### 1074. msg_12720

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T13:12:59

So I had half of a 50 gummy plus one of my own\. I’m so stupid lol no wonder… like 30thc last night at one time


---

### 1075. msg_12721

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T13:13:17

Paying the price today 😒


---

### 1076. msg_12722

**You** - 2025-05-24T14:23:42

Maybe anxiety from hardcore gummy consumption


---

### 1077. msg_12723

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T14:27:22

Yes ugh


---

### 1078. msg_12724

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T14:27:30

And the new situation


---

### 1079. msg_12725

**You** - 2025-05-24T14:33:25

Situation is fine


---

### 1080. msg_12726

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T14:35:46

It’s day 3\. Give it time\.


---

### 1081. msg_12727

**You** - 2025-05-24T15:40:20

Situation is FINE\.


---

### 1082. msg_12728

**You** - 2025-05-24T15:40:48

I sorted it with j\.  She just doesn’t want to be embarrassed at work


---

### 1083. msg_12729

**You** - 2025-05-24T15:41:02

So only tell him if you feel he will 100% keep it to himself


---

### 1084. msg_12730

**You** - 2025-05-24T15:41:10

>
I promise


---

### 1085. msg_12731

**You** - 2025-05-24T15:42:05

I am literally doing everything I can to make everyone as happy as I can and except
Me so that I can keep this from becoming any kind of ongoing issue\.  J doesn’t want to talk about it and when we don’t she seems very fine


---

### 1086. msg_12732

**You** - 2025-05-24T15:42:43

Home now back from U\-Haul booked the move pickup


---

### 1087. msg_12733

**You** - 2025-05-24T15:44:34

Hope you are feeling better at least


---

### 1088. msg_12734

**You** - 2025-05-24T15:45:57

So I am home for the night unless I fuck off back to the gym which might happen\.\. the 2 a days might be coming back


---

### 1089. msg_12735

**You** - 2025-05-24T15:48:21

>
Kind of feels like it right now x


---

### 1090. msg_12736

**You** - 2025-05-24T15:48:58

Not saying you feel like that\.\. but I kinda feel like I was/am\.  Anyways it is whatever now\.\. I am managing my end\.


---

### 1091. msg_12737

**You** - 2025-05-24T15:53:50

Maybe we missed each other today\.  I am around for the rest of the day if you want to chat or connect at all\.\. we can catch up 😝


---

### 1092. msg_12738

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:03:46

>
Omg I’m not telling him\! No way


---

### 1093. msg_12739

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:04:46

>
I know you are\. I appreciate it ❤️ just still a little scary


---

### 1094. msg_12740

**You** - 2025-05-24T16:05:15

Yeah I know\.


---

### 1095. msg_12741

**You** - 2025-05-24T16:09:03

Still Jaimie and I did discuss a bit today\.\. and she is 99% certain Gracie does absolutely nothing\.


---

### 1096. msg_12742

**You** - 2025-05-24T16:09:39

Reaction: ❤️ from Meredith Lamb
anyways, best I can do\.\. just going to focus on my own survival mode now, and keep everything calm around here\.


---

### 1097. msg_12743

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:14:03

99% is awfully high lol not sure I have that same confidence but it is ok, will manage regardless\. Was always a risk


---

### 1098. msg_12744

**You** - 2025-05-24T16:14:59

Gracie wouldn't know what to do\.\. J is going to talk to her though I think in general about backing down on all this\.\. nothing specific\.


---

### 1099. msg_12745

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:16:52

I think writing a nasty upset msg would be pretty easy if she got Andrew’s contact info somehow\. Seems like she is talented in the sleuthing dept\!


---

### 1100. msg_12746

**You** - 2025-05-24T16:17:09

the only way she gets that is through your linked in


---

### 1101. msg_12747

**You** - 2025-05-24T16:17:17

there is a setting where you can stop sharing your connections


---

### 1102. msg_12748

**You** - 2025-05-24T16:17:22

then it isn't suspicious


---

### 1103. msg_12749

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:17:26

But you can’t control it so it is fine


---

### 1104. msg_12750

**You** - 2025-05-24T16:17:40

I just told you how to mitigate what i can see as the only risk there is


---

### 1105. msg_12751

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:17:51

I’m doing it now


---

### 1106. msg_12752

**You** - 2025-05-24T16:20:30

worked


---

### 1107. msg_12753

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:21:13

Done\. Yup


---

### 1108. msg_12754

**You** - 2025-05-24T16:21:15

I can see mutual connectioons only


---

### 1109. msg_12755

**You** - 2025-05-24T16:28:22

kk well you probably have stuff going on\.\. so I am going to go focus on some work\.


---

### 1110. msg_12756

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T16:33:08

I am literally doing nothing\. Sad day\. Lol


---

### 1111. msg_12757

**You** - 2025-05-24T17:09:39

I mean sounds like you are enjoying relaxing so there is that\.


---

### 1112. msg_12758

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:25:23

What are you up to?


---

### 1113. msg_12759

**You** - 2025-05-24T17:25:54

Just some drama\.\. same shit different day\.


---

### 1114. msg_12760

**You** - 2025-05-24T17:26:03

hiding in basement beefing up security


---

### 1115. msg_12761

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:26:19

:\(


---

### 1116. msg_12762

**You** - 2025-05-24T17:26:26

Gracie still fighting about not leaving\.\. whatever\.\. over it


---

### 1117. msg_12763

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:26:59

I’m a little paranoid I may have said something that Andrew heard or something when I was a mess\. Mackenzie thinks she doesn’t think so\. We will see\.


---

### 1118. msg_12764

**You** - 2025-05-24T17:27:20

Did you go back and read the transcript yet\.\.\.\.\.\.\.\.\.


---

### 1119. msg_12765

**You** - 2025-05-24T17:27:46

starting from your mom whipping me into shape


---

### 1120. msg_12766

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:28:01

Omg no I will hate myself if I go back and read


---

### 1121. msg_12767

**You** - 2025-05-24T17:28:12

I would appreciate it if you would\.


---

### 1122. msg_12768

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:28:25

Whyyyyyyy


---

### 1123. msg_12769

**You** - 2025-05-24T17:28:51

because it was rough\.\. and I am cool if you want to do that\.\. and I love every version of Meredith, even that one\.\. but I cannot do that again\.


---

### 1124. msg_12770

**You** - 2025-05-24T17:29:00

I was really worried


---

### 1125. msg_12771

**You** - 2025-05-24T17:29:31

You won't understand if you don't read it\.


---

### 1126. msg_12772

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:29:32

Reaction: ❤️ from Scott Hicks
I’m sorry 😢


---

### 1127. msg_12773

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:34:55

Sorry talking to Andrew\. He is acting normal so I guess I didn’t do anything too weird last night


---

### 1128. msg_12774

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:35:03

He just got home


---

### 1129. msg_12775

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:35:40

I cannot read last night\. I know it was a mess\.


---

### 1130. msg_12776

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:35:47

Just by how I feel today


---

### 1131. msg_12777

**You** - 2025-05-24T17:37:38

>
k


---

### 1132. msg_12778

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:41:46

I was stupid, live … learn\. Is there something specific you want me to read/ know?


---

### 1133. msg_12779

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:42:04

Because I know I was generally the hugest mess ever\.


---

### 1134. msg_12780

**You** - 2025-05-24T17:42:45

Mer it's fine I don't want to go back through it again\.\. I shared with you some notes this morning\.\. if you want to just to leave it\.\. that is fine\.


---

### 1135. msg_12781

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:48:59

>
I’m kind of scared to hear what you are feeling I think\.


---

### 1136. msg_12782

**You** - 2025-05-24T17:49:54

Nothing for you to be scared of\.


---

### 1137. msg_12783

**You** - 2025-05-24T17:50:17

But you won't have context\.


---

### 1138. msg_12784

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:50:31

Wdym


---

### 1139. msg_12785

**You** - 2025-05-24T17:51:41

You have to go through the whole thing from last night to this morning\.\. then you can ask me questions\. Otherwise you will have no context\.


---

### 1140. msg_12786

**You** - 2025-05-24T17:52:02

And then there was the conversation lol\.\. that at least wasn't recorded\.\. rofl\.


---

### 1141. msg_12787

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:52:15

Phewwwww


---

### 1142. msg_12788

**You** - 2025-05-24T17:52:23

But you did mock me when I said I love you\.


---

### 1143. msg_12789

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:52:32

:\(


---

### 1144. msg_12790

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:52:53

I honestly have zero recollection\.


---

### 1145. msg_12791

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:53:04

Why did I mock u??


---

### 1146. msg_12792

**You** - 2025-05-24T17:53:05

You said something along the lines of "Anyone can say that and it can mean anything\.\. it's easy\."


---

### 1147. msg_12793

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:53:14

Oh


---

### 1148. msg_12794

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:53:21

Out of my mind obviously


---

### 1149. msg_12795

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:53:23

lol


---

### 1150. msg_12796

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:53:45

Why didn’t you block me?


---

### 1151. msg_12797

**You** - 2025-05-24T17:53:52

?


---

### 1152. msg_12798

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:53:54

Seriously…


---

### 1153. msg_12799

**You** - 2025-05-24T17:54:02

block you


---

### 1154. msg_12800

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:54:12

Because I was so annoying …


---

### 1155. msg_12801

**You** - 2025-05-24T17:54:20

that isn't how this works\.


---

### 1156. msg_12802

**You** - 2025-05-24T17:54:30

and by this I  mean us


---

### 1157. msg_12803

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:54:40

You could have unblocked me this morning lol


---

### 1158. msg_12804

**You** - 2025-05-24T17:54:47

I would never do that to you\.


---

### 1159. msg_12805

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:55:40

Very kind but you can if I’m super annoying


---

### 1160. msg_12806

**You** - 2025-05-24T17:56:06

It will never happen\. So not worth getting into tbh\.\. I would never do that for any reason\.


---

### 1161. msg_12807

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T17:57:29

Just running to pick up Maelle at work


---

### 1162. msg_12808

**You** - 2025-05-24T17:57:50

yup


---

### 1163. msg_12809

**You** - 2025-05-24T19:09:55

Hey not sure if you are still out or not\.\. I am going to head to the gym and plan on being there till probably 10\.\. so not sure if you will be up to chatting or not\.\. let me know\.


---

### 1164. msg_12810

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:15:22

I am around just watching tv\. I felt like I should leave you alone tonight cuz of last night\. 😔


---

### 1165. msg_12811

**You** - 2025-05-24T19:18:31

I mean I don’t think that will make me feel better\.\. I feel like it might be you would rather avoid talking to me tonight lol\.\. that might be more accurate\.\. I told you already if you don’t want to go back and take a look we don’t have to discuss my feelings and we can drop it\.


---

### 1166. msg_12812

**You** - 2025-05-24T19:19:02

Either way whatever you want meet


---

### 1167. msg_12813

**You** - 2025-05-24T19:19:09

Mer


---

### 1168. msg_12814

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:19:11

Not true\. Not trying to avoid you\.


---

### 1169. msg_12815

**You** - 2025-05-24T19:19:14

Sorry driving


---

### 1170. msg_12816

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:20:15

If there is something we should discuss, then we should\. Not trying to avoid… just feeling loser\-ish\. Lol


---

### 1171. msg_12817

**You** - 2025-05-24T19:23:13

Let’s just leave it I shared enough earlier and last night\.  Will just deal with rest\.


---

### 1172. msg_12818

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:24:23

I read what you shared this morning\. But you said you wanted to discuss, ask questions\.


---

### 1173. msg_12819

**You** - 2025-05-24T19:25:00

It was about what you said last night it doesn’t matter mer\.\. it’s all over now it’s fine\.


---

### 1174. msg_12820

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:26:26

But I don’t even remember so you need to refresh my memory\. I can’t exactly bring up much\. 🙁


---

### 1175. msg_12821

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:26:40

Did I say bad stuff?


---

### 1176. msg_12822

**You** - 2025-05-24T19:30:28

Mer I don’t even want to go back through it now\.  Let’s just say I was really really worried\.  You were so messed I thought anything could happen and saying something to Andrew was only one of the many many things that went through my head\.\. you cannot understand if you don’t read it and you don’t want to read it and I don’t want to go back through it\.  So I think this will just be on me to resolve my own issues here\.


---

### 1177. msg_12823

**You** - 2025-05-24T19:31:36

But one thing I did say and I am paraphrasing was if I got that messed up and J was around it would have drove you crazy\.


---

### 1178. msg_12824

**You** - 2025-05-24T19:32:02

Anyhow I am gonna head in to get changed and run my ass off\.


---

### 1179. msg_12825

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:32:44

Sigh, I’m really sorry\. Honestly\. I was not even near Andrew for 99% of the night\.


---

### 1180. msg_12826

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:33:07

But I completely understand, I do\.


---

### 1181. msg_12827

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:33:24

And you are correct\.


---

### 1182. msg_12828

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:33:47

I was planning to be like that though\. Just want to re\-iterate\.


---

### 1183. msg_12829

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:33:54

\*wasnt


---

### 1184. msg_12830

**You** - 2025-05-24T19:36:36

Like I said mer it is over\.\. it’s is fine\.\. like nothing you can do\. Don’t worry about it\.


---

### 1185. msg_12831

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:40:56

Do you worry I would do something with Andrew when I’m messed up?


---

### 1186. msg_12832

**You** - 2025-05-24T19:41:06

Yep I do\.


---

### 1187. msg_12833

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:41:26

But I would not\.


---

### 1188. msg_12834

**You** - 2025-05-24T19:41:34

I mean I always worrrt a bit


---

### 1189. msg_12835

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:41:39

I don’t even like him\.


---

### 1190. msg_12836

**You** - 2025-05-24T19:41:41

But last night was another level


---

### 1191. msg_12837

**You** - 2025-05-24T19:41:54

You didn’t know what you were saying or doing last night


---

### 1192. msg_12838

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:42:05

True\.


---

### 1193. msg_12839

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:42:11

Can’t argue with that\.


---

### 1194. msg_12840

**You** - 2025-05-24T19:43:11

And you said some interesting things\.


---

### 1195. msg_12841

**You** - 2025-05-24T19:43:14

Maybe I had a paranoid thought you were going to ruin me\.


---

### 1196. msg_12842

**You** - 2025-05-24T19:43:27

I usually find drunk people are pretty honest


---

### 1197. msg_12843

**You** - 2025-05-24T19:43:39

So yeah I was worried


---

### 1198. msg_12844

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:44:02

Do I even want to know what I said that was “interesting”?


---

### 1199. msg_12845

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:44:04

Gah


---

### 1200. msg_12846

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:44:17

>
Why would I ruin you? Omg


---

### 1201. msg_12847

**You** - 2025-05-24T19:44:52

No I was going to ruin you mer


---

### 1202. msg_12848

**You** - 2025-05-24T19:44:58

You said that to me


---

### 1203. msg_12849

**You** - 2025-05-24T19:45:14

Again not going into the rest because I tried to but couldn’t understand a lot


---

### 1204. msg_12850

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:45:21

Oh that wasn’t obvious by the way you typed it\.


---

### 1205. msg_12851

**You** - 2025-05-24T19:45:32

Sorry was pasting what you said


---

### 1206. msg_12852

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:46:00

Ah


---

### 1207. msg_12853

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:46:18

Well I can’t say I feel that way so… not sure\.


---

### 1208. msg_12854

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:47:22

I doubt I was only drunk at that point\.


---

### 1209. msg_12855

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:47:27

But who knows\.


---

### 1210. msg_12856

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:47:54

The gummies were a bit much for me


---

### 1211. msg_12857

**You** - 2025-05-24T19:49:04

I doubt you could explain much of what happened last night anyways even if you did go back\.  Like I said it is over it is fine\.\.  but I cannot do that again\.\. I would rather not know\.


---

### 1212. msg_12858

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:49:58

Understood\. Is there something I said that is majorly bothering you?


---

### 1213. msg_12859

**You** - 2025-05-24T19:54:46

Other than the ruin me part which I hear a lot echoed around here it was the general concern for what could happen\.\. it’s fine like I said I don’t expect anything to change\. And you shouldn’t have to to deal\. I just think on those nights I will just tap out\.  I won’t like it will still know what is going on but maybe I will deal better\.  Uggh………\.\.


---

### 1214. msg_12860

**You** - 2025-05-24T19:55:48

This fucking sucks\.


---

### 1215. msg_12861

**You** - 2025-05-24T19:56:11

Shouldn’t bother me Mike this


---

### 1216. msg_12862

**You** - 2025-05-24T19:56:13

Like


---

### 1217. msg_12863

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T19:57:41

Reaction: ❤️ from Scott Hicks
I seriously don’t feel that way so I’m not sure why I was spouting off about that\. And I am genuinely sorry\.


---

### 1218. msg_12864

**You** - 2025-05-24T19:59:03

Doesn’t change anything between us mer\.\. just bad night for me and really hard to process\. Not sure what to do here but again that is my problem\.


---

### 1219. msg_12865

**You** - 2025-05-24T20:02:39

Does seem like problems are piling up lately lol\.


---

### 1220. msg_12866

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:02:45

😭


---

### 1221. msg_12867

**You** - 2025-05-24T20:02:46

So should be interesting


---

### 1222. msg_12868

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:03:38

What’s hard to process though? My irresponsibility? Poor decision making? Gah


---

### 1223. msg_12869

**You** - 2025-05-24T20:03:58

Upside though you only have to see me for 2 days out of the next 3 weeks


---

### 1224. msg_12870

**You** - 2025-05-24T20:04:06

Asking Ian for 2 weeks off on
Monday\.


---

### 1225. msg_12871

**You** - 2025-05-24T20:04:25

Probably take another 1 or 2 off in July\.


---

### 1226. msg_12872

**You** - 2025-05-24T20:04:30

So there is that too


---

### 1227. msg_12873

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:06:08

>
You realize this isn’t really an upside right


---

### 1228. msg_12874

**You** - 2025-05-24T20:06:11

>
No you are just doing what you feel you need to\.


---

### 1229. msg_12875

**You** - 2025-05-24T20:06:20

>
I think it is for you


---

### 1230. msg_12876

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:06:33

>
But what is hard to process?


---

### 1231. msg_12877

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:07:00

>
Nothing about this situation / reality feels “upside”


---

### 1232. msg_12878

**You** - 2025-05-24T20:07:04

I just thought if I did that you would lose your mind\.\.


---

### 1233. msg_12879

**You** - 2025-05-24T20:07:21

Anyways when I started trying to warn you you just kind of blew me off\.


---

### 1234. msg_12880

**You** - 2025-05-24T20:07:31

Again you were messed so w/e


---

### 1235. msg_12881

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:07:37

Oh


---

### 1236. msg_12882

**You** - 2025-05-24T20:07:53

Like I said there is no point in re hashing\.\. not going to solve anything


---

### 1237. msg_12883

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:07:59

But what if you did it by accident? Poor decision making?


---

### 1238. msg_12884

**You** - 2025-05-24T20:08:11

We have 2 months to get through I cannot let this mess me up


---

### 1239. msg_12885

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:08:12

Maybe I would be more understanding


---

### 1240. msg_12886

**You** - 2025-05-24T20:08:22

I don’t drink around Jaimie


---

### 1241. msg_12887

**You** - 2025-05-24T20:09:21

Mer I am not holding this against you if that is your concern I told you I just need to be absent for future events\.


---

### 1242. msg_12888

**You** - 2025-05-24T20:09:32

It is what it is\.


---

### 1243. msg_12889

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:09:59

Okay, understood\.


---

### 1244. msg_12890

**You** - 2025-05-24T20:11:39

Look you don’t need to engage on this anymore\.  Why don’t you just do relax and do what you were doing\.  I am going to just walk and think for a while then shower and go home to bed\.


---

### 1245. msg_12891

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:14:04

Ok, but before that, do you trust that I never actually did anything with Andrew?


---

### 1246. msg_12892

**You** - 2025-05-24T20:16:52

I trust you mer\.\. but you don’t even Remeber what happened last night for like the last 2\-3 hours\.\.  and god I love you to death\.\. so I would just rather be ignorant in the future\.\. answer me this you might not want to but go read the exchanges then ask yourself if the roles were reversed would you be 100% certain?  I am not trying to be mean 😢 I believe in you and us\.\. but man last night you had absolutely no clue about anything mer I have never seen you like that\.  There is no way you could make thought out decisions\.


---

### 1247. msg_12893

**You** - 2025-05-24T20:17:52

Like I am just trying to survive the next 60 days\.


---

### 1248. msg_12894

**You** - 2025-05-24T20:18:12

I will do what I have to\.\. even if that is stick my head in the sand and pretend\.


---

### 1249. msg_12895

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:18:42

I know I don’t remember a lot but I know we didn’t do anything\. Nor would I have wanted to anyway\.


---

### 1250. msg_12896

**You** - 2025-05-24T20:19:23

Kk I believe you\.\. it’s ok\.  I know you wouldn’t have wanted to regardless\.


---

### 1251. msg_12897

**You** - 2025-05-24T20:19:31

Ok\.\.


---

### 1252. msg_12898

**You** - 2025-05-24T20:20:39

Mer it’s fine ok I believe you this is all my problem\.\. it’s just in my head\.


---

### 1253. msg_12899

**You** - 2025-05-24T20:21:01

… I don’t know what else to say…\.\.


---

### 1254. msg_12900

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:21:44

You don’t have to say anything else\. I will smarten up… need to for my damn kids anyway\. :p


---

### 1255. msg_12901

**You** - 2025-05-24T20:22:17

It what I asked\.  I need you to come through this as the mer I love


---

### 1256. msg_12902

**You** - 2025-05-24T20:22:23

I need you to do what you need to do


---

### 1257. msg_12903

**You** - 2025-05-24T20:22:30

But maybe just not that hard


---

### 1258. msg_12904

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:22:33

I try to escape this reality and obviously went overboard\. Johnnys gummies fault imo


---

### 1259. msg_12905

**You** - 2025-05-24T20:22:50

Yeah it wasn’t good


---

### 1260. msg_12906

**You** - 2025-05-24T20:22:57

Reaction: ❓ from Meredith Lamb
You wanted to meet Andrew


---

### 1261. msg_12907

**You** - 2025-05-24T20:23:06

And apparent mac was on my side


---

### 1262. msg_12908

**You** - 2025-05-24T20:23:12

Not sure what that meant


---

### 1263. msg_12909

**You** - 2025-05-24T20:23:22

You wanted me to meet Andrew


---

### 1264. msg_12910

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:23:37

Oh weird\. No don’t want that


---

### 1265. msg_12911

**You** - 2025-05-24T20:23:50

Something about a monologue


---

### 1266. msg_12912

**You** - 2025-05-24T20:23:56

You sent me half a voice chat


---

### 1267. msg_12913

**You** - 2025-05-24T20:24:01

Then deleted it


---

### 1268. msg_12914

**You** - 2025-05-24T20:24:05

So yeah


---

### 1269. msg_12915

**You** - 2025-05-24T20:24:08

Hard to follow


---

### 1270. msg_12916

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:24:24

Sorry I can even help to interpret that unfortunately


---

### 1271. msg_12917

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:24:32

Ughhhh


---

### 1272. msg_12918

**You** - 2025-05-24T20:24:33

Figured


---

### 1273. msg_12919

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:24:48

I’m a mess\.


---

### 1274. msg_12920

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:24:53

Shit\.


---

### 1275. msg_12921

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:25:03

Will turn it around\.


---

### 1276. msg_12922

**You** - 2025-05-24T20:26:01

I dunno\.\. this plus not seeing you for weeks\.\. hard


---

### 1277. msg_12923

**You** - 2025-05-24T20:26:31

It’s the plan though so gotta hold to it\.


---

### 1278. msg_12924

**You** - 2025-05-24T20:27:39

And I will be scarce Monday and Tuesday already decided


---

### 1279. msg_12925

**You** - 2025-05-24T20:27:51

Told you that last night too\.\. cannot remember what you said


---

### 1280. msg_12926

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:28:37

Things feel so bleak\. This feeling worries me\.


---

### 1281. msg_12927

**You** - 2025-05-24T20:28:39

Honestly hurts too much yku see it on my face


---

### 1282. msg_12928

**You** - 2025-05-24T20:28:48

And then you feel bad


---

### 1283. msg_12929

**You** - 2025-05-24T20:28:54

Reaction: 👎 from Meredith Lamb
Better I just go somewhere else


---

### 1284. msg_12930

**You** - 2025-05-24T20:29:34

The feeling is called resignation\.  As in we have no choice\.


---

### 1285. msg_12931

**You** - 2025-05-24T20:32:54

>
They feel that way because they are nothing to do but get through it\.\. I think you will have an easy 3 weeks ahead so that is goood for you


---

### 1286. msg_12932

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:33:23

>
You can’t actually believe this?


---

### 1287. msg_12933

**You** - 2025-05-24T20:34:07

I think that was your biggest problem the other day\.\. so it will be solved as of Monday\.


---

### 1288. msg_12934

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:35:10

Scott, there is no real solution here that is feasible so you just disappearing from view for 3 wks is not going to fix things


---

### 1289. msg_12935

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:35:13

Just saying


---

### 1290. msg_12936

**You** - 2025-05-24T20:35:18

We did talk about it that night after golf\.


---

### 1291. msg_12937

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:35:25

That is a very black and white approach


---

### 1292. msg_12938

**You** - 2025-05-24T20:35:47

I can only address the concerns you have as best I can and try to protect myself in the orocesss


---

### 1293. msg_12939

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:36:32

We cannot ignore what you need in this though\.


---

### 1294. msg_12940

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:36:49

That will just shut you down and you will start resenting me


---

### 1295. msg_12941

**You** - 2025-05-24T20:36:49

Well I am going to


---

### 1296. msg_12942

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:36:53

No


---

### 1297. msg_12943

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:37:14

We need a balance


---

### 1298. msg_12944

**You** - 2025-05-24T20:37:19

Yes and I won’t resent you but I will shit down more and more just again to protect myself


---

### 1299. msg_12945

**You** - 2025-05-24T20:37:25

There cannot be any balance mer


---

### 1300. msg_12946

**You** - 2025-05-24T20:37:31

We don’t work that way\.


---

### 1301. msg_12947

**You** - 2025-05-24T20:37:36

At least not now


---

### 1302. msg_12948

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:37:40

We can try


---

### 1303. msg_12949

**You** - 2025-05-24T20:37:58

I don’t think so mer trying caused you grief\.\. I do t want to do that again\.


---

### 1304. msg_12950

**You** - 2025-05-24T20:38:05

I really don’t


---

### 1305. msg_12951

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:39:22

Here’s what happened\. We talked about it and didn’t fully resolve it \(which was fine\. It was challenging\) and we had to just chill and go to bed\. Then I woke up to “problem, j knows”\.


---

### 1306. msg_12952

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:39:30

It was like 🤯


---

### 1307. msg_12953

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:39:52

So it was kind of like a tsunami


---

### 1308. msg_12954

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:40:08

That’s literally what it felt like


---

### 1309. msg_12955

**You** - 2025-05-24T20:40:10

I don’t think there is a resolution\.\. my resolution is to work next week and fuck off the two after that


---

### 1310. msg_12956

**You** - 2025-05-24T20:40:13

Then Chatham


---

### 1311. msg_12957

**You** - 2025-05-24T20:40:31

Then whatever\.\. too far out to know


---

### 1312. msg_12958

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:41:21

I know you don’t want this to be your next 3 weeks\. What would you want for real?


---

### 1313. msg_12959

**You** - 2025-05-24T20:43:09

That is what I want


---

### 1314. msg_12960

**You** - 2025-05-24T20:44:23

Of course that isn’t what I fucking want\.\. but it doesn’t matter mer\.\. we cannot have what we want\.


---

### 1315. msg_12961

**You** - 2025-05-24T20:44:48

So this solution at least makes it easier for one of us


---

### 1316. msg_12962

**You** - 2025-05-24T20:46:20

I am going to go jump in the sauna and then shower should be done in 30 mins\. Didnt feel like doing anymore gym tonight\.


---

### 1317. msg_12963

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:47:29

k, I’m feeling really upset, I don’t like this 😢 I will watch tv… I miss you irl


---

### 1318. msg_12964

**You** - 2025-05-24T20:49:08

Reaction: 😢 from Meredith Lamb
I will message
You when I am done if you want\.  I miss you to\.\. sorry I made you upset I love you\.  I do if nothing else mer I swear to god\.\. I swear o\. The memory of my mother\.\. I will never ever stop loving you for as long you will have me\.\. but right now  my heart hurts like it has never hurt before and I cannot do anything about it\.


---

### 1319. msg_12965

**You** - 2025-05-24T20:49:39

Will msg after\.\. if
You are still up\. But if you are exhausted mentally etc just don’t bother responding I will know and it will be fine


---

### 1320. msg_12966

**You** - 2025-05-24T20:50:43

If you want to call me if you can if it would make you feel better I will drive around for a bit\.


---

### 1321. msg_12967

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T20:52:46

Calling might be tricky tonight\. Quiet house with ppl everywhere


---

### 1322. msg_12968

**You** - 2025-05-24T21:10:03

Kk no worries\.\. I am just gonna get changed and go to car\.


---

### 1323. msg_12969

**You** - 2025-05-24T21:16:35

I mean probably better if we just don’t anyways\.\. we don’t have much to talk about honestly and that is the big problem\.\. we don’t have a future to discuss… yet\.\. so it just leads to kind of sad chats anyways right\.\.


---

### 1324. msg_12970

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:17:30

These msgs make me sadder\.


---

### 1325. msg_12971

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:18:05

How did we get here…\. Hoping this is a small blip\.


---

### 1326. msg_12972

**You** - 2025-05-24T21:19:04

I wouldn’t call it small\. But yeah it is a blip\.  We got here because we are different and need different things\. Together I think we are perfect but in this situation\.\. not so perfect at supporting each other unfortunately


---

### 1327. msg_12973

**You** - 2025-05-24T21:19:59

If we had have realized this in September for the first time I think it would have been epic


---

### 1328. msg_12974

**You** - 2025-05-24T21:22:51

But yeah we got moments of epic  to kick it off\.\. a clear realization this is real and I feel we are pretty awesome together\.\. very easy actually unlike this\.  And then reality hit us things got scary and anxious for you\.\. while I am still full steam ahead even despite people finding out\.\. so it doesn’t fit well here\.\. in this phase\.  But it is where we are now\. Nothing to be done\.  I am sorry I should have went way slower\.  Then maybe our expectations, well my expectations would be lower\.


---

### 1329. msg_12975

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:25:17

I just don’t know what I’m supposed to do anymore\. I don’t like that feeling\. I don’t like letting you down constantly\. I feel like I’m dragging you down\.


---

### 1330. msg_12976

**You** - 2025-05-24T21:25:59

In the car now \- feel like I should go to a bar find a stranger and share all mu troubles with them\.  That’s what happens in the movies and then get some kind of ahah moment\.


---

### 1331. msg_12977

**You** - 2025-05-24T21:26:29

>
It’s not you\.\. it is just the situation\.\. you can’t do anything but be yourself\.


---

### 1332. msg_12978

**You** - 2025-05-24T21:27:57

>
I also feel the same way… I just want to see you all the time\.\. and that just puts way too much pressure on you\.\. so I think we are in the same boat like I said we need different things\.\. but I can give you what you want or at least most of it


---

### 1333. msg_12979

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:31:55

I don’t know what to say\. Just wish we were together tonight\. That’s all\.


---

### 1334. msg_12980

**You** - 2025-05-24T21:34:05

Yeah you know what I don’t want this to come across the wrong way but maybe we should even think about dialling back chats??? I mean you are chill and happy at night with your rc and stuff and this does nothing but bring you down\.


---

### 1335. msg_12981

**You** - 2025-05-24T21:35:12

I mean I am just looking for ways to avoid more pain etc


---

### 1336. msg_12982

**You** - 2025-05-24T21:35:58

Just a thought don’t onerthinj it it doesn’t have a deeper meaning


---

### 1337. msg_12983

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:37:03

😞


---

### 1338. msg_12984

**You** - 2025-05-24T21:38:43

I mean I don’t know what to do\.  It bothers me just as
Much to see you\.  Can’t go to you flirt with you give you a hug\.\. then we try to talk like everything is fine at night\.\. welll last night was a whole other thing\.\. but most nights we don’t have anything to build towards or look forward to\.\. you get it right


---

### 1339. msg_12985

**You** - 2025-05-24T21:39:52

So this is where I pull you down because if I don’t call you


---

### 1340. msg_12986

**You** - 2025-05-24T21:40:08

You will just chill and lose yourself in your shows and just keep on keep in on


---

### 1341. msg_12987

**You** - 2025-05-24T21:41:06

Deleted\. No
Words
Anyways


---

### 1342. msg_12988

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:45:08

This is making me feel very f\*cked up\. Maybe tomorrow will be better\.


---

### 1343. msg_12989

**You** - 2025-05-24T21:47:57

home sweet home


---

### 1344. msg_12990

**You** - 2025-05-24T21:48:12



---

### 1345. msg_12991

**You** - 2025-05-24T21:50:35

>
yeah let's call it a night\.\. now one is going to end up happy regardless\.\. feel free to just do whatever tomorrow with this\.\. don't feel like you need to reach out if you don't want to\.\. likely ends up something like this anyways\.\.\. I won't dogpile any messages like this morning\.\. I thought about the idea of using this as a running journal and just sharing random things with your throughout the day\.\. but I think that is a kind of stupid idea too\.


---

### 1346. msg_12992

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:53:10

What did you delete?


---

### 1347. msg_12993

**You** - 2025-05-24T21:53:18

just looking at schedules for Monday and Tuesday


---

### 1348. msg_12994

**You** - 2025-05-24T21:53:29

should be easy to fill and you and I don't have any meetings planned\.


---

### 1349. msg_12995

**You** - 2025-05-24T21:53:35

>
doesn't matter\.


---

### 1350. msg_12996

**You** - 2025-05-24T21:54:19

at one point last night the topic of what do we do came up\.\. you were pretty drunk\.


---

### 1351. msg_12997

**You** - 2025-05-24T21:54:31

or drunk and stoned


---

### 1352. msg_12998

**You** - 2025-05-24T21:54:43

push pause was kind of raised\.


---

### 1353. msg_12999

**You** - 2025-05-24T21:54:58

not by me\.\.\.


---

### 1354. msg_13000

**You** - 2025-05-24T21:55:16

that was that last thing I was going to ask you about earlier\.\.


---

### 1355. msg_13001

**You** - 2025-05-24T21:55:22

but you said you didn't remember anything


---

### 1356. msg_13002

**You** - 2025-05-24T21:55:42

that was what I deleted


---

### 1357. msg_13003

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:55:59

Ugh k


---

### 1358. msg_13004

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:56:23

I don’t want to pause, seriously\.


---

### 1359. msg_13005

**You** - 2025-05-24T21:56:22

again I see people who are drunk to have no inhibitions\.\. and are usually honest\.\.


---

### 1360. msg_13006

**You** - 2025-05-24T21:56:34

which is why I am worried about this about you about andrew about all ofit


---

### 1361. msg_13007

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:57:01

Not true\. Lots of ppl say things they don’t mean with substance abuse\.


---

### 1362. msg_13008

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:57:12

It isn’t always truth


---

### 1363. msg_13009

**You** - 2025-05-24T21:57:18

you havent struck me that way so far though


---

### 1364. msg_13010

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:57:39

Did I say we SHOULD pause?


---

### 1365. msg_13011

**You** - 2025-05-24T21:57:48

could and then maybe should


---

### 1366. msg_13012

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:58:31

Listen, the whole “my family knows and thinks you are a home wrecker” thing kind of hit me like a tsunami\.


---

### 1367. msg_13013

**You** - 2025-05-24T21:58:34

look i don't want to anyways


---

### 1368. msg_13014

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:58:45

I was feeling a lot of scary stuff


---

### 1369. msg_13015

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:59:10

So likely that impacted the way I was acting last night\.


---

### 1370. msg_13016

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:59:22

I am not very resilient\.


---

### 1371. msg_13017

**You** - 2025-05-24T21:59:27

perhaps\.\. I think issues existed pre tsunami


---

### 1372. msg_13018

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:59:31

I like to escape when things are hard\.


---

### 1373. msg_13019

**You** - 2025-05-24T21:59:47

well maybe you need this then


---

### 1374. msg_13020

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T21:59:56

>
Absolutely but that threw me over the edge I think\.


---

### 1375. msg_13021

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:01:03

>
No, I don’t think so but I obviously have some work to do mentally\.


---

### 1376. msg_13022

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:01:33

Reaction: ❤️ from Scott Hicks
Honestly I am so sure about us, I would move in with you tomorrow if I could\.


---

### 1377. msg_13023

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:01:39

Like I don’t have uncertainties


---

### 1378. msg_13024

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:02:02

I’m just a little lost I guess\. This is very hard to navigate


---

### 1379. msg_13025

**You** - 2025-05-24T22:04:11

well again while it wont technically be a pause I think you will get some time and space in the next few weeks\.


---

### 1380. msg_13026

**You** - 2025-05-24T22:04:31

so maybe that will help you


---

### 1381. msg_13027

**You** - 2025-05-24T22:04:42

don't worry about me\.\. nothing you can do anyways


---

### 1382. msg_13028

**You** - 2025-05-24T22:06:22

>
for the record I don't either\.\. and I would move in with you now too and be all the happier for it\.


---

### 1383. msg_13029

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:08:29

>
I will always worry about you\.


---

### 1384. msg_13030

**You** - 2025-05-24T22:08:51

>
but it isn't worth it\.\. nothing can be done


---

### 1385. msg_13031

**You** - 2025-05-24T22:08:55

so don't bother


---

### 1386. msg_13032

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:09:03

Reaction: ❤️ from Scott Hicks
>
I think we would both be happier\. Not sure about everyone else but we would be


---

### 1387. msg_13033

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:10:52

>
This isn’t true\. You are part of my world now… you are important to me\. So I want to help you just as much as you do for me\. But we don’t need to sort it tonight\.


---

### 1388. msg_13034

**You** - 2025-05-24T22:11:28

>
mer I mean it won't get sorted for weeks and weeks etc etc etc\.\. so at least no point worrying now\.


---

### 1389. msg_13035

**You** - 2025-05-24T22:13:22

>
I feel the same way about you\.\. but like I said\.\. I don't think you can help\.\. and I don't want to expect that help\.\.


---

### 1390. msg_13036

**You** - 2025-05-24T22:27:10

>
also\.\. the we do not need to sort it tonight\.\. that is becoming a theme btw\.\. if you read back lol\.\. just saying


---

### 1391. msg_13037

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:29:14

Well if we could sort it I would\.


---

### 1392. msg_13038

**You** - 2025-05-24T22:29:33

so why don't we "put a pin in it" "per se" and "as we don't need to sort it out tonight"


---

### 1393. msg_13039

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:29:41

If you were lying beside me it would be sorted\.


---

### 1394. msg_13040

**You** - 2025-05-24T22:29:56

Reaction: ❤️ from Scott Hicks
I wouldn't be lying beside you for one thing\.\. it is 10:30\.


---

### 1395. msg_13041

**You** - 2025-05-24T22:30:22

but yeah I am steering clear of those too


---

### 1396. msg_13042

**You** - 2025-05-24T22:30:23

lol


---

### 1397. msg_13043

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:30:39

?


---

### 1398. msg_13044

**You** - 2025-05-24T22:30:44

my entendres


---

### 1399. msg_13045

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:30:53

lol oh


---

### 1400. msg_13046

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:31:25

Sigh


---

### 1401. msg_13047

**You** - 2025-05-24T22:31:36

>
and it wouldn't  because we were lying beside each other all weekend\.\. lol


---

### 1402. msg_13048

**You** - 2025-05-24T22:31:55

time and patience I guess\.\. and pain and sadness\.\. etc etc\.\. until I dunno\.\. September?


---

### 1403. msg_13049

**You** - 2025-05-24T22:32:38

anyways go to bed Mer\.\. I am not going to make anyone feel better tonight\.\. probably not for a while\.\. so again\.\. we can revisit chatting etc\.\. because you deserve to be happy\.\. you are a happy soul\.\.


---

### 1404. msg_13050

**You** - 2025-05-24T22:32:51

and right now\.\. I am stifling you and smothering you with all my sad shit\.


---

### 1405. msg_13051

**You** - 2025-05-24T22:33:05

you don't need it or me right now\.\. you just need to focus on getting through your stuff\.


---

### 1406. msg_13052

**You** - 2025-05-24T22:33:54

just know if I dial back the texts\.\. it isn't because I am not thinking about you\.


---

### 1407. msg_13053

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:35:13

Omg you have to stop saying all of that crap…\.


---

### 1408. msg_13054

**You** - 2025-05-24T22:35:27

>
it's not crap mer\.


---

### 1409. msg_13055

**You** - 2025-05-24T22:36:47

😬


---

### 1410. msg_13056

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:37:57

They are difficult messages to read from the person I am in love with and just want to be with\.

*1 attachment(s)*


---

### 1411. msg_13057

**You** - 2025-05-24T22:45:35

they are messages from someone who loves you and wants to be with you but knows that he cannot\.\. and he knows that wanting you as bad as he does\.\. being disappointed when opportunities pass by, making you feel bad because because you see and feel his disappointment\.\. it's not fair to anyone


---

### 1412. msg_13058

**You** - 2025-05-24T22:48:39

I mean the more I want, the more I love you, the more intensely I love you, which is still going btw\.\. makes no sense but it keeps growing\.\. it just causes you more pain, when I feel pain\.\. so why wouldn't it be better to block that off?


---

### 1413. msg_13059

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:49:56

You are allowed to be disappointed and express that\. It is fair\. So don’t say that


---

### 1414. msg_13060

**You** - 2025-05-24T22:50:18

but then you take it on yourself


---

### 1415. msg_13061

**You** - 2025-05-24T22:50:27

like it is your fault I am too needy


---

### 1416. msg_13062

**You** - 2025-05-24T22:51:41

I told you earlier\.\. we are great for each other down the road\.\. we are not great at supporting each other right now\.\. I don't know how to be different


---

### 1417. msg_13063

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:52:17

Listen, you are not needy\. You are just dealing with someone \(me\) who isn’t in a “normal” life situation right now\.


---

### 1418. msg_13064

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T22:53:04

And I love you more and more as time passes also… sucks 🙃


---

### 1419. msg_13065

**You** - 2025-05-24T22:58:27

>
listen I appreciate this\.\. and the effort\.\. but I don't want you to waste your energy on this seriously\.\. I know you love me\.\. but you cannot fix this\.  You not fixing it doesn't mean you aren't the love of my life or the only person I want to spend it with\.\. it just means right now and for the foreseeable future\.\. we are not going to have a lot of fun\.


---

### 1420. msg_13066

**You** - 2025-05-24T23:00:54

So when you need to escape\.\. like last night \- I can do a little bit of that\.\. especially if Andrew isn't around\.\. but that much with him around\.\. yeah I cannot\.\. and neither could you\.\. so we know to avoid that\.   I don't know what to say beyond that\.  Hope for the best I guess\.\. right\.


---

### 1421. msg_13067

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T23:03:49

I honestly wasn’t really thinking\. I won’t do that again\. Seriously\.


---

### 1422. msg_13068

**You** - 2025-05-24T23:05:26

I didn't say that to shame you\.\. I just\.\.


---

### 1423. msg_13069

**You** - 2025-05-24T23:05:34

again\.\. you can do it


---

### 1424. msg_13070

**You** - 2025-05-24T23:05:37

or do whatever


---

### 1425. msg_13071

**You** - 2025-05-24T23:05:40

it is your life\.


---

### 1426. msg_13072

**You** - 2025-05-24T23:06:20

I just cannot be watching and listening and thinking and worrying\.  right\.\. that is all\.


---

### 1427. msg_13073

**You** - 2025-05-24T23:06:29

if I was there I would be in it with you and laughing away


---

### 1428. msg_13074

**You** - 2025-05-24T23:07:41

it is just different when we are apart and expect to be constantly apart for weeks\.\. gives me too much time to think\.\. without getting grounded with you again\.  I don't know how else to explain it\.\. but you should go to bed mer\.\. it is late\.\. and you were up late last night\.


---

### 1429. msg_13075

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T23:09:22

I get it completely…\. All of it\. You should go to bed too


---

### 1430. msg_13076

**You** - 2025-05-24T23:10:10

\.\. ok\.\. I love you\.\. get some sleep\.\. ❤️


---

### 1431. msg_13077

**You** - 2025-05-24T23:12:42

who knows\.\. like you said\.\. maybe tomorrow will be a better day\.\. rofl\.


---

### 1432. msg_13078

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T23:13:26

Maybe ❤️


---

### 1433. msg_13079

**You** - 2025-05-24T23:14:18

Reaction: ❤️ from Meredith Lamb
>
I am a realist\.\.\. forecast says cloudy with a chance of a thunderstorm, with tornadoes, rotating around an exploding volcano\.


---

### 1434. msg_13080

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T23:15:20

LOL


---

### 1435. msg_13081

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T23:15:25

Reaction: ❤️ from Scott Hicks
Accurate


---

### 1436. msg_13082

**You** - 2025-05-24T23:16:09

yep my life\.\. ain't it fucking grand\.  Goodnight xo\.\. srlsy go to sleep and stop worrying or being upset or anything\.\. just focus on you\.\. that is enough\.


---

### 1437. msg_13083

**Meredith Lamb \(\+14169386001\)** - 2025-05-24T23:22:29

Reaction: ❤️ from Scott Hicks
I cannot stop but goodnight \- love you


---

### 1438. msg_13084

**You** - 2025-05-24T23:24:11

>
You need to though there is no point for both of us suffering\.


---

