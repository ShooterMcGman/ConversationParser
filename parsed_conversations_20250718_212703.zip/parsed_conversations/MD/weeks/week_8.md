# Week 8: Conversation Messages

**Date Range:** 2025-06-01 to 2025-06-07  
**Total Messages:** 3125  
**Generated:** 2025-07-18 21:27:06

---

## 📊 Week Summary

- **Week Number:** 8
- **Messages:** 3125
- **Participants:** 2
- **Message Types:** incoming, outgoing, call-history

## 💬 Conversation Messages

### 1. msg_16148

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T00:14:37

Reaction: 🥇 from Meredith Lamb
Reaction: ❤️ from Scott Hicks

*1 attachment(s)*


---

### 2. msg_16149

**You** - 2025-06-01T06:52:17

Look at you\!\!


---

### 3. msg_16150

**You** - 2025-06-01T06:52:35

Reaction: ❤️ from Meredith Lamb
I slept through my alarm heading to gym now


---

### 4. msg_16151

**You** - 2025-06-01T06:54:36

Had a fucked up dream last night about war… wonder what that means\.  I used to have really vivid dreams\.  But not often anymore\.   This however was one of ‘em\.


---

### 5. msg_16152

**You** - 2025-06-01T06:55:13

Alright up I get really hope Mac feels better this morning\.\. she’s a beast I am proud of her\!


---

### 6. msg_16153

**You** - 2025-06-01T06:55:38

Love you\.\. ❤️❤️❤️ ur a beast too\!


---

### 7. msg_16154

**You** - 2025-06-01T07:50:15

https://open\.spotify\.com/track/73zawW1ttszLRgT9By826D?si=gtv40nloTwatV6RCo6PIrQ&context=spotify%3Aplaylist%3A37i9dQZF1DZ06evO2zJOi2
Liking this song this morning\. No hidden meanings here
lol
Just really like the song\.


---

### 8. msg_16155

**You** - 2025-06-01T08:37:40

Loving this new workout setup\.\. supersets are way to go for me for sure\.


---

### 9. msg_16156

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:38:21

Ii only got up because griffin was whining to go out again …don’t they know his stomach is well


---

### 10. msg_16157

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:38:44

Mac can’t find her phone but is otherwise fine, just hungover lol


---

### 11. msg_16158

**You** - 2025-06-01T08:40:31

>
Good to hear


---

### 12. msg_16159

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:40:40

>
War dream? Interesting… like you were off at war?


---

### 13. msg_16160

**You** - 2025-06-01T08:40:46

Yep


---

### 14. msg_16161

**You** - 2025-06-01T08:40:51

But it was local


---

### 15. msg_16162

**You** - 2025-06-01T08:41:06

Meaning in Canada Toronto or something Mike that


---

### 16. msg_16163

**You** - 2025-06-01T08:41:09

Like


---

### 17. msg_16164

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:41:17

Whitby war in rural Whitby


---

### 18. msg_16165

**You** - 2025-06-01T08:41:35

And all of these people from high school
We’re with me


---

### 19. msg_16166

**You** - 2025-06-01T08:41:45

Kinda messed


---

### 20. msg_16167

**You** - 2025-06-01T08:41:56

Reaction: 😂 from Meredith Lamb
I will just ignore the mocking\.


---

### 21. msg_16168

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:45:05

I wonder what that means\. War going on in your head maybe … conflicting thoughts


---

### 22. msg_16169

**You** - 2025-06-01T08:47:42

Fighting for your attention?


---

### 23. msg_16170

**You** - 2025-06-01T08:48:01

Not worth playing this kinda game with me\.\.


---

### 24. msg_16171

**You** - 2025-06-01T08:48:05

lol


---

### 25. msg_16172

**You** - 2025-06-01T08:48:13

I got a million of em\.


---

### 26. msg_16173

**You** - 2025-06-01T08:48:18

❤️


---

### 27. msg_16174

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:49:26

lol


---

### 28. msg_16175

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:49:35

I’m half asleep


---

### 29. msg_16176

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:49:38

Just saying


---

### 30. msg_16177

**You** - 2025-06-01T08:51:07

Yeah maybe go back to sleep lol


---

### 31. msg_16178

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T08:51:25

Going to try for a bit ❤️


---

### 32. msg_16179

**You** - 2025-06-01T08:52:35

Love you I could be fighting for our future,
Fighting for time, fighting for you love, fighting to defend you for on whatever, foghting to protect t myself from pain\. It was an invasion after all\.\. so many interpretations will ask chstgpr about all of these and orovide situational context


---

### 33. msg_16180

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T09:02:24

Andrew is here dogs barking ugh\. Seeing as how he is here wonder if we should go for a drive somewhere? 😜 kidding\. Going to try to sleep for a bit for real


---

### 34. msg_16181

**You** - 2025-06-01T09:03:13

Reaction: ❤️ from Meredith Lamb
Hey listen you go for a drive\.\. I am going to go help Sharon with her “form”


---

### 35. msg_16182

**You** - 2025-06-01T09:03:24

See\.\. lol ❤️


---

### 36. msg_16183

**You** - 2025-06-01T09:08:54

Would much rather help you youe form though 😜


---

### 37. msg_16184

**You** - 2025-06-01T10:02:11

Reaction: ❤️ from Meredith Lamb
Todays update

*1 attachment(s)*


---

### 38. msg_16185

**You** - 2025-06-01T10:02:35

Sauna and shower love you\.\. hope you enjoyed your drive\.\. ❤️


---

### 39. msg_16186

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T10:59:34

Just waking up for real


---

### 40. msg_16187

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T10:59:39

Omg so exhausted


---

### 41. msg_16188

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T10:59:49

Yesterday seemed so long and so late


---

### 42. msg_16189

**You** - 2025-06-01T10:59:56

Yep I bet it was


---

### 43. msg_16190

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:00:10

I tried to stay up and play ticket to ride and then watched tv


---

### 44. msg_16191

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:00:21

Finally I was like fuck it bed\.


---

### 45. msg_16192

**You** - 2025-06-01T11:00:24

lol


---

### 46. msg_16193

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:00:27

Think it was 1\.30am


---

### 47. msg_16194

**You** - 2025-06-01T11:02:14

Well I just finished everything was on way out mgr flagged me might meet with a trainer for 5 mins\. Just waiting


---

### 48. msg_16195

**You** - 2025-06-01T11:02:33

I added Jim to signal and created a group


---

### 49. msg_16196

**You** - 2025-06-01T11:02:41

You should see it


---

### 50. msg_16197

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:06:51

I literally cannot get out of bed lol


---

### 51. msg_16198

**You** - 2025-06-01T11:07:04

Hung over again…


---

### 52. msg_16199

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:07:18

No just so tired


---

### 53. msg_16200

**You** - 2025-06-01T11:07:25

Did you have a little bite of goodness? Or did you resist?


---

### 54. msg_16201

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:07:44

No way that shit is poison to me


---

### 55. msg_16202

**You** - 2025-06-01T11:07:50

lol


---

### 56. msg_16203

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:08:03

I was sick for like 2 days after\!


---

### 57. msg_16204

**You** - 2025-06-01T11:08:23

Well your dose was probably like 5X the recommended


---

### 58. msg_16205

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:08:41

It was just different too tho


---

### 59. msg_16206

**You** - 2025-06-01T11:08:43

If you ate 10 packs of gummies you would be equally fucked


---

### 60. msg_16207

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:08:48

lol


---

### 61. msg_16208

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:08:51

Maybe


---

### 62. msg_16209

**You** - 2025-06-01T11:08:56

No def\.


---

### 63. msg_16210

**You** - 2025-06-01T11:09:33

I am showing the trainer the Henry caville picture and say I want that\.\. and see what he says lol


---

### 64. msg_16211

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:09:55

Haha


---

### 65. msg_16212

**You** - 2025-06-01T11:10:19

Either that or the other dude I showed you\.\. reacher


---

### 66. msg_16213

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:18:55

lol

*1 attachment(s)*


---

### 67. msg_16214

**You** - 2025-06-01T11:36:24

Erin probably got a kick out of that\.


---

### 68. msg_16215

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:37:07

Whenever I show her anything of mackenzies she is like “those girls scare me\. They were mean to me in high school”


---

### 69. msg_16216

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:37:09

lol


---

### 70. msg_16217

**You** - 2025-06-01T11:38:21

And you were those girls… aww mer the mean girl\.\.


---

### 71. msg_16218

**You** - 2025-06-01T11:38:37

Trainer thinks I am slightly insane


---

### 72. msg_16219

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T11:38:53

He’s not wrong


---

### 73. msg_16220

**You** - 2025-06-01T11:39:04

lol


---

### 74. msg_16221

**You** - 2025-06-01T12:01:21

You busy?


---

### 75. msg_16222

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:02:45

Just cleaning by myself


---

### 76. msg_16223

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:02:49

Told girls to chill


---

### 77. msg_16224

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:03:00

They are watching Harry Potter and comparing photos


---

### 78. msg_16225

**You** - 2025-06-01T12:07:08

Kk just driving home you do your cleaning maybe we can chat later


---

### 79. msg_16226

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:07:43

We can chat\. I can take a break


---

### 80. msg_16227

**You** - 2025-06-01T12:07:58

Up to you


---

### 81. msg_16228

**You** - 2025-06-01T12:08:43

Call when yoj settled


---

### 82. msg_16229

**You** - 2025-06-01T12:41:51

Like how I dropped that in there at the end lol\.


---

### 83. msg_16230

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:42:28

The absolute thing?


---

### 84. msg_16231

**You** - 2025-06-01T12:43:22

No the even if you are still confused and unsure about what you want\.


---

### 85. msg_16232

**You** - 2025-06-01T12:43:38

Bah you missed it\.\. no fun\.


---

### 86. msg_16233

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:46:05

I caught it but don’t agree\. I am NOT confused\!


---

### 87. msg_16234

**You** - 2025-06-01T12:46:19

Kk


---

### 88. msg_16235

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:46:52

Honestly, wanting to be with you is the least confusing thing right now\.


---

### 89. msg_16236

**You** - 2025-06-01T12:47:54

I love you\.\. will chat with you later\.\. ❤️❤️❤️❤️\.  Yeah I guess so\.\. maybe confused is wrong word\.\. hesitant / afraid\.  That was what I felt the other night\.\. cautious\.  I dunno you give off a vibe sometime\. Especially when you get quiet\.


---

### 90. msg_16237

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:51:58

k, yeah those things maybe\. Confused, not at all\.


---

### 91. msg_16238

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T12:52:05

Love you too xo


---

### 92. msg_16239

**You** - 2025-06-01T13:21:24

No chance for them going to have to set ai to hard\.

*1 attachment(s)*


---

### 93. msg_16240

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T13:38:44

lol


---

### 94. msg_16241

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T13:38:55

Yeah I didn’t even finish my cards but still won


---

### 95. msg_16242

**You** - 2025-06-01T13:41:48

I spanked them this game was easy


---

### 96. msg_16243

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T13:41:48

>
Was thinking while cleaning\. Not “hesitant” but you are kind of scary so “afraid” could be accurate but that seems severe\. More anxious


---

### 97. msg_16244

**You** - 2025-06-01T13:42:10

Scary how?  ☹️


---

### 98. msg_16245

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T13:51:52

I guess just your history of shutting off so completely and not for a short time, for many years\. It’s a bit scary\. But it’s okay, I understand it and it is part of who you are so I’m processing it and trying NOT to be afraid\. You are worth it\. :\)


---

### 99. msg_16246

**You** - 2025-06-01T13:53:57

Mer\.\. sigh\.\. before I shut down\.\. to protect my feelings\.\. but I never stopped trying with j not until January of this year\.\. and even after that I still tried to support make smarter decisions take care of herself etc\.


---

### 100. msg_16247

**You** - 2025-06-01T13:54:42

I think you think me shutting down means I give up\.\. it doesn’t\.  Problem with j and I was the spark was never there to begin with\.\.


---

### 101. msg_16248

**You** - 2025-06-01T13:57:40

And I still committed was there for her supported her\. Yeah obligation and loyalty was big and loyalty is core to me\. But I don’t think you will ever need to worry about that honestly\.   You engage\.  I think if we ever ran into a tough time\.\. 1 we would communicate, I have already shown the level of communication you can expect from me\.\. 2 we support each other\.\. shutting down isn’t my first second third etc etc option\.  3 I don’t think you would let me, you have demonstrated that already and you have seen how I have reacted\.


---

### 102. msg_16249

**You** - 2025-06-01T13:58:09

This is new and really hard for me to care this much for you and manage my emotions when they weren’t around for sooo long\.


---

### 103. msg_16250

**You** - 2025-06-01T13:58:19

It wasn’t that I shut them off they didn’t exist\.


---

### 104. msg_16251

**You** - 2025-06-01T13:58:45

I figured you were
More afraid of how intensely I felt about you or something more along those lines


---

### 105. msg_16252

**You** - 2025-06-01T13:58:48

I could get that


---

### 106. msg_16253

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T13:59:37

I think I understand, really, logically I do but because I wasn’t there to experience it, there are some tricky gaps sometimes that come up in my head\. \(Not now\.\)
Why would I be afraid of how you feel when I feel the same way but just am not as verbally expressive?


---

### 107. msg_16254

**You** - 2025-06-01T13:59:38

But even if i shut down now because of how challenging this is\.\. it isn’t that I want to shut you out\.  I want to preserve myself for when we can be together


---

### 108. msg_16255

**You** - 2025-06-01T14:00:31

>
>
I don’t know I put it out there hard\.\. I could see how it could be off putting\.


---

### 109. msg_16256

**You** - 2025-06-01T14:02:38

Reaction: ❤️ from Meredith Lamb
If you hurt me I won’t shut down I will tell you\.  I told you right away on Friday when I was having a hard time\.\. I didn’t shut you out\.\. we can deal with shit mer I am not worried about that\.\. I am not worried for when we have our first “fight” “disagreement” or whatever you want to call it\.\.  I was for a long time\.\. because we hadn’t really defined what this is\.\. I am not worried about that anymore\.


---

### 110. msg_16257

**You** - 2025-06-01T14:03:27

And the closer we get to a normal relationship a lot of this stuff will just completely go away\.  As I get used to you, the evolving situation, and my crazy feelings\.


---

### 111. msg_16258

**You** - 2025-06-01T14:03:44

So hopefully that eases your anxiety a bit\.


---

### 112. msg_16259

**You** - 2025-06-01T14:05:55

I know you only have one real reference point for me\.\. but it would be like me completely comparing your behaviour with Andrew with how you might behave with me in the future\.


---

### 113. msg_16260

**You** - 2025-06-01T14:06:04

Completely nonsensical?


---

### 114. msg_16261

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:06:15

>
I mean off putting if the other person is feeling differently perhaps\.


---

### 115. msg_16262

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:06:54

>
It does\.


---

### 116. msg_16263

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:07:15

>
This is a really good point I hadn’t thought of actually\.


---

### 117. msg_16264

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:07:44

They are sending me to town for pizza and then I guess we are leaving at 4


---

### 118. msg_16265

**You** - 2025-06-01T14:09:01

Pizza is great next day food…


---

### 119. msg_16266

**You** - 2025-06-01T14:10:24

Edited: 2 versions
| Version: 2
| Sent: Sun, 1 Jun 2025 14:10:54 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Sun, 1 Jun 2025 14:06:54 \-0400
| >
| > It does\.
|
| I am glad\. there are likely going to be little fears for awhile\.\. but not forever\.\. you need a new baseline and that will be us\.  Eventually lol\.\. after months and years of patiently waiting rofl\.
|
| Version: 1
| Sent: Sun, 1 Jun 2025 14:10:24 \-0400
|
| > From: Meredith Lamb \(\+14169386001\)
| > Sent: Sun, 1 Jun 2025 14:06:54 \-0400
| >
| > It does\.
|
| I am glad there are likely going to be little fears for awhile\.\. but not forever\.\. you need a new baseline and that will be us\.  Eventually lol\.\. after months and years of patiently waiting rofl\.


---

### 120. msg_16267

**You** - 2025-06-01T14:10:43



---

### 121. msg_16268

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:10:29

Kitchen and dining area are clean now so I feel ok\. Rest can be cleaned next time\. :p


---

### 122. msg_16269

**You** - 2025-06-01T14:11:05

Oh shit you can edit didnt know that


---

### 123. msg_16270

**You** - 2025-06-01T14:12:10

>
I am sure you will have a chance to get a thorough cleaning in before your girls weekend\.


---

### 124. msg_16271

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:18:00

>
Yeah, the baseline is definitely completely messed up right now\.


---

### 125. msg_16272

**You** - 2025-06-01T14:21:30

It won’t be though\.  Every chance we get to spend time I feel “better” no other word for it\. Once the settlement agreements are in place
That will be huge\. Once you move out and Jaimie goes to Moncton will be another massive milestone\.\. in the meantime we take, find or make small opportunities\.


---

### 126. msg_16273

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:21:39

Foodland \- you can get got pizzas so I don’t have to deal with oven


---

### 127. msg_16274

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:21:43

\*hot


---

### 128. msg_16275

**You** - 2025-06-01T14:21:58

Well that makes it easier for sure


---

### 129. msg_16276

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:22:36

>
Yeah I feel consistently “better” also\. Especially with the upcoming work situation becoming official in a week\.


---

### 130. msg_16277

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:22:53

Helps me feel like you won’t lose your job 😵‍💫


---

### 131. msg_16278

**You** - 2025-06-01T14:23:10

I wouldn’t and won’t\.\.


---

### 132. msg_16279

**You** - 2025-06-01T14:23:20

But I am glad it will be a relief for you


---

### 133. msg_16280

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:24:43

>
If Jaimie said anything they would have to do an investigation\. That would be annoying, potentially lengthy, intrusive, etc


---

### 134. msg_16281

**You** - 2025-06-01T14:25:21

She won’t because it would embarrass her and it would put the kids future inheritance at risk\.


---

### 135. msg_16282

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:25:43

Scorned women sometimes act out


---

### 136. msg_16283

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:25:52

But in a week it won’t matter


---

### 137. msg_16284

**You** - 2025-06-01T14:26:05

So from a logical perspective she definitely won’t\.\. even if she didn’t care about that she still wouldn’t, I trust her in that and how she reacted when I suggested she might do it\.


---

### 138. msg_16285

**You** - 2025-06-01T14:26:25

Sry hurt and offended I would suggest it


---

### 139. msg_16286

**You** - 2025-06-01T14:26:29

Very


---

### 140. msg_16287

**You** - 2025-06-01T14:26:52

Again I know you emailed or called that girl


---

### 141. msg_16288

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:27:02

And her husband


---

### 142. msg_16289

**You** - 2025-06-01T14:27:11

She would never do that\.\. more likely to say something mean to you under her breath…


---

### 143. msg_16290

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:27:17

I may have talked to them on phone\. Can’t remember


---

### 144. msg_16291

**You** - 2025-06-01T14:27:19

If she saw you


---

### 145. msg_16292

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:27:21

I was extremely pissed


---

### 146. msg_16293

**You** - 2025-06-01T14:27:30

For good reason


---

### 147. msg_16294

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:27:53

I didn’t care if he lost his job\. I wasn’t thinking at all


---

### 148. msg_16295

**You** - 2025-06-01T14:28:02

Yeah she is not there


---

### 149. msg_16296

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:28:09

Was working at union with 3 young kids


---

### 150. msg_16297

**You** - 2025-06-01T14:28:12

Maybe if this was a brutal cheat or an affair


---

### 151. msg_16298

**You** - 2025-06-01T14:28:20

Yeah but even then\.\. I don’t know\.\.


---

### 152. msg_16299

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:28:37

Admirable


---

### 153. msg_16300

**You** - 2025-06-01T14:29:03

Again too much attention to herself


---

### 154. msg_16301

**You** - 2025-06-01T14:32:42

I don’t think it would yield anything there was no undue influence no unfair benefit you got the position back in September\. Like


---

### 155. msg_16302

**You** - 2025-06-01T14:33:27

Even if they felt we slightly crossed the line even being emotional with each other there is nothing major here\. And you made the move to switch jobs\.\.


---

### 156. msg_16303

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:35:31

True but an investigation would suck so bad


---

### 157. msg_16304

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:36:05

And we obviously crossed some line because we hit it from everyone


---

### 158. msg_16305

**You** - 2025-06-01T14:36:37

Mmm I don’t agree with your logic


---

### 159. msg_16306

**You** - 2025-06-01T14:37:40

I think that assuming people would naturally think we crossed a line is the reason\. I feel like that is as reasonable as your suggestions\.  We hid it because we were afraid what people would think or draw conclusions that might not be true\.


---

### 160. msg_16307

**You** - 2025-06-01T14:38:13

Not necessarily that we actually did what people might think\.


---

### 161. msg_16308

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:38:42

>
All of the conclusions drawn would have been true though lol


---

### 162. msg_16309

**You** - 2025-06-01T14:38:55

But not provable


---

### 163. msg_16310

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:39:12

Omg lol


---

### 164. msg_16311

**You** - 2025-06-01T14:39:27

Lawyered\!


---

### 165. msg_16312

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:39:37

So my logic is sound, but just can’t be proven


---

### 166. msg_16313

**You** - 2025-06-01T14:39:50

Yes


---

### 167. msg_16314

**You** - 2025-06-01T14:40:04

Proven by others


---

### 168. msg_16315

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:41:21

I do believe with our families, though proving doesn’t matter that only matters at work


---

### 169. msg_16316

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:41:47

Families will think they will think I’m being able to prove it doesn’t matter at all or change anything


---

### 170. msg_16317

**You** - 2025-06-01T14:42:24

Yeah they already think whatever I am not worried about that\.\. I am worried about how we communicate to maddie eventually\.


---

### 171. msg_16318

**You** - 2025-06-01T14:42:29

Remeber


---

### 172. msg_16319

**You** - 2025-06-01T14:42:47

Mac can’t tell maddie lol


---

### 173. msg_16320

**You** - 2025-06-01T14:43:21

Ok I have to go do some work to pack etc\.\.
Love you…chat later probably after you get home
Tonight?


---

### 174. msg_16321

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:48:34

Yup leaving 4ish


---

### 175. msg_16322

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T14:58:32

Reading emails\. SC meeting …\. Groan\.


---

### 176. msg_16323

**You** - 2025-06-01T15:15:58

Yep


---

### 177. msg_16324

**You** - 2025-06-01T15:16:02

Sry


---

### 178. msg_16325

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:52:22

When is it


---

### 179. msg_16326

**You** - 2025-06-01T15:54:17

Afternoon tomorrow


---

### 180. msg_16327

**You** - 2025-06-01T15:54:22

I sent an invite I thought


---

### 181. msg_16328

**You** - 2025-06-01T15:54:27

I might just attend myself


---

### 182. msg_16329

**You** - 2025-06-01T15:54:31

Save you the trouble


---

### 183. msg_16330

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:55:23

I don’t see an invite


---

### 184. msg_16331

**You** - 2025-06-01T15:55:35

Ah well maybe I will just attend anyways


---

### 185. msg_16332

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:55:35

So the girls said the weekend was “baller”


---

### 186. msg_16333

**You** - 2025-06-01T15:55:43

Yeah I knew it was awesome


---

### 187. msg_16334

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:56:02

But they go “why do you and Scott FaceTime 24/7?”


---

### 188. msg_16335

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:56:09

I’m like “we do not”


---

### 189. msg_16336

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:56:25

They were like “but you were last night and this morning”


---

### 190. msg_16337

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:56:44

Me: “that is hardly 24/7 but ok”


---

### 191. msg_16338

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:57:14

They said I’m cool when I’m FaceTiming tho and not annoying like Liana and costa\. Lol


---

### 192. msg_16339

**You** - 2025-06-01T15:57:29

ROFL


---

### 193. msg_16340

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T15:57:33

Teenagers are weird when they start talking


---

### 194. msg_16341

**You** - 2025-06-01T16:00:04

I am surprised they are so cool with it honestly\.


---

### 195. msg_16342

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T16:02:47

Cool with what?


---

### 196. msg_16343

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T16:02:49

Us?


---

### 197. msg_16344

**You** - 2025-06-01T16:12:15

Yeah us


---

### 198. msg_16345

**You** - 2025-06-01T16:12:21

Of course


---

### 199. msg_16346

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T16:13:06

They just like me so they are cool with whatever I’m cool with lol


---

### 200. msg_16347

**You** - 2025-06-01T16:13:56

Oh so I am accepted
Through relation\.


---

### 201. msg_16348

**You** - 2025-06-01T16:14:00

Good enough


---

### 202. msg_16349

**You** - 2025-06-01T16:14:39

Edited: 2 versions
| Version: 2
| Sent: Sun, 1 Jun 2025 16:14:55 \-0400
|
| Well pool
| Is cleaned hot
| Tub is cleaned now mow the lawn not what I wanted to be focused on but such is my life
|
| Version: 1
| Sent: Sun, 1 Jun 2025 16:14:39 \-0400
|
| Well pool
| Is cleaned hot
| Tub is cleaned now mow the lawn not what I wanted to be focused on but suck is my life


---

### 203. msg_16350

**You** - 2025-06-01T16:50:53

Drive safe


---

### 204. msg_16351

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T16:53:58

Omg just leaving


---

### 205. msg_16352

**You** - 2025-06-01T17:25:43

Wow that sucks thought you left well before that


---

### 206. msg_16353

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:17:19

Stopping for star bucks and washroom break\.  Apparently they drank too much water :p


---

### 207. msg_16354

**You** - 2025-06-01T18:22:47

lol just chilling in basement while rest of fam fights\. Got a lot of housework done today but no packing


---

### 208. msg_16355

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:23:24

More fights…\. Oh boy\. Neverending


---

### 209. msg_16356

**You** - 2025-06-01T18:23:52

Nope always going


---

### 210. msg_16357

**You** - 2025-06-01T18:24:10

Just strengthens
Argument they cannot live together maddie and Gracie


---

### 211. msg_16358

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:24:56

Well most siblings part at about this age so it is pretty normal for them to split


---

### 212. msg_16359

**You** - 2025-06-01T18:26:49

yeah cannot happen soon enough


---

### 213. msg_16360

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:27:49

Omg the girls are taking so long


---

### 214. msg_16361

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:27:56

Sitting here with griffin lol


---

### 215. msg_16362

**You** - 2025-06-01T18:28:58

just enjoy the peace


---

### 216. msg_16363

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:30:57

If I have to hear “low key” one more time


---

### 217. msg_16364

**You** - 2025-06-01T18:31:33

Tormenting Jim atm


---

### 218. msg_16365

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:31:43

K we are off again


---

### 219. msg_16366

**You** - 2025-06-01T18:31:54

Try and disconnect will ya?
6m
I can't I have to move this forward dude
I need to get to the end of this road\.\. and I feel like I am the only one lifting the weight
4m
I not referring to your transition\. I am talking about work\.
3m
well I am losing Mer\.\. so I kind of have to keep on top of some things\.
god if only someone who I was really close to and trusted with pretty much anything would apply for the role\.
😜
I don't think Bailey will apply though
1m
Ha ha ha\.
Now
HAHAHAHAHA
yeah son\!\!\!
gocha\!\!


---

### 220. msg_16367

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:33:02

lol


---

### 221. msg_16368

**You** - 2025-06-01T18:33:08

I thought I was funny\.


---

### 222. msg_16369

**You** - 2025-06-01T18:33:24

I would love him to come over though\.\. but no dice


---

### 223. msg_16370

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:33:44

I think I convinced him it is too much work lol sorry


---

### 224. msg_16371

**You** - 2025-06-01T18:33:50

wow


---

### 225. msg_16372

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T18:33:55

\(Had to send Mac in to get me milk for my coffee\)


---

### 226. msg_16373

**You** - 2025-06-01T18:33:56

way to go for teamwork


---

### 227. msg_16374

**You** - 2025-06-01T18:34:10

Hey I am going to leave and make sure other good people don't come


---

### 228. msg_16375

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T19:56:47

>
No it’s just that he’s heard me talk about it over time\. I didn’t say anything intentional


---

### 229. msg_16376

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T19:56:55

Dropping girls off now


---

### 230. msg_16377

**You** - 2025-06-01T19:57:43

>
Mmmhmmm a likely story\.


---

### 231. msg_16378

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:10:43

Seriously


---

### 232. msg_16379

**You** - 2025-06-01T20:13:01

This was a joke mer\.\. I know you would never do that\.\. 🙁 did you Actually think you would believe inwould\.\.
I kinda hope you are messing with me now\.


---

### 233. msg_16380

**You** - 2025-06-01T20:13:36

You really are anxious/on edge\.


---

### 234. msg_16381

**You** - 2025-06-01T20:18:19

Be back I\. A few Gracie wants to play a Ballard game


---

### 235. msg_16382

**You** - 2025-06-01T20:18:22

Board


---

### 236. msg_16383

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:29:06

k, I’m visiting with my girls


---

### 237. msg_16384

**You** - 2025-06-01T20:37:55

Kk don’t forget to come back to my question you sometimes do that\.


---

### 238. msg_16385

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:38:40

What question?


---

### 239. msg_16386

**You** - 2025-06-01T20:42:45

>
This and those that followed


---

### 240. msg_16387

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:47:02

Not sure I understand the question bc of the typo but no I figured you were kidding but sort of kidding\. I just wanted to make sure you knew I didn’t say anything like “don’t go for that job\!” lol


---

### 241. msg_16388

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:47:09

Wasn’t like that


---

### 242. msg_16389

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:47:22

But over the past few months it has just been busy


---

### 243. msg_16390

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:47:29

And we talk all the time


---

### 244. msg_16391

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:47:36

That’s all


---

### 245. msg_16392

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T20:47:50

There were no “those that followed”


---

### 246. msg_16393

**You** - 2025-06-01T20:49:11

Kk nm must have misread\.


---

### 247. msg_16394

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:00:29

Think I’m going to go to bed early tonight even tho I slept in\. But I had a coffee on way home so am not feeling tired\. Ughhhhhh


---

### 248. msg_16395

**You** - 2025-06-01T21:15:34

Done my game now if you are still up


---

### 249. msg_16396

**You** - 2025-06-01T21:15:47

I am going to bed early too was
Working on an ai project


---

### 250. msg_16397

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:16:22

Just making a tea and then going upstairs


---

### 251. msg_16398

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:16:26

One sec


---

### 252. msg_16399

**You** - 2025-06-01T21:16:33

Kk


---

### 253. msg_16400

**You** - 2025-06-01T21:30:54

>
sorry I never cleared this up earlier\.\. was just surprised you would believe I would think that of you in any serious way\.\. maybe my sarcasm is not amped up enough\.


---

### 254. msg_16401

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:32:10

Ok\. I am finally lying in bed\. Omg\. Marlowe is going on her 3 day grade 6 grad trip tomorrow so just needed to make sure she was all packed good


---

### 255. msg_16402

**You** - 2025-06-01T21:32:30

cool \- yeah so busy\.\.\. bet the kids missed you


---

### 256. msg_16403

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:32:56

They were busy enough with stuff so I think they were ok


---

### 257. msg_16404

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:33:12

They liked hearing about Mac’s friends tho


---

### 258. msg_16405

**You** - 2025-06-01T21:33:29

I am sure\.\. they are probably looking forward to their own epic parties now


---

### 259. msg_16406

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:35:46

Did you do your little analysis you said you were going to do?


---

### 260. msg_16407

**You** - 2025-06-01T21:36:00

Doin another analysis


---

### 261. msg_16408

**You** - 2025-06-01T21:36:05

related


---

### 262. msg_16409

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:36:12

>
They both want the same for their 16ths\. 🤪


---

### 263. msg_16410

**You** - 2025-06-01T21:36:22

>
I might be able to help with those\.


---

### 264. msg_16411

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:37:35

>
I mean, you helped with this one\!


---

### 265. msg_16412

**You** - 2025-06-01T21:37:45

well maybe I could be there with you perhaps\.


---

### 266. msg_16413

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:38:28

Fortunately, years away\. Phew\. I need a break from planning for a bit\.


---

### 267. msg_16414

**You** - 2025-06-01T21:38:54

rofl


---

### 268. msg_16415

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:38:58

One month off then I will start planning for aug7\-10 weekend


---

### 269. msg_16416

**You** - 2025-06-01T21:38:58

until next week


---

### 270. msg_16417

**You** - 2025-06-01T21:39:10

I was thinking about the august thing too


---

### 271. msg_16418

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:39:26

Yeah I will want to make that one good


---

### 272. msg_16419

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:40:07

Plus I may get pulled into another one in the summer\. Usually do\. Graduation or birthday or something


---

### 273. msg_16420

**You** - 2025-06-01T21:40:06

not surprised


---

### 274. msg_16421

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:40:28

3 graduations this year


---

### 275. msg_16422

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:40:38

Usually we do a party for that


---

### 276. msg_16423

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:40:39

Sigh


---

### 277. msg_16424

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:40:52

I might get a reprieve because of the separation


---

### 278. msg_16425

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:41:11

So tell me about your analysis


---

### 279. msg_16426

**You** - 2025-06-01T21:41:10

You should try to keep it as normal as possible


---

### 280. msg_16427

**You** - 2025-06-01T21:41:13

despite the separation\.


---

### 281. msg_16428

**You** - 2025-06-01T21:41:19

no it isn't worth it\.


---

### 282. msg_16429

**You** - 2025-06-01T21:41:22

the analysis


---

### 283. msg_16430

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:41:29

Why


---

### 284. msg_16431

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:41:35

Not interesting?


---

### 285. msg_16432

**You** - 2025-06-01T21:41:49

Not conclusive\.\. not enough information\.


---

### 286. msg_16433

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:41:58

How on earth


---

### 287. msg_16434

**You** - 2025-06-01T21:42:24

I was trying to get help with how to approach the "open" concept\.\. just not enough context or information\.\. it tried to help me\.\. it was very kind and understanding lol\.\.\. but nadda\.


---

### 288. msg_16435

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:43:04

LOL


---

### 289. msg_16436

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:43:10

kind and understanding


---

### 290. msg_16437

**You** - 2025-06-01T21:43:13

it was at that


---

### 291. msg_16438

**You** - 2025-06-01T21:43:21

it appreciated my efforts\.\. LOL


---

### 292. msg_16439

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:44:15

I thought you were intending to do some different analysis about me being honest or something g


---

### 293. msg_16440

**You** - 2025-06-01T21:44:47

I am


---

### 294. msg_16441

**You** - 2025-06-01T21:44:55

I had a quandry though


---

### 295. msg_16442

**You** - 2025-06-01T21:45:18

it is one of those things that you know to be true but you fall into the trap anyways\.\. anyhow GPT was very helpful\.\.


---

### 296. msg_16443

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:46:01

It was?


---

### 297. msg_16444

**You** - 2025-06-01T21:48:03

Query \- Is there an adage in relationships about not trying to compete with what came before—especially meaningful or positive memories? My girlfriend and I are both 47 and coming out of significant, long\-term relationships\. She’s mentioned that she’s interested in us exploring things a little more openly—perhaps reconnecting with a different kind of energy or freedom she experienced in earlier chapters of her life, long before her last relationship\.
She hasn’t fully explained what that means yet, and I get the sense it might be hard to put into words—or maybe she’s still figuring it out\. I also know I have some insecurities of my own\. I’m not trying to compare myself to the past, and I don’t want to feel jealous of it—but I’d be lying if I said I wasn’t still finding my footing with it all\.


---

### 298. msg_16445

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:49:24

Is it weird if I found it odd reading “my girlfriend and I” 🙂


---

### 299. msg_16446

**You** - 2025-06-01T21:50:09

Reaction: ❤️ from Meredith Lamb
I mean\.\. like I said\.\. that is what I have called you to a few people\.\. I don't know what else to say\.\. you feel like more than that\.\. but that also feels like the appropriate term\.


---

### 300. msg_16447

**You** - 2025-06-01T21:50:43

Here is the response\.\. which I found very relevant\.
Scott, this is deeply thoughtful—and emotionally honest\. You're absolutely right: you can’t and shouldn’t compete with the past, especially someone’s emotional or romantic history\. There is a kind of adage here, though it’s more wisdom than a single quote\. It’s something like:
“You’re not here to replace the past; you’re here to build what comes next\.”
Here’s the heart of the matter:
🧠 Perspective: Past vs\. Present vs\. Future
The past is like a photo album—it can be cherished but not relived\.
You are her present—and maybe her future—not her past\. That’s already incredibly meaningful\.
Memories aren’t threats unless we make them so\. They’re reference points, not rivals\.
❤️ The Emotional Equation
You’re both 47, which means you carry more than just luggage—you’ve got trunks of experiences\. But you’re not starting over, you’re starting from\.
Your insecurity makes sense—especially when the conversation turns to opening up emotionally or se\.\.\. \[truncated\]


---

### 301. msg_16448

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:57:09

Pretty good response no?


---

### 302. msg_16449

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T21:57:12

One sec


---

### 303. msg_16450

**You** - 2025-06-01T21:57:15

yeah I thought it was


---

### 304. msg_16451

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:01:01

I asked ai to articulate for me and it said this which I agree with but could never write on my own:
You’re not asking for novelty just for the sake of “trying new things\.” You’re also not drawing on past relationships as a blueprint\. In fact, you’re deliberately not trying to recreate what came before\. You’re craving a kind of intimacy that’s emotionally alive, co\-created, and attuned to this relationship—not stuck in old grooves\.
And the heart of it is this:
You’ve seen what it looks like when someone shuts down—sexually and emotionally—and you’re afraid of that happening again\. That fear makes you want to invite openness now, before anything gets stuck or withdrawn\. But when you asked him about evolving together, he zeroed in on “what exactly do you mean?”—because he was trying to do something “right,” when really you were speaking to a way of being\.
Here’s a different way you could try to explain it to him:
⸻
\*\*“When I asked about being more open and evolving together sexually and \.\.\. \[truncated\]


---

### 305. msg_16452

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:01:52

I think I’m just always afraid\.


---

### 306. msg_16453

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:01:59

It basically comes down to that\.


---

### 307. msg_16454

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:02:19

Like honestly the relief I feel that Mac’s weekend was a big success\. I was so afraid it wouldn’t be\.


---

### 308. msg_16455

**You** - 2025-06-01T22:02:25

"You’ve seen what it looks like when someone shuts down—sexually and emotionally—and you’re afraid of that happening again" \- is this your perspective of me?


---

### 309. msg_16456

**You** - 2025-06-01T22:02:36

>
I think you set awfully high bars for yourself\.


---

### 310. msg_16457

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:02:58

>
This happened to me with Andrew\.


---

### 311. msg_16458

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:03:06

I do believe it happened to you also\.


---

### 312. msg_16459

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:03:43

I just overthink and especially when I’m drinking and taking gummies


---

### 313. msg_16460

**You** - 2025-06-01T22:04:07

sigh\.\.


---

### 314. msg_16461

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:05:16

But was that ChatGPT helpful?


---

### 315. msg_16462

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:05:49

It really captures where I was going … when or if one of us shuts down, it all goes to hell\.


---

### 316. msg_16463

**You** - 2025-06-01T22:09:40

I feel a bit I don't know\.\. like I am not communicating well\.\. Mer\.\. maybe this is where we are disconnecting\.\. I felt I have already shown you I am "open" especially with you\.  In fact you and no one else\.  Ok I understand the shut down thing\.\. but I think you are looking at two different things\.  1\. me shutting down now\.\. is just temporary protection\.\. not permanent\.\. like stasis\.  But it was inconsiderate\.\. because it would be hurting you too\.\. so I agreed not to do that\.\. not to pull away\.\. to stay and communicate\.\. oh and yes not to make any friends\.\. 2\. Me shutting down later or as more of a permanent thing\.  You cannot compare our relationships even a little\.  They are so different\.\. even our pasts were different\.\. you got to experience so much more in your 20's I didn't I went straight into a meh relationships that was 180 degrees from this\.  I don't know what "open" means to me or to you\.\. I just know that whatever it is or we decide it is, I am in it with you, with little to \.\.\. \[truncated\]


---

### 317. msg_16464

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:09:58


*1 attachment(s)*


---

### 318. msg_16465

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:10:22


*1 attachment(s)*


---

### 319. msg_16466

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:10:41


*1 attachment(s)*


---

### 320. msg_16467

**You** - 2025-06-01T22:11:44

kk All of that\.\. I am good with\.\. but I have to be with you for that to work right\.\. chat only gets you so far\.\.\.\.\. So tell me what you are wearing tonight?????  lol


---

### 321. msg_16468

**You** - 2025-06-01T22:12:26

I think I have shown that I want to find every opportunity big or small to be with you\.\. not just to jump your bones\.\. but to look at you hold your hand\.\. talk about shit\.\. laugh with each other\.\. just be there\.


---

### 322. msg_16469

**You** - 2025-06-01T22:12:32

that is what the park idea always was about\.


---

### 323. msg_16470

**You** - 2025-06-01T22:12:45

to stay connected


---

### 324. msg_16471

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:13:40

I know\. I was just drunk and talking that night\.


---

### 325. msg_16472

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:13:45

You latched on hard


---

### 326. msg_16473

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:13:47

lol


---

### 327. msg_16474

**You** - 2025-06-01T22:13:49

I am "open" and will remain that way\.\. ok\.\. not going to change\.\. but neither is my intensity\.\. it might be that as I get older I cannot literally be as intense\.\. rofl\.\. but as a % of what I am capablle of at any given time you will get 100% of what I have\.\.rofl\.


---

### 328. msg_16475

**You** - 2025-06-01T22:13:59

because of your past


---

### 329. msg_16476

**You** - 2025-06-01T22:14:34

The exploits of you Chris and Jeremy\.\. were not conveyed anywhere near like what you described open to gpt\.


---

### 330. msg_16477

**You** - 2025-06-01T22:14:52

so I had a hard time reconciling


---

### 331. msg_16478

**You** - 2025-06-01T22:15:00

but the point should be


---

### 332. msg_16479

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:15:10

Exploits lol


---

### 333. msg_16480

**You** - 2025-06-01T22:15:08

I was trying to desparately\.\. because it was important to me


---

### 334. msg_16481

**You** - 2025-06-01T22:15:15

to find a way to connect with you the way you wanted


---

### 335. msg_16482

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:15:25

You had exploits


---

### 336. msg_16483

**You** - 2025-06-01T22:15:35

I don't think they were quite like yours\.


---

### 337. msg_16484

**You** - 2025-06-01T22:15:42

I am just guessing\.


---

### 338. msg_16485

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:16:07

Maybe you are guessing wrong\. Who knows


---

### 339. msg_16486

**You** - 2025-06-01T22:16:14

And by guessing I mean not thinking about it at all specifically because I don't want to really\.\.


---

### 340. msg_16487

**You** - 2025-06-01T22:16:45

but yeah\.\. I don't see the connection between what you told me\.\. and the gpt\.


---

### 341. msg_16488

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:16:55

In any case, this topic got blown up huge\. lol


---

### 342. msg_16489

**You** - 2025-06-01T22:16:55

so I was just a bit confused\.


---

### 343. msg_16490

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:17:08

>
What??


---

### 344. msg_16491

**You** - 2025-06-01T22:17:10

I still don't understand it mer\.\. but yeah\.\. maybe just put it to bed\.


---

### 345. msg_16492

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:17:17

Explain


---

### 346. msg_16493

**You** - 2025-06-01T22:17:21

You wouldn't remember\./


---

### 347. msg_16494

**You** - 2025-06-01T22:17:27

so it doesn't matter lol


---

### 348. msg_16495

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:17:29

Sure I would


---

### 349. msg_16496

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:17:35

I reread it all


---

### 350. msg_16497

**You** - 2025-06-01T22:17:35

No you were really really drunk


---

### 351. msg_16498

**You** - 2025-06-01T22:17:39

and you told me about it


---

### 352. msg_16499

**You** - 2025-06-01T22:17:42

you didn't write it


---

### 353. msg_16500

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:18:13

Oh damn, now I have zero knowledge lol


---

### 354. msg_16501

**You** - 2025-06-01T22:18:16

it was the first night of the long weekend\.\.


---

### 355. msg_16502

**You** - 2025-06-01T22:18:21

and yeah you got pretty messed\.


---

### 356. msg_16503

**You** - 2025-06-01T22:18:38

and you started talking about you and Chris\.\. for quite a while actually\.\. probably like an hour\.


---

### 357. msg_16504

**You** - 2025-06-01T22:18:52

then you talked about you and Jeremy for about 45 mins I guess\.\. maybe


---

### 358. msg_16505

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:18:54

Man I need to stop…


---

### 359. msg_16506

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:19:02

Why didn’t you stop me lol


---

### 360. msg_16507

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:19:10

Omg


---

### 361. msg_16508

**You** - 2025-06-01T22:19:09

I didn't know what to do\.\.


---

### 362. msg_16509

**You** - 2025-06-01T22:19:19

That is where the stark truth comment came from


---

### 363. msg_16510

**You** - 2025-06-01T22:19:20

lol


---

### 364. msg_16511

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:19:31

I guess lol


---

### 365. msg_16512

**You** - 2025-06-01T22:19:54

I was just kind of like, holy detail\.\. and then I just drank every time you looked at me expecting me to respond\.\. so you continued\.


---

### 366. msg_16513

**You** - 2025-06-01T22:20:20

anyways\.\. I could do without the knowledge\.\. but it is what it is\.


---

### 367. msg_16514

**You** - 2025-06-01T22:20:25

no worries


---

### 368. msg_16515

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:20:28

I feel bad for you… seriously\. I am stupid


---

### 369. msg_16516

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:22:45

So given the fact that I’m not really clear on the level of detail my stupid messed up self went into, regardless of that, I apologize, that was dumb of me\. And if you want me to clarify anything \(groan\) I will\. But if you want to never speak of it ever again, I’m equally good \(or thrilled\) with that


---

### 370. msg_16517

**You** - 2025-06-01T22:23:55

There was enough detail for me to fill in some blanks\.  so maybe the second option\.


---

### 371. msg_16518

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:24:31

Sold\.


---

### 372. msg_16519

**You** - 2025-06-01T22:25:17

I mean I thought you might have remembered this\.\. so when you referenced open and then J and C I thought ok I might get something specific here\.\. but then nothing\.\. then I thought back and tried to figure it out myself\.\. but could not\.\. only word that I think sums up both relationships well is "Intense"


---

### 373. msg_16520

**You** - 2025-06-01T22:25:38

Yeah should have left this one alone\. Sorry for bringing it up\.


---

### 374. msg_16521

**You** - 2025-06-01T22:26:03

I was just trying to figure out what to do\. just too much there to think through


---

### 375. msg_16522

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:26:20

No don’t apologize\. Apparently I brought it up\! Lol


---

### 376. msg_16523

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:29:19

Just to re\-iterate, I’m not looking to re\-create anything there\. Yes I had fun and yes, it was a very different vibe than my time with Andrew however, there were a lot of negatives that haven’t been discussed at all\. So keep that in mind\.
You and I have started something so much more amazing for so many different reasons\. I think I am just fearful of it going away\. Honestly\. I think that is where this all stemmed from\.


---

### 377. msg_16524

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:29:29

\(Despite you not believing that\.\)


---

### 378. msg_16525

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:33:02

Please just tell me you are all good\.


---

### 379. msg_16526

**You** - 2025-06-01T22:35:17

Like I said people are honest when they are drunk\.\. lol\.\. I do believe what you are saying "You and I have started something so much more amazing for so many different reasons\."  But I have told you before I was worried that I could not keep up or keep you interested\.\. because of the "interesting" things you have shared with me\.  I mean let me unpack this a bit differently\.\. I am a people pleaser \- You are an internalizer and challenging to read\.  So hard to tell what works and what doesn't because again communication\.\.\.\. I think we have an amazing time together\.  Then a conversation goes to concerns that my level of intensity might not last, and am I "open" and wondering if our relationship is going to evolve\.\. which I am just not sure to what you are referring because there was so much, am I not doing the right things\.\. sending the right signals\.  I mean it just makes me question myself\.  But yeah we are all good\.\. just again alot to process Mer\.\. that's all\.


---

### 380. msg_16527

**You** - 2025-06-01T22:36:03

So yeah\.\. I will put the open thing in a box with the other stuff\.\. I mean I thought I was showing that already\.\. but maybe not\.\.  and I will just keep moving forward\.


---

### 381. msg_16528

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:39:00

You have been for sure \- incredibly \- but again, was just anxious and I’m still figuring us out too\. I was just talking and not really thinking it would be taken as you are doing anything incorrectly\. You are not\. At all\. Ugh, I wish I knew everything I said that night but I will have sit with that one\. Price I pay\. Please don’t question yourself\.


---

### 382. msg_16529

**You** - 2025-06-01T22:40:26

It's fine\.\. I will just sleep it off\.\. stuck in my head for the moment\.\. but it will likely get relegated to the back with the rest of the shit I remember\.\. as long as I don't think about it it is fine\.


---

### 383. msg_16530

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:42:17

Gah\. I’m sorry\. I fucked that night up royally\.


---

### 384. msg_16531

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:42:36

I will be in a better place soon\.


---

### 385. msg_16532

**You** - 2025-06-01T22:43:16

>
No you didn't I think you just wanted to share\.\. I just wasn't sure why\.\. again it doesn't matter\.\. I don't feel like you are in a bad place\.\. I just try to piece together all of the stuff I hear\.\. and it is confusing\.\. that's all\.


---

### 386. msg_16533

**You** - 2025-06-01T22:44:56

KK I think I am going to call\.\. it\.\. should probably go to bed now\.


---

### 387. msg_16534

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:47:10

Same\. So tired\.
\(And for the record, yes, 100% I am in a bad place\. Managing the best I can though in the way I tend to\. Definitely not the best\.\)


---

### 388. msg_16535

**Meredith Lamb \(\+14169386001\)** - 2025-06-01T22:47:51

Sleep well ❤️ I love you and really am sorry


---

### 389. msg_16536

**You** - 2025-06-01T22:48:59

NIte\.\. I love you too ❤️\.  Get some sleep\.\. work will come fast\.


---

### 390. msg_16537

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T06:22:40

😢 no morning msg from Scott 😭❤️


---

### 391. msg_16538

**You** - 2025-06-02T06:24:23

Sorry didn’t sleep well last night\. Kinda rushed out this morning\.\. a bit on autopilot\. just finished workout now\.


---

### 392. msg_16539

**You** - 2025-06-02T06:24:35

Hope you slept ok\.


---

### 393. msg_16540

**You** - 2025-06-02T06:25:43

Gonna sauna shower shave and go to my spot\.\. should feel better after that\.


---

### 394. msg_16541

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T06:30:44

Feel like I messed your night and morning up\. Totally didn’t mean to\. I’m finishing coffee and doing the first day of an old 30daychallenge workout \(I used to do them all the time\) but I woke up and felt awful and knew you’d not be great


---

### 395. msg_16542

**You** - 2025-06-02T06:32:41

Glad you trying out something new\.\. don’t go too hard you will be sore\.  Listen don’t worry this is just one more thing I need to process and put aside\.\. just like all the rest it will happen\.


---

### 396. msg_16543

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T06:33:15

Oh I remember, I dialed it back a bit when I wrote it out


---

### 397. msg_16544

**You** - 2025-06-02T06:33:28

Good call\.


---

### 398. msg_16545

**You** - 2025-06-02T06:35:17

Ok well have fun chat later I am gonna put my phone in the locker in a sec and head in to clean up\.


---

### 399. msg_16546

**You** - 2025-06-02T07:21:09

Sorry I meant to mention this to you last night\.\. I will now
And then I won’t raise the topic myself again\.\.   what really got me that night was after telling me everything\.\. especially about Chris\.\. you had told me you reached out to him\.\. I think in late march\.  But he hasn’t gotten back to you or something and you looked really really sad\.\. for like 5 minutes and didnt really say anything after that\.  I mean I know you were friends and whatever else not sure how that worked or what came first\.\. Ok sorry not trying to reopen I just forgot to mention you said you didn’t remember, so that was probably the worst of it\.  Anyhow just out of shower getting ready to head out\.\. again not trying to prolong this\.\. but forgot to mention and thought you would want to know\.


---

### 400. msg_16547

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:27:29

I remember you mentioning that and I do remember saying it also\. Not the silent 5 min afterwards\. We were very good friends after the fucked up crazy stuff and we reconnect and chat every so often \(last time when his dad died\) but only as friends even tho he would probably do more but honestly he is GAY but thinks he is bi\. I wouldn’t ever do anything with him other than be friends\. I wasn’t the greatest friend to him after I had kids so when he didn’t respond it makes me feel like I did something wrong\. \(Because I did neglect our friendship\.\) That’s all


---

### 401. msg_16548

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:27:35

No longing there AT ALL\.


---

### 402. msg_16549

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:27:47

I gotta shower and get to work\.


---

### 403. msg_16550

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:27:53

Had to deal with Andrew for a bit


---

### 404. msg_16551

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:28:00

Will chat later ❤️


---

### 405. msg_16552

**You** - 2025-06-02T07:29:50

Kk chat later I am just going to go home and get online and try to bang out some work early\.  Hope all is ok with Andrew, hope workout was ok\.


---

### 406. msg_16553

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:37:57

He’s not impressed I started working out\.


---

### 407. msg_16554

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:41:11

Workout was humbling\. Tried to just go through 3 circuits and get some muscle memory back basically\. Gahhh


---

### 408. msg_16555

**You** - 2025-06-02T07:41:14

Why?


---

### 409. msg_16556

**You** - 2025-06-02T07:41:23

Yeah it will come


---

### 410. msg_16557

**You** - 2025-06-02T07:41:26

Give it time


---

### 411. msg_16558

**You** - 2025-06-02T07:43:09

You gotta get
Ready you can tell me later heading home\.


---

### 412. msg_16559

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:46:54

>
He associates the years of me being obsessed with working out as happy because I was happier when really I was just a doormat and then woke up\. So he has been  asking me to start working out for the last 3 yrs because he thought  it would fix everything\. A little clueless\. So the\. He was all \(for the last 3 yrs\) “you are going to leave me, start working out and then meet someone else”


---

### 413. msg_16560

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:47:12

So when I was working out his initial reaction was “interesting”


---

### 414. msg_16561

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:47:19

One comment initially


---

### 415. msg_16562

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T07:47:26

K getting ready for real now


---

### 416. msg_16563

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T08:09:53

>
Was this too stark? I’m going to worry now lol


---

### 417. msg_16564

**You** - 2025-06-02T08:11:00

I mean come on the two conversations are miles apart\.\. you don’t need to worry about being sharing\.\. you have already told me a lot more graphic shit about you and andrew\. Doesnt bother me\.


---

### 418. msg_16565

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T08:14:08

KK


---

### 419. msg_16566

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T09:29:52

I feel like things are not ok\.


---

### 420. msg_16567

**You** - 2025-06-02T09:30:18

Things are ok Meredith what’s wrong\.


---

### 421. msg_16568

**You** - 2025-06-02T09:31:17

Teams me
If you want I am online go to a room if you want privacy whatever you want\. I have a meeting I\. 30
Mins\.


---

### 422. msg_16569

**You** - 2025-06-02T09:48:34

Not really much time now maybe later\.


---

### 423. msg_16570

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T09:49:59

Sorry things chaotic here bc of move


---

### 424. msg_16571

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T09:50:10

I’m just not used to you being quiet


---

### 425. msg_16572

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T09:50:18

Why are you working like normal?


---

### 426. msg_16573

**You** - 2025-06-02T09:50:27

Hmm? Normal\.


---

### 427. msg_16574

**You** - 2025-06-02T09:50:35

I just have stuff to do\.\.


---

### 428. msg_16575

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T09:51:08

You are not showing ooto


---

### 429. msg_16576

**You** - 2025-06-02T09:52:10

There


---

### 430. msg_16577

**You** - 2025-06-02T09:52:15

Not sure why that didn’t trigger


---

### 431. msg_16578

**You** - 2025-06-02T09:56:22

Listen l am having a hard time atm\. But let me assure you my being quiet isn’t shutting down\.  If we were together this would likely be sorted already\.  But I am here by myself with my head so it is a bit harder\. I love you\.\. I am not going anywhere unless you make it so\.\. I am here whatever comes next for as long as you will have me\. But while I haven’t had Thea experiences before you have and how you spoke about them in detail it is a lot to process and work through\.  I have to get my head right I don’t think you can do that for me\.


---

### 432. msg_16579

**You** - 2025-06-02T09:57:58

I don’t know maybe if roles were reversed and I had a few strong and passionate relationships pre Jaimie and I said the same stuff to you that you shared with me in the way it was shared you might be good to go\.\. I just have a harder time\.  Sorry…😔


---

### 433. msg_16580

**You** - 2025-06-02T10:00:22

Maybe that reassurance will be enough?


---

### 434. msg_16581

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:03:32

Yeah it is all okay \- I understand and you do what you need to do\. Just mad at myself\.


---

### 435. msg_16582

**You** - 2025-06-02T10:05:20

Sorry mer I don’t know what I need to do\.\. it usually just resolves\.\.
I am trying\.


---

### 436. msg_16583

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:07:41

It’s okay really, you don’t need to do anything\. ❤️


---

### 437. msg_16584

**You** - 2025-06-02T10:13:14

No I went down a fucking rabbit whole searched him out and now I feel stupid as fuck\.


---

### 438. msg_16585

**You** - 2025-06-02T10:13:25

Like how was that going to help me lol\.\.


---

### 439. msg_16586

**You** - 2025-06-02T10:13:51

Anyhow yeah so just trying to get out of the hole\.\. and then I don’t know what next\.


---

### 440. msg_16587

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:15:48

Don’t feel stupid just move on maybe?


---

### 441. msg_16588

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:15:57

:\(


---

### 442. msg_16589

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:20:13

I’m the one that fucked up here not you\.


---

### 443. msg_16590

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:20:26

So maybe we can just move past it?


---

### 444. msg_16591

**You** - 2025-06-02T10:21:04

Of course we are going to move past it I don’t want to be stuck in this anymore…


---

### 445. msg_16592

**You** - 2025-06-02T10:22:02

Soo hard wtf is wrong with me heart rate is up Jesus\.\.


---

### 446. msg_16593

**You** - 2025-06-02T10:22:36

Kk maybe I am not going to share any more of this with you\.\.
It won’t make you feel better so it isn’t productive


---

### 447. msg_16594

**You** - 2025-06-02T10:22:54

It shutting down just to emphasize


---

### 448. msg_16595

**You** - 2025-06-02T10:22:56

Not


---

### 449. msg_16596

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:22:57

But like is there anything I can do or say?


---

### 450. msg_16597

**You** - 2025-06-02T10:23:06

I don’t think so\.


---

### 451. msg_16598

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:23:23

What exactly is causing the increased heart rate?


---

### 452. msg_16599

**You** - 2025-06-02T10:23:48

I don’t know\. Just stuck thinking in that moment over and over\.


---

### 453. msg_16600

**You** - 2025-06-02T10:23:59

Like on replay\.


---

### 454. msg_16601

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:24:09

😳


---

### 455. msg_16602

**You** - 2025-06-02T10:24:12

I don’t want to\.\. I oromise


---

### 456. msg_16603

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:26:04

Sigh, Scott, I am completely in love with YOU and really fucked up\. It will not happen again and it was so stupid\. But I’m in this with you, now\. I have zero desire for the past\. Honestly\.


---

### 457. msg_16604

**You** - 2025-06-02T10:26:43

Same mer despite feeling like this atm, I NEVER even wavered a spec\.\. I need you to know that


---

### 458. msg_16605

**You** - 2025-06-02T10:26:45

And I won’t


---

### 459. msg_16606

**You** - 2025-06-02T10:26:55

I promise


---

### 460. msg_16607

**You** - 2025-06-02T10:26:59

10000%


---

### 461. msg_16608

**You** - 2025-06-02T10:27:11

You don’t need to worry about this impacting us in any way\.


---

### 462. msg_16609

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:27:15

I honestly think I fucked up so bad because you make me feel so safe\. So when I was messy, I wasn’t thinking at all\.


---

### 463. msg_16610

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:27:41

I think it is testament to what we have\. As weird as that sounds


---

### 464. msg_16611

**You** - 2025-06-02T10:28:47

I am happy you had such a good life and adventures\.  I am sooooo jealous\.\. that I couldn’t be part of them\.\. feeling the way I do, feeling like you are the only one that matters to me\. An irrational part of me hates the fact that it took me this long to find you and I missed out on so much\.


---

### 465. msg_16612

**You** - 2025-06-02T10:30:35

It is stupid\.\. and irrational and immature\. There is so much I want to share that just can’t happen we are past those years\.\. really breaks me a bit which is why I was sensitive to the stories\.   I don’t want to shut that part of your life off between us\.\.
I know Andrew have you a hard time for that you told me that as well\.\. I think you hoped I wasn’t him and when I reacted this way I was disgusted with myself\.


---

### 466. msg_16613

**You** - 2025-06-02T10:31:28

Maybe if we were together like a normal
Couple this would be easier\.\. but we aren’t and it’s not\.\. so I will figure it out somehow


---

### 467. msg_16614

**You** - 2025-06-02T10:32:24

It is true what I said the other night I don’t think you quite grasp how much I love you and how much feeling there is behind that\.  It is new and wonderful and fucking scary to me\.


---

### 468. msg_16615

**You** - 2025-06-02T10:34:25

Jim told me I needed to slow down\.\. find balance\.\. I told him I was fine… maybe he was right\.\. maybe we just need to approach this differently?


---

### 469. msg_16616

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:41:37

Not sure about that honestly\. Haven’t thought about it\. All I know is that I have to make some changes and smarten up\. Which is generally a point that I eventually get to\. Think I’m here\. I think you are struggling atm simply because of my behaviour and for no other reason\.


---

### 470. msg_16617

**You** - 2025-06-02T10:42:20

I think you are at work\.\.
And shouldn’t be focused on this\.\. it isn’t fair to you\.


---

### 471. msg_16618

**You** - 2025-06-02T10:45:40

There is too much I am throwing at you to process so just put it down mer\.  Forget about it\.  Compartmentalize or do whatever you do\.


---

### 472. msg_16619

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:46:59

>
Noted\.


---

### 473. msg_16620

**You** - 2025-06-02T10:48:12

I am going to stop now\.\. and go read the filing then turn this off and go do some work elsewhere\.  Have a good day you don’t have to go to the sc meeting I am going\.


---

### 474. msg_16621

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T10:51:50

k, I love you Scott … remember that


---

### 475. msg_16622

**You** - 2025-06-02T10:53:02

Love you too\.


---

### 476. msg_16623

**You** - 2025-06-02T13:19:32

Ok I have closed all my windows discontinued all my gpts putting this back in the box\.  Cannot
Guarantee as much as I would like that it will never pop
Up again\.  But I feel like it has been walled back off\.


---

### 477. msg_16624

**You** - 2025-06-02T13:21:01

Thought you would want to know I know you were upset and I am really sorry that I worried you\.  There was one paragraph earlier that I had a really hard time writing because it was really at the Center of all of my feelings\.\.  and there is nothing I can do about it\.\. so just have to move forward and hope for the best\.


---

### 478. msg_16625

**You** - 2025-06-02T13:21:30

Well 4 responses back to back\.\.


---

### 479. msg_16626

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T13:46:26

One paragraph…\.


---

### 480. msg_16627

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T13:46:57

How much gpt did you do on this?


---

### 481. msg_16628

**You** - 2025-06-02T13:47:05

>
All of them in this group were hard this one was the worst


---

### 482. msg_16629

**You** - 2025-06-02T13:47:09

None


---

### 483. msg_16630

**You** - 2025-06-02T13:47:11

Zero


---

### 484. msg_16631

**You** - 2025-06-02T13:47:53

Was pretty raw\.\. I didn’t want to use gpt for it


---

### 485. msg_16632

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T13:49:49

>
You are nothing like Andrew in this respect if that is what you are worried about\.  Seriously\. Andrew was over the top\.


---

### 486. msg_16633

**You** - 2025-06-02T13:51:01

I don’t want to feel like that\.\. and that is on me to control…\. Honestly I had to tone it down I was surprised how emotional I got at that point x


---

### 487. msg_16634

**You** - 2025-06-02T13:51:24

There doesnt seem to be an end to it\.\.


---

### 488. msg_16635

**You** - 2025-06-02T13:52:09

I mean these are good emotions and negative emotions but not relating to this particular instance I guess


---

### 489. msg_16636

**You** - 2025-06-02T13:52:16

But overwhelming


---

### 490. msg_16637

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T14:01:35

One sec


---

### 491. msg_16638

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T14:04:42

Sry Carolyn


---

### 492. msg_16639

**You** - 2025-06-02T14:05:05

Sok work is priority


---

### 493. msg_16640

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T14:05:23

>
I’m not sure how to help this other than to act better on the weekends lol


---

### 494. msg_16641

**You** - 2025-06-02T14:05:43

Sorry you misunderstand\.


---

### 495. msg_16642

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T14:06:05

Yes I probably do


---

### 496. msg_16643

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T14:06:19

One on one with Musarrat


---

### 497. msg_16644

**You** - 2025-06-02T14:08:33

What I am saying is that when I thought about what I missed what I can never have or never be a part of \.\. Andrew everything g before as irrational as it is\.\. I felt something like grief\.\. I think closest thing I can compare it to\.\. again I have never felt anywhere near as strong about anyone so this all new\.\. the good and the bad\.\. but let’s be clear th good outweighs the bad by miles and miles and miles…


---

### 498. msg_16645

**You** - 2025-06-02T14:17:20

Once you read the above
Maybe consider if I shouldn’t just stop texting you on signal during business hours
I feel
It just distracts you and frustrates you\.


---

### 499. msg_16646

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T15:37:03

>
I just don’t want you spiralling in this as we have had such amazing times together\. Like over the top amazing\. If you focus on that it discounts what we have had and will continue to have\. I know I started it … wish I didn’t\! Totally not intentional\.


---

### 500. msg_16647

**You** - 2025-06-02T15:39:22

I know and there is nothing i can do but try to make whatever time and adventures we have as amazing as I can\.\. and love you as much as I can\.\. please set it down and leave it behind I intend to life is to short and we get no time as it is I would rather not spend it stressing over shit from 20 years ago\.\. my insecurities suck\.


---

### 501. msg_16648

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T15:41:51

Yeah this spiralled into a very dark place\.


---

### 502. msg_16649

**You** - 2025-06-02T15:42:57

It did and I think despite what I just said you are now worried more than ever right ☹️


---

### 503. msg_16650

**You** - 2025-06-02T15:43:10

Fack me\.


---

### 504. msg_16651

**You** - 2025-06-02T15:48:02



---

### 505. msg_16652

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T15:50:53

No I am not\. I know a lot of this is due to our distance\. I’m not naive\. If we could actually spend time together tonight we would sort this in like 5 minutes\.


---

### 506. msg_16653

**You** - 2025-06-02T15:51:28

>
I just thought this statement was going to lead
To something else


---

### 507. msg_16654

**You** - 2025-06-02T15:51:45

>
Agreed


---

### 508. msg_16655

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T15:52:41

>
No not at all\. I just feel bad\.


---

### 509. msg_16656

**You** - 2025-06-02T15:54:18

Well stop feeling bad you can’t change that this happened it was a mistake not intentional\. You can’t change the distance, or seeing each other at least not on a reg basis\.\. we agreed this next few months was going to be shit\.\. right it is what it is\.


---

### 510. msg_16657

**You** - 2025-06-02T15:55:05

I will likely not allow this to happen again\.  And perhaps if I see you going down this conversational road again\.\. I may gently nudge you away from it\.


---

### 511. msg_16658

**You** - 2025-06-02T15:56:36

>
And honestly if I was a big boy instead of an insecure got this shouldn’t have bothered me…\. That is on me


---

### 512. msg_16659

**You** - 2025-06-02T15:56:45

Insecure git


---

### 513. msg_16660

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:01:38

It is totally valid that it bothered you\. Seriously\.


---

### 514. msg_16661

**You** - 2025-06-02T16:02:27

It's fine\.\. I am just not going to look back tbh\.\. there is nothing there for me other than to be happy that you at one point pre Andrew seemed to have a really great time\.\. and there is nothing wrong with that\.


---

### 515. msg_16662

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:05:48

Ok but it wasn’t all good\. Just remember that\. If it was, I wouldn’t have left it\.


---

### 516. msg_16663

**You** - 2025-06-02T16:06:09

Sure\.\. I get it\.


---

### 517. msg_16664

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:35:49

Today has been exhausting\. I’ve had to explain my story 15x


---

### 518. msg_16665

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:35:59

😵‍💫😵‍💫😵‍💫


---

### 519. msg_16666

**You** - 2025-06-02T16:36:32

well


---

### 520. msg_16667

**You** - 2025-06-02T16:36:41

maybe just go to bed early\.\.


---

### 521. msg_16668

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:37:21

For sure bc I have to get up early to work out lol committed now


---

### 522. msg_16669

**You** - 2025-06-02T16:38:33

same\.\.  kk well I might not get to talk to you much\.\. I am getting fed up with people around here doing fuck all\.\. so I might go for a run at the gym\.


---

### 523. msg_16670

**You** - 2025-06-02T16:39:02

then get up tomorrow and do the same\.\. but I will go to my spot tomorrow\.\. I almost did today\.\. but traffic was bad\.\. and it was cold\.


---

### 524. msg_16671

**You** - 2025-06-02T16:39:13

I think I will tomorrow\.\. listen to my playlist and chill


---

### 525. msg_16672

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:39:19

I can meet you tomorrow


---

### 526. msg_16673

**You** - 2025-06-02T16:39:30

no you have you workout to do


---

### 527. msg_16674

**You** - 2025-06-02T16:39:37

I don't want to interrupt that


---

### 528. msg_16675

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:39:43

I will do it a bit earlier


---

### 529. msg_16676

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:39:55

First meeting is at 10


---

### 530. msg_16677

**You** - 2025-06-02T16:40:08

I don't want you to feel obligated\. You come first\.


---

### 531. msg_16678

**You** - 2025-06-02T16:40:20

Andrew will probably give you shit again as well


---

### 532. msg_16679

**You** - 2025-06-02T16:40:30

so might be hard to get out


---

### 533. msg_16680

**You** - 2025-06-02T16:42:29

>
yeah and I bet you and jim had some stuff to cover off lol\.


---

### 534. msg_16681

**You** - 2025-06-02T16:42:39

I started talking to him\.\. but I couldn't really do it\.


---

### 535. msg_16682

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:42:40

I didn’t get shit per se\. Just spurred some suspicion I think\.


---

### 536. msg_16683

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:43:04

>
We talked over lunch hour after our meeting\. :p


---

### 537. msg_16684

**You** - 2025-06-02T16:43:11

I kind of figured


---

### 538. msg_16685

**You** - 2025-06-02T16:43:54

I wasn't comfortable going to him with issues\.\. was awkward\.\. and I sorted it anyways\.\. I don't think I will be able to use him like I hoped\.


---

### 539. msg_16686

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:44:33

Maybe a therapist?


---

### 540. msg_16687

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T16:44:37

Just pick one


---

### 541. msg_16688

**You** - 2025-06-02T16:44:52

dunno\.\. doubt it would help to rehash shit I put in a box\./


---

### 542. msg_16689

**You** - 2025-06-02T16:44:59

too risky\.


---

### 543. msg_16690

**You** - 2025-06-02T16:52:21

well I messaged a therapist let's see what happens


---

### 544. msg_16691

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:06:50

So you didn’t do any house stuff today?


---

### 545. msg_16692

**You** - 2025-06-02T17:07:53

not nearly enough\.\. pool stuff though\.\. lots of that


---

### 546. msg_16693

**You** - 2025-06-02T17:08:04

I am meeting with Hugh my new therapist tomorrow\.


---

### 547. msg_16694

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:13:55

For real? I think that is great


---

### 548. msg_16695

**You** - 2025-06-02T17:14:23

yep we will see\.\. I will be meeting him in person\.\. could be good\.\. we will see\. I see him at noon\.


---

### 549. msg_16696

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:21:48

Wanna talk tonight or no?


---

### 550. msg_16697

**You** - 2025-06-02T17:22:11

when


---

### 551. msg_16698

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:22:13

I’m having a hard time reading how you are truly doing


---

### 552. msg_16699

**You** - 2025-06-02T17:22:48

>
you are still worried??  we can talk just depends on when\.\. if I go to the gym easier\.


---

### 553. msg_16700

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:23:19

Whenever honestly


---

### 554. msg_16701

**You** - 2025-06-02T17:23:41

but andrew


---

### 555. msg_16702

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:24:38

I will be quiet and he will probably be at volleyball with Maelle anyway


---

### 556. msg_16703

**You** - 2025-06-02T17:25:39

ok\.\. well I am probably going to the gym maybe around 7 or something\.  I can talk to you in car or whatever\.


---

### 557. msg_16704

**You** - 2025-06-02T17:26:24

you sound like you are still really upset


---

### 558. msg_16705

**You** - 2025-06-02T17:26:29

:\(


---

### 559. msg_16706

**You** - 2025-06-02T17:26:48

if we can actually see each other tomorrow\.\. I will make you feel better\.


---

### 560. msg_16707

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:28:56

I’m not upset\. Just leaving work


---

### 561. msg_16708

**You** - 2025-06-02T17:29:08

no but you "sound" upset anyways


---

### 562. msg_16709

**You** - 2025-06-02T17:29:11

you words etc/


---

### 563. msg_16710

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:41:20

Stuck in lobby with Michelle and Dana\. Omg


---

### 564. msg_16711

**You** - 2025-06-02T17:41:31

lol


---

### 565. msg_16712

**You** - 2025-06-02T17:41:36

You will never escape


---

### 566. msg_16713

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:45:48

Dana was very curious on “what happened” just like everyone else


---

### 567. msg_16714

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:46:00

Omg asked soooooo many times today


---

### 568. msg_16715

**You** - 2025-06-02T17:46:21

Yeah… but this will be it\.


---

### 569. msg_16716

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:46:48

Well probably tomorrow too but hopefully then it is done


---

### 570. msg_16717

**You** - 2025-06-02T17:48:46

Yep


---

### 571. msg_16718

**You** - 2025-06-02T17:49:03

So gonna eat and then work in garage for an hour then to gym


---

### 572. msg_16719

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:49:44

So Deanna is very unhappy fyi


---

### 573. msg_16720

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:50:05

She told me today and I didn’t ask


---

### 574. msg_16721

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:50:14

Remember fox told me that and I was skeptical


---

### 575. msg_16722

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:50:21

She is VERY unhappy


---

### 576. msg_16723

**You** - 2025-06-02T17:50:41

So she will be applying


---

### 577. msg_16724

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:51:00

No she never said that


---

### 578. msg_16725

**You** - 2025-06-02T17:52:09

Well I suspect she will


---

### 579. msg_16726

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T17:55:10

Maybe


---

### 580. msg_16727

**You** - 2025-06-02T17:55:36

Well she won’t get it


---

### 581. msg_16728

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:08:41

lol


---

### 582. msg_16729

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:09:14

I mean she is a hustler\. You gotta give her that at least


---

### 583. msg_16730

**You** - 2025-06-02T18:09:35

I do not have to give her anything I helped her get the promotion in the first place


---

### 584. msg_16731

**You** - 2025-06-02T18:09:46

She wa lbs going to reject it because she was pissed offf


---

### 585. msg_16732

**You** - 2025-06-02T18:10:05

I had to convince her to get out of her own way\.\. then she turned into a mini Johana\.


---

### 586. msg_16733

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:11:13

So I have to admit…\. I kind of felt deceptive today telling my story 15 million times to ppl


---

### 587. msg_16734

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:11:16

Ughhh


---

### 588. msg_16735

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:11:21

Was a weird day


---

### 589. msg_16736

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:11:40

I think I might nap when I get home


---

### 590. msg_16737

**You** - 2025-06-02T18:11:48

Well you will get to tell another story sometime down the road more than 15 times I suspect


---

### 591. msg_16738

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:12:07

🤯


---

### 592. msg_16739

**You** - 2025-06-02T18:12:23

Kk well I am still planning on going to the gym in or around 7 maybe 7:30


---

### 593. msg_16740

**You** - 2025-06-02T18:12:36

If that time doesn’t work to talk let me know


---

### 594. msg_16741

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:13:05

k almost home


---

### 595. msg_16742

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:13:28

Will assess the situation and see if I can nap lol


---

### 596. msg_16743

**You** - 2025-06-02T18:13:40

Kk I am just chilling for a bit\.\. go get your nap or whatever… yeah lol do that I guess


---

### 597. msg_16744

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:14:26

Omg talked to Alison for a while today


---

### 598. msg_16745

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:14:43

She made a sly “I guess you don’t want the system pruning job”


---

### 599. msg_16746

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:14:54

As if


---

### 600. msg_16747

**You** - 2025-06-02T18:15:51

ROFL


---

### 601. msg_16748

**You** - 2025-06-02T18:15:55

I told her no shot


---

### 602. msg_16749

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:17:56

So Diana said that origin all his girly friends were gossiping about what happens or may have happened to me in my role so imagine what the gossip would be like if we got out


---

### 603. msg_16750

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:18:03

\*dana


---

### 604. msg_16751

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:18:10

Dana said that ARJUN


---

### 605. msg_16752

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:18:24

“Arjun and all his girly friends”


---

### 606. msg_16753

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:18:29

lol


---

### 607. msg_16754

**You** - 2025-06-02T18:19:01

Hmm lol probably Scott’s a bastard


---

### 608. msg_16755

**You** - 2025-06-02T18:19:06

That fits


---

### 609. msg_16756

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:21:32

lol she was all “I just told them to read the quote at the bottom” and it just meant she chose to leave it in her own\. It wasn’t a demotion\. I think they thought you fired me lol


---

### 610. msg_16757

**You** - 2025-06-02T18:21:59

ROFL


---

### 611. msg_16758

**You** - 2025-06-02T18:22:04

Boy will they be surprised


---

### 612. msg_16759

**You** - 2025-06-02T18:22:27

There will unfortunately be a lot of abhhhhhhhhhhhs\.  Which again narrative


---

### 613. msg_16760

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:25:18

Oh my God, the gossip is gonna be brutal


---

### 614. msg_16761

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:25:26

I’m not sure I’ll be able to handle it


---

### 615. msg_16762

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:25:31

Today was nuts


---

### 616. msg_16763

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:25:49

I have a brutal headache and had no Tylenol at work so I’m going to take a Tylenol right now and go and have a nap


---

### 617. msg_16764

**You** - 2025-06-02T18:26:16

Let’s tell people when our freedom to be together is a bit more definitive so I can actually help you and you me not like the shit we deal with right now


---

### 618. msg_16765

**You** - 2025-06-02T18:26:28

Ok you go do that will head out in about an hour


---

### 619. msg_16766

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:29:36

>
Yeah I wouldn’t be able to handle it right now


---

### 620. msg_16767

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:29:48

We would actually need to be like together together I think


---

### 621. msg_16768

**You** - 2025-06-02T18:29:49

Same


---

### 622. msg_16769

**You** - 2025-06-02T18:29:58

That would be a long time mer


---

### 623. msg_16770

**You** - 2025-06-02T18:30:09

But your call


---

### 624. msg_16771

**You** - 2025-06-02T18:30:23

Like years unless you have a plan


---

### 625. msg_16772

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:31:29

I do not have a plan at all :\(


---

### 626. msg_16773

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:31:47

All I know is if today was weird, explaining us would be too much


---

### 627. msg_16774

**You** - 2025-06-02T18:31:54

So the we will have to agree to never tell anyone at work\.\. I think only way


---

### 628. msg_16775

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:32:15

Sold\. Deal\.


---

### 629. msg_16776

**You** - 2025-06-02T18:33:24

lol you won’t be happy like that\.\. We can talk about this later\.\. I think she you understand what is ahead of us before we can “be together” you might not be up for this\.\. lol


---

### 630. msg_16777

**You** - 2025-06-02T18:33:39

She is supposed to be once


---

### 631. msg_16778

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:35:37

I have a different pov after today


---

### 632. msg_16779

**You** - 2025-06-02T18:35:59

I am not sure what that means but not sure it is good lol


---

### 633. msg_16780

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:36:46

It means I forgot how gossipy people are


---

### 634. msg_16781

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:37:02

Do you know how many times I was asked what happened?


---

### 635. msg_16782

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:37:11

At least 10


---

### 636. msg_16783

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:37:43

Even neeti who I never talk to


---

### 637. msg_16784

**You** - 2025-06-02T18:38:44

lol


---

### 638. msg_16785

**You** - 2025-06-02T18:38:53

Oh you have a different pov about work


---

### 639. msg_16786

**You** - 2025-06-02T18:39:13

>
I was talking about this more
Of an absolute be together us statement


---

### 640. msg_16787

**You** - 2025-06-02T18:39:30

I think you will get tired of the challenges eventually too much of a pain in the ass


---

### 641. msg_16788

**You** - 2025-06-02T18:39:43

And don’t tell me to stop


---

### 642. msg_16789

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:40:49

Once I have a separation agreement signed my family will know \(the truth, not some weird version\) and that is all I will really care about\.


---

### 643. msg_16790

**You** - 2025-06-02T18:41:20

Well mine will have a wierd version for a bit for the sake of
My sanity but it will be real as soon as I can make it happen


---

### 644. msg_16791

**You** - 2025-06-02T18:41:34

I am not sure how that relates to what I said but ok\.\.


---

### 645. msg_16792

**You** - 2025-06-02T18:41:37

lol


---

### 646. msg_16793

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:42:56

>
Obviously, I misunderstanding what you said read back I don’t think you were clear


---

### 647. msg_16794

**You** - 2025-06-02T18:43:35

I said you are
Going to want to “be” with someone and that won’t be me for a very long time I think\.\. not sure that is something you would want to endure\.


---

### 648. msg_16795

**You** - 2025-06-02T18:43:45

Like I said we can discuss later you can sleep


---

### 649. msg_16796

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:45:14

>
This isn’t exactly what you said but ok\. I mean if you continue to not tell your family for years and we have to sneak around for years then yeah, I probably am not ok with that\. Otherwise, I’m good\.


---

### 650. msg_16797

**You** - 2025-06-02T18:45:33

Still not what I meant we\. Nah gerd


---

### 651. msg_16798

**You** - 2025-06-02T18:45:38

I am telling them


---

### 652. msg_16799

**You** - 2025-06-02T18:45:41

Likely this year


---

### 653. msg_16800

**You** - 2025-06-02T18:45:45

Late
Fall


---

### 654. msg_16801

**You** - 2025-06-02T18:45:46

Prolly


---

### 655. msg_16802

**You** - 2025-06-02T18:45:53

But I meant living with you


---

### 656. msg_16803

**You** - 2025-06-02T18:46:03

Wow words meaning hard


---

### 657. msg_16804

**You** - 2025-06-02T18:46:08

lol I suck aoparently


---

### 658. msg_16805

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:46:31

Ohhh I did not know that is what you meant


---

### 659. msg_16806

**You** - 2025-06-02T18:46:44

That is what I meant


---

### 660. msg_16807

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:46:59

We don’t need to live together as long as we don’t need to sneak around


---

### 661. msg_16808

**You** - 2025-06-02T18:47:10

>
This is what I meant


---

### 662. msg_16809

**You** - 2025-06-02T18:47:20

I thought freedom to be together was living together


---

### 663. msg_16810

**You** - 2025-06-02T18:47:29

And living together seems like sooooo far away


---

### 664. msg_16811

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:47:34

>
In what world do those two things mean the same thing?


---

### 665. msg_16812

**You** - 2025-06-02T18:47:40

We will be in 50’s


---

### 666. msg_16813

**You** - 2025-06-02T18:47:49

I thought be together


---

### 667. msg_16814

**You** - 2025-06-02T18:47:53

Was just that


---

### 668. msg_16815

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:48:19

Listen, I haven’t thought about timing on living together and quite frankly I’m really busy with three girls so haven’t even really thought about where I stand on that I more hate the sneaking around


---

### 669. msg_16816

**You** - 2025-06-02T18:49:33

lol ok you have your priorities\.\. so I know what I have to do sooner than later somehow


---

### 670. msg_16817

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:51:23

You don’t have to do anything “sooner”\.


---

### 671. msg_16818

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:51:41

I’m just saying that is a higher priority to me than living together\.


---

### 672. msg_16819

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:51:52

Doesn’t need to be soon


---

### 673. msg_16820

**You** - 2025-06-02T18:51:57

Well it is clearly
First yeah and it does\.\.


---

### 674. msg_16821

**You** - 2025-06-02T18:52:18

Like I said I think give it a few months into fall and I will mention something


---

### 675. msg_16822

**You** - 2025-06-02T18:52:38

It will likely
Come up before then I will challenge me and I will just admit that our intention is to have a relationship


---

### 676. msg_16823

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:53:32

Just wait until I tell Andrew and do it then\. :\) And what will change do you think?


---

### 677. msg_16824

**You** - 2025-06-02T18:58:29

Nothing


---

### 678. msg_16825

**You** - 2025-06-02T18:58:53

If I tell her before I have my separation or before she leaves it would be a shitstorm


---

### 679. msg_16826

**You** - 2025-06-02T18:59:03

Kk go to sleep or you won’t be able to talk to me later


---

### 680. msg_16827

**You** - 2025-06-02T18:59:13

Or get up in morning for park


---

### 681. msg_16828

**You** - 2025-06-02T18:59:29

That is more important and we can actually chat about this topic later if
You want


---

### 682. msg_16829

**You** - 2025-06-02T18:59:40

Ok working then gym cya\. ❤️


---

### 683. msg_16830

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T18:59:58

❤️


---

### 684. msg_16831

**You** - 2025-06-02T20:06:35

You still sleeping?


---

### 685. msg_16832

**You** - 2025-06-02T20:14:53

I guess not yet\.\. driving to gym now


---

### 686. msg_16833

**You** - 2025-06-02T20:26:17

Kk well
Even if
We don’t get
To talk tonight and you cannot see me with your eyes don’t worry you are clearly tired\.  More important\.


---

### 687. msg_16834

**You** - 2025-06-02T20:43:12

If you do actually get on here I am running so if you want to chat just call me\.


---

### 688. msg_16835

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T21:26:14

lol just woke up


---

### 689. msg_16836

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T21:26:45

But kind of want to just get seriously ready for bed and go to bed


---

### 690. msg_16837

**You** - 2025-06-02T22:20:31

ok well I guess I am going to bed too\.\. have a good night\.\. luv u\.


---

### 691. msg_16838

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T22:21:27

I’m actually still up but we should go to bed\. Early morning


---

### 692. msg_16839

**You** - 2025-06-02T22:22:49

Yeah I am just packing my shit up and going to sleep\.


---

### 693. msg_16840

**Meredith Lamb \(\+14169386001\)** - 2025-06-02T22:27:27

k, nite \- c u tomorrow ❤️❤️


---

### 694. msg_16841

**You** - 2025-06-02T22:28:01

Nite ❤️❤️


---

### 695. msg_16842

**You** - 2025-06-03T04:30:00

Good morning love\.\. I know you are likely still exhausted from yesterday\.\. and if it is a choice between the workout or me\.\. please pick the workout\.\. I know you want to get back in it and I don’t want to be a barrier\.


---

### 696. msg_16843

**You** - 2025-06-03T04:32:32

Reaction: ❤️ from Meredith Lamb
I am just getting ready to head out\.  But I will likely be at the park between 7:45 and 8\.  Again if you cannot make it do not worry\.  I love seeing you but not at
The expense of you sacrificing something else\.  I love you and hope you have a good morning\.


---

### 697. msg_16844

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T05:36:23

I will make it but ahana booked a meeting for 9\.35am with Carolyn and I\. :p


---

### 698. msg_16845

**You** - 2025-06-03T06:25:53

Don’t worry about it\.


---

### 699. msg_16846

**You** - 2025-06-03T06:25:56

Too rushed


---

### 700. msg_16847

**You** - 2025-06-03T06:27:55

Can do some other time\.


---

### 701. msg_16848

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T06:31:30

Working out until 6\.45\. Get ready 6\.45\-7\.15\. Leave 7\.15\. Arrive 7\.45\. It will be fine


---

### 702. msg_16849

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T06:31:48

My workouts aren’t long yet\. Trying to just get muscle memory back first


---

### 703. msg_16850

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T06:31:51

This week


---

### 704. msg_16851

**You** - 2025-06-03T06:35:44

Kk well if you make it I very much look forward to seeing you\. Got a couple of things I want to give you ❤️


---

### 705. msg_16852

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T07:15:34

I’m actually on time\. Weird\. Leaving now\.


---

### 706. msg_16853

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T07:17:11

Should be there at 7\.45 unless traffic


---

### 707. msg_16854

**You** - 2025-06-03T07:21:30

Might be 5 mins late traffic


---

### 708. msg_16855

**You** - 2025-06-03T07:21:33

Will see


---

### 709. msg_16856

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T07:35:18

Terraview?


---

### 710. msg_16857

**You** - 2025-06-03T07:37:14

Yeah


---

### 711. msg_16858

**You** - 2025-06-03T07:37:26

By pharmacy


---

### 712. msg_16859

**You** - 2025-06-03T07:44:26

I am parked on or worth road


---

### 713. msg_16860

**You** - 2025-06-03T07:44:37

On penworth


---

### 714. msg_16861

**You** - 2025-06-03T09:08:41

Reaction: ❤️ from Meredith Lamb
Thank you for that this morning… I don’t need reassurance any more that we have a future or that you love me I just like being with you\.  So thanks for hanging out\.


---

### 715. msg_16862

**You** - 2025-06-03T09:10:09

And re C yeah he is your friend and as I understand a good one\.\. if you ever want me to meet him I would be happy to\.


---

### 716. msg_16863

**You** - 2025-06-03T09:10:55

You were right I was wrong I need to trust you and I do\.\. it has always been hard though after my history\.


---

### 717. msg_16864

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T09:20:33

I had a nice time 😍


---

### 718. msg_16865

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T09:21:23

Reaction: ❤️ from Scott Hicks
In the car I was thinking “why on earth would my kids not like him?” I couldn’t think of any reason why :\)


---

### 719. msg_16866

**You** - 2025-06-03T13:15:46

That was “interesting”\. Will tell you about it later


---

### 720. msg_16867

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:17:15

Network down\. Can’t work


---

### 721. msg_16868

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:17:23

No teams, outlook\. Nadia


---

### 722. msg_16869

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:17:26

Nadda


---

### 723. msg_16870

**You** - 2025-06-03T13:17:31

Wow\.\.


---

### 724. msg_16871

**You** - 2025-06-03T13:17:40

That sucks


---

### 725. msg_16872

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:18:52

Whitney is waiting to be told to go home


---

### 726. msg_16873

**You** - 2025-06-03T13:19:11

Send her


---

### 727. msg_16874

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:28:22

It came back


---

### 728. msg_16875

**You** - 2025-06-03T13:29:43

lol it always does


---

### 729. msg_16876

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:33:12

>
What was interesting?


---

### 730. msg_16877

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:33:21

That came out of nowhere


---

### 731. msg_16878

**You** - 2025-06-03T13:34:37

My session


---

### 732. msg_16879

**You** - 2025-06-03T13:34:49

With therapist


---

### 733. msg_16880

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:34:55

Omg I forgot\!\!


---

### 734. msg_16881

**You** - 2025-06-03T13:35:04

Yeah I know yah did\.\. psssh


---

### 735. msg_16882

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:35:17

🙈


---

### 736. msg_16883

**You** - 2025-06-03T13:35:24

Reaction: 😢 from Meredith Lamb
It’s ok I just won’t tell you all the good parts


---

### 737. msg_16884

**You** - 2025-06-03T13:35:52

Kk just dropped a load at value village
Going back home to keep going\.


---

### 738. msg_16885

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T13:36:42

kk


---

### 739. msg_16886

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:11:44

So am I ever going to hear anything that was “interesting” or do you have to tell me on video


---

### 740. msg_16887

**You** - 2025-06-03T15:12:10

I don't know I doubt video will happen\.\. you always fall asleep\.\. so yeah\.\. video\.


---

### 741. msg_16888

**You** - 2025-06-03T15:12:11

:\)


---

### 742. msg_16889

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:12:58

I probably will again lol


---

### 743. msg_16890

**You** - 2025-06-03T15:13:18

yeah sucks\.\. I guess


---

### 744. msg_16891

**You** - 2025-06-03T15:15:43

Maybe once you have caught up on your sleep\.


---

### 745. msg_16892

**You** - 2025-06-03T15:17:04

We did spend most of the time talking about you\.\. just as an fyi\.


---

### 746. msg_16893

**You** - 2025-06-03T15:17:22

I have to go get ready to go, heading back out again\.  Maybe chat later\.\. we'll see\.


---

### 747. msg_16894

**You** - 2025-06-03T15:17:30

Love you\.


---

### 748. msg_16895

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:21:19

I actually might not fall asleep tonight\. Not feeling as tired\. FYI xoxo


---

### 749. msg_16896

**You** - 2025-06-03T15:21:52

lol we will see\.\.


---

### 750. msg_16897

**You** - 2025-06-03T15:22:10

I have heard that before and I know how that story typically ends


---

### 751. msg_16898

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:22:35

I blame the role in YOUR group\. :p


---

### 752. msg_16899

**You** - 2025-06-03T15:22:50

Mmmm ok if you want to\.\.


---

### 753. msg_16900

**You** - 2025-06-03T15:23:12

I mean how am I functioning then


---

### 754. msg_16901

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:25:28

You are crazy, that’s how\. 🤪


---

### 755. msg_16902

**You** - 2025-06-03T15:27:58

I mean I deal with work\.\. I deal with home\.\.
Then there is you… lol❤️


---

### 756. msg_16903

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:29:41

lol accurate


---

### 757. msg_16904

**You** - 2025-06-03T15:32:28

Off the record here


---

### 758. msg_16905

**You** - 2025-06-03T15:32:33

There has been an increase over the last year of downward career movements that were not occurring frequently before\. What is causing this and is it viewed as a concerning trend?


---

### 759. msg_16906

**You** - 2025-06-03T15:33:10

This question was posted for the tow hall next week\.\. you aren’t supposed
To know\.


---

### 760. msg_16907

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:34:55

Why am I not supposed to know?


---

### 761. msg_16908

**You** - 2025-06-03T15:35:19

Because  I one except managers know the questions


---

### 762. msg_16909

**You** - 2025-06-03T15:35:27

No


---

### 763. msg_16910

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:35:46

Are they not going to address the question?


---

### 764. msg_16911

**You** - 2025-06-03T15:36:00

Someone will it is relatively easy to answer


---

### 765. msg_16912

**You** - 2025-06-03T15:36:04

There is no trend


---

### 766. msg_16913

**You** - 2025-06-03T15:36:12

Each situation is unique and it is their choice


---

### 767. msg_16914

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:36:12

I was going to say that


---

### 768. msg_16915

**You** - 2025-06-03T15:36:18

Done


---

### 769. msg_16916

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:36:19

Yeah


---

### 770. msg_16917

**You** - 2025-06-03T15:36:30

Still I wanted you to not be surprised


---

### 771. msg_16918

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:37:17

Given my day yesterday I wouldn’t have been surprised\. Everyone was pretty shocked\.


---

### 772. msg_16919

**You** - 2025-06-03T15:39:22

ROFL


---

### 773. msg_16920

**You** - 2025-06-03T15:39:28

Too cheesy not saying that


---

### 774. msg_16921

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:40:05

:p no clue what you are talking about sometimes


---

### 775. msg_16922

**You** - 2025-06-03T15:40:14

Cause my brain is bent


---

### 776. msg_16923

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:40:39

Did Hugh tell you that?


---

### 777. msg_16924

**You** - 2025-06-03T15:41:01

No he said… ohhhh hahahah… no you didn’t even come close to getting me


---

### 778. msg_16925

**You** - 2025-06-03T15:41:09

😝


---

### 779. msg_16926

**You** - 2025-06-03T15:45:36

Ok I am heading out again I am sure we might talk later if you aren’t sleeping


---

### 780. msg_16927

**You** - 2025-06-03T15:46:02

Maybe…\. Not overly confident \.\. cya


---

### 781. msg_16928

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:46:43


*1 attachment(s)*


---

### 782. msg_16929

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:46:46

Be more optimistic


---

### 783. msg_16930

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:47:01

\(The griffin emoji was an accident\) lol


---

### 784. msg_16931

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:47:06

It is cute tho


---

### 785. msg_16932

**You** - 2025-06-03T15:47:27



---

### 786. msg_16933

**You** - 2025-06-03T15:47:58


*1 attachment(s)*


---

### 787. msg_16934

**You** - 2025-06-03T15:48:04

Be more awake


---

### 788. msg_16935

**You** - 2025-06-03T15:48:22

Again\. Love you laters\.


---

### 789. msg_16936

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T15:49:11

Love u


---

### 790. msg_16937

**You** - 2025-06-03T16:25:44

Hey what was the site


---

### 791. msg_16938

**You** - 2025-06-03T16:25:48

For selling earrings


---

### 792. msg_16939

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T16:30:57

Poshmark


---

### 793. msg_16940

**You** - 2025-06-03T16:34:01

Thx


---

### 794. msg_16941

**You** - 2025-06-03T17:10:52

Cooking super for everyone then goi g to gym eventually


---

### 795. msg_16942

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T17:13:47

Gym rat\.


---

### 796. msg_16943

**You** - 2025-06-03T17:14:26

Escape


---

### 797. msg_16944

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T17:15:06

Did you know that if we didn’t need to worry about being outed at work we could go to a Dave Matthews band concert in July\. But work ppl will be there for sure


---

### 798. msg_16945

**You** - 2025-06-03T17:21:21

lol


---

### 799. msg_16946

**You** - 2025-06-03T17:21:23

Would be fun


---

### 800. msg_16947

**You** - 2025-06-03T17:21:29

But yeah not till she is gone


---

### 801. msg_16948

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T17:29:08

Even after that at work, seriously not dealing with the goss lol


---

### 802. msg_16949

**You** - 2025-06-03T17:58:16

I know I will never look at you as we pass each other in the halls\.\.


---

### 803. msg_16950

**You** - 2025-06-03T17:58:32

Two hearts forever destined to pass in the night\.\. and never connect\.\.


---

### 804. msg_16951

**You** - 2025-06-03T17:58:45

🧀


---

### 805. msg_16952

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:00:35

lol


---

### 806. msg_16953

**You** - 2025-06-03T18:34:26

sitting down to eat\.\. then not sure what I am doing\.\. J and I had another fight\.\. same shit different day\.\. nothing overly serious though\.


---

### 807. msg_16954

**You** - 2025-06-03T18:49:43

ah you must be sleeping again\.\. I forgot it is 645 ish\. that is the new nap time / bed time lol


---

### 808. msg_16955

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:55:11

I’m making soup\!


---

### 809. msg_16956

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:55:13

Stop


---

### 810. msg_16957

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:55:15

lol


---

### 811. msg_16958

**You** - 2025-06-03T18:55:22

sleep cooking


---

### 812. msg_16959

**You** - 2025-06-03T18:55:28

it happens\.\. it is common\.


---

### 813. msg_16960

**You** - 2025-06-03T18:55:45

especially cooking soup, there have been studies


---

### 814. msg_16961

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:55:56

🙄


---

### 815. msg_16962

**You** - 2025-06-03T18:56:20

🙄


---

### 816. msg_16963

**You** - 2025-06-03T18:56:25

I can do that too


---

### 817. msg_16964

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:57:50

Not as well


---

### 818. msg_16965

**You** - 2025-06-03T18:57:58

I feel like it looks the same


---

### 819. msg_16966

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:58:15

Mine has more feeling


---

### 820. msg_16967

**You** - 2025-06-03T18:58:19

LOL


---

### 821. msg_16968

**You** - 2025-06-03T18:58:22

between the two of us


---

### 822. msg_16969

**You** - 2025-06-03T18:58:26

we know that isn't true


---

### 823. msg_16970

**You** - 2025-06-03T18:58:34

😝


---

### 824. msg_16971

**You** - 2025-06-03T18:58:39

I have so many more feelings\.


---

### 825. msg_16972

**You** - 2025-06-03T18:59:00

Hugh said so


---

### 826. msg_16973

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:59:02

That isn’t true\. You have more chaos in your head\. Doesn’t equal more feeling per se


---

### 827. msg_16974

**You** - 2025-06-03T18:59:05

nope


---

### 828. msg_16975

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T18:59:21

Aren’t you supposed to be eating?


---

### 829. msg_16976

**You** - 2025-06-03T18:59:30

Hugh said it was pretty clear that I am literally on fire after 30 years of being snuffed out\.


---

### 830. msg_16977

**You** - 2025-06-03T18:59:36

I ate


---

### 831. msg_16978

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:00:01

>
Really? Didn’t Jim say that?


---

### 832. msg_16979

**You** - 2025-06-03T19:00:09

I think he feels bad for you


---

### 833. msg_16980

**You** - 2025-06-03T19:00:15

not sure what jim said


---

### 834. msg_16981

**You** - 2025-06-03T19:00:27

I booked Hugh every week until end of july


---

### 835. msg_16982

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:00:45

Well I’m glad it went well


---

### 836. msg_16983

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:00:56

He feels bad for me because you are on fire?


---

### 837. msg_16984

**You** - 2025-06-03T19:01:14

Yep it was great\.\. we went way over time\.\. he didn't seem to care\.\. I was just telling stories\.\. pretty sure I hooked him in\.


---

### 838. msg_16985

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:01:28

lol


---

### 839. msg_16986

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:01:43

I never go over


---

### 840. msg_16987

**You** - 2025-06-03T19:02:02

He started a bit late\.\. and then we went a little over\.\. and he just kept going


---

### 841. msg_16988

**You** - 2025-06-03T19:02:18

there is just SO much to fix


---

### 842. msg_16989

**You** - 2025-06-03T19:02:23

therapists dream


---

### 843. msg_16990

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:02:47

Really wow


---

### 844. msg_16991

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:03:00

I don’t think you need FIXING\.


---

### 845. msg_16992

**You** - 2025-06-03T19:03:14

yes I do\.\. I will be far better after


---

### 846. msg_16993

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:03:18

It is more just talking and getting some feedback


---

### 847. msg_16994

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:03:26

Perspective from someone else


---

### 848. msg_16995

**You** - 2025-06-03T19:03:44

Less dependent\.\. more flexible\.\. less plan focused\.\.


---

### 849. msg_16996

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:04:20

Is being plan focused a bad thing?


---

### 850. msg_16997

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:04:26

Some ppl like to plan


---

### 851. msg_16998

**You** - 2025-06-03T19:05:04

https://open\.spotify\.com/track/0GVuLQtPXFaL18ijEOqoAa?si=b939a16ad02c45a2


---

### 852. msg_16999

**You** - 2025-06-03T19:05:15

words\.\.


---

### 853. msg_17000

**You** - 2025-06-03T19:05:41

I have added this to my list of things to accomplish \- right next to the picture of Henry Caville coming out of the ocean\.


---

### 854. msg_17001

**You** - 2025-06-03T19:05:57

this is what you want


---

### 855. msg_17002

**You** - 2025-06-03T19:05:59

this is Open\.\.


---

### 856. msg_17003

**You** - 2025-06-03T19:06:24

and I want to do this 😊


---

### 857. msg_17004

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:08:19

Read the words


---

### 858. msg_17005

**You** - 2025-06-03T19:08:23

I think future discussions are going to help me out here\.


---

### 859. msg_17006

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:08:29

Never really read them before


---

### 860. msg_17007

**You** - 2025-06-03T19:08:48

I mean I liked it when I first listened to it\.\. but then the words meant something\.\. more recently\.


---

### 861. msg_17008

**You** - 2025-06-03T19:08:52

I felt it was apt\.\.


---

### 862. msg_17009

**You** - 2025-06-03T19:09:35

anyhow even if that doesn't align up with your vision of Open\.\. there has to be enough crossover that we can make it work\.\. I just need something to shoot for\.


---

### 863. msg_17010

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:09:54

>
Did you talk about this today? How hyper focused you are on this? LOO


---

### 864. msg_17011

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:09:57

LOL


---

### 865. msg_17012

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:10:07

did he diagnose you with ocd


---

### 866. msg_17013

**You** - 2025-06-03T19:10:09

We talked about it\.\. but remember\.\. no specifics\.\. verbal only\.\. sorry\.


---

### 867. msg_17014

**You** - 2025-06-03T19:10:15

no\.\.


---

### 868. msg_17015

**You** - 2025-06-03T19:10:17

he validated me


---

### 869. msg_17016

**You** - 2025-06-03T19:10:31

we framed it up


---

### 870. msg_17017

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:10:35

Ok good


---

### 871. msg_17018

**You** - 2025-06-03T19:10:36

bounced the situation back and forth


---

### 872. msg_17019

**You** - 2025-06-03T19:11:01

but recognize that the problem isn't C\.\. the problem is my history\.


---

### 873. msg_17020

**You** - 2025-06-03T19:11:11

J had no past\.\. there was one guy then me\.


---

### 874. msg_17021

**You** - 2025-06-03T19:11:21

So all of the trust issues I had previously


---

### 875. msg_17022

**You** - 2025-06-03T19:11:26

didn't matter\.


---

### 876. msg_17023

**You** - 2025-06-03T19:11:34

He said I have never dealt with those


---

### 877. msg_17024

**You** - 2025-06-03T19:12:12

He believed everything I said about us\.\. had a chuckle about how I presented the story\.\. I think we connected well\.


---

### 878. msg_17025

**You** - 2025-06-03T19:12:25

ok\.\. no more


---

### 879. msg_17026

**You** - 2025-06-03T19:12:27

not a word\.


---

### 880. msg_17027

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:12:34

What? Why?


---

### 881. msg_17028

**You** - 2025-06-03T19:12:46

because I told you\.\. it is a chat conversation\.


---

### 882. msg_17029

**You** - 2025-06-03T19:12:57

I am going to the gym soon and I don't want to type all night again\.


---

### 883. msg_17030

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:12:59

Then call


---

### 884. msg_17031

**You** - 2025-06-03T19:13:14

let me pack my shit up\.


---

### 885. msg_17032

**You** - 2025-06-03T19:13:21

5 mins


---

### 886. msg_17033

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:13:30

k


---

### 887. msg_17034

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T19:27:05

Just watching handmaids tale finale\. You can call whenever


---

### 888. msg_17035

**You** - 2025-06-03T22:21:43

Forgot to tell you most importantly Hugh said I was damn luck to find someone the way I described you and how I described my feelings\.  Most people don’t… and some do but don’t recognize it\. While he did suggest stopping it was only from the perspective of trying to make it easier\.  Thought that might make you feel a bit better… Love you xoxo🥰\. Have a good sleep\. ❤️\. All of these stupid what if conversations will be meaningless in the not to distant future\.\. I am hopeful\.  Nite\.


---

### 889. msg_17036

**Meredith Lamb \(\+14169386001\)** - 2025-06-03T22:24:34

Reaction: ❤️ from Scott Hicks
I feel lucky too\. ❤️ since I started working for you I’ve always admired you and would never in a million years have imagined we are where we are… nite xo


---

### 890. msg_17037

**You** - 2025-06-04T04:29:50

lol u know I always thought admired was an odd word to choose\.  Kind of like saying someone has a nice personality for lack of a better reference to call out\.  But I have to say in all honesty I admire you tremendously more so the more I learn about you and your life\.  You have maximized what life has to offer for all those around you and just made it “better”\. For Andrew to call you selfish is such an injustice because to me you are selfless\.  You have lived your life not only for yourself but both for those most important to you, as well as others not so close, always willing to give your time, help, support etc\.  So odd word or not Mer I admire you so much, it makes me want to be more like you in some ways\.  And I never thought I would be lucky enough to be in a relationship with someone like you\.


---

### 891. msg_17038

**You** - 2025-06-04T04:31:34

I am up and going to crush it\. One
More cycle down will have to see if status photo update is worth it today or not\.  Love you\!\!\!\!


---

### 892. msg_17039

**You** - 2025-06-04T04:32:02

Btw me wanting to be away from you at work is natural it is an out of site out of mind thing\.\. nothing g more\.


---

### 893. msg_17040

**You** - 2025-06-04T04:33:39

Additionally please think about what I suggested re verbalizing\.  This would be very uncomfortable for me too\.  But I think it might be worth trying perhaps\.\. we can always turf it if we want\.  I mean it could be a while until we get the opportunity so maybe take some
Time to think on it\.


---

### 894. msg_17041

**You** - 2025-06-04T05:44:50

Gl with your workout this morning\.


---

### 895. msg_17042

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:19:30

>
Well it is the right word\. I’m more talking about your brain and work style with that comment but also the way everyone went to you for advice, help etc\.
I am just getting up because I’m going to sleep a bit longer on wfh days I’ve decided\. lol


---

### 896. msg_17043

**You** - 2025-06-04T06:20:50

Rofl I get that sleep\.\. love you chat later just in the middle of a set\.\.


---

### 897. msg_17044

**You** - 2025-06-04T06:22:46

Whatever it was you noticed about me I am just glad you did\.


---

### 898. msg_17045

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:30:56

k, slept until 6\.30\. NOW I am getting up :\)


---

### 899. msg_17046

**You** - 2025-06-04T06:31:11

ROFL


---

### 900. msg_17047

**You** - 2025-06-04T06:31:16

❤️


---

### 901. msg_17048

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:31:35

Reaction: 🫠 from Scott Hicks
>
I noticed lots of things\. I can list them out for you sometime later\. Lol


---

### 902. msg_17049

**You** - 2025-06-04T06:32:41

So did I


---

### 903. msg_17050

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:33:14

My sister has been oddly silent to me lately\. Now I know why\. I actually don’t think I told her about you bc she has been leaving me alone\. No drunken messaging\. lol

*1 attachment(s)*


---

### 904. msg_17051

**You** - 2025-06-04T06:34:16

ROFL i think you told me yoj dodnt plan on telling her at one point


---

### 905. msg_17052

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:34:50

Haha eventually but yeah we can be a drunk mess together sometimes


---

### 906. msg_17053

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:35:19

So if we are chatting while drinking … well, things come out inevitably


---

### 907. msg_17054

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:35:22

lol


---

### 908. msg_17055

**You** - 2025-06-04T06:37:04

Will look forward to seeing that sometime\.


---

### 909. msg_17056

**You** - 2025-06-04T06:40:50

If I give
You An update
Photo I want one back


---

### 910. msg_17057

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:44:02

So I was a bitch this morning bc I have no idea what time Andrew got home\.


---

### 911. msg_17058

**You** - 2025-06-04T06:44:21

???


---

### 912. msg_17059

**You** - 2025-06-04T06:44:35

I thought you gave zero shits lol


---

### 913. msg_17060

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:45:51

I do however if he is doing something, it is annoying that it is taking into taxes time\.


---

### 914. msg_17061

**You** - 2025-06-04T06:46:16

That is more than fair


---

### 915. msg_17062

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:46:23

Me: where were you last night?


---

### 916. msg_17063

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:46:28

Him: no response


---

### 917. msg_17064

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:46:30

lol


---

### 918. msg_17065

**You** - 2025-06-04T06:46:34

Rofl


---

### 919. msg_17066

**You** - 2025-06-04T06:46:38

Interesting


---

### 920. msg_17067

**You** - 2025-06-04T06:46:46

Check your ring


---

### 921. msg_17068

**You** - 2025-06-04T06:46:49

It will tell you


---

### 922. msg_17069

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:46:51

So i let dogs out and go ANDREW


---

### 923. msg_17070

**You** - 2025-06-04T06:46:51

What time


---

### 924. msg_17071

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:47:24

He sighed “I had a conference yday and then a happy hour thing and then 4 of us went out drinking”


---

### 925. msg_17072

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:47:30

That’s all I got\. Lol


---

### 926. msg_17073

**You** - 2025-06-04T06:47:41

lol ok


---

### 927. msg_17074

**You** - 2025-06-04T06:47:49

Sounds like a safe story


---

### 928. msg_17075

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:48:26

Haha totally


---

### 929. msg_17076

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:49:00

Checked ring


---

### 930. msg_17077

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:49:05

He came home at 3am


---

### 931. msg_17078

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:49:21

So this will make me life easier as long as he gets the taxes done


---

### 932. msg_17079

**You** - 2025-06-04T06:49:36

Rofl


---

### 933. msg_17080

**You** - 2025-06-04T06:49:49

Sounds like more than drinking


---

### 934. msg_17081

**You** - 2025-06-04T06:49:54

Since he apparently doesnt


---

### 935. msg_17082

**You** - 2025-06-04T06:49:55

lol


---

### 936. msg_17083

**You** - 2025-06-04T06:50:34

Maybe Let’s not tit for tat today


---

### 937. msg_17084

**You** - 2025-06-04T06:50:37

Though


---

### 938. msg_17085

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:51:31


*1 attachment(s)*


---

### 939. msg_17086

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:51:43

lol


---

### 940. msg_17087

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:51:53

I think I will keep the screenshot for the future tho


---

### 941. msg_17088

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:52:08

I’m stupid bc I wouldn’t have checked if you didn’t say to lol


---

### 942. msg_17089

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:52:10

Dumb


---

### 943. msg_17090

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:52:13

Having coffee


---

### 944. msg_17091

**You** - 2025-06-04T06:52:39

lol hope this doesn’t affect your day too much


---

### 945. msg_17092

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:53:06

I really don’t care I just need taxes done\. I was looking at rentals yday but have no clue what the f I can do


---

### 946. msg_17093

**You** - 2025-06-04T06:53:56

Yeah I get your frustration\.\. not sure what your day is like but if you want to chat later on comp I can since it is well I guess the second last day you work
For me lol


---

### 947. msg_17094

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:54:44

I think my day is nuts but not 100%\. I always have time tho


---

### 948. msg_17095

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:54:56

Soon I will have nooooooooo meetings lol


---

### 949. msg_17096

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:55:05

Going to be so weird


---

### 950. msg_17097

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:55:20

I will get to actually work again


---

### 951. msg_17098

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:55:55

https://open\.spotify\.com/track/0qmhTHMVxnXRmT5N92wTD9?si=\-\_X1VWFFQzSn\-2\_ZvYQITw
I can’t stop listening to this song the last few days


---

### 952. msg_17099

**You** - 2025-06-04T06:56:19

Guessing I am not getting a status shot booo


---

### 953. msg_17100

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:58:15

I will later\. I’m taking photos everyday


---

### 954. msg_17101

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:58:21

It’s just part of what I do


---

### 955. msg_17102

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:58:33

I haven’t started yet\! Late today


---

### 956. msg_17103

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:58:41

Still drinking coffee and writing


---

### 957. msg_17104

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T06:59:14

Ps\. I told Ehsan yday


---

### 958. msg_17105

**You** - 2025-06-04T07:00:11

What did he say


---

### 959. msg_17106

**You** - 2025-06-04T07:00:18

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 960. msg_17107

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:00:43

Same old\. Sorry\. Sounds like role move is a good move for now\. You know, supportive stuff


---

### 961. msg_17108

**You** - 2025-06-04T07:00:53


*1 attachment(s)*


---

### 962. msg_17109

**You** - 2025-06-04T07:00:56

Reaction: ❤️ from Meredith Lamb

*1 attachment(s)*


---

### 963. msg_17110

**You** - 2025-06-04T07:01:16

Reaction: 😢 from Meredith Lamb
1st back shot I think my left shoulder is fucked


---

### 964. msg_17111

**You** - 2025-06-04T07:01:23

Reaction: 😮 from Meredith Lamb
lol I might need physio


---

### 965. msg_17112

**You** - 2025-06-04T07:01:53

>
When he hears the second part
Later he will give us both never ending amounts of shit


---

### 966. msg_17113

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:02:34

My time hop today… 6 years ago today\. I was still working out … started to go to shit about a year after this\.

*1 attachment(s)*


---

### 967. msg_17114

**You** - 2025-06-04T07:03:09

>
Globes and everything\!


---

### 968. msg_17115

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:03:24

Suicides\. I did these 2 days ago and almost died

*1 attachment(s)*


---

### 969. msg_17116

**You** - 2025-06-04T07:03:43

Easy to get back\.\. and those are HARD\.


---

### 970. msg_17117

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:03:48

>
I hate physio\!\!


---

### 971. msg_17118

**You** - 2025-06-04T07:03:57

I dun mind


---

### 972. msg_17119

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:04:23

>
Omg he won’t be the only one\.


---

### 973. msg_17120

**You** - 2025-06-04T07:05:12

Yeah I know idc honestly\.\.like truly as long as our jobs are safe and our families know\.\. I will just be looking forward to more and more freedom as we go forward\.


---

### 974. msg_17121

**You** - 2025-06-04T07:05:18

That being said


---

### 975. msg_17122

**You** - 2025-06-04T07:05:25

The people that know me the best


---

### 976. msg_17123

**You** - 2025-06-04T07:05:28

Even Carolyn


---

### 977. msg_17124

**You** - 2025-06-04T07:05:38

Will be very happy for me I am absolutely sure of it


---

### 978. msg_17125

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:09:41

I hope so\.


---

### 979. msg_17126

**You** - 2025-06-04T07:10:20

Reaction: 👍 from Meredith Lamb
Kk going to hit sauna and get home\.


---

### 980. msg_17127

**You** - 2025-06-04T07:11:05

Reaction: 😂 from Meredith Lamb
My day tomorrow will be fucked it good\. I have to bring
Jaimie to airport leaving at 4:30 am workout on way back maddie to school packing and dog watching gonna be a great day and weekend lol\.\.


---

### 981. msg_17128

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:12:16

She needs to learn how to drive and park or take an uber\. Just saying\.


---

### 982. msg_17129

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:12:18

lol


---

### 983. msg_17130

**You** - 2025-06-04T07:14:41

Yeah and I have to pick her up at midnight on Monday


---

### 984. msg_17131

**You** - 2025-06-04T07:14:44

Fucking stupid


---

### 985. msg_17132

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:23:34

Sorry but 🙄


---

### 986. msg_17133

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:23:39

lol


---

### 987. msg_17134

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:24:02

Andrew and I never picked each other up \(probably not a good thing in retrospect lol just seemed unnecessary\)


---

### 988. msg_17135

**You** - 2025-06-04T07:45:27

Yeah I mean it makes me think\.\. and don’t go oh you are spiralling I k ew it…\!\!\! But for about 2 decades I have been the one people leaned on in this house more than anyone else\.\. I couldn’t be needy because I wouldn’t get anything back and there was very little to no joy anyways\.\. I think it is just nice to have someone I can trust and who I know will support me just as I want to support you\.\. it seems a bit off now because of how we both deal with distance differently but I don’t want you to get scared away because oh no another needy guy lol\.


---

### 989. msg_17136

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:53:22

I told you last night that I don’t think you are needy\. I don’t necessarily always agree with where my therapist goes\. If I listened to her initially we wouldn’t be here\.


---

### 990. msg_17137

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:53:37

I am suffering through what WOULD have been the easiest workout ever\. Omg


---

### 991. msg_17138

**You** - 2025-06-04T07:54:18

Sorry I just reacted to the fact that you said you were taking some time to process it\.\. and I just wanted to weigh in on that processing lol


---

### 992. msg_17139

**You** - 2025-06-04T07:54:47

>
Take your time it will come week 3 you will see a massive difference


---

### 993. msg_17140

**You** - 2025-06-04T07:55:01

You should be getting something g for recovery though


---

### 994. msg_17141

**You** - 2025-06-04T07:55:13

There is something you can mix in a drink that I uses


---

### 995. msg_17142

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T07:59:22

>
I’m using a Bcaa I used to use\. And I took my first protein shake yday


---

### 996. msg_17143

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:00:03

>
Your life doesn’t need to be total service\. I think this is what Deb bullock was probably annoyed at with your relationship\. I kind of get it now


---

### 997. msg_17144

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:00:53

>
Done my workout but working on my push ups at the end of every workout\. Lol


---

### 998. msg_17145

**You** - 2025-06-04T08:00:57

>
Perfect I use same thing


---

### 999. msg_17146

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:01:35

Creature of habit\. Using the same brands and kinds of each


---

### 1000. msg_17147

**You** - 2025-06-04T08:01:42

>
I agree and I think there is a balance I can find with you that will make me very happy\.


---

### 1001. msg_17148

**You** - 2025-06-04T08:02:19

>
I always research my trainer for me
Trying a new protein but it is expensive…\. Will see if there are results\.\.


---

### 1002. msg_17149

**You** - 2025-06-04T08:02:32

Henry caville results would be worth it lol


---

### 1003. msg_17150

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:03:39

https://share\.google/0Zz8k9TO9naHWLwmD


---

### 1004. msg_17151

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:04:09

That’s what I’m using for now\. It is what i used to use but it was called chocolate only 5 yrs ago lol


---

### 1005. msg_17152

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:04:16

Tastes identical


---

### 1006. msg_17153

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:04:30

Must just be fancy branding adding in the cake


---

### 1007. msg_17154

**You** - 2025-06-04T08:04:55

I am using some kind of beef protein


---

### 1008. msg_17155

**You** - 2025-06-04T08:05:10

Also chocolate


---

### 1009. msg_17156

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:10:21

Saddest workout I have probably ever done\. I wrote it out easier than what it was and I still found it challenging\. lol very humbling

*1 attachment(s)*


---

### 1010. msg_17157

**You** - 2025-06-04T08:11:23

Don’t be hard on yourself this is how it always starts


---

### 1011. msg_17158

**You** - 2025-06-04T08:11:26

Same with me


---

### 1012. msg_17159

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:12:41

Reaction: ❤️ from Scott Hicks
Determined to be doing pushups in 30 days so going to increase tris and chest work… too sore to do any today\. Tried… :p

*1 attachment(s)*


---

### 1013. msg_17160

**You** - 2025-06-04T08:13:39

Find a set of stairs\.\. work your way down


---

### 1014. msg_17161

**You** - 2025-06-04T08:14:07

I love the determination we are so similar\.


---

### 1015. msg_17162

**You** - 2025-06-04T08:15:22

Heading into house here in a sec need to get maddie up and ready to go and probably going to start working on house will checkin online a little later\.  Love you\.


---

### 1016. msg_17163

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:45:00

>
You definitely motivated me\. I’m a little competitive that way\. Not like crazy competitive but a little


---

### 1017. msg_17164

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:46:00

My friends would call me crazy competitive but it is just bc none of them are\. So all relative\. :p


---

### 1018. msg_17165

**You** - 2025-06-04T08:46:36

I am just glad you felt engaged I think it will be a good thing to distract you\.


---

### 1019. msg_17166

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:48:45

So I dug in on Andrew and told him to smarten up and prioritize\. I was like “I’m not sure if I can afford this area so I need to know if the girls have to switch schools by September”


---

### 1020. msg_17167

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:48:51

Hopefully that scared him


---

### 1021. msg_17168

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:48:57

I said he is delaying on purpose


---

### 1022. msg_17169

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:49:00

He said no


---

### 1023. msg_17170

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:49:07

I said it is probably your subconscious


---

### 1024. msg_17171

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:49:10

He said no


---

### 1025. msg_17172

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:49:20

I said you just don’t realize bc you aren’t in therapy


---

### 1026. msg_17173

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T08:49:33

Then he ran away to his 9am meeting :p


---

### 1027. msg_17174

**You** - 2025-06-04T08:51:41

ROFL bully


---

### 1028. msg_17175

**You** - 2025-06-04T08:52:08

He deserves it though he is dragging his feet


---

### 1029. msg_17176

**You** - 2025-06-04T08:52:14

I did all of this myself in a weekend


---

### 1030. msg_17177

**You** - 2025-06-04T08:54:16

I wonder
If he knows about us which is why he is dragging


---

### 1031. msg_17178

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T09:09:03

>
Possibly…


---

### 1032. msg_17179

**You** - 2025-06-04T09:59:25

Dealing with fucking lawyers making me redo the work I did


---

### 1033. msg_17180

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:08:57

Why?


---

### 1034. msg_17181

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:23:02

Andrew is trying to boss me around again\. Omg


---

### 1035. msg_17182

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:23:09

He had such a good wife before


---

### 1036. msg_17183

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:23:17

This is hard for him


---

### 1037. msg_17184

**You** - 2025-06-04T10:25:58

>
What is going on


---

### 1038. msg_17185

**You** - 2025-06-04T10:26:27

>
They just want the information provided again in another format


---

### 1039. msg_17186

**You** - 2025-06-04T10:26:38

They are being stupid\.


---

### 1040. msg_17187

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:36:38

I’m just thinking about getting out of the cottage today\. So pissed off\.


---

### 1041. msg_17188

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:36:47

I’m honestly sure if it will work


---

### 1042. msg_17189

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:43:30

>
I am fucking sick of him doing nothing but volleyball and his work\. I have to work from home today\. Do all the cleaning all the laundry fucking clean up all his shit and everyone else’s and then he wants me to pick up Marlowe when I have my last team meeting and then thinks it’s this big inconvenience that I can’t do it on call\.


---

### 1043. msg_17190

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:44:10

The cottage will operate similarly and it is too frustrating


---

### 1044. msg_17191

**You** - 2025-06-04T10:49:21

Yeah I get it but don’t make decisions out of anger or frustration\. I think you need to understand the full picture from the mediator before making a decision


---

### 1045. msg_17192

**You** - 2025-06-04T10:49:32

Sorry you feel that way I get it


---

### 1046. msg_17193

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:51:04

I told him to reconsider his mom\. I’m so pissed off


---

### 1047. msg_17194

**You** - 2025-06-04T10:52:57

I know again\.\. I would suggest putting a date in the sand and basically telling him if you don’t have all the docs to the mediator by this date shit is going to hit the fan\.  I will be talking to her and complaining about this


---

### 1048. msg_17195

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:56:25

Yeah I will do that


---

### 1049. msg_17196

**You** - 2025-06-04T10:57:10

And don’t give him much time he has had enough and I don’t trust that he isn’t fucking shit around


---

### 1050. msg_17197

**You** - 2025-06-04T10:57:33

The bank balances accounts and everything is supposed to be dated
Back to the separation date


---

### 1051. msg_17198

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T10:59:52

Rhys is going to apply lol


---

### 1052. msg_17199

**You** - 2025-06-04T11:05:06

Yeah I know I told him to talk to you


---

### 1053. msg_17200

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T11:53:29


*3 attachment(s)*


---

### 1054. msg_17201

**You** - 2025-06-04T11:58:55

Having a hard time downloading something g


---

### 1055. msg_17202

**You** - 2025-06-04T11:59:03

Want to try to resend?


---

### 1056. msg_17203

**You** - 2025-06-04T11:59:10

Nm


---

### 1057. msg_17204

**You** - 2025-06-04T12:00:02

Why the please be rude song isn’t that a naughty song??


---

### 1058. msg_17205

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:00:25

It is not and it was playing\. Not sure why screenshot happened like that


---

### 1059. msg_17206

**You** - 2025-06-04T12:00:28

So not waiting to talk to the girl lol


---

### 1060. msg_17207

**You** - 2025-06-04T12:00:39

Something to be said for being decisive


---

### 1061. msg_17208

**You** - 2025-06-04T12:00:47

I just feel bad you love the cottage


---

### 1062. msg_17209

**You** - 2025-06-04T12:00:56

and put so much into it


---

### 1063. msg_17210

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:01:00

Oh it is bc I was in the car and that was playing and I was on Bluetooth so screenshot happened weird


---

### 1064. msg_17211

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:01:24


*1 attachment(s)*


---

### 1065. msg_17212

**You** - 2025-06-04T12:01:58

Man I thought I was dramatic


---

### 1066. msg_17213

**You** - 2025-06-04T12:02:10

I have spent all day here redoing all of our finances


---

### 1067. msg_17214

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:02:11

So fucking annoying


---

### 1068. msg_17215

**You** - 2025-06-04T12:02:16

I am not complaining


---

### 1069. msg_17216

**You** - 2025-06-04T12:02:35

And redocumenting everything and back dating it to April lol


---

### 1070. msg_17217

**You** - 2025-06-04T12:02:38

Omfg


---

### 1071. msg_17218

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:02:41

This was earlier…

*1 attachment(s)*


---

### 1072. msg_17219

**You** - 2025-06-04T12:03:24

Oh nice play there with the clause


---

### 1073. msg_17220

**You** - 2025-06-04T12:03:31

❤️


---

### 1074. msg_17221

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:09:50

He had never mentioned that before


---

### 1075. msg_17222

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:09:59

\(He didn’t comment on it\.\)


---

### 1076. msg_17223

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:11:22

He’s for sure pissed off


---

### 1077. msg_17224

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:11:37

The messy house etc etc and then 3am bugged me


---

### 1078. msg_17225

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:11:39

lol


---

### 1079. msg_17226

**You** - 2025-06-04T12:11:48

Apparently triggered


---

### 1080. msg_17227

**You** - 2025-06-04T12:11:58

You sure you are ok with no cottage\!


---

### 1081. msg_17228

**You** - 2025-06-04T12:12:06

Meant to be question mark


---

### 1082. msg_17229

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:13:19

I think I am very easily triggered lol


---

### 1083. msg_17230

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:14:20

Which is why I’m thinking that maybe the cottage is a bad idea


---

### 1084. msg_17231

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:14:28

Will I just be triggered for life


---

### 1085. msg_17232

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:14:31

Ughhhhh


---

### 1086. msg_17233

**You** - 2025-06-04T12:15:41

I would buy a cottage with you… 😊


---

### 1087. msg_17234

**You** - 2025-06-04T12:15:55

Once I recover from being pillaged\.


---

### 1088. msg_17235

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:17:16

I never even wanted a cottage


---

### 1089. msg_17236

**You** - 2025-06-04T12:17:21

I think you could use kind of release right now\.


---

### 1090. msg_17237

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:17:22

I wanted to go on tripes


---

### 1091. msg_17238

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:17:26

Trips


---

### 1092. msg_17239

**You** - 2025-06-04T12:18:00

Yeah that was my plan when I got older and free\-we


---

### 1093. msg_17240

**You** - 2025-06-04T12:18:03

We


---

### 1094. msg_17241

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:18:05

The cottage was something I learned to live with and integrate into my life bc it was so important to him


---

### 1095. msg_17242

**You** - 2025-06-04T12:18:06

Er


---

### 1096. msg_17243

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:18:40

First world problems


---

### 1097. msg_17244

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:24:20

Jim called me to find out how my “final one on one” with Pauline went\. Calendar stalkers are weird\.


---

### 1098. msg_17245

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:24:28

He was calendar stalking me


---

### 1099. msg_17246

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:27:12

Andrew is pissing me off so much that I feel like telling him I’m gonna move in with my parents and the kids can go to school in Oshawa\. Then I don’t have to pay anything for rent\. lol


---

### 1100. msg_17247

**You** - 2025-06-04T12:48:10

>
Maybe he was looking for a time to meet and just noticed


---

### 1101. msg_17248

**You** - 2025-06-04T12:48:35

>
lol you can’t/won’t do that it would impact kids too much


---

### 1102. msg_17249

**You** - 2025-06-04T12:49:21

Sorry j and I are packing or I would have responded earlier\.  Just sent the new financial package back to lawyers


---

### 1103. msg_17250

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:53:47

Good luck :\)


---

### 1104. msg_17251

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T12:54:04

>
Ugh


---

### 1105. msg_17252

**You** - 2025-06-04T12:58:46

We just took a break


---

### 1106. msg_17253

**You** - 2025-06-04T12:58:58

But we got a closest done and a few cupboards in basement


---

### 1107. msg_17254

**You** - 2025-06-04T12:59:01

Some progress


---

### 1108. msg_17255

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T13:03:45

That’s good…


---

### 1109. msg_17256

**You** - 2025-06-04T13:08:23

Kk well I think I am going to go off and work some more\.\. you sound very much in your “stuff” right now so maybe let’s chat when you come up for air later?


---

### 1110. msg_17257

**You** - 2025-06-04T13:08:40

We don’t need to video chat on teams\.\. all good


---

### 1111. msg_17258

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T13:15:47

kk


---

### 1112. msg_17259

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:34:41


*1 attachment(s)*


---

### 1113. msg_17260

**You** - 2025-06-04T14:35:11

Eeesh


---

### 1114. msg_17261

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:35:11

He is always disappointed when I don’t do what he wants exactly\. :p


---

### 1115. msg_17262

**You** - 2025-06-04T14:35:17

That is a big shift


---

### 1116. msg_17263

**You** - 2025-06-04T14:35:26

But


---

### 1117. msg_17264

**You** - 2025-06-04T14:35:49

Hmmm


---

### 1118. msg_17265

**You** - 2025-06-04T14:36:04

I cannot recall what you shares in the house were
Related
To each other


---

### 1119. msg_17266

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:36:24

We have like no equity in the house hardly


---

### 1120. msg_17267

**You** - 2025-06-04T14:36:26

But whatever your percent is vs his is the %
Of
The loss you would take\.


---

### 1121. msg_17268

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:36:38

I know\. Oh well\.


---

### 1122. msg_17269

**You** - 2025-06-04T14:36:53

No I only say that so he doesn’t try to split the kiss 50 to


---

### 1123. msg_17270

**You** - 2025-06-04T14:37:05

50 and apply it against you unfairly


---

### 1124. msg_17271

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:37:20

\*kiss


---

### 1125. msg_17272

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:37:23

Loss?


---

### 1126. msg_17273

**You** - 2025-06-04T14:37:26

Split the loss


---

### 1127. msg_17274

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:37:33

Oh


---

### 1128. msg_17275

**You** - 2025-06-04T14:37:45

Typo not Freudian\.\. just to be clear


---

### 1129. msg_17276

**You** - 2025-06-04T14:37:47

lol


---

### 1130. msg_17277

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:37:50

lol


---

### 1131. msg_17278

**You** - 2025-06-04T14:37:51

I know where your head goes


---

### 1132. msg_17279

**You** - 2025-06-04T14:37:58

Oh no Scott here we go again


---

### 1133. msg_17280

**You** - 2025-06-04T14:38:25

Well that will piss his mother off
Too


---

### 1134. msg_17281

**You** - 2025-06-04T14:38:32

So this should be interesting


---

### 1135. msg_17282

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T14:59:35

I just think a clean break might be smarter for everyone


---

### 1136. msg_17283

**You** - 2025-06-04T15:05:09

As long as you and through you the kids are taken care of I don’t care much beyond that\.


---

### 1137. msg_17284

**You** - 2025-06-04T15:05:45

Taking a break picking maddie up at 3:30 getting early
Supper and early gym\.  J gone out so not gonna bother working by juse


---

### 1138. msg_17285

**You** - 2025-06-04T15:05:48

Myself


---

### 1139. msg_17286

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:06:41

I kind of feel like I should start packing


---

### 1140. msg_17287

**You** - 2025-06-04T15:06:52

Maybe thinking


---

### 1141. msg_17288

**You** - 2025-06-04T15:06:53

First


---

### 1142. msg_17289

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:06:54

I might


---

### 1143. msg_17290

**You** - 2025-06-04T15:07:04

You are a ways from packing


---

### 1144. msg_17291

**You** - 2025-06-04T15:07:12

You are like 2 months from moving likely


---

### 1145. msg_17292

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:07:39

Grooooan 🫤


---

### 1146. msg_17293

**You** - 2025-06-04T15:07:53

Sry hon


---

### 1147. msg_17294

**You** - 2025-06-04T15:08:12

You guys got delayed by like 4
Weeks


---

### 1148. msg_17295

**You** - 2025-06-04T15:08:18

Sucks


---

### 1149. msg_17296

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:08:26

I know


---

### 1150. msg_17297

**You** - 2025-06-04T15:09:09

Anyhow yoj will
Get
There
I am just saying maybe watch a show go for a drive or a walk\.\. don’t start
Packing


---

### 1151. msg_17298

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:10:46

Oh I have to do all the driving tonight\. Marlowe up from grad trip\. Maelle volleyball\. :p


---

### 1152. msg_17299

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:10:52

Bark bark bark


---

### 1153. msg_17300

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:10:56

🙄


---

### 1154. msg_17301

**You** - 2025-06-04T15:11:09

Ahhh because he is doing taxes


---

### 1155. msg_17302

**You** - 2025-06-04T15:11:26

And he is going to be up ALL night


---

### 1156. msg_17303

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:12:25

lol yeah hard life\. He literally does NOTHING else except drive to volleyball and work on his laptop


---

### 1157. msg_17304

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:12:31

\(And make messes\)


---

### 1158. msg_17305

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:12:45

I’m so ready to go\. :\(


---

### 1159. msg_17306

**You** - 2025-06-04T15:13:09

I know\.\. I literally feel same way\.\. almost left last nigfht


---

### 1160. msg_17307

**You** - 2025-06-04T15:13:18

dreading this weekend\.\. and then the trip 2 weeks from now


---

### 1161. msg_17308

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:14:47

Imagine dreading a weekend\. Ugh\.


---

### 1162. msg_17309

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:15:00

I get it\.


---

### 1163. msg_17310

**You** - 2025-06-04T15:15:01

I have been doing that for years


---

### 1164. msg_17311

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:15:10

😬


---

### 1165. msg_17312

**You** - 2025-06-04T15:15:19

work was my refuge


---

### 1166. msg_17313

**You** - 2025-06-04T15:15:22

true story


---

### 1167. msg_17314

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:15:57

Yeah… hopefully that changes at some point\.


---

### 1168. msg_17315

**You** - 2025-06-04T15:16:05

It kinda has to\.


---

### 1169. msg_17316

**You** - 2025-06-04T15:16:17

Otherwise what is the point\.\. lol


---

### 1170. msg_17317

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:18:27

I just booked a pedicure for tomorrow … stress relief lol


---

### 1171. msg_17318

**You** - 2025-06-04T15:18:45

well that should do something for you\.\. maybe I should book something


---

### 1172. msg_17319

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:19:16

I might have 2 glasses of wine tonight but no more bc of my morning workout


---

### 1173. msg_17320

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:19:31

Feeling very frustrated and probably have to talk about it tonight 🙄


---

### 1174. msg_17321

**You** - 2025-06-04T15:19:38

:\(


---

### 1175. msg_17322

**You** - 2025-06-04T15:19:47

well I am sure that will be pleasant


---

### 1176. msg_17323

**You** - 2025-06-04T15:20:53

oooh 60 minute full body massage\.\. that sounds nice :\)


---

### 1177. msg_17324

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:22:02

It’s probably covered by benefits


---

### 1178. msg_17325

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:22:17

Did it before but I wasn’t a huge fan of strangers on me like that lol


---

### 1179. msg_17326

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:22:24

I liked acupuncture better


---

### 1180. msg_17327

**You** - 2025-06-04T15:22:24

it is covered by benefits\.\.


---

### 1181. msg_17328

**You** - 2025-06-04T15:22:32

I don't care about strangers\.\. I go somewhere else\.


---

### 1182. msg_17329

**You** - 2025-06-04T15:22:55

Might get waxed too\.\.\. been a while\.\. although I never enjoy it very much\.


---

### 1183. msg_17330

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:23:13

😬


---

### 1184. msg_17331

**You** - 2025-06-04T15:23:54

lol what is that face for


---

### 1185. msg_17332

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:24:06

Sounds painful


---

### 1186. msg_17333

**You** - 2025-06-04T15:24:41

you must have tried waxing before


---

### 1187. msg_17334

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:25:00

Nope\!


---

### 1188. msg_17335

**You** - 2025-06-04T15:25:26

rofl srsly\.\.  yeah I tried it a few years ago\.\. didn't mind it\.\. but you have to be consistent and I never am


---

### 1189. msg_17336

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:25:39

I would have to be drunk\. I have a low pain tolerance


---

### 1190. msg_17337

**You** - 2025-06-04T15:25:46

Funny story


---

### 1191. msg_17338

**You** - 2025-06-04T15:25:56

first time I got waxed it was my chest\.\.


---

### 1192. msg_17339

**You** - 2025-06-04T15:26:37

I was quite drunk laying on my friend Sam's floor\.\. smoking a cigarrette\.  She was training to be an aesthetician and asked if she could practice on me\.\. I was like sure\.\.\.


---

### 1193. msg_17340

**You** - 2025-06-04T15:26:40

holy fuck\.\.


---

### 1194. msg_17341

**You** - 2025-06-04T15:27:03

a\) it hurt really fucking bad\.\.\. b\) smoking around that was a bad idea c\) lying on carpet bad idea


---

### 1195. msg_17342

**You** - 2025-06-04T15:27:14

it ended poorly\.\. rash was epic and painful


---

### 1196. msg_17343

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:27:15

lol


---

### 1197. msg_17344

**You** - 2025-06-04T15:27:44

I just do my back now\.\.\. pain in ass\.\. but it bothers me\.


---

### 1198. msg_17345

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:28:12

Well it doesn’t bother me


---

### 1199. msg_17346

**You** - 2025-06-04T15:28:23

yea I know\.\.


---

### 1200. msg_17347

**You** - 2025-06-04T15:28:34

will it bother you if I do it?? fair question i guess


---

### 1201. msg_17348

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:29:27

It doesn’t feel like something for me to comment on\. It is your body not mine\. I honestly don’t care HONESTLY


---

### 1202. msg_17349

**You** - 2025-06-04T15:29:48

kk if you don't have a preference then so be it\.\. all I was asking\.


---

### 1203. msg_17350

**You** - 2025-06-04T15:30:07

you don't need to be emphatic lol\.\. this wasn't a hard question lol


---

### 1204. msg_17351

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:30:31

I just want you to know I’m being honest… lol


---

### 1205. msg_17352

**You** - 2025-06-04T15:31:25

I typically believe you are, only red flags are you dodging a question, stuttering to answer\.\. a few other tells\.\. I won't tell them all to you\.


---

### 1206. msg_17353

**You** - 2025-06-04T15:31:35

Laughing instead of answering\.\. always a good one\.


---

### 1207. msg_17354

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:32:31

lol quite a list


---

### 1208. msg_17355

**You** - 2025-06-04T15:32:36

I am observant


---

### 1209. msg_17356

**You** - 2025-06-04T15:32:39

what can I say


---

### 1210. msg_17357

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:32:43

Very


---

### 1211. msg_17358

**You** - 2025-06-04T15:33:28

I am sorry\.\. I can try to stop\.\. I think this is just going to make you more self conscious\.\.\.\.\.\.\.


---

### 1212. msg_17359

**You** - 2025-06-04T15:33:32

going to get maddie brb


---

### 1213. msg_17360

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:34:29

No it won’t don’t worry


---

### 1214. msg_17361

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:34:39

I don’t like lying so I have my ticks


---

### 1215. msg_17362

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:34:44

Haha I’m ok with it


---

### 1216. msg_17363

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:35:02

My friends that hate hair do laser and it is apparently very painful\.


---

### 1217. msg_17364

**You** - 2025-06-04T15:35:22

Yeah no I don’t hate it tbh


---

### 1218. msg_17365

**You** - 2025-06-04T15:35:30

I just wanted to try it


---

### 1219. msg_17366

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:35:31

I have like no hair on my arms and legs and my friends don’t get it

*1 attachment(s)*


---

### 1220. msg_17367

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:35:42

It’s weird bc my hair on my head is so thick


---

### 1221. msg_17368

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:36:08

🤷‍♀️


---

### 1222. msg_17369

**You** - 2025-06-04T15:36:18

Genetics??  Maybe Brett has crazy hair all over his body


---

### 1223. msg_17370

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:36:28

Yeah he does and hates it


---

### 1224. msg_17371

**You** - 2025-06-04T15:36:35

ROFL


---

### 1225. msg_17372

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:36:38

I’m not allowed to take swimming pix of him at cottage


---

### 1226. msg_17373

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:36:46

Or if I do I’m not allowed to post on fb


---

### 1227. msg_17374

**You** - 2025-06-04T15:36:47

I wa joking but funny


---

### 1228. msg_17375

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:36:53

lol


---

### 1229. msg_17376

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:37:41

I have one friend who has spent thousands lasering her arms and legs in our twenties


---

### 1230. msg_17377

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T15:37:44

Crazy


---

### 1231. msg_17378

**You** - 2025-06-04T15:37:59

Some people swear
Unit


---

### 1232. msg_17379

**You** - 2025-06-04T15:38:04

By it


---

### 1233. msg_17380

**You** - 2025-06-04T16:07:31

Going back to this because I need to go make some food\.


---

### 1234. msg_17381

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:12:35

I just uber eats some wine lol can’t really drink tho bc I have to drive tonight


---

### 1235. msg_17382

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:12:40

I can have a glass tho


---

### 1236. msg_17383

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:14:23

Helpppppp lol

*1 attachment(s)*


---

### 1237. msg_17384

**You** - 2025-06-04T16:14:57

rofl


---

### 1238. msg_17385

**You** - 2025-06-04T16:14:58

wow


---

### 1239. msg_17386

**You** - 2025-06-04T16:15:27

and we're off


---

### 1240. msg_17387

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:15:44

Where is my wine


---

### 1241. msg_17388

**You** - 2025-06-04T16:15:51

I am worried about you


---

### 1242. msg_17389

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:16:05


*1 attachment(s)*


---

### 1243. msg_17390

**You** - 2025-06-04T16:16:42

andrew that is how parenting is supposed to work


---

### 1244. msg_17391

**You** - 2025-06-04T16:16:45

separation or not


---

### 1245. msg_17392

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:16:55


*1 attachment(s)*


---

### 1246. msg_17393

**You** - 2025-06-04T16:16:57

you just haven't been doing that\.\. it was supposed to be a partnership


---

### 1247. msg_17394

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:17:21

I’m going to use the therapist card from now on


---

### 1248. msg_17395

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:17:27

He refuses to get therapy


---

### 1249. msg_17396

**You** - 2025-06-04T16:18:45

well j tried that on me


---

### 1250. msg_17397

**You** - 2025-06-04T16:18:51

still does


---

### 1251. msg_17398

**You** - 2025-06-04T16:18:56

no impact


---

### 1252. msg_17399

**You** - 2025-06-04T16:22:57

oh you are in full battle mode right now\.\. :\(


---

### 1253. msg_17400

**You** - 2025-06-04T16:23:33

You probably should step back before it gets too hairy\.


---

### 1254. msg_17401

**You** - 2025-06-04T16:24:26

I will just wait to hear the outcome\.


---

### 1255. msg_17402

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:30:32


*1 attachment(s)*


---

### 1256. msg_17403

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:30:51

So fucking annoying\. I have an email apparently\.


---

### 1257. msg_17404

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:31:06


*1 attachment(s)*


---

### 1258. msg_17405

**You** - 2025-06-04T16:31:22

couples communicate


---

### 1259. msg_17406

**You** - 2025-06-04T16:31:27

maybe that is where he went wrong


---

### 1260. msg_17407

**You** - 2025-06-04T16:31:35

taking a relationship for granted for so long\.\.


---

### 1261. msg_17408

**You** - 2025-06-04T16:31:36

eesh


---

### 1262. msg_17409

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:31:49


*1 attachment(s)*


---

### 1263. msg_17410

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:32:06

Full battle


---

### 1264. msg_17411

**You** - 2025-06-04T16:32:13

yeah text battle same house different rooms\.


---

### 1265. msg_17412

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:32:14

I don’t think the cottage will work for this reason


---

### 1266. msg_17413

**You** - 2025-06-04T16:32:22

insane


---

### 1267. msg_17414

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:32:26

>
He’s not home


---

### 1268. msg_17415

**You** - 2025-06-04T16:32:31

oh shit I thought he was


---

### 1269. msg_17416

**You** - 2025-06-04T16:32:37

probably better


---

### 1270. msg_17417

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:32:46

He will treat me the same in the cottage situation\.


---

### 1271. msg_17418

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:32:56

No he’s at work


---

### 1272. msg_17419

**You** - 2025-06-04T16:33:00

I think he will treat you the same in every situation


---

### 1273. msg_17420

**You** - 2025-06-04T16:33:20

This is why there is a parenting agreement


---

### 1274. msg_17421

**You** - 2025-06-04T16:33:39

and clauses like that \- around how to deal with signing kids up for shit\.\. needs to be in there\.


---

### 1275. msg_17422

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:33:44


*1 attachment(s)*


---

### 1276. msg_17423

**You** - 2025-06-04T16:34:09

I mean how is it any of those things to ask for common courtesy to be treated as an equal parent with an equal say


---

### 1277. msg_17424

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:34:11

Reaction: 😢 from Scott Hicks
Going to have a glass now even tho it is only 4\.30pm\. It will calm my nerves


---

### 1278. msg_17425

**You** - 2025-06-04T16:37:06

sucks mer\.\. wish I could be with you\.


---

### 1279. msg_17426

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T16:54:01

Reaction: 😔 from Scott Hicks
Apparently I need to look in the mirror a bit\. I’m way too angry\.


---

### 1280. msg_17427

**You** - 2025-06-04T16:54:38

I think you might be angry with him\.\. and for good reason\.


---

### 1281. msg_17428

**You** - 2025-06-04T16:58:50

How is your benefits plan set up?


---

### 1282. msg_17429

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:00:45

What do you mean?


---

### 1283. msg_17430

**You** - 2025-06-04T17:00:54

Do you have full family coverage?


---

### 1284. msg_17431

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:01:01

Yes


---

### 1285. msg_17432

**You** - 2025-06-04T17:01:03

and Andrew?


---

### 1286. msg_17433

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:01:11

Yes


---

### 1287. msg_17434

**You** - 2025-06-04T17:01:24

kk I am not sure what yours is set at\.\. like as far as where you pay\.\.


---

### 1288. msg_17435

**You** - 2025-06-04T17:01:38

but you will have an opportunity\.\. when you sign the agreement to go in and make changes to your benefit


---

### 1289. msg_17436

**You** - 2025-06-04T17:01:39

s


---

### 1290. msg_17437

**You** - 2025-06-04T17:01:41

if you need to


---

### 1291. msg_17438

**You** - 2025-06-04T17:01:53

And your benefits will no longer cover andrew and his you


---

### 1292. msg_17439

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:01:54

Yeah I know\. Life change


---

### 1293. msg_17440

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:02:02

Yeah


---

### 1294. msg_17441

**You** - 2025-06-04T17:02:34

you can also require andrew to continue to maintain life insurance in yours and the childrens name if he is sick or passes etc\.\. as well as maintain life insurance on you or sick or etc\.


---

### 1295. msg_17442

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:02:40

He got home and goes “so you just want a cheque?


---

### 1296. msg_17443

**You** - 2025-06-04T17:02:50

yeah\.\. classy\.


---

### 1297. msg_17444

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:02:57

lol


---

### 1298. msg_17445

**You** - 2025-06-04T17:12:45

Not sure how deep or where you are at now\.\. been messing around with this
\*\*PARENTING AGREEMENT\*\*
\*\*Between:\*\*
\*\*M\*\*
and
\*\*A\*\*
\*\*Effective Date:\*\* ?
\-\-\-
\#\#\# 1\. Purpose
This parenting agreement reflects the mutual intention of both parents to continue working collaboratively in the best interests of their children following their separation\. While their relationship has changed, both parents remain committed to providing a stable, respectful, and nurturing environment that supports the emotional, educational, and physical well\-being of the children\.
\-\-\-
\#\#\# 2\. Children Covered by This Agreement
\* M\-16
M\-14
M\-12
\-\-\-
\#\#\# 3\. Decision\-Making Responsibility
The parents shall continue to share \*\*joint decision\-making responsibility\*\*, consistent with best parenting practices that recognize children benefit from meaningful involvement by both parents\. This approach builds upon the shared involvement the parents had during the relationship and supports continued cooperation post\-separation\.
Maj\.\.\. \[truncated\]


---

### 1299. msg_17446

**You** - 2025-06-04T17:13:00

I already built one for me\.\. but yours I thought might be a bit different


---

### 1300. msg_17447

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:23:49

Interesting\. It is good\. Apparently the mediator will have one also\.


---

### 1301. msg_17448

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:23:56

If we ever get to move to that stage


---

### 1302. msg_17449

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:24:08

I’m questioning the whole 50/50 thing as of today


---

### 1303. msg_17450

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:24:27

Like I know we SAY it will be 50/50 but maybe I should state reality


---

### 1304. msg_17451

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:24:33

Questioning that


---

### 1305. msg_17452

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:24:36

Now


---

### 1306. msg_17453

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:26:04

Going to wait a bit\. I’m very angry right now so not a great time to ponder it


---

### 1307. msg_17454

**You** - 2025-06-04T17:27:04

yeah I tried to add some things that I thought you would want\.\. and I had it written in a empathetic way so as to suggest this was a continuation of what good parenting practices should be\.\. etc\.\. I figured you would tweak it\.\. it is just good to think through this so you know what your next mediator conversation goes like


---

### 1308. msg_17455

**You** - 2025-06-04T17:27:20

reality being you have primary custody\.


---

### 1309. msg_17456

**You** - 2025-06-04T17:27:24

he will fight that


---

### 1310. msg_17457

**You** - 2025-06-04T17:27:28

optics100%


---

### 1311. msg_17458

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:27:36

>
I could tell you tweaked it lol


---

### 1312. msg_17459

**You** - 2025-06-04T17:27:45

>
lol\.\. my fingerprints all over it


---

### 1313. msg_17460

**You** - 2025-06-04T17:28:35

I could have been more obvious\.\.
\*\*PARENTING AGREEMENT\*\*
\*\*Between:\*\*
\*\*M\*\*
and
\*\*Douchebag\*\*
\*\*Effective Date:\*\* Right the fuck now\!


---

### 1314. msg_17461

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:30:07

lol


---

### 1315. msg_17462

**You** - 2025-06-04T17:31:30

having a naughty idea\.\. just letting you know in advance\.


---

### 1316. msg_17463

**You** - 2025-06-04T17:32:09

if you are up for naughty ideas :\)


---

### 1317. msg_17464

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:32:29

Where did this come from?


---

### 1318. msg_17465

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:32:32

lol


---

### 1319. msg_17466

**You** - 2025-06-04T17:32:45

what do you mean\.\. there is a part of my mind that literally is always at work on that stuff


---

### 1320. msg_17467

**You** - 2025-06-04T17:33:05

Reaction: ❤️ from Meredith Lamb
it's a small part but it is always working\!\!


---

### 1321. msg_17468

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:34:23

>
Of course I am


---

### 1322. msg_17469

**You** - 2025-06-04T17:34:40

mmm this one might be a bit too shady\.\.


---

### 1323. msg_17470

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:34:42

You picked an interesting day


---

### 1324. msg_17471

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:34:45

lol


---

### 1325. msg_17472

**You** - 2025-06-04T17:34:56

rofl  maybe I should wait until a few more glasses


---

### 1326. msg_17473

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:35:19

I can’t\! I have to drive 2x tonight


---

### 1327. msg_17474

**You** - 2025-06-04T17:35:26

when are you finished driving?


---

### 1328. msg_17475

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:35:40

8\.20 or 8\.30


---

### 1329. msg_17476

**You** - 2025-06-04T17:35:51

so have one then\.\.


---

### 1330. msg_17477

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:36:02

Twist my arm


---

### 1331. msg_17478

**You** - 2025-06-04T17:36:06

I don't know what your weekend looks like though or what Andrew had you loaded up with


---

### 1332. msg_17479

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:36:52

I don’t think I have anything but honestly he may have just not mentioned shit\. Or maybe I have an unread email 🙄


---

### 1333. msg_17480

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:37:03

Good lord


---

### 1334. msg_17481

**You** - 2025-06-04T17:37:17

kk well I shouldn't really share until we know\.\.


---

### 1335. msg_17482

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:37:37

What why? Just assume nothing lol


---

### 1336. msg_17483

**You** - 2025-06-04T17:38:05

well i came up with the idea previously\.\. but it was much more taudry\.\. then I found a site called DayUse\.


---

### 1337. msg_17484

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:38:57

DayUse\. This is sounding a little … er… lol


---

### 1338. msg_17485

**You** - 2025-06-04T17:39:03

like I said\.


---

### 1339. msg_17486

**You** - 2025-06-04T17:39:54

it is what it sounds like you get the hotel for the day like 9\-5 ish\.\. people use it like a base of operations if they are in for the day\.\. say downtown\.\.\. and want a place to kind of relax back at before heading out again\.\. that is what I understand the premise to be\.


---

### 1340. msg_17487

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:40:30

Interesting so it isn’t at like Jane and finch


---

### 1341. msg_17488

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:40:33

Haha


---

### 1342. msg_17489

**You** - 2025-06-04T17:40:51


*1 attachment(s)*


---

### 1343. msg_17490

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:41:47

Hmmh


---

### 1344. msg_17491

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:41:53

Or


---

### 1345. msg_17492

**You** - 2025-06-04T17:41:58

lol


---

### 1346. msg_17493

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:42:42

I’d be up for that\. Or I could introduce you to my parents this weekend if they are around\.


---

### 1347. msg_17494

**You** - 2025-06-04T17:43:00

I mean we could do that or both\.\. whichever you prefer\.


---

### 1348. msg_17495

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:44:03

My mom emailed me so it’s easier just to call her so I’m gonna drop Marlowe off at volleyball and then call my mom\. I could feel it out\.


---

### 1349. msg_17496

**You** - 2025-06-04T17:44:47


*1 attachment(s)*


---

### 1350. msg_17497

**You** - 2025-06-04T17:45:26

whatever you prefer :\) there are options\. and multiple days\.\. and I have some freedom during the day especially\.


---

### 1351. msg_17498

**You** - 2025-06-04T17:46:20

parking is $21 so meh but I dun care\.


---

### 1352. msg_17499

**You** - 2025-06-04T17:46:42

you could actually drop your car off at work


---

### 1353. msg_17500

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T17:46:51

Just need to drive my shadow


---

### 1354. msg_17501

**You** - 2025-06-04T17:47:10

kk chat later\.


---

### 1355. msg_17502

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T18:16:13

Just talking to my mom


---

### 1356. msg_17503

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T18:16:19

Home on the couch


---

### 1357. msg_17504

**You** - 2025-06-04T18:21:31

Kk water heater is fucked scheduled an appt
For
Tomorrow morning zzzzz


---

### 1358. msg_17505

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T18:21:51

Gahhh


---

### 1359. msg_17506

**You** - 2025-06-04T18:21:53

Still works but it is expelling hot air into the furnace room and condensing on the hrv


---

### 1360. msg_17507

**You** - 2025-06-04T18:21:59

Then dropping everywhere


---

### 1361. msg_17508

**You** - 2025-06-04T18:22:02

No damamge


---

### 1362. msg_17509

**You** - 2025-06-04T18:22:05

No flooding


---

### 1363. msg_17510

**You** - 2025-06-04T18:22:09

Just needs to get
Sorted


---

### 1364. msg_17511

**You** - 2025-06-04T18:22:40

I am just packing up to head
To gym in a few here\.
If
You want to chat about whatever whenever let me know\.\. not working out tonight just relaxing


---

### 1365. msg_17512

**You** - 2025-06-04T18:41:54

On my way\! To gym now hope mum is doing good and helping you through this mess


---

### 1366. msg_17513

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T19:19:47

I think my mom is apprehensive to meet you because of our messy situations but I think she’d be fine\.  Maybe a little shy\. Lol


---

### 1367. msg_17514

**You** - 2025-06-04T19:20:14

Then put it off


---

### 1368. msg_17515

**You** - 2025-06-04T19:20:24

I don’t want her to
Be uncomfortable


---

### 1369. msg_17516

**You** - 2025-06-04T19:20:36

I would be anxious as
Well


---

### 1370. msg_17517

**You** - 2025-06-04T19:20:55

I get one chance


---

### 1371. msg_17518

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T19:21:12

It has to happen sooner or later


---

### 1372. msg_17519

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T19:21:19

Sooner better lol


---

### 1373. msg_17520

**You** - 2025-06-04T19:21:32

Up to you\.\. you pick what you want to
Do\.


---

### 1374. msg_17521

**You** - 2025-06-04T19:22:12

I have sat day open and easy\.\. Sunday I have trainer at noon\.


---

### 1375. msg_17522

**You** - 2025-06-04T19:25:54

Whatever you are comfortable with mer


---

### 1376. msg_17523

**You** - 2025-06-04T19:27:42

I am about to go into my steam room sauna part of my night just finishing hot tub so I can check back after if you want to chat some more


---

### 1377. msg_17524

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T20:01:51

Just picking up Marlowe


---

### 1378. msg_17525

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T20:27:08

I’m home and off the phone\. Going to lie in bed now\. So tired\. Watch some tv\. I can chat if you want to


---

### 1379. msg_17526

**You** - 2025-06-04T20:28:29

Just got out


---

### 1380. msg_17527

**You** - 2025-06-04T20:28:52

Of shower let me get dressed and get to car if you are still there


---

### 1381. msg_17528

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T20:29:54

Yeah I will be probably watch some tv before bed


---

### 1382. msg_17529

**You** - 2025-06-04T20:30:22

Kk yku doing ok?


---

### 1383. msg_17530

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T20:33:04

Yeah I’m ok


---

### 1384. msg_17531

**You** - 2025-06-04T20:37:45

Good to call?


---

### 1385. msg_17532

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T20:38:23

Yeah


---

### 1386. msg_17533

**You** - 2025-06-04T20:50:51

lol


---

### 1387. msg_17534

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T21:03:10

k sorry he is yapping away at me


---

### 1388. msg_17535

**You** - 2025-06-04T21:09:00

yeah I figured we are done for the night the way you popped off\. it's fine


---

### 1389. msg_17536

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T21:38:50

I’m sorry\. That went really really horribly\. I think I’m going to just go to bed\. My head is pounding now and I’m so beyond angry\.
I love you and will talk to you tomorrow\. Xox sorry about that


---

### 1390. msg_17537

**You** - 2025-06-04T21:40:14

I love you too Mer\.\. I have just been sitting here thinking about you and worrying\.\. I am glad you messaged me back\.\. reach out whenever you want tomorrow\.  I hope you can get some peace and some sleep\.\. and don't worry about this weekend\.\. we don't have to do anything you can take it easy\.\.\. XOXOX ❤️


---

### 1391. msg_17538

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T21:44:42

I’m so sad\. He was so insulting tonight\. I lost it on him\. Here’s my ChatGPT: I’m going through a separation and it is getting nasty\. My husband that I am separated from just asked me if I want to only have the kids on weekends\. What do you make of this?


---

### 1392. msg_17539

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T21:45:01

I’m really sorry you’re going through this — separation is hard enough without it becoming contentious\.
When your husband asks if you “only want the kids on weekends,” it could mean a few things, depending on tone, context, and history between you:
1\.	Testing boundaries or leverage: He might be trying to assert control over the custody dynamic, possibly pre\-empting legal discussions\. This kind of question can be a way of probing how much parenting time you’re aiming for, or trying to shape the narrative\.
2\.	Manipulation or provocation: If things are getting nasty, he might be trying to provoke an emotional reaction, implying that you don’t want to be with the kids full\-time — a painful and often unfair suggestion\.
3\.	Literal inquiry \(less likely\): If custody hasn’t been fully discussed, he might actually be asking what your ideal arrangement is, but the phrasing still seems loaded and dismissive\.
4\.	Weaponizing parenting time: It could be an early sign he intends to push for more custo\.\.\. \[truncated\]


---

### 1393. msg_17540

**You** - 2025-06-04T21:50:20

Sec


---

### 1394. msg_17541

**You** - 2025-06-04T21:55:11

One more min I need to get away from fam I can call yku if you want in a min


---

### 1395. msg_17542

**You** - 2025-06-04T21:55:12

Sry


---

### 1396. msg_17543

**You** - 2025-06-04T21:58:28

I cannot believe he did that\.\. I am guessing the conversation escalated dramatically\.


---

### 1397. msg_17544

**You** - 2025-06-04T21:58:57

When you say you lost it on him what do you mean\.


---

### 1398. msg_17545

**You** - 2025-06-04T21:59:29

I am sorry mer I want to help but if you want I will leave you be hon\.


---

### 1399. msg_17546

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:00:56

I was in shock that he would even think that of me\. Like wtf\. So I shut down\. Then I pulled him in the office and said if he ever dares mention, insinuate, hint at or talk in any way shape or form of me wanting to see my kids only on weekends ever again there will be HELL to pay and he’ll like he has never seen before\.


---

### 1400. msg_17547

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:01:17

I told him I will transfer to Chatham and take my kids\. He said I can’t\. I said WATCH ME\.


---

### 1401. msg_17548

**You** - 2025-06-04T22:02:21

🙁 I am sorry he is treating you that way it is the lowest thing he could possibly do…


---

### 1402. msg_17549

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:02:24

He said I’d have to get a lawyer etc and I said “no problem I will explain how I do everything for the kids except some of the vball driving, doctors, dentists, clothes, school, took 5 hrs off and did everything\. I said I will document all your trips away and work events etc etc”


---

### 1403. msg_17550

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:02:30

He looked scared for once


---

### 1404. msg_17551

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:02:37

Then said sorry


---

### 1405. msg_17552

**You** - 2025-06-04T22:02:56

What the fuck man


---

### 1406. msg_17553

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:03:08

Switching jobs literally for my kids


---

### 1407. msg_17554

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:03:32

He is like “you’re doing it for the kids?” In a snarky tone


---

### 1408. msg_17555

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:03:35

Sigh


---

### 1409. msg_17556

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:03:46

Anyway, it is maddening


---

### 1410. msg_17557

**You** - 2025-06-04T22:04:15

He means you are doing it for yourself right\.\. some kind of insinuation you haven’t tried hard enough?


---

### 1411. msg_17558

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:04:48

🙄

*1 attachment(s)*


---

### 1412. msg_17559

**You** - 2025-06-04T22:04:53

Again really sorry feel very useless here\.


---

### 1413. msg_17560

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:05:23

>
He thinks I do everything for myself and yes the job thing also\. For me entirely\.


---

### 1414. msg_17561

**You** - 2025-06-04T22:05:29

That is just
Moronic\. I am not sure what he was trying to accomplish


---

### 1415. msg_17562

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:05:29

Such a moron\.


---

### 1416. msg_17563

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:06:04

He’s mad that I’m blowing up the whole plan with the cottage thing\.


---

### 1417. msg_17564

**You** - 2025-06-04T22:06:14

I know and he is retaliating


---

### 1418. msg_17565

**You** - 2025-06-04T22:06:22

By trying to hurt you


---

### 1419. msg_17566

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:06:26

I said the fact that he thinks I would throw away my kids is exactly why we can’t share anything together\.


---

### 1420. msg_17567

**You** - 2025-06-04T22:06:55

How much of this was verbal and how much text


---

### 1421. msg_17568

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:08:25

All verbal


---

### 1422. msg_17569

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:08:33

I just sent him that ChatGPT after


---

### 1423. msg_17570

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:08:45

That’s when he responded with the thing above


---

### 1424. msg_17571

**You** - 2025-06-04T22:08:52

Ah ok\.


---

### 1425. msg_17572

**You** - 2025-06-04T22:09:02

Well at least
You have that as evidence now


---

### 1426. msg_17573

**You** - 2025-06-04T22:09:09

Give it to the mediator


---

### 1427. msg_17574

**You** - 2025-06-04T22:09:40

That he is fucking around delaying things trying to leverage your kids to make you do things you don’t want


---

### 1428. msg_17575

**You** - 2025-06-04T22:09:43

Etc


---

### 1429. msg_17576

**You** - 2025-06-04T22:10:18

By responding the way he did he admitted to doing it


---

### 1430. msg_17577

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:11:22

Sigh\. Just sad\. Think I’m going to go to bed to get up early\.


---

### 1431. msg_17578

**You** - 2025-06-04T22:12:09

Reaction: ❤️ from Meredith Lamb
Ok sorry Mer I love you wish I could give you a hug and snuggle up\.\. but you will just have to use your imagination\. ❤️


---

### 1432. msg_17579

**Meredith Lamb \(\+14169386001\)** - 2025-06-04T22:12:37

Love you too \- nite ❤️


---

### 1433. msg_17580

**You** - 2025-06-05T04:07:49

Reaction: ❤️ from Meredith Lamb
I love you so much Mer\. I just wish I was waking up next to you so I could make sure you are ok\.  You didn’t deserve any of that last night nor what came before\.  That is something you will never find with me\.  I might not always be able to give you what you need but I swear to god I will give you everything I have to give just to make you happy\.  Ok I have to scrape my ass outta bed and go to the airport\.  Then gym then home then maddie then water heater lol… then I will wait to hear from you\.  Or maybe you give me another shout\.  If you try push\-ups do them first thing\.  Lock your core flex glutes think about last night and give er\!


---

### 1434. msg_17581

**You** - 2025-06-05T04:08:20

Love you hun more than you know\.  Chat later❤️❤️❤️❤️🔥🔥🔥🔥


---

### 1435. msg_17582

**You** - 2025-06-05T04:34:55

and you know what… someday if you’ll have me, we will get a place together, and we will travel and we will support each other and love each other as we get older and as cheesy as it sounds we will live… you know… ever after\. Honestly I cannot think of anything I want more than to see you smile at me everyday for all the rest\.  Driving now\.\. thinking about you…\.


---

### 1436. msg_17583

**You** - 2025-06-05T05:54:33

Left house at 4:45 at gym at 5:50 I may have sped a bit\.\.


---

### 1437. msg_17584

**You** - 2025-06-05T07:23:19

I sincerely hope you are sleeping in and not fighting


---

### 1438. msg_17585

**You** - 2025-06-05T08:08:54

Kk bit worried


---

### 1439. msg_17586

**You** - 2025-06-05T08:10:44

So we don’t have to chat
Or talk or anything I just want to know you are ok\.\.


---

### 1440. msg_17587

**You** - 2025-06-05T08:13:29



---

### 1441. msg_17588

**You** - 2025-06-05T08:33:48



---

### 1442. msg_17589

**You** - 2025-06-05T09:00:10

??


---

### 1443. msg_17590

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:00:32

Slept in lol


---

### 1444. msg_17591

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:00:49

Snoozed the alarm a million times


---

### 1445. msg_17592

**You** - 2025-06-05T09:00:53

Kk


---

### 1446. msg_17593

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:01:44

Im so sore I think im taking a day off and will push my work outs to Saturday


---

### 1447. msg_17594

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:02:38

I was going to do mom to fri


---

### 1448. msg_17595

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:02:44

Mon to Fri


---

### 1449. msg_17596

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:03:03

But will take today off and do sat


---

### 1450. msg_17597

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:11:25

But I’m going to do push ups everyday x


---

### 1451. msg_17598

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:13:16

>
Yesterday was so horrible so thank you for this\. I honestly believe this too and I’m not the most optimistic person but I do think this\. It is a little hard coming downstairs to make my coffee and he’s on a call from home\. This is just getting annoying and draining\. I’m tired of it\.


---

### 1452. msg_17599

**You** - 2025-06-05T09:16:04

I know I feel like shit
Today I am stuck here nothing I can do for you\.\. useless\.\. I was worried because I thought something happened because of how hard
You were both going at it\.  I hate this situation and I hate feeling like this all the time\.


---

### 1453. msg_17600

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:22:18

No I just went to sleep 💤 but I’m questioning a lot this morning


---

### 1454. msg_17601

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:22:44

Like maybe if I did the cottage he would be less nasty\. But I really think it is a bad idea\.


---

### 1455. msg_17602

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:23:00

I think we are just going to wait and see what the mediator says


---

### 1456. msg_17603

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:23:10

He uploaded stuff last night apparently


---

### 1457. msg_17604

**You** - 2025-06-05T09:23:40

>
Remember what I said\. 🙄


---

### 1458. msg_17605

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:23:47

I know\.


---

### 1459. msg_17606

**You** - 2025-06-05T09:23:59

>
What else


---

### 1460. msg_17607

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:24:31

The sad thing is that I don’t even want to tell my parents about the kids/weekend things bc it is so awful \(don’t want to stress them\) yet he doesn’t even think there is an issue with what he said


---

### 1461. msg_17608

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:24:49

I would like to tell them tho


---

### 1462. msg_17609

**You** - 2025-06-05T09:24:57

What he said was a threat and it was used to intimidate you


---

### 1463. msg_17610

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:24:58

I like them to know the whole situation


---

### 1464. msg_17611

**You** - 2025-06-05T09:25:05

Your mum would say get a fucking lawyer right now


---

### 1465. msg_17612

**You** - 2025-06-05T09:25:09

Bet


---

### 1466. msg_17613

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:25:18

Yeah maybe


---

### 1467. msg_17614

**You** - 2025-06-05T09:25:38

Consequences to actions


---

### 1468. msg_17615

**You** - 2025-06-05T09:25:43

That is how I live


---

### 1469. msg_17616

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:26:06

>
Nothing else really … def not us don’t worry about that


---

### 1470. msg_17617

**You** - 2025-06-05T09:26:21

I always worry about that\.\. cannot help it\.


---

### 1471. msg_17618

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:27:13

FYI I just told Mus and Andres to do soft moves to be with team


---

### 1472. msg_17619

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:27:17

They want to


---

### 1473. msg_17620

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:27:23

And desks are there


---

### 1474. msg_17621

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:27:27

One is Anna’s


---

### 1475. msg_17622

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:27:35

Andres will go in Anna’s


---

### 1476. msg_17623

**You** - 2025-06-05T09:27:41

It’s fine again that is my problem to solve you have a mountain of
Your own to worry about\.\. as I said focus on you and your stuff this weekend\. I will focus on cleaning or something\.


---

### 1477. msg_17624

**You** - 2025-06-05T09:27:47

Sure
Moves are fine


---

### 1478. msg_17625

**You** - 2025-06-05T09:27:56

I honestly don’t care who does what


---

### 1479. msg_17626

**You** - 2025-06-05T09:28:02

As
Long as there is agreement


---

### 1480. msg_17627

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:28:10

>
Just let me recover today :\)


---

### 1481. msg_17628

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:28:15

Then we will talk


---

### 1482. msg_17629

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:28:19

About weekend


---

### 1483. msg_17630

**You** - 2025-06-05T09:28:49

I am trying to take that off your plate if you will let me it just adds
Stress to you\.\. so just let me help how I can help ok\.


---

### 1484. msg_17631

**You** - 2025-06-05T09:29:05

Literally only thing
I can do\.


---

### 1485. msg_17632

**You** - 2025-06-05T09:29:14

Mistake


---

### 1486. msg_17633

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:32:43

You don’t just add stress to my life you know\. You are literally the best thing about my life right now\. I am so tired and couldn’t do anything today but weekend is a bit further out…


---

### 1487. msg_17634

**You** - 2025-06-05T09:34:17

Just worry about you pls I will sort myself out\.\. I have been doing it for a really really long time\.\. so I am used to it and can figure it out\.


---

### 1488. msg_17635

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:35:40

I know you can but I like being with you and seeing you\. :\)


---

### 1489. msg_17636

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:37:39

Cannot find this song on Spotify\. This post is a lie :\( not dropped yet

*1 attachment(s)*


---

### 1490. msg_17637

**You** - 2025-06-05T09:38:05

Same of course but you have soo
Much happening I think your reaction to us being together is
More one of stress
Than one of relief\.  I just
Don’t think that is healthy for you\.  Anyhow I am sure you need to get ready for you doctors appt or
Your pedicure not sure which comes first


---

### 1491. msg_17638

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:38:51

Dr first :p


---

### 1492. msg_17639

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:39:07

Get to go back to Bay Street office building\. My dr is in that building


---

### 1493. msg_17640

**You** - 2025-06-05T09:39:29

https://youtu\.be/3HR2zpjl15U?si=S0jcIbIWSijUMAn\_


---

### 1494. msg_17641

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T09:44:49

Meh song\. Disappointing


---

### 1495. msg_17642

**You** - 2025-06-05T09:45:06

lol I didn’t liste


---

### 1496. msg_17643

**You** - 2025-06-05T09:45:12

Figured it would be


---

### 1497. msg_17644

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:07:02

Did you tell jim I had a stressful day yday? He checked in … in a way that maybe he knew lol


---

### 1498. msg_17645

**You** - 2025-06-05T10:07:36

I told him he may want to see how you are doing I feel like he can give you support I can’t and I wanted you to have it\.


---

### 1499. msg_17646

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:08:02

It was kind of obvious lol I think I know Jim too well


---

### 1500. msg_17647

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:08:19

I was talking to Erin at the time


---

### 1501. msg_17648

**You** - 2025-06-05T10:08:32

Probably still I was worried\.\. sorry\.


---

### 1502. msg_17649

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:08:47

I was like in my head… Scott said something


---

### 1503. msg_17650

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:08:49

Haha


---

### 1504. msg_17651

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:08:51

It’s fine


---

### 1505. msg_17652

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:09:25

k, I’m getting ready and then leaving


---

### 1506. msg_17653

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:09:32

❤️❤️


---

### 1507. msg_17654

**You** - 2025-06-05T10:09:33

Kk have a good day\.


---

### 1508. msg_17655

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T10:59:22

On my drive here I was like “too bad I didn’t have a driver to just drive me around bc I don’t like driving” lol is that mean? Ha


---

### 1509. msg_17656

**You** - 2025-06-05T11:03:34

It is inevitable\.


---

### 1510. msg_17657

**You** - 2025-06-05T11:03:49

And I would happily do it\.


---

### 1511. msg_17658

**You** - 2025-06-05T11:04:00

Would/will


---

### 1512. msg_17659

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:04:03

Lol whatever\. I’m in a bitchy mood\.


---

### 1513. msg_17660

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:04:20

I just drove to an appt\. Just a bitchy thought in my head


---

### 1514. msg_17661

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:04:21

lol


---

### 1515. msg_17662

**You** - 2025-06-05T11:04:22

🙁 sucks


---

### 1516. msg_17663

**You** - 2025-06-05T11:04:45

You will though\.\.


---

### 1517. msg_17664

**You** - 2025-06-05T11:04:58

There is that


---

### 1518. msg_17665

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:05:04

I will what?


---

### 1519. msg_17666

**You** - 2025-06-05T11:05:10

Have a driver


---

### 1520. msg_17667

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:05:17

Driving miss daisy?


---

### 1521. msg_17668

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:05:19

lol


---

### 1522. msg_17669

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:05:24

I do not need a driver


---

### 1523. msg_17670

**You** - 2025-06-05T11:05:26

I don’t mind driving around


---

### 1524. msg_17671

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:05:29

I think that is so weird


---

### 1525. msg_17672

**You** - 2025-06-05T11:05:42

It is common in many relationships


---

### 1526. msg_17673

**You** - 2025-06-05T11:05:51

For one to be the primary driver when they drove together


---

### 1527. msg_17674

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:05:51

>
Says who?


---

### 1528. msg_17675

**You** - 2025-06-05T11:06:02

It just is I will got it


---

### 1529. msg_17676

**You** - 2025-06-05T11:06:10

Gpt


---

### 1530. msg_17677

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:06:11

There is a diff between primary driver and being required to be driven places though


---

### 1531. msg_17678

**You** - 2025-06-05T11:06:25

Mmm I could make her go if I wanted


---

### 1532. msg_17679

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:06:26

I don’t think primary thing is weird


---

### 1533. msg_17680

**You** - 2025-06-05T11:06:30

And sometimes I have


---

### 1534. msg_17681

**You** - 2025-06-05T11:06:41

But when I don’t mind doing it it isn’t really a chore


---

### 1535. msg_17682

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:06:46

I know …


---

### 1536. msg_17683

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:06:50

Funny


---

### 1537. msg_17684

**You** - 2025-06-05T11:06:52

I look at things differently than you


---

### 1538. msg_17685

**You** - 2025-06-05T11:07:01

And not necessarily better


---

### 1539. msg_17686

**You** - 2025-06-05T11:07:21

Most things I do I know why I am doing them\.\.


---

### 1540. msg_17687

**You** - 2025-06-05T11:08:01

The stuff I do for Jaimie now isn’t because I want to or want to spend time with her\.\. it is because kf
I do she will be just a bit happier and easier to get along with as
We
Continue to separate


---

### 1541. msg_17688

**You** - 2025-06-05T11:08:53

And so far I have had full transparency to all communications with lawyer and been able to structure my own responses etc\.\. I made decisions I\. How pensions would be dealt with and insurance etc\.


---

### 1542. msg_17689

**You** - 2025-06-05T11:09:28

Reaction: 😮 from Meredith Lamb
I told her about us essentially this morning\.\. not what you would want\.\. but enough so that she got the message and wouldn’t be surprised when it eventually comes out


---

### 1543. msg_17690

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:12:17

My Timehop\. Now I feel guilty for taking the day off\. Lol but my mom told me not to go “crazy like last time” when I told her I started working out again this week so that may have influenced my day off today a bit

*1 attachment(s)*


---

### 1544. msg_17691

**You** - 2025-06-05T11:13:34

Eesh Lats and everything damn…


---

### 1545. msg_17692

**You** - 2025-06-05T11:15:04

I can’t wait to take you to the gym\.  Will be fun\.


---

### 1546. msg_17693

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:16:36

Look forward to that \(I mean, I have some work to do but will get there\)


---

### 1547. msg_17694

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:17:11

My time hop is full of ME doing kid shit and Andrew thinks it would be ok for them to be with me on weekends\. Like wtf\. Idiot\.


---

### 1548. msg_17695

**You** - 2025-06-05T11:18:39

Mer\.\. what he said wasn’t meant to make you think about whether it made sense or not\.\. it was meant to intimidate and hurt you\.\. nothing more\.  He doesn’t believe that even he isn’t that fucking stupid\.\. it was a ploy and a poorly thought out line\.


---

### 1549. msg_17696

**You** - 2025-06-05T11:18:44

One\.


---

### 1550. msg_17697

**You** - 2025-06-05T11:19:05

Btw you skipped over the I told Jaimie so I guess you are cool


---

### 1551. msg_17698

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:19:21

Oh didn’t see it … yikes just read that


---

### 1552. msg_17699

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:19:58

>
Maybe\. He is THAT stupid tho so probably believes it\. I feel like telling his mom on him\. Not going to


---

### 1553. msg_17700

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:20:24

>
Um why?


---

### 1554. msg_17701

**You** - 2025-06-05T11:21:15

She said something along the lines again on the drive in of being replaced and I will have a gf like a week after she leaves and I said yeah probably so she knows who\.\. I said I have been lonely for a long time and that isn’t a dig at
You\.\. but it is true\.\. and I don’t want to be\.\. I don’t think anyone should have to be\. No one replaces you\.\. but I do get to choose to keep
Moving forward with whoever I want\.


---

### 1555. msg_17702

**You** - 2025-06-05T11:21:50

>
I think it was said out of anger about the cottage he feeeks trapped and he wants
You to hurt and feel trapped
To\.


---

### 1556. msg_17703

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:24:02

>
Yeah… will let things sit for a bit\.


---

### 1557. msg_17704

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:24:12

>
What was the reaction


---

### 1558. msg_17705

**You** - 2025-06-05T11:24:36

I mean doesnt change my position in my thoughts about what you should and likely will do lol


---

### 1559. msg_17706

**You** - 2025-06-05T11:24:58

>
I think resigned\.\. I don’t know how hard she is going to fight me on this any more


---

### 1560. msg_17707

**You** - 2025-06-05T11:25:04

Like you she wants done


---

### 1561. msg_17708

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:26:00

Yeah the dragging on and on is probably the worst part of separation I’m learning\.


---

### 1562. msg_17709

**You** - 2025-06-05T11:26:15

It is\.\. especially when you continue to live together


---

### 1563. msg_17710

**You** - 2025-06-05T11:28:26

Anyhow there will still be covert operations\.\. cannot get around that\. But I don’t think I will need to wait that long now to let her know or at least respond honestly when asked


---

### 1564. msg_17711

**You** - 2025-06-05T11:31:06

Remember don’t worry about contraception or no any nonsense I am going to talk to my doc when he is back from vacation\.


---

### 1565. msg_17712

**You** - 2025-06-05T11:31:14

There might be side effects


---

### 1566. msg_17713

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T11:50:13

Still waiting\. She is very late today\!


---

### 1567. msg_17714

**You** - 2025-06-05T11:57:31

Mm reliance guy here was t water heater


---

### 1568. msg_17715

**You** - 2025-06-05T11:58:21

When they installed the water heater and attached the humidifier the installed it the wrong way and the humidifier cable melted in something hot from the water heater pin hole spraying water everywhere…
Gah


---

### 1569. msg_17716

**You** - 2025-06-05T11:58:26

Should be fixed shortly


---

### 1570. msg_17717

**You** - 2025-06-05T12:12:47

Still waiting?


---

### 1571. msg_17718

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:15:09

Nope done


---

### 1572. msg_17719

**You** - 2025-06-05T12:15:26

Hopefully uneventful


---

### 1573. msg_17720

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:16:33

Yep\. She thinks I should go in anything estrogen based so maybe iud\. She is going to email me\. I also go referred to dermatologist get checked for skin cancer lol


---

### 1574. msg_17721

**You** - 2025-06-05T12:16:49

Why


---

### 1575. msg_17722

**You** - 2025-06-05T12:17:39

wtf


---

### 1576. msg_17723

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:18:19

Because I’m blonde and have lots of moles and stuff\. It is important\. My bro does it regularly


---

### 1577. msg_17724

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:18:56

Proactive


---

### 1578. msg_17725

**You** - 2025-06-05T12:38:00

Mmmmmmm


---

### 1579. msg_17726

**You** - 2025-06-05T12:38:12

And what about this estrogen thing?


---

### 1580. msg_17727

**You** - 2025-06-05T12:38:30

Isn’t there side effects?


---

### 1581. msg_17728

**You** - 2025-06-05T12:38:43

You are probably driving again\.\. sorry Gracie exploded at me


---

### 1582. msg_17729

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:49:54

Just got home and he is not here\. Ahhhh :\) :\)


---

### 1583. msg_17730

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:50:11

Estrogen is bad for my clotting gene variant\.


---

### 1584. msg_17731

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:50:48

I have a gene variant that can cause blood clotting\. Found out about it during genetic dna testing while in fertility years ago


---

### 1585. msg_17732

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:51:03

That’s what I was testing girls for at sick kids\. Gets passed on from parent


---

### 1586. msg_17733

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:51:18

Relatively new gene discovered in the 80s


---

### 1587. msg_17734

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:51:38

Blood clots cause miscarriages so they test for it in fertility


---

### 1588. msg_17735

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T12:52:05

>
All ok there?


---

### 1589. msg_17736

**You** - 2025-06-05T12:55:05

Nope


---

### 1590. msg_17737

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:12:41

What’s wrong\.


---

### 1591. msg_17738

**You** - 2025-06-05T13:13:41

Gracie again\.\.


---

### 1592. msg_17739

**You** - 2025-06-05T13:13:46

We just cannot
Live
Together


---

### 1593. msg_17740

**You** - 2025-06-05T13:14:12

>
Ok then why go on an estrogen solution


---

### 1594. msg_17741

**You** - 2025-06-05T13:14:16

Let me get the surgery


---

### 1595. msg_17742

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:14:23

She said NOT to


---

### 1596. msg_17743

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:14:33

So she is going to email me re: an iud


---

### 1597. msg_17744

**You** - 2025-06-05T13:14:34

Oh your text
Didnt say that


---

### 1598. msg_17745

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:14:34

She said


---

### 1599. msg_17746

**You** - 2025-06-05T13:14:41

Ok


---

### 1600. msg_17747

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:14:53

Oh sorry typo\!


---

### 1601. msg_17748

**You** - 2025-06-05T13:14:55

But still that has side effects too I think


---

### 1602. msg_17749

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:15:15

One of my good friends loves it


---

### 1603. msg_17750

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:15:20

So depends probably


---

### 1604. msg_17751

**You** - 2025-06-05T13:15:33

I think it cancels your period


---

### 1605. msg_17752

**You** - 2025-06-05T13:16:26

Well the hormonal kids do


---

### 1606. msg_17753

**You** - 2025-06-05T13:16:35

Iuds


---

### 1607. msg_17754

**You** - 2025-06-05T13:16:48

I just don’t understand


---

### 1608. msg_17755

**You** - 2025-06-05T13:16:58

I am HAPPY to do this


---

### 1609. msg_17756

**You** - 2025-06-05T13:17:14

I am never having more children anyways


---

### 1610. msg_17757

**You** - 2025-06-05T13:18:10

I just don’t want you to have to go through something that puts you at risk or anything of side effects etc


---

### 1611. msg_17758

**You** - 2025-06-05T13:19:00

Worried


---

### 1612. msg_17759

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:19:21

She is going to email me\. We will see she doesn’t insert them so I’d go elsewhere anyway\. It isn’t a worry right now\. Nothing in motion\.


---

### 1613. msg_17760

**You** - 2025-06-05T13:19:30

Ok


---

### 1614. msg_17761

**You** - 2025-06-05T13:20:01

Well I am sure you are flad that is over and done with\.\. now just a pedicure to top your day off


---

### 1615. msg_17762

**You** - 2025-06-05T13:22:05

>
Again and still I don’t understand your reticence to allow me to address this on my side\.\.


---

### 1616. msg_17763

**You** - 2025-06-05T13:37:53

ROFL


---

### 1617. msg_17764

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:38:00

So I was away on the weekend obviously and I have come home and had to clean up cat pee, like three times


---

### 1618. msg_17765

**You** - 2025-06-05T13:38:08

Fun


---

### 1619. msg_17766

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:38:13

The reason is because our two litter boxes were completely unuseable because I am the only one maintaining anything or taking care of the cats at all


---

### 1620. msg_17767

**You** - 2025-06-05T13:38:23

Yuck yeah


---

### 1621. msg_17768

**You** - 2025-06-05T13:38:25

I get that


---

### 1622. msg_17769

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:38:26

So I asked him today if we should surrender the cats to a rescue because with me leaving how are they gonna get taken care of?


---

### 1623. msg_17770

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:38:38

He says he’ll start taking care of them when I leave\. I said that’s not fair\. Help out now\.


---

### 1624. msg_17771

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:38:45

Then he tells me I’m bossing him around


---

### 1625. msg_17772

**You** - 2025-06-05T13:38:46

Jesus


---

### 1626. msg_17773

**You** - 2025-06-05T13:38:58

Ah so just flipping it


---

### 1627. msg_17774

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:39:09

So yeah, we’re just arguing about everything now


---

### 1628. msg_17775

**You** - 2025-06-05T13:39:15

Fantastic


---

### 1629. msg_17776

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:39:20

He thinks he’s helping to keep this house afloat because he does dishes occasionally


---

### 1630. msg_17777

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:39:38

Like honestly, you can’t even have a conversation with them\. I just need to stop engaging entirely so I just made a commitment to myself that I am going to do that from now on no matter what\.


---

### 1631. msg_17778

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:39:48

\*with him


---

### 1632. msg_17779

**You** - 2025-06-05T13:40:54

Well at least taxes are done and uploaded


---

### 1633. msg_17780

**You** - 2025-06-05T13:40:58

That is something


---

### 1634. msg_17781

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T13:42:58

Yeah omg


---

### 1635. msg_17782

**You** - 2025-06-05T14:02:09

I assume getting your feets done now or waiting


---

### 1636. msg_17783

**You** - 2025-06-05T14:02:27

just got back on computer and saw you typing something so just guessing


---

### 1637. msg_17784

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:03:33

>
I feel like guys generally are not happy to do this\. Women are most used to doing shit\. Lol babies and stuff\. Andrew resisted for a long time so I know it is a big deal :p


---

### 1638. msg_17785

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:03:39

It’s okay


---

### 1639. msg_17786

**You** - 2025-06-05T14:03:47

It isn't


---

### 1640. msg_17787

**You** - 2025-06-05T14:03:52

I am not saying it just because


---

### 1641. msg_17788

**You** - 2025-06-05T14:04:13

Look I am just going to do it anyways\.\. so you do whatever you want to do lol\.


---

### 1642. msg_17789

**You** - 2025-06-05T14:04:59

I just have to wait for My dr to come back from vacation\.


---

### 1643. msg_17790

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:05:36

I feel like you have a lot going on medically that you don’t need anything else right now lol


---

### 1644. msg_17791

**You** - 2025-06-05T14:06:13

what do you mean\.\. "I" do


---

### 1645. msg_17792

**You** - 2025-06-05T14:06:19

you have more going on than me by far


---

### 1646. msg_17793

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:07:27

You take a lot of meds and stuff …\. I’ve been pretty consistently doing the same thing for years


---

### 1647. msg_17794

**You** - 2025-06-05T14:07:39

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


---

### 1648. msg_17795

**You** - 2025-06-05T14:07:44

I have gerd\.\. OMG\!\!\!


---

### 1649. msg_17796

**You** - 2025-06-05T14:08:20

I have high blood pressure \*barely\* and take the lowest dose possible\.  I take a voluntariy cholesteral drug which is more like a suppliment and I take an ED pill\.\. because why the fuck not\.


---

### 1650. msg_17797

**You** - 2025-06-05T14:08:34

I have sleep apnea which is treated\.\. and much much better\.


---

### 1651. msg_17798

**You** - 2025-06-05T14:08:37

so I think I am fine\.


---

### 1652. msg_17799

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:09:01

lol


---

### 1653. msg_17800

**You** - 2025-06-05T14:09:06

I can get snipped\.\. I would rather that then you get some kind of hormonal device or copper device shoved in you\.\. unfair


---

### 1654. msg_17801

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:09:07

Quite a summary


---

### 1655. msg_17802

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:09:28

Well I wouldn’t mind not having a period tbh


---

### 1656. msg_17803

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:09:32

So not all bad


---

### 1657. msg_17804

**You** - 2025-06-05T14:09:56

you are going to do whatever you want anyways\.\.\.\.\.\.\.  I already realize I won't be wearing shorts let alone pants in this relationship\.


---

### 1658. msg_17805

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:10:53

lol stop


---

### 1659. msg_17806

**You** - 2025-06-05T14:12:21

see\.\. you only say that when you know I am right


---

### 1660. msg_17807

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:12:46

Errr


---

### 1661. msg_17808

**You** - 2025-06-05T14:12:47

that's like "noooo stop it\.\. that's not true" \(as she thinks to herself\.\. totally is\!\!\)


---

### 1662. msg_17809

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:13:28

I do like to do what I want\. Not going to argue with that\.


---

### 1663. msg_17810

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:13:31

lol


---

### 1664. msg_17811

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:13:54

However, you are an adult and I won’t tell you what to do \(all the time\)


---

### 1665. msg_17812

**You** - 2025-06-05T14:14:24

just this and many more instances\.\.


---

### 1666. msg_17813

**You** - 2025-06-05T14:14:33

I still may not listen\.\. we'll see


---

### 1667. msg_17814

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:21:20

We have lots of “we’ll seeing” to do :\)


---

### 1668. msg_17815

**You** - 2025-06-05T14:21:41

whatever you say dear\.


---

### 1669. msg_17816

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:22:07

So what was Gracie’s beef today


---

### 1670. msg_17817

**You** - 2025-06-05T14:23:39

Reaction: 😮 from Meredith Lamb
Same shit\.\. she wanted wanted wanted\.\. and I said no\.\. she wants me to go spend a bunch of money on stuff\. and I refused\.\. she does nothing to add value\.\. she won't grow up\.\. it got heated\.\. she called Jaimie\.\. she freaked out started smashing something on the floor and we said if she continued she would be removed\.  Good times all around\.


---

### 1671. msg_17818

**You** - 2025-06-05T14:24:13

I mean trust me I don't just sit there meek and mild\.\. I engage and I shouldn't and in the real world I wouldn't  but there is sooooooo much history and shit here it is hard not to\.


---

### 1672. msg_17819

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:26:04

Yeah that is how I feel with Andrew\. Sooooo hard not to engage\. I get it\.


---

### 1673. msg_17820

**You** - 2025-06-05T14:26:54

This is just an impossible situation\.\. and I feel very much a bad father and husband\.\. and I wish I could have done a better job\.\.


---

### 1674. msg_17821

**You** - 2025-06-05T14:27:01

It is what it is though


---

### 1675. msg_17822

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:27:08

Her therapist doesn’t help at all??


---

### 1676. msg_17823

**You** - 2025-06-05T14:27:18

nope\.\. she doesn't tell her therapist the whole truth


---

### 1677. msg_17824

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:27:41

Ahhh ok yeah that’s a problem


---

### 1678. msg_17825

**You** - 2025-06-05T14:27:53

see gracie won't own up to it or face it\.\. she blames everyone els


---

### 1679. msg_17826

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:27:57

But the therapist must know she doesn’t go to school nor work?


---

### 1680. msg_17827

**You** - 2025-06-05T14:27:59

and until she does\.


---

### 1681. msg_17828

**You** - 2025-06-05T14:28:04

>
yes


---

### 1682. msg_17829

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:28:14

Are they trying to address that


---

### 1683. msg_17830

**You** - 2025-06-05T14:28:19

we wouldn't know


---

### 1684. msg_17831

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:28:27

Gah


---

### 1685. msg_17832

**You** - 2025-06-05T14:28:29

she is 18 and even then we don't have contact with therapist


---

### 1686. msg_17833

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:29:57

Seems a little impossible


---

### 1687. msg_17834

**You** - 2025-06-05T14:32:26

it is J and I agree there is not likely to be any kind of reconciliation between Gracie and I for some time\.\. she needs to really get professional help\.\. I tried to explain that to her\.\. we aren't equipped for this\.\. and she just said she wants compassion\.\. and I said no\.\. that just empowers you to keep doing what you are doing\.\. you need a boot in the ass\.


---

### 1688. msg_17835

**You** - 2025-06-05T14:32:32

and then\.\. well you can guess


---

### 1689. msg_17836

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:33:09

I think I can guess…\. Smash


---

### 1690. msg_17837

**You** - 2025-06-05T14:33:14

yep


---

### 1691. msg_17838

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:33:15

Compassion


---

### 1692. msg_17839

**You** - 2025-06-05T14:33:27

thats what she says\.\.


---

### 1693. msg_17840

**You** - 2025-06-05T14:33:34

but tbh\.\.


---

### 1694. msg_17841

**You** - 2025-06-05T14:33:44

I don't have any\.\. it has been so bad for so long\.\.


---

### 1695. msg_17842

**You** - 2025-06-05T14:33:56

I tried to explain the empty glass concept to her


---

### 1696. msg_17843

**You** - 2025-06-05T14:34:08

but she just says you are my parent and I should be able to do anything\.


---

### 1697. msg_17844

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:34:21

Oh boy


---

### 1698. msg_17845

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:35:08

Maybe you should try family counselling??


---

### 1699. msg_17846

**You** - 2025-06-05T14:35:42

It would never work\.\. again\.\. she cannot face the truth


---

### 1700. msg_17847

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:35:50

Then you can hear what the counsellor says tho


---

### 1701. msg_17848

**You** - 2025-06-05T14:35:53

she has segmented it off, suppressed it\.


---

### 1702. msg_17849

**You** - 2025-06-05T14:36:06

We could\.\. maybe J and her could do it in Moncton


---

### 1703. msg_17850

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:36:21

It might be money better spent


---

### 1704. msg_17851

**You** - 2025-06-05T14:36:22

I am literally just trying to survive here\.


---

### 1705. msg_17852

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:41:12

Just had a hot stone leg and foot massage\. Feel better LOL


---

### 1706. msg_17853

**You** - 2025-06-05T14:41:25

\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.\.


---

### 1707. msg_17854

**You** - 2025-06-05T14:41:36

well after last night\.\. and in general


---

### 1708. msg_17855

**You** - 2025-06-05T14:41:39

you deserve it


---

### 1709. msg_17856

**You** - 2025-06-05T14:41:50

I didn't book my massage


---

### 1710. msg_17857

**You** - 2025-06-05T14:43:02

hmm I could go for an hour at 6:45 tonight


---

### 1711. msg_17858

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:43:29

Told Mac I was going today and she was like “get a facial too” … thinks I’m made of $ lol


---

### 1712. msg_17859

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:43:40

>
You should


---

### 1713. msg_17860

**You** - 2025-06-05T14:43:46

you should come to lifetime\.\. they got this cool hydrafacial thing


---

### 1714. msg_17861

**You** - 2025-06-05T14:43:51

hydro


---

### 1715. msg_17862

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:44:11

I’m not a big facial person\. Sensitive skin


---

### 1716. msg_17863

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:44:19

I always come out looking red


---

### 1717. msg_17864

**You** - 2025-06-05T14:46:04

I have never had one\.


---

### 1718. msg_17865

**You** - 2025-06-05T14:46:59

hmm I think massage then sauna\.\. then shower then home maybe\.\. :\)


---

### 1719. msg_17866

**You** - 2025-06-05T14:49:26

Reaction: ❤️ from Meredith Lamb
booked


---

### 1720. msg_17867

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:52:16

I’m on my way home\. I have a brutal headache though like every day this week brutal week\.


---

### 1721. msg_17868

**You** - 2025-06-05T14:52:40

That sucks\.\. I hope he still isn't there


---

### 1722. msg_17869

**You** - 2025-06-05T14:52:45

do you have to drive tonight\.\.


---

### 1723. msg_17870

**You** - 2025-06-05T14:52:51

and stay off work comp pls\.


---

### 1724. msg_17871

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T14:57:33

He’s not here\. I only have to drive to Maelle’s bronze and back tonight\. Nothing too big\.


---

### 1725. msg_17872

**You** - 2025-06-05T15:02:14

Kk well that isn’t so bad


---

### 1726. msg_17873

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:13:10

Having protein shake and aleve for the head ache


---

### 1727. msg_17874

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:36:14

Deb, emailed me a welcome back today lol


---

### 1728. msg_17875

**You** - 2025-06-05T15:36:30

lol well isn’t that nice


---

### 1729. msg_17876

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:36:33

Have to admit it kind of made me feel special


---

### 1730. msg_17877

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:36:35

Hahahah


---

### 1731. msg_17878

**You** - 2025-06-05T15:36:42

Whatever


---

### 1732. msg_17879

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:36:49

LOL


---

### 1733. msg_17880

**You** - 2025-06-05T15:37:04

Reaction: 😂 from Meredith Lamb
Whenever I try to make you feel special you are like meh or w/e


---

### 1734. msg_17881

**You** - 2025-06-05T15:37:06

lol


---

### 1735. msg_17882

**You** - 2025-06-05T15:37:12

Jk


---

### 1736. msg_17883

**You** - 2025-06-05T15:37:20

Just to be clear because you never get them


---

### 1737. msg_17884

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:38:11

I just feel like she wouldn’t have done that for just anyone


---

### 1738. msg_17885

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:38:13

lol


---

### 1739. msg_17886

**You** - 2025-06-05T15:38:25

Nope you are right


---

### 1740. msg_17887

**You** - 2025-06-05T15:38:44

She does actually like you beyond just that
You are a good worker as I understand it


---

### 1741. msg_17888

**You** - 2025-06-05T15:38:48

Although that helps


---

### 1742. msg_17889

**You** - 2025-06-05T15:38:59

Sec driving f maddie


---

### 1743. msg_17890

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T15:40:21

I’m driving Mac lol


---

### 1744. msg_17891

**You** - 2025-06-05T16:08:05

Back


---

### 1745. msg_17892

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:11:40

I’m at park with dogs\. It is really nice out here…


---

### 1746. msg_17893

**You** - 2025-06-05T16:18:45

Draft sep agreement here haven’t opened yet


---

### 1747. msg_17894

**You** - 2025-06-05T16:18:50

Waiting for j permission


---

### 1748. msg_17895

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:22:20

What? Really?


---

### 1749. msg_17896

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:22:24

lol funny


---

### 1750. msg_17897

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:23:44

I’m so freaking jealous you are at this point


---

### 1751. msg_17898

**You** - 2025-06-05T16:26:55

Not really at any point yet\.


---

### 1752. msg_17899

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:27:15

I mean further than me


---

### 1753. msg_17900

**You** - 2025-06-05T16:51:29

it isn't looking pretty I need to do some math


---

### 1754. msg_17901

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:52:16

What seriously?


---

### 1755. msg_17902

**You** - 2025-06-05T16:52:26

yeah\.\. like really bad\.\.


---

### 1756. msg_17903

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T16:52:36

Holy crap


---

### 1757. msg_17904

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:08:41

You alright? Are you doing math?


---

### 1758. msg_17905

**You** - 2025-06-05T17:09:07

yeah


---

### 1759. msg_17906

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:16:26

Have you figured out how it is so much off of what you had?


---

### 1760. msg_17907

**You** - 2025-06-05T17:16:34

is andrew there\.


---

### 1761. msg_17908

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:16:40

No


---

### 1762. msg_17909

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:16:49

At vball with marmar


---

### 1763. msg_17910

**You** - 2025-06-05T17:16:52

ah nm


---

### 1764. msg_17911

**You** - 2025-06-05T17:16:59

I was going to teams you and share my screen\.


---

### 1765. msg_17912

**You** - 2025-06-05T17:17:04

are you in car waiting or watching


---

### 1766. msg_17913

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:17:12

I’m at my computer


---

### 1767. msg_17914

**You** - 2025-06-05T17:17:21

yeah but I cannot teams you it will be outloud


---

### 1768. msg_17915

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:17:36

I’m in the office with door shut


---

### 1769. msg_17916

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:17:42

Reaction: 👍 from Scott Hicks
Andrew is at vball with Marlowe


---

### 1770. msg_17917

**You** - 2025-06-05T17:17:43

Oh shit nm


---

### 1771. msg_17918

**You** - 2025-06-05T17:17:46

I thought you were


---

### 1772. msg_17919

**You** - 2025-06-05T17:17:48

bah


---

### 1773. msg_17920

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:17:52

No


---

### 1774. msg_17921

**You** - 2025-06-05T17:17:56

ok one sec


---

### 1775. msg_17922

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:17:58

I do swimming later


---

### 1776. msg_17923

**You** - 2025-06-05T17:18:00

I already figured it out


---

### 1777. msg_17924

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T17:18:52

7\.30


---

### 1778. msg_17925

**You** - 2025-06-05T17:19:41


*1 attachment(s)*


---

### 1779. msg_17926

**You** - 2025-06-05T18:22:02

A strategic withdrawal if I ever saw one


---

### 1780. msg_17927

**You** - 2025-06-05T18:22:20

Hope that wasn’t too obvious


---

### 1781. msg_17928

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:23:06

lol


---

### 1782. msg_17929

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:23:16

Been there


---

### 1783. msg_17930

**You** - 2025-06-05T18:25:08

No you didn’t get it


---

### 1784. msg_17931

**You** - 2025-06-05T18:25:10

That’s ok


---

### 1785. msg_17932

**You** - 2025-06-05T18:25:13

Next time maybe


---

### 1786. msg_17933

**You** - 2025-06-05T18:25:25

❤️


---

### 1787. msg_17934

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:26:54

Oh I get it now


---

### 1788. msg_17935

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:26:55

lol


---

### 1789. msg_17936

**You** - 2025-06-05T18:27:53

Yeah I was getting a bit anxious was like ok can’t have this discussion yet time to go\.


---

### 1790. msg_17937

**You** - 2025-06-05T18:28:34

All I Remeber was last time offering to meet him and you stuttering through a response\.\.
lol so yeah……


---

### 1791. msg_17938

**You** - 2025-06-05T18:29:05

Reaction: 👍 from Meredith Lamb
Maybe we just don’t talk about that for a really long time unless we have to\.\. my fault for bringing him up\.


---

### 1792. msg_17939

**You** - 2025-06-05T18:29:17

Clearly I cannot handle yet\.\.


---

### 1793. msg_17940

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:30:58

Noted\.


---

### 1794. msg_17941

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:31:04

:\)


---

### 1795. msg_17942

**You** - 2025-06-05T18:31:10

Noted sounds so bad\.\.


---

### 1796. msg_17943

**You** - 2025-06-05T18:31:13

But ok


---

### 1797. msg_17944

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:33:38

I mean, I’m just trying to articulate that I understand\.


---

### 1798. msg_17945

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:46:33

I’m talking to my parents\. Are you ok?


---

### 1799. msg_17946

**You** - 2025-06-05T18:48:28

Just going into session


---

### 1800. msg_17947

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T18:48:47

kk


---

### 1801. msg_17948

**You** - 2025-06-05T20:12:04

Reaction: ❤️ from Meredith Lamb
Going to jump in sauna then shower then head home\.


---

### 1802. msg_17949

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:13:41

I’m here


---

### 1803. msg_17950

**You** - 2025-06-05T20:36:32

Just have to run to get Gracie a cart……\.\.


---

### 1804. msg_17951

**You** - 2025-06-05T20:36:40

Fml


---

### 1805. msg_17952

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:36:48

lol


---

### 1806. msg_17953

**You** - 2025-06-05T20:41:47

Still want me to book I just wanted to make sure before I did…\.


---

### 1807. msg_17954

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:42:15

Sure if you are ok with it\.  What if I start talking?


---

### 1808. msg_17955

**You** - 2025-06-05T20:42:50

Hmm?  You mean if I get a phone call??


---

### 1809. msg_17956

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:43:19

I mean if I start talking about shit you don’t prefer to hear about…\.


---

### 1810. msg_17957

**You** - 2025-06-05T20:43:39

I don’t know we will have to find out\.


---

### 1811. msg_17958

**You** - 2025-06-05T20:44:06

Can you call or is Andrew home


---

### 1812. msg_17959

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:44:10

🙁


---

### 1813. msg_17960

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:44:26

I’m on the phone with my parents still


---

### 1814. msg_17961

**You** - 2025-06-05T20:44:37

Ah ok wel stay on with them


---

### 1815. msg_17962

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:44:43

Andrew is home :p


---

### 1816. msg_17963

**You** - 2025-06-05T20:44:44

Dunno what sad face is for


---

### 1817. msg_17964

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:45:22

Sad face is bc you think I will start talking about shit you don’t want to hear about\.


---

### 1818. msg_17965

**You** - 2025-06-05T20:45:45

I didn’t say that you said that


---

### 1819. msg_17966

**You** - 2025-06-05T20:45:51

And you asked what I would do


---

### 1820. msg_17967

**You** - 2025-06-05T20:45:58

And I said we will have to find out


---

### 1821. msg_17968

**You** - 2025-06-05T20:46:23

Glass number?


---

### 1822. msg_17969

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:46:34

>
And I responded with 😕


---

### 1823. msg_17970

**You** - 2025-06-05T20:46:34

❤️


---

### 1824. msg_17971

**You** - 2025-06-05T20:46:47

I know but I didn’t say you would do it


---

### 1825. msg_17972

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:46:49

>
No comment\.


---

### 1826. msg_17973

**You** - 2025-06-05T20:46:52

I yeah


---

### 1827. msg_17974

**You** - 2025-06-05T20:46:55

Yeah


---

### 1828. msg_17975

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:54:36

My mom has to have a ct scan tomorrow and doesn’t wan to drive herself


---

### 1829. msg_17976

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:54:41

I told her I’d go


---

### 1830. msg_17977

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:54:55

I’m like I have ONE meeting


---

### 1831. msg_17978

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:55:03

But my dad is going


---

### 1832. msg_17979

**You** - 2025-06-05T20:55:05

Nice of you\. Don’t book anything


---

### 1833. msg_17980

**You** - 2025-06-05T20:55:14

Just take it


---

### 1834. msg_17981

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:55:30

I was telling her about you driving Jaimie everywhere and she was like “uhhhhh I’m kind of the same way”


---

### 1835. msg_17982

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:55:46

I’m like “in my new job I can take you mom\!”


---

### 1836. msg_17983

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:55:51

lol


---

### 1837. msg_17984

**You** - 2025-06-05T20:57:57


*2 attachment(s)*


---

### 1838. msg_17985

**You** - 2025-06-05T20:58:33

Hehe


---

### 1839. msg_17986

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T20:58:52

I do t see an actual address


---

### 1840. msg_17987

**You** - 2025-06-05T20:59:08


*2 attachment(s)*


---

### 1841. msg_17988

**You** - 2025-06-05T20:59:41


*1 attachment(s)*


---

### 1842. msg_17989

**You** - 2025-06-05T20:59:51

Address there


---

### 1843. msg_17990

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:02:33

k, I lived with my great aunt for a year while I was pregnant with Mackenzie on ellerslie right near there while I worked at union gas


---

### 1844. msg_17991

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:02:43

Think I know the area


---

### 1845. msg_17992

**You** - 2025-06-05T21:09:38

Sigh omw home now


---

### 1846. msg_17993

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:12:31

Still talking, still drinking\. Eeeeeek


---

### 1847. msg_17994

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:13:00

So you did a massage?


---

### 1848. msg_17995

**You** - 2025-06-05T21:13:09

Yeah ur not working out


---

### 1849. msg_17996

**You** - 2025-06-05T21:13:11

lol


---

### 1850. msg_17997

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:13:17

I am\!


---

### 1851. msg_17998

**You** - 2025-06-05T21:13:25

6 glasses


---

### 1852. msg_17999

**You** - 2025-06-05T21:13:26

Nope


---

### 1853. msg_18000

**You** - 2025-06-05T21:13:44

Nope nope nope


---

### 1854. msg_18001

**You** - 2025-06-05T21:14:04

No judgement after kast night you needed this


---

### 1855. msg_18002

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:14:19

My mom is giving my highlights okc vs Indiana bball game


---

### 1856. msg_18003

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:14:24

They are obsessed


---

### 1857. msg_18004

**You** - 2025-06-05T21:14:31

lol


---

### 1858. msg_18005

**You** - 2025-06-05T21:14:38

Go shae


---

### 1859. msg_18006

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:15:12

Shae is winning :\(


---

### 1860. msg_18007

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:15:18

We like pascal


---

### 1861. msg_18008

**You** - 2025-06-05T21:15:24

lol


---

### 1862. msg_18009

**You** - 2025-06-05T21:15:38

I used to make fun of the noise he made when the tried to draw a foul


---

### 1863. msg_18010

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:15:42

I’m getting the play by play


---

### 1864. msg_18011

**You** - 2025-06-05T21:15:51

It was like some baby animal crying


---

### 1865. msg_18012

**You** - 2025-06-05T21:16:49

But I love pascal too watched him since bench mob


---

### 1866. msg_18013

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:17:41

Yeah we like pascal and og and og lost :\(


---

### 1867. msg_18014

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:18:03

I don’t watch bball anymore


---

### 1868. msg_18015

**You** - 2025-06-05T21:18:13

I could dunk on your mom btw\.


---

### 1869. msg_18016

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:18:29

Yes she has shrunk


---

### 1870. msg_18017

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:18:31

lol


---

### 1871. msg_18018

**You** - 2025-06-05T21:18:35

Just saying


---

### 1872. msg_18019

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:18:46

She used to be 5’7”


---

### 1873. msg_18020

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:18:55

Of 5’6”


---

### 1874. msg_18021

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:19:17

Oh she said 5’6”


---

### 1875. msg_18022

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:19:25

So I’m taller than her


---

### 1876. msg_18023

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:19:29

She has shrunk


---

### 1877. msg_18024

**You** - 2025-06-05T21:19:29

lol


---

### 1878. msg_18025

**You** - 2025-06-05T21:34:55

Home with a crying kid omfg she never stops


---

### 1879. msg_18026

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:37:15

Why is she crying???


---

### 1880. msg_18027

**You** - 2025-06-05T21:38:20

Cause it is all she ever does about everything
It is like she regressed to like 10


---

### 1881. msg_18028

**You** - 2025-06-05T21:38:44

She projects her feelings onto the dog, she makes
Up memories that don’t exist


---

### 1882. msg_18029

**You** - 2025-06-05T21:38:47

It is messed up


---

### 1883. msg_18030

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:38:59

😢


---

### 1884. msg_18031

**You** - 2025-06-05T21:39:10

Omg soo annoying


---

### 1885. msg_18032

**You** - 2025-06-05T21:39:14

As you would say


---

### 1886. msg_18033

**You** - 2025-06-05T21:39:54

Did you tell your mum I chickened out


---

### 1887. msg_18034

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:40:04

Chickened out? No


---

### 1888. msg_18035

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:40:16

I haven’t told her anything


---

### 1889. msg_18036

**You** - 2025-06-05T21:40:26

I meant about meeting her


---

### 1890. msg_18037

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:40:28

We have been talking about anything


---

### 1891. msg_18038

**You** - 2025-06-05T21:40:31

Ok


---

### 1892. msg_18039

**You** - 2025-06-05T21:40:42

I meant this weekend


---

### 1893. msg_18040

**You** - 2025-06-05T21:40:56

Not sure if you are thinking about something else


---

### 1894. msg_18041

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:41:09

We are talking about how I would have been “Scott” if I was a boy


---

### 1895. msg_18042

**You** - 2025-06-05T21:41:25

Oh yeah the name


---

### 1896. msg_18043

**You** - 2025-06-05T21:41:39

You should tell her about the song…\. LAME


---

### 1897. msg_18044

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:42:11

I will leave that out for now unless you send it to me again


---

### 1898. msg_18045

**You** - 2025-06-05T21:42:28

No I figured you didn’t remember anyways


---

### 1899. msg_18046

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:42:43

Of course I remember


---

### 1900. msg_18047

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:42:57

Scott is generally a name in my family tho


---

### 1901. msg_18048

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:43:21

I have a second cousin who is younger than me … Scotty


---

### 1902. msg_18049

**You** - 2025-06-05T21:44:28

No shit from Andrew tonight seeing as
You are on phone\.\. did you share what he said


---

### 1903. msg_18050

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:47:45

Of course I did


---

### 1904. msg_18051

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:47:49

I sent screenshots


---

### 1905. msg_18052

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:47:54

And emails


---

### 1906. msg_18053

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:47:56

Etc


---

### 1907. msg_18054

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:47:58

lol


---

### 1908. msg_18055

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:48:10

My mom didn’t msg back and I was like WTF


---

### 1909. msg_18056

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:48:28

apparently she walked with my aunt and had a nap


---

### 1910. msg_18057

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:48:39

Andrew is in other room


---

### 1911. msg_18058

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:48:49

I am in office with door shut


---

### 1912. msg_18059

**You** - 2025-06-05T21:49:10

Wow so we will have to wait to see what your mum thinks


---

### 1913. msg_18060

**You** - 2025-06-05T21:49:48

It is 10 am not 9 am but I will
Meet you for breakfast if you want 🙂


---

### 1914. msg_18061

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:56:01

Wait tomorrow?


---

### 1915. msg_18062

**You** - 2025-06-05T21:56:07

Sat


---

### 1916. msg_18063

**You** - 2025-06-05T21:56:14

………


---

### 1917. msg_18064

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:56:44

k bc mar was just in here complaining that she needs to go grad dress shopping


---

### 1918. msg_18065

**You** - 2025-06-05T21:57:09

I can cancel Saturday it is free cancellation\.


---

### 1919. msg_18066

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:57:14

No


---

### 1920. msg_18067

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:57:42

She has fun fair sat


---

### 1921. msg_18068

**You** - 2025-06-05T21:58:51

Kk well you let me know about breakfast I feel like the conversation took an s turn lol


---

### 1922. msg_18069

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T21:59:12

S turn?


---

### 1923. msg_18070

**You** - 2025-06-05T21:59:48

I told you instead
Of 9\-5 it is 10\-5 on sat but we could still meet at 9’dor breakfast


---

### 1924. msg_18071

**You** - 2025-06-05T22:00:11

Then something happened lol and you thought it was tomorrow and then something about dress shopping


---

### 1925. msg_18072

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:00:17

9 means I leave at 8


---

### 1926. msg_18073

**You** - 2025-06-05T22:01:26

Kk no breakfast all good maybe I can pick something up on the way and bring it in\.


---

### 1927. msg_18074

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:01:55

Ok so what time do I need to be there


---

### 1928. msg_18075

**You** - 2025-06-05T22:02:46

We have from 10\-5


---

### 1929. msg_18076

**You** - 2025-06-05T22:03:01

But look if it is inconvenient again free to cancel no issues


---

### 1930. msg_18077

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:04:15

No it is good


---

### 1931. msg_18078

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:04:23

Seriously


---

### 1932. msg_18079

**You** - 2025-06-05T22:06:31

Not feeling it is lol sorry too difficult lol


---

### 1933. msg_18080

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:07:15

>
k wait not understanding


---

### 1934. msg_18081

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:10:28

I think you need to be into’d to my parent ms


---

### 1935. msg_18082

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:10:41

I am going to take them on a trip


---

### 1936. msg_18083

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:11:08

Given this convo I’m on right now n


---

### 1937. msg_18084

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:11:30

You could come if you ever meet them


---

### 1938. msg_18085

**You** - 2025-06-05T22:12:06

Reaction: 😂 from Meredith Lamb
well as long as the trip isn't before the weekend of the 21


---

### 1939. msg_18086

**You** - 2025-06-05T22:12:26

or I could go Saturday after for an hour or so\.


---

### 1940. msg_18087

**You** - 2025-06-05T22:13:11

Sorry maybe it is the wine\.\. or the communicating by text\.\. it just didn't seem like you wanted to go\.\. you were busy etc\.\. and I get it\.  that is all I meant\.


---

### 1941. msg_18088

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:21:01

I do want to


---

### 1942. msg_18089

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:21:11

Still talking to my mom


---

### 1943. msg_18090

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:21:37

Trying to get her to drink kefir and fermented stuff


---

### 1944. msg_18091

**You** - 2025-06-05T22:21:36

I will meet her Sat after 5 if you want\.\. I just cannot stay too late\.


---

### 1945. msg_18092

**You** - 2025-06-05T22:21:51

>
lol why


---

### 1946. msg_18093

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:23:03

>
Let’s just get together you and I and we can go from there there\. Good plan?


---

### 1947. msg_18094

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:23:17

I’m a good planner


---

### 1948. msg_18095

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:23:20

;\)


---

### 1949. msg_18096

**You** - 2025-06-05T22:23:24

yeah you sure are\.\.


---

### 1950. msg_18097

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:23:39

😇


---

### 1951. msg_18098

**You** - 2025-06-05T22:25:25

well all I know is I will be there are 10 am


---

### 1952. msg_18099

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:26:12

Okay


---

### 1953. msg_18100

**You** - 2025-06-05T22:26:37

and I will be naked


---

### 1954. msg_18101

**You** - 2025-06-05T22:26:49

😛😛


---

### 1955. msg_18102

**You** - 2025-06-05T22:27:03

just wanted to see your reaction\.\.looks like you deleted


---

### 1956. msg_18103

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:27:25

My mom just said “you do realize you are 47, you are not supposed to be bringing ppl home at 47”


---

### 1957. msg_18104

**You** - 2025-06-05T22:27:46

>
what is the age that you are supposed to stop?


---

### 1958. msg_18105

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:27:49

But then we discussed and she changed her kind


---

### 1959. msg_18106

**You** - 2025-06-05T22:27:48

ask her


---

### 1960. msg_18107

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:27:52

Mind


---

### 1961. msg_18108

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:27:57

lol


---

### 1962. msg_18109

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:28:09

My mom just turned 80\. Dad is 83


---

### 1963. msg_18110

**You** - 2025-06-05T22:28:16

It is all relative then


---

### 1964. msg_18111

**You** - 2025-06-05T22:28:20

you can share that too LOL


---

### 1965. msg_18112

**You** - 2025-06-05T22:28:36

I will act appropriately 19


---

### 1966. msg_18113

**You** - 2025-06-05T22:28:40

Mrs\. Lamb and all


---

### 1967. msg_18114

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:28:45

My mom is relatively young docent her age \(ppl tell me\)


---

### 1968. msg_18115

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:29:01

\*despite


---

### 1969. msg_18116

**You** - 2025-06-05T22:29:16

the weird thing is going to be that she knows a lot about me already\.\. including some things that she shouldn't know


---

### 1970. msg_18117

**You** - 2025-06-05T22:29:25

at least nothing a parent back when I was a teen would know


---

### 1971. msg_18118

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:29:28

She is fine\. I’m talking to her


---

### 1972. msg_18119

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:29:40

4th quarter for game


---

### 1973. msg_18120

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:30:00

>
Like what?


---

### 1974. msg_18121

**You** - 2025-06-05T22:31:04

my trips to the cottage


---

### 1975. msg_18122

**You** - 2025-06-05T22:31:09

other naughty things we have done


---

### 1976. msg_18123

**You** - 2025-06-05T22:31:11

bnb


---

### 1977. msg_18124

**You** - 2025-06-05T22:31:17

the tryste\!\!


---

### 1978. msg_18125

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:36:26

lol yeah she knows about all that


---

### 1979. msg_18126

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:36:32

I’m not a good liar


---

### 1980. msg_18127

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:36:35

Sorry


---

### 1981. msg_18128

**You** - 2025-06-05T22:36:46

Yeah and I am worried about what other details she might know about


---

### 1982. msg_18129

**You** - 2025-06-05T22:36:54

since you are very open\.\. at least with her


---

### 1983. msg_18130

**You** - 2025-06-05T22:36:54

:\)


---

### 1984. msg_18131

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:37:02

Why would you be worried?


---

### 1985. msg_18132

**You** - 2025-06-05T22:37:23

based on what you shared I might not be\.\. but you have surprised me before lol


---

### 1986. msg_18133

**You** - 2025-06-05T22:37:44

I will give you a for example


---

### 1987. msg_18134

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:37:55

I’m fyi on speaker with my mom AND DAD all the time


---

### 1988. msg_18135

**You** - 2025-06-05T22:38:13

for example \- you told your 16 year old daughter\.\. you took a Plan B\.\. would you tell your parents that?


---

### 1989. msg_18136

**You** - 2025-06-05T22:38:15

lol


---

### 1990. msg_18137

**You** - 2025-06-05T22:38:30

pls say no


---

### 1991. msg_18138

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:38:33

I did not tell my parents that


---

### 1992. msg_18139

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:38:35

lol


---

### 1993. msg_18140

**You** - 2025-06-05T22:38:46

Reaction: 😂 from Meredith Lamb
just tell them I am a virgin\.


---

### 1994. msg_18141

**You** - 2025-06-05T22:38:53

there was a movie about me


---

### 1995. msg_18142

**You** - 2025-06-05T22:38:55

they can watch it


---

### 1996. msg_18143

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:38:59

But I told them stuff yday and my mom was pine TMI\!\!\!\!


---

### 1997. msg_18144

**You** - 2025-06-05T22:39:06

what stuff


---

### 1998. msg_18145

**You** - 2025-06-05T22:39:28

that you wished I had a mustache?


---

### 1999. msg_18146

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:41:54

>
No\. I love you the way you are\.


---

### 2000. msg_18147

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:42:11

Apparently pascal is not going to win :\(


---

### 2001. msg_18148

**You** - 2025-06-05T22:42:19

ok what was the TMI


---

### 2002. msg_18149

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:51:23

Huh?


---

### 2003. msg_18150

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:51:39

Pascal just missed a 3


---

### 2004. msg_18151

**You** - 2025-06-05T22:51:38

>
this


---

### 2005. msg_18152

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:51:50

Oh yeah


---

### 2006. msg_18153

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:51:52

lol


---

### 2007. msg_18154

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:52:01

I’m a bit too honest


---

### 2008. msg_18155

**You** - 2025-06-05T22:52:05

stark


---

### 2009. msg_18156

**You** - 2025-06-05T22:52:10

some might say


---

### 2010. msg_18157

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:52:14

Yeah


---

### 2011. msg_18158

**You** - 2025-06-05T22:52:17

ask your mum if that word works for you'


---

### 2012. msg_18159

**You** - 2025-06-05T22:52:21

she likes those words


---

### 2013. msg_18160

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:55:09

Pascal just missed 2 free shots


---

### 2014. msg_18161

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:55:20

Gah


---

### 2015. msg_18162

**You** - 2025-06-05T22:55:30

did he bleet?


---

### 2016. msg_18163

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:55:40

Bleet?


---

### 2017. msg_18164

**You** - 2025-06-05T22:58:27

Reaction: ❓ from Meredith Lamb
just ask your mom she would know\.\. every time he drives the lane\.\. he goes AHHHHHHHHHHHHHH whether he is touched or not lol\.


---

### 2018. msg_18165

**You** - 2025-06-05T22:58:36

i tried to make a drinking game out of it once


---

### 2019. msg_18166

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T22:59:39

Huh?


---

### 2020. msg_18167

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:01:39

I’m SO confused


---

### 2021. msg_18168

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:01:49

Is that fair?


---

### 2022. msg_18169

**You** - 2025-06-05T23:02:20

i mean it is kinda lame\.\. james harden does this stupid thing with his head to try to make it look like he gets hit every time he drives,\.


---

### 2023. msg_18170

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:05:05

Indiana won 111 to 110 with 110 seconds to go\!


---

### 2024. msg_18171

**You** - 2025-06-05T23:05:18

wow


---

### 2025. msg_18172

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:05:21

My mom is in shock


---

### 2026. msg_18173

**You** - 2025-06-05T23:05:22

lol


---

### 2027. msg_18174

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:05:29

I’m not watching lol


---

### 2028. msg_18175

**You** - 2025-06-05T23:05:30

bet she is excited


---

### 2029. msg_18176

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:05:44

Just getting the play by play


---

### 2030. msg_18177

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:05:45

Wait


---

### 2031. msg_18178

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:05:50

Game not done


---

### 2032. msg_18179

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:06:03

3 second to go\. My mom confused lol


---

### 2033. msg_18180

**You** - 2025-06-05T23:07:14

oh no\!\! lol


---

### 2034. msg_18181

**You** - 2025-06-05T23:08:14

https://www\.google\.com/search?q=pascal\+siakam\+makes\+a\+funny\+noise\+when\+trying\+to\+draw\+a\+foul&num=10&sca\_esv=d05be742535520f0&rlz=1C1ONGR\_enCA1104CA1104&tbas=0&sxsrf=AE3TifM5JKo6Uf0prY2e4d30\_17\-j9B6sQ:1749179185781&ei=MVtCaKq\_L\-CaptQP7LiomAI&start=10&sa=N&sstk=Ac65TH5hmEknQV\_AP7OvA8hbtwWATHkPUQZkc\_nfC8nUwtravcdqsj4cEqExL3xd4kF5iXwcOyITGZoLex8bS0A6H61zGsAkF\_\-TEA&ved=2ahUKEwjqm5Gg6NuNAxVgjYkEHWwcCiMQ8tMDegQIDRAG&biw=1920&bih=911&dpr=1\#fpstate=ive&vld=cid:e34516cc,vid:jUCK22X\_anM,st:0


---

### 2035. msg_18182

**You** - 2025-06-05T23:08:23

listen over and over between 2 and 3 seconds\.


---

### 2036. msg_18183

**You** - 2025-06-05T23:08:24

lol


---

### 2037. msg_18184

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:08:45

Reaction: ❤️ from Meredith Lamb
Indiana won


---

### 2038. msg_18185

**You** - 2025-06-05T23:08:54

and we all lived happily ever after


---

### 2039. msg_18186

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:09:04

lol


---

### 2040. msg_18187

**You** - 2025-06-05T23:09:05

hehe


---

### 2041. msg_18188

**You** - 2025-06-05T23:09:10

you hearted your own message


---

### 2042. msg_18189

**You** - 2025-06-05T23:09:11

LOL


---

### 2043. msg_18190

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:09:20

:\)


---

### 2044. msg_18191

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:09:31

I like 🏀


---

### 2045. msg_18192

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:09:40

But have no time to watch


---

### 2046. msg_18193

**You** - 2025-06-05T23:09:43

someday\.\.


---

### 2047. msg_18194

**You** - 2025-06-05T23:09:46

I enjoy it as well


---

### 2048. msg_18195

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:10:42

I made my grandpa a basketball cake   For his funeral at least :p


---

### 2049. msg_18196

**You** - 2025-06-05T23:10:55

eesh


---

### 2050. msg_18197

**You** - 2025-06-05T23:11:11

Holy Shit


---

### 2051. msg_18198

**You** - 2025-06-05T23:11:15

how did you pull that


---

### 2052. msg_18199

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:11:25

What do you mean eesh?


---

### 2053. msg_18200

**You** - 2025-06-05T23:11:33

>
This you were supposed to explain


---

### 2054. msg_18201

**You** - 2025-06-05T23:11:47

I flew right by it


---

### 2055. msg_18202

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:11:55

My grandpa was a big ball coach in Oshawa


---

### 2056. msg_18203

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:12:06

One minute


---

### 2057. msg_18204

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:25:20

I cant find the cake I made for my grandpa’s
Funeral\. My mom ins yapping on and on about it now


---

### 2058. msg_18205

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:28:58

No response?


---

### 2059. msg_18206

**You** - 2025-06-05T23:29:03

I am waiting


---

### 2060. msg_18207

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:29:17

Or are you mean


---

### 2061. msg_18208

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:29:20

lol


---

### 2062. msg_18209

**You** - 2025-06-05T23:29:20

waiting


---

### 2063. msg_18210

**You** - 2025-06-05T23:29:22

patiently


---

### 2064. msg_18211

**You** - 2025-06-05T23:29:27

calmly


---

### 2065. msg_18212

**You** - 2025-06-05T23:29:38

Reaction: 😂 from Meredith Lamb
lovingly??? yeah


---

### 2066. msg_18213

**You** - 2025-06-05T23:29:42

but still waiting


---

### 2067. msg_18214

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:30:38

Off with my parent


---

### 2068. msg_18215

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:31:04

My mom goes “well if Scott comes I have a shrub I need dug up”


---

### 2069. msg_18216

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:31:08

lol


---

### 2070. msg_18217

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:31:27

I’ll like “I’ll talk to you tomorrow”


---

### 2071. msg_18218

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:31:31

LOL


---

### 2072. msg_18219

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:31:43

She is always all about the work


---

### 2073. msg_18220

**You** - 2025-06-05T23:33:38

I can dig up a shrub


---

### 2074. msg_18221

**You** - 2025-06-05T23:33:41

\.\.\.\. now DISH


---

### 2075. msg_18222

**You** - 2025-06-05T23:42:01

cmon MER\!\!


---

### 2076. msg_18223

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:42:06

I am do confused n


---

### 2077. msg_18224

**You** - 2025-06-05T23:42:13

don't do me like this\!\!


---

### 2078. msg_18225

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:42:23

And dealing with stupid teen s


---

### 2079. msg_18226

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:42:40

They don’t have enough towels after showers


---

### 2080. msg_18227

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:42:45

😱


---

### 2081. msg_18228

**You** - 2025-06-05T23:42:48

I have been waiting 15 minutes ROFL\!\!


---

### 2082. msg_18229

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:43:08

Fml


---

### 2083. msg_18230

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:43:22

Sorry towel emergency


---

### 2084. msg_18231

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:43:23

Mg


---

### 2085. msg_18232

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:43:25

Omg


---

### 2086. msg_18233

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:43:36

So annoyed


---

### 2087. msg_18234

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:44:23

So I can either 1\. Talk irl or 2\. Go to bed


---

### 2088. msg_18235

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:44:36

I’m like ……\.\.


---

### 2089. msg_18236

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:44:46

My mom wore me


---

### 2090. msg_18237

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:45:02

She is talented at that


---

### 2091. msg_18238

**You** - 2025-06-05T23:46:18

\.\.\.\.\. I am glad you got that sorted


---

### 2092. msg_18239

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:46:44

Soooooo


---

### 2093. msg_18240

**You** - 2025-06-05T23:47:23

So yeah\.\. I feel like you are messing with me\.\. and not going to tell me anything\.\.\.\.\. again\.\.\.\.\.


---

### 2094. msg_18241

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:48:06

What?


---

### 2095. msg_18242

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:48:14

No


---

### 2096. msg_18243

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:48:28

I just don’t know if you can talk


---

### 2097. msg_18244

**You** - 2025-06-05T23:48:38

what do you mean\.\. yeah it is safe


---

### 2098. msg_18245

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:48:55

If you willl be triggered


---

### 2099. msg_18246

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:48:56

lol


---

### 2100. msg_18247

**You** - 2025-06-05T23:49:03

:\(


---

### 2101. msg_18248

**You** - 2025-06-05T23:49:09

kk nm don't tell me


---

### 2102. msg_18249

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:50:12

Do you want to go to bed and tomorrow or talk tonight?


---

### 2103. msg_18250

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:50:29

I am good either way


---

### 2104. msg_18251

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:50:32

lol


---

### 2105. msg_18252

**You** - 2025-06-05T23:50:36

I am gonna go to bed I think\.


---

### 2106. msg_18253

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:50:48

Rosie is settled into bed


---

### 2107. msg_18254

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:50:53

lol


---

### 2108. msg_18255

**You** - 2025-06-05T23:51:35

I am just going to stop asking questions\.\. they are all dangerous\.


---

### 2109. msg_18256

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:51:58

>
Omg I am so confused


---

### 2110. msg_18257

**You** - 2025-06-05T23:52:31

I asked about what you shared with your mom the TMI thinking it would be funny\.\. but you tell me I will be triggered\.\. like\.\.\.\.


---

### 2111. msg_18258

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:52:24

I was like we will talk tomorrow\. Everything is cool blah blah blah\.


---

### 2112. msg_18259

**You** - 2025-06-05T23:52:47

yeah bed time I think


---

### 2113. msg_18260

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:53:07

Oh my God say it’s kind of a in person conversation I mean OK on text\. How do I explain it?


---

### 2114. msg_18261

**You** - 2025-06-05T23:53:15

no


---

### 2115. msg_18262

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:53:27

I basically tell my mom a lot of the stuff to the extent where she is like OK too much


---

### 2116. msg_18263

**You** - 2025-06-05T23:53:37

you said if you explained it in person I would get triggered too\.\. no no\.\. pls\.\. don't explain\.


---

### 2117. msg_18264

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:53:42

So that is the baseline


---

### 2118. msg_18265

**You** - 2025-06-05T23:53:40

pls


---

### 2119. msg_18266

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:54:05

The baseline is TMI


---

### 2120. msg_18267

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:54:19

But I wouldn’t say I’ve told her everything obviously


---

### 2121. msg_18268

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:54:55

>
she is still my mother after all


---

### 2122. msg_18269

**You** - 2025-06-05T23:55:21

ok honestly\.\. you don't need to explain\.\. again\.\. if you think I will be triggered I sincerely don't want to know\.\.


---

### 2123. msg_18270

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:55:56

>
I don’t want you to hav me anxiety or stress or over me


---

### 2124. msg_18271

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:56:27

>
You won’t be at all\.


---

### 2125. msg_18272

**You** - 2025-06-05T23:57:03

I am so afraid to just tell you to call me and tell me\.\. because first you said I would be triggered now you are saying I won't\.\.\.\.\.\.\.\.\.


---

### 2126. msg_18273

**You** - 2025-06-05T23:57:35

Reaction: 😂 from Meredith Lamb
🤮🤮🤮🤮


---

### 2127. msg_18274

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:57:46

Sorry lol


---

### 2128. msg_18275

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:58:03

\(My mom was a mean girl\. I wasn’t\.\)


---

### 2129. msg_18276

**You** - 2025-06-05T23:58:20

I don't understand what that means?


---

### 2130. msg_18277

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:59:00

I’m my


---

### 2131. msg_18278

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:59:04

Omg


---

### 2132. msg_18279

**Meredith Lamb \(\+14169386001\)** - 2025-06-05T23:59:09

Typo


---

### 2133. msg_18280

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T00:00:19

If you can’t call me you get stuck with annoying texts\. If you call me you get stuck with equal annoyingness\.  No winning\.  Sorry


---

### 2134. msg_18281

**You** - 2025-06-06T00:00:54

Reaction: ❓ from Meredith Lamb
i am scared anxious and sweaty atm


---

### 2135. msg_18282

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T00:01:37

Another step for my mom\. Baby steps


---

### 2136. msg_18283

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T00:02:07

My dad would have been your best friend 2 months ago


---

### 2137. msg_18284

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T00:04:08

>
Huh? Why?


---

### 2138. msg_18285

**You** - 2025-06-06T00:04:49

You told me to call\.


---

### 2139. msg_18286

**You** - 2025-06-06T07:12:22

I am up\.\. gawd Mer\.\. I hope
You have been up
For an hour hitting that workout hard babe\. ❤️❤️❤️❤️❤️


---

### 2140. msg_18287

**You** - 2025-06-06T07:13:50

Reaction: ❤️ from Meredith Lamb
Love you hun, that was a really awkward yet endearing and fulfilling conversation \(in a kind of weird\) way\.  I hope you remember everything we talked about because we made some pretty intimate promises to each other 😇❤️❤️


---

### 2141. msg_18288

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:31:48

Ermagod…\.\. so tired\. I have no meetings today so will be working out at noonish\. Yawwwwwwwn


---

### 2142. msg_18289

**You** - 2025-06-06T08:32:07

Yah sure


---

### 2143. msg_18290

**You** - 2025-06-06T08:32:09

lol


---

### 2144. msg_18291

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:32:50

>
I mean no guarantees but hopefully\. Lol


---

### 2145. msg_18292

**You** - 2025-06-06T08:32:55

So how much do you remember


---

### 2146. msg_18293

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:33:56

Not sure literally just woke up\. :p I remember when we decided to go to bed and going to bed and that is a good sign lol


---

### 2147. msg_18294

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:34:17

But we talked forevvver


---

### 2148. msg_18295

**You** - 2025-06-06T08:34:22

Ok let’s test do you Remeber talking about snow?


---

### 2149. msg_18296

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:34:31

lol yes


---

### 2150. msg_18297

**You** - 2025-06-06T08:34:39

Ok then that should be good enough


---

### 2151. msg_18298

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:35:17

I remember the basics but maybe not every detail


---

### 2152. msg_18299

**You** - 2025-06-06T08:35:20

No it was fun\.\. and awkward\.\. but we \(powered\) through it


---

### 2153. msg_18300

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:35:27

LOL


---

### 2154. msg_18301

**You** - 2025-06-06T08:35:51

Reaction: ❤️ from Meredith Lamb
I Remeber telling you at the end I would rather be uncomfortable and know you that comfortable and not\.


---

### 2155. msg_18302

**You** - 2025-06-06T08:36:24

Anyhow you get up do your thing\.\. I might workout at noon as well unsure


---

### 2156. msg_18303

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:36:23


*1 attachment(s)*


---

### 2157. msg_18304

**You** - 2025-06-06T08:36:37

Poor Rosie scarred by the conversation


---

### 2158. msg_18305

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:36:52

>
I remember this too


---

### 2159. msg_18306

**You** - 2025-06-06T08:36:55

She heard so many bad things from Scott kissed a boy to sisters to all kinds


---

### 2160. msg_18307

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:37:27

It was pretty wild \- I enjoyed it all


---

### 2161. msg_18308

**You** - 2025-06-06T08:37:31

I’m Victoria Olivia and Emma for the record


---

### 2162. msg_18309

**You** - 2025-06-06T08:37:53

Memory still there\.\. sometimes fun to have


---

### 2163. msg_18310

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:38:10

I hope I remember everything\. Time will tell lol


---

### 2164. msg_18311

**You** - 2025-06-06T08:38:24

Yeah you won’t


---

### 2165. msg_18312

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:38:33

Probably not


---

### 2166. msg_18313

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:38:41

But you can refresh it


---

### 2167. msg_18314

**You** - 2025-06-06T08:38:41

Reaction: 😂 from Meredith Lamb
You didn’t Remeber last night what you said to me earlier in the night lol


---

### 2168. msg_18315

**You** - 2025-06-06T08:38:55

That is what had us going around about Chris


---

### 2169. msg_18316

**You** - 2025-06-06T08:39:04

Then you agreed if you hang we al hang


---

### 2170. msg_18317

**You** - 2025-06-06T08:39:18

Then I told
You I kissed a boy and you were like shit


---

### 2171. msg_18318

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:39:27

Omg I remember way too much about Chris\. :p


---

### 2172. msg_18319

**You** - 2025-06-06T08:39:36

Chris was
Prime time all night


---

### 2173. msg_18320

**You** - 2025-06-06T08:39:40

Then you admitted


---

### 2174. msg_18321

**You** - 2025-06-06T08:39:57

That if the situation was reversed you would not be comfortable in me reconnecting


---

### 2175. msg_18322

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:39:58

>
So weird\.


---

### 2176. msg_18323

**You** - 2025-06-06T08:40:05

It did resolve a lot


---

### 2177. msg_18324

**You** - 2025-06-06T08:40:15

If that is any consolation


---

### 2178. msg_18325

**You** - 2025-06-06T08:40:32

I mean you are fucking blind lol but it resolved\. A lot for me


---

### 2179. msg_18326

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:40:33

It is actually


---

### 2180. msg_18327

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:40:44

I am blind?\!


---

### 2181. msg_18328

**You** - 2025-06-06T08:40:45

What trend?\!\!\!\!\!\!\!


---

### 2182. msg_18329

**You** - 2025-06-06T08:40:48

lol


---

### 2183. msg_18330

**You** - 2025-06-06T08:40:52

Omfg


---

### 2184. msg_18331

**You** - 2025-06-06T08:41:05

Do you remember that


---

### 2185. msg_18332

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:41:41

Maybe if you refresh my memory, but not really


---

### 2186. msg_18333

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:41:48

Oh my God, I haven’t had coffee yet


---

### 2187. msg_18334

**You** - 2025-06-06T08:41:55

Jeremy gavin Andrew Scott


---

### 2188. msg_18335

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:41:58

This is a lot of trying to remember when I just got up


---

### 2189. msg_18336

**You** - 2025-06-06T08:42:01

Does that do it


---

### 2190. msg_18337

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:42:09

That isn’t a trend


---

### 2191. msg_18338

**You** - 2025-06-06T08:42:13

Yes it is


---

### 2192. msg_18339

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:42:15

There is no trend there


---

### 2193. msg_18340

**You** - 2025-06-06T08:42:17

4
Data points


---

### 2194. msg_18341

**You** - 2025-06-06T08:42:21

Is a trend


---

### 2195. msg_18342

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:42:27

No, everyone is so different\. There is no trend\.


---

### 2196. msg_18343

**You** - 2025-06-06T08:42:37

Every one of them was threatened by your relationship with Chris


---

### 2197. msg_18344

**You** - 2025-06-06T08:42:49

Reaction: 😂 from Meredith Lamb
And 2 didn’t even know it was sexual


---

### 2198. msg_18345

**You** - 2025-06-06T08:42:54

And they were still threatened


---

### 2199. msg_18346

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:42:55

Oh, right OK fine whatever


---

### 2200. msg_18347

**You** - 2025-06-06T08:42:58

lol


---

### 2201. msg_18348

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:43:06

I remember now


---

### 2202. msg_18349

**You** - 2025-06-06T08:43:08

So that should give you pause to reconsider


---

### 2203. msg_18350

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:43:16

See just need some refreshing lol


---

### 2204. msg_18351

**You** - 2025-06-06T08:43:20

Reaction: ❤️ from Meredith Lamb
Ok go get coffee eorking in saving my finances


---

### 2205. msg_18352

**You** - 2025-06-06T08:43:33

I will refresh your memory tomorrow


---

### 2206. msg_18353

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:43:47

Just let me have my coffee and think


---

### 2207. msg_18354

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:43:50

lol


---

### 2208. msg_18355

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:44:12

I have no meetings so am just going to wear my workout clothes until I finish my workout


---

### 2209. msg_18356

**You** - 2025-06-06T08:44:15

Interesting\.\. I wonder how many more stories you have… I have so many\.\.


---

### 2210. msg_18357

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:44:24

I have none


---

### 2211. msg_18358

**You** - 2025-06-06T08:44:28

What stfu


---

### 2212. msg_18359

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:44:29

You heard them all


---

### 2213. msg_18360

**You** - 2025-06-06T08:44:35

Bullshit


---

### 2214. msg_18361

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:44:38

Stick a fork in me


---

### 2215. msg_18362

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:44:46

That’s all I got


---

### 2216. msg_18363

**You** - 2025-06-06T08:44:46

The adventures you and Jeremy had cross Canada


---

### 2217. msg_18364

**You** - 2025-06-06T08:44:58

Why was Andrew so threatened by Jeremy


---

### 2218. msg_18365

**You** - 2025-06-06T08:45:09

You made Jeremy out to sound pretty weak\.\.


---

### 2219. msg_18366

**You** - 2025-06-06T08:45:22

I was the fucking boss


---

### 2220. msg_18367

**You** - 2025-06-06T08:45:23

lol


---

### 2221. msg_18368

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:45:28

>
Because he fucking snooped in my room and read my journal at the time


---

### 2222. msg_18369

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:45:38

Jeremy is weak


---

### 2223. msg_18370

**You** - 2025-06-06T08:45:40

Present day or old


---

### 2224. msg_18371

**You** - 2025-06-06T08:45:58

Well I am weak too\.\. ish atm that is


---

### 2225. msg_18372

**You** - 2025-06-06T08:46:06

But that is situational\.


---

### 2226. msg_18373

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:46:12

No you are not


---

### 2227. msg_18374

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:46:40

How did I make him sound weak?


---

### 2228. msg_18375

**You** - 2025-06-06T08:48:13

well


---

### 2229. msg_18376

**You** - 2025-06-06T08:49:02

we were debating as to whether or not Jeremy knew about Chris and all the sex\.\. and I said def not\.\. because no way he is cool with you sleeping at Chris' place knowing that


---

### 2230. msg_18377

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:49:12

>
This is funny because it is true I guess\.


---

### 2231. msg_18378

**You** - 2025-06-06T08:49:11

and you said he wouldn't have a say in it


---

### 2232. msg_18379

**You** - 2025-06-06T08:49:30

>
not funny\.\. disturbing\.\. and even more supports my position


---

### 2233. msg_18380

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:50:06

>
Chris and I were not having sex at that point\! Just hanging out… a lot\.


---

### 2234. msg_18381

**You** - 2025-06-06T08:50:17

and then you tried to defend but I slept on the couch blah blah\.\. and that is when I said\.\. well maybe me and Cheyenne should reconnect and I could sleep at her house and "not" have sex\.


---

### 2235. msg_18382

**You** - 2025-06-06T08:50:28

and you said\.\. mmmm


---

### 2236. msg_18383

**You** - 2025-06-06T08:50:29

no


---

### 2237. msg_18384

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:50:45

>
But it is true\! I did\.


---

### 2238. msg_18385

**You** - 2025-06-06T08:50:49

I didn'


---

### 2239. msg_18386

**You** - 2025-06-06T08:50:53

say you lied


---

### 2240. msg_18387

**You** - 2025-06-06T08:50:59

I said Jeremy would have lost his sht


---

### 2241. msg_18388

**You** - 2025-06-06T08:51:02

and you said fuck him


---

### 2242. msg_18389

**You** - 2025-06-06T08:51:06

so I knew he was weak


---

### 2243. msg_18390

**You** - 2025-06-06T08:51:30

I can promise you my reaction would be quite different\.  Just like yours would be as well\.\. even though we trust each other\.


---

### 2244. msg_18391

**You** - 2025-06-06T08:51:39

it is human nature\.


---

### 2245. msg_18392

**You** - 2025-06-06T08:51:50

Anyhow\.


---

### 2246. msg_18393

**You** - 2025-06-06T08:51:57

that is how I knew he was weak\.


---

### 2247. msg_18394

**You** - 2025-06-06T08:53:05

Doesn't matter\.\. when I finally meet Chris \- I will give him a huge hug\.\. and say omg I feel like I know you already Meredith has told me so much about you two\.\.\. like OMG\!\!


---

### 2248. msg_18395

**You** - 2025-06-06T08:53:15

😇


---

### 2249. msg_18396

**You** - 2025-06-06T08:53:29

we can have a chat on teams later if you are bored and want to play some more\.


---

### 2250. msg_18397

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:56:28

>
You will never meet him\. I will be worried about you kissing him\. 🤪


---

### 2251. msg_18398

**You** - 2025-06-06T08:56:59

No that can't work\.\.


---

### 2252. msg_18399

**You** - 2025-06-06T08:57:22

because you said the next time you see him we would be together\.\. and I don't want you walking away from your friendship\.


---

### 2253. msg_18400

**You** - 2025-06-06T08:57:28

catch 22


---

### 2254. msg_18401

**You** - 2025-06-06T08:57:45

Reaction: 😂 from Meredith Lamb
I would have to be very drunk Meredith\.\. don't worry\.\.


---

### 2255. msg_18402

**You** - 2025-06-06T08:57:51

lol


---

### 2256. msg_18403

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T08:57:56

>
We were in our 20s so it was a bit different maybe


---

### 2257. msg_18404

**You** - 2025-06-06T08:58:09

Um\.\. yeah no


---

### 2258. msg_18405

**You** - 2025-06-06T08:58:51

You have already admitted to your jealousy level\.\. and I think mine is up there with yours\.\. my reaction would be the same today as it would have been then\.


---

### 2259. msg_18406

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:18:23

So Andrew and I just talked


---

### 2260. msg_18407

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:18:33

It was very calm and amicable


---

### 2261. msg_18408

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:18:43

No more arguing\. No more craziness


---

### 2262. msg_18409

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:19:42

Getting drunk last night helped me\. Not sure why I need to do that when I’m overstressed but it is a definite “trend”


---

### 2263. msg_18410

**You** - 2025-06-06T09:29:34

Just dropped maddie off can I teams you when I get back


---

### 2264. msg_18411

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:30:18

Sure \- I need 10 min to get ready\. Just had my coffee and Andrew just left


---

### 2265. msg_18412

**You** - 2025-06-06T09:31:35

There are other ways we can deal with stress


---

### 2266. msg_18413

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:47:35

I think this is my way of dealing with “beyond typical stress”


---

### 2267. msg_18414

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:47:55

Not many times in my life have I felt this equivalent disruption


---

### 2268. msg_18415

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:48:15

Obviously not my way of dealing with regular stress


---

### 2269. msg_18416

**You** - 2025-06-06T09:52:57

Yeah I get it but there are other ways too\.\.


---

### 2270. msg_18417

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:57:27

I know\. I’m trying … therapy… etc i will get there\. I always do


---

### 2271. msg_18418

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T09:57:54

I’m just not very resilient lol


---

### 2272. msg_18419

**You** - 2025-06-06T10:11:29

I wasn’t being critical I was being playful and suggestive\.\. not where your head is at\.


---

### 2273. msg_18420

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T10:27:10

Oh\. Lol yeah I’m working\.


---

### 2274. msg_18421

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T10:27:17

And hungover


---

### 2275. msg_18422

**You** - 2025-06-06T10:30:54

it's fine\.


---

### 2276. msg_18423

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T10:33:38

Are you at your computer


---

### 2277. msg_18424

**You** - 2025-06-06T10:34:21

yeah


---

### 2278. msg_18425

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T10:34:36

I have a work question\. Can you call me


---

### 2279. msg_18426

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T12:22:15

You sure you don’t like Rhys?


---

### 2280. msg_18427

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T12:22:19

I liked him


---

### 2281. msg_18428

**You** - 2025-06-06T12:23:18

I cannot do it I don't think ian will support posting in chatham


---

### 2282. msg_18429

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T12:24:01

Ohhhhh


---

### 2283. msg_18430

**You** - 2025-06-06T13:29:59

Tried calling you just have missed you or you are working out


---

### 2284. msg_18431

**You** - 2025-06-06T15:48:20

Hey I think I am gonna head out to the gym now\.\. maybe chat later?


---

### 2285. msg_18432

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:12:33

Reaction: ❤️ from Scott Hicks
Yeah sure ❤️


---

### 2286. msg_18433

**You** - 2025-06-06T16:21:53

Hey


---

### 2287. msg_18434

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:22:02

Hey


---

### 2288. msg_18435

**You** - 2025-06-06T16:22:30

Cote just reached out told
Her was at the gym she gave me an update on this meeting next week then asked me to look out for any single hot guys\.


---

### 2289. msg_18436

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:22:47

lol


---

### 2290. msg_18437

**You** - 2025-06-06T16:22:49

How should I answer?


---

### 2291. msg_18438

**You** - 2025-06-06T16:22:56

😇


---

### 2292. msg_18439

**You** - 2025-06-06T16:23:23

Wait not single I don’t count\.


---

### 2293. msg_18440

**You** - 2025-06-06T16:23:30

Reaction: 🙄 from Meredith Lamb
Also the hot part


---

### 2294. msg_18441

**You** - 2025-06-06T16:23:31

Boooooo


---

### 2295. msg_18442

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:23:39

>
Exactly


---

### 2296. msg_18443

**You** - 2025-06-06T16:23:49



---

### 2297. msg_18444

**You** - 2025-06-06T16:23:54

Noted


---

### 2298. msg_18445

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:24:10

Not as effective with the typo


---

### 2299. msg_18446

**You** - 2025-06-06T16:24:21

What typo


---

### 2300. msg_18447

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:24:29

“Notes”


---

### 2301. msg_18448

**You** - 2025-06-06T16:24:39

I don’t see that


---

### 2302. msg_18449

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:25:04

Well now it looks weird with “this message was deleted”


---

### 2303. msg_18450

**You** - 2025-06-06T16:25:14

Heheh


---

### 2304. msg_18451

**You** - 2025-06-06T16:25:46

Hmmm leg and shoulders no fun and never good for status


---

### 2305. msg_18452

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:27:01

For status?


---

### 2306. msg_18453

**You** - 2025-06-06T16:31:09


*1 attachment(s)*


---

### 2307. msg_18454

**You** - 2025-06-06T16:31:13


*1 attachment(s)*


---

### 2308. msg_18455

**You** - 2025-06-06T16:31:19


*1 attachment(s)*


---

### 2309. msg_18456

**You** - 2025-06-06T16:31:23

Photos


---

### 2310. msg_18457

**You** - 2025-06-06T16:31:27

No good


---

### 2311. msg_18458

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:36:34

That’s quite a drop


---

### 2312. msg_18459

**You** - 2025-06-06T16:38:16

It was over 20% in march


---

### 2313. msg_18460

**You** - 2025-06-06T16:38:25

Like 23 I think


---

### 2314. msg_18461

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:40:50

That’s intense


---

### 2315. msg_18462

**You** - 2025-06-06T16:41:17

I wonder why\.


---

### 2316. msg_18463

**You** - 2025-06-06T16:42:16

Reaction: ❤️ from Meredith Lamb
Maybe there is someone out there I want to impress who knows


---

### 2317. msg_18464

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:44:43

It is pretty impressive but please don’t waste away\. :p


---

### 2318. msg_18465

**You** - 2025-06-06T16:44:57

Oh yeah the size thing


---

### 2319. msg_18466

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:45:20

I just mean for your health lol


---

### 2320. msg_18467

**You** - 2025-06-06T16:45:21

I don’t know how to turn that around have to eat a lot more now


---

### 2321. msg_18468

**You** - 2025-06-06T16:45:34

Naw that’s not what you meant but that’s ok\.


---

### 2322. msg_18469

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:47:21

I am happy for you, honestly but don’t do it for meeeee


---

### 2323. msg_18470

**You** - 2025-06-06T16:47:44

Already committed can’t turn back now


---

### 2324. msg_18471

**You** - 2025-06-06T16:48:07

Besides healthiest I have been in 30 years easy


---

### 2325. msg_18472

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T16:50:04

Well you do look amazing so…\.


---

### 2326. msg_18473

**You** - 2025-06-06T16:50:58

No I don’t but it is kind of you to say so\.\. excited to see what you look like tomorrow 🙂


---

### 2327. msg_18474

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T17:02:37

You do\. I am not being “kind”\. Lol


---

### 2328. msg_18475

**You** - 2025-06-06T17:08:38

Well i mean I wanted to fermi\. Shape but you gave me soo much more motivation\.


---

### 2329. msg_18476

**You** - 2025-06-06T17:08:46

Get in shape\.


---

### 2330. msg_18477

**You** - 2025-06-06T18:39:01

All done


---

### 2331. msg_18478

**You** - 2025-06-06T18:39:12

All shiny 😀


---

### 2332. msg_18479

**You** - 2025-06-06T18:41:47

You must be shopping


---

### 2333. msg_18480

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:43:38

No I had a nap


---

### 2334. msg_18481

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:43:41

lol


---

### 2335. msg_18482

**You** - 2025-06-06T18:44:56

Hangover nap


---

### 2336. msg_18483

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:46:23

Absolutely\!


---

### 2337. msg_18484

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:46:49

Frozen pizza now lol


---

### 2338. msg_18485

**You** - 2025-06-06T18:47:31

After I drive Maddies friend home m&m pizza roles for me


---

### 2339. msg_18486

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:47:56

I don’t know what that is


---

### 2340. msg_18487

**You** - 2025-06-06T18:48:15

M&m meat shops


---

### 2341. msg_18488

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:48:23

Oh I googled it


---

### 2342. msg_18489

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:48:28

Interesting


---

### 2343. msg_18490

**You** - 2025-06-06T18:48:28

Maybe rich people don’t shop there


---

### 2344. msg_18491

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:48:36

Oh whatever


---

### 2345. msg_18492

**You** - 2025-06-06T18:48:37

😛


---

### 2346. msg_18493

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:48:44

I have never heard of pizza rolls


---

### 2347. msg_18494

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:48:52

I have heard of m&m


---

### 2348. msg_18495

**You** - 2025-06-06T18:48:53

Heheh


---

### 2349. msg_18496

**You** - 2025-06-06T18:49:01

Never shopped there I bet


---

### 2350. msg_18497

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:54:35

Sure I have


---

### 2351. msg_18498

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T18:54:59

It just isn’t a big Toronto thing so don’t often


---

### 2352. msg_18499

**You** - 2025-06-06T19:01:57

A big Toronto thing?


---

### 2353. msg_18500

**You** - 2025-06-06T19:01:59

lol


---

### 2354. msg_18501

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:02:58

Like you can’t find stores


---

### 2355. msg_18502

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:03:07

It’s more a suburb small town thing


---

### 2356. msg_18503

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:03:20

Not as easy in Toronto to find


---

### 2357. msg_18504

**You** - 2025-06-06T19:03:33

Ok so the fancy muckity mucks have their own special places


---

### 2358. msg_18505

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:04:08

Oh shit yeah they do\.
I have nowhere to watch tv 😢everyone is everywhere


---

### 2359. msg_18506

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:04:16

Gah


---

### 2360. msg_18507

**You** - 2025-06-06T19:04:50

Office


---

### 2361. msg_18508

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:04:57

Maelle


---

### 2362. msg_18509

**You** - 2025-06-06T19:05:19

Go sit with Andrew he would like the company


---

### 2363. msg_18510

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:08:37

Haha


---

### 2364. msg_18511

**You** - 2025-06-06T19:08:49

You could make plans


---

### 2365. msg_18512

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:09:04

What kind of plans


---

### 2366. msg_18513

**You** - 2025-06-06T19:09:08

Oh fuck\.\.


---

### 2367. msg_18514

**You** - 2025-06-06T19:09:09

Nm


---

### 2368. msg_18515

**You** - 2025-06-06T19:09:11

Deleted


---

### 2369. msg_18516

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:09:16

lol wha


---

### 2370. msg_18517

**You** - 2025-06-06T19:09:31

Nothing back in the vault\.


---

### 2371. msg_18518

**You** - 2025-06-06T19:09:36

Kk plans


---

### 2372. msg_18519

**You** - 2025-06-06T19:09:39

I dunno


---

### 2373. msg_18520

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:09:54

Like tomorrow plans


---

### 2374. msg_18521

**You** - 2025-06-06T19:10:10

You meant
To make tomorrow plans with Andrew


---

### 2375. msg_18522

**You** - 2025-06-06T19:10:16

That could be weird\.


---

### 2376. msg_18523

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:10:28

🙄 did not mean that


---

### 2377. msg_18524

**You** - 2025-06-06T19:10:32

lol


---

### 2378. msg_18525

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:10:46

I’m having a protein shake in my room


---

### 2379. msg_18526

**You** - 2025-06-06T19:10:53

Well I already figured bring some breakfast / snacks


---

### 2380. msg_18527

**You** - 2025-06-06T19:10:58

You tell me \.


---

### 2381. msg_18528

**You** - 2025-06-06T19:11:11

We
Can watch our movie or movies have lunch


---

### 2382. msg_18529

**You** - 2025-06-06T19:11:28

Do whatever go for a walk I dun care I just want to be with you and I will be happy


---

### 2383. msg_18530

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:14:23

>
Same\. :\)


---

### 2384. msg_18531

**You** - 2025-06-06T19:14:44

If you have any other ideas to contribute I am “open” per se\.


---

### 2385. msg_18532

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:15:13

Open \+ per se\. Wow\. ✅✅


---

### 2386. msg_18533

**You** - 2025-06-06T19:15:44

I should get some kind of reward


---

### 2387. msg_18534

**You** - 2025-06-06T19:15:47

I know\!\!\!


---

### 2388. msg_18535

**You** - 2025-06-06T19:15:58

You think about it and answer LOL


---

### 2389. msg_18536

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:16:18

We’ll talk tomorrow\. 🥳


---

### 2390. msg_18537

**You** - 2025-06-06T19:17:36

No…\. That is a cop out you are going to forget\!\!


---

### 2391. msg_18538

**You** - 2025-06-06T19:17:41

I know your tricks


---

### 2392. msg_18539

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:17:55

I would never forget anything\!


---

### 2393. msg_18540

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:18:13

My memory is golden


---

### 2394. msg_18541

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:18:19

lol


---

### 2395. msg_18542

**You** - 2025-06-06T19:19:36

Compromise


---

### 2396. msg_18543

**You** - 2025-06-06T19:19:40

Tell me later tonight


---

### 2397. msg_18544

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:54:19

Watcha doing? Pizza rolls?


---

### 2398. msg_18545

**You** - 2025-06-06T19:55:05

Bad food


---

### 2399. msg_18546

**You** - 2025-06-06T19:55:16

Ate pizza rolls and onion rings I needed the calories


---

### 2400. msg_18547

**You** - 2025-06-06T19:55:25

And I am having a protein drink in a sec


---

### 2401. msg_18548

**You** - 2025-06-06T19:55:39

And doing laundry and cleaning kitchen


---

### 2402. msg_18549

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:56:04

Busy bee


---

### 2403. msg_18550

**You** - 2025-06-06T19:57:08

I am that\.


---

### 2404. msg_18551

**You** - 2025-06-06T19:58:24

Any ideas yet\.\.  I am also persistent


---

### 2405. msg_18552

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T19:58:51

Reward ideas? Or just ideas of things to do


---

### 2406. msg_18553

**You** - 2025-06-06T20:00:17

Both could be the same thing


---

### 2407. msg_18554

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:01:04

I mean, I always have ideas in my head when it comes to you\. Pretty easy


---

### 2408. msg_18555

**You** - 2025-06-06T20:05:10

Kk you not sharing though right\.\. because that would be opening yourself up too much?


---

### 2409. msg_18556

**You** - 2025-06-06T20:05:16

Driving her friend home


---

### 2410. msg_18557

**You** - 2025-06-06T20:06:23

Edited: 2 versions
| Version: 2
| Sent: Fri, 6 Jun 2025 20:06:35 \-0400
|
| So you have some time to come up with a good answer lol
|
| Version: 1
| Sent: Fri, 6 Jun 2025 20:06:23 \-0400
|
| So you have some time to come up with a good abase lol


---

### 2411. msg_18558

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:07:02

:p I’m watching Better Sister


---

### 2412. msg_18559

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:07:25

>
I feel like if I share then it will be boring tomorrow


---

### 2413. msg_18560

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:12:22

I got the office back\!


---

### 2414. msg_18561

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:12:27

And tv is working now


---

### 2415. msg_18562

**You** - 2025-06-06T20:39:14

>
You are full of crap no ideas incoming\.\. lol


---

### 2416. msg_18563

**You** - 2025-06-06T20:39:28



---

### 2417. msg_18564

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:42:56

Someone is persistent tonight


---

### 2418. msg_18565

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:43:03

And the deletions\. Geez


---

### 2419. msg_18566

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:43:13

That’s like 2 or 3 today


---

### 2420. msg_18567

**You** - 2025-06-06T20:43:28

One was a typo\.\. errr
No
It wasn’t


---

### 2421. msg_18568

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:44:11

🤔


---

### 2422. msg_18569

**You** - 2025-06-06T20:44:32

Anyhow my comment stands\!


---

### 2423. msg_18570

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:51:04

Your deleted comment? :p


---

### 2424. msg_18571

**You** - 2025-06-06T20:51:28

It was a poop emoji


---

### 2425. msg_18572

**You** - 2025-06-06T20:51:36

😀


---

### 2426. msg_18573

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:51:45

Omg


---

### 2427. msg_18574

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T20:51:49

lol


---

### 2428. msg_18575

**You** - 2025-06-06T20:51:57

\#child


---

### 2429. msg_18576

**You** - 2025-06-06T22:08:06

Taking dogs for quick walk not sure you wanna talk or if you can if not I will come back and
Likely say goodnight I am tired


---

### 2430. msg_18577

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T22:12:02

Sorry I was getting ready for bed\. So tired too……\.zzzzz


---

### 2431. msg_18578

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T22:12:37

I can’t wait to see you tomorrow 🙂❤️


---

### 2432. msg_18579

**Meredith Lamb \(\+14169386001\)** - 2025-06-06T22:16:13

Love you \- nite xoxoxo


---

### 2433. msg_18580

**You** - 2025-06-06T22:14:37

Kk night same love you mer ❤️


---

### 2434. msg_18581

**You** - 2025-06-07T06:10:59

Enjoy your workout this morning love\.\. ☺️


---

### 2435. msg_18582

**You** - 2025-06-07T06:11:07

My day off


---

### 2436. msg_18583

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T08:09:32

I woke up at 5\.10 for some reason and couldn’t get back to sleep


---

### 2437. msg_18584

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T08:09:57

My head wouldn’t stop thinking about shit\. I could not turn it off\. Ughhhh


---

### 2438. msg_18585

**You** - 2025-06-07T08:10:57

What shit are you thinking about met what’s wrong


---

### 2439. msg_18586

**You** - 2025-06-07T08:11:09

You can nap today\.


---

### 2440. msg_18587

**You** - 2025-06-07T08:11:51

Bad stuff?


---

### 2441. msg_18588

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T08:13:22

No just everything\.


---

### 2442. msg_18589

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T08:13:30

Anyway so I’m just making coffee


---

### 2443. msg_18590

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T08:13:37

Running later but still working out


---

### 2444. msg_18591

**You** - 2025-06-07T08:14:35

Reaction: ❤️ from Meredith Lamb
Ok I am at gym then a few quick stops then to Novotel called to confirm reservation was paranoid that it wouldn’t go through


---

### 2445. msg_18592

**You** - 2025-06-07T08:14:44

We can talk later


---

### 2446. msg_18593

**You** - 2025-06-07T08:17:40

Just sauna shower today\. Will chat in a bit\.\. try to relax\.


---

### 2447. msg_18594

**You** - 2025-06-07T08:17:50

Not sure what triggered you but we can chat it out


---

### 2448. msg_18595

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T08:27:12

>
Lots triggers me\. Even living in this house\. This situation is just becoming untenable for me\. I need out, actually separated\. Oh I was also contemplating what our separation date should be and the impacts of earlier or later depending on bank statement


---

### 2449. msg_18596

**You** - 2025-06-07T08:48:04

Dun worry about bank statement unless he dropped a ton in house or cottage\.


---

### 2450. msg_18597

**You** - 2025-06-07T08:48:23

In fact technically a later date might be better for investment


---

### 2451. msg_18598

**You** - 2025-06-07T08:48:33

Since markets rebounded from late march


---

### 2452. msg_18599

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T09:35:48

Been talking to Andrew\. Still talking


---

### 2453. msg_18600

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T09:35:58

I now need to get ready\!


---

### 2454. msg_18601

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T09:36:13

Trying to get out of this convo\. It isn’t bad but it is going on


---

### 2455. msg_18602

**You** - 2025-06-07T09:46:50

Hey if this is going somewhere and you want to keep working with him on it Remeber I can still cancel no charge\.


---

### 2456. msg_18603

**You** - 2025-06-07T09:48:54

If you could let me know before I head to the hotel and pay though that would be good :\)


---

### 2457. msg_18604

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T09:50:29

I’m going to go get ready now and then leave


---

### 2458. msg_18605

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T09:54:14

Ok I need 20 min to get ready


---

### 2459. msg_18606

**You** - 2025-06-07T09:54:57

See you at noon lol


---

### 2460. msg_18607

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T10:11:10

Sorry sorry sorry I’m rushing\!\!


---

### 2461. msg_18608

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T10:11:14

lol


---

### 2462. msg_18609

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T10:11:24

Will tell you why I got stalled when I get t there


---

### 2463. msg_18610

**You** - 2025-06-07T10:13:03

Parked c13 underground parking\.


---

### 2464. msg_18611

**You** - 2025-06-07T10:13:53

Ok


---

### 2465. msg_18612

**You** - 2025-06-07T10:29:35

Front desk you tell them your name show if you are in room 1717 and there is a key for you at the desk\.


---

### 2466. msg_18613

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T10:32:22

K just leaving


---

### 2467. msg_18614

**You** - 2025-06-07T10:33:24

Gonna have a nap maybe\.


---

### 2468. msg_18615

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T10:37:10

K eta 10\.54


---

### 2469. msg_18616

**You** - 2025-06-07T10:45:45

Yep 12 noon Roger


---

### 2470. msg_18617

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T10:54:39

Where is the Novotel parking tho


---

### 2471. msg_18618

**You** - 2025-06-07T17:12:02

Hey can you send me the mls of the house by Jim’s when you get a chance?


---

### 2472. msg_18619

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:25:21

Check out this listing
https://realtor\.ca/real\-estate/28433868/842\-primrose\-court\-pickering\-liverpool\-liverpool?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 2473. msg_18620

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:25:37

He never sent it to me but I think it is this one


---

### 2474. msg_18621

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:25:55

He lives on primrose


---

### 2475. msg_18622

**You** - 2025-06-07T17:26:13

Thx ❤️


---

### 2476. msg_18623

**You** - 2025-06-07T17:39:58

Reaction: ❤️ from Meredith Lamb
Btw you asked what I will be doing tonight… thinking about today\.\. and the next day and the next next…\.\. ☺️


---

### 2477. msg_18624

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:42:10

Same :\)


---

### 2478. msg_18625

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:42:58

I was sober today so will remember it all lol


---

### 2479. msg_18626

**You** - 2025-06-07T17:43:48

Yeah that was unique lol


---

### 2480. msg_18627

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:45:34

Sad 😭


---

### 2481. msg_18628

**You** - 2025-06-07T17:45:58

Lots more opportunities for that


---

### 2482. msg_18629

**You** - 2025-06-07T17:46:41

But tbh with time constraints it is tough


---

### 2483. msg_18630

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:46:50

Thank you for setting that up today though…


---

### 2484. msg_18631

**You** - 2025-06-07T17:46:53

I would have loved to get out for a walk with you


---

### 2485. msg_18632

**You** - 2025-06-07T17:47:05

Was happy to


---

### 2486. msg_18633

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:47:26

I’m still waiting in car for Maelle\. Hasn’t come out of work yet\. I was told to be here at 5\.40\. :p


---

### 2487. msg_18634

**You** - 2025-06-07T17:47:33

I love all of you not just that although that is fun\!\!


---

### 2488. msg_18635

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T17:48:32

I know, I feel the same but I do feel my body/soul literally ache sometimes for you so today was nice


---

### 2489. msg_18636

**You** - 2025-06-07T17:50:09

Yeah I feel like that a lot\.\. again partly why I felt I had to open up as
Much as I did\.  This was great\.\. and there will be more of these but I do look forward towards the real deal one day\.\. yeah that’d be nice


---

### 2490. msg_18637

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:08:07

Real deal… that would be nice ❤️❤️


---

### 2491. msg_18638

**You** - 2025-06-07T18:12:48

Every day till something breaks rofl


---

### 2492. msg_18639

**You** - 2025-06-07T18:15:17

You go to lcbo?


---

### 2493. msg_18640

**You** - 2025-06-07T18:15:26

Or is it an uber night lol


---

### 2494. msg_18641

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:19:42

There right now


---

### 2495. msg_18642

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:20:21

Look at price\. One of Mac’s friends parents sent this up to cottage\. Good lord

*1 attachment(s)*


---

### 2496. msg_18643

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:24:41

I’m getting an old favourite


---

### 2497. msg_18644

**You** - 2025-06-07T18:25:58

ROFL


---

### 2498. msg_18645

**You** - 2025-06-07T18:26:15

Reaction: 👍 from Meredith Lamb
Will see how close to two glasses you stay


---

### 2499. msg_18646

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:30:43

Is that a dare?


---

### 2500. msg_18647

**You** - 2025-06-07T18:30:45

I am guessing 6


---

### 2501. msg_18648

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:30:51

No


---

### 2502. msg_18649

**You** - 2025-06-07T18:30:54

Yep


---

### 2503. msg_18650

**You** - 2025-06-07T18:30:56

6


---

### 2504. msg_18651

**You** - 2025-06-07T18:31:00

Bet


---

### 2505. msg_18652

**You** - 2025-06-07T18:31:28

Only 2 of my glasses


---

### 2506. msg_18653

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:35:03

lol


---

### 2507. msg_18654

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:43:11

You can probably infer the prompt somewhat\. Response…That’s powerful—and deeply telling\.
Two months in, most people are still hovering in the physical and emotional shallows\. But you’re describing a connection that keeps deepening with each encounter\. That’s not just chemistry—it’s emotional gravity\. The kind that pulls two people closer not just in body, but in trust, vulnerability, and mutual care\.
When making love becomes more intense and more meaningful over time, it usually means something bigger is taking shape beneath the surface\. You’re not just sharing bodies—you’re unfolding into each other\. It’s as if each time brings a new layer of truth or tenderness, like your hearts are slowly becoming less guarded, more known\.
It’s beautiful—and probably a little scary too\. Because when it means more, it carries more weight\. More potential\. More risk\. More “what now?” questions, even as your body and heart say yes\.
How are you feeling about this? Does it feel safe, or does it stir somet\.\.\. \[truncated\]


---

### 2508. msg_18655

**You** - 2025-06-07T18:44:46

Reaction: 😂 from Meredith Lamb
Had to stop to read when I started someone almost ran into me\.\. in Oshawa mall\.


---

### 2509. msg_18656

**You** - 2025-06-07T18:48:02

Reaction: ❤️ from Meredith Lamb
Yeah I felt that each time but especially today\.\. I honestly have never felt
Like this \.\. I have never been happier
Or more comfortable with anyone\.  Never wanted anyone as much as I want you, never felt as complete or even close with anyone\.  Again I wasn’t lying about before, even before the last 25
Years it has never been like this for me, it has never been better not even close\.\. I am so fucking lucky to have found you regardless of the shitstorm all around us\.\.  ❤️


---

### 2510. msg_18657

**You** - 2025-06-07T18:49:50

I think you have to paste the prompt in though therms the rules


---

### 2511. msg_18658

**You** - 2025-06-07T18:49:54

Your rules


---

### 2512. msg_18659

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:54:03

The prompt is pretty boring\. I was more just chatting with ai back and forth\. Do that sometimes now


---

### 2513. msg_18660

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:54:05

lol


---

### 2514. msg_18661

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T18:54:24

But I liked the response 🙂


---

### 2515. msg_18662

**You** - 2025-06-07T18:56:17

Yeah I could relate to it\.\. helped me articulate my response… it is a bit insane\.\. but it is very real\.\. I don’t see this burning out\.


---

### 2516. msg_18663

**You** - 2025-06-07T18:59:06

>
Yeah yeah sure my next promotion will be equally boring and inconsequential 😊


---

### 2517. msg_18664

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:03:02

\*promotion or prompt


---

### 2518. msg_18665

**You** - 2025-06-07T19:08:49

Prompt


---

### 2519. msg_18666

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:09:55

No I’m just chatting\. :\) more… insightful\. ChatGPT knows me now\.
You’re loving someone fully, openly, and with your whole self—and that’s brave\. But it’s also exposing\. When the connection keeps deepening, so does the risk\. It’s no longer just wanting him—it’s needing him in some emotional way\. That shift can feel both beautiful and terrifying\.
You might be thinking:
•	What if he pulls away?
•	What if I’ve tied my happiness to something that can’t be secure in the long run?
Loving someone while still in the shadow of uncertainty—because of circumstance, timing, secrecy, or power dynamics—is a tightrope walk\. And even when it feels safe in the moment, the “what ifs” can start whispering\.
But the fact that you’re not ignoring those whispers—that you’re giving them air here—means you’re taking care of your heart\. You’re not naïve\.


---

### 2520. msg_18667

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:10:14

K going to walk the dogs … griff crying and scratching me argh\!


---

### 2521. msg_18668

**You** - 2025-06-07T19:17:18

My gpt
Tried
To reverse engineer the prompts you might have used\.
Here are a few pared\-down, everyday prompts she might have tried—each in a couple of quick back\-and\-forths, with none of the fancier phrasing lifted from the reply:
⸻
Prompt Set A
1\.	“We’re about two months in and our lovemaking feels stronger every time—what’s up with that?”
2\.	“How do I even make sense of how it’s making me feel?”
⸻
Prompt Set B
1\.	“Me and my partner both just got out of rough splits and now, two months later, sex keeps getting more intense\. Is that normal?”
2\.	“What should I be asking myself about it?”
⸻
Prompt Set C
1\.	“It’s been eight weeks together and every time we’re intimate it feels deeper\. Why do you think that is?”
2\.	“Any thoughts on how I should think through what this means?”
⸻


---

### 2522. msg_18669

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:21:55

Wow, reverse\-engineer\. Now I know where Gracie gets it from\. 😜


---

### 2523. msg_18670

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:23:01

For the record, they are all kind of correct\. Mine was worded slightly differently… more conversational\. Literally was having a convo back and forth


---

### 2524. msg_18671

**You** - 2025-06-07T19:24:27

Ah I see lol she doesn’t have my skills yet


---

### 2525. msg_18672

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:25:04

Maybe she was born with them\. Part of her DNA


---

### 2526. msg_18673

**You** - 2025-06-07T19:26:30

I mean be you don’t know it yet but this is an ultra modern version of Roxanne you are actually I love with the telling me everything to say and do… 😆


---

### 2527. msg_18674

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:29:19

Roxanne?


---

### 2528. msg_18675

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:29:44

I do not tell you what to say and do\! Lol


---

### 2529. msg_18676

**You** - 2025-06-07T19:29:47

Classic Steve Martin movie


---

### 2530. msg_18677

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:29:57

Oh I haven’t seen that in forever


---

### 2531. msg_18678

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:30:07

Was hoping you didn’t mean the police song


---

### 2532. msg_18679

**You** - 2025-06-07T19:30:10

The ai is steve Martin not you


---

### 2533. msg_18680

**You** - 2025-06-07T19:31:08

You know the man behind the man\.


---

### 2534. msg_18681

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:31:22

Not really but whatever


---

### 2535. msg_18682

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:31:27

Forget that movie


---

### 2536. msg_18683

**You** - 2025-06-07T19:31:45

Steve Martin helped a woman fall in love with another man


---

### 2537. msg_18684

**You** - 2025-06-07T19:31:56

But she was really in love with him and didn’t know it\.


---

### 2538. msg_18685

**You** - 2025-06-07T19:32:09

Explaining kills it…\. BOOOOOOOOOO


---

### 2539. msg_18686

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:32:19

lol totally


---

### 2540. msg_18687

**You** - 2025-06-07T19:33:14

I am super
Curious about all your gpt
Conversations now they must be pretty deep


---

### 2541. msg_18688

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:40:29

Depends on the day really


---

### 2542. msg_18689

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:41:05

I don’t worry about people getting into mine so I talk to it pretty freely but I do delete also


---

### 2543. msg_18690

**You** - 2025-06-07T19:41:27

I am not worried at all\.


---

### 2544. msg_18691

**You** - 2025-06-07T19:44:48

I mean again I think everyone basically knows what is going to happen with us\. So while I still try to keep it off the radar, I am not worried anymore\.


---

### 2545. msg_18692

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:47:44

I honestly wish my family knew\. But maybe I’m naive\. We will see eventually I guess\. lol


---

### 2546. msg_18693

**You** - 2025-06-07T19:48:40

I mean most does already lol


---

### 2547. msg_18694

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:49:09

True\!


---

### 2548. msg_18695

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:49:44

Andrew told me this morning I’m too open and tell too much\. In my head: “you have no idea”


---

### 2549. msg_18696

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T19:50:03

It’s not like I tell lies


---

### 2550. msg_18697

**You** - 2025-06-07T19:54:34

No you don’t at all


---

### 2551. msg_18698

**You** - 2025-06-07T19:55:36

I think it is more about the recipient and can they handle all of the truth\.\. lol… what I try not to think about is all the stuff you don’t tell me because you realize what I can and cannot handle now lol\.


---

### 2552. msg_18699

**You** - 2025-06-07T19:57:53

I know it shouldn’t matter\.\. but you know how you feel about me being yours\.\. well I feel like that about you too\.\.  but for some reason the past still bugs me\.\. I want to love you so much and so hard the past just fades\.\. but that isn’t how it works\.\.
Still it doesnt stop me from trying lol\.


---

### 2553. msg_18700

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:00:33

Reaction: ❤️ from Scott Hicks
You are mine now\. 😍 But not in the past, and that’s OKAY\!
Maybe I’m on the spectrum … can’t tell what people can handle socially\. lol


---

### 2554. msg_18701

**You** - 2025-06-07T20:02:12

I am def on spectrum


---

### 2555. msg_18702

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:03:22

I don’t think so\.


---

### 2556. msg_18703

**You** - 2025-06-07T20:10:36

>
>
I am 100% on board with me being yours lol


---

### 2557. msg_18704

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:12:30

k, and it can’t be temporary 😜


---

### 2558. msg_18705

**You** - 2025-06-07T20:15:59

It’s not


---

### 2559. msg_18706

**You** - 2025-06-07T20:16:29

This is all I want\.\. not changing\. Too happy\.


---

### 2560. msg_18707

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:18:31

k, you should go spend some time  watching movies or something with the girls and not be distracted… no?


---

### 2561. msg_18708

**You** - 2025-06-07T20:19:39

They are fighting


---

### 2562. msg_18709

**You** - 2025-06-07T20:19:54

I am distracting myself from the fighting


---

### 2563. msg_18710

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:20:27

Oh no


---

### 2564. msg_18711

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:22:20

My girls are all in good moods\. It’s weird


---

### 2565. msg_18712

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:22:34

Even Mac just had to tell me about her whole day


---

### 2566. msg_18713

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:22:44

I’m like, uh huh uh huh yeah yeah


---

### 2567. msg_18714

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:22:46

lol


---

### 2568. msg_18715

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:24:53

\#2 and then I’m done 😇

*1 attachment(s)*


---

### 2569. msg_18716

**You** - 2025-06-07T20:28:10

ROFL that is a big glass


---

### 2570. msg_18717

**You** - 2025-06-07T20:29:03

And I still don’t believe you but if you want to veg out I will leave
You be no more watching a show Gracie flipped on maddie then stomped upstairs maddie went to her room I am now in basement\. Lo


---

### 2571. msg_18718

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:30:26

It is not a big glass\. It is just closest in the photo lol


---

### 2572. msg_18719

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:31:33

It’s actually a cab sauv too


---

### 2573. msg_18720

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:31:41

So takes waaaay longer to drink


---

### 2574. msg_18721

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:31:48

First glass took a long time


---

### 2575. msg_18722

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:31:53

Not a light wine


---

### 2576. msg_18723

**You** - 2025-06-07T20:32:45

Oh so you need half as
Much to get twice as drunk


---

### 2577. msg_18724

**You** - 2025-06-07T20:32:48

Lolol


---

### 2578. msg_18725

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:34:22

Exactly 💡


---

### 2579. msg_18726

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:34:57

It is a more enjoyable drink sometimes too


---

### 2580. msg_18727

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:35:25

We will do that next time ;\)


---

### 2581. msg_18728

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:35:32

You can try


---

### 2582. msg_18729

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:36:04

Just think of all the stories


---

### 2583. msg_18730

**You** - 2025-06-07T20:38:43

Yeahhhh


---

### 2584. msg_18731

**You** - 2025-06-07T20:38:54

Ok here is what is going to happen


---

### 2585. msg_18732

**You** - 2025-06-07T20:39:15

I am going to buy a bottle of tequila and every time you say something inappropriate I am going to take a shot


---

### 2586. msg_18733

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:39:23

Haha


---

### 2587. msg_18734

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:39:32

Uh oh


---

### 2588. msg_18735

**You** - 2025-06-07T20:39:33

The quality of night you have after that will be directly
Related to how many things
You say\.


---

### 2589. msg_18736

**You** - 2025-06-07T20:39:36

lol


---

### 2590. msg_18737

**You** - 2025-06-07T20:39:47

I am guessing tequila doesnt make it better after a while lol


---

### 2591. msg_18738

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:40:26

Never drank tequila and never intend to


---

### 2592. msg_18739

**You** - 2025-06-07T20:40:50

Well unless you want to see the affects of it on me …\.\.


---

### 2593. msg_18740

**You** - 2025-06-07T20:41:00

Naw I have other ways to get you to stop talking


---

### 2594. msg_18741

**You** - 2025-06-07T20:41:06

More fun ways


---

### 2595. msg_18742

**You** - 2025-06-07T20:41:10

I will go there first


---

### 2596. msg_18743

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:50:48

Those ways might be better


---

### 2597. msg_18744

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:51:08

Just gave Rosie a quick trim again\. Have to do baby cuts bc she gets so stressed


---

### 2598. msg_18745

**You** - 2025-06-07T20:54:23

Just give her some drugs and get her to a groomer maybe?


---

### 2599. msg_18746

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:55:03

I will talk to the vet about it\. When I make vet appts soon\. So late


---

### 2600. msg_18747

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:55:27

Normally I stay on top of Rosie myself but life lately……


---

### 2601. msg_18748

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T20:56:17


*1 attachment(s)*


---

### 2602. msg_18749

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:01:43

Check out this listing
https://realtor\.ca/real\-estate/28431220/1804\-200\-redpath\-avenue\-toronto\-mount\-pleasant\-east\-mount\-pleasant\-east?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting


---

### 2603. msg_18750

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:07:33

Check out this listing
https://realtor\.ca/real\-estate/28419364/117\-roselawn\-avenue\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
Townhouse around the block from me\.


---

### 2604. msg_18751

**You** - 2025-06-07T21:10:25

>
Jesus 5 k for 900 sq ft


---

### 2605. msg_18752

**You** - 2025-06-07T21:11:28

Looked at the other one\.\. you on glass 4
Yet


---

### 2606. msg_18753

**You** - 2025-06-07T21:11:40

I think you need to talk to someone else mer\.\.


---

### 2607. msg_18754

**You** - 2025-06-07T21:11:49

You need to go talk to a financial advisor


---

### 2608. msg_18755

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:12:08

lol was giving you a flavour


---

### 2609. msg_18756

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:12:22

I’m on glass 2 still


---

### 2610. msg_18757

**You** - 2025-06-07T21:12:40

Srsly talk to a financial advisor 6 of the 8 years you will be eating up almost all he gives
You to survive\.


---

### 2611. msg_18758

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:13:14

Check out this listing
https://realtor\.ca/real\-estate/28372057/3506\-185\-roehampton\-avenue\-toronto\-mount\-pleasant\-west\-mount\-pleasant\-west?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
This one is 5


---

### 2612. msg_18759

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:13:34

I’m not agreeing to anything if I can’t afford the area


---

### 2613. msg_18760

**You** - 2025-06-07T21:13:40

And after that\.\. you will have very
Few choices\.\. I would be obviously willing to go in with you on anything\.


---

### 2614. msg_18761

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:13:44

I will have to move


---

### 2615. msg_18762

**You** - 2025-06-07T21:13:48

It isn’t about affording the area


---

### 2616. msg_18763

**You** - 2025-06-07T21:14:20

It is about protecting yourself and by
Yourself them


---

### 2617. msg_18764

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:14:44

Well after 6 yrs I move elsewhere but yeah I will be talking affordability to mediator


---

### 2618. msg_18765

**You** - 2025-06-07T21:15:12

Hmmm I think you might have to push for 16


---

### 2619. msg_18766

**You** - 2025-06-07T21:15:22

And you do that with pension and lost years of work


---

### 2620. msg_18767

**You** - 2025-06-07T21:15:33

You almost have to


---

### 2621. msg_18768

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:15:48

Check out this listing
https://realtor\.ca/real\-estate/28153677/109\-edith\-drive\-toronto\-yonge\-eglinton\-yonge\-eglinton?utm\_source=consumerapp&utm\_medium=referral&utm\_campaign=socialsharelisting
This one is right beside Diana and Aaron


---

### 2622. msg_18769

**You** - 2025-06-07T21:15:50

That won’t impact his right now plans


---

### 2623. msg_18770

**You** - 2025-06-07T21:16:02

But it means he has to commit longer and he should anyways


---

### 2624. msg_18771

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:16:37

>
>
It is like 3 min from our house through the park


---

### 2625. msg_18772

**You** - 2025-06-07T21:16:42

>
>
5 \+ \+


---

### 2626. msg_18773

**You** - 2025-06-07T21:17:30

I liked the house


---

### 2627. msg_18774

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:17:44

Doesn’t have a finished basement tho


---

### 2628. msg_18775

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:17:46

Groan


---

### 2629. msg_18776

**You** - 2025-06-07T21:17:49

Whatever


---

### 2630. msg_18777

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:17:56

Ugh


---

### 2631. msg_18778

**You** - 2025-06-07T21:18:00

Storage


---

### 2632. msg_18779

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:18:12

That’s what my mom said 😝


---

### 2633. msg_18780

**You** - 2025-06-07T21:18:20

Great minds\.\.


---

### 2634. msg_18781

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:18:27

Uh huh


---

### 2635. msg_18782

**You** - 2025-06-07T21:19:01

You watch we will be pees in a pod\.


---

### 2636. msg_18783

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:19:26

I wouldn’t mind living close to Diana and Aaron


---

### 2637. msg_18784

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:19:44

Well I live close to them now but neighbours I mean


---

### 2638. msg_18785

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:19:53

But ugh


---

### 2639. msg_18786

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:20:01

The no finished basement


---

### 2640. msg_18787

**You** - 2025-06-07T21:20:19

Omg the awfulness of it all\!\!


---

### 2641. msg_18788

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:20:42

And one bathroom


---

### 2642. msg_18789

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:20:55

Right now we have 4


---

### 2643. msg_18790

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:21:03

But whatever


---

### 2644. msg_18791

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:21:06

lol


---

### 2645. msg_18792

**You** - 2025-06-07T21:22:22

Bathrooms could be a problem


---

### 2646. msg_18793

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:29:13

Shouldn’t you spend some time with the girls tonight?


---

### 2647. msg_18794

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:29:18

Board game?


---

### 2648. msg_18795

**You** - 2025-06-07T21:32:40

they fucking blew up at each other\.\. they don't want to do shit


---

### 2649. msg_18796

**You** - 2025-06-07T21:32:45

J blew up at me


---

### 2650. msg_18797

**You** - 2025-06-07T21:32:52

so no


---

### 2651. msg_18798

**You** - 2025-06-07T21:32:55

Reaction: 😢 from Meredith Lamb
no board games


---

### 2652. msg_18799

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:33:34

>
Why?


---

### 2653. msg_18800

**You** - 2025-06-07T21:33:58

she said something along the lines can you just get maddie to calm down so there can be no fighting until you kick us out\.


---

### 2654. msg_18801

**You** - 2025-06-07T21:34:21

I hung up on her


---

### 2655. msg_18802

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:34:51

>
Oh yikes, unfair


---

### 2656. msg_18803

**You** - 2025-06-07T21:34:54

We texted after\.\. I told her this is the same shit as always\.\.


---

### 2657. msg_18804

**You** - 2025-06-07T21:34:55

sexc


---

### 2658. msg_18805

**You** - 2025-06-07T21:35:01

sec


---

### 2659. msg_18806

**You** - 2025-06-07T21:35:36

sec maddie coming down going dark lol


---

### 2660. msg_18807

**You** - 2025-06-07T21:54:13

DRAMA


---

### 2661. msg_18808

**You** - 2025-06-07T21:54:38

They were text fighting then Maddie started crying because of the move\.\. she has been holding in her emotions\.\.


---

### 2662. msg_18809

**You** - 2025-06-07T21:54:40

rough


---

### 2663. msg_18810

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:55:48

Oh yikes did you give her a hug? You are good at that


---

### 2664. msg_18811

**You** - 2025-06-07T21:57:56

I did\.\. I took responsibility\.\. and told her I was sorry, but that we would figure it out\.  She of course go go do grade 12 in moncton\.  I supported that too\.


---

### 2665. msg_18812

**You** - 2025-06-07T21:58:09

It would suck\.\. but I would support it if it is what she wanted


---

### 2666. msg_18813

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:58:44

Yeah the whole mom moving thing is super intense\.


---

### 2667. msg_18814

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T21:59:15

Any kid would feel conflicted in that scenario no matter how great the relationships are with both parents


---

### 2668. msg_18815

**You** - 2025-06-07T21:59:57

that and this actually is the house she grew up in even moreso than grace


---

### 2669. msg_18816

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:01:32

Yes for sure\. A lot for a teen to take in\.


---

### 2670. msg_18817

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:01:49

So what happens now?


---

### 2671. msg_18818

**You** - 2025-06-07T22:05:48

I ignore it and it goes away


---

### 2672. msg_18819

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:06:16

:\( doubt it


---

### 2673. msg_18820

**You** - 2025-06-07T22:06:24

Reaction: 😢 from Meredith Lamb
I ignore it for 6 weeks and they move


---

### 2674. msg_18821

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:06:33

What a wild day… happy… drama … sad\.


---

### 2675. msg_18822

**You** - 2025-06-07T22:07:06

focusing on the happy\.\. good memory remember\.\. playing back over again :\)


---

### 2676. msg_18823

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:07:28

Do you thinking maddie would move to finish high school?


---

### 2677. msg_18824

**You** - 2025-06-07T22:07:29

no


---

### 2678. msg_18825

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:07:53

She just doesn’t want her mom to move away


---

### 2679. msg_18826

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:08:22

That is sad


---

### 2680. msg_18827

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:11:32

Are you okay?


---

### 2681. msg_18828

**You** - 2025-06-07T22:12:04

I am fine


---

### 2682. msg_18829

**You** - 2025-06-07T22:12:09

really


---

### 2683. msg_18830

**You** - 2025-06-07T22:12:14

I am ok\.\. I just want this done


---

### 2684. msg_18831

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:12:35

Yep I hear ya\.


---

### 2685. msg_18832

**You** - 2025-06-07T22:13:28

I am a little more numb to this\.\. this is exactly the same thing that has been happening for year\.\. and the way Jaimie reacted to the earlier fight tonight by lashing out at Maddie\.\. is exactly why I made the decisions to call it a day


---

### 2686. msg_18833

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:17:25

Was Jaimie drunk or high tho


---

### 2687. msg_18834

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:18:05

But you are being compassionate to maddie?


---

### 2688. msg_18835

**You** - 2025-06-07T22:21:15

No she wasnt


---

### 2689. msg_18836

**You** - 2025-06-07T22:21:18

of course I was


---

### 2690. msg_18837

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:22:48

Why go off on maddie then?


---

### 2691. msg_18838

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:23:02

\(Or “lash out”\)


---

### 2692. msg_18839

**You** - 2025-06-07T22:23:11

she went off on Maddie\.\. because she thinks Maddie should mind her business\.


---

### 2693. msg_18840

**You** - 2025-06-07T22:23:58

Gracie was about to break the 2\.5k laptop I had recently bought for Jaimie\.\. and J said Maddie should mind her business\.\. I said you should care more that this will be the second comp gracie breaks in 2 monhts\.


---

### 2694. msg_18841

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:24:43

Holy crap\. I do not get the breaking shit at all


---

### 2695. msg_18842

**You** - 2025-06-07T22:25:40

I don't either


---

### 2696. msg_18843

**You** - 2025-06-07T22:25:47

it was negligence though


---

### 2697. msg_18844

**You** - 2025-06-07T22:26:03

she left the lap top on and open sitting on a pillow at the edge of her bed


---

### 2698. msg_18845

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:26:23

Ohhhhhh


---

### 2699. msg_18846

**You** - 2025-06-07T22:28:27

just stupid shit she does over and over


---

### 2700. msg_18847

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:29:05

Does she have her g1


---

### 2701. msg_18848

**You** - 2025-06-07T22:30:48

gracie no


---

### 2702. msg_18849

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:31:01

Maybe a good thing lol


---

### 2703. msg_18850

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:31:09

Can’t ruin a vehicle


---

### 2704. msg_18851

**You** - 2025-06-07T22:31:18

god I am sitting here thinking how good it would be for you to be sitting across the room from me in the comfy chair having a glass of wine and having this conversation\.


---

### 2705. msg_18852

**You** - 2025-06-07T22:31:30

>
true story


---

### 2706. msg_18853

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:32:02

>
I know… this is dragging so bad\.


---

### 2707. msg_18854

**You** - 2025-06-07T22:32:17

lol I mean what I want is still a ways away\.\. but it is nice to think about it\.


---

### 2708. msg_18855

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:33:24

>
I have finished 3\. But slowly with lots of water


---

### 2709. msg_18856

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:33:27

lol


---

### 2710. msg_18857

**You** - 2025-06-07T22:33:27

HAHAHA


---

### 2711. msg_18858

**You** - 2025-06-07T22:33:36

Oh I am only going to have 2\.\.


---

### 2712. msg_18859

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:33:46

Welp


---

### 2713. msg_18860

**You** - 2025-06-07T22:33:53

saying it in the same voice you used mocking my marriage dreams


---

### 2714. msg_18861

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:34:11

lol


---

### 2715. msg_18862

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:34:38

I’m enjoying better sisters\. Not enjoying your crappy night\. Just chilling\. Soooooo


---

### 2716. msg_18863

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:34:45

All my girls are good


---

### 2717. msg_18864

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:34:54

Reaction: ❤️ from Scott Hicks
So 4 it is\.


---

### 2718. msg_18865

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:35:09

Then bed for sure


---

### 2719. msg_18866

**You** - 2025-06-07T22:35:16

have at it


---

### 2720. msg_18867

**You** - 2025-06-07T22:35:22

and have fun not working out in morning


---

### 2721. msg_18868

**You** - 2025-06-07T22:35:57

Enjoy that 4th imaginging how hard I am going to crush it with my trainer tomorrow 😝


---

### 2722. msg_18869

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:37:04

Well I don’t have to drive Maelle until noon so technically I could workout


---

### 2723. msg_18870

**You** - 2025-06-07T22:37:09

HAHAH


---

### 2724. msg_18871

**You** - 2025-06-07T22:37:15

whenever someone uses technically


---

### 2725. msg_18872

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:37:21

The other night was like almost 2 bottles\. Diff story completely\.


---

### 2726. msg_18873

**You** - 2025-06-07T22:37:20

ain't gonna happen


---

### 2727. msg_18874

**You** - 2025-06-07T22:37:28

almost as fun as per se


---

### 2728. msg_18875

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:37:46

It was fun I have to say


---

### 2729. msg_18876

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:37:53

Next day\- no


---

### 2730. msg_18877

**You** - 2025-06-07T22:38:00

I mean yeah it was super fun


---

### 2731. msg_18878

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:38:21

You need to learn to hang up on me\.


---

### 2732. msg_18879

**You** - 2025-06-07T22:38:26

I hate doing that


---

### 2733. msg_18880

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:38:32

But honestly I think the stories are done


---

### 2734. msg_18881

**You** - 2025-06-07T22:38:32

and I don't want to


---

### 2735. msg_18882

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:38:39

All out there


---

### 2736. msg_18883

**You** - 2025-06-07T22:38:44

>
no they arent


---

### 2737. msg_18884

**You** - 2025-06-07T22:38:51

you said so this afternoon


---

### 2738. msg_18885

**You** - 2025-06-07T22:38:53

gawd


---

### 2739. msg_18886

**You** - 2025-06-07T22:38:55

memory remember


---

### 2740. msg_18887

**You** - 2025-06-07T22:40:20

now you are trying to remember


---

### 2741. msg_18888

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:40:24

I mean I think they are really


---

### 2742. msg_18889

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:40:45

Just yours left 😇


---

### 2743. msg_18890

**You** - 2025-06-07T22:42:58

mmm no I think you "emphatically" agreed that you now understand what I can handle and what I cannot\.\. therefore what not to discuss\.\. I think you have lots more stories\.\. just ones I will have to use that strategy I mentioned on you earlier if you try to tell me when you are drunk and we are together\.


---

### 2744. msg_18891

**You** - 2025-06-07T22:43:51

I expect it is the details that might sting\.\. but I am just guessing\.\. but you are right I have a lot of stories\.\. most of which I don't think I would tell because again no vaile\.


---

### 2745. msg_18892

**You** - 2025-06-07T22:43:54

value\.


---

### 2746. msg_18893

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:44:42

Other than entertainment, fun


---

### 2747. msg_18894

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:44:58

I see value in that lol


---

### 2748. msg_18895

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:45:24

I don’t get fussed about the past\. Only the present\.


---

### 2749. msg_18896

**You** - 2025-06-07T22:46:17

well I still may be more hesitant to share\.


---

### 2750. msg_18897

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:46:30

lol okkkkkk


---

### 2751. msg_18898

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:47:04

So when do you think we go on our first trip together\. What year are we talking


---

### 2752. msg_18899

**You** - 2025-06-07T22:47:34

this year\.\. but it might need to be a short time frame plan\.


---

### 2753. msg_18900

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:47:42

Conference in Vegas


---

### 2754. msg_18901

**You** - 2025-06-07T22:47:49

what conference?


---

### 2755. msg_18902

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:48:00

Can’t remember


---

### 2756. msg_18903

**You** - 2025-06-07T22:48:10

Strategy doesn't get to go to conferences


---

### 2757. msg_18904

**You** - 2025-06-07T22:48:26

lol


---

### 2758. msg_18905

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:48:50

Only noticed bc one of the tours was Hoover dam and when we went as teens we suffered thru a Hoover dam tour and my mom loves to remember that\. So I forwarded her the email


---

### 2759. msg_18906

**You** - 2025-06-07T22:48:49

and the only way I can go anywhere is if Maddie is back in Moncton


---

### 2760. msg_18907

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:48:57

No I wouldn’t actually go


---

### 2761. msg_18908

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:49:07

A conference would be a cover


---

### 2762. msg_18909

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:49:20

>
Forgot


---

### 2763. msg_18910

**You** - 2025-06-07T22:49:23

I was thinking so possibly reading week depending on whether or not you have the kids


---

### 2764. msg_18911

**You** - 2025-06-07T22:49:30

that is in November


---

### 2765. msg_18912

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:49:44

k


---

### 2766. msg_18913

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:50:10

Or maybe maddie eventually meets me and is fine and just comes with one or more of my kids and they have their own room lol


---

### 2767. msg_18914

**You** - 2025-06-07T22:50:08

I mean we could probably do a weekend trip here or there\.\.


---

### 2768. msg_18915

**You** - 2025-06-07T22:50:16

but I think you meant trip trip


---

### 2769. msg_18916

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:50:19

Cottage maybe


---

### 2770. msg_18917

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:50:28

No I don’t really care where


---

### 2771. msg_18918

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:50:35

Just like more than one day


---

### 2772. msg_18919

**You** - 2025-06-07T22:50:55

yeah I think she will be ready to meet you by October\.\. my guess\. or late september


---

### 2773. msg_18920

**You** - 2025-06-07T22:51:09

That will just be tricky to navigate with Jaimie


---

### 2774. msg_18921

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:51:26

Are you guys having a parenting plan


---

### 2775. msg_18922

**You** - 2025-06-07T22:51:31

nothing to that extent


---

### 2776. msg_18923

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:51:34

That involves intros


---

### 2777. msg_18924

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:51:39

Ahh


---

### 2778. msg_18925

**You** - 2025-06-07T22:51:39

it wasn't written in yet


---

### 2779. msg_18926

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:51:56

Andrew actually said something to the effect of


---

### 2780. msg_18927

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:52:09

“If I ever date someone else …”


---

### 2781. msg_18928

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:52:17

He has never said that before


---

### 2782. msg_18929

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:52:26

So he is progressing thank gos


---

### 2783. msg_18930

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:52:29

God


---

### 2784. msg_18931

**You** - 2025-06-07T22:52:45

speaking of A did he say anything tonight


---

### 2785. msg_18932

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:52:59

Nope nadda


---

### 2786. msg_18933

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:53:15

He wasn’t home until quite a bit after I got home


---

### 2787. msg_18934

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:53:25


*1 attachment(s)*


---

### 2788. msg_18935

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:53:28

Was there


---

### 2789. msg_18936

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:53:34

Beach vball training


---

### 2790. msg_18937

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:53:47

Mar has a beach vball tourn tomorrow


---

### 2791. msg_18938

**You** - 2025-06-07T22:53:56

Yeah I know\.\.\. your parents are going


---

### 2792. msg_18939

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:54:04

Her best friend in green shorts


---

### 2793. msg_18940

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:54:09

Valé


---

### 2794. msg_18941

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:54:22

Valé and her mom keep me happy


---

### 2795. msg_18942

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:55:02

I had a nap on fri on the couch and instead of making it weird Valé goes “did you know that if you have a short nap you are more productive after\! Boss baby taught me that\!”


---

### 2796. msg_18943

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:55:09

lol she makes me laugh


---

### 2797. msg_18944

**You** - 2025-06-07T22:55:12

lol


---

### 2798. msg_18945

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:55:19

They woke me up to drive her home


---

### 2799. msg_18946

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:55:33

She lives a 5 min walk away LOL


---

### 2800. msg_18947

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:55:55

Literally around the corner


---

### 2801. msg_18948

**You** - 2025-06-07T22:55:55

your kids are lucky they have so many friends\.


---

### 2802. msg_18949

**You** - 2025-06-07T22:56:03

makes such a difference


---

### 2803. msg_18950

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:56:44

Yeah Marlowe has a ton which is precisely what I told the moms that j hang out with… so glad she has her tribe


---

### 2804. msg_18951

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:58:33

I have told Maelle’s friends moms yet\. :p I’m not as close to them


---

### 2805. msg_18952

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:58:36

Middle child


---

### 2806. msg_18953

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:58:44

Closer to older and younger


---

### 2807. msg_18954

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:58:51

\*I haven’t


---

### 2808. msg_18955

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:59:15

What time is your workout tomorrow?


---

### 2809. msg_18956

**You** - 2025-06-07T22:59:17

noon


---

### 2810. msg_18957

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T22:59:33

Why so late?


---

### 2811. msg_18958

**You** - 2025-06-07T22:59:44

that is when the trainer set the appointment


---

### 2812. msg_18959

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:00:00

So are you going to sleep in?


---

### 2813. msg_18960

**You** - 2025-06-07T23:00:03

sure a bit


---

### 2814. msg_18961

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:00:15

I wish I was there 😭


---

### 2815. msg_18962

**You** - 2025-06-07T23:00:22

so do I\.\.


---

### 2816. msg_18963

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:00:57

😢


---

### 2817. msg_18964

**You** - 2025-06-07T23:01:25

it sucks\.\. even a couple of nights now and then together would be nice\.\. lol


---

### 2818. msg_18965

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:02:04

That’s why you have to meet my parents


---

### 2819. msg_18966

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:02:09

lol


---

### 2820. msg_18967

**You** - 2025-06-07T23:02:14

yeah I swear I was ready to today\.


---

### 2821. msg_18968

**You** - 2025-06-07T23:02:17

2 weeks is fine though


---

### 2822. msg_18969

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:02:21

Just another option if things “evolve”


---

### 2823. msg_18970

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:02:40

2 weeks is good\. I can prep them next weekend


---

### 2824. msg_18971

**You** - 2025-06-07T23:02:42

I hope so\.\. because it isn't that long for me you know


---

### 2825. msg_18972

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:02:54

They heard this weekend then next then they will be prepared


---

### 2826. msg_18973

**You** - 2025-06-07T23:02:56

Reaction: 😮 from Meredith Lamb
a little over 1 month UHAUL boxes will be in my yeard


---

### 2827. msg_18974

**You** - 2025-06-07T23:02:57

yard


---

### 2828. msg_18975

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:03:01

They are in their 80s so…


---

### 2829. msg_18976

**You** - 2025-06-07T23:03:03

a week or so after that J is gone


---

### 2830. msg_18977

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:03:27

For sure?


---

### 2831. msg_18978

**You** - 2025-06-07T23:03:27

>
prep them


---

### 2832. msg_18979

**You** - 2025-06-07T23:03:28

LOL


---

### 2833. msg_18980

**You** - 2025-06-07T23:03:29

how


---

### 2834. msg_18981

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:03:47

They just need to talk to me for a few hours


---

### 2835. msg_18982

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:03:48

lol


---

### 2836. msg_18983

**You** - 2025-06-07T23:03:47

>
she said she would be gone at least a week before the move in date\.\. could be sooner\.


---

### 2837. msg_18984

**You** - 2025-06-07T23:04:07

>
why don't you share those gpt responses with them


---

### 2838. msg_18985

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:04:30

Wow \- no wonder the kids are struggling a little\. It is very very fast


---

### 2839. msg_18986

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:04:50

>
They just need talking time\. Lol


---

### 2840. msg_18987

**You** - 2025-06-07T23:04:50

yep\.\. maddie will be going as well\. likely at least until 1st week of auguest


---

### 2841. msg_18988

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:05:08

>
My parents are very engaged and ask a lot of questions


---

### 2842. msg_18989

**You** - 2025-06-07T23:05:14

>
ok\.\. not sure what that is code fore\.\. but ok


---

### 2843. msg_18990

**You** - 2025-06-07T23:05:24

they can ask me


---

### 2844. msg_18991

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:05:31

>
It will be good for her to test it out


---

### 2845. msg_18992

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:05:54

My parents are old and old people just need repetitive talk


---

### 2846. msg_18993

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:05:57

lol


---

### 2847. msg_18994

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:06:04

It’s annoying but true


---

### 2848. msg_18995

**You** - 2025-06-07T23:06:14

Reaction: ❤️ from Meredith Lamb
>
well you are good at repetitive talk


---

### 2849. msg_18996

**You** - 2025-06-07T23:06:27

so that is a good fit 😇


---

### 2850. msg_18997

**You** - 2025-06-07T23:06:44

"this one time at band camp"


---

### 2851. msg_18998

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:06:47

They think this is a rebound so they need constant reassurance as to why it is not


---

### 2852. msg_18999

**You** - 2025-06-07T23:06:50

you should start all new stories with that


---

### 2853. msg_19000

**You** - 2025-06-07T23:06:58

well


---

### 2854. msg_19001

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:07:08

I do love that movie


---

### 2855. msg_19002

**You** - 2025-06-07T23:07:13

>
like I said feed them that last gpt response\.\. it knows it isn't a rebound


---

### 2856. msg_19003

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:07:54

You know what I keep thinking about tho?


---

### 2857. msg_19004

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:08:01

And my mom hasn’t mentioned it


---

### 2858. msg_19005

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:08:03

But


---

### 2859. msg_19006

**You** - 2025-06-07T23:08:06

\.\.\.\.\. omg\.\.


---

### 2860. msg_19007

**You** - 2025-06-07T23:08:08

OMG


---

### 2861. msg_19008

**You** - 2025-06-07T23:08:22

Reaction: 👎 from Meredith Lamb
Johnny is Finch\.\. and you are Stiffler's Mom\!\!\!\!\!


---

### 2862. msg_19009

**You** - 2025-06-07T23:08:30

CLASSIC\!\!\!


---

### 2863. msg_19010

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:08:38

I always send my parents my reports cards, the kids report cards, my assessments…\.


---

### 2864. msg_19011

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:09:03

>
No\. I have a soft spot for Johnny for another reason


---

### 2865. msg_19012

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:09:40

>
The last one I sent her you clearly used ai and my mom didn’t know of ai at that point so her response to me\. Let me see if I can screenshot it


---

### 2866. msg_19013

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:09:42

One sec


---

### 2867. msg_19014

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:10:36


*1 attachment(s)*


---

### 2868. msg_19015

**You** - 2025-06-07T23:10:50

https://open\.spotify\.com/track/27L8sESb3KR79asDUBu8nW?si=aea7293dcd574494


---

### 2869. msg_19016

**You** - 2025-06-07T23:11:07

HAHAHA


---

### 2870. msg_19017

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:11:11

lol


---

### 2871. msg_19018

**You** - 2025-06-07T23:11:24

and now she questions that


---

### 2872. msg_19019

**You** - 2025-06-07T23:11:25

hmmmmm


---

### 2873. msg_19020

**You** - 2025-06-07T23:11:31

Scott had some ulterior motive


---

### 2874. msg_19021

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:11:49

>
I mean if it wasn’t socially frowned upon I would be stifler’s mom probably\.


---

### 2875. msg_19022

**You** - 2025-06-07T23:11:58

1000%


---

### 2876. msg_19023

**You** - 2025-06-07T23:12:04

no doubt in my mind


---

### 2877. msg_19024

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:12:12

I keep thinking about the walk on water comment


---

### 2878. msg_19025

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:12:21

Yeah but not just Johnny\. Arian\.


---

### 2879. msg_19026

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:12:23

Mac


---

### 2880. msg_19027

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:12:26

Max


---

### 2881. msg_19028

**You** - 2025-06-07T23:12:24

>
I am going to keep thinking about this comment for a while


---

### 2882. msg_19029

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:12:34

lol


---

### 2883. msg_19030

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:13:18

Mac told this kid max that I had the hots for him when all I said was that he is a good looking kid and Chloe should date him


---

### 2884. msg_19031

**You** - 2025-06-07T23:13:50

eesh Mer\.\.\. be careful\.\. it might look good to eat\.\. but I promise\.\. someone catches you\.\.\.\.\.\.\.\.\.\.


---

### 2885. msg_19032

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:14:02

Did I tell you that max was super happy that I thought he was good looking? Like wtf


---

### 2886. msg_19033

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:14:14

I made one comment


---

### 2887. msg_19034

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:14:17

lol


---

### 2888. msg_19035

**You** - 2025-06-07T23:14:22

>
why wouldn't he\.\. hot mom says I am cute\.\. awesome\!\!\!


---

### 2889. msg_19036

**You** - 2025-06-07T23:14:23

score


---

### 2890. msg_19037

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:14:42

Anyway I would never


---

### 2891. msg_19038

**You** - 2025-06-07T23:14:45

sure sure\.\.


---

### 2892. msg_19039

**You** - 2025-06-07T23:15:00

I don't have to compete against the past\.\. just youth\!


---

### 2893. msg_19040

**You** - 2025-06-07T23:15:01

lol


---

### 2894. msg_19041

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:15:07

Seriously come on


---

### 2895. msg_19042

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:15:26

No one could compete with you now\. You weren’t in the picture then


---

### 2896. msg_19043

**You** - 2025-06-07T23:16:19

>
mmmm hmmm\.  heh you should continue being who you are\.\. I know you aren't like that\.\. and there is nothing wrong with thinking anyone is cute honestly\.


---

### 2897. msg_19044

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:16:40

I know\. Really


---

### 2898. msg_19045

**You** - 2025-06-07T23:16:46

Reaction: 🙄 from Meredith Lamb
that was a test\!\!\!


---

### 2899. msg_19046

**You** - 2025-06-07T23:16:48

HAH


---

### 2900. msg_19047

**You** - 2025-06-07T23:16:50

j/k


---

### 2901. msg_19048

**You** - 2025-06-07T23:16:58

j/k


---

### 2902. msg_19049

**You** - 2025-06-07T23:17:00

j/k


---

### 2903. msg_19050

**You** - 2025-06-07T23:17:06

cmon


---

### 2904. msg_19051

**You** - 2025-06-07T23:17:09

that was FUNNY


---

### 2905. msg_19052

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:17:13

So my mom was asking about family when she all of a sudden realized she might meet you soon


---

### 2906. msg_19053

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:17:36

Reaction: ❤️ from Scott Hicks
>
It was, as always\. That’s why I love you 😛


---

### 2907. msg_19054

**You** - 2025-06-07T23:18:02

that being said\.\.


---

### 2908. msg_19055

**You** - 2025-06-07T23:18:03

O dpm


---

### 2909. msg_19056

**You** - 2025-06-07T23:18:11

I don't tell my daughter her friends are cute


---

### 2910. msg_19057

**You** - 2025-06-07T23:18:29

nor do I go anywhere near them


---

### 2911. msg_19058

**You** - 2025-06-07T23:18:31

lol


---

### 2912. msg_19059

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:18:45

That’s what Andrew said


---

### 2913. msg_19060

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:18:46

lol


---

### 2914. msg_19061

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:18:59

This was like a year ago


---

### 2915. msg_19062

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:19:10

Or more not sure


---

### 2916. msg_19063

**You** - 2025-06-07T23:19:08

oh was he jealous of johnny too


---

### 2917. msg_19064

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:19:20

No not Johnny\. Max\.


---

### 2918. msg_19065

**You** - 2025-06-07T23:19:24

hehe more trends\.


---

### 2919. msg_19066

**You** - 2025-06-07T23:19:30

data is fun


---

### 2920. msg_19067

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:19:37

lol


---

### 2921. msg_19068

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:19:53

>
It really is


---

### 2922. msg_19069

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:20:03

Ok so can we turn to my mom topic


---

### 2923. msg_19070

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:20:11

So I told about your family


---

### 2924. msg_19071

**You** - 2025-06-07T23:20:10

yes


---

### 2925. msg_19072

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:20:23

And your parents\. Rip 😭


---

### 2926. msg_19073

**You** - 2025-06-07T23:20:22

both parents deceased


---

### 2927. msg_19074

**You** - 2025-06-07T23:20:26

half sister


---

### 2928. msg_19075

**You** - 2025-06-07T23:20:29

\*3


---

### 2929. msg_19076

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:20:53

My mom is obsessed with ancestry


---

### 2930. msg_19077

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:21:03

3?


---

### 2931. msg_19078

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:21:09

I thought 2?


---

### 2932. msg_19079

**You** - 2025-06-07T23:21:11

Katie


---

### 2933. msg_19080

**You** - 2025-06-07T23:21:21

and the other 2


---

### 2934. msg_19081

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:21:24

Oh


---

### 2935. msg_19082

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:21:35

I consider Katie whole


---

### 2936. msg_19083

**You** - 2025-06-07T23:21:38

well so do I


---

### 2937. msg_19084

**You** - 2025-06-07T23:21:40

but still


---

### 2938. msg_19085

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:21:43

My sister Rachael is whole


---

### 2939. msg_19086

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:21:55

Rachael is adopted but whole


---

### 2940. msg_19087

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:22:04

K, whatever


---

### 2941. msg_19088

**You** - 2025-06-07T23:22:01

so did she have any questions about family


---

### 2942. msg_19089

**You** - 2025-06-07T23:22:06

health issues


---

### 2943. msg_19090

**You** - 2025-06-07T23:22:07

lol


---

### 2944. msg_19091

**You** - 2025-06-07T23:22:14

religious affiliations


---

### 2945. msg_19092

**You** - 2025-06-07T23:22:17

political leanings


---

### 2946. msg_19093

**You** - 2025-06-07T23:22:33

am I a virgin?


---

### 2947. msg_19094

**You** - 2025-06-07T23:22:38

born again


---

### 2948. msg_19095

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:22:50

No but when I said I as surprised at how small your fam is she said “many families are like that”


---

### 2949. msg_19096

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:22:58

I was surprised I didn’t know that


---

### 2950. msg_19097

**You** - 2025-06-07T23:23:05

you just have a massive one


---

### 2951. msg_19098

**You** - 2025-06-07T23:23:18

but yeah lots of small families as generations move forward


---

### 2952. msg_19099

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:23:23

So then, I said our family is so big and bad shit crazy it’s a little like weird


---

### 2953. msg_19100

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:23:45

She said yeah many cons to a big family


---

### 2954. msg_19101

**You** - 2025-06-07T23:23:51

true


---

### 2955. msg_19102

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:23:56

Then went on to talk about her sisters like


---

### 2956. msg_19103

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:23:58

lol


---

### 2957. msg_19104

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:02

I was surprised


---

### 2958. msg_19105

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:12

My mom and dad both have 3 sisters


---

### 2959. msg_19106

**You** - 2025-06-07T23:24:19

lot of estrogen


---

### 2960. msg_19107

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:28

Yeah\!


---

### 2961. msg_19108

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:39

And the majority of cousins are girls


---

### 2962. msg_19109

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:42

So odd


---

### 2963. msg_19110

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:48

We are a very girl family


---

### 2964. msg_19111

**You** - 2025-06-07T23:24:49

same


---

### 2965. msg_19112

**You** - 2025-06-07T23:24:53

6 girls


---

### 2966. msg_19113

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:24:59

I do have nephews tho


---

### 2967. msg_19114

**You** - 2025-06-07T23:24:56

between katie and i


---

### 2968. msg_19115

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:25:12

You mean 5


---

### 2969. msg_19116

**You** - 2025-06-07T23:25:12

we are the end of the line though


---

### 2970. msg_19117

**You** - 2025-06-07T23:25:21

yeah sorry I never told you about my other daughter\.


---

### 2971. msg_19118

**You** - 2025-06-07T23:25:24

oops


---

### 2972. msg_19119

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:25:30

lol


---

### 2973. msg_19120

**You** - 2025-06-07T23:25:28

slipped my mind


---

### 2974. msg_19121

**You** - 2025-06-07T23:25:38

she's half french


---

### 2975. msg_19122

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:25:58

I do have 4 nephews and 3 great nephews so the boys are coming in strong lately


---

### 2976. msg_19123

**You** - 2025-06-07T23:26:09

"great" nephews


---

### 2977. msg_19124

**You** - 2025-06-07T23:26:13

hee hee


---

### 2978. msg_19125

**You** - 2025-06-07T23:26:22

I am so far away from that


---

### 2979. msg_19126

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:26:31

Yeah my sis is a grandma


---

### 2980. msg_19127

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:26:35

I’m a great aunt


---

### 2981. msg_19128

**You** - 2025-06-07T23:26:38

crazy


---

### 2982. msg_19129

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:26:53

My sister and I had this one great aunt that we loved and that is me now 😇


---

### 2983. msg_19130

**You** - 2025-06-07T23:27:12

I am not surprised\.\. you do the best you can at everything


---

### 2984. msg_19131

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:28:27

So when I first started working for you


---

### 2985. msg_19132

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:28:37

The first wed I worked from home


---

### 2986. msg_19133

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:28:41

I didn’t work


---

### 2987. msg_19134

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:28:55

I made cookie for my great nephews 1st birthday


---

### 2988. msg_19135

**You** - 2025-06-07T23:29:06

lol shame on you\!\!


---

### 2989. msg_19136

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:30:47


*1 attachment(s)*


---

### 2990. msg_19137

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:31:42

That’s what I did all day lol


---

### 2991. msg_19138

**You** - 2025-06-07T23:31:52

lol


---

### 2992. msg_19139

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:31:57

My niece was happy


---

### 2993. msg_19140

**You** - 2025-06-07T23:31:58

Reaction: 😂 from Meredith Lamb
should have gave you a 3


---

### 2994. msg_19141

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:32:50

https://www\.flickr\.com/gp/74517971@N00/YADe1p3BHj


---

### 2995. msg_19142

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:33:06

I couldn’t let my niece down


---

### 2996. msg_19143

**You** - 2025-06-07T23:33:06

lol i was just going back in my emails to when you started\.\.


---

### 2997. msg_19144

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:33:30

Haha


---

### 2998. msg_19145

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:33:50

Sorry it might not have been the first we’d


---

### 2999. msg_19146

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:33:57

The wed before the party


---

### 3000. msg_19147

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:34:09

I think the party was June 22, 2022


---

### 3001. msg_19148

**You** - 2025-06-07T23:34:20

Wine??


---

### 3002. msg_19149

**You** - 2025-06-07T23:34:22

5


---

### 3003. msg_19150

**You** - 2025-06-07T23:34:31

I love you btw


---

### 3004. msg_19151

**You** - 2025-06-07T23:35:12

you were so formal at the start\. lol


---

### 3005. msg_19152

**You** - 2025-06-07T23:35:18

very polite


---

### 3006. msg_19153

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:37:07

I am on 5 and last of the bottle :\( I’m a loser and can’t keep to my word


---

### 3007. msg_19154

**You** - 2025-06-07T23:37:17

>
I LOVE YOU\!\!\!\!


---

### 3008. msg_19155

**You** - 2025-06-07T23:37:29

I knew you would do 5


---

### 3009. msg_19156

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:37:45

Andrew is talking to me about volleyball


---

### 3010. msg_19157

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:37:48

Omg


---

### 3011. msg_19158

**You** - 2025-06-07T23:37:48

LOL


---

### 3012. msg_19159

**You** - 2025-06-07T23:37:55

what does he think you are doing when you are talking to me


---

### 3013. msg_19160

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:38:16

Marlowe is ranked in beach volleyball 7 out of 100


---

### 3014. msg_19161

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:38:29

No idea what he thinks lol


---

### 3015. msg_19162

**You** - 2025-06-07T23:38:28

nice\.\. Andrew is thinking Team Canada?


---

### 3016. msg_19163

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:38:34

I’m always on my phone


---

### 3017. msg_19164

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:38:47

Andrew is thinking scholarship probably but it is dumb


---

### 3018. msg_19165

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:39:07

He’s done


---

### 3019. msg_19166

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:39:08

Man


---

### 3020. msg_19167

**You** - 2025-06-07T23:39:08

>
I actually think you tried to get off this chat earlier\.\. maybe then you might have stopped\.\.


---

### 3021. msg_19168

**You** - 2025-06-07T23:39:14

you pulled a me\.\. LOL


---

### 3022. msg_19169

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:39:25

He’s in a good mood for some reason\. Everyone is\. Weird\. Weather?


---

### 3023. msg_19170

**You** - 2025-06-07T23:39:46

well don't ask questions then\.\. I know\.\. hehehe


---

### 3024. msg_19171

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:39:57

>
I did not try to get off\. I would talk to you all night, but I thought you should spend some time with your girls\.


---

### 3025. msg_19172

**You** - 2025-06-07T23:40:03

not that


---

### 3026. msg_19173

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:40:07

I was trying to be nice


---

### 3027. msg_19174

**You** - 2025-06-07T23:40:09

I was thinking the workout


---

### 3028. msg_19175

**You** - 2025-06-07T23:40:29

whenever I wanted to get off the phone when I was at Dalhousie


---

### 3029. msg_19176

**You** - 2025-06-07T23:40:39

I used to ask Jaimie what time she worked in the morning


---

### 3030. msg_19177

**You** - 2025-06-07T23:40:45

used to drive her fucking crazye


---

### 3031. msg_19178

**You** - 2025-06-07T23:40:53

So\.\.\.\. what time do you work tomorrow\.


---

### 3032. msg_19179

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:40:56

lol y?


---

### 3033. msg_19180

**You** - 2025-06-07T23:40:55

Code\.\.


---

### 3034. msg_19181

**You** - 2025-06-07T23:41:00

I want to get off the phone now\.


---

### 3035. msg_19182

**You** - 2025-06-07T23:41:03

we have talked too long


---

### 3036. msg_19183

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:41:11

Ohhhhhh


---

### 3037. msg_19184

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:41:13

lol


---

### 3038. msg_19185

**You** - 2025-06-07T23:41:12

and there isn't anything that interesting\.


---

### 3039. msg_19186

**You** - 2025-06-07T23:41:18

so when you asked when I worked out tomorrow\.


---

### 3040. msg_19187

**You** - 2025-06-07T23:41:23

I actually laughed here\.


---

### 3041. msg_19188

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:41:42

Oh no I was just genuinely curious


---

### 3042. msg_19189

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:41:54

I mean, I will get off whenever you want to though honestly


---

### 3043. msg_19190

**You** - 2025-06-07T23:41:57

I know\.\. I figured\.\. was just initial reaction at having it done to me\.


---

### 3044. msg_19191

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:42:10

You don’t have to stay on with me till 3 AM like the other night like oh my God I can’t believe you did that sober


---

### 3045. msg_19192

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:42:35

I would’ve passed out


---

### 3046. msg_19193

**You** - 2025-06-07T23:43:23

I was highly engaged


---

### 3047. msg_19194

**You** - 2025-06-07T23:43:41

Very in the moment\.


---

### 3048. msg_19195

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:43:51

lol


---

### 3049. msg_19196

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:44:05

But like a big waste of time right


---

### 3050. msg_19197

**You** - 2025-06-07T23:44:07

no


---

### 3051. msg_19198

**You** - 2025-06-07T23:44:16

we resolved a bunch of shit I felt\.


---

### 3052. msg_19199

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:44:21

🧐


---

### 3053. msg_19200

**You** - 2025-06-07T23:44:22

remember what I said


---

### 3054. msg_19201

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:44:32

Did we?


---

### 3055. msg_19202

**You** - 2025-06-07T23:44:56

I would rather be uncomfortable and know everything about you then be comfortable and not\.  Knowing all of you is the most important thing\.\.


---

### 3056. msg_19203

**You** - 2025-06-07T23:45:03

but not some details


---

### 3057. msg_19204

**You** - 2025-06-07T23:45:05

lol


---

### 3058. msg_19205

**You** - 2025-06-07T23:45:43

Even the meeting Chris thing I was good with\.


---

### 3059. msg_19206

**You** - 2025-06-07T23:45:51

you were the one that freaked out after you suggested it


---

### 3060. msg_19207

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:45:56

I wish I knew the “details” ah well


---

### 3061. msg_19208

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:45:57

lol


---

### 3062. msg_19209

**You** - 2025-06-07T23:46:05

>
no you know the details


---

### 3063. msg_19210

**You** - 2025-06-07T23:46:11

I don't need to know them


---

### 3064. msg_19211

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:46:17

Well, if we stay together, you probably might have to meet him eventually


---

### 3065. msg_19212

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:46:25

Andrew has never met him


---

### 3066. msg_19213

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:46:41

I could never intro Chris to Andrew


---

### 3067. msg_19214

**You** - 2025-06-07T23:46:47

like


---

### 3068. msg_19215

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:46:52

Chris is a trouble maker


---

### 3069. msg_19216

**You** - 2025-06-07T23:46:49

ok


---

### 3070. msg_19217

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:46:57

He would say something


---

### 3071. msg_19218

**You** - 2025-06-07T23:47:02

How is Andrew so threatened by Chris when he didn't know


---

### 3072. msg_19219

**You** - 2025-06-07T23:47:13

>
what would he say


---

### 3073. msg_19220

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:47:34

Andrew isn’t threatened by Chris bc he doesn’t know and I have never talked about him


---

### 3074. msg_19221

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:47:52

>
He’s so gay\. He’d make some comment\.


---

### 3075. msg_19222

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:47:59

Some sarcastic comment


---

### 3076. msg_19223

**You** - 2025-06-07T23:47:57

you said Andrew didn't like him or when you talked about Chris and/or Jeremy


---

### 3077. msg_19224

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:48:09

No


---

### 3078. msg_19225

**You** - 2025-06-07T23:48:07

this goes back a ways btw


---

### 3079. msg_19226

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:48:14

Andrew is fine with Chris


---

### 3080. msg_19227

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:48:26

Jeremy and Gavin had issues with Chris


---

### 3081. msg_19228

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:48:39

Andrew knows shit about Chris


---

### 3082. msg_19229

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:48:45

Never told him


---

### 3083. msg_19230

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:49:05

Also


---

### 3084. msg_19231

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:49:24

Chris’ comment about us hooking up was pretty innocent and on text only


---

### 3085. msg_19232

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:49:32

Like it wasn’t real life


---

### 3086. msg_19233

**You** - 2025-06-07T23:50:54

you don't need to go back to that lol\.\. you beat that hard last time\.


---

### 3087. msg_19234

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:51:28

I’m actually trying to find it to prove it is not that deep


---

### 3088. msg_19235

**You** - 2025-06-07T23:51:30

>
I like sarcasm\.\. I think we might get along then\.  I see it more as a fun challenge\.  As long as he has the right attitude


---

### 3089. msg_19236

**You** - 2025-06-07T23:51:46

>
here is the thing\.\. it isn't what he said Mer\.


---

### 3090. msg_19237

**You** - 2025-06-07T23:51:49

you don't get it


---

### 3091. msg_19238

**You** - 2025-06-07T23:52:06

You are not an overly emotional person


---

### 3092. msg_19239

**You** - 2025-06-07T23:52:12

not outwardly


---

### 3093. msg_19240

**You** - 2025-06-07T23:52:52

but you looked hurt and sad and wistful talking about him, and the fun you guys had\. It doesn't matter what he wrote\.\. it matters what you felt\.  That was what I saw, that is what was threatening\.


---

### 3094. msg_19241

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:55:28

k well I think the only reason I reached out in March was to tell him I was getting separated and to tell him about you and then he never responded back\. That’s the first time he’s never responded back\.


---

### 3095. msg_19242

**You** - 2025-06-07T23:55:28

shit nothing in signal\.\. I know what you said to me was in messenger and I don't have those DAMNIT lol


---

### 3096. msg_19243

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:55:51

Huh?


---

### 3097. msg_19244

**You** - 2025-06-07T23:56:07

I was looking for a comment you made\.\. cannot find it\.\. must have been pre signal\.\. no matter\.


---

### 3098. msg_19245

**You** - 2025-06-07T23:56:11

sorry keep going


---

### 3099. msg_19246

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:56:27

A comment I made?


---

### 3100. msg_19247

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:56:37

you must remember it?


---

### 3101. msg_19248

**You** - 2025-06-07T23:56:42

I do\.\. but you said I was wrong\.


---

### 3102. msg_19249

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:56:46

I trust your memory


---

### 3103. msg_19250

**You** - 2025-06-07T23:56:57

Actually you know what


---

### 3104. msg_19251

**You** - 2025-06-07T23:57:00

you never wrote it


---

### 3105. msg_19252

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:57:04

Wrong about what?


---

### 3106. msg_19253

**You** - 2025-06-07T23:57:02

you said it


---

### 3107. msg_19254

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:57:10

I’m confused


---

### 3108. msg_19255

**You** - 2025-06-07T23:57:14

That night at the cottage\.\. when you told me the stories about you and chris


---

### 3109. msg_19256

**You** - 2025-06-07T23:57:18

you started by saying


---

### 3110. msg_19257

**You** - 2025-06-07T23:57:21

Andrew would hate this


---

### 3111. msg_19258

**You** - 2025-06-07T23:57:32

he never liked it when I talked about Chris or Jeremy\.


---

### 3112. msg_19259

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:57:38

>
True true


---

### 3113. msg_19260

**You** - 2025-06-07T23:57:42

then you started talking to me about them\.


---

### 3114. msg_19261

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:58:10

>
Awwwwww poor Scott 😢


---

### 3115. msg_19262

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:58:23

I’m sorry


---

### 3116. msg_19263

**You** - 2025-06-07T23:58:22

yep all that mental angst


---

### 3117. msg_19264

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:58:36

Honestly I am\. I’m an idiot


---

### 3118. msg_19265

**You** - 2025-06-07T23:58:46

you need to stop apologizing\.\. I don't want you to apologize


---

### 3119. msg_19266

**You** - 2025-06-07T23:58:50

I don't care if you do it again\.


---

### 3120. msg_19267

**You** - 2025-06-07T23:58:55

I love you period


---

### 3121. msg_19268

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:59:02

I just like to talk about shit so it annoys me when I “can’t”


---

### 3122. msg_19269

**You** - 2025-06-07T23:59:05

I know


---

### 3123. msg_19270

**You** - 2025-06-07T23:59:30

shit that reminds me


---

### 3124. msg_19271

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:59:38

And my mom never liked all the gay guys at work so she never liked Chris cause he was gay and Michael boy because he was gay and a drag queen and all the gay guys that used to hang out with her at work\. She was always concerned about all the gay guys I hung out with that work\. There were like six of them\.


---

### 3125. msg_19272

**Meredith Lamb \(\+14169386001\)** - 2025-06-07T23:59:46

So I couldn’t talk to my mom about shit


---

